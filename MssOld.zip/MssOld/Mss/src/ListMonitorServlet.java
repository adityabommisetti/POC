// $Id: ListMonitorServlet.java,v 1.1 2014/06/26 07:56:03 praveen Exp $

import java.io.*;
import java.util.*;
import java.sql.*;

import javax.servlet.*;
import javax.servlet.http.*;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import com.ps.mss.db.DbConn;

public class ListMonitorServlet extends HttpServlet
{
	private static Logger logger=LoggerFactory.getLogger(ListMonitorServlet.class);

public void doGet(HttpServletRequest request, HttpServletResponse response)
  throws ServletException, IOException
{
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();

    out.println("<HTML>");
    out.println("<HEAD>");
    out.println("<TITLE>Monitor List</TITLE>");
    out.println("</HEAD>");
    out.println("<BODY>");

    ServletContext sc = getServletContext();
    Hashtable monitor = (Hashtable)sc.getAttribute("monitor");

    if (monitor != null)
    {
        String      str;
        HttpSession session;
       
        Connection conn = null;
        Statement  stmt = null;
        ResultSet  rs   = null;

        try {
        	
        	conn = DbConn.getConnection();
            stmt = conn.createStatement();

            Enumeration e = monitor.keys();
            while ( e.hasMoreElements() )
            {
                str = (String)e.nextElement();
                session = (HttpSession)monitor.get(str);
                out.println(str + " " + session.getId() + " ");
                String SQL = "SELECT signedon_yn, cust_nbr" +
                       " FROM secuser, secgroup" +
                      " WHERE user_id = '" + str + "'" +
                        " AND secuser.group_id = secgroup.group_id";
                rs = stmt.executeQuery(SQL);
                if (rs.next())
                {
                    String SignedOn_YN = rs.getString(1);
                    String Cust_Nbr = rs.getString(2);
                    out.println("SignedOn_YN = " + SignedOn_YN + "  Customer: " + Cust_Nbr);
                }
                out.println("<BR>");
            }

        } catch (SQLException eSQL) {
            logger.error(eSQL.getErrorCode() + " : " + eSQL.getMessage());
        } catch (NullPointerException eNullPointer) {
            logger.error("NullPointer Exception: " + eNullPointer.getMessage());
        } finally {

            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
                logger.error( e.getMessage());
            }

            try {
                if (stmt != null)
                    stmt.close();
            } catch (Exception e) {
                logger.error( e.getMessage());
            }


            try {
                if (conn != null)
                    conn.close();
            } catch (Exception e) {
                logger.error( e.getMessage());
            }
        }

    }

    out.println("</BODY>");
    out.println("</HTML>");

}

}



