import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ps.http.RequestHandler;
import com.ps.http.HttpClientRequestHandler;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import com.ps.mss.dao.EEMDao;
import com.ps.mss.dao.EEMEnrollDao;
import com.ps.mss.dao.model.EMMbrTriggerVO;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.DbConnWeb;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.security.SessionManager;
import com.ps.mss.util.MssProperties;
import com.ps.util.DateUtil;
import com.ps.util.StringUtil;

/**
 * 
 * Author: Lakshman Sai Avirneni Date: 08/02/2016 Copyright Notice: Description:
 * Wipro Healthcare Services iDesk tracking #: <375448> Internal CR to manual
 * create invoices for members
 */
@SuppressWarnings("serial")
public class MemberBillingHistoryRequestsServlet extends HttpServlet {
	private static Logger logger=LoggerFactory.getLogger(MemberBillingHistoryRequestsServlet.class);

	@SuppressWarnings("unused")
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.info("MemberBillingHistoryRequestsServlet");
		HttpSession session = SessionManager.getSession(request);
		String method = ((String) request.getParameter("requestName")).trim();
		//logger.error(method);
		Connection conn = null;
		String targetURL = null;
		RequestHandler requestHandler = null;
		String trggerIds = "";

		try {
			conn = DbConnWeb.getConnection();
			String MFId = (String) session.getAttribute("MF_id");
			String eemDb = (String) session.getAttribute(SessionManager.EEMDB);
			String userId = (String) session.getAttribute(Constants.SESSION_USER_ID);
			conn = DbConn.reGetConnection(conn, eemDb);

			if (session == null) {
				logger.error("No Session");
				response.sendRedirect((String) response.encodeRedirectURL("/mss/jsp/ErrorPFJsp.jsp?Msg=Page+Expired"));
				return;
			}

			String User_id = (String) session.getAttribute("User_id");
			if (User_id == null) {
				logger.error("Null User_id");
				response.sendRedirect(
						(String) response.encodeRedirectURL("/mss/jsp/ErrorPFJsp.jsp?Msg=Invalid+Session"));
				return;
			}
			logger.debug("Request Received from " + User_id);
			String historyresponse = null;
			if ("mbrpremreq".equals(method)) {
                historyresponse = memberPremiumHistoryRequest(request, response, conn, MFId, userId);
                logger.debug("mbrpremreq historyresponse :: " + historyresponse);
			}
			if ("mbrinvoicereq".equals(method)) {
				historyresponse = memberInvoiceSummaryRequest(request, response, conn, MFId, userId);
				
			}
			if ("mbrpremreq".equals(method) || "mbrinvoicereq".equals(method) ) {
				logger.info("Dataset has been triggered");
				logger.info("Dataset triggered");

				if(historyresponse.equalsIgnoreCase("Submitted Successfully")){
					logger.info("Dataset will triggered");

					
					int timeOut = session.getMaxInactiveInterval();
					session.setAttribute("MaxInactiveInterval", new Integer(timeOut));
					targetURL = "http://" + MssProperties.getFileAppURL() + "/servlet/ReceiveFileServlet";
	
					 requestHandler = new HttpClientRequestHandler(targetURL);
					 requestHandler.processRequest(request, response);
					logger.info("Dataset has been triggered successfully");
				
				
			}else {
				logger.info("Dataset is going to trigger");
				session.setAttribute("historyresponse", historyresponse);
				session.setAttribute("memberIds", ((String) request.getParameter("memberId")).trim());
				if("mbrinvoicereq".equals(method)){
					session.setAttribute("ssaIds", ((String) request.getParameter("ssaId")).trim());
				}				
				response.sendRedirect(request.getHeader("referer"));
				logger.info("Dataset did not get triggered successfully");
			}
			
		
		}else {
			logger.info("Dataset has been set to trigger");
				int timeOut = session.getMaxInactiveInterval();
				session.setAttribute("MaxInactiveInterval", new Integer(timeOut));
				session.setMaxInactiveInterval(18000);
				
				targetURL = "http://" + MssProperties.getFileAppURL() + "/servlet/ReceiveFileServlet";

				 requestHandler = new HttpClientRequestHandler(targetURL);
				 requestHandler.processRequest(request, response);
				logger.info("Dataset did not get triggered");
				
		}
		
			
		} catch (ApplicationException e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		} finally {
			try {
				if (conn != null)
					conn.close();
				targetURL = null;
				requestHandler = null;
			} catch (Exception e) {
				e.printStackTrace();
				logger.error(e.getMessage());
			}
		}

	
	}
	

	@SuppressWarnings({ "rawtypes" })
	private String memberInvoiceSummaryRequest(HttpServletRequest request, HttpServletResponse response, Connection conn,
			String MFId, String userId) throws ApplicationException, ServletException, IOException {
		int insertTag = 0;
		String trggerIds = "";
		String invalidIds = "";
		String memberIds = ((String) request.getParameter("memberId")).trim();
		String ssaIds = ((String) request.getParameter("ssaId")).trim();
		ArrayList memberIdList = getValidMemberId(memberIds.split(","));
		ArrayList arraySsa = getValidSSA(memberIdList, ssaIds.split(","));
		for (int i = 0; i < memberIdList.size(); i++) {
			logger.debug("member Id:" + memberIdList.get(i) + " SSA Id:" + arraySsa.get(i));
		}
		for (int i = 0; i < memberIdList.size(); i++) {
			if (arraySsa != null) {
				if (StringUtil.nonNullTrim((String) arraySsa.get(i)).equals("SMIS")) {
					insertTag = insertPremiumHistoryReTrigger(conn, MFId,
							StringUtil.nonNullTrim((String) memberIdList.get(i)), userId, "SMIS");
				} else if (StringUtil.nonNullTrim((String) arraySsa.get(i)).equals("NSMIS")) {
					insertTag = insertPremiumHistoryReTrigger(conn, MFId,
							StringUtil.nonNullTrim((String) memberIdList.get(i)), userId, "SMI");
				}
			}
			if (insertTag != 1) {
				logger.info("Error occured while submitting, member id entered:" + (String) memberIdList.get(i)
						+ ",submitted by " + userId);

			} else {
				logger.info("Submitted Successfully, member id entered:" + (String) memberIdList.get(i)
						+ ",submitted by" + userId);
			}
			if(insertTag == 0){
				if(!trggerIds.isEmpty()){
					trggerIds = trggerIds + ",";
				}
				trggerIds = trggerIds + StringUtil.nonNullTrim((String) memberIdList.get(i));
			}
			if(insertTag == -1){
				if(!invalidIds.isEmpty()){
					invalidIds = invalidIds + ",";
				}
				invalidIds = invalidIds + StringUtil.nonNullTrim((String) memberIdList.get(i));
			}
		}
		String msg = "";
		if(!invalidIds.isEmpty()){
			if(invalidIds.contains(",")){
				msg = "Member Ids :"+invalidIds+" are invalid.";
			}else{
				msg = "Member Id :"+invalidIds+" is invalid.";
			}
		}
		if(!trggerIds.isEmpty()){
			if(!msg.isEmpty()){
				msg = msg+"\\n";
			}
			if(trggerIds.contains(",")){
				msg = msg+"Member Ids :"+trggerIds+" are already triggered.";
			}else{
				msg = msg+"Member Id :"+trggerIds+" is already triggered.";
			}
		}	
		if(msg.isEmpty()){
			msg = "Submitted Successfully";
		}
		logger.info("Error in logging in");
		return msg;
	}

	@SuppressWarnings({ "rawtypes" })
	private String memberPremiumHistoryRequest(HttpServletRequest request, HttpServletResponse response, Connection conn,
			String MFId, String userId) throws ApplicationException, ServletException, IOException {
		String trggerIds = "";
		String invalidIds = "";
		int insertTag = 0;
		String memberIds = ((String) request.getParameter("memberId")).trim();
		ArrayList memberIdList = getValidMemberId(memberIds.split(","));
		for (int i = 0; i < memberIdList.size(); i++) {
			insertTag = insertPremiumHistoryReTrigger(conn, MFId, StringUtil.nonNullTrim((String) memberIdList.get(i)),
					userId, "PHR");
			if (insertTag == -1) {
				logger.info("Error occured while submitting, member id entered:" + (String) memberIdList.get(i)
						+ ", submitted by " + userId);

			} else if(insertTag == 0){
				logger.info("Trigger cannot be generated, member id entered:" + (String) memberIdList.get(i)
						+ ", submitted by " + userId);
			}
			else {
				logger.info("Submitted Successfully, member id entered:" + (String) memberIdList.get(i)
				+ ", submitted by " + userId);
				
			}
			if(insertTag == 0){
				if(!trggerIds.isEmpty()){
					trggerIds = trggerIds + ",";
				}
				trggerIds = trggerIds + StringUtil.nonNullTrim((String) memberIdList.get(i));
			}
			if(insertTag == -1){
				if(!invalidIds.isEmpty()){
					invalidIds = invalidIds + ",";
				}
				invalidIds = invalidIds + StringUtil.nonNullTrim((String) memberIdList.get(i));
			}
		}
		String msg = "";
		if(!invalidIds.isEmpty()){
			if(invalidIds.contains(",")){
				msg = "Member Ids :"+invalidIds+" are invalid.";
			}else{
				msg = "Member Id :"+invalidIds+" is invalid.";
			}
		}
		if(!trggerIds.isEmpty()){
			if(!msg.isEmpty()){
				msg = msg+"\\n";
			}else{
				msg = "";
			}
			if(trggerIds.contains(",")){
				msg = msg+"Member Ids :"+trggerIds+" are already triggered.";
			}else{
				msg = msg+"Member Id :"+trggerIds+" is already triggered.";
			}
		}	
		if(msg.isEmpty()){
			msg = "Submitted Successfully";
		}
		return msg;

	}

	public boolean getMemberIdCheck(Connection conn, String MFId, String memberId) throws ApplicationException {

		boolean memberPresent = false;
		try {
			memberPresent = new EEMDao().getMemberIdDetails(conn, MFId, memberId);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return memberPresent;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public ArrayList getValidMemberId(String[] memberId) throws ApplicationException {

		ArrayList validMemberId = new ArrayList();
		try {
			for (int i = 0; i < memberId.length; i++) {
				if (StringUtil.nonNullTrim(memberId[i]).length() > 0) {
					validMemberId.add(memberId[i]);
				}
			}

		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		return validMemberId;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public ArrayList getValidSSA(ArrayList memberId, String[] ssa) throws ApplicationException {

		ArrayList ssaV = new ArrayList();
		try {
			for (int i = 0; i < memberId.size(); i++) {
				if (StringUtil.nonNullTrim((String) memberId.get(i)).length() > 0) {
					ssaV.add((String) ssa[i]);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return ssaV;
	}

	@SuppressWarnings("rawtypes")
	public int insertPremiumHistoryReTrigger(Connection conn, String MFId, String memberId, String UserId,
			String triggerCode) throws ApplicationException {
		logger.info("Inserting into EM_MBR_TRIGGER table");
		ArrayList plan = null;
		int insertTag = 0;
		DateUtil du = new DateUtil();
		String ts = du.getDB2DTS();

		try {

			EMMbrTriggerVO trig = new EMMbrTriggerVO();
			EEMEnrollDao enrlDao = new EEMEnrollDao();
			plan = new EEMDao().getMemberPlanDetails(conn, MFId, memberId);
			trig.setCustomerId(MFId);
			trig.setMemberId(memberId);
			trig.setTriggerType("BIL");
			trig.setEffectiveDate(du.getTodaysDate());
			trig.setTriggerCode(triggerCode);
			trig.setPlanId(plan.get(0).toString());
			trig.setPbpId(plan.get(1).toString());
			trig.setPlanDesignation(plan.get(2).toString());
			trig.setTriggerStatus(EEMConstants.TRIGGER_STATUS_OPEN);
			trig.setProcessSource(EEMConstants.PROCESS_SOURCE_MBR);
			trig.setOrigTriggerType("");
			trig.setOrigTriggerCode("");
			trig.setOrigEffectiveDate("");
			trig.setOrigTriggerCreateTime("");
			trig.setCreateUserid(UserId);
			trig.setCreateTime(ts);
			trig.setLastUpdtUserid(UserId);
			trig.setLastUpdtTime(ts);
			if (getMemberTrigger(conn, MFId, memberId, triggerCode) == 0) {
				insertTag = enrlDao.insertMbrTrigger(conn, trig);
			}
		} catch (Exception e) {
			insertTag = -1;
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return insertTag;
	}

	public int getMemberTrigger(Connection conn, String MFId, String memberId, String triggerCode)
			throws ApplicationException, SQLException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		int memberFound = 0;
		try {
			String sql;
			sql = "SELECT *" + " FROM EM_MBR_TRIGGER" + " WHERE CUSTOMER_ID = ? AND MEMBER_ID = ?"
					+ " AND TRIGGER_TYPE = ? AND TRIGGER_CODE=? AND TRIGGER_STATUS=?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, MFId);
			ps.setString(2, memberId);
			ps.setString(3, "BIL");
			ps.setString(4, triggerCode);
			ps.setString(5, EEMConstants.TRIGGER_STATUS_OPEN);
			rs = ps.executeQuery();
			if (rs.next()) {
				memberFound++;
			}
			logger.debug("memberFound -- "+memberFound);
			return memberFound;
		} finally {
			try {
				if (ps != null)
					ps.close();
			} catch (Exception e) {
				e.printStackTrace();
				logger.error(e.getMessage());
			}
		}
	}

}
