/*
 * $Id: FtpStatusServlet.java,v 1.1 2014/06/26 07:56:08 praveen Exp $
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ps.mss.db.DbConn;
import com.ps.mss.security.SessionManager;

public class FtpStatusServlet extends HttpServlet
{	private static Logger logger=LoggerFactory.getLogger(FtpStatusServlet.class);


public void service(HttpServletRequest request, HttpServletResponse response)
  throws ServletException, IOException
{
    PrintWriter out = new PrintWriter(response.getOutputStream());
    response.setHeader("Expires","0");
    response.setContentType("text/plain");

    // session login
    HttpSession session  = SessionManager.getSession(request);
    if (session == null)
    {
        logger.error("No Session");
        out.println("ERROR");
        out.flush();
        out.close();
        return;
    }

    String User_id = (String) session.getAttribute("User_id");
    if (User_id == null)
    {
        logger.error("Null User_id");
        out.println("ERROR");
        out.flush();
        out.close();
        return;
    }

    String MF_id = request.getParameter("MFid");
    String Rpt_type = request.getParameter("Type");
    String stat = request.getParameter("status");

    int    status;
    try {
        status = new Integer(stat).intValue();
    } catch(NumberFormatException nfe) {
        status = -1;
    }

    if (status != 40 && status != 45)
    {
        logger.error("Invalid Status Code [" + status + "]");
        out.println("ERROR");
        out.flush();
        out.close();
        return;
    }

    String ExMsg = null;
    int ExCode = 0;

    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
    String SQL = null;

    try {
        conn = DbConn.getConnection();
        stmt = conn.createStatement();

        SQL = "UPDATE ftptracking set WebToClient = Current_Timestamp, Status_ind = " + status + " WHERE MF_id = '" + MF_id + "' AND Rpt_type = '" + Rpt_type + "'";
        stmt.executeUpdate(SQL);

        //log.writeMessage(moduleName,"FTPTracking Update: " + Rpt_type + " " + MF_id + " " + " " + status + " " + User_id);
        out.println("SUCCESS");

    } catch(Exception e) {
        logger.error(e.getMessage());
        out.println("ERROR");
    } finally {
        out.flush();
        out.close();
        try {
            if (rs != null)
                rs.close();
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        try {
            if (stmt != null)
                stmt.close();
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        try {
            conn.close();
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }
}

}

