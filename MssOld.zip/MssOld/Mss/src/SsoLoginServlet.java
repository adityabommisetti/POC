//sso changes - start	


import java.io.ByteArrayInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

import com.ps.mss.db.DbConn;
import com.ps.mss.util.MssProperties;
import com.wipro.security.saml.Base64Util;
import com.wipro.security.saml.SAMLXMLParseUtil;
import com.wipro.security.saml.UserDTO;

/**
 * Servlet implementation class SsoLoginServlet
 */
public class SsoLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final String RESPONSE_PARAM = "SAMLResponse";
	private static Logger logger = LoggerFactory.getLogger(SsoLoginServlet.class);
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SsoLoginServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String base64EncodedSAML=request.getParameter(RESPONSE_PARAM);
    	logger.info("encoded SAML XML is: "+base64EncodedSAML);
    	boolean flag = false;
    	try {
    		
    		String BaseUrl = MssProperties.getWebAppURL();
    		VerifySignature VerifySign = new VerifySignature();
    		boolean validSignature = false;
    		String decodedSAMLXML=Base64Util.decode(base64EncodedSAML);
    		logger.info("decoded SAML XML is: "+decodedSAMLXML );
    		//IFOX-416769 BCBSAZ SSO CR - Start
    		InputStream decodedSAMLXMLStream = new ByteArrayInputStream(decodedSAMLXML.getBytes("UTF_8"));
    		String keyForIDPOkta =	"http://www.okta.com/exkldkweshmYM1aA00h7";
    		String keyForIDPOktaTrain =	"http://www.okta.com/exk18w5mteT9J3LAm357";
    		String keyForIDPOktaProd =	"http://www.okta.com/exkmuzwh1qBHKtltS356";
    		boolean oktaSAMLRequest	=	false;
    		boolean oktaSAMLRequestTrain = false;
    		boolean oktaSAMLRequestProd = false;
    		if(decodedSAMLXML != null && decodedSAMLXML.length() != 0){
    			if(decodedSAMLXML.indexOf(keyForIDPOkta) != -1){
    				validSignature=VerifySign.verifyXMLSignatureForOKTA(request, response,decodedSAMLXMLStream, false);
    				oktaSAMLRequest = true;
    				logger.info("OKTA SAML Request Found !!");
    			}
    			else if(decodedSAMLXML.indexOf(keyForIDPOktaTrain) != -1){
    				validSignature=VerifySign.verifyXMLSignatureForOKTATrain(request, response,decodedSAMLXMLStream, false);
    				oktaSAMLRequestTrain = true;
    				logger.info("OKTA Training SAML Request Found !!");
    			}
    			else if(decodedSAMLXML.indexOf(keyForIDPOktaProd) != -1){
    				validSignature=VerifySign.verifyXMLSignatureForOKTAProd(request, response,decodedSAMLXMLStream, false);
    				oktaSAMLRequestProd = true;
    				logger.info("OKTA Prod SAML Request Found !!");
    			}else{
    				validSignature=VerifySign.verifyXMLSignature(request, response,decodedSAMLXMLStream, false);
    			}
    		}
    		//IFOX-416769 BCBSAZ SSO CR - End
    		if(!validSignature){
				response.sendRedirect((String) response
    					.encodeRedirectURL("https://"
    							+ BaseUrl
    							+ "/mss/jsp/ErrorJsp.jsp?Msg=The digital Certificate on SAML Response cannot be validated, it might have been tampered"));
    			return;
			}
    		UserDTO theLoggedInUser = SAMLXMLParseUtil.parseSAMLReponseToUserDTO(decodedSAMLXML);
    		logger.info("The logged in user is - " + theLoggedInUser.getUserId());
    		if(null==theLoggedInUser.getUserId() || null==theLoggedInUser.getEmailId()){
    			response.sendRedirect((String) response
    					.encodeRedirectURL("https://"
    							+ BaseUrl
    							+ "/mss/jsp/ErrorJsp.jsp?Msg=Error in SAML Attributes"));
    			return;
    		}
    		String UserId = theLoggedInUser.getUserId().toUpperCase();
    		//IFOX-416769 BCBSAZ SSO CR - Start
    		if(oktaSAMLRequest){
    			String ssoUserID = "";
    			ssoUserID = getValidUserForOKTA(theLoggedInUser.getUserId(), theLoggedInUser.getEmailId());
    			if(!"".equals(ssoUserID) && ssoUserID != null ){
    				UserId = ssoUserID;
    				flag = true;
    			}
    		}
    		else if(oktaSAMLRequestTrain){
    			String ssoUserID = "";
    			ssoUserID = getValidUserForOKTA(theLoggedInUser.getUserId(), "TR"+theLoggedInUser.getEmailId());
    			if(!"".equals(ssoUserID) && ssoUserID != null ){
    				UserId = ssoUserID;
    				flag = true;
    			}
    		}
    		else if(oktaSAMLRequestProd){
    			String ssoUserID = "";
    			ssoUserID = getValidUserForOKTA(theLoggedInUser.getUserId(), theLoggedInUser.getEmailId());
    			if(!"".equals(ssoUserID) && ssoUserID != null ){
    				UserId = ssoUserID;
    				flag = true;
    			}
    		}else{
    			flag = isValidUser(theLoggedInUser.getUserId().toUpperCase(), theLoggedInUser.getEmailId());
    		}
    		
    		//IFOX-416769 BCBSAZ SSO CR - End
    		if (flag) {
    			request.setAttribute("User_id",UserId);
    			request.setAttribute("SSO","true");
    			ServletContext servletContext = getServletContext();
    			RequestDispatcher requestDispatcher = servletContext
    					.getRequestDispatcher("/servlet/LoginServlet");
    			requestDispatcher.forward(request, response);
    		}
    		else {
    			response.sendRedirect((String) response
    					.encodeRedirectURL("https://"
    							+ BaseUrl
    							+ "/mss/jsp/ErrorUnauthorizedJsp.jsp?Msg=An+Unauthorized+User"));
    		}
    	} catch (SAXException e) {
    		logger.error(e.getMessage());
    	} catch (ParserConfigurationException e) {
    		logger.error(e.getMessage());
    	}

    	
    }
    
	public boolean isValidUser(String userSecurityName, String userEmaiId) {
		logger.debug("Validating the User : " + userSecurityName);

		boolean isValid = false;
		Connection theConnection = null;
		PreparedStatement theStatement = null;
		ResultSet resultSet = null;

		try {
			theConnection = DbConn.getConnection();
			theStatement = theConnection
					.prepareStatement("SELECT USER_ID FROM SECUSER WHERE USER_ID=? AND EMAIL= ?");
			theStatement.setString(1, userSecurityName);
			theStatement.setString(2, userEmaiId);
			resultSet = theStatement.executeQuery();
			while (resultSet.next()) {

				String userId = resultSet.getString("USER_ID").trim();

				if (userSecurityName.equals(userId)) {

					isValid = true;
					break;
				}
			}

		} catch (Exception ex) {
			logger.info("Validating the User " + userSecurityName+" failed");
			logger.info(ex.getMessage());
		} finally {
			try {
				if (theConnection != null) {
					theConnection.close();
				}
				if (theStatement != null) {
					theStatement.close();
				}
				if (resultSet != null) {
					resultSet.close();
				}
			} catch (SQLException ex1) {
				logger.info(ex1.getMessage());
			}
		}
		logger.info("Validating the " + userSecurityName + " : " + isValid);

		return isValid;
	}
    
	
	//IFOX-416769 BCBSAZ SSO CR - Start
	public String getValidUserForOKTA(String userSecurityName, String userEmaiId) {
		logger.debug("Validating the OKTA User for : " + userSecurityName);

		Connection theConnection = null;
		PreparedStatement theStatement = null;
		ResultSet resultSet = null;
		String ssoUserId = "";

		try {
			theConnection = DbConn.getConnection();
			theStatement = theConnection
					.prepareStatement("SELECT USER_ID FROM SECUSER WHERE EMAIL= ?");
			theStatement.setString(1, userEmaiId);
			resultSet = theStatement.executeQuery();
			while (resultSet.next()) {
				ssoUserId = resultSet.getString("USER_ID").trim();
			}

		} catch (Exception ex) {
			logger.info("Retrieving the User with Email ID " + userSecurityName+" failed");
			logger.info(ex.getMessage());
		} finally {
			try {
				if (theConnection != null) {
					theConnection.close();
				}
				if (theStatement != null) {
					theStatement.close();
				}
				if (resultSet != null) {
					resultSet.close();
				}
			} catch (SQLException ex1) {
				logger.info(ex1.getMessage());
			}
		}
		logger.info("Retrieving the User with Email ID " + userSecurityName + " : " + ssoUserId);
		logger.debug("Validating the OKTA User Completed Successfully : " + ssoUserId);

		return ssoUserId;
	}

	//IFOX-416769 BCBSAZ SSO CR - End

}
//sso changes - end