/*
 * $Id: FileUploadStatusServlet.java,v 1.1 2014/06/26 07:56:02 praveen Exp $
 */

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Created on Dec 18, 2006
 * @author ppalat
 *
 * This servlet will provide the percentage of upload by using the contentLength and the 
 * current file size of the output file. 
 */

public class FileUploadStatusServlet extends HttpServlet {
	
    public void service(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException{
    	
    	HttpSession session = request.getSession(false);

    	String totalLengthStr = null;
    	String bytesReadStr = null;
    	
    	String fileName = null;
    	
    	long totalLength = 0L;
    	long bytesRead = 0L;
    	double progressPercentage = 0;
    	
    	BufferedInputStream bis = null;
    	
    	if ( session != null){
    		totalLengthStr = (String)session.getAttribute("UPLOAD_CONTENT_LEN"); // TODO - Make UPLOAD_CONTENT_LEN a constant. 
    		fileName = (String)session.getAttribute("UPLOAD_FILE_NAME"); //TODO - Make UPLOAD_FILE_NAME a constant. 
    		
    		try{
    			totalLength = new Long(totalLengthStr).longValue();	
    		}catch(NumberFormatException nfe){
    			totalLength = 1;
    		}

    		try{
    			/*    			
    			URL receiveStatusServlet = new URL("https://" + MssProperties.getFileAppURL() + "/servlet/ReceiveFileStatusServlet?fileName=" + fileName);
    			URLConnection urlCon = receiveStatusServlet.openConnection();
    			urlCon.setDoInput(true);
    			urlCon.setDoOutput(true);
    			urlCon.setUseCaches(false);
    			urlCon.setRequestProperty("Content-type",request.getContentType());
    			
    			bis = new BufferedInputStream(urlCon.getInputStream());
    			
                int bufSize = 4196;
                byte[] data = new byte[bufSize];        
                String responseString  = "0";
                int totalBytes = 0;
            
                do
                {
                    bytesRead = bis.read(data,0,bufSize);
                    responseString += bytesRead;
                    
                }while(bytesRead != -1);

                try{
                	bytesRead = new Long(responseString).longValue();
                }catch(NumberFormatException nfe){
                	bytesRead = 0;
                }
    			*/
    			
    			File file = new File(fileName);
    			if ( file.exists())
    			{
    				bytesRead = file.length();
    			}
    			
    			
    		}catch(Exception nfe){
    			bytesRead = 0;
    		}

    		try{
    			
    			progressPercentage = (bytesRead * 100) / totalLength;
    			
    		}catch ( ArithmeticException ae){
    			progressPercentage = 0;
    		}
    		
    	}
    	
    	response.setContentType("text/plain");
    	PrintWriter out = new PrintWriter(response.getOutputStream());
    	
   		out.write(new Double(progressPercentage).toString());
   		out.flush();
   		
   		return;
    }
}
