import java.sql.Connection;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.mss.db.BeneficiaryPersistence;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.RAPlanFinancialProjectionVO;
import com.ps.mss.db.view.BeneInfo;
import com.ps.mss.pdf.RAExpertReportPDFUtil;
import com.ps.mss.security.SessionManager;
import com.ps.mss.util.MssProperties;
import com.ps.pdf.PdfTable;
import com.ps.pdf.PdfUtil;

public class GenerateReviewPlanFinPro extends HttpServlet{
	private static Logger logger=LoggerFactory.getLogger(GenerateReviewPlanFinPro.class);

	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException{
		
		RAExpertReportPDFUtil raExpertPDFUtil = new RAExpertReportPDFUtil();
		
	    Connection conn = null;
		try{

		    String BaseUrl = MssProperties.getWebAppURL();
		    String XferUrl = MssProperties.getFtpAppURL();
		    	       
		    String User_name = null; 
			String planId = request.getParameter("planId"); 
			String hicNumber = request.getParameter("hicNbr"); 
			int paymentYear = Integer.parseInt(request.getParameter("paymentYear"));
						
			HashMap payBaselineMapProjYr = new HashMap();
			HashMap reconCMSMapProjYr = new HashMap();						
			HashMap reconPlanMapProjYr = new HashMap();						
			HashMap planRAPSMapProjYr = new HashMap();						
			//HashMap planHCCMODDMapProjYr = new HashMap();		
			HashMap planRAPSLAGMapProjecYr = new HashMap();

			HashMap payBaselineMapCurYr = new HashMap();
			HashMap reconCMSMapCurYr = new HashMap();						
			HashMap reconPlanMapCurYr = new HashMap();						
			HashMap planRAPSMapCurYr = new HashMap();						
			HashMap planHCCMODDMapCurYr = new HashMap();						

			HashMap payBaselineMapHistYr = new HashMap();
			HashMap reconCMSMapHistYr = new HashMap();						
			HashMap reconPlanMapHistYr = new HashMap();						
			HashMap planRAPSMapHistYr = new HashMap();						
			HashMap planHCCMODDMapHistYr = new HashMap();	
		    
			String prevYear = String.valueOf(paymentYear - 2);
			String thisYear = String.valueOf(paymentYear - 1);
			String projectionYear = String.valueOf(paymentYear);
		 				
	        conn = DbConn.getConnection();

		    HttpSession session = SessionManager.getSession(request, conn);
		    if (session == null)
		    {
		        logger.error("No Session");
		        response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/RAExpertPDFLoadError.jsp"));
		        return;
		    }
		    String User_id = (String)session.getAttribute("User_id");
		    if (User_id == null)
		    {
		       logger.error("No User_id");
		       response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/RAExpertPDFLoadError.jsp"));
		       return;
		    }

			String reconDb = (String) session.getAttribute("ReconDB");
			conn = DbConn.reGetConnection(conn,reconDb);
			
			BeneficiaryPersistence beneficiaryPersistence = new BeneficiaryPersistence();
			BeneInfo beneInfo = beneficiaryPersistence.getBeneInfo(conn, planId, hicNumber);

			if ( beneInfo.isClaimValid()){
		        User_name =  beneInfo.getLastName() + " " + beneInfo.getFirstName();
	        }else{
	        	User_name = "Hic Number is not valid.";
	        }		    
		    /***********************  Start Report generation *********************************************/
				    
		    response.setContentType("application/pdf");			
			
		    RAPlanFinancialProjectionVO raPlanFinancialProjectionVO = (RAPlanFinancialProjectionVO)  request.getAttribute("RAReportVO");
		    
			payBaselineMapProjYr = raPlanFinancialProjectionVO.getPayBaselineMapProjecYr();
			planRAPSMapProjYr = raPlanFinancialProjectionVO.getPlanRAPSMapProjecYr();
			planRAPSLAGMapProjecYr = raPlanFinancialProjectionVO.getPlanRAPSLAGMapProjecYr();

			payBaselineMapCurYr = raPlanFinancialProjectionVO.getPayBaselineMapCurYr();
			reconCMSMapCurYr = raPlanFinancialProjectionVO.getReconCMSMapCurYr();
			reconPlanMapCurYr = raPlanFinancialProjectionVO.getReconPlanMapCurYr();
			planRAPSMapCurYr = raPlanFinancialProjectionVO.getPlanRAPSMapCurYr();
			planHCCMODDMapCurYr = raPlanFinancialProjectionVO.getPlanHCCMODDMapCurYr();

			payBaselineMapHistYr = raPlanFinancialProjectionVO.getPayBaselineMapHistYr();
			reconCMSMapHistYr = raPlanFinancialProjectionVO.getReconCMSMapHistYr();
			reconPlanMapHistYr = raPlanFinancialProjectionVO.getReconPlanMapHistYr();
			planRAPSMapHistYr = raPlanFinancialProjectionVO.getPlanRAPSMapHistYr();
			planHCCMODDMapHistYr = raPlanFinancialProjectionVO.getPlanHCCMODDMapHistYr();
		    
		    
			PdfUtil pdfUtil = new PdfUtil("");
			pdfUtil.enableSilentPrint(true);
			pdfUtil.createPDF(response.getOutputStream());
	

			int rowIndex = 0;
	
			// Member Detail Table
			PdfTable memberDetailTable = new PdfTable(2);
			memberDetailTable.setFont(RAExpertReportPDFUtil.normalTextFont);
			memberDetailTable.setBorder(0);
			float[] memberDetailColWidths = {15f,85f};
			memberDetailTable.setColumnWidths(memberDetailColWidths);
	
	
			rowIndex = memberDetailTable.addRow();
			memberDetailTable.setText(rowIndex, 1, "Plan ID :");
			memberDetailTable.setFont(rowIndex, 1, RAExpertReportPDFUtil.title1BoldFont);
			memberDetailTable.setText(rowIndex, 2, planId);
			memberDetailTable.setFont(rowIndex, 2, RAExpertReportPDFUtil.title1NormalFont);
	
	
			// Define the numbers table
	
			PdfTable finReviewTable = new PdfTable(16);
			finReviewTable.setWidthPercentage(100);
			finReviewTable.setBorder(0);
			finReviewTable.setFont(RAExpertReportPDFUtil.normalTextFont);
			finReviewTable.setAlignment(PdfTable.RIGHT);
			float[] finReviewTableWidths = {9f,1f,18f,.4f,1f,18f,.4f,1f,18f,.4f,1f,18f,.4f,1f,18f,.1f};
			finReviewTable.setColumnWidths(finReviewTableWidths);
	
			payBaselineMapProjYr = raPlanFinancialProjectionVO.getPayBaselineMapProjecYr();
			
			raExpertPDFUtil.printPaymentTopHeader ( finReviewTable);
			raExpertPDFUtil.printPaymentSubHeader ( finReviewTable, payBaselineMapCurYr, null, reconCMSMapCurYr, null, reconPlanMapCurYr, null, planRAPSMapCurYr, null, null, null, planRAPSLAGMapProjecYr, null);
			raExpertPDFUtil.printPaymentContent ( finReviewTable, true, projectionYear, payBaselineMapProjYr, null, null, null, null, null, planRAPSMapProjYr, null, null, null, planRAPSLAGMapProjecYr, null);
						
			rowIndex = finReviewTable.addSpacerLine(12); // New Row
			
			raExpertPDFUtil.printPaymentSubHeader ( finReviewTable, payBaselineMapCurYr, null, reconCMSMapCurYr, null, reconPlanMapCurYr, null, planRAPSMapCurYr, null, planHCCMODDMapCurYr, null, null, null);
			raExpertPDFUtil.printPaymentContent ( finReviewTable, false, thisYear, payBaselineMapCurYr, null, reconCMSMapCurYr, null, reconPlanMapCurYr, null, planRAPSMapCurYr, null, planHCCMODDMapCurYr, null, null, null);

			rowIndex = finReviewTable.addSpacerLine(12);
			
			raExpertPDFUtil.printPaymentContent ( finReviewTable, false, prevYear, payBaselineMapHistYr, null, reconCMSMapHistYr, null, reconPlanMapHistYr, null, planRAPSMapHistYr, null, planHCCMODDMapHistYr, null, null, null);			
	
			// MAIN TABLE
	
			PdfTable pdfTable = new PdfTable(1);
			pdfTable.setWidthPercentage(100);
			pdfTable.setBorder(0);
			pdfTable.setAlignment(PdfTable.CENTER);
			pdfTable.setFont(RAExpertReportPDFUtil.pageHeadingFont);
	
	
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "RA-Expert ");
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "Part C HCC Analysis  ");
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "Plan Financial Review with " + paymentYear + " Projection");
	
			rowIndex = pdfTable.addSpacerLine(12);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, memberDetailTable);
	
			rowIndex = pdfTable.addSpacerLine(12);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, finReviewTable);
	
			pdfUtil.addTable(pdfTable);
	
			pdfUtil.close();

		}catch(Exception ex){
			logger.error("Exception " + ex);
			throw new ServletException(ex);
		} finally {
			try {
				if (conn != null) conn.close();
			} catch(Exception e) {
				logger.error(e.getMessage());
			}
		}	

	}
}