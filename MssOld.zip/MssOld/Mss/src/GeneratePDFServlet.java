/*
 * Created on Aug 2, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author palat.pradeep
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.helper.GenerateRAExpertReport;

public class GeneratePDFServlet extends HttpServlet{
	
	private static Logger logger=LoggerFactory.getLogger(GeneratePDFServlet.class);
	
	public void service(HttpServletRequest request, HttpServletResponse response){
		try{
			
		    HttpSession session = SessionManager.getSession(request);
		    if (session == null)
		    {
		        logger.error("No Session");
		        response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/RAExpertPDFLoadError.jsp"));
		        return;
		    }
		    String User_id = (String)session.getAttribute("User_id");
		    if (User_id == null)
		    {
		       logger.error("No User_id");
		       response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/RAExpertPDFLoadError.jsp"));
		       return;
		    }
			
			response.setContentType("application/pdf");
			
			String reportType = request.getParameter("reportType");
			String servletName = "";

			request.setAttribute("RAReportVO", session.getAttribute("RAReportVO"));
			//session.removeAttribute("RAReportVO");
			
			if ( "MemberFinReview".equals(reportType)){
				servletName = "/servlet/GenerateMemberFinReview";
			
			}else if ( "MemberFinProReview".equals(reportType)){
				servletName = "/servlet/GenerateMemberFinProReview";
				
			}else if ( "MemberHCCDiagReview".equals(reportType)){
				servletName = "/servlet/GenerateMemberHCCDiagReview";
				
			}else if ( "MemberHCCReview".equals(reportType)){
				servletName = "/servlet/GenerateMemberHCCReview";
				
			}else if ( "ReviewPlan".equals(reportType)){
				servletName = "/servlet/GenerateReviewPlan";
				
			}else if ( "ReviewPlanFinPro".equals(reportType)){
				servletName = "/servlet/GenerateReviewPlanFinPro";
				
			}else if ( "PDMemberFinReview".equals(reportType)){
				servletName = "/servlet/GeneratePDMemberFinReview";
				
			}else if ( "PDMemberFinProReview".equals(reportType)){
				servletName = "/servlet/GeneratePDMemberFinProReview";
				
			}else if ( "PDMemberHCCDiagReview".equals(reportType)){
				servletName = "/servlet/GeneratePDMemberHCCDiagReview";
				
			}else if ( "PDMemberHCCReview".equals(reportType)){
				servletName = "/servlet/GeneratePDMemberHCCReview";
				
			}else if ( "PDReviewPlan".equals(reportType)){
				servletName = "/servlet/GeneratePDReviewPlan";
				
			}else if ( "PDReviewPlanFinPro".equals(reportType)){
				servletName = "/servlet/GeneratePDReviewPlanFinPro";				
			}else if ( "YrToYr".equals(reportType) || "hccHist".equals(reportType) 
					|| "hccProj".equals(reportType) || "finAudit".equals(reportType)){
				GenerateRAExpertReport.createReport(request, response, reportType);
				return;
			}
			
			getServletContext().getRequestDispatcher(servletName).forward(request, response);
			

		}catch(Exception ex){
			logger.error("GeneratePDFServlet : service : Caught Exception " + ex);
			try{
				getServletContext().getRequestDispatcher("/mss/jsp/RAExpertPDFLoadError.jsp").forward(request, response);
			}catch ( ServletException se){
				logger.error("GeneratePDFServlet : service : Caught ServletException while trying to redirect to errorpage " + ex);	
			}catch ( IOException ioe){
				logger.error("GeneratePDFServlet : service : Caught IOException while trying to redirect to errorpage" + ex);	
			}
		}
	}
}
