
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Hashtable;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import com.ps.mss.db.DbConn;
import com.ps.mss.security.CryptoDigest;
import com.ps.util.StringUtil;

public class BaseUtilityCommandServlet extends HttpServlet
{
   	private static Logger logger=LoggerFactory.getLogger(BaseUtilityCommandServlet.class);
	public void doGet(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
	{
		doPost(request,response);
	}
	
    public void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException
    {

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        String SQL = null;

        String userId = StringUtil.nonNullTrim(request.getParameter("UId")).toUpperCase(); 
        String passWord = StringUtil.nonNullTrim(request.getParameter("Pwd"));
        
        String cryptPasswd = null;
        
        CryptoDigest crypt = new CryptoDigest();
        try {
        	cryptPasswd = crypt.digest(userId,passWord);
        } catch(NoSuchAlgorithmException e) {
        	cryptPasswd = null;
        }
        
        try {

        	conn = DbConn.getConnection(); // Gets the dfltDb from the mssproperties and creates connection to db
        	stmt = conn.createStatement();
            SQL = "SELECT Active_yn, PwdExpire_date" +
                   " FROM secuser, secgroup " +
                  " WHERE secuser.Group_id = secgroup.Group_id" +
                    " AND Cust_nbr = '110000'" +
                    " AND User_id = '" + userId + "' AND User_pwd = '" + cryptPasswd + "'" +
                    " AND Active_yn = 'Y'" +
                    " AND PwdExpire_date >= Current_Timestamp";
            rs = stmt.executeQuery(SQL);
            if (!rs.next())
            {
                String msgUrl = request.getParameter("msgURL");
                if (msgUrl != null) {
                	String countiueLink = request.getParameter("CL");
                	response.sendRedirect((String)response.encodeRedirectURL(msgUrl + "?CL=" + countiueLink + "&Msg=Error:+Security"));
                }
                return;
            }

            String command = StringUtil.nonNull(request.getParameter("cmd")); 

            if (command.equals("MAINT"))
                doMaint(request,response);
            else
            if (command.equals("HIRELOAD"))
                doHiReload(request,response);
            else
            if (command.equals("COUNT"))
                doCount(request,response);
            else
                doNothing(request,response);

        } catch(Exception e) {
        	logger.error(e.getMessage());
        } finally {
            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
                logger.error(e.getMessage());
            }
            try {
                if (stmt != null)
                    stmt.close();
            } catch (Exception e) {
                logger.error(e.getMessage());
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (Exception e) {
                logger.error(e.getMessage());
            }
        }

    }


    private void doNothing(HttpServletRequest request, HttpServletResponse response) throws IOException
    {

        String msgUrl = request.getParameter("msgURL");
        String countiueLink = request.getParameter("CL");


        response.sendRedirect((String)response.encodeRedirectURL(msgUrl + "?CL=" + countiueLink + "&Msg=Error:+Invalid+command+parameter"));

    }

    private void doMaint(HttpServletRequest request, HttpServletResponse response) throws IOException
    {
    	String act = StringUtil.nonNullTrim(request.getParameter("act")); 
    	
        String msgUrl = request.getParameter("msgURL");
        String countiueLink = request.getParameter("CL");

        logger.debug("act: " + act);

        File fn = new File("D:\\inetpub\\ftproot\\MAINTENANCE");

        if (act.equals("OFF"))
        {
            if (fn.exists())
            {
                if (!fn.isFile())
                {
                    response.sendRedirect((String)response.encodeRedirectURL(msgUrl + "?CL=" + countiueLink + "&Msg=Error: Flag+File+Exists+but+is+not+a+File"));
                    return;
                }
                try {
                    fn.delete();
                } catch(Exception e) {
                    response.sendRedirect((String)response.encodeRedirectURL(msgUrl + "?CL=" + countiueLink + "&Msg=Error+deletings+Existing+Flag+File"));
                    return;
                }
            }
            response.sendRedirect((String)response.encodeRedirectURL(msgUrl + "?CL=" + countiueLink + "&Msg=Maintenance+Page+Removed+-+System+Now+Open"));
            return;
        }

        if (act.equals("ON"))
        {
            PrintWriter pw;
            try {
                pw = new PrintWriter(new FileWriter(fn));
                pw.println(Calendar.getInstance().getTime().toString());
                pw.close();
                response.sendRedirect((String)response.encodeRedirectURL(msgUrl + "?CL=" + countiueLink + "&Msg=Maintenance+Page+On+-+System+Closed"));
                return;
            } catch(Exception e) {
                response.sendRedirect((String)response.encodeRedirectURL(msgUrl + "?CL=" + countiueLink + "&Msg=Error+creating+Flag+File"));
                return;
            }
        }

        if (act.equals("SHOW"))
        {
            String curStatus = "OFF";
            if (fn.exists())
            {
                if (!fn.isFile())
                {
                    response.sendRedirect((String)response.encodeRedirectURL(msgUrl + "?CL=" + countiueLink + "&Msg=Error: Flag+File+Exists+but+is+not+a+File"));
                    return;
                }
                curStatus = "ON";
            }
            response.sendRedirect((String)response.encodeRedirectURL(msgUrl + "?CL=" + countiueLink + "&Msg=Maintenance+Page+Is+"+curStatus));
            return;
        }

        response.sendRedirect((String)response.encodeRedirectURL(msgUrl + "?CL=" + countiueLink + "&Msg=Error:+Invalid+status+parameter"));
    }

    private void doHiReload(HttpServletRequest request, HttpServletResponse response) throws IOException
    {
        String action = StringUtil.nonNullTrim(request.getParameter("act")); 
        
        String msgUrl = request.getParameter("msgURL");

        String countiueLink = request.getParameter("CL");

        File fn = new File("D:\\inetpub\\ftproot\\HI_RELOAD");

        if (action.equals("OFF"))
        {
            if (fn.exists())
            {
                if (!fn.isFile())
                {
                    response.sendRedirect((String)response.encodeRedirectURL(msgUrl + "?CL=" + countiueLink + "&Msg=Error: Flag+File+Exists+but+is+not+a+File"));
                    return;
                }
                try {
                    fn.delete();
                } catch(Exception e) {
                    response.sendRedirect((String)response.encodeRedirectURL(msgUrl + "?CL=" + countiueLink + "&Msg=Error+deletings+Existing+Flag+File"));
                    return;
                }
            }
            response.sendRedirect((String)response.encodeRedirectURL(msgUrl + "?CL=" + countiueLink + "&Msg=Reload+Canceled"));
            return;
        }

        if (action.equals("ON"))
        {
            PrintWriter pw;
            try {
                pw = new PrintWriter(new FileWriter(fn));
                pw.println(Calendar.getInstance().getTime().toString());
                pw.close();
                response.sendRedirect((String)response.encodeRedirectURL(msgUrl + "?CL=" + countiueLink + "&Msg=Reload+Scheduled"));
                return;
            } catch(Exception e) {
                response.sendRedirect((String)response.encodeRedirectURL(msgUrl + "?CL=" + countiueLink + "&Msg=Error+creating+Flag+File"));
                return;
            }
        }

        if (action.equals("SHOW"))
        {
            String curStatus = "OFF";
            if (fn.exists())
            {
                if (!fn.isFile())
                {
                    response.sendRedirect((String)response.encodeRedirectURL(msgUrl + "?CL=" + countiueLink + "&Msg=Error: Flag+File+Exists+but+is+not+a+File"));
                    return;
                }
                curStatus = "ON";
            }
            response.sendRedirect((String)response.encodeRedirectURL(msgUrl + "?CL=" + countiueLink + "&Msg=Reload+Status+is+"+curStatus));
            return;
        }

        response.sendRedirect((String)response.encodeRedirectURL(msgUrl + "?CL=" + countiueLink + "&Msg=Error:+Invalid+status+parameter"));

    }

    private void doCount(HttpServletRequest request, HttpServletResponse response) throws IOException
    {
    	ServletContext sc = getServletContext();
    	Hashtable monitor = (Hashtable)sc.getAttribute("monitor");
    	
    	int logOnCount = monitor.size();
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        out.println(logOnCount);
    }
    
}
