import java.awt.Color;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ps.pdf.PdfFontUtil;
import com.ps.pdf.PdfTable;
import com.ps.pdf.PdfUtil;

public class GeneratePDReviewPlanFinPro extends HttpServlet{
	private static Logger logger=LoggerFactory.getLogger(GeneratePDReviewPlanFinPro.class);
	public void service(HttpServletRequest request, HttpServletResponse response){
		
		try{

			PdfUtil pdfUtil = new PdfUtil("");
			pdfUtil.enableSilentPrint(true);
			pdfUtil.createPDF(response.getOutputStream());
	
			String pageHeadingFont = PdfFontUtil.defineFont("PAGE_HEADING_FONT", PdfFontUtil.COURIER, 11, PdfFontUtil.BOLD_FONT);
			String title1NormalFont = PdfFontUtil.defineFont("TITLE_NORMAL_FONT", PdfFontUtil.COURIER, 11, PdfFontUtil.NORMAL_FONT);
			String title1BoldFont = PdfFontUtil.defineFont("TITLE_BOLD_FONT", PdfFontUtil.COURIER, 11, PdfFontUtil.BOLD_FONT);
			String normalTextFont = PdfFontUtil.defineFont("NORMAL_TEXT_FONT", PdfFontUtil.COURIER, 9, PdfFontUtil.NORMAL_FONT);
			String boldTextFont = PdfFontUtil.defineFont("BOLD_TEXT_FONT", PdfFontUtil.COURIER, 9, PdfFontUtil.BOLD_FONT);
	
			int rowIndex = 0;
	
			// Member Detail Table
			PdfTable memberDetailTable = new PdfTable(2);
			memberDetailTable.setFont(normalTextFont);
			memberDetailTable.setBorder(0);
			float[] memberDetailColWidths = {15f,85f};
			memberDetailTable.setColumnWidths(memberDetailColWidths);
	
	
			rowIndex = memberDetailTable.addRow();
			memberDetailTable.setText(rowIndex, 1, "Plan ID :");
			memberDetailTable.setFont(rowIndex, 1, title1BoldFont);
			memberDetailTable.setText(rowIndex, 2, "H9998");
			memberDetailTable.setFont(rowIndex, 2, title1NormalFont);
	
	
			// Define the numbers table
	
			PdfTable finReviewTable = new PdfTable(11);
			finReviewTable.setWidthPercentage(100);
			finReviewTable.setBorder(0);
			finReviewTable.setFont(normalTextFont);
			finReviewTable.setAlignment(PdfTable.CENTER);
			float[] finReviewTableWidths = {8f,.5f,20f,.5f,18f,.5f,18f,.5f,20f,.5f,18f};
			finReviewTable.setColumnWidths(finReviewTableWidths);
	
			rowIndex = finReviewTable.addRow();		// New Row
			finReviewTable.setColSpan(rowIndex, 5, 3);
			finReviewTable.setColSpan(rowIndex, 9, 3);
	
			finReviewTable.drawLine(rowIndex, 5, .75f, Color.LIGHT_GRAY);
			finReviewTable.drawLine(rowIndex, 9, .75f, Color.LIGHT_GRAY);
	
			rowIndex = finReviewTable.addRow();		// New Row
			finReviewTable.setFont(rowIndex, boldTextFont);
			finReviewTable.setColSpan(rowIndex, 5, 3);
			finReviewTable.setColSpan(rowIndex, 9, 3);
			finReviewTable.setText(rowIndex, 5, "Recon");
			finReviewTable.setText(rowIndex, 9, "Plan Expected Payment");
	
			rowIndex = finReviewTable.addRow();		// New Row
			finReviewTable.drawLine(rowIndex, 3, .75f, Color.LIGHT_GRAY);
			finReviewTable.drawLine(rowIndex, 5, .75f, Color.LIGHT_GRAY);
			finReviewTable.drawLine(rowIndex, 7, .75f, Color.LIGHT_GRAY);
			finReviewTable.drawLine(rowIndex, 9, .75f, Color.LIGHT_GRAY);
			finReviewTable.drawLine(rowIndex, 11, .75f, Color.LIGHT_GRAY);
	
			rowIndex = finReviewTable.addRow();		// New Row
			finReviewTable.setFont(rowIndex, boldTextFont);
			finReviewTable.setText(rowIndex, 3, "Baseline");
			finReviewTable.setText(rowIndex, 5, "CMS");
			finReviewTable.setText(rowIndex, 7, "Plan");
			finReviewTable.setText(rowIndex, 9, "RAPS");
			finReviewTable.setText(rowIndex, 11, "RAPS/HCCMODD");
	
			rowIndex = finReviewTable.addRow();		// New Row
			finReviewTable.drawLine(rowIndex, 3, .75f, Color.LIGHT_GRAY);
			finReviewTable.drawLine(rowIndex, 5, .75f, Color.LIGHT_GRAY);
			finReviewTable.drawLine(rowIndex, 7, .75f, Color.LIGHT_GRAY);
			finReviewTable.drawLine(rowIndex, 9, .75f, Color.LIGHT_GRAY);
			finReviewTable.drawLine(rowIndex, 11, .75f, Color.LIGHT_GRAY);
	
			rowIndex = finReviewTable.addRow();		// Projection Data
			finReviewTable.setText(rowIndex, 1, "200808");
			finReviewTable.setText(rowIndex, 3, "9,617,597.94");
			finReviewTable.setText(rowIndex, 5, "");
			finReviewTable.setText(rowIndex, 7, "");
			finReviewTable.setText(rowIndex, 9, "6,607,997.94");
			finReviewTable.setText(rowIndex, 11, "");
	
			finReviewTable.drawLine(.75f, Color.LIGHT_GRAY);
	
			rowIndex = finReviewTable.addRow();		// Projection Data
			finReviewTable.setText(rowIndex, 1, "Total");
			finReviewTable.setFont(rowIndex, 1, boldTextFont);
			finReviewTable.setText(rowIndex, 3, "115,411,175.28");
			finReviewTable.setText(rowIndex, 5, "");
			finReviewTable.setText(rowIndex, 7, "");
			finReviewTable.setText(rowIndex, 9, "79,295,975.28");
			finReviewTable.setText(rowIndex, 11, "");
	
			rowIndex = finReviewTable.addSpacerLine(12); // New Row
			
			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200701");
			finReviewTable.setText(rowIndex, 3, "9,437,077.24");
			finReviewTable.setText(rowIndex, 5, "7,674,374.30");
			finReviewTable.setText(rowIndex, 7, "7,614,277.24");
			finReviewTable.setText(rowIndex, 9, "7,673,677.24");
			finReviewTable.setText(rowIndex, 11, "7,833,877.24");


			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200702");
			finReviewTable.setText(rowIndex, 3, "9,330,497.65");
			finReviewTable.setText(rowIndex, 5, "7,600,905.97");
			finReviewTable.setText(rowIndex, 7, "7,507,697.65");
			finReviewTable.setText(rowIndex, 9, "7,567,097.65");
			finReviewTable.setText(rowIndex, 11, "7,727,297.65");


			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200703");
			finReviewTable.setText(rowIndex, 3, "9,292,030.99");
			finReviewTable.setText(rowIndex, 5, "7,547,390.21");
			finReviewTable.setText(rowIndex, 7, "7,469,230.99");
			finReviewTable.setText(rowIndex, 9, "7,528,630.99");
			finReviewTable.setText(rowIndex, 11, "7,688,830.99");


			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200704");
			finReviewTable.setText(rowIndex, 3, "9,283,301.80");
			finReviewTable.setText(rowIndex, 5, "7,450,070.54");
			finReviewTable.setText(rowIndex, 7, "7,460,501.80");
			finReviewTable.setText(rowIndex, 9, "7,519,901.80");
			finReviewTable.setText(rowIndex, 11, "7,680,101.80");


			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200705");
			finReviewTable.setText(rowIndex, 3, "9,140,763.20");
			finReviewTable.setText(rowIndex, 5, "7,348,859.32");
			finReviewTable.setText(rowIndex, 7, "7,317,963.20");
			finReviewTable.setText(rowIndex, 9, "7,377,363.20");
			finReviewTable.setText(rowIndex, 11, "7,537,563.20");


			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200706");
			finReviewTable.setText(rowIndex, 3, "9,130,609.51");
			finReviewTable.setText(rowIndex, 5, "7,300,383.27");
			finReviewTable.setText(rowIndex, 7, "7,307,809.51");
			finReviewTable.setText(rowIndex, 9, "7,367,209.51");
			finReviewTable.setText(rowIndex, 11, "7,527,409.51");


			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200707");
			finReviewTable.setText(rowIndex, 3, "9,067,618.16");
			finReviewTable.setText(rowIndex, 5, "7,228,388.65");
			finReviewTable.setText(rowIndex, 7, "7,244,818.16");
			finReviewTable.setText(rowIndex, 9, "7,304,218.16");
			finReviewTable.setText(rowIndex, 11, "7,464,418.16");


			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200708");
			finReviewTable.setText(rowIndex, 3, "9,017,597.94");
			finReviewTable.setText(rowIndex, 5, "7,226,398.50");
			finReviewTable.setText(rowIndex, 7, "7,194,797.94");
			finReviewTable.setText(rowIndex, 9, "7,254,197.94");
			finReviewTable.setText(rowIndex, 11, "7,414,397.94");
	
			finReviewTable.drawLine(0.75f, Color.LIGHT_GRAY);
	
			rowIndex = finReviewTable.addRow();		// New Row
			finReviewTable.setFont(rowIndex, boldTextFont);
			finReviewTable.setText(rowIndex, 1, "Total");
			finReviewTable.setText(rowIndex, 3, "73,699,496.49");
			finReviewTable.setText(rowIndex, 5, "59,376,770.76");
			finReviewTable.setText(rowIndex, 7, "59,117,096.49");
			finReviewTable.setText(rowIndex, 9, "59,592,296.49");
			finReviewTable.setText(rowIndex, 11, "60,873,896.49");			

			rowIndex = finReviewTable.addSpacerLine(12);
			
			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200601");
			finReviewTable.setText(rowIndex, 3,"8,431,365.02");
			finReviewTable.setText(rowIndex, 5, "8,293,950.47");
			finReviewTable.setText(rowIndex, 7, "8,338,946.02");
			finReviewTable.setText(rowIndex, 9, "0.00");
			finReviewTable.setText(rowIndex, 11, "8,338,946.02");


			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200602");
			finReviewTable.setText(rowIndex, 3, "8,472,924.31");
			finReviewTable.setText(rowIndex, 5, "8,254,911.90");
			finReviewTable.setText(rowIndex, 7, "8,380,505.31");
			finReviewTable.setText(rowIndex, 9, "0.00");
			finReviewTable.setText(rowIndex, 11, "8,380,505.31");


			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200603");
			finReviewTable.setText(rowIndex, 3, "8,407,619.89");
			finReviewTable.setText(rowIndex, 5, "8,219,617.82");
			finReviewTable.setText(rowIndex, 7, "8,315,200.89");
			finReviewTable.setText(rowIndex, 9, "0.00");
			finReviewTable.setText(rowIndex, 11, "8,315,200.89");


			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200604");
			finReviewTable.setText(rowIndex, 3, "8,300,585.76");
			finReviewTable.setText(rowIndex, 5, "8,104,264.66");
			finReviewTable.setText(rowIndex, 7, "8,208,166.76");
			finReviewTable.setText(rowIndex, 9, "0.00");
			finReviewTable.setText(rowIndex, 11, "8,208,166.76");


			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200605");
			finReviewTable.setText(rowIndex, 3, "8,085,231.81");
			finReviewTable.setText(rowIndex, 5, "8,001,876.48");
			finReviewTable.setText(rowIndex, 7, "8,085,231.81");
			finReviewTable.setText(rowIndex, 9, "0.00");
			finReviewTable.setText(rowIndex, 11, "8,085,231.81");


			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200606");
			finReviewTable.setText(rowIndex, 3, "8,053,550.14");
			finReviewTable.setText(rowIndex, 5, "7,955,398.15");
			finReviewTable.setText(rowIndex, 7, "8,053,550.14");
			finReviewTable.setText(rowIndex, 9, "0.00");
			finReviewTable.setText(rowIndex, 11, "8,053,550.14");


			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200607");
			finReviewTable.setText(rowIndex, 3, "7,979,109.40");
			finReviewTable.setText(rowIndex, 5, "7,883,368.82");
			finReviewTable.setText(rowIndex, 7, "7,979,109.40");
			finReviewTable.setText(rowIndex, 9, "0.00");
			finReviewTable.setText(rowIndex, 11, "7,979,109.40");


			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200608");
			finReviewTable.setText(rowIndex, 3, "7,833,502.92");
			finReviewTable.setText(rowIndex, 5, "7,775,727.91");
			finReviewTable.setText(rowIndex, 7, "7,833,502.92");
			finReviewTable.setText(rowIndex, 9, "0.00");
			finReviewTable.setText(rowIndex, 11, "7,833,502.92");


			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200609");
			finReviewTable.setText(rowIndex, 3, "7,789,254.66");
			finReviewTable.setText(rowIndex, 5, "7,725,990.70");
			finReviewTable.setText(rowIndex, 7, "7,789,254.66");
			finReviewTable.setText(rowIndex, 9, "0.00");
			finReviewTable.setText(rowIndex, 11, "7,789,254.66");


			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200610");
			finReviewTable.setText(rowIndex, 3, "7,714,206.24");
			finReviewTable.setText(rowIndex, 5, "7,615,206.58");
			finReviewTable.setText(rowIndex, 7, "7,714,206.24");
			finReviewTable.setText(rowIndex, 9, "0.00");
			finReviewTable.setText(rowIndex, 11, "7,714,206.24");


			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200611");
			finReviewTable.setText(rowIndex, 3, "7,578,459.14");
			finReviewTable.setText(rowIndex, 5, "7,557,993.42");
			finReviewTable.setText(rowIndex, 7, "7,578,459.14");
			finReviewTable.setText(rowIndex, 9, "0.00");
			finReviewTable.setText(rowIndex, 11, "7,578,459.14");


			rowIndex = finReviewTable.addRow();
			finReviewTable.setText(rowIndex, 1, "200612");
			finReviewTable.setText(rowIndex, 3, "7,526,208.67");
			finReviewTable.setText(rowIndex, 5, "7,505,267.56");
			finReviewTable.setText(rowIndex, 7, "7,526,208.67");
			finReviewTable.setText(rowIndex, 9, "0.00");
			finReviewTable.setText(rowIndex, 11, "7,526,208.67");

			finReviewTable.drawLine(0.75f, Color.LIGHT_GRAY);
	
			rowIndex = finReviewTable.addRow();		// New Row
			finReviewTable.setFont(rowIndex, boldTextFont);
			finReviewTable.setText(rowIndex, 1, "Total");
			finReviewTable.setText(rowIndex, 3, "96,172,017.96");
			finReviewTable.setText(rowIndex, 5, "94,893,574.47");
			finReviewTable.setText(rowIndex, 7, "95,802,341.96");
			finReviewTable.setText(rowIndex, 9, "0.0");
			finReviewTable.setText(rowIndex, 11, "95,802,341.96");	
	
			// MAIN TABLE
	
			PdfTable pdfTable = new PdfTable(1);
			pdfTable.setWidthPercentage(100);
			pdfTable.setBorder(0);
			pdfTable.setAlignment(PdfTable.CENTER);
			pdfTable.setFont(pageHeadingFont);
	
	
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "RA-Expert ");
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "Part D HCC Analysis  ");
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "Plan Financial Review by Month");
	
			rowIndex = pdfTable.addSpacerLine(12);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, memberDetailTable);
	
			rowIndex = pdfTable.addSpacerLine(12);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, finReviewTable);
	
			pdfUtil.addTable(pdfTable);
	
			pdfUtil.close();

		}catch(Exception ex){
			logger.error("Exception " + ex);
		}	

	}
}