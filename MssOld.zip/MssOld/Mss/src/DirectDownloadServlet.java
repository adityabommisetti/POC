import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;
import com.ps.io.FileNameUtil;
import com.ps.io.ModuleLog;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.FileXferLog;
import com.ps.mss.db.FileXferLogPersistence;
import com.ps.mss.db.SecgroupPersistence;
import com.ps.mss.security.SessionManager;
import com.ps.mss.util.MssProperties;
import com.ps.net.URLEncoder;
import com.ps.text.DateFormatter;
import com.ps.util.DateUtil;


public class DirectDownloadServlet extends HttpServlet {
	private static Logger logger=LoggerFactory.getLogger(DirectDownloadServlet.class);
	private static String[] textReports = {".M6MBP010","PTDMODR","MONMEMSR","HCCMODR","PLANPAY","M6COP001","M6COP002"};
	private static String directDownload= "DDL";
	
public void service(HttpServletRequest request, HttpServletResponse response)
  throws ServletException, IOException
{
    HttpSession session = SessionManager.getSession(request);
    if (session == null)
    {
        logger.error("No Session");
        response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/ErrorJsp.jsp?Msg=Page+Expired"));
        return;
    }
    String userId = (String) session.getAttribute("User_id");
    if (userId == null)
    {
        logger.error("No User_id");
        response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/ErrorJsp.jsp?Msg=Invalid+Session"));
        return;
    }
    String MFId = (String) session.getAttribute("MF_id");
    if (MFId == null)
    {
        logger.error("No MF_id");
        response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/ErrorJsp.jsp?Msg=Invalid+Session"));
        return;
    }
    int start = 0;
    response.setContentType("application/zip");
    
    response.setHeader("Content-Disposition","inline; filename=output.zip;");  
    
    String pdf = request.getParameter("pdf");
    String rptType = request.getParameter("RptType");
    String pathName = request.getParameter("Dir");
    String [] fileName = request.getParameterValues("fileName");
    boolean directDownloadFlag = (directDownload.equalsIgnoreCase(pdf))?true:false;
    logger.debug("####pdf:"+pdf+" ,directDownloadFlag:"+directDownloadFlag);
   // String statusParm = request.getParameter("Status");
   
	/*if (statusParm  == null)
        statusParm = "false";*/
    String [] fileDlType = new String[fileName.length];
    
    boolean overridePDFOption = false;
     if(pdf.equalsIgnoreCase("true") && !"HCF0068".equals(MFId)){
    	 overridePDFOption = canOverridePDFOpt(fileName[0], MFId);
     }
    
    String dlType;
boolean statusParm = fileName[0] != null && 
	(
    		contains(fileName[0],"MMA.BATCH") ||
    		contains(fileName[0],"MMAT.BATCH")
    		) ? true : false;
    if (("true").equals(pdf) && !overridePDFOption) {
        dlType = "TXTPDF";
    } else {
        dlType = "TXTDAT";
    }
    int extPos;
    for (int i = 0; i < fileName.length; i++)
    {
    	extPos = fileName[i].lastIndexOf(".");
    	if (extPos >= 0) {
    		String ext = fileName[i].substring(extPos).toUpperCase();
    		if (FileNameUtil.knownExtension(ext))
    			fileDlType[i] = "TYPE";
    	}
		if (fileDlType[i] == null)
			fileDlType[i] = dlType;
    }
	/*  Duplicate code snipped thus commented  
	 *  for (int i = 0; i < fileName.length; i++)
	    {
	    	extPos = fileName[i].lastIndexOf(".");
	    	if (extPos >= 0) {
	    		String ext = fileName[i].substring(extPos).toUpperCase();
	    		if (FileNameUtil.knownExtension(ext))
	    			fileDlType[i] = "TYPE";
	    	}
			if (fileDlType[i] == null)
				fileDlType[i] = dlType;
	    }*/
    ServletOutputStream os       = response.getOutputStream();
  // FileOutputStream os = new FileOutputStream("C:\\new.zip");
    ZipOutputStream zout = new ZipOutputStream(os);
    
    String fileDisplayName = null;
    String sourceFile = null;
    
	for (int i = start; i < fileName.length; i++) {
		fileDisplayName = fileName[i];
		 if ("TXTPDF".equals(fileDlType[i]))
	        {          
			 fileDisplayName = fileDisplayName + ".pdf";   
			 fileName[i] = fileDisplayName;

	        }else if ("TXTDAT".equals(fileDlType[i])){
	        	fileDisplayName = fileDisplayName + ".txt";
	        }
		 
      ZipEntry ze = new ZipEntry(fileDisplayName);
     
      try {
        System.out.println("Downloading " + fileDisplayName);
        sourceFile = MFId + "\\" + pathName + "\\" + MFId + "." + fileName[i];
        zout.putNextEntry(ze); 


       this.writeFile(request, zout, sourceFile, userId, session,MFId,i,fileDisplayName,directDownloadFlag);
        zout.closeEntry();
        String status = "40";
		if (statusParm){
			updateFTPtracking(status, rptType, MFId );
		}
            
      } finally {
        
      }
    }
	zout.finish(); 
	zout.close(); 
   
    
    os.flush();
    os.close();

    logger.info("File downloaded at client successfully");
  }
private boolean updateFTPtracking(String stat, String Rpt_type, String MF_id)
{logger.info("FTP Tracking: Updateing");
logger.info(Rpt_type+"::"+MF_id);
int status;
  try {
      status = new Integer(stat).intValue();
  } catch(NumberFormatException nfe) {
      status = -1;
  }

  if (status != 40 && status != 45)
  {
      logger.info("Invalid Status Code [" + status + "]");
    
      return false;
  }

  String ExMsg = null;
  int ExCode = 0;

  Connection conn = null;
  Statement stmt = null;
  ResultSet rs = null;
  String SQL = null;

  // Is the Driver Available
  try {

     conn = DbConn.getConnection();
      stmt = conn.createStatement();

      SQL = "UPDATE ftptracking set WebToClient = Current_Timestamp, Status_ind = " + status + " WHERE MF_id = '" + MF_id + "' AND Rpt_type = '" + Rpt_type + "'";
      stmt.executeUpdate(SQL);

      logger.info("SUCCESS");

  } catch(SQLException eSQL) {
      ExMsg = eSQL.getMessage();
      ExCode = eSQL.getErrorCode();
      logger.error("SQL Exception: " + ExCode + " : " + ExMsg);
      logger.error("ERROR");
  } catch(NullPointerException eNullPointer){
      ExMsg = eNullPointer.getMessage();
      logger.error("NullPointer Exception: " + ExMsg);
     logger.error("ERROR");
  } finally {
    
      try {
          if (rs != null)
              rs.close();
      } catch (Exception e) {
          logger.error("Exception: " + e.getMessage());
      }
      try {
          if (stmt != null)
              stmt.close();
      } catch (Exception e) {
          logger.error("Exception: " + e.getMessage());
      }
      try {
          conn.close();
      } catch (Exception e) {
          logger.error("Exception: " + e.getMessage());
      }
  }


logger.info("FTP Tracking: Updated");
return true;
}

private void writeFile(HttpServletRequest request,ZipOutputStream zout,String rptName,String userId,HttpSession session,
		String MFId,int cnt,String fileName,boolean directDownloadFlag){
  
    logger.debug("Rpt Name: " + rptName);

    DataInputStream in = null;
    String abort = "true";
    int timeOut = session.getMaxInactiveInterval();
    boolean isPDF = false;
    int totalBytes = 0;        
    try {
    	session.setMaxInactiveInterval(36000);
    	logger.debug("checking for PDF extension "+fileName);
    	if(rptName.contains("M6COP") || rptName.contains("RECON") || rptName.contains("M6BL") || rptName.contains("M6PY")
        		|| rptName.contains("M6MB") || rptName.contains("PTD") || rptName.contains("PAY") || rptName.contains("HCC")
        		|| rptName.contains("PLANPAY") || rptName.contains("BILL") || rptName.contains("SUM") || rptName.contains("MON")){
            if(rptName.toLowerCase().contains(".pdf")){
            	logger.debug("Has PDF extension for "+fileName);
      	   isPDF = true;
      	   //Recon Baseplus UI issues:start
      	   rptName = rptName.toLowerCase().replace(".pdf", "");
      	   //Recon Baseplus UI issues:end
             }
         	}
         	
         	else{
      		if(rptName.toLowerCase().contains(".pdf")){
      			logger.debug("2 >>> Has PDF extension for "+fileName);
      	    	   isPDF = true;
      	          }
      	}
                   
        URL receiveServlet = new URL("http://" + MssProperties.getFileAppURL() + "/servlet/SendFileServlet?Id="+URLEncoder.encode("W/Ef2E+8+yn9Ba86OI78BLmK1J4=")+"&rpt="+rptName);
        URLConnection uc = receiveServlet.openConnection();

        uc.setDoInput(true);
        uc.setDoOutput(true);
        uc.setUseCaches(false);
        uc.setRequestProperty("Content-type","application/octet-stream");

        in = new DataInputStream(uc.getInputStream());
        
        //directDownloadFlag =true => the download should be binary . Added as per IFOX-00394063
        if(isPDF && (!directDownloadFlag)){
        	logger.debug("Processing PDF for "+fileName);
        	this.addPDFToZip(in, zout,fileName);
        	logger.debug("PDF is added "+fileName);
        }
        else {
	       	//binary download
        	logger.debug("#### starting binary download for file:"+fileName);	
	        int bufSize = 4196;
	        byte[] data = new byte[bufSize];        
	                               
	        int bytesRead = 0;
	    
	        while (bytesRead >= 0)
	        {
	            bytesRead = in.read(data,0,bufSize);
	            if (bytesRead == -1) break;
	            totalBytes += bytesRead;
	            zout.write(data,0,bytesRead);
	        }
	        logger.debug("#### completed binary download for file:"+fileName);
        }
        
        
    } catch(Exception e) {
        logger.error(e.getMessage());
        abort = "false";
    } finally {
    	session  = request.getSession(false);
    	session.setMaxInactiveInterval(timeOut);
        try {
            if (in != null) in.close();
        } catch(Exception e) {
            logger.error(e.getMessage());
        }
                
    }
    logger.debug(MFId + " " + rptName + " " + abort + " " + cnt + " " + totalBytes);
    Connection conn = null;
    try {
        DateUtil du = new DateUtil();
        DateFormatter df = new DateFormatter();
        
        conn = DbConn.getConnection();
        
        SecgroupPersistence sgp = new SecgroupPersistence();
        String Cust_nbr = sgp.getCustNbrByUserId(conn, userId);
        File f = new File(rptName);
        String baseName = f.getName();

        FileXferLog fxl = new FileXferLog();
        fxl.setXferTimestamp(df.reFormatDate(du.getDTS(),DateFormatter.YYYYMMDDHHMMSSFF,DateFormatter.SQL_TIMESTAMP));
        fxl.setSponsorCust(Cust_nbr);
        fxl.setUserId(userId);
        fxl.setFileName(baseName);
        fxl.setSource("SMS");
        fxl.setDestination("WEB");
        fxl.setTotalBytes(totalBytes);
        
        FileXferLogPersistence fxlp = new FileXferLogPersistence();
        fxlp.InsertFileXferLog(conn, fxl);           
    } catch(Exception e) {
        logger.error(e.getMessage());
    } finally {
        try {
            if (conn != null)
                conn.close();
        } catch(Exception e) {
        	logger.debug(e.toString());
        }
    }        
         
           // logger.error(e.getMessage());
        }

	private Document addPDFToZip(DataInputStream input,
			ZipOutputStream outputStream, String fileName) {
		Document output = null;
		logger.debug("IN addPDFToZip method for "+fileName);
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			output = new Document(PageSize.A1);

			PdfWriter.getInstance(output, baos);

			output.addAuthor("Wipro Infocrossing");
			output.addSubject(fileName);
			output.addTitle(fileName);
			output.open();

			Font f1 = FontFactory.getFont(FontFactory.COURIER, 11);

			String line = "";
			logger.debug("Reading lines");
			while (null != (line = input.readLine())) {
				//log.println(line);
				Paragraph p = new Paragraph(line, f1);
			//	p.setAlignment(Element.ALIGN_JUSTIFIED);
				output.add(p);
			}
			
			output.close();
			input.close();

			outputStream.write(baos.toByteArray());
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("ERROR in addPDFToZip method for "+e.getMessage());

		}
		
		return output;

	}
	
	private boolean canOverridePDFOpt(String rptName, String MFId){
		/*IFOX-00402119*/
		System.out.println(" DirectDownloadServlet : rptName ["+rptName+"] ");
		if(null != textReports)
			for(int i = 0; i < textReports.length; i++) 
				System.out.println("DirectDownloadServlet : TextReports[" + i + "] = [" + textReports[i] + "] ");
		/*IFOX-00402119*/
		
		if (null != MFId && !"HCF0281".equals(MFId)) { // change for TripleS
			String[] textReport = new String[5];
			for(int i = 0; i < textReports.length-2; i++) {
				textReport[i]=textReports[i];
				System.out.println("DirectDownloadServlet : TextReport[" + i + "] = [" + textReport[i] + "] ");
			}
			if (rptName != null && textReport != null) {
				for (String filter : textReport) {
					if (rptName.contains(filter)) {
						return true;
					}
				}
			}
		}
	else{
		if(rptName != null && textReports != null){
			for(String filter:textReports){
				 if(rptName.contains(filter)){
					 return true;
				 }
			}
		}
	}	
		return false;
	}

	private boolean contains(String str,String subStr){
		return str != null && subStr != null && str.indexOf(subStr) >= 0 ? true : false;
	}
}
