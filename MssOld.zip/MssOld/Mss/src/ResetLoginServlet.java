import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.mss.db.DbConn;
import com.ps.mss.util.MssProperties;
import com.ps.net.URLEncoder;

public class ResetLoginServlet extends HttpServlet
{
	private static Logger logger = LoggerFactory.getLogger(ResetLoginServlet.class);

    public void service(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        String remoteHost = request.getRemoteHost();
        logger.debug(remoteHost);
        logger.debug(request.getRequestURI());
        logger.debug(request.getQueryString());
        logger.debug(request.getContextPath());

        String callUrl = request.getParameter("Url");
        if (callUrl == null)
            callUrl = MssProperties.getWebAppURL();

        String User_id = request.getParameter("User_id");

	    String sSource = request.getParameter("Source");
        String sDest = null;
        if (sSource == null)
        {
    	    sDest = "http://" + callUrl + "/mssadmin/admin/UserDtlJsp.jsp?Mode=Edit&Source=UserList&User_id="+User_id;
        }
        else
        {
	        sDest = "http://" + callUrl + sSource;
        }

        if (User_id == null)
        {
            response.sendRedirect((String)response.encodeRedirectURL("http://" + callUrl + "/mssadmin/jsp/MsgJsp.jsp?Msg=Invalid+User+Id+/+Password&CL=" + URLEncoder.encode(sDest)));
            return;
        }

        User_id = User_id.trim().toUpperCase();

        if (User_id.length() == 0)
        {
            response.sendRedirect((String)response.encodeRedirectURL("http://" + callUrl + "/mssadmin/jsp/MsgJsp.jsp?Msg=Invalid+User+Id+/+Password&CL=" + URLEncoder.encode(sDest)));
            return;
        }

        String rqsList = "";

        //Hashtable hList = new Hashtable();
        //Hashtable pool = rqs_pool.get_mpool().getPool();
        //if (pool != null)
        //    hList.put(new Integer(1), pool);
        //
        //Enumeration ekeys = hList.keys();
        //while (ekeys.hasMoreElements())
        //{
        //    Integer pool_key = (Integer)ekeys.nextElement();
        //    try {
        //        pool = (Hashtable)hList.get(pool_key);
        //        if (pool != null)
        //        {
        //            Enumeration rqsSessions = pool.keys();
        //            String rqsSessionId;
        //            RQSFrameManager rqsframemanager;
        //            String wasID;
        //            String mssUserID;
        //            while(rqsSessions.hasMoreElements())
        //            {
        //                rqsSessionId = (String)rqsSessions.nextElement();
        //                rqsframemanager = (RQSFrameManager)pool.get(rqsSessionId);
        //
        //                try  {
        //                    mssUserID = rqsframemanager.getManagerPropStr("mssUserID");
        //                    if (mssUserID != null)
        //                    {
        //                        if (mssUserID.equals(User_id))
        //                        {
        //                            try {
        //                                rqs_pool.removeSession(rqsframemanager);
        //                                rqsList = rqsList + "[Killed " + rqsSessionId + "]";
        //                                logger.error("ResetLoginServlet: ResQPortal Session " + rqsSessionId + " Killed");
        //                            } catch(Exception e) {
        //                                rqsList = rqsList + "[Error " + rqsSessionId + "]";
        //                                logger.error("ResetLoginServlet: Error Killing Session: " + e.getMessage());
        //                            }
        //                        }
        //                    }
        //                } catch(Exception e) {
        //                    logger.error("ResetLoginServlet: Error getting ResQPortal Property: " + e.getMessage());
        //                }
        //            }
        //        }
        //    } catch(Exception e) {
        //        logger.error("ResetLoginServlet: Error getting ResQPortal pool: " + e.getMessage());
        //    }
        //}

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        String SQL = null;
        
        try {
            // Establish a Connection to the Database
            conn = DbConn.getConnection();
            stmt = conn.createStatement();

            // Customer Query
            SQL = "SELECT distinct cust_nbr" +
                   " FROM secuser, secgroup" +
                  " WHERE secuser.User_id = '" + User_id + "'" +
                    " AND secuser.group_id = secgroup.group_id";
            rs = stmt.executeQuery(SQL);
            if (rs.next())
            {
                String Cust_Nbr = rs.getString("CUST_NBR");

                // Check to see if the user is logged in for the case of browser crash
                // if this happens the user may not be logged out and need there flags
                // reset manually.  however when the session times this code will be
                // execuated.  so check the log in status so the customer login count
                // dose not become corrupt

                // Get the user signed on field
                SQL = "SELECT SignedOn_yn FROM secuser WHERE User_id ='" + User_id + "'";
                rs = stmt.executeQuery(SQL);
                if (rs.next())
                {
                    String SignedOn_yn = rs.getString("SignedOn_yn");

                    if (SignedOn_yn.equals("Y"))
                    {
                        //Update the user signed on field
                        SQL = "UPDATE secuser SET Signoff_time = CURRENT_TIMESTAMP, signedon_yn = 'N', was_sid = null WHERE User_id ='" + User_id + "'";
                        int rowcount1 = stmt.executeUpdate(SQL);

                        // NOT RIGHT NEEDS TO BE BASED ON SERVICES
                        //Update customer signon count
                        SQL = "UPDATE customer SET signon_cnt = signon_cnt - 1 WHERE cust_nbr = '" + Cust_Nbr +"'";
                        int rowcount2 = stmt.executeUpdate(SQL);

                        if ((rowcount1 == 1) && (rowcount2 == 1))
                        {
                            SQL = "INSERT INTO appllog( log_date, Logkey1, Msg_id, Module_id, Errloc_id, Comments ) VALUES ( CURRENT_TIMESTAMP, '" + User_id + "',9,4,1,'" + rqsList + "')";
                            stmt.executeUpdate(SQL);
                            response.sendRedirect((String)response.encodeRedirectURL("http://" + callUrl + "/mssadmin/jsp/MsgJsp.jsp?Msg=User+Reset&CL=" + URLEncoder.encode(sDest)));
                        } else {
                            logger.debug("ResetLoginServlet: Rowcount Error [" + rowcount1 + "][" + rowcount2 + "]");
                            SQL = "INSERT INTO appllog( log_date, Logkey1, Msg_id, Module_id, Errloc_id, Comments ) VALUES ( CURRENT_TIMESTAMP, '" + User_id + "',6,4,2,'"+ rqsList + "[" + rowcount1 + "][" + rowcount2 + "]')";
                            stmt.executeUpdate(SQL);
                            response.sendRedirect((String)response.encodeRedirectURL("http://" + callUrl + "/mssadmin/jsp/MsgJsp.jsp?Msg=Error+Updateing+Database&CL=" + URLEncoder.encode(sDest)));
                        }
                    }
                    else
                        response.sendRedirect((String)response.encodeRedirectURL("http://" + callUrl + "/mssadmin/jsp/MsgJsp.jsp?Msg=User+Id+Was+Not+Logged+in&CL=" + URLEncoder.encode(sDest)));
                }
                else
               	    response.sendRedirect((String)response.encodeRedirectURL("http://" + callUrl + "/mssadmin/jsp/MsgJsp.jsp?Msg=Invalid+User+Id&CL=" + URLEncoder.encode(sDest)));
            }
            else
        	    response.sendRedirect((String)response.encodeRedirectURL("http://" + callUrl + "/mssadmin/jsp/MsgJsp.jsp?Msg=Invalid+User+Id&CL=" + URLEncoder.encode(sDest)));

        } catch(SQLException eSQL) {
            logger.error("ResetLoginServlet: " + SQL + "\n" + eSQL.getMessage());
            response.sendRedirect((String)response.encodeRedirectURL("http://"+callUrl+"/mssadmin/jsp/MsgJsp.jsp?Msg=SQL+Exception&CL=" + URLEncoder.encode(sDest)));
        } catch(NullPointerException eNullPointer) {
            logger.error("ResetLoginServlet: " + SQL + "\n" + eNullPointer.getMessage());
            response.sendRedirect((String)response.encodeRedirectURL("http://"+callUrl+"/mssadmin/jsp/MsgJsp.jsp?Msg=Database+Connection+Error&CL=" + URLEncoder.encode(sDest)));
        } finally {
            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
                logger.error("ResetLoginServlet: " + e.getMessage());
            }

            try {
                if (stmt != null)
                    stmt.close();
            } catch (Exception e) {
                logger.error("ResetLoginServlet: " + e.getMessage());
            }

            try {
                if (conn != null)
                    conn.close();
            } catch (Exception e) {
                logger.error("ResetLoginServlet: " + e.getMessage());
            }
        }
    }
}



