/*
 * $Id: LoginServlet.java,v 1.4 2016/08/21 23:16:17 dinesh Exp $
 */
//performance fix--start
//import java.io.File;
//performance fix--end
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.slf4j.LoggerFactory;
import com.ps.io.ModuleLog;
import com.ps.mss.db.AppLogPersistence;
import com.ps.mss.db.CustSvcParmsPersistence;
import com.ps.mss.db.CustSvcParmsValues;
import com.ps.mss.db.CustomerPersistence;
import com.ps.mss.db.DbConn;
//performance fix--start
//import com.ps.mss.db.GroupSvcParmsPersistence;
//performance fix--end
import com.ps.mss.db.EEMProfileSettings;
import com.ps.mss.db.Message;
import com.ps.mss.db.Module;
import com.ps.mss.db.RptType;
import com.ps.mss.db.SecPlanPersistence;
import com.ps.mss.db.SecuserPersistence;
import com.ps.mss.db.SecuserSetting;
import com.ps.mss.db.SecuserSettingPersistence;
import com.ps.mss.dynaCache.EEMLoginDynaCache;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.security.CryptoDigest;
import com.ps.mss.security.SessionCrypt;
import com.ps.mss.security.SessionManager;
import com.ps.mss.util.MssProperties;
import com.ps.net.URLEncoder;
import com.ps.text.DateFormatter;
import com.ps.text.TextFormatter;
import com.ps.util.DateUtil;
import com.ps.util.ServerProperties;
//performance fix--start
//import com.ps.util.ServerProperties;
//performance fix--end
import com.ps.util.StringUtil;
import com.ps.mss.framework.Constants;
import com.ps.mss.framework.EEMConstants;

import com.ps.mss.web.helper.SessionHelper;

public class LoginServlet extends HttpServlet
{
private static Logger logger = LoggerFactory.getLogger(LoginServlet.class);

public void init() throws ServletException
{
    ServletContext sc = getServletContext();
    Hashtable monitor = new Hashtable();
    sc.setAttribute("monitor",monitor);
}

/*ModuleLog log = new ModuleLog("LoginServlet");*/

public void doPost(HttpServletRequest request, HttpServletResponse response)
  throws ServletException, IOException
{
	logger.info("UserID [" + StringUtil.nonNullTrim(request.getParameter("User_id")) 
	+ "], MethodName [doPost] :: START");
	long starttime = System.currentTimeMillis();
	//sso changes - start
	String userId = "";
	boolean sso = false;
	String ssoInd = StringUtil.nonNullTrim((String)request.getAttribute("SSO"));
	if(ssoInd.equalsIgnoreCase("true")){
		sso = true;
	}
	if(sso){
	userId = (String)request.getAttribute("User_id");
	}
	
	HttpSession session;
	if(!sso){
	session  = request.getSession(false);
    if (session != null)
    	session.invalidate();
	}
    boolean debug = false;
    long tid = System.currentTimeMillis();

    String BaseUrl = MssProperties.getWebAppURL();
    String parmUserId = "";
    String parmUserPwd = "";
    if(!sso){
     parmUserId = StringUtil.nonNullTrim(request.getParameter("User_id"));
     parmUserPwd = StringUtil.nonNullTrim(request.getParameter("User_pwd"));
    }
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    String screen = (int)screenSize.getWidth() + "x" + (int)screenSize.getHeight();
    String userAgent = request.getHeader("User-Agent"); 
    //String screen = request.getParameter("screen");
    //String userAgent = request.getParameter("userAgent");
  //sso changes - end
  //performance fix--start
    /*String parmWebMaster = StringUtil.nonNullTrim(request.getParameter("WebMaster"));

    if (parmUserId.equals("") || (parmUserId.length() > 10))
    {
        log.println("No User Id");
        response.sendRedirect((String)response.encodeRedirectURL("https://"+BaseUrl+"/mss/home/Index.jsp?sMsg=Invalid+User+Id+or+Password&UId="+URLEncoder.encode(parmUserId)));
        return;
    }*/
  //performance fix--end
  //sso changes - start
    String userPwd = "";
    if(!sso){
     userId = parmUserId.toUpperCase();
     userPwd = null;
    
    CryptoDigest crypt = new CryptoDigest();
    try {
        userPwd = crypt.digest(userId,parmUserPwd.trim());
     //  System.out.println("userPwd:::"+userPwd);
    } catch(NoSuchAlgorithmException e) {
        userPwd = null;
    }
    }
  //sso changes - end
    Connection conn = null;
    PreparedStatement psUsr = null;
    PreparedStatement psCust = null;
    PreparedStatement psService = null;
    PreparedStatement psState = null;
    PreparedStatement ps = null;
    ResultSet rsUsr = null;
    ResultSet rsCust = null;
    ResultSet rsState = null;
    ResultSet rs = null;
    String SQL = null,mStatus = "TRUE";    
    String uniqueClaimInd = "FALSE";    // IFOX 367728
    boolean edpsFileTrackingFlag = false;

    boolean inTrans = false;
    boolean mustCommit = false;
  //sso changes - start
    PreparedStatement psUsrPwd = null;
    ResultSet rsUsrPwd = null;
  //sso changes - end
    //performance fix--start
    // check here in case DB is down
    /*boolean inMaintenance = false;
    File fn = new File("D:\\Java\\MAINTENANCE");
    if (fn.exists())
    {
        if (!parmWebMaster.equals("TRUE"))
        {
       		response.sendRedirect((String)response.encodeRedirectURL("https://"+BaseUrl+"/mss/home/MaintInProgressJsp.jsp") );
       		return;
        }
        inMaintenance = true;
    }*/     
    //performance fix--end
    try {
    	conn = DbConn.getConnection();

        ServletContext sc = getServletContext();
        HttpSession oldSession = null;
        Hashtable monitor = (Hashtable)sc.getAttribute("monitor");

        AppLogPersistence alp = new AppLogPersistence();
        SecuserPersistence sup = new SecuserPersistence();
        CustomerPersistence cp = new CustomerPersistence();
        SecuserSettingPersistence ssp = new SecuserSettingPersistence();
        //performance fix--start
        // Second check on Maintence WebMaster parm passed in, need database up
        /*if (inMaintenance)
        {
        	String webMaster = StringUtil.nonNullTrim(ssp.getValue(conn,userId,SecuserSetting.WEBMASTER));
            if (!webMaster.equals("TRUE")) {
            	log.println("User: " + userId + " Attempeted Login During maintance");
            	response.sendRedirect((String)response.encodeRedirectURL("https://"+BaseUrl+"/mss/home/MaintInProgressJsp.jsp") );
            	return;
            }
        }*/        
        //performance fix--end
        synchronized (this) {
            if (monitor.containsKey(userId))
            {
                oldSession = (HttpSession)monitor.get(userId);
            }
            if (oldSession != null)
            {
            	alp.add(conn,userId,Module.LOGIN_SERVLET,Message.KILLING_MONITOR_SESSION,1);

            	logger.debug("[" + tid + "] Invalidating Monitor Session For " + userId + " " + oldSession.getId());

                try {
                	LoginBindingListener lbl = (LoginBindingListener)oldSession.getAttribute("LoginBindingListener");
                	lbl.setNeedLogout(false);

                    oldSession.removeAttribute("LoginBindingListener");
                    oldSession.removeAttribute("HII");
					//SSNRI Conversion Tab. START
					oldSession.removeAttribute("MBIC");
					//SSNRI Conversion Tab. END
                    oldSession.removeAttribute("ERS");
                    oldSession.removeAttribute("ERP");
                    oldSession.removeAttribute("RetroAdj");
                    oldSession.removeAttribute("Recon");
                    oldSession.removeAttribute(Constants.SESSION_SERVICE_BOR);
                    oldSession.removeAttribute("RxRecon");
                    oldSession.removeAttribute("RaExpert");
                    oldSession.removeAttribute(SessionManager.RXRECONDB);
                    oldSession.removeAttribute(SessionManager.RECONDB);
                    oldSession.removeAttribute(SessionManager.RAPSDB);
                    oldSession.removeAttribute(SessionManager.RECONUIDB);
                    oldSession.removeAttribute("Enctr");
                    oldSession.removeAttribute("FTS");
                    oldSession.removeAttribute("FTEmail");
                    oldSession.removeAttribute("OLP");
                    oldSession.removeAttribute("QAP");
                    oldSession.removeAttribute("QAM");                   
                    oldSession.removeAttribute("QAS");
                    oldSession.removeAttribute("QAR");
                    oldSession.removeAttribute("QCA");
                    oldSession.removeAttribute("Plan_id");
                    oldSession.removeAttribute("MF_id");
                    oldSession.removeAttribute("Cust_type");
                    oldSession.removeAttribute("Cust_nbr");
                    oldSession.removeAttribute("User_id");
                    oldSession.removeAttribute("User_pwd");
                    oldSession.removeAttribute("tid");
                    oldSession.removeAttribute("screen");
                    oldSession.removeAttribute("TESTCICS");
                    oldSession.removeAttribute("WRO");
                    oldSession.removeAttribute("QCD");
                    oldSession.removeAttribute("QLP");
                    oldSession.removeAttribute("QLM");
                    oldSession.removeAttribute("QLS");
                    oldSession.removeAttribute("QLR");
                	oldSession.removeAttribute("ILMR");
					oldSession.removeAttribute("TXMR");
					oldSession.removeAttribute("NMMR");
					oldSession.removeAttribute("MNMR");
					oldSession.removeAttribute("MRA");
					oldSession.removeAttribute("MRD");
					oldSession.removeAttribute("MRP");
					oldSession.removeAttribute("NMA");
					oldSession.removeAttribute("NMD");
					oldSession.removeAttribute("NMP");
					oldSession.removeAttribute("TXA");
					oldSession.removeAttribute("TXD");
					oldSession.removeAttribute("TXP");
					oldSession.removeAttribute("MNA");
					oldSession.removeAttribute("MND");
					oldSession.removeAttribute("MNP0");
					//IFOX - 431927 Global Health Data Masking : start
					oldSession.removeAttribute("MASK");
					//IFOX - 431927 Global Health Data Masking : end
                    
                    
                    oldSession.invalidate();
                } catch (Throwable t) {
                    alp.add(conn,userId,Module.LOGIN_SERVLET,Message.MONITOR_SESSION_NOT_EXISTS,2);
                    logger.error("[" + tid + "] Illegal State killing session For " + userId);
                    logger.error("[" + tid + "] " + t.toString());

                    monitor.remove(userId);
                }
            }
        }
        
        conn.setAutoCommit(false);
        inTrans = true;
        
        SQL = "SELECT User_pwd, Group_id, HintAnswer, SignedOn_YN, Active_YN, PwdExpire_date, Failed_Logon_cnt, Hint2_Answer, Hint3_Answer FROM secuser WHERE User_id = ? FOR UPDATE";
        psUsr = conn.prepareStatement(SQL);
        psUsr.setString(1,userId);

        rsUsr = psUsr.executeQuery();
        
        if (!rsUsr.next())
        {
        	conn.setAutoCommit(true);
        	inTrans = false;
        	logger.debug("Invalid User id [" + userId + "]");
        	alp.add(conn,userId,Module.LOGIN_SERVLET,Message.INVALID_USER_ID,3);
        	//sso changes - start
        	if(!sso){
            //Home Page changes-Start
        	response.sendRedirect((String)response.encodeRedirectURL("https://"+BaseUrl+"/mss/home/Index.jsp?sMsg=Invalid+User+Id+or+Password&UId="+URLEncoder.encode(parmUserId)));
        	//Home Page changes-End
        	} else{
        		response.sendRedirect((String) response.encodeRedirectURL("https://"+ BaseUrl+ "/mss/jsp/ErrorUnauthorizedJsp.jsp?Msg=An+Unauthorized+User"));
        	}
        	//sso changes - end
        	logger.info("UserID [" + StringUtil.nonNullTrim(request.getParameter("User_id")) 
    		+ "], MethodName [doPost] :: END");
        	return;
        }

        String dbUserPwd = StringUtil.nullTrim(rsUsr.getString("User_pwd"));
        String groupId =  StringUtil.nonNullTrim(rsUsr.getString("Group_id"));
        String hintAnswer = StringUtil.nonNullTrim(rsUsr.getString("HintAnswer"));
        String signedOn = rsUsr.getString("SignedOn_yn");
        String activeYN = rsUsr.getString("Active_yn");
        String pwdExpireDate = rsUsr.getString("PwdExpire_date");
        int failedLogonCnt = rsUsr.getInt("Failed_Logon_cnt");
        String hintAnswer2 = StringUtil.nonNullTrim(rsUsr.getString("Hint2_Answer"));
        String hintAnswer3 = StringUtil.nonNullTrim(rsUsr.getString("Hint3_Answer"));

        //SQL = "SELECT Cust_nbr FROM secgroup WHERE Group_id = ?";
        SQL = "SELECT Cust_nbr, mfuser.MF_id, MF_pwd FROM secgroup JOIN mfuser ON mfuser.mf_id = secgroup.mf_id WHERE TRIM(Group_id) = ?";
        psCust = conn.prepareStatement(SQL);
        psCust.setString(1,groupId.trim());
        rsCust = psCust.executeQuery();
     
        
        if(!rsCust.next()) 
        {
        	conn.setAutoCommit(true);
        	inTrans = false;
        	logger.debug("Error Getting Cust Nbr from secgroup joining mfuser , [" + userId + "]");
        	alp.add(conn,userId,groupId,Module.LOGIN_SERVLET,Message.CUST_QUERY_ERROR,4);
        	//sso changes - start
        	if(!sso){
        	//Home Page changes-Start
            response.sendRedirect((String)response.encodeRedirectURL("https://"+BaseUrl+"/mss/home/Index.jsp?sMsg=Unexpected+Response&UId="+URLEncoder.encode(parmUserId)));
          //Home Page changes-End
        	}else{
        		response.sendRedirect((String) response.encodeRedirectURL("https://"+ BaseUrl+ "/mss/jsp/ErrorJsp.jsp?Msg=An+Unexpected+Response+Has+Occured"));
        	}
        	//sso changes - end
        	logger.info("UserID [" + StringUtil.nonNullTrim(request.getParameter("User_id")) 
    		+ "], MethodName [doPost] :: END");
        	return;        	
        }
        
        System.out.println("rsCust-first is success " );
        String custNbr = StringUtil.nonNullTrim(rsCust.getString("Cust_nbr"));
        String mfId = rsCust.getString("MF_id");
        //performance fix--start
        //String mfPwd = rsCust.getString("MF_pwd");
        //performance fix--end
      //sso changes - start
        if(!sso){
      //sso changes - end
        if (activeYN.equals("L"))
        {
        	sup.updateFailedLogin(conn,userId,failedLogonCnt,activeYN);
        	conn.commit();
        	mustCommit = false;
        	inTrans = false;
        	conn.setAutoCommit(true);
        	alp.add(conn,userId,Integer.toString(failedLogonCnt),Module.LOGIN_SERVLET,Message.LOCKED_USER_LOGIN,4);
        	logger.debug("Locked User Login Attempt " + userId + " [" + failedLogonCnt + "]");
          //Home Page changes-Start
            response.sendRedirect((String)response.encodeRedirectURL("https://"+BaseUrl+"/mss/home/Index.jsp?sMsg=Account+Is+Locked&UId="+URLEncoder.encode(parmUserId)));
          //Home Page changes-End
            logger.info("UserID [" + StringUtil.nonNullTrim(request.getParameter("User_id")) 
    		+ "], MethodName [doPost] :: END");
            return;
        }

        if (!activeYN.equals("Y"))
        {
        	sup.updateFailedLogin(conn,userId,failedLogonCnt,activeYN);
        	conn.commit();
        	mustCommit = false;
        	inTrans = false;
        	conn.setAutoCommit(true);
        	alp.add(conn,userId,Integer.toString(failedLogonCnt),Module.LOGIN_SERVLET,Message.INACTIVE_LOGIN_ATTEMPT,4);
        	logger.debug("Inactive User Login Attempt " + userId + " [" + failedLogonCnt + "]");
          //Home Page changes-Start
            response.sendRedirect((String)response.encodeRedirectURL("https://"+BaseUrl+"/mss/home/Index.jsp?sMsg=Inactive+Account&UId="+URLEncoder.encode(parmUserId)));
          //Home Page changes-End
            logger.info("UserID [" + StringUtil.nonNullTrim(request.getParameter("User_id")) 
    		+ "], MethodName [doPost] :: END");
            return;
        }
      //sso changes - start
        }
      //sso changes - end
        /*
         * Whether plan is MMP or not, it will be identified by the below table.
         * If record is present in this table it means the plan is MMP 
         */
       SQL = "SELECT * FROM statemmp WHERE MMP_MF_ID = ?";
        psState = conn.prepareStatement(SQL);
        psState.setString(1,mfId);
        rsState = psState.executeQuery();
        if (!rsState.next()) {
        	mStatus = "FALSE";
        }
     //   IFOX 367728 Starts
        /*   SQL = "SELECT OVERRIDE_IND FROM ENC_PROFILE WHERE PARM_CD = ? AND Mf_id = ?";
        psState = conn.prepareStatement(SQL);
        psState.setString(1, "UNIQUE");
        psState.setString(2, mfId);
        rsState = psState.executeQuery();
        if (rsState.next()) {
        String val = StringUtil.nonNullTrim(rsState.getString("OVERRIDE_IND"));
        if (val != null) {
			if (val.equalsIgnoreCase("N"))
				uniqueClaimInd = "TRUE";
			else if (val.equalsIgnoreCase("Y"))
				uniqueClaimInd = "FALSE";
		}
        	
        }*/
        
        
        uniqueClaimInd = "FALSE";
        
        /* IFOX 367728 * Ends */
      //sso changes - start
        if(!sso){ 
      //sso changes - end
        SQL = "SELECT count(*) from secgroup_service WHERE Group_id = ? AND Service_id = ?";
        psService = conn.prepareStatement(SQL);
        
        CustSvcParmsPersistence csvp = new CustSvcParmsPersistence();
        if (ServerProperties.inDMZ()) {
        	String intranetOnly = StringUtil.nonNullTrim(csvp.getParmValue(conn, mfId, "WEB", CustSvcParmsValues.INTRANETONLY));
        	if (!intranetOnly.equals("Y")) {
        		// are we configured at the group level
                psService.setString(1,groupId);
                psService.setString(2,"INTR");
                rs = psService.executeQuery();
                if (rs.next()) {
                	int intraServices = rs.getInt(1);
                	if (intraServices > 0)
                		intranetOnly = "Y";
                }       		
        	}
        	if (intranetOnly.equals("Y")) {
        		String newStatus = sup.updateFailedLogin(conn,userId,failedLogonCnt,activeYN);
            	conn.commit();
            	mustCommit = false;
            	inTrans = false;
            	conn.setAutoCommit(true);
            	alp.add(conn,userId,Integer.toString(failedLogonCnt),Module.LOGIN_SERVLET,Message.BLOCKED_INTERNET_LOGIN,5);
            	logger.debug("Blocked Internet Login Attempt " + userId + " [" + failedLogonCnt + "]");
                String msg = null;
                if (newStatus.equals("L"))
                	msg = "Account is Locked";
                else
                	msg = "Internet Access Disabled";
                response.sendRedirect((String)response.encodeRedirectURL("https://"+BaseUrl+"/mss/home/LoginPage.jsp?sMsg=" + URLEncoder.encode(msg) + "&UId="+URLEncoder.encode(parmUserId)));
                logger.info("UserID [" + StringUtil.nonNullTrim(request.getParameter("User_id")) 
        		+ "], MethodName [doPost] :: END");
                return;        		
        	}
        }
                
        if (!dbUserPwd.equals(userPwd))
        {
        	String newStatus = sup.updateFailedLogin(conn,userId,failedLogonCnt,activeYN);
        	conn.commit();
        	mustCommit = false;
        	inTrans = false;
        	conn.setAutoCommit(true);
        	alp.add(conn,userId,Integer.toString(failedLogonCnt), "[" + dbUserPwd + "][" + userPwd + "]", Module.LOGIN_SERVLET,Message.FAILED_LOGIN_ATTEMPT,5);
            // Debug for Reported Password Issue
        	//alp.add(conn,userId,Integer.toString(failedLogonCnt), "[" + dbUserPwd + "][" + userPwd + "][" + parmUserPwd + "]", Module.LOGIN_SERVLET,Message.FAILED_LOGIN_ATTEMPT,6);
        	logger.debug("Failed Login Attempt " + userId + " [" + failedLogonCnt + "]");
            String msg = null;
            if (newStatus.equals("L"))
            	msg = "Account is Locked";
            else
            	msg = "Invalid User Id or Password";
          //Home Page changes-Start
            response.sendRedirect((String)response.encodeRedirectURL("https://"+BaseUrl+"/mss/home/Index.jsp?sMsg=" + URLEncoder.encode(msg) + "&UId="+URLEncoder.encode(parmUserId)));
          //Home Page changes-End
            logger.info("UserID [" + StringUtil.nonNullTrim(request.getParameter("User_id")) 
    		+ "], MethodName [doPost] :: END");
            return;
        }
      //sso changes - start
        }
      //sso changes - end
        //perfomance fix--start
        int ftsServices = 0;
      //perfomance fix--end
        int hiiServices = 0;
		int mbicServices = 0;
        int ersServices = 0;
        int erpServices = 0;
        int rxReconServices = 0;
        int reconServices = 0;
        int reinUpdate = 0;
        int wroServices = 0;
        int enctrServices = 0;
        int raxServices = 0;
        int retroAdjServices = 0;
        int rccServices = 0;
        int qapServices = 0;
        int qamServices = 0;
        int qasServices = 0;        
        int qarServices = 0;
        int olpServices = 0;
        int reportingServices = 0;
        int ftEmailAdminServices = 0;
        int qcdServices = 0;
        int qlpServices = 0;
        int qlmServices = 0;
        int qlsServices = 0;
        int qlrServices = 0;
        int eemServices = 0;
        int eemUpdate = 0;
        int eemSupervisor = 0;
        int eemAppServices = 0;
        int eemAppUpdate = 0;
        int eemMbrServices = 0;
        int eemMbrUpdate = 0;
        int eemLtrServices = 0;
        int eemLtrUpdate = 0;
        int eemBilServices = 0;
        int eemBilUpdate = 0;
        int eemSetupServices = 0;
        int eemSetupUpdate = 0;
        int hpeServices = 0;
        int hpeUpdate = 0;
		  //original application start    
        int emOrignalApp = 0;
        int emValidApp = 0;
        int emCancelApp = 0;
       //original application end
        
        int eemAsesServices = 0;// ASES CR for TripleS
        
        //TSA- CR- 428408- start
        int eemComments = 0;
        int eemDsInfo = 0;
        int eemLEP = 0;
        int eemLTRU = 0;
        int eemAPPLCVC = 0;
        int eemLTRDel = 0;
        int eemDDCUT = 0;
        int eemEnrollLIS = 0;
        int eemEnrollAGT = 0;
        int eemEnrollCOB = 0;
        int eemEnrollButtons = 0;
        int eemLTRReview = 0;
      //TSA- CR- 428408- end

		int emLepUpdate = 0;
        int emDenial = 0;
        int eemTimers=0;
        int eemRejectApp=0;
        int emSecurity=0;
		int emWorKFlow =0;
		int emDashboard =0;
		int emLepLetter = 0;
		int jasperServices = 0;
		/*E&E360 --start*/
			int resq = 0;
    /*E&E360 --end*/
		int eemMbrPcp = 0; //Ticket 415616 
		int edpsFileTrackingService = 0 ;
		int eemOEV= 0;
		
		//Added for VAP to remove update button
		int eemTimerUpdate= 0;
		
		int eligInd=0;
		// HCSC Medicaid Recon -start
					int ilMedReconServ = 0;
					int nmMedReconServ = 0;
					int txMedReconServ = 0;
					int mtMedReconServ = 0;
					int discMedicaidReconServ = 0;
					int paymentMedicaidReconServ = 0;
					int anamolyMedicaidReconServ = 0;
        //HCSC Medicaid Recon -End 
		//IFOX-00395242 - viewPdf-- start
					int viewPdf = 0;
		//IFOX-00395242 - viewPdf-- end
					//IFOX-00399921 LTC Tab. START
					int ltcTab = 0;
					//IFOX-00399921 LTC Tab. END
					int atchTab = 0;
					
					//IFOX-00417542 SOA_Tab START
					int soaTab = 0;
					//IFOX-00417542 SOA_Tab END
					//IFOX- 421763 Billing User Role : start
					int dashboard = 0;
					int billingNSF = 0;
					//IFOX- 421763 Billing User Role : end
					//Recon Demo Work Queue Changes : start
					int workQueue = 0;
					//Recon Demo Work Queue Changes : end
					
					//77141 : EDPS Comments tab changes -start
					int edpsMemberComments=0;
					//77141 : EDPS Comments tab changes -end
					//IFOX - 431927 Global Health Data Masking : start
					int dataMasking =0;
					//IFOX - 431927 Global Health Data Masking : end
        	//performance fix--start
 			List<String> eemServList = EEMLoginDynaCache.getDynaCacheMap(groupId,conn,mfId); 
       /* SQL = "SELECT distinct service_id from secgroup_service WHERE Group_id = ?" +
		        " AND Service_id in ('HII','ERS','BE0','ERP','RXR','RP','R4C','WRO0','EDS'," +
				                    "'RAX','RAE','RAD','RAU','IF','RCC'," +
									"'QAP','QAM','QAS','QAR','QLP','QLM','QLS','QLR','QCD','OLP'," +
									"'BOR','FTE'," +
									"'EEM','EEMU','EEMS','EEMA','EEUA','EEMM','EEUM','EEMB','EEUB','EEML','EEUL','EEMG','EEUG'," +
									"'HPE','HPEU','EEMT','EEGW','EESS','EMAO','EMAV','EMAB','EMAR','EMDA','EEMD','EMCB','EEMN','EMCM','EMUC'," +
									"'EMDM','EMDN','EMDD','EMLU','EMBU','EMAU','EMCU','EMPU','EMAD','EMDU','EMPW','EMOU','EMPN','EMSA','EMDI','EMDL','EMBR','EMEL','EMLP','EMLR','EMUT','EMNA','EMUL','EEWF','EMLL','FLFM')";
        PreparedStatement psServ = conn.prepareStatement(SQL);
        psServ.setString(1,groupId);
        ResultSet rsServ = psServ.executeQuery();
        */
       /* while (rsServ.next()) {*/
//        System.out.println(" eemServList :::: " +eemServList);
        //System.out.println(" in login servlet =="+eemServList.size()+eemServList.contains("EEM"));
        if(eemServList.size() > 0) {
        	//String service = StringUtil.nonNullTrim(rsServ.getString("Service_id"));

        	if (eemServList.contains("FTS"))
        		ftsServices = 1; // File transfer
        
        	if (eemServList.contains("HII"))
        		hiiServices = 1; // Eligibility
        	
			//SSNRI Conversion Tab. START
			if (eemServList.contains("MBIC"))
				mbicServices = 1;//SSNRI Conversion Tab
			//SSNRI Conversion Tab. END
        	
        	if (eemServList.contains("ERS") || eemServList.contains("BE0"))
        		ersServices = 1; // Enrollment Recon
        	 
          	if (eemServList.contains("ERP")) // obsolete
           		erpServices = 1; // Enrollment Recon Production
        	
           	if (eemServList.contains("RXR"))
           		rxReconServices = 1; // Rx RECON
        	 
           	if (eemServList.contains("RP"))
           		reconServices = 1; // RECON
        	 
           	if (eemServList.contains("OLP"))
           		olpServices = 1; // Online Processing
        	 
           	if (eemServList.contains("QAP"))
           		qapServices = 1; // QAdvantage Production
          	 
           	if (eemServList.contains("QAM"))
           		qamServices = 1; // QAdvantage Model Office
           	 
           	if (eemServList.contains("QAS"))
           		qasServices = 1; // QAdvantage Staging
          	 
           	if (eemServList.contains("QAR"))
           		qarServices = 1; // QAdvantage Regression Testing
        	 
           	if (eemServList.contains("WRO0"))
           		wroServices = 1; // Payment Writeoff
        	 
           	if (eemServList.contains("EDS"))
           		enctrServices = 1; // Encounter
           	
            if (eemServList.contains("HPEFT"))
				 edpsFileTrackingService = 1; // EDPS File Tracking Service
        	 
          	if (eemServList.contains("EEM"))
           		eemServices = 1; // EEM
           	
            if (eemServList.contains("EEMU"))
            	eemUpdate = 1; // EEM Update
           	 
            if (eemServList.contains("EEMS"))
              	eemSupervisor = 1; // EEM Supervisor
        	 
          	if (eemServList.contains("EEMA"))
           		eemAppServices = 1; // EEM
           	 
          	if (eemServList.contains("EEUA"))
           		eemAppUpdate = 1; // EEM
        	//original application start
          	 
             if (eemServList.contains("EMAO"))
                		emOrignalApp = 1; // EEM
             
             if (eemServList.contains("EMAV"))
                    	emValidApp = 1; // EEM
            
             
             if (eemServList.contains("EMAB"))
                     emCancelApp = 1; // EEM
        	//original application end
           	
          	if (eemServList.contains("EEMM"))
           		eemMbrServices = 1; // EEM
           	 
          	if (eemServList.contains("EEUM"))
           		eemMbrUpdate = 1; // EEM
           	 
          	if (eemServList.contains("EEMB"))
           		eemBilServices = 1; // EEM
           	 
          	if (eemServList.contains("EEUB"))
           		eemBilUpdate = 1; // EEM
           	 
          	if (eemServList.contains("EEML"))
           		eemLtrServices = 1; // EEM
           	 
          	if (eemServList.contains("EEUL"))
           		eemLtrUpdate = 1; // EEM
           	 
          	if (eemServList.contains("EEMG"))
           		eemSetupServices = 1; // EEM
			
            if (eemServList.contains("EEWF"))
                emWorKFlow = 1;	  //EEM
            
            if (eemServList.contains("EDSB"))
                emDashboard  = 1;	  //EEM
            
            if (eemServList.contains("EMLL"))
                emLepLetter = 1;    //EEM
			
            if (eemServList.contains("EMLU"))
                emLepUpdate = 1; // EEM
           	
          	if (eemServList.contains("EEUG"))
           		eemSetupUpdate = 1; // EEM
           	 
           	if (eemServList.contains("RAX"))
           		raxServices = 1; // Ra Expert
           	 
        	if (eemServList.contains("RAE") || eemServList.contains("RAD") || eemServList.contains("RAU") || eemServList.contains("IF"))
        		retroAdjServices = 1; // Retro Adjustment
        	 
        	if (eemServList.contains("RCC"))
           		rccServices = 1; // RAPS C & C
        	 
           	if (eemServList.contains("R4C"))
           		reinUpdate = 1; // Recon Reinsurance Update
           	 
        	if (eemServList.contains("BOR"))
        		reportingServices = 1; //Business object reporting service
        	 
        	if (eemServList.contains("FTE"))
        		ftEmailAdminServices = 1; //File Transfer Email Admin service
        	 
           	if (eemServList.contains("QCD"))
           		qcdServices = 1; // Qcare Demo
        	 
           	if (eemServList.contains("QLP"))
           		qlpServices = 1; // QAdvantage Letters Production
           	 
           	if (eemServList.contains("QLM"))
           		qlmServices = 1; // QAdvantage Letters Model Office
           	 
           	if (eemServList.contains("QLS"))
           		qlsServices = 1; // QAdvantage Letters Staging
           	 
           	if (eemServList.contains("QLR"))
           		qlrServices = 1; // QAdvantage Letters Regression
           	 
           	if (eemServList.contains("HPE"))
           		hpeServices = 1; 
           	
           	if (eemServList.contains("HPEU"))
               	hpeUpdate = 1; 
            
            if (eemServList.contains("EMDL"))
                    emDenial = 1;
             //TSA- CR- 428408- start
            if (eemServList.contains("EEC"))
            	eemComments = 1;
            if (eemServList.contains("DSIN"))
            	eemDsInfo = 1;
            if (eemServList.contains("MLEP"))
            	eemLEP = 1;
            if (eemServList.contains("LTRU"))
            	eemLTRU = 1;
            if (eemServList.contains("CVC"))
            	eemAPPLCVC = 1;
            if (eemServList.contains("ELTB"))
            	eemLTRDel = 1;
            if (eemServList.contains("EEUT"))
            	eemDDCUT = 1;
            if (eemServList.contains("MLIS"))
            	eemEnrollLIS = 1;
            if (eemServList.contains("MAGT"))
            	eemEnrollAGT = 1;
            if (eemServList.contains("MCOB"))
            	eemEnrollCOB = 1;  
            if (eemServList.contains("EMUD"))
            		eemEnrollButtons = 1;
            if (eemServList.contains("ELRW"))
            	eemLTRReview = 1;
            
            
          //TSA- CR- 428408- End
            
                
            if (eemServList.contains("EESS"))
                        emSecurity = 1;
            
            if (eemServList.contains("OEV"))
            	eemOEV = 1;
            
          //Added for VAP to remove update button
            if (eemServList.contains("EMUT"))
            	eemTimerUpdate = 1;
            
            //Wellcare Eligibility
            if (eemServList.contains("ELID"))
            	eligInd = 1;
            
            
          // ASES CR for TripleS -Start
			 if (eemServList.contains("EEAS"))
				eemAsesServices = 1; // EEM
			// ASES CR for TripleS -End
            
        	/**
        	 * Cambia_Timers-Start
        	 */
        	
            if (eemServList.contains("EEMT"))
               		eemTimers = 1; // EEM
        	/**
        	 * Cambia_Timers-End
        	 */
            	
             if (eemServList.contains("EMAR"))
                  		eemRejectApp = 1; 
             
             if (eemServList.contains("JAS")) // 
            		jasperServices = 1; // Jasper Services
             
             /*E&E360 --start*/
              if (eemServList.contains("ADM1")) // 
                    resq = 1; 
              /*E&E360 --end*/
             
             if (eemServList.contains("EEUP")) //
            		eemMbrPcp = 1; // Ticket 415616
             
          // HCSC Medicaid Recon -start
			 if (eemServList.contains("ILMR"))
				ilMedReconServ = 1; // Medicaid RECON - Illinois
			 if (eemServList.contains("NMMR"))
				nmMedReconServ = 1; // Medicaid RECON - New Mexico
			 if (eemServList.contains("TXMR"))
				txMedReconServ = 1; // Medicaid RECON - Texas
			 if (eemServList.contains("MNMR"))
				mtMedReconServ = 1; // Medicaid RECON - Montana
			 if (eemServList.contains("MRD"))
				discMedicaidReconServ = 1; // Medicaid RECON
			 if (eemServList.contains("MRP"))
				paymentMedicaidReconServ = 1; // Medicaid RECON
			 if (eemServList.contains("MRA"))
				anamolyMedicaidReconServ = 1; // Medicaid RECON

			 if (eemServList.contains("NMD"))
				discMedicaidReconServ = 1; // Medicaid RECON
			 if (eemServList.contains("NMP"))
				paymentMedicaidReconServ = 1; // Medicaid RECON
			 if (eemServList.contains("NMA"))
				anamolyMedicaidReconServ = 1; // Medicaid RECON
			 if (eemServList.contains("TXD"))
				discMedicaidReconServ = 1; // Medicaid RECON
			 if (eemServList.contains("TXP"))
				paymentMedicaidReconServ = 1; // Medicaid RECON
			 if (eemServList.contains("TXA"))
				anamolyMedicaidReconServ = 1; // Medicaid RECON
			 if (eemServList.contains("MND"))
					discMedicaidReconServ = 1; // Medicaid RECON
				 if (eemServList.contains("MNP0"))
					paymentMedicaidReconServ = 1; // Medicaid RECON
				 if (eemServList.contains("MNA"))
					anamolyMedicaidReconServ = 1; // Medicaid RECON
				 if (eemServList.contains("MNRD"))
						discMedicaidReconServ = 1; // Medicaid RECON-Prod
					 if (eemServList.contains("MNPP"))
						paymentMedicaidReconServ = 1; // Medicaid RECON-Prod
					 if (eemServList.contains("MNRA"))
						anamolyMedicaidReconServ = 1; // Medicaid RECON-Prod
			// HCSC Medicaid Recon -end
					//IFOX-00395242 - viewPdf-- start
					 if (eemServList.contains("VPDF"))
						 viewPdf = 1 ;
					//IFOX-00395242 - viewPdf-- end
					//IFOX-00399921 LTC Tab. START
					 if(eemServList.contains("VLTC"))
						 ltcTab = 1;
					//IFOX-00399921 LTC Tab. END
					 
					//IFOX-00426356: Attachment CR Start
					 if(eemServList.contains("ATCH"))
						 atchTab = 1;
					//IFOX-00426356: Attachment CR End
					//
					//IFOX-00417542 SOA_Tab START
					 if(eemServList.contains("SOA"))
						 soaTab = 1;
					//IFOX-00417542 SOA_Tab END
					//IFOX- 421763 Billing User Role : start
					 if(eemServList.contains("DBRD"))
						 dashboard = 1;
					 if(eemServList.contains("BNSF"))
						 billingNSF = 1;
						
					//IFOX- 421763 Billing User Role : end
					//Recon Demo Work Queue Changes : start
					 if(eemServList.contains("WRKQ"))
						 workQueue = 1;
					//Recon Demo Work Queue Changes :end
					 
					//77141 : EDPS Comments tab changes -start
					 if(eemServList.contains("EDMC"))
						 edpsMemberComments =1;
					//77141 : EDPS Comments tab changes -end
					//IFOX - 431927 Global Health Data Masking : start
					 if(eemServList.contains("MASK"))
						 dataMasking =1;
					//IFOX - 431927 Global Health Data Masking : end
					 
        }        
		long endTime1=System.currentTimeMillis();
        logger.debug(" time taken for login and services =="+((endTime1-starttime)));
		//performance fix--end
        // check for QCare / QAdvantage
        String QAC = "";
        if ((qapServices > 0) || (qamServices > 0) || (qasServices > 0) || (qarServices > 0) || (qcdServices > 0)) {
        	CustSvcParmsPersistence cspp = new CustSvcParmsPersistence();
        	QAC = StringUtil.nonNullTrim(cspp.getParmValue(conn,mfId,RptType.QADV,CustSvcParmsValues.QCQA));
        	if (QAC.equals(""))
        		QAC = CustSvcParmsValues.QADVANTAGE;
        }
        
        // the OLP, QAM, QAP, QAS services deterimne if we update the Customer Count
        boolean applyCount = ((olpServices > 0) || (qapServices > 0) || (qamServices > 0) || (qasServices > 0) || (qarServices > 0) || (qcdServices > 0));
        
        SQL = "SELECT SignonMax_cnt, Signon_cnt, Cust_name, Cust_type FROM customer WHERE TRIM(Cust_nbr) = ? FOR UPDATE";
        psCust = conn.prepareStatement(SQL);
        psCust.setString(1,custNbr.trim());
        rsCust = psCust.executeQuery();
             
        if (!rsCust.next()) 
        {
        	conn.setAutoCommit(true);
        	inTrans = false;
        	logger.debug("Error Getting Cust Nbr [" + userId + "]");
        	alp.add(conn,userId,custNbr,Module.LOGIN_SERVLET,Message.CUST_QUERY_ERROR,5);
        	//sso changes - start
        	if(!sso){
        	//Home Page changes-Start
        	response.sendRedirect((String)response.encodeRedirectURL("https://"+BaseUrl+"/mss/home/Index.jsp?sMsg=Unexpected+Response&UId="+URLEncoder.encode(parmUserId)));
        	//Home Page changes-End
        	}else{
        		response.sendRedirect((String) response.encodeRedirectURL("https://"+ BaseUrl+ "/mss/jsp/ErrorJsp.jsp?Msg=An+Unexpected+Response+Has+Occured"));
        	}
        	//sso changes - end
        	logger.info("UserID [" + StringUtil.nonNullTrim(request.getParameter("User_id")) 
    		+ "], MethodName [doPost] :: END");
        	return;        	
        }
        
        int signOnMaxCnt = rsCust.getInt("SignonMax_cnt");
        int signonCnt = rsCust.getInt("Signon_cnt");
        String custType = StringUtil.nonNullTrim(rsCust.getString("Cust_type"));
        String custName = StringUtil.nonNullTrim(rsCust.getString("Cust_name"));       
      //sso changes - start
        if(!sso){
      //sso changes - end
        if (signOnMaxCnt <= 0) {
        	conn.setAutoCommit(true);
        	inTrans = false;
        	logger.debug("Attempeted Login on Disabled Customer Number [" + userId + "]");
        	alp.add(conn,userId,custNbr,Module.LOGIN_SERVLET,Message.DISABLED_CUST_ATTEMPT,8);
        	//Home Page changes-Start
        	response.sendRedirect((String)response.encodeRedirectURL("https://"+BaseUrl+"/mss/home/Index.jsp?sMsg=Customer+Account+Disabled&UId="+URLEncoder.encode(parmUserId)));
        	//Home Page changes-End
        	logger.info("UserID [" + StringUtil.nonNullTrim(request.getParameter("User_id")) 
    		+ "], MethodName [doPost] :: END");
        	return;        	
        }
      //sso changes - start
        }
      //sso changes - end
        if (signedOn.equals("Y")) 
        {
        	mustCommit = true;
        	alp.add(conn,userId,custNbr,Module.LOGIN_SERVLET,Message.SIGNED_ON_LOGIN_ATTEMPT,6);
        	if (sup.logoff(conn,userId) != 1) {
        		logger.debug("Error Updading User Logoff [" + userId + "]");
        		alp.add(conn,userId,custNbr,Module.LOGIN_SERVLET,Message.SIGNOFF_UPDATE_FAILED,4);
        	}
        	alp.add(conn,userId,custNbr,Module.LOGIN_SERVLET,Message.USER_LOGOUT,7);
        	if (applyCount) {
        		if (cp.updateSignOnCnt(conn,custNbr,-1) != 1) {
        			logger.debug("Error Updading Customer Logoff [" + userId + "]");
        			alp.add(conn,userId,custNbr,Module.LOGIN_SERVLET,Message.SIGNOFF_UPDATE_FAILED,4);        		
        		}
        		--signonCnt;
        	}
        }
      //sso changes - start
        if(!sso){
       //sso changes - end
        if (applyCount)
        {
            if (signonCnt >= signOnMaxCnt)
            {
            	if (mustCommit) {
            		conn.commit();
            		mustCommit = false;
					inTrans = false;
            	}
            	conn.setAutoCommit(true);
            	alp.add(conn,custNbr,Integer.toString(signOnMaxCnt),Module.LOGIN_SERVLET,Message.CUST_LOGON_COUNT_EXCEEDED,5);
            	logger.debug("Customer Max Signon Cnt Exceeded " + custNbr + " [" + signOnMaxCnt + "]");
              //Home Page changes-Start
                response.sendRedirect((String)response.encodeRedirectURL("https://"+BaseUrl+"/mss/home/Index.jsp?sMsg=The+Number+Of+Concurrent+Licenses+For+Your+Account+Has+Been+Exceeded<BR>Please+try+again+later&UId="+URLEncoder.encode(parmUserId)));
              //Home Page changes-End
                logger.info("UserID [" + StringUtil.nonNullTrim(request.getParameter("User_id")) 
        		+ "], MethodName [doPost] :: END");
                return;
            }
        }
      //sso changes - start
        }
      //sso changes - end
        // see if the group has any file transfer services
        //performance fix--start
        /*int ftsServices = 0;
        SQL = "SELECT count(*) from secgroup_service, service" +
              " WHERE secgroup_service.Service_id = service.Service_id" +
                " AND Group_id = ? AND Rpt_type IS NOT NULL AND Rpt_ind = '0'";
        ps = conn.prepareStatement(SQL);
        ps.setString(1,groupId);
        rs = ps.executeQuery();
        if (rs.next())
            ftsServices = rs.getInt(1);
        else
            log.println("Unable to determine File Transfer Services");
       
        String temp;
        
        GroupSvcParmsPersistence gsvp = new GroupSvcParmsPersistence(log.getStream());*/
        
        //get the QAdv db
        String qadvDB = null;
        /*temp = ssp.getValue(conn, userId, SecuserSetting.QADVDB);
        if (temp != null)
        	qadvDB = temp;
        else {
        	temp = gsvp.getParmValue(conn, mfId, groupId, "QADV", CustSvcParmsValues.QADVDB);
        	if (temp != null)
        		qadvDB = temp;
        	else {
        		temp = csvp.getParmValue(conn, mfId, "QADV", CustSvcParmsValues.QADVDB);
        		if (temp != null)
        			qadvDB = temp;
        	}
        }
        if (qadvDB == null)*/
        	qadvDB = MssProperties.getDfltDb();

        //get the raps db
        String rapsDB = null;
      /*temp = ssp.getValue(conn, userId, SecuserSetting.RAPSDB);
        if (temp != null)
        	rapsDB = temp;
        else {
        	temp = gsvp.getParmValue(conn, mfId, groupId, "RAPS", CustSvcParmsValues.RAPSDB);
        	if (temp != null)
        		rapsDB = temp;
        	else {
        		temp = csvp.getParmValue(conn, mfId, "RAPS", CustSvcParmsValues.RAPSDB);
        		if (temp != null)
        			rapsDB = temp;
        	}
        }
        if (rapsDB == null)*/
        	rapsDB = MssProperties.getDfltDb();
        
        // get the recon UI db
        String reconUIDB = null;
      /*temp = ssp.getValue(conn, userId, SecuserSetting.RECONDB);
        if (temp != null) {
        	reconUIDB = temp;
        } else {
        	temp = gsvp.getParmValue(conn, mfId, groupId, "RDB", CustSvcParmsValues.RECONDB);
        	if (temp != null)
        		reconUIDB = temp;
        	else {
        		temp = csvp.getParmValue(conn, mfId, "RDB", CustSvcParmsValues.RECONDB);
        		if (temp != null) {
        			reconUIDB = temp;
        		}
        	}
        }
        if (reconUIDB == null)*/
        	reconUIDB = MssProperties.getDfltDb();
        // set for backward compatablity
        String rxReconDB = reconUIDB;
        String reconDB = reconUIDB;

        //get the EEM db
        String eemDB = null;
        /*temp = ssp.getValue(conn, userId, SecuserSetting.EEMDB);
        if (temp != null)
        	eemDB = temp;
        else {
        	temp = gsvp.getParmValue(conn, mfId, groupId, "EEM", CustSvcParmsValues.EEMDB);
        	if (temp != null)
        		eemDB = temp;
        	else {
        		temp = csvp.getParmValue(conn, mfId, "EEM", CustSvcParmsValues.EEMDB);
        		if (temp != null)
        			eemDB = temp;
        	}
        }
        if (eemDB == null)*/
        	eemDB = MssProperties.getDfltDb();

        //get the HPE db
        String hpeDB = null;
        /* temp = ssp.getValue(conn, userId, SecuserSetting.HPEDB);
        if (temp != null)
        	hpeDB = temp;
        else { 
        	temp = gsvp.getParmValue(conn, mfId, groupId, "HPE", CustSvcParmsValues.HPEDB);
        	if (temp != null)
        		hpeDB = temp;
        	else {
        		temp = csvp.getParmValue(conn, mfId, "HPE", CustSvcParmsValues.HPEDB);
        		if (temp != null)
        			hpeDB = temp;
        	}
        }
        if (hpeDB == null)*/
        	hpeDB = MssProperties.getDfltDb();
        
        // see if the user goes to test CICS region
        boolean testCICS = false;
        /*SQL = "SELECT value from secuser_setting WHERE User_id = ? AND Setting_id = ?";
        ps = conn.prepareStatement(SQL);
        ps.setString(1,userId);
        ps.setString(2,"TESTCICS");
        rs = ps.executeQuery();
        if (rs.next())
        {
            if (StringUtil.nonNullTrim(rs.getString("value")).toUpperCase().equals("TRUE"))
                testCICS = true;
        }*/
        //performance fix--end
        // see if the user can use the plugin
        String allowPlugIn = "FORCE";
        //String allowPlugIn;
        //ps.setString(1,userId);
        //ps.setString(2,"AllowPlugIn");
        //rs = ps.executeQuery();
        //if (rs.next())
        //    allowPlugIn = StringUtil.nonNullTrim(rs.getString("value")).toUpperCase();
        //else
        //    allowPlugIn = "FALSE";

        // Get the default Plan ID
        SecPlanPersistence spp = new SecPlanPersistence();
        String planId = StringUtil.nonNullTrim(spp.getDefaultPlan(conn,custNbr));
        if (planId.equals(""))
        	logger.debug("Unable to determine Plan id for " + custNbr);

        // session login
        session  = request.getSession(false);
        if (session != null)
        	session.invalidate();
        session  = request.getSession(true);
        if (session == null)
        {
        	logger.debug("No Session");             
            response.sendRedirect((String)response.encodeRedirectURL("https://"+BaseUrl+"/mss/jsp/ErrorJsp.jsp?Msg=Error+Creating+Session"));
            logger.info("UserID [" + StringUtil.nonNullTrim(request.getParameter("User_id")) 
    		+ "], MethodName [doPost] :: END");
            return;
        }

        String wasSid = session.getId();
       //if (applyCount)
        //   session.setMaxInactiveInterval(43200);
       //Session management  IFOX-00428243 : end 
        session.setMaxInactiveInterval(1800);//setting timeout to 30 minutes
        session.setAttribute("extendCounter", 0);
         //Session management  IFOX-00428243 : end
       String cryptUserPwd = null;
      //sso changes - start
        if(!sso){
        //if (true) {
        	SessionCrypt sCrypt = new SessionCrypt();
        	cryptUserPwd = sCrypt.encrypt(conn,parmUserPwd);
        //	System.out.println("Password =="+cryptUserPwd);
       // }
        }else{
        	SQL = "SELECT USER_PWD FROM SECUSER WHERE USER_ID = ? FOR UPDATE";

			psUsrPwd = conn.prepareStatement(SQL);
			psUsrPwd.setString(1, userId);
			rsUsrPwd = psUsrPwd.executeQuery();
			while (rsUsrPwd.next()) {
				cryptUserPwd = StringUtil.nonNullTrim(rsUsrPwd
						.getString("USER_PWD"));
			}
        }
        
        //IFOX-416305 - Billing Finance Access CR - Start
        
       if(Constants.BILLING_FINANCE_ACCESS_GROUP.equalsIgnoreCase(groupId)){
    	   session.setAttribute("BFAG",Constants.BILLING_FINANCE_ACCESS_GROUP);
       }
        
       //IFOX-416305 - Billing Finance Access CR - End
        
      //sso changes - end
       	/**AAH BasePlus Migration IFOX-00426351 START*/     
        if("Y".equalsIgnoreCase(getProfileParmInd(conn, "",mfId, "LOB_VALD")))
	          session.setAttribute(EEMProfileSettings.LOB_VALD,"Y");
	    else
	          session.setAttribute(EEMProfileSettings.LOB_VALD,"N");
        
        if("Y".equalsIgnoreCase(getProfileParmInd(conn, "",mfId, "LTC_QUES")))
	          session.setAttribute(EEMProfileSettings.LTC_QUES,"Y");
	    else
	          session.setAttribute(EEMProfileSettings.LTC_QUES,"N");
        
        if("Y".equalsIgnoreCase(getProfileParmInd(conn, "",mfId, "NOICD")))
	          session.setAttribute(EEMProfileSettings.NME_INST,"Y");
	           else
	          session.setAttribute(EEMProfileSettings.NME_INST,"N");
        
        if("Y".equalsIgnoreCase(getProfileParmInd(conn, "",mfId, "ENBCMAQUES")))
	          session.setAttribute(EEMProfileSettings.ENABLE_CMA_QUESTIONS,"Y");
	           else
	          session.setAttribute(EEMProfileSettings.ENABLE_CMA_QUESTIONS,"N");
        /**AAH BasePlus Migration IFOX-00426351 END*/
        
        
        
       /* AAH CR-Start -426569 */
        String singonFile	=	EEMProfileSettings.getCalendarProfileItem("", mfId, EEMProfileSettings.VALIDATE_SIGN_AGENT);
        if("Y".equalsIgnoreCase(singonFile))
	          session.setAttribute(EEMProfileSettings.VALIDATE_SIGN_AGENT,"Y");
	    else
	          session.setAttribute(EEMProfileSettings.VALIDATE_SIGN_AGENT,"N");    
        
        if("Y".equalsIgnoreCase(getProfileParmInd(conn, "",mfId, "AUTOAPPLDT")))
	          session.setAttribute(EEMProfileSettings.AUTO_POPULTATE_APPLDT,"Y");
	           else
	          session.setAttribute(EEMProfileSettings.AUTO_POPULTATE_APPLDT,"N");
         /*AAH CR-end -426569*/ 
        
        /**AAH: BasePlus Migration. Letter Description Empty Issue Fix. Start**/
		String ltrDesDispPrfInd = EEMProfileSettings.getCalendarProfileItem("", mfId,
				EEMProfileSettings.LTR_DES_DISP);
		if ("Y".equalsIgnoreCase(ltrDesDispPrfInd))
			session.setAttribute(EEMProfileSettings.LTR_DES_DISP, "Y");
		else
			session.setAttribute(EEMProfileSettings.LTR_DES_DISP, "N");
        
        /**AAH: BasePlus Migration. Letter Description Empty Issue Fix. END**/
        
        //Super User changes - start
        if("Y".equalsIgnoreCase(getProfileParmInd(conn, groupId.trim(),mfId, "SUPUSER")))
        	session.setAttribute(Constants.SUPER_USER,true);
        else
        	session.setAttribute(Constants.SUPER_USER,false);
       //Super User changes - end
        
        //IFOX-00406767 -start
        //if("Y".equalsIgnoreCase(getProfileParmInd(conn, groupId.trim(),mfId, "APPFIELDS")))
        session.setAttribute("Group_id", groupId);//change for detailed logging
        SessionHelper sessionHelper = new SessionHelper(request);
		if("Y".equalsIgnoreCase(EEMProfileSettings.getCalendarProfileItem ((String) sessionHelper.getAttribute(SessionManager.EEMDB), mfId, "APPFIELDS")))
        	session.setAttribute(EEMConstants.APPFIELDS,true);
        else
        	session.setAttribute(EEMConstants.APPFIELDS,false);
    	//IFOX-00406767 -end        
        // Start IFOX-00396423
        String signDateProfileOpt = EEMProfileSettings.getCalendarProfileItem("", mfId, EEMProfileSettings.AGENTDT);
        session.setAttribute(EEMProfileSettings.AGENTDT,signDateProfileOpt);
       // End IFOX-00396423
        
        // IFOX-415141 Billing Enhancements CR - Start
        String multiORG	=	EEMProfileSettings.getCalendarProfileItem("", mfId, EEMProfileSettings.MULTIORG);
        if("Y".equalsIgnoreCase(multiORG))
	          session.setAttribute(EEMProfileSettings.MULTIORG,"Y");
	    else
	          session.setAttribute(EEMProfileSettings.MULTIORG,"N");        
       // IFOX-415141 Billing Enhancements CR - End   
        
        session.setAttribute("recon_cust_nbr",custNbr);        
        session.setAttribute("tid",new Long(tid));
        session.setAttribute("User_id",userId);
        if ((qapServices > 0) || (qamServices > 0) || (qasServices > 0) || (qarServices > 0) || (qcdServices > 0) || (reportingServices > 0))
        	session.setAttribute("User_pwd",cryptUserPwd);
        	//session.setAttribute("User_pwd",parmUserPwd);
        session.setAttribute("Cust_nbr",custNbr);
        session.setAttribute("Cust_type",custType);
        session.setAttribute("Cust_name",custName);
        session.setAttribute("MF_id",mfId);
        session.setAttribute("Plan_id",planId);
      //performance fix--start
        session.setAttribute("OLP",(olpServices > 0) ? "TRUE" : "FALSE");
        /*session.setAttribute("QAP",(qapServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("QAM",(qamServices > 0) ? "TRUE" : "FALSE");        
        session.setAttribute("QAS",(qasServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("QAR",(qarServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("QCD",(qcdServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("QAC",QAC);*/
      //performance fix--end
        session.setAttribute("FTS",(ftsServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("FTEmail",(ftEmailAdminServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("Recon",(reconServices > 0) ? "TRUE" : "FALSE");
     // HCSC Medicare Recon -start
     			session.setAttribute("ILMedicaidRecon",
     					(ilMedReconServ > 0) ? "TRUE" : "FALSE");
     			session.setAttribute("NMMedicaidRecon",
     					(nmMedReconServ > 0) ? "TRUE" : "FALSE");
     			session.setAttribute("TXMedicaidRecon",
     					(txMedReconServ > 0) ? "TRUE" : "FALSE");
     			session.setAttribute("MTMedicaidRecon",
     					(mtMedReconServ > 0) ? "TRUE" : "FALSE");
     			session.setAttribute("MCRecDisc",
     					(discMedicaidReconServ > 0) ? "TRUE" : "FALSE");
     			session.setAttribute("MCRecPay",
     					(paymentMedicaidReconServ > 0) ? "TRUE" : "FALSE");
     			session.setAttribute("MCRecAnom",
     					(anamolyMedicaidReconServ > 0) ? "TRUE" : "FALSE");
     			// HCSC Medicare Recon -end
        session.setAttribute("RxRecon",(rxReconServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("WRO",(wroServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("REIN_UPDATE",(reinUpdate > 0) ? "TRUE" : "FALSE");
        session.setAttribute(SessionManager.RXRECONDB,rxReconDB);
        session.setAttribute(SessionManager.RECONDB,reconDB);
        session.setAttribute(SessionManager.RAPSDB, rapsDB);
        session.setAttribute(SessionManager.RECONUIDB,reconUIDB);
        session.setAttribute(SessionManager.QADVDB,qadvDB);
        session.setAttribute(SessionManager.EEMDB,eemDB);
        session.setAttribute(SessionManager.HPEDB,hpeDB);
        session.setAttribute("Enctr",(enctrServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("RaExpert",(raxServices > 0) ? "TRUE" : "FALSE");        
        session.setAttribute("RetroAdj",(retroAdjServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("HII",(hiiServices > 0) ? "TRUE" : "FALSE");
		//SSNRI Conversion Tab. START
		session.setAttribute("MBIC", (mbicServices > 0) ? "TRUE" : "FALSE");
		//SSNRI Conversion Tab. END
        session.setAttribute("ERS",(ersServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("ERP",(erpServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("RCC",(rccServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute(Constants.SESSION_SERVICE_BOR,(reportingServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("TESTCICS",(testCICS) ? "TRUE" : "FALSE");
        session.setAttribute("AllowPlugIn",allowPlugIn);
        session.setAttribute("screen",screen);
      //sso changes - start
        session.setAttribute("LoginBindingListener",new LoginBindingListener(sc,custNbr,userId,wasSid,tid,applyCount,sso));
      //sso changes - end
        session.setAttribute("QLP",(qlpServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("QLM",(qlmServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("QLS",(qlsServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("QLR",(qlrServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EEM",(eemServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EEMU",(eemUpdate > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EEMS",(eemSupervisor > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EEMA",(eemAppServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EEUA",(eemAppUpdate > 0) ? "TRUE" : "FALSE");
        //original application start
        
        session.setAttribute("EMAO",(emOrignalApp > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EMAV",(emValidApp > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EMAB",(emCancelApp > 0) ? "TRUE" : "FALSE");
        
        //original application end
        
      // ASES CR for TripleS -Start
		session.setAttribute("EEAS", (eemAsesServices > 0) ? "TRUE"
				: "FALSE");
		// ASES CR for TripleS -End

        session.setAttribute("OEV",(eemOEV > 0) ? "TRUE" : "FALSE");
        
        //Added for VAP to remove update button
        session.setAttribute("EMUT",(eemTimerUpdate > 0) ? "TRUE" : "FALSE");
        
        session.setAttribute("ELID",(eligInd > 0) ? "TRUE" : "FALSE");
        
        session.setAttribute("EEMM",(eemMbrServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EEUM",(eemMbrUpdate > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EEML",(eemLtrServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EEUL",(eemLtrUpdate > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EEMB",(eemBilServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EEUB",(eemBilUpdate > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EEMG",(eemSetupServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EEUG",(eemSetupUpdate > 0) ? "TRUE" : "FALSE");
        session.setAttribute("HPE",(hpeServices > 0) ? "TRUE" : "FALSE");
        session.setAttribute("HPEFT", (edpsFileTrackingService > 0) ? "TRUE" : "FALSE");
        session.setAttribute("HPEU",(hpeUpdate > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EMLU",(emLepUpdate > 0) ? "TRUE" : "FALSE");
        //WorkFlow Change
        session.setAttribute("EEWF",(emWorKFlow > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EDSB",(emDashboard > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EMLL",(emLepLetter > 0) ? "TRUE" : "FALSE");  
        
        //TSA- CR- 428408- start
        session.setAttribute("EEC",(eemComments > 0) ? "TRUE" : "FALSE");
        session.setAttribute("DSIN",(eemDsInfo > 0) ? "TRUE" : "FALSE");
        session.setAttribute("MLEP",(eemLEP > 0) ? "TRUE" : "FALSE");
        session.setAttribute("LTRU",(eemLTRU > 0) ? "TRUE" : "FALSE");
        session.setAttribute("CVC",(eemAPPLCVC > 0) ? "TRUE" : "FALSE");
        session.setAttribute("ELTB",(eemLTRDel > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EEUT",(eemDDCUT > 0) ? "TRUE" : "FALSE");
        session.setAttribute("MLIS",(eemEnrollLIS > 0) ? "TRUE" : "FALSE");
        session.setAttribute("MAGT",(eemEnrollAGT > 0) ? "TRUE" : "FALSE");
        session.setAttribute("MCOB",(eemEnrollCOB > 0) ? "TRUE" : "FALSE");
        session.setAttribute("EMUD",(eemEnrollButtons > 0) ? "TRUE" : "FALSE");
        session.setAttribute("ELRW",(eemLTRReview > 0) ? "TRUE" : "FALSE");
      //TSA- CR- 428408- End
        
        
        /**
         * Application Deial_cambia
         */
        session.setAttribute("EMDL",(emDenial > 0) ? "TRUE" : "FALSE");
        
        /**
         * Security roles cambia
         * 
         */
        session.setAttribute("EESS",(emSecurity > 0) ? "TRUE" : "FALSE");
        
        /**
  		 * Cambia_Timers - Start
  		 */
        session.setAttribute("EEMT",(eemTimers > 0)?"TRUE" : "FALSE");	
          /**
  		 * Cambia_Timers - End
  		 */
        /**
         * Cambia_Application Cancellation-Start
         *   
         */
        session.setAttribute("EMAR",(eemRejectApp > 0)?"TRUE" : "FALSE");
      
        /**
         *  Cambia_Application Cancellation-End
         */
        
        /**
         * Jasper Enable for ESI Demo -Start
         *   
         */
        session.setAttribute("JAS",(jasperServices > 0)?"TRUE" : "FALSE");
        

        workflowPendingTask(conn,mfId,session,userId);
       // session.setAttribute("MyAttribute", "test value");
      
        /**
         *  Jasper Enable for ESI Demo - End
         */

        /*E&E360 --start*/
	        session.setAttribute("ADM1",(resq > 0)? "TRUE" : "FALSE");
	        /*E&E360 --end*/
     
        //Ticket 415616
        session.setAttribute("EEUP",(eemMbrPcp > 0) ? "TRUE" : "FALSE");
        //IFOX-00395242 - viewPdf-- start
        session.setAttribute("VPDF", (viewPdf > 0)? "TRUE" : "FALSE");
      //IFOX-00395242 - viewPdf-- end
        
        //IFOX-00426356: Attachment CR
        session.setAttribute(EEMConstants.EEM_ATTACHMENTS, (atchTab > 0) ? "TRUE" : "FALSE");
        //session.setAttribute(EEMConstants.EEM_MBR_TAB_ATTACHMENTS, (atchTab > 0) ? "TRUE" : "FALSE");
        
      //IFOX-00417542 SOA_Tab START
        session.setAttribute(EEMConstants.EEM_SOA, (soaTab > 0)? "TRUE" : "FALSE");
      //IFOX-00417542 SOA_Tab END
      //IFOX-00399921 LTC Tab. START
        session.setAttribute(EEMConstants.EEM_LTC_TAB, (ltcTab > 0)? "TRUE" : "FALSE");
      //IFOX-00399921 LTC Tab. END
        //Recon Demo Work Queue Changes : start
        session.setAttribute("WRKQ", (workQueue > 0)? "TRUE" : "FALSE");
      //Recon Demo Work Queue Changes : end 
      //77141 : EDPS Comments tab changes -start
        session.setAttribute("EDMC", (edpsMemberComments > 0)? "TRUE" : "FALSE");
      //77141 : EDPS Comments tab changes -end
      //sso changes - start
        session.setAttribute("SSO",sso);
      //sso changes - end
      //IFOX- 421763 Billing User Role : start
        session.setAttribute(EEMConstants.DASHBOARD, (dashboard > 0)? "TRUE" : "FALSE");
        session.setAttribute(EEMConstants.BILLING_NSF_ADJUSTMENT, (billingNSF > 0)? "TRUE" : "FALSE");
      //IFOX- 421763 Billing User Role : end
     // EDPS File Tracking flag - start 
     			String fileTrackingFlag = (String) session.getAttribute("HPEFT");
     	        edpsFileTrackingFlag = getEncProfileParmInd(conn, mfId, "FILETRACK", "N");  
     	        // EDPS File Tracking flag - End
     	        
     			if (!fileTrackingFlag.equalsIgnoreCase("TRUE")) {

     				if (edpsFileTrackingFlag) {
     					session.setAttribute("HPEFT", "TRUE");
     					logger.debug("File Tracking service is ENABLED.");
     				} else {
     					session.setAttribute("HPEFT", "FALSE");
     					logger.debug("File Tracking service is not ENABLED. so set flag from ENC_PROFILE table. ");
     				}
     			} else {
     				logger.debug("File Tracking service is enabled. ");
     			}
     			// EDPS File Tracking flag - start 
        
        session.setAttribute("MMP",mStatus); 
        session.setAttribute("UNIQUE", uniqueClaimInd); // IFOX 367728

	      //IFOX - 431927 Global Health Data Masking : start
	        session.setAttribute("MASK", (dataMasking > 0)? "TRUE" : "FALSE");
	      //IFOX - 431927 Global Health Data Masking : end
        int addedFlag = 0;
        synchronized (this) {
            if (!monitor.containsKey(userId))
            {
                monitor.put(userId,session);
                addedFlag = 1;
            }
        }
        if (addedFlag == 0)
        {
        	logger.debug("[" + tid + "] " + userId + " Exists in Hashtable");
        }

        //log.println("Login [" + tid + "] [" + was_sid + "]");

        if (applyCount)
        {
            //Update SIGNON_CNT Fields
    		if (cp.updateSignOnCnt(conn,custNbr,1) != 1) {
    			logger.debug("Error Updading Customer Logoff [" + userId + "]");
    			alp.add(conn,custNbr,userId,Module.LOGIN_SERVLET,Message.SIGNOFF_UPDATE_FAILED,4);        		
    		}
        }

        //Update Last Login Fields
        sup.updateLogin(conn,userId,wasSid);
        String logComment = TextFormatter.rpad(screen,10) + " " + userAgent;
        if (logComment.length() > 255)
        	logComment = logComment.substring(0,255);
        alp.add(conn,userId,custNbr,logComment,Module.LOGIN_SERVLET,Message.USER_LOGIN,8);
        // Debug for Reported Password Issue
        //alp.add(conn,userId,custNbr,parmUserPwd,Module.LOGIN_SERVLET,Message.USER_LOGIN,9);        

        conn.commit();
        mustCommit = false;
        inTrans = false;
        conn.setAutoCommit(true);

        logger.debug("User: " + userId + " wasSID: " + wasSid + " Cust: " + custNbr + " Screen: " + screen + " userAgent: " + userAgent );
      //sso changes - start
        String dataUseAgreed = StringUtil.nonNullTrim(ssp.getValue(conn,userId,SecuserSetting.MBD_DATA_USE));
        if(!sso){
        //sso changes - end
        String Parm = "";
        
        DateUtil du = new DateUtil();
        DateFormatter df = new DateFormatter();
        
        int TodaysDate = du.getTodaysDateAsInt();
        int ExpireDate = Integer.parseInt(df.reFormatDate(pwdExpireDate,DateFormatter.DB2_TIMESTAMP,DateFormatter.YYYYMMDD));
      //sso changes - start
		//String dataUseAgreed = StringUtil.nonNullTrim(ssp.getValue(conn,userId,SecuserSetting.MBD_DATA_USE));
      //sso changes - end
        if (TodaysDate >= ExpireDate)
        {
            Parm = "Required=1";
            if (hintAnswer.equals(""))
            {
                Parm = Parm + "&Hint=1";
            }
            if (hintAnswer2.equals(""))
            {
                Parm = Parm + "&Hint2=1";
            }
            if (hintAnswer3.equals(""))
            {
                Parm = Parm + "&Hint3=1";
            }
        }
        else if (hintAnswer.equals("") | hintAnswer2.equals("") | hintAnswer3.equals(""))
        {
        	Parm = "Required=2";
	        if (hintAnswer.equals(""))
	        {
	            Parm = Parm + "&Hint=1";
	        }
	        if (hintAnswer2.equals(""))
	        {
	            Parm = Parm + "&Hint2=1";
	        }
	        if (hintAnswer3.equals(""))
	        {
	            Parm = Parm + "&Hint3=1";
	        }
        }
        if (Parm.length() > 0)
        {
            if (dataUseAgreed.equals("")) {
		        response.sendRedirect((String)response.encodeRedirectURL("/mss/home/MBDDataUseAgreementJsp.jsp?"+Parm));
		        logger.info("UserID [" + StringUtil.nonNullTrim(request.getParameter("User_id")) 
	    		+ "], MethodName [doPost] :: END");
		        return;                
            }
            response.sendRedirect((String)response.encodeRedirectURL("https://"+BaseUrl+"/mss/home/ChangePasswordJsp.jsp?"+Parm));
            logger.info("UserID [" + StringUtil.nonNullTrim(request.getParameter("User_id")) 
    		+ "], MethodName [doPost] :: END");
            return;
        }
        
        if (debug)
        	logger.debug(tid + " Redirecting");
      //sso changes - start
        }
      //sso changes - end
        if (dataUseAgreed.equals("")) {
	        response.sendRedirect((String)response.encodeRedirectURL("/mss/home/MBDDataUseAgreementJsp.jsp"));
	        logger.info("UserID [" + StringUtil.nonNullTrim(request.getParameter("User_id")) 
    		+ "], MethodName [doPost] :: END");
	        return;                
        }

        response.sendRedirect((String)response.encodeRedirectURL("https://"+BaseUrl+"/mss/jsp/Recon/jsp/index.jsp"));
        logger.info("UserID [" + StringUtil.nonNullTrim(request.getParameter("User_id")) 
		+ "], MethodName [doPost] :: END");
        return;
        
        
    } catch(Exception e){
    	logger.error(e.toString());
    } finally {
    	if (inTrans) {
    		if (mustCommit) {
    			try {
    				conn.commit();
    			} catch(Exception eSQL) {
    				logger.error(eSQL.toString());
    			}    			
    		} else {
    			try {
    				conn.rollback();
    			} catch(Exception eSQL) {
    				logger.error(eSQL.toString());
    			}
    		}
    		try {
    			conn.setAutoCommit(true);
    		} catch(Exception eSQL) {
    			logger.error(eSQL.toString());
    		}
    	}    	
    	try {
    		if (rsCust != null) rsCust.close();
    	} catch(Exception e) {
    		logger.error(e.toString());
    	}
    	try {
    		if (rsUsr != null) rsUsr.close();
    	} catch(Exception e) {
    		logger.error(e.toString());
    	}
    	try {
    		if (rs != null) rs.close();
    	} catch(Exception e) {
    		logger.error(e.toString());
    	}
    	try {
    		if (psCust != null) psCust.close();
    	} catch(Exception e) {
    		logger.error(e.toString());
    	}
    	try {
    		if (psUsr != null) psUsr.close();
    	} catch(Exception e) {
    		logger.error(e.toString());
    	}
    	//performance fix--start
    	/*try {
    		if (psService != null) psService.close();
    	} catch(Exception e) {
    		log.println(e.toString());
    	}*/
    	//performance fix--end
    	try {
    		if (ps != null) ps.close();
    	} catch(Exception e) {
    		logger.error(e.toString());
    	}
    	try {
    		if (conn != null) conn.close();
    	} catch(Exception e) {
    		logger.error(e.toString());
    	}
    }
    
    response.sendRedirect((String)response.encodeRedirectURL("https://"+BaseUrl+"/mss/jsp/ErrorJsp.jsp?Msg=An+Unexpected+Response+Has+Occured"));
}

public void workflowPendingTask(Connection conn, String customerId, HttpSession session, String userId)
		throws ApplicationException, SQLException {
	logger.info("Customer ID [" + customerId+ "], MethodName [workflowPendingTask] :: START");
	int count = 0;
	PreparedStatement ps = null;
	ResultSet rs = null;
	
	try {
		
		String sql = "";
		sql = " SELECT COUNT(DISTINCT A.AGREEMENT_ID) as AGR_COUNT "
				+ "FROM EM_WF_AGREEMENT A, "
				+ "EM_WF_USER_QUEUE Q "
				+ "WHERE A.CUSTOMER_ID = Q.CUSTOMER_ID "
				+ "AND A.AGREEMENT_ID = Q.AGREEMENT_ID "
				+ "AND A.CUSTOMER_ID =? "
				+ "AND A.OVERIDE_IND ='N' "
				+ "AND Q.OVERIDE_IND ='N' "
				+ "AND A.AGREEMENT_STATUS ='OPEN' "
				+ "AND Q.QUEUE_STATUS ='OPEN' "
				+ "AND Q.QUEUE_SUB_STATUS ='OPEN' "
				+ "AND Q.CURRENT_USER_ID =?  ";
		
		ps = conn.prepareStatement(sql);
		ps.setString(1, customerId);
		ps.setString(2, userId);
		rs = ps.executeQuery();
		while(rs.next()){
			count = rs.getInt("AGR_COUNT");
		}
	        
		session.setAttribute("EnrollPending",count);
		
	} finally {
		try {
			if (ps != null)
				ps.close();
		} catch (Exception e) {
			logger.error(" Exception:"+e.getMessage());	
		}
	}
	logger.info("Customer ID [" + customerId+ "], MethodName [workflowPendingTask] :: END");

}



private boolean getEncProfileParmInd(final Connection conn, final String mfId, final String parmCode, final String overrideInd) throws SQLException {
	logger.info("MF ID [" + mfId+ "], MethodName [getEncProfileParmInd] :: START");
    final String ENC_PROFILE_SQL = "SELECT PARM_IND_VALUE FROM ENC_PROFILE WHERE MF_ID = ?  AND PARM_CD = ? AND OVERRIDE_IND = ? ";
    
    String parmIndVal = "";
    PreparedStatement ps = null;
    ResultSet rs = null;
    boolean enableBatchTracking = false;
    
    try
    {
      ps = conn.prepareStatement(ENC_PROFILE_SQL);
      
      ps.setString(1, mfId);
      ps.setString(2, parmCode);
      ps.setString(3, overrideInd);
      
      rs = ps.executeQuery();
      
      if (rs.next()) {
          parmIndVal = StringUtil.nonNullTrim(rs.getString("PARM_IND_VALUE"));
      }
      
      if (parmIndVal != null) {
          if (parmIndVal.equalsIgnoreCase("Y")) {
              enableBatchTracking = true;
          } else if (parmIndVal.equalsIgnoreCase("N")) {
              enableBatchTracking = false;
          }
        }
      
    }
    catch(Exception e){
    	logger.error("Unable to get freqCode flag from ENC_PROFILE table ,"  + e);
    }
    finally
    {
        if (rs != null) {
          rs.close();
      }
  }
    logger.info("MF ID [" + mfId+ "], MethodName [getEncProfileParmInd] :: END");
    return enableBatchTracking;
    
}

//CR IFOX-379535 - Start getting PARM_IND_VALUE value based User Role
	public String getProfileParmInd(Connection conn, String groupID,String customerID, String parmCD) throws SQLException {
		logger.info("Customer ID [" + customerID+ "], MethodName [getProfileParmInd] :: START");
		String paramIndValue = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			String sql = "SELECT PARM_IND_VALUE FROM EM_PROFILE"
					+ " WHERE PARM_TEXT_VALUE = ? AND PARM_CD = ? AND CUSTOMER_ID = ? AND OVERRIDE_IND = 'N'";
			ps = conn.prepareStatement(sql);
			ps.setString(1, groupID);
			ps.setString(2, parmCD);
			ps.setString(3, customerID);
			
			rs = ps.executeQuery();
			if (rs.next()) {
				paramIndValue = StringUtil.nonNullTrim(rs.getString("PARM_IND_VALUE"));
			} else {
				paramIndValue = "";
			}

		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception e) {
			}
			try {
				if (ps != null)
					ps.close();
			} catch (Exception e) {
			}
		}
		logger.info("Customer ID [" + customerID+ "], MethodName [getProfileParmInd] :: END");
		return paramIndValue;
	}
	//CR IFOX-379535 - End getting PARM_IND_VALUE value based User Role


}

