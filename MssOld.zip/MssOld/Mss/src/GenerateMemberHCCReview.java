// $Id: GenerateMemberHCCReview.java,v 1.1 2014/06/26 07:56:02 praveen Exp $

import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ps.mss.db.BeneficiaryPersistence;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.RAMemberHCCReviewVO;
import com.ps.mss.db.view.BeneInfo;
import com.ps.mss.pdf.RAExpertReportPDFUtil;
import com.ps.mss.security.SessionManager;
import com.ps.mss.util.MssProperties;
import com.ps.pdf.PdfTable;
import com.ps.pdf.PdfUtil;

public class GenerateMemberHCCReview extends HttpServlet{
	private static Logger logger=LoggerFactory.getLogger(GenerateMemberHCCReview.class);

	//ModuleLog log = new ModuleLog("GenerateMemberHCCReview");

	RAExpertReportPDFUtil raExpertPDFUtil = new RAExpertReportPDFUtil();

	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException{
		
		
	    String BaseUrl = MssProperties.getWebAppURL();
	    String XferUrl = MssProperties.getFtpAppURL();
	    	
	    Connection conn = null;       
	    String User_name = null; 
		String planId = request.getParameter("planId"); 
		String hicNumber = request.getParameter("hicNbr"); 
		int paymentYear = Integer.parseInt(request.getParameter("paymentYear"));

		ArrayList hccModdList = null;
		ArrayList rapsList = null;
		ArrayList rapsHCCList = null;
		ArrayList baselineList = null;
		ArrayList outstandingDGList = new ArrayList();

		String totalCurrentFactor = "";
		String riskScoreValue = "";		
	    
		String prevYear = String.valueOf(paymentYear - 1);
		String thisYear = String.valueOf(paymentYear);
		
		try{

	        conn = DbConn.getConnection();

		    HttpSession session = SessionManager.getSession(request, conn);
		    if (session == null)
		    {
		        logger.error("No Session");
		        response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/RAExpertPDFLoadError.jsp"));
		        return;
		    }
		    String User_id = (String)session.getAttribute("User_id");
		    if (User_id == null)
		    {
		       logger.error("No User_id");
		       response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/RAExpertPDFLoadError.jsp"));
		       return;
		    }
			
			String reconDb = (String) session.getAttribute("ReconDB");
			conn = DbConn.reGetConnection(conn,reconDb);
			
			BeneficiaryPersistence beneficiaryPersistence = new BeneficiaryPersistence();
			BeneInfo beneInfo = beneficiaryPersistence.getBeneInfo(conn, planId, hicNumber);

			if ( beneInfo.isClaimValid()){
		        User_name =  beneInfo.getLastName() + " " + beneInfo.getFirstName();
	        }else{
	        	User_name = "Hic Number is not valid.";
	        }
		
			RAMemberHCCReviewVO raMemberHccReviewVO = (RAMemberHCCReviewVO) request.getAttribute("RAReportVO");
			
		    // Fetch the HCC MODD 
		    hccModdList = raMemberHccReviewVO.getHccModdList();

			// Fetch the RADiseaseGroup Data
			// RAPS DATA
			rapsList = raMemberHccReviewVO.getRapsList();

			// RAPSHCC DATA
			rapsHCCList = raMemberHccReviewVO.getRapsHCCList();

			// BASELINE DATA
			baselineList = raMemberHccReviewVO.getBaselineList();

			// Fetch the outstanding / Non-submitted Disease Group list
			outstandingDGList = raMemberHccReviewVO.getOutstandingDGList();
			
			totalCurrentFactor = raMemberHccReviewVO.getTotalCurrentFactor();
			
			riskScoreValue = raMemberHccReviewVO.getRiskScoreValue();
			
			
			PdfUtil pdfUtil = new PdfUtil("");
			pdfUtil.setLayout(PdfUtil.LANDSCAPE);
			pdfUtil.setLeftMargin(40);
			pdfUtil.setTopMargin(20);
			pdfUtil.enableSilentPrint(true);
			pdfUtil.createPDF(response.getOutputStream());
	
			int rowIndex = 0;
	
			// Member Detail Table
			PdfTable memberDetailTable = new PdfTable(4);
			memberDetailTable.setFont(RAExpertReportPDFUtil.normalTextFont);
			memberDetailTable.setBorder(0);
			float[] memberDetailColWidths = {10f,40f,15f,35f};
			memberDetailTable.setColumnWidths(memberDetailColWidths);
	
	
			rowIndex = memberDetailTable.addRow();
			memberDetailTable.setText(rowIndex, 1, "Plan ID :");
			memberDetailTable.setFont(rowIndex, 1, RAExpertReportPDFUtil.title1BoldFont);
			memberDetailTable.setText(rowIndex, 2, planId);
			memberDetailTable.setFont(rowIndex, 2, RAExpertReportPDFUtil.title1NormalFont);
	
			rowIndex = memberDetailTable.addRow();
			memberDetailTable.setText(rowIndex, 1, "Hic Nbr :");
			memberDetailTable.setFont(rowIndex, 1, RAExpertReportPDFUtil.title1BoldFont);
			memberDetailTable.setText(rowIndex, 2, hicNumber);
			memberDetailTable.setFont(rowIndex, 2, RAExpertReportPDFUtil.title1NormalFont);
	
			memberDetailTable.setText(rowIndex, 3, "Member Name : ");
			memberDetailTable.setFont(rowIndex, 3, RAExpertReportPDFUtil.title1BoldFont);
			memberDetailTable.setText(rowIndex, 4, User_name);
			memberDetailTable.setFont(rowIndex, 4, RAExpertReportPDFUtil.title1NormalFont);
	
	
			// NESTED TABLE
	
			PdfTable pdfTable1 = new PdfTable(87);
			pdfTable1.setBorder(0);
			pdfTable1.setFont(RAExpertReportPDFUtil.normalTextFont);
	
			//float[] columnWidths = {7,4,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,6,6,8};
			float[] columnWidths = {7,4,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,12,.7f,8};
			pdfTable1.setColumnWidths(columnWidths);
	
			
			// Define the DISEASE GROUP Table
			raExpertPDFUtil.printDiseaseGroupHeader( pdfTable1);
				
			raExpertPDFUtil.printAllHccModdValues( pdfTable1, hccModdList);			
			raExpertPDFUtil.printDiseaseGroupValues( pdfTable1, rapsList);
			raExpertPDFUtil.printDiseaseGroupValues( pdfTable1, rapsHCCList);
			raExpertPDFUtil.printDiseaseGroupValues( pdfTable1, baselineList);
			
			raExpertPDFUtil.printDiseaseGroupFooter( pdfTable1);
	
			// Define the numbers table
	
			PdfTable outstandingTable = new PdfTable(7);
			outstandingTable.setWidthPercentage(100);
			outstandingTable.setBorder(0);
			outstandingTable.setFont(RAExpertReportPDFUtil.normalTextFont);
			outstandingTable.setAlignment(PdfTable.LEFT);
			float[] outstandingTableWidths = {10,1,10,1,65,1,10};
			outstandingTable.setColumnWidths(outstandingTableWidths);
			
			raExpertPDFUtil.printOutstandingHCCHeader(outstandingTable);
			
			raExpertPDFUtil.printOutstandingHcc(outstandingTable, outstandingDGList, true);
	
			//rowIndex = outstandingTable.addRow();		// New Row
			//outstandingTable.setColSpan(rowIndex, 1, 6);
			//outstandingTable.setFont(rowIndex, RAExpertReportPDFUtil.boldTextFont);
			//outstandingTable.setText(rowIndex, 1, "Less  current lower hierarchy");
			//outstandingTable.setText(rowIndex, 7, totalCurrentFactor);
	
			//rowIndex = outstandingTable.addRow();		// New Row
			//outstandingTable.setColSpan(rowIndex, 1, 6);
			//outstandingTable.setFont(rowIndex, RAExpertReportPDFUtil.boldTextFont);
			//outstandingTable.setText(rowIndex, 1, "Total outstanding risk score value");
			//outstandingTable.setText(rowIndex, 7, riskScoreValue);
	
			// MAIN TABLE
	
			PdfTable pdfTable = new PdfTable(1);
			pdfTable.setWidthPercentage(100);
			pdfTable.setBorder(0);
			pdfTable.setAlignment(PdfTable.CENTER);
			pdfTable.setFont(RAExpertReportPDFUtil.pageHeadingFont);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "RA-Expert ");
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "Part C HCC Analysis  ");
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "Member HCC Review for Payment Year " + thisYear);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "Data Collection Dates 01/01/" + prevYear + " thru 12/31/" + prevYear);
	
			rowIndex = pdfTable.addSpacerLine(12);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, memberDetailTable);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, pdfTable1);
	
			rowIndex = pdfTable.addSpacerLine(12);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, outstandingTable);
	
			pdfUtil.addTable(pdfTable);
	
			pdfUtil.close();
	
		}catch(Exception ex){
			logger.error("GenerateMemberHCCReview : service : Caught Exception " + ex);
			throw new ServletException(ex);
		} finally {
			try {
				if (conn != null) conn.close();
			} catch(Exception e) {
				logger.error(e.getMessage());
			}
		}
	}
}