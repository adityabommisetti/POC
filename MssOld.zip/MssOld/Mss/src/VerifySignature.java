/*
* Copyright (c) 2015 by wipro.com. All rights reserved.
*
* Oct 14, 2015
* 
* @author Aditya
*
*
*/

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateNotYetValidException;
import java.security.cert.X509Certificate;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.apache.log4j.Logger;
import org.apache.xml.security.keys.KeyInfo;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.utils.Constants;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.ps.mss.util.MssProperties;
import com.wipro.security.saml.LogHandler;


/**
 * The Class VerifySignature.
 *
 * @author Aditya
 */
public class VerifySignature {

	/** The Constant LOGHANDLER. */
	private static final LogHandler LOGHANDLER = new LogHandler();

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LOGHANDLER
			.getLogger(VerifySignature.class);
	/** The Constant X509Certificate. */
	public static final String X509Certificate="ds:X509Certificate";
    static {
        org.apache.xml.security.Init.init();
    }
    
	/**
	 * Verify xml signature.
	 *
	 * @param xmlInputStream the xml input stream
	 * @param schemaValidate the schema validate
	 * @return true, if successful
	 * @throws IOException 
	 */
	public boolean verifyXMLSignature(HttpServletRequest request, HttpServletResponse response,InputStream xmlInputStream, boolean schemaValidate) throws IOException{

		LOGHANDLER.methodStartLog("verifyXMLSignature()-", LOGGER);
		boolean validCertificate=false;
		String BaseUrl = MssProperties.getWebAppURL();

		final String signatureSchemaFile = "xmldsig-core-schema.xsd";
		if (schemaValidate) {
			LOGGER.debug("We do schema-validation");
		}

		javax.xml.parsers.DocumentBuilderFactory dbf =
				javax.xml.parsers.DocumentBuilderFactory.newInstance();

		if (schemaValidate) {
			dbf.setAttribute("http://apache.org/xml/features/validation/schema",
					Boolean.TRUE);
			dbf.setAttribute("http://apache.org/xml/features/dom/defer-node-expansion",
					Boolean.TRUE);
			dbf.setValidating(true);
			dbf.setAttribute("http://xml.org/sax/features/validation",
					Boolean.TRUE);
		}

		dbf.setNamespaceAware(true);
		dbf.setAttribute("http://xml.org/sax/features/namespaces", Boolean.TRUE);

		if (schemaValidate) {
			dbf.setAttribute("http://apache.org/xml/properties/schema/external-schemaLocation",
					Constants.SignatureSpecNS + " " + signatureSchemaFile);
		}
		try {

			javax.xml.parsers.DocumentBuilder db = dbf.newDocumentBuilder();

			db.setErrorHandler(new org.apache.xml.security.utils.IgnoreAllErrorHandler());

			if (schemaValidate) {
				db.setEntityResolver(new org.xml.sax.EntityResolver() {

					public org.xml.sax.InputSource resolveEntity(
							String publicId, String systemId
							) throws org.xml.sax.SAXException {

						if (systemId.endsWith("xmldsig-core-schema.xsd")) {
							try {
								return new org.xml.sax.InputSource(
										new FileInputStream(signatureSchemaFile));
							} catch (FileNotFoundException ex) {
								throw new org.xml.sax.SAXException(ex);
							}
						} else {
							return null;
						}
					}
				});
			}

			Document doc = db.parse(xmlInputStream);

			XPathFactory xpf = XPathFactory.newInstance();
			XPath xpath = xpf.newXPath();
			xpath.setNamespaceContext(new DSNamespaceContext());

			String expression = "//ds:Signature[1]";

			Element sigElement =
					(Element) xpath.evaluate(expression, doc, XPathConstants.NODE);
			XMLSignature signature =
					new XMLSignature(sigElement, "");

			signature.addResourceResolver(new OfflineResolver());

			KeyInfo ki = signature.getKeyInfo();

			if (ki != null) {
				if (ki.containsX509Data()) {
					LOGGER.info("Digital Certificate Verification Could find a X509Data element in the KeyInfo");
				}

				X509Certificate cert = signature.getKeyInfo().getX509Certificate();
				PublicKey publicKey = signature.getKeyInfo().getPublicKey();
				LOGGER.info("Certificate: "+cert);
				if (cert != null && publicKey != null) {
					
					cert.checkValidity();//checks validity of the certificate
					cert.verify(publicKey);//checks private key corresponds to public key of the certificate
					DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
					DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
					Document custMetaData = dBuilder.parse(getClass().getClassLoader().getResourceAsStream("mss/resources/GoogleIDPMetadata-devoted.com.xml"));
					String custCert = custMetaData.getElementsByTagName(X509Certificate).item(0).getTextContent();
					String samlCert = doc.getElementsByTagName(X509Certificate).item(0).getTextContent();
					//verifies configured certificate with the certificate available in the request
					if(custCert.equals(samlCert)){
						validCertificate = true;
					}
					LOGGER.info("Certificate Validation : "+validCertificate);
				}
			} else {
				LOGGER.error("Digital Certificate Validation Failed becuase there is no KeyInfo in SAML Response");
			}
		}catch (CertificateExpiredException CertExpire) {
			LOGGER.error(CertExpire.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=Certificate Expired"));
			return false;
		}catch (CertificateNotYetValidException CertNotValid) {
			LOGGER.error(CertNotValid.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=Certificate Not Yet Valid"));
			return false;
		}catch (CertificateException CE) {
			LOGGER.error(CE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}catch (SignatureException  SE) {
			LOGGER.error(SE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}catch (NoSuchProviderException	  SE) {
			LOGGER.error(SE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}catch (InvalidKeyException  SE) {
			LOGGER.error(SE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}catch (NoSuchAlgorithmException  SE) {
			LOGGER.error(SE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}
		
		catch (Exception ex) {
			LOGGER.error(ex.getMessage());
		}

		return validCertificate;
	}

	//IFOX-416769 BCBSAZ SSO CR - Start
    
	/**
	 * Verify OKTA xml signature for BCBSAZ customer SAML request
	 *
	 * @param xmlInputStream the xml input stream
	 * @param schemaValidate the schema validate
	 * @return true, if successful
	 * @throws IOException 
	 */
	public boolean verifyXMLSignatureForOKTA(HttpServletRequest request, HttpServletResponse response,InputStream xmlInputStream, boolean schemaValidate) throws IOException{

		LOGHANDLER.methodStartLog("verifyXMLSignature()-", LOGGER);
		boolean validCertificate=false;
		String BaseUrl = MssProperties.getWebAppURL();

		final String signatureSchemaFile = "xmldsig-core-schema.xsd";
		if (schemaValidate) {
			LOGGER.debug("We do schema-validation");
		}

		javax.xml.parsers.DocumentBuilderFactory dbf =
				javax.xml.parsers.DocumentBuilderFactory.newInstance();

		if (schemaValidate) {
			dbf.setAttribute("http://apache.org/xml/features/validation/schema",
					Boolean.TRUE);
			dbf.setAttribute("http://apache.org/xml/features/dom/defer-node-expansion",
					Boolean.TRUE);
			dbf.setValidating(true);
			dbf.setAttribute("http://xml.org/sax/features/validation",
					Boolean.TRUE);
		}

		dbf.setNamespaceAware(true);
		dbf.setAttribute("http://xml.org/sax/features/namespaces", Boolean.TRUE);

		if (schemaValidate) {
			dbf.setAttribute("http://apache.org/xml/properties/schema/external-schemaLocation",
					Constants.SignatureSpecNS + " " + signatureSchemaFile);
		}
		try {

			javax.xml.parsers.DocumentBuilder db = dbf.newDocumentBuilder();

			db.setErrorHandler(new org.apache.xml.security.utils.IgnoreAllErrorHandler());

			if (schemaValidate) {
				db.setEntityResolver(new org.xml.sax.EntityResolver() {

					public org.xml.sax.InputSource resolveEntity(
							String publicId, String systemId
							) throws org.xml.sax.SAXException {

						if (systemId.endsWith("xmldsig-core-schema.xsd")) {
							try {
								return new org.xml.sax.InputSource(
										new FileInputStream(signatureSchemaFile));
							} catch (FileNotFoundException ex) {
								throw new org.xml.sax.SAXException(ex);
							}
						} else {
							return null;
						}
					}
				});
			}

			Document doc = db.parse(xmlInputStream);

			XPathFactory xpf = XPathFactory.newInstance();
			XPath xpath = xpf.newXPath();
			xpath.setNamespaceContext(new DSNamespaceContext());

			String expression = "//ds:Signature[1]";

			Element sigElement =
					(Element) xpath.evaluate(expression, doc, XPathConstants.NODE);
			XMLSignature signature =
					new XMLSignature(sigElement, "");

			signature.addResourceResolver(new OfflineResolver());

			KeyInfo ki = signature.getKeyInfo();

			if (ki != null) {
				if (ki.containsX509Data()) {
					LOGGER.info("Digital Certificate Verification Could find a X509Data element in the KeyInfo");
				}

				X509Certificate cert = signature.getKeyInfo().getX509Certificate();
				PublicKey publicKey = signature.getKeyInfo().getPublicKey();
				LOGGER.info("Certificate: "+cert);
				if (cert != null && publicKey != null) {
					
					cert.checkValidity();//checks validity of the certificate
					cert.verify(publicKey);//checks private key corresponds to public key of the certificate
					DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
					DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
					Document custMetaData = dBuilder.parse(getClass().getClassLoader().getResourceAsStream("mss/resources/OKTAIDPMetadata-BCBSAZ.com.xml"));
					String custCert = custMetaData.getElementsByTagName(X509Certificate).item(0).getTextContent();
					String samlCert = doc.getElementsByTagName(X509Certificate).item(0).getTextContent();
					//verifies configured certificate with the certificate available in the request
					if(custCert.equals(samlCert)){
						validCertificate = true;
					}
					LOGGER.info("Certificate Validation : "+validCertificate);
				}
			} else {
				LOGGER.error("Digital Certificate Validation Failed becuase there is no KeyInfo in SAML Response");
			}
		}catch (CertificateExpiredException CertExpire) {
			LOGGER.error(CertExpire.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=Certificate Expired"));
			return false;
		}catch (CertificateNotYetValidException CertNotValid) {
			LOGGER.error(CertNotValid.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=Certificate Not Yet Valid"));
			return false;
		}catch (CertificateException CE) {
			LOGGER.error(CE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}catch (SignatureException  SE) {
			LOGGER.error(SE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}catch (NoSuchProviderException	  SE) {
			LOGGER.error(SE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}catch (InvalidKeyException  SE) {
			LOGGER.error(SE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}catch (NoSuchAlgorithmException  SE) {
			LOGGER.error(SE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}
		
		catch (Exception ex) {
			LOGGER.error(ex.getMessage());
		}

		return validCertificate;
	}
	
	public boolean verifyXMLSignatureForOKTATrain(HttpServletRequest request, HttpServletResponse response,InputStream xmlInputStream, boolean schemaValidate) throws IOException{

		LOGHANDLER.methodStartLog("verifyXMLSignature()-", LOGGER);
		boolean validCertificate=false;
		String BaseUrl = MssProperties.getWebAppURL();

		final String signatureSchemaFile = "xmldsig-core-schema.xsd";
		if (schemaValidate) {
			LOGGER.debug("We do schema-validation");
		}

		javax.xml.parsers.DocumentBuilderFactory dbf =
				javax.xml.parsers.DocumentBuilderFactory.newInstance();

		if (schemaValidate) {
			dbf.setAttribute("http://apache.org/xml/features/validation/schema",
					Boolean.TRUE);
			dbf.setAttribute("http://apache.org/xml/features/dom/defer-node-expansion",
					Boolean.TRUE);
			dbf.setValidating(true);
			dbf.setAttribute("http://xml.org/sax/features/validation",
					Boolean.TRUE);
		}

		dbf.setNamespaceAware(true);
		dbf.setAttribute("http://xml.org/sax/features/namespaces", Boolean.TRUE);

		if (schemaValidate) {
			dbf.setAttribute("http://apache.org/xml/properties/schema/external-schemaLocation",
					Constants.SignatureSpecNS + " " + signatureSchemaFile);
		}
		try {

			javax.xml.parsers.DocumentBuilder db = dbf.newDocumentBuilder();

			db.setErrorHandler(new org.apache.xml.security.utils.IgnoreAllErrorHandler());

			if (schemaValidate) {
				db.setEntityResolver(new org.xml.sax.EntityResolver() {

					public org.xml.sax.InputSource resolveEntity(
							String publicId, String systemId
							) throws org.xml.sax.SAXException {

						if (systemId.endsWith("xmldsig-core-schema.xsd")) {
							try {
								return new org.xml.sax.InputSource(
										new FileInputStream(signatureSchemaFile));
							} catch (FileNotFoundException ex) {
								throw new org.xml.sax.SAXException(ex);
							}
						} else {
							return null;
						}
					}
				});
			}

			Document doc = db.parse(xmlInputStream);

			XPathFactory xpf = XPathFactory.newInstance();
			XPath xpath = xpf.newXPath();
			xpath.setNamespaceContext(new DSNamespaceContext());

			String expression = "//ds:Signature[1]";

			Element sigElement =
					(Element) xpath.evaluate(expression, doc, XPathConstants.NODE);
			XMLSignature signature =
					new XMLSignature(sigElement, "");

			signature.addResourceResolver(new OfflineResolver());

			KeyInfo ki = signature.getKeyInfo();

			if (ki != null) {
				if (ki.containsX509Data()) {
					LOGGER.info("Digital Certificate Verification Could find a X509Data element in the KeyInfo");
				}

				X509Certificate cert = signature.getKeyInfo().getX509Certificate();
				PublicKey publicKey = signature.getKeyInfo().getPublicKey();
				LOGGER.info("Certificate: "+cert);
				if (cert != null && publicKey != null) {
					
					cert.checkValidity();//checks validity of the certificate
					cert.verify(publicKey);//checks private key corresponds to public key of the certificate
					DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
					DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
					Document custMetaData = dBuilder.parse(getClass().getClassLoader().getResourceAsStream("mss/resources/OKTAIDPMetadata-BCBSAZTR.com.xml"));
					String custCert = custMetaData.getElementsByTagName(X509Certificate).item(0).getTextContent();
					String samlCert = doc.getElementsByTagName(X509Certificate).item(0).getTextContent();
					//verifies configured certificate with the certificate available in the request
					if(custCert.equals(samlCert)){
						validCertificate = true;
					}
					LOGGER.info("Certificate Validation : "+validCertificate);
				}
			} else {
				LOGGER.error("Digital Certificate Validation Failed becuase there is no KeyInfo in SAML Response");
			}
		}catch (CertificateExpiredException CertExpire) {
			LOGGER.error(CertExpire.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=Certificate Expired"));
			return false;
		}catch (CertificateNotYetValidException CertNotValid) {
			LOGGER.error(CertNotValid.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=Certificate Not Yet Valid"));
			return false;
		}catch (CertificateException CE) {
			LOGGER.error(CE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}catch (SignatureException  SE) {
			LOGGER.error(SE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}catch (NoSuchProviderException	  SE) {
			LOGGER.error(SE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}catch (InvalidKeyException  SE) {
			LOGGER.error(SE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}catch (NoSuchAlgorithmException  SE) {
			LOGGER.error(SE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}
		
		catch (Exception ex) {
			LOGGER.error(ex.getMessage());
		}

		return validCertificate;
	}
	
	public boolean verifyXMLSignatureForOKTAProd(HttpServletRequest request, HttpServletResponse response,InputStream xmlInputStream, boolean schemaValidate) throws IOException{

		LOGHANDLER.methodStartLog("verifyXMLSignature()-", LOGGER);
		boolean validCertificate=false;
		String BaseUrl = MssProperties.getWebAppURL();

		final String signatureSchemaFile = "xmldsig-core-schema.xsd";
		if (schemaValidate) {
			LOGGER.debug("We do schema-validation");
		}

		javax.xml.parsers.DocumentBuilderFactory dbf =
				javax.xml.parsers.DocumentBuilderFactory.newInstance();

		if (schemaValidate) {
			dbf.setAttribute("http://apache.org/xml/features/validation/schema",
					Boolean.TRUE);
			dbf.setAttribute("http://apache.org/xml/features/dom/defer-node-expansion",
					Boolean.TRUE);
			dbf.setValidating(true);
			dbf.setAttribute("http://xml.org/sax/features/validation",
					Boolean.TRUE);
		}

		dbf.setNamespaceAware(true);
		dbf.setAttribute("http://xml.org/sax/features/namespaces", Boolean.TRUE);

		if (schemaValidate) {
			dbf.setAttribute("http://apache.org/xml/properties/schema/external-schemaLocation",
					Constants.SignatureSpecNS + " " + signatureSchemaFile);
		}
		try {

			javax.xml.parsers.DocumentBuilder db = dbf.newDocumentBuilder();

			db.setErrorHandler(new org.apache.xml.security.utils.IgnoreAllErrorHandler());

			if (schemaValidate) {
				db.setEntityResolver(new org.xml.sax.EntityResolver() {

					public org.xml.sax.InputSource resolveEntity(
							String publicId, String systemId
							) throws org.xml.sax.SAXException {

						if (systemId.endsWith("xmldsig-core-schema.xsd")) {
							try {
								return new org.xml.sax.InputSource(
										new FileInputStream(signatureSchemaFile));
							} catch (FileNotFoundException ex) {
								throw new org.xml.sax.SAXException(ex);
							}
						} else {
							return null;
						}
					}
				});
			}

			Document doc = db.parse(xmlInputStream);

			XPathFactory xpf = XPathFactory.newInstance();
			XPath xpath = xpf.newXPath();
			xpath.setNamespaceContext(new DSNamespaceContext());

			String expression = "//ds:Signature[1]";

			Element sigElement =
					(Element) xpath.evaluate(expression, doc, XPathConstants.NODE);
			XMLSignature signature =
					new XMLSignature(sigElement, "");

			signature.addResourceResolver(new OfflineResolver());

			KeyInfo ki = signature.getKeyInfo();

			if (ki != null) {
				if (ki.containsX509Data()) {
					LOGGER.info("Digital Certificate Verification Could find a X509Data element in the KeyInfo");
				}

				X509Certificate cert = signature.getKeyInfo().getX509Certificate();
				PublicKey publicKey = signature.getKeyInfo().getPublicKey();
				LOGGER.info("Certificate: "+cert);
				if (cert != null && publicKey != null) {
					
					cert.checkValidity();//checks validity of the certificate
					cert.verify(publicKey);//checks private key corresponds to public key of the certificate
					DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
					DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
					Document custMetaData = dBuilder.parse(getClass().getClassLoader().getResourceAsStream("mss/resources/OKTAIDPMetadata-BCBSAZPR.com.xml"));
					String custCert = custMetaData.getElementsByTagName(X509Certificate).item(0).getTextContent();
					String samlCert = doc.getElementsByTagName(X509Certificate).item(0).getTextContent();
					//verifies configured certificate with the certificate available in the request
					if(custCert.equals(samlCert)){
						validCertificate = true;
					}
					LOGGER.info("Certificate Validation : "+validCertificate);
				}
			} else {
				LOGGER.error("Digital Certificate Validation Failed becuase there is no KeyInfo in SAML Response");
			}
		}catch (CertificateExpiredException CertExpire) {
			LOGGER.error(CertExpire.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=Certificate Expired"));
			return false;
		}catch (CertificateNotYetValidException CertNotValid) {
			LOGGER.error(CertNotValid.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=Certificate Not Yet Valid"));
			return false;
		}catch (CertificateException CE) {
			LOGGER.error(CE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}catch (SignatureException  SE) {
			LOGGER.error(SE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}catch (NoSuchProviderException	  SE) {
			LOGGER.error(SE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}catch (InvalidKeyException  SE) {
			LOGGER.error(SE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}catch (NoSuchAlgorithmException  SE) {
			LOGGER.error(SE.getMessage());
			response.sendRedirect((String) response
					.encodeRedirectURL("https://"
							+ BaseUrl
							+ "/mss/jsp/ErrorJsp.jsp?Msg=The certificate was not signed using Private Key that corresponds to the specified Public Key"));
			return false;
		}
		
		catch (Exception ex) {
			LOGGER.error(ex.getMessage());
		}

		return validCertificate;
	}

	//IFOX-416769 BCBSAZ SSO CR - End
}