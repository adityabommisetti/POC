
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import javax.servlet.http.HttpServlet;
import org.slf4j.LoggerFactory;

import com.ps.pdf.PdfFontUtil;
import com.ps.pdf.PdfTable;
import com.ps.pdf.PdfUtil;

import java.awt.Color;

public class GeneratePDMemberFinProReview extends HttpServlet{
	private static Logger logger=LoggerFactory.getLogger(GeneratePDMemberFinProReview.class);
	public void service(HttpServletRequest request, HttpServletResponse response){
		
		try{

			response.setContentType("application/pdf");
			
			PdfUtil pdfUtil = new PdfUtil("");
			pdfUtil.setLayout(PdfUtil.LANDSCAPE);
			pdfUtil.setLeftMargin(40);
			pdfUtil.setTopMargin(20);
			pdfUtil.enableSilentPrint(true);
			pdfUtil.createPDF(response.getOutputStream());
	
			String pageHeadingFont = PdfFontUtil.defineFont("PAGE_HEADING_FONT", PdfFontUtil.COURIER, 11, PdfFontUtil.BOLD_FONT);
			String title1NormalFont = PdfFontUtil.defineFont("TITLE_NORMAL_FONT", PdfFontUtil.COURIER, 11, PdfFontUtil.NORMAL_FONT);
			String title1BoldFont = PdfFontUtil.defineFont("TITLE_BOLD_FONT", PdfFontUtil.COURIER, 11, PdfFontUtil.BOLD_FONT);
			String normalTextFont = PdfFontUtil.defineFont("NORMAL_TEXT_FONT", PdfFontUtil.COURIER, 9, PdfFontUtil.NORMAL_FONT);
			String boldTextFont = PdfFontUtil.defineFont("BOLD_TEXT_FONT", PdfFontUtil.COURIER, 9, PdfFontUtil.BOLD_FONT);
	
			int rowIndex = 0;
	
			// Member Detail Table
			PdfTable memberDetailTable = new PdfTable(4);
			memberDetailTable.setFont(normalTextFont);
			memberDetailTable.setBorder(0);
			float[] memberDetailColWidths = {10f,40f,15f,35f};
			memberDetailTable.setColumnWidths(memberDetailColWidths);
	
	
			rowIndex = memberDetailTable.addRow();
			memberDetailTable.setText(rowIndex, 1, "Plan ID :");
			memberDetailTable.setFont(rowIndex, 1, title1BoldFont);
			memberDetailTable.setText(rowIndex, 2, "H9998");
			memberDetailTable.setFont(rowIndex, 2, title1NormalFont);
	
			rowIndex = memberDetailTable.addRow();
			memberDetailTable.setText(rowIndex, 1, "Hic Nbr :");
			memberDetailTable.setFont(rowIndex, 1, title1BoldFont);
			memberDetailTable.setText(rowIndex, 2, "WE0011175D");
			memberDetailTable.setFont(rowIndex, 2, title1NormalFont);
	
			memberDetailTable.setText(rowIndex, 3, "Member Name : ");
			memberDetailTable.setFont(rowIndex, 3, title1BoldFont);
			memberDetailTable.setText(rowIndex, 4, "MONACO, HERBERT");
			memberDetailTable.setFont(rowIndex, 4, title1NormalFont);
	
	
			// NESTED TABLE
	
			PdfTable pdfTable1 = new PdfTable(90);
			pdfTable1.setBorder(0);
			pdfTable1.setFont(normalTextFont);
	
			float[] columnWidths = {7,4,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,6,6,8};
			pdfTable1.setColumnWidths(columnWidths);
	
			pdfTable1.addRow();
			pdfTable1.setFont(1, boldTextFont);
	
			pdfTable1.setText(1,1,"Source");
			pdfTable1.setText(1,2,"Year");
			pdfTable1.setText(1,3,"-");
			pdfTable1.setText(1,4,"-");
			pdfTable1.setText(1,5,"-");
			pdfTable1.setText(1,6,"-");
			pdfTable1.setText(1,7,"+");
			pdfTable1.setText(1,8,"-");
			pdfTable1.setText(1,9,"-");
			pdfTable1.setText(1,10,"-");
			pdfTable1.setText(1,11,"-");
			pdfTable1.setText(1,12,"1");
			pdfTable1.setText(1,13,"-");
			pdfTable1.setText(1,14,"-");
			pdfTable1.setText(1,15,"-");
			pdfTable1.setText(1,16,"-");
			pdfTable1.setText(1,17,"+");
			pdfTable1.setText(1,18,"-");
			pdfTable1.setText(1,19,"-");
			pdfTable1.setText(1,20,"-");
			pdfTable1.setText(1,21,"-");
			pdfTable1.setText(1,22,"2");
			pdfTable1.setText(1,23,"-");
			pdfTable1.setText(1,24,"-");
			pdfTable1.setText(1,25,"-");
			pdfTable1.setText(1,26,"-");
			pdfTable1.setText(1,27,"+");
			pdfTable1.setText(1,28,"-");
			pdfTable1.setText(1,29,"-");
			pdfTable1.setText(1,30,"-");
			pdfTable1.setText(1,31,"-");
			pdfTable1.setText(1,32,"-");
			pdfTable1.setText(1,33,"3");
			pdfTable1.setText(1,34,"-");
			pdfTable1.setText(1,35,"-");
			pdfTable1.setText(1,36,"-");
			pdfTable1.setText(1,37,"+");
			pdfTable1.setText(1,38,"-");
			pdfTable1.setText(1,39,"-");
			pdfTable1.setText(1,40,"-");
			pdfTable1.setText(1,41,"-");
			pdfTable1.setText(1,42,"4");
			pdfTable1.setText(1,43,"-");
			pdfTable1.setText(1,44,"-");
			pdfTable1.setText(1,45,"-");
			pdfTable1.setText(1,46,"-");
			pdfTable1.setText(1,47,"+");
			pdfTable1.setText(1,48,"-");
			pdfTable1.setText(1,49,"-");
			pdfTable1.setText(1,50,"-");
			pdfTable1.setText(1,51,"-");
			pdfTable1.setText(1,52,"5");
			pdfTable1.setText(1,53,"-");
			pdfTable1.setText(1,54,"-");
			pdfTable1.setText(1,55,"-");
			pdfTable1.setText(1,56,"-");
			pdfTable1.setText(1,57,"+");
			pdfTable1.setText(1,58,"-");
			pdfTable1.setText(1,59,"-");
			pdfTable1.setText(1,60,"-");
			pdfTable1.setText(1,61,"-");
			pdfTable1.setText(1,62,"6");
			pdfTable1.setText(1,63,"-");
			pdfTable1.setText(1,64,"-");
			pdfTable1.setText(1,65,"-");
			pdfTable1.setText(1,66,"-");
			pdfTable1.setText(1,67,"+");
			pdfTable1.setText(1,68,"-");
			pdfTable1.setText(1,69,"-");
			pdfTable1.setText(1,70,"-");
			pdfTable1.setText(1,71,"-");
			pdfTable1.setText(1,72,"7");
			pdfTable1.setText(1,73,"-");
			pdfTable1.setText(1,74,"-");
			pdfTable1.setText(1,75,"-");
			pdfTable1.setText(1,76,"-");
			pdfTable1.setText(1,77,"+");
			pdfTable1.setText(1,78,"-");
			pdfTable1.setText(1,79,"-");
			pdfTable1.setText(1,80,"-");
			pdfTable1.setText(1,81,"-");
			pdfTable1.setText(1,82,"8");
			pdfTable1.setText(1,83,"-");
			pdfTable1.setText(1,84,"-");
			pdfTable1.setText(1,85,"-");
			pdfTable1.setText(1,86,"-");			
			pdfTable1.setText(1,87,"");
			pdfTable1.setText(1,88,"");
			pdfTable1.setText(1,89,"");
			pdfTable1.setText(1,90,"Raw RA Factor");
	
			pdfTable1.addRow();
			pdfTable1.setText(2,1,"RAPS");
			pdfTable1.setText(2,2,"2007");
			pdfTable1.setText(2,3,"0");
			pdfTable1.setText(2,4,"0");
			pdfTable1.setText(2,5,"0");
			pdfTable1.setText(2,6,"0");
			pdfTable1.setText(2,7,"0");
			pdfTable1.setText(2,8,"0");
			pdfTable1.setText(2,9,"0");
			pdfTable1.setText(2,10,"0");
			pdfTable1.setText(2,11,"0");
			pdfTable1.setText(2,12,"0");
			pdfTable1.setText(2,13,"0");
			pdfTable1.setText(2,14,"0");
			pdfTable1.setText(2,15,"0");
			pdfTable1.setText(2,16,"0");
			pdfTable1.setText(2,17,"0");
			pdfTable1.setText(2,18,"0");
			pdfTable1.setText(2,19,"0");
			pdfTable1.setText(2,20,"0");
			pdfTable1.setText(2,21,"0");
			pdfTable1.setText(2,22,"0");
			pdfTable1.setText(2,23,"1");
			pdfTable1.setFont(2,23, boldTextFont);
			pdfTable1.setText(2,24,"0");
			pdfTable1.setText(2,25,"0");
			pdfTable1.setText(2,26,"0");
			pdfTable1.setText(2,27,"0");
			pdfTable1.setText(2,28,"0");
			pdfTable1.setText(2,29,"0");
			pdfTable1.setText(2,30,"0");
			pdfTable1.setText(2,31,"0");
			pdfTable1.setText(2,32,"0");
			pdfTable1.setText(2,33,"0");
			pdfTable1.setText(2,34,"0");
			pdfTable1.setText(2,35,"0");
			pdfTable1.setText(2,36,"0");
			pdfTable1.setText(2,37,"0");
			pdfTable1.setText(2,38,"0");
			pdfTable1.setText(2,39,"0");
			pdfTable1.setText(2,40,"0");
			pdfTable1.setText(2,41,"0");
			pdfTable1.setText(2,42,"0");
			pdfTable1.setText(2,43,"0");
			pdfTable1.setText(2,44,"0");
			pdfTable1.setText(2,45,"0");
			pdfTable1.setText(2,46,"0");
			pdfTable1.setText(2,47,"0");
			pdfTable1.setText(2,48,"0");
			pdfTable1.setText(2,49,"0");
			pdfTable1.setText(2,50,"0");
			pdfTable1.setText(2,51,"0");
			pdfTable1.setText(2,52,"1");
			pdfTable1.setFont(2,52, boldTextFont);
			pdfTable1.setText(2,53,"0");
			pdfTable1.setText(2,54,"0");
			pdfTable1.setText(2,55,"0");
			pdfTable1.setText(2,56,"0");
			pdfTable1.setText(2,57,"0");
			pdfTable1.setText(2,58,"0");
			pdfTable1.setText(2,59,"0");
			pdfTable1.setText(2,60,"0");
			pdfTable1.setText(2,61,"0");
			pdfTable1.setText(2,62,"0");
			pdfTable1.setText(2,63,"0");
			pdfTable1.setText(2,64,"0");
			pdfTable1.setText(2,65,"0");
			pdfTable1.setText(2,66,"0");
			pdfTable1.setText(2,67,"0");
			pdfTable1.setText(2,68,"0");
			pdfTable1.setText(2,69,"0");
			pdfTable1.setText(2,70,"0");
			pdfTable1.setText(2,71,"0");
			pdfTable1.setText(2,72,"0");
			pdfTable1.setText(2,73,"0");
			pdfTable1.setText(2,74,"0");
			pdfTable1.setText(2,75,"0");
			pdfTable1.setText(2,76,"0");
			pdfTable1.setText(2,77,"0");
			pdfTable1.setText(2,78,"0");
			pdfTable1.setText(2,79,"0");
			pdfTable1.setText(2,80,"0");
			pdfTable1.setText(2,81,"0");
			pdfTable1.setText(2,82,"0");
			pdfTable1.setText(2,83,"0");
			pdfTable1.setText(2,84,"0");
			pdfTable1.setText(2,85,"0");
			pdfTable1.setText(2,86,"0");
			pdfTable1.setText(2,87,"");
			pdfTable1.setText(2,88,"");
			pdfTable1.setText(2,89,"");
			pdfTable1.setText(2,90,"0.687");
			
			pdfTable1.addRow();
			pdfTable1.setText(3,1,"BASELINE");
			pdfTable1.setText(3,2,"2007");
			pdfTable1.setText(3,3,"0");
			pdfTable1.setText(3,4,"0");
			pdfTable1.setText(3,5,"0");
			pdfTable1.setText(3,6,"0");
			pdfTable1.setText(3,7,"0");
			pdfTable1.setText(3,8,"0");
			pdfTable1.setText(3,9,"0");
			pdfTable1.setText(3,10,"0");
			pdfTable1.setText(3,11,"0");
			pdfTable1.setText(3,12,"0");
			pdfTable1.setText(3,13,"0");
			pdfTable1.setText(3,14,"0");
			pdfTable1.setText(3,15,"0");
			pdfTable1.setText(3,16,"0");
			pdfTable1.setText(3,17,"0");
			pdfTable1.setText(3,18,"0");
			pdfTable1.setText(3,19,"0");
			pdfTable1.setText(3,20,"0");
			pdfTable1.setText(3,21,"0");
			pdfTable1.setText(3,22,"0");
			pdfTable1.setText(3,23,"1");
			pdfTable1.setFont(3,23, boldTextFont);
			pdfTable1.setText(3,24,"0");
			pdfTable1.setText(3,25,"1");
			pdfTable1.setFont(3,25, boldTextFont);
			pdfTable1.setText(3,26,"0");
			pdfTable1.setText(3,27,"0");
			pdfTable1.setText(3,28,"0");
			pdfTable1.setText(3,29,"0");
			pdfTable1.setText(3,30,"0");
			pdfTable1.setText(3,31,"0");
			pdfTable1.setText(3,32,"0");
			pdfTable1.setText(3,33,"0");
			pdfTable1.setText(3,34,"0");
			pdfTable1.setText(3,35,"0");
			pdfTable1.setText(3,36,"0");
			pdfTable1.setText(3,37,"0");
			pdfTable1.setText(3,38,"0");
			pdfTable1.setText(3,39,"0");
			pdfTable1.setText(3,40,"0");
			pdfTable1.setText(3,41,"0");
			pdfTable1.setText(3,42,"0");
			pdfTable1.setText(3,43,"0");
			pdfTable1.setText(3,44,"0");
			pdfTable1.setText(3,45,"1");
			pdfTable1.setFont(3,45, boldTextFont);
			pdfTable1.setText(3,46,"0");
			pdfTable1.setText(3,47,"0");
			pdfTable1.setText(3,48,"0");
			pdfTable1.setText(3,49,"0");
			pdfTable1.setText(3,50,"0");
			pdfTable1.setText(3,51,"0");
			pdfTable1.setText(3,52,"1");
			pdfTable1.setFont(3,52, boldTextFont);
			pdfTable1.setText(3,53,"0");
			pdfTable1.setText(3,54,"0");
			pdfTable1.setText(3,55,"0");
			pdfTable1.setText(3,56,"0");
			pdfTable1.setText(3,57,"0");
			pdfTable1.setText(3,58,"0");
			pdfTable1.setText(3,59,"0");
			pdfTable1.setText(3,60,"0");
			pdfTable1.setText(3,61,"0");
			pdfTable1.setText(3,62,"0");
			pdfTable1.setText(3,63,"0");
			pdfTable1.setText(3,64,"0");
			pdfTable1.setText(3,65,"0");
			pdfTable1.setText(3,66,"0");
			pdfTable1.setText(3,67,"0");
			pdfTable1.setText(3,68,"0");
			pdfTable1.setText(3,69,"0");
			pdfTable1.setText(3,70,"0");
			pdfTable1.setText(3,71,"0");
			pdfTable1.setText(3,72,"0");
			pdfTable1.setText(3,73,"0");
			pdfTable1.setText(3,74,"0");
			pdfTable1.setText(3,75,"0");
			pdfTable1.setText(3,76,"0");
			pdfTable1.setText(3,77,"0");
			pdfTable1.setText(3,78,"0");
			pdfTable1.setText(3,79,"0");
			pdfTable1.setText(3,80,"0");
			pdfTable1.setText(3,81,"0");
			pdfTable1.setText(3,82,"0");
			pdfTable1.setText(3,83,"0");
			pdfTable1.setText(3,84,"");
			pdfTable1.setText(3,85,"");
			pdfTable1.setText(3,86,"");
			pdfTable1.setText(3,87,"1.759");
			
			pdfTable1.addRow();
			pdfTable1.setText(4,1,"BASELINE");
			pdfTable1.setText(4,2,"2008");
			pdfTable1.setText(4,3,"0");
			pdfTable1.setText(4,4,"0");
			pdfTable1.setText(4,5,"0");
			pdfTable1.setText(4,6,"0");
			pdfTable1.setText(4,7,"0");
			pdfTable1.setText(4,8,"0");
			pdfTable1.setText(4,9,"0");
			pdfTable1.setText(4,10,"0");
			pdfTable1.setText(4,11,"0");
			pdfTable1.setText(4,12,"0");
			pdfTable1.setText(4,13,"0");
			pdfTable1.setText(4,14,"0");
			pdfTable1.setText(4,15,"0");
			pdfTable1.setText(4,16,"0");
			pdfTable1.setText(4,17,"0");
			pdfTable1.setText(4,18,"0");
			pdfTable1.setText(4,19,"0");
			pdfTable1.setText(4,20,"0");
			pdfTable1.setText(4,21,"0");
			pdfTable1.setText(4,22,"0");
			pdfTable1.setText(4,23,"1");
			pdfTable1.setFont(4,23, boldTextFont);
			pdfTable1.setText(4,24,"0");
			pdfTable1.setText(4,25,"1");
			pdfTable1.setFont(4,25, boldTextFont);
			pdfTable1.setText(4,26,"0");
			pdfTable1.setText(4,27,"0");
			pdfTable1.setText(4,28,"0");
			pdfTable1.setText(4,29,"0");
			pdfTable1.setText(4,30,"0");
			pdfTable1.setText(4,31,"0");
			pdfTable1.setText(4,32,"0");
			pdfTable1.setText(4,33,"0");
			pdfTable1.setText(4,34,"0");
			pdfTable1.setText(4,35,"0");
			pdfTable1.setText(4,36,"0");
			pdfTable1.setText(4,37,"0");
			pdfTable1.setText(4,38,"0");
			pdfTable1.setText(4,39,"0");
			pdfTable1.setText(4,40,"0");
			pdfTable1.setText(4,41,"0");
			pdfTable1.setText(4,42,"0");
			pdfTable1.setText(4,43,"0");
			pdfTable1.setText(4,44,"0");
			pdfTable1.setText(4,45,"1");
			pdfTable1.setFont(4,45, boldTextFont);
			pdfTable1.setText(4,46,"0");
			pdfTable1.setText(4,47,"0");
			pdfTable1.setText(4,48,"0");
			pdfTable1.setText(4,49,"0");
			pdfTable1.setText(4,50,"0");
			pdfTable1.setText(4,51,"0");
			pdfTable1.setText(4,52,"1");
			pdfTable1.setFont(4,52, boldTextFont);
			pdfTable1.setText(4,53,"0");
			pdfTable1.setText(4,54,"0");
			pdfTable1.setText(4,55,"0");
			pdfTable1.setText(4,56,"0");
			pdfTable1.setText(4,57,"0");
			pdfTable1.setText(4,58,"0");
			pdfTable1.setText(4,59,"0");
			pdfTable1.setText(4,60,"0");
			pdfTable1.setText(4,61,"0");
			pdfTable1.setText(4,62,"0");
			pdfTable1.setText(4,63,"0");
			pdfTable1.setText(4,64,"0");
			pdfTable1.setText(4,65,"0");
			pdfTable1.setText(4,66,"0");
			pdfTable1.setText(4,67,"0");
			pdfTable1.setText(4,68,"0");
			pdfTable1.setText(4,69,"0");
			pdfTable1.setText(4,70,"0");
			pdfTable1.setText(4,71,"0");
			pdfTable1.setText(4,72,"0");
			pdfTable1.setText(4,73,"0");
			pdfTable1.setText(4,74,"0");
			pdfTable1.setText(4,75,"0");
			pdfTable1.setText(4,76,"0");
			pdfTable1.setText(4,77,"0");
			pdfTable1.setText(4,78,"0");
			pdfTable1.setText(4,79,"0");
			pdfTable1.setText(4,80,"0");
			pdfTable1.setText(4,81,"0");
			pdfTable1.setText(4,82,"0");
			pdfTable1.setText(4,83,"0");
			pdfTable1.setText(4,84,"0");
			pdfTable1.setText(4,85,"0");
			pdfTable1.setText(4,86,"0");
			pdfTable1.setText(4,87,"");
			pdfTable1.setText(4,88,"");
			pdfTable1.setText(4,89,"");
			pdfTable1.setText(4,90,"1.759");			
			
			pdfTable1.addRow();
			pdfTable1.setText(5,1,"RAPS");
			pdfTable1.setText(5,2,"2008");
			pdfTable1.setText(5,3,"0");
			pdfTable1.setText(5,4,"0");
			pdfTable1.setText(5,5,"0");
			pdfTable1.setText(5,6,"0");
			pdfTable1.setText(5,7,"0");
			pdfTable1.setText(5,8,"0");
			pdfTable1.setText(5,9,"0");
			pdfTable1.setText(5,10,"0");
			pdfTable1.setText(5,11,"0");
			pdfTable1.setText(5,12,"0");
			pdfTable1.setText(5,13,"0");
			pdfTable1.setText(5,14,"0");
			pdfTable1.setText(5,15,"0");
			pdfTable1.setText(5,16,"0");
			pdfTable1.setText(5,17,"0");
			pdfTable1.setText(5,18,"0");
			pdfTable1.setText(5,19,"0");
			pdfTable1.setText(5,20,"0");
			pdfTable1.setText(5,21,"0");
			pdfTable1.setText(5,22,"0");
			pdfTable1.setText(5,23,"1");
			pdfTable1.setFont(5,23, boldTextFont);
			pdfTable1.setText(5,24,"0");
			pdfTable1.setText(5,25,"0");
			pdfTable1.setText(5,26,"0");
			pdfTable1.setText(5,27,"0");
			pdfTable1.setText(5,28,"0");
			pdfTable1.setText(5,29,"0");
			pdfTable1.setText(5,30,"0");
			pdfTable1.setText(5,31,"0");
			pdfTable1.setText(5,32,"0");
			pdfTable1.setText(5,33,"0");
			pdfTable1.setText(5,34,"0");
			pdfTable1.setText(5,35,"0");
			pdfTable1.setText(5,36,"0");
			pdfTable1.setText(5,37,"0");
			pdfTable1.setText(5,38,"0");
			pdfTable1.setText(5,39,"0");
			pdfTable1.setText(5,40,"0");
			pdfTable1.setText(5,41,"0");
			pdfTable1.setText(5,42,"0");
			pdfTable1.setText(5,43,"0");
			pdfTable1.setText(5,44,"0");
			pdfTable1.setText(5,45,"0");
			pdfTable1.setText(5,46,"0");
			pdfTable1.setText(5,47,"0");
			pdfTable1.setText(5,48,"0");
			pdfTable1.setText(5,49,"0");
			pdfTable1.setText(5,50,"0");
			pdfTable1.setText(5,51,"0");
			pdfTable1.setText(5,52,"0");
			pdfTable1.setText(5,53,"0");
			pdfTable1.setText(5,54,"0");
			pdfTable1.setText(5,55,"0");
			pdfTable1.setText(5,56,"0");
			pdfTable1.setText(5,57,"0");
			pdfTable1.setText(5,58,"0");
			pdfTable1.setText(5,59,"0");
			pdfTable1.setText(5,60,"0");
			pdfTable1.setText(5,61,"0");
			pdfTable1.setText(5,62,"0");
			pdfTable1.setText(5,63,"0");
			pdfTable1.setText(5,64,"0");
			pdfTable1.setText(5,65,"0");
			pdfTable1.setText(5,66,"0");
			pdfTable1.setText(5,67,"0");
			pdfTable1.setText(5,68,"0");
			pdfTable1.setText(5,69,"0");
			pdfTable1.setText(5,70,"0");
			pdfTable1.setText(5,71,"0");
			pdfTable1.setText(5,72,"0");
			pdfTable1.setText(5,73,"0");
			pdfTable1.setText(5,74,"0");
			pdfTable1.setText(5,75,"0");
			pdfTable1.setText(5,76,"0");
			pdfTable1.setText(5,77,"0");
			pdfTable1.setText(5,78,"0");
			pdfTable1.setText(5,79,"0");
			pdfTable1.setText(5,80,"0");
			pdfTable1.setText(5,81,"0");
			pdfTable1.setText(5,82,"0");
			pdfTable1.setText(5,83,"0");
			pdfTable1.setText(5,84,"0");
			pdfTable1.setText(5,85,"0");
			pdfTable1.setText(5,86,"0");
			pdfTable1.setText(5,87,"");
			pdfTable1.setText(5,88,"");
			pdfTable1.setText(5,89,"");
			pdfTable1.setText(5,90,"0.687");			
	
			pdfTable1.addRow();
			pdfTable1.setFont(6, boldTextFont);
	
			pdfTable1.setText(6,1,"");
			pdfTable1.setText(6,2,"");
			pdfTable1.setText(6,3,"-");
			pdfTable1.setText(6,4,"-");
			pdfTable1.setText(6,5,"-");
			pdfTable1.setText(6,6,"-");
			pdfTable1.setText(6,7,"+");
			pdfTable1.setText(6,8,"-");
			pdfTable1.setText(6,9,"-");
			pdfTable1.setText(6,10,"-");
			pdfTable1.setText(6,11,"-");
			pdfTable1.setText(6,12,"1");
			pdfTable1.setText(6,13,"-");
			pdfTable1.setText(6,14,"-");
			pdfTable1.setText(6,15,"-");
			pdfTable1.setText(6,16,"-");
			pdfTable1.setText(6,17,"+");
			pdfTable1.setText(6,18,"-");
			pdfTable1.setText(6,19,"-");
			pdfTable1.setText(6,20,"-");
			pdfTable1.setText(6,21,"-");
			pdfTable1.setText(6,22,"2");
			pdfTable1.setText(6,23,"-");
			pdfTable1.setText(6,24,"-");
			pdfTable1.setText(6,25,"-");
			pdfTable1.setText(6,26,"-");
			pdfTable1.setText(6,27,"+");
			pdfTable1.setText(6,28,"-");
			pdfTable1.setText(6,29,"-");
			pdfTable1.setText(6,30,"-");
			pdfTable1.setText(6,31,"-");
			pdfTable1.setText(6,32,"-");
			pdfTable1.setText(6,33,"3");
			pdfTable1.setText(6,34,"-");
			pdfTable1.setText(6,35,"-");
			pdfTable1.setText(6,36,"-");
			pdfTable1.setText(6,37,"+");
			pdfTable1.setText(6,38,"-");
			pdfTable1.setText(6,39,"-");
			pdfTable1.setText(6,40,"-");
			pdfTable1.setText(6,41,"-");
			pdfTable1.setText(6,42,"4");
			pdfTable1.setText(6,43,"-");
			pdfTable1.setText(6,44,"-");
			pdfTable1.setText(6,45,"-");
			pdfTable1.setText(6,46,"-");
			pdfTable1.setText(6,47,"+");
			pdfTable1.setText(6,48,"-");
			pdfTable1.setText(6,49,"-");
			pdfTable1.setText(6,50,"-");
			pdfTable1.setText(6,51,"-");
			pdfTable1.setText(6,52,"5");
			pdfTable1.setText(6,53,"-");
			pdfTable1.setText(6,54,"-");
			pdfTable1.setText(6,55,"-");
			pdfTable1.setText(6,56,"-");
			pdfTable1.setText(6,57,"+");
			pdfTable1.setText(6,58,"-");
			pdfTable1.setText(6,59,"-");
			pdfTable1.setText(6,60,"-");
			pdfTable1.setText(6,61,"-");
			pdfTable1.setText(6,62,"6");
			pdfTable1.setText(6,63,"-");
			pdfTable1.setText(6,64,"-");
			pdfTable1.setText(6,65,"-");
			pdfTable1.setText(6,66,"-");
			pdfTable1.setText(6,67,"+");
			pdfTable1.setText(6,68,"-");
			pdfTable1.setText(6,69,"-");
			pdfTable1.setText(6,70,"-");
			pdfTable1.setText(6,71,"-");
			pdfTable1.setText(6,72,"7");
			pdfTable1.setText(6,73,"-");
			pdfTable1.setText(6,74,"-");
			pdfTable1.setText(6,75,"-");
			pdfTable1.setText(6,76,"-");
			pdfTable1.setText(6,77,"+");
			pdfTable1.setText(6,78,"-");
			pdfTable1.setText(6,79,"-");
			pdfTable1.setText(6,80,"-");
			pdfTable1.setText(6,81,"-");
			pdfTable1.setText(6,82,"8");
			pdfTable1.setText(6,83,"-");
			pdfTable1.setText(6,84,"-");
			pdfTable1.setText(6,85,"-");
			pdfTable1.setText(6,86,"-");
			pdfTable1.setText(6,87,"");
			pdfTable1.setText(6,88,"");
			pdfTable1.setText(6,89,"");
			pdfTable1.setText(6,90,"");
	
			PdfTable projectionTable = new PdfTable(7);
			projectionTable.setWidthPercentage(100);
			projectionTable.setBorder(0);
			projectionTable.setFont(normalTextFont);
			float[] projectionTableWidths = {8f, 14f, 14f, 22f,14f,14f,10f};
			projectionTable.setColumnWidths(projectionTableWidths);
	
			rowIndex = projectionTable.addRow();		// New Row
			projectionTable.setColSpan(rowIndex, 1, 7);
			projectionTable.setText(rowIndex, 1, "************************************************** 2008 Earned to Date **************************************************");
			projectionTable.setAlignment(rowIndex, 1, PdfTable.CENTER);
	
			rowIndex = projectionTable.addRow();		// New Row
			projectionTable.setText(rowIndex, 1, "");
			projectionTable.setText(rowIndex, 2, "Baseline");
			projectionTable.setText(rowIndex, 3, "RAFactor");
			projectionTable.setText(rowIndex, 4, "");
			projectionTable.setText(rowIndex, 5, "RAPS");
			projectionTable.setText(rowIndex, 6, "RAFactor");
			projectionTable.setText(rowIndex, 7, "");
	
			rowIndex = projectionTable.addRow();		// New Row
			projectionTable.setText(rowIndex, 1, "2008XX");
			projectionTable.setText(rowIndex, 2, "1604.25");
			projectionTable.setText(rowIndex, 3, "2.412");
			projectionTable.setText(rowIndex, 4, "");
			projectionTable.setText(rowIndex, 5, "789.21");
			projectionTable.setText(rowIndex, 6, "1.016");
			projectionTable.setText(rowIndex, 7, "");
	
			rowIndex = projectionTable.addRow();		// New Row
			projectionTable.setText(rowIndex, 1, "Total");
			projectionTable.setFont(rowIndex, 1, boldTextFont);
			projectionTable.setText(rowIndex, 2, "19251");
			projectionTable.setText(rowIndex, 3, "");
			projectionTable.setText(rowIndex, 4, "");
			projectionTable.setText(rowIndex, 5, "9470.52");
			projectionTable.setText(rowIndex, 6, "");
			projectionTable.setText(rowIndex, 7, "");
	
			// Define the numbers table
			PdfTable reconPayTable = new PdfTable(16);
			reconPayTable.setWidthPercentage(100);
			reconPayTable.setBorder(0);
			reconPayTable.setFont(normalTextFont);
			reconPayTable.setAlignment(PdfTable.CENTER);
			float[] reconPayTableWidths = {5f,.1f,8f,8f,.1f,8f,8f,.1f,8f,8f,.1f,8f,8f,.1f,8f,8f};
			reconPayTable.setColumnWidths(reconPayTableWidths);
	
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setColSpan(rowIndex, 1, 16);
			reconPayTable.setText(rowIndex, 1, "****************************************************** 2007 Actuals ******************************************************");
	
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setColSpan(rowIndex, 3, 2);
			reconPayTable.setColSpan(rowIndex, 6, 5);
			reconPayTable.setColSpan(rowIndex, 12, 5);
	
			reconPayTable.drawLine(rowIndex, 3, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 6, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 12, .75f, Color.LIGHT_GRAY);
	
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setFont(rowIndex, boldTextFont);
			reconPayTable.setColSpan(rowIndex, 3, 2);
			reconPayTable.setColSpan(rowIndex, 6, 5);
			reconPayTable.setColSpan(rowIndex, 12, 5);
			reconPayTable.setText(rowIndex, 3, "");
			reconPayTable.setText(rowIndex, 6, "Recon+");
			reconPayTable.setText(rowIndex, 12, "Plan Expected Payment");
	
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setColSpan(rowIndex, 3, 2);
			reconPayTable.setColSpan(rowIndex, 6, 2);
			reconPayTable.setColSpan(rowIndex, 9, 2);
			reconPayTable.setColSpan(rowIndex, 12, 5);
	
			reconPayTable.drawLine(rowIndex, 3, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 6, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 9, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 12, .75f, Color.LIGHT_GRAY);
	
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setFont(rowIndex, boldTextFont);
			reconPayTable.setText(rowIndex, 1, "");
			reconPayTable.setText(rowIndex, 2, "");
			reconPayTable.setText(rowIndex, 3, "Baseline");
			reconPayTable.setText(rowIndex, 4, "RAFactor");
			reconPayTable.setText(rowIndex, 5, "");
			reconPayTable.setText(rowIndex, 6, "CMS");
			reconPayTable.setText(rowIndex, 7, "RAFactor");
			reconPayTable.setText(rowIndex, 8, "");
			reconPayTable.setText(rowIndex, 9, "Plan");
			reconPayTable.setText(rowIndex, 10, "RAFactor");
			reconPayTable.setText(rowIndex, 11, "");
			reconPayTable.setText(rowIndex, 12, "RAPS");
			reconPayTable.setText(rowIndex, 13, "RAFactor");
			reconPayTable.setText(rowIndex, 14, "");
			reconPayTable.setText(rowIndex, 15, "RAPS and PTDMODD");
			reconPayTable.setText(rowIndex, 16, "RAFactor");
	
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setColSpan(rowIndex, 3, 2);
			reconPayTable.setColSpan(rowIndex, 6, 2);
			reconPayTable.setColSpan(rowIndex, 9, 2);
			reconPayTable.setColSpan(rowIndex, 12, 5);
	
			reconPayTable.drawLine(rowIndex, 3, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 6, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 9, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 12, .75f, Color.LIGHT_GRAY);
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setText(rowIndex, 1, "200701");
			reconPayTable.setText(rowIndex, 2, "");
			reconPayTable.setText(rowIndex, 3, "1604.25");
			reconPayTable.setText(rowIndex, 4, "2.412");
			reconPayTable.setText(rowIndex, 5, "");
			reconPayTable.setText(rowIndex, 6, "996.11");
			reconPayTable.setText(rowIndex, 7, "1.37");
			reconPayTable.setText(rowIndex, 8, "");
			reconPayTable.setText(rowIndex, 9, "996.11");
			reconPayTable.setText(rowIndex, 10, "1.37");
			reconPayTable.setText(rowIndex, 11, "");
			reconPayTable.setText(rowIndex, 12, "996.11");
			reconPayTable.setText(rowIndex, 13, "1.37");
			reconPayTable.setText(rowIndex, 14, "");
			reconPayTable.setText(rowIndex, 15, "996.11");
			reconPayTable.setText(rowIndex, 16, "1.37");
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setText(rowIndex, 1, "200702");
			reconPayTable.setText(rowIndex, 2, "");
			reconPayTable.setText(rowIndex, 3, "1604.25");
			reconPayTable.setText(rowIndex, 4, "2.412");
			reconPayTable.setText(rowIndex, 5, "");
			reconPayTable.setText(rowIndex, 6, "996.11");
			reconPayTable.setText(rowIndex, 7, "1.37");
			reconPayTable.setText(rowIndex, 8, "");
			reconPayTable.setText(rowIndex, 9, "996.11");
			reconPayTable.setText(rowIndex, 10, "1.37");
			reconPayTable.setText(rowIndex, 11, "");
			reconPayTable.setText(rowIndex, 12, "996.11");
			reconPayTable.setText(rowIndex, 13, "1.37");
			reconPayTable.setText(rowIndex, 14, "");
			reconPayTable.setText(rowIndex, 15, "996.11");
			reconPayTable.setText(rowIndex, 16, "1.37");
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setText(rowIndex, 1, "200703");
			reconPayTable.setText(rowIndex, 2, "");
			reconPayTable.setText(rowIndex, 3, "1604.25");
			reconPayTable.setText(rowIndex, 4, "2.412");
			reconPayTable.setText(rowIndex, 5, "");
			reconPayTable.setText(rowIndex, 6, "996.11");
			reconPayTable.setText(rowIndex, 7, "1.37");
			reconPayTable.setText(rowIndex, 8, "");
			reconPayTable.setText(rowIndex, 9, "996.11");
			reconPayTable.setText(rowIndex, 10, "1.37");
			reconPayTable.setText(rowIndex, 11, "");
			reconPayTable.setText(rowIndex, 12, "996.11");
			reconPayTable.setText(rowIndex, 13, "1.37");
			reconPayTable.setText(rowIndex, 14, "");
			reconPayTable.setText(rowIndex, 15, "996.11");
			reconPayTable.setText(rowIndex, 16, "1.37");
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setText(rowIndex, 1, "200704");
			reconPayTable.setText(rowIndex, 2, "");
			reconPayTable.setText(rowIndex, 3, "1604.25");
			reconPayTable.setText(rowIndex, 4, "2.412");
			reconPayTable.setText(rowIndex, 5, "");
			reconPayTable.setText(rowIndex, 6, "996.11");
			reconPayTable.setText(rowIndex, 7, "1.37");
			reconPayTable.setText(rowIndex, 8, "");
			reconPayTable.setText(rowIndex, 9, "996.11");
			reconPayTable.setText(rowIndex, 10, "1.37");
			reconPayTable.setText(rowIndex, 11, "");
			reconPayTable.setText(rowIndex, 12, "996.11");
			reconPayTable.setText(rowIndex, 13, "1.37");
			reconPayTable.setText(rowIndex, 14, "");
			reconPayTable.setText(rowIndex, 15, "996.11");
			reconPayTable.setText(rowIndex, 16, "1.37");
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setText(rowIndex, 1, "200705");
			reconPayTable.setText(rowIndex, 2, "");
			reconPayTable.setText(rowIndex, 3, "1604.25");
			reconPayTable.setText(rowIndex, 4, "2.412");
			reconPayTable.setText(rowIndex, 5, "");
			reconPayTable.setText(rowIndex, 6, "996.11");
			reconPayTable.setText(rowIndex, 7, "1.37");
			reconPayTable.setText(rowIndex, 8, "");
			reconPayTable.setText(rowIndex, 9, "996.11");
			reconPayTable.setText(rowIndex, 10, "1.37");
			reconPayTable.setText(rowIndex, 11, "");
			reconPayTable.setText(rowIndex, 12, "996.11");
			reconPayTable.setText(rowIndex, 13, "1.37");
			reconPayTable.setText(rowIndex, 14, "");
			reconPayTable.setText(rowIndex, 15, "996.11");
			reconPayTable.setText(rowIndex, 16, "1.37");
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setText(rowIndex, 1, "200706");
			reconPayTable.setText(rowIndex, 2, "");
			reconPayTable.setText(rowIndex, 3, "1604.25");
			reconPayTable.setText(rowIndex, 4, "2.412");
			reconPayTable.setText(rowIndex, 5, "");
			reconPayTable.setText(rowIndex, 6, "996.11");
			reconPayTable.setText(rowIndex, 7, "1.37");
			reconPayTable.setText(rowIndex, 8, "");
			reconPayTable.setText(rowIndex, 9, "996.11");
			reconPayTable.setText(rowIndex, 10, "1.37");
			reconPayTable.setText(rowIndex, 11, "");
			reconPayTable.setText(rowIndex, 12, "996.11");
			reconPayTable.setText(rowIndex, 13, "1.37");
			reconPayTable.setText(rowIndex, 14, "");
			reconPayTable.setText(rowIndex, 15, "996.11");
			reconPayTable.setText(rowIndex, 16, "1.37");
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setText(rowIndex, 1, "200707");
			reconPayTable.setText(rowIndex, 2, "");
			reconPayTable.setText(rowIndex, 3, "1604.25");
			reconPayTable.setText(rowIndex, 4, "2.412");
			reconPayTable.setText(rowIndex, 5, "");
			reconPayTable.setText(rowIndex, 6, "996.11");
			reconPayTable.setText(rowIndex, 7, "1.37");
			reconPayTable.setText(rowIndex, 8, "");
			reconPayTable.setText(rowIndex, 9, "996.11");
			reconPayTable.setText(rowIndex, 10, "1.37");
			reconPayTable.setText(rowIndex, 11, "");
			reconPayTable.setText(rowIndex, 12, "996.11");
			reconPayTable.setText(rowIndex, 13, "1.37");
			reconPayTable.setText(rowIndex, 14, "");
			reconPayTable.setText(rowIndex, 15, "996.11");
			reconPayTable.setText(rowIndex, 16, "1.37");
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setText(rowIndex, 1, "200708");
			reconPayTable.setText(rowIndex, 2, "");
			reconPayTable.setText(rowIndex, 3, "1604.25");
			reconPayTable.setText(rowIndex, 4, "2.412");
			reconPayTable.setText(rowIndex, 5, "");
			reconPayTable.setText(rowIndex, 6, "996.11");
			reconPayTable.setText(rowIndex, 7, "1.37");
			reconPayTable.setText(rowIndex, 8, "");
			reconPayTable.setText(rowIndex, 9, "996.11");
			reconPayTable.setText(rowIndex, 10, "1.37");
			reconPayTable.setText(rowIndex, 11, "");
			reconPayTable.setText(rowIndex, 12, "996.11");
			reconPayTable.setText(rowIndex, 13, "1.37");
			reconPayTable.setText(rowIndex, 14, "");
			reconPayTable.setText(rowIndex, 15, "996.11");
			reconPayTable.setText(rowIndex, 16, "1.37");
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setText(rowIndex, 1, "200709");
			reconPayTable.setText(rowIndex, 2, "");
			reconPayTable.setText(rowIndex, 3, "1604.25");
			reconPayTable.setText(rowIndex, 4, "2.412");
			reconPayTable.setText(rowIndex, 5, "");
			reconPayTable.setText(rowIndex, 6, "996.11");
			reconPayTable.setText(rowIndex, 7, "1.37");
			reconPayTable.setText(rowIndex, 8, "");
			reconPayTable.setText(rowIndex, 9, "996.11");
			reconPayTable.setText(rowIndex, 10, "1.37");
			reconPayTable.setText(rowIndex, 11, "");
			reconPayTable.setText(rowIndex, 12, "996.11");
			reconPayTable.setText(rowIndex, 13, "1.37");
			reconPayTable.setText(rowIndex, 14, "");
			reconPayTable.setText(rowIndex, 15, "996.11");
			reconPayTable.setText(rowIndex, 16, "1.37");
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setText(rowIndex, 1, "200710");
			reconPayTable.setText(rowIndex, 2, "");
			reconPayTable.setText(rowIndex, 3, "1604.25");
			reconPayTable.setText(rowIndex, 4, "2.412");
			reconPayTable.setText(rowIndex, 5, "");
			reconPayTable.setText(rowIndex, 6, "996.11");
			reconPayTable.setText(rowIndex, 7, "1.37");
			reconPayTable.setText(rowIndex, 8, "");
			reconPayTable.setText(rowIndex, 9, "996.11");
			reconPayTable.setText(rowIndex, 10, "1.37");
			reconPayTable.setText(rowIndex, 11, "");
			reconPayTable.setText(rowIndex, 12, "996.11");
			reconPayTable.setText(rowIndex, 13, "1.37");
			reconPayTable.setText(rowIndex, 14, "");
			reconPayTable.setText(rowIndex, 15, "996.11");
			reconPayTable.setText(rowIndex, 16, "1.37");
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setText(rowIndex, 1, "200711");
			reconPayTable.setText(rowIndex, 2, "");
			reconPayTable.setText(rowIndex, 3, "1604.25");
			reconPayTable.setText(rowIndex, 4, "2.412");
			reconPayTable.setText(rowIndex, 5, "");
			reconPayTable.setText(rowIndex, 6, "996.11");
			reconPayTable.setText(rowIndex, 7, "1.37");
			reconPayTable.setText(rowIndex, 8, "");
			reconPayTable.setText(rowIndex, 9, "996.11");
			reconPayTable.setText(rowIndex, 10, "1.37");
			reconPayTable.setText(rowIndex, 11, "");
			reconPayTable.setText(rowIndex, 12, "996.11");
			reconPayTable.setText(rowIndex, 13, "1.37");
			reconPayTable.setText(rowIndex, 14, "");
			reconPayTable.setText(rowIndex, 15, "996.11");
			reconPayTable.setText(rowIndex, 16, "1.37");
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setText(rowIndex, 1, "200712");
			reconPayTable.setText(rowIndex, 2, "");
			reconPayTable.setText(rowIndex, 3, "1604.25");
			reconPayTable.setText(rowIndex, 4, "2.412");
			reconPayTable.setText(rowIndex, 5, "");
			reconPayTable.setText(rowIndex, 6, "996.11");
			reconPayTable.setText(rowIndex, 7, "1.37");
			reconPayTable.setText(rowIndex, 8, "");
			reconPayTable.setText(rowIndex, 9, "996.11");
			reconPayTable.setText(rowIndex, 10, "1.37");
			reconPayTable.setText(rowIndex, 11, "");
			reconPayTable.setText(rowIndex, 12, "996.11");
			reconPayTable.setText(rowIndex, 13, "1.37");
			reconPayTable.setText(rowIndex, 14, "");
			reconPayTable.setText(rowIndex, 15, "996.11");
			reconPayTable.setText(rowIndex, 16, "1.37");
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setColSpan(rowIndex, 3, 2);
			reconPayTable.setColSpan(rowIndex, 6, 2);
			reconPayTable.setColSpan(rowIndex, 9, 2);
			reconPayTable.setColSpan(rowIndex, 12, 5);
	
			reconPayTable.drawLine(rowIndex, 3, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 6, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 9, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 12, .75f, Color.LIGHT_GRAY);
	
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setText(rowIndex, 1, "Total");
			reconPayTable.setFont(rowIndex, 1, boldTextFont);
			reconPayTable.setText(rowIndex, 2, "");
			reconPayTable.setText(rowIndex, 3, "12,834");
			reconPayTable.setText(rowIndex, 4, "");
			reconPayTable.setText(rowIndex, 5, "");
			reconPayTable.setText(rowIndex, 6, "7968.88");
			reconPayTable.setText(rowIndex, 7, "");
			reconPayTable.setText(rowIndex, 8, "");
			reconPayTable.setText(rowIndex, 9, "7968.88");
			reconPayTable.setText(rowIndex, 10, "");
			reconPayTable.setText(rowIndex, 11, "");
			reconPayTable.setText(rowIndex, 12, "7968.88");
			reconPayTable.setText(rowIndex, 13, "");
			reconPayTable.setText(rowIndex, 14, "");
			reconPayTable.setText(rowIndex, 15, "7968.88");
			reconPayTable.setText(rowIndex, 16, "");
	
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setColSpan(rowIndex, 3, 2);
			reconPayTable.setColSpan(rowIndex, 6, 5);
			reconPayTable.setColSpan(rowIndex, 12, 5);
	
			reconPayTable.drawLine(rowIndex, 3, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 6, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 12, .75f, Color.LIGHT_GRAY);
	
			// MAIN TABLE
	
			PdfTable pdfTable = new PdfTable(1);
			pdfTable.setWidthPercentage(100);
			pdfTable.setBorder(0);
			pdfTable.setAlignment(PdfTable.CENTER);
			pdfTable.setFont(pageHeadingFont);
	
	
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "RA-Expert ");
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "Part D HCC Analysis  ");
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "Member Financial Projection for Payment Year 2007 ");
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "Data Collection Dates 01/01/2007 thru 12/31/2007 ");
	
			rowIndex = pdfTable.addSpacerLine(12);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, memberDetailTable);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, pdfTable1);
	
			rowIndex = pdfTable.addSpacerLine(12);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, projectionTable);
	
			rowIndex = pdfTable.addSpacerLine(12);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, reconPayTable);
	
			pdfUtil.addTable(pdfTable);
	
			pdfUtil.close();

		}catch(Exception ex){
			logger.error("Exception " + ex);
		}
	}
}