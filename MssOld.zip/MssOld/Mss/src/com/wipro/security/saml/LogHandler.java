//sso changes - start
/*
* Copyright (c) 2015 by wipro.com. All rights reserved.
*
* Oct 14, 2015
* 
* @author Ashish Shrivastava
*
*
*/

package com.wipro.security.saml;

import org.apache.log4j.Logger;


/**
 * The Class LogHandler.
 *
 * @author Ashish Shrivastava
 */
public class LogHandler {

	/**
	 * Gets the logger.
	 *
	 * @param clz the clz
	 * @return the logger
	 */
	public Logger getLogger(Class clz) {

		Logger logger = Logger.getLogger(clz);
		return logger;
	}

	/**
	 * Method start log.
	 *
	 * @param methodName the method name
	 * @param logger the logger
	 */
	public void methodStartLog(String methodName, Logger logger) {
		logger.info(methodName + "START");
	}

	/**
	 * Method end log.
	 *
	 * @param methodName the method name
	 * @param logger the logger
	 */
	public void methodEndLog(String methodName, Logger logger) {
		logger.info(methodName + "END");
	}
	

}
//sso changes - end