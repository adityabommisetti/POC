//sso changes - start
package com.wipro.security.saml;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


/**
 * The Class SAMLXMLParseUtil.
 */
public class SAMLXMLParseUtil {
	/** The Constant LOGHANDLER. */
	private static final LogHandler LOGHANDLER = new LogHandler();
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LOGHANDLER
			.getLogger(SAMLXMLParseUtil.class);
	
	
	/** The Constant SUBJECT. */
	public static final String SUBJECT="saml:Subject";
	
	
	/** The Constant ATTRIBUTE. */
	public static final String SAML_ATTRIBUTE="saml:Attribute";
	
	/** The Constant ATTRIBUTE. */
	public static final String SAML2_ATTRIBUTE="saml2:Attribute";
	
	/** The Constant USER_NAME. */
	public static final String USER_NAME="Name";
	


	/**
	 * Parses the saml reponse to user dto.
	 *
	 * @param samlXML
	 *            the saml xml
	 * @return the user dto
	 * @throws SAXException
	 *             the SAX exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws ParserConfigurationException
	 *             the parser configuration exception
	 */
	public static UserDTO parseSAMLReponseToUserDTO(String samlXML)
			throws SAXException, IOException, ParserConfigurationException {
		LOGHANDLER.methodStartLog("parseSAMLReponseToUserDTO()-", LOGGER);
		UserDTO userDTO = new UserDTO();
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		LOGGER.debug("Starting Parsing on the XML ");	
		Document doc = dBuilder.parse(new ByteArrayInputStream(samlXML.getBytes()));
		doc.getDocumentElement().normalize();
		LOGGER.debug("Parsing the XML Initiated");
		NodeList nList = doc.getElementsByTagName(SAML_ATTRIBUTE);
		if(nList.getLength()<=0){
			nList = doc.getElementsByTagName(SAML2_ATTRIBUTE);
		}
		for (int i = 0; i < nList.getLength(); i++) {
			Node nNode = nList.item(i);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;

				String attributeName = eElement.getAttribute(USER_NAME);
				String attributeValue = rtrim(ltrim(eElement.getTextContent()));

				if (attributeName.equalsIgnoreCase(UserDTO.USER_ID)) {
					LOGGER.info("Attribute Name: " +attributeName+ "Attribute Value: "+ attributeValue);
					userDTO.setUserId(attributeValue);
				}
				if (attributeName.equalsIgnoreCase(UserDTO.LAST_NAME)) {
					LOGGER.info("Attribute Name: " +attributeName+ "Attribute Value: "+ attributeValue);
					userDTO.setLastName(attributeValue);
				}
				
				if (attributeName.equalsIgnoreCase(UserDTO.FIRST_NAME)) {
					LOGGER.info("Attribute Name: " +attributeName+ "Attribute Value: "+ attributeValue);
					userDTO.setFirstName(attributeValue);
				}
				
				if (attributeName.equalsIgnoreCase(UserDTO.EMAIL_ID)) {
					LOGGER.info("Attribute Name: " +attributeName+ "Attribute Value: "+ attributeValue);
					userDTO.setEmailId(attributeValue);
				}
		
			}
		}
		
		LOGGER.debug("The User Info is SAML is "+userDTO);
		LOGHANDLER.methodEndLog("parseSAMLReponseToUserDTO()-", LOGGER);
		return userDTO;
	}

	/**
	 * Ltrim.
	 *
	 * @param s
	 *            the s
	 * @return the string
	 */
	public static String ltrim(String s) {
		int i = 0;
		while (i < s.length() && Character.isWhitespace(s.charAt(i))) {
			i++;
		}
		return s.substring(i);
	}

	/**
	 * Rtrim.
	 *
	 * @param s
	 *            the s
	 * @return the string
	 */
	public static String rtrim(String s) {
		int i = s.length() - 1;
		while (i >= 0 && Character.isWhitespace(s.charAt(i))) {
			i--;
		}
		return s.substring(0, i + 1);
	}
}
//sso changes - end