//sso changes - start
/*
* Copyright (c) 2015 by wipro.com. All rights reserved.
*
* Oct 14, 2015
* 
* @author Aditya
*
*
*/
package com.wipro.security.saml;




// TODO: Auto-generated Javadoc
/**
 * The Class UserDTO.
 *
 * @author Aditya
 * <p>Title: UserDTO</p>
 * 
 * <p>Description: User Data Transfer Object describing a User entity</p>
 */
public class UserDTO{
	
	/** The Constant CUSTOMER_ID. */
/*	public static final String CUSTOMER_ID="customerId";*/
	
	/** The Constant EMPLOYEE_ID. */
	/*public static final String EMPLOYEE_ID="employeeId";*/
	
	/** The Constant USER_ID. */
	public static final String USER_ID="userId";
	
	/** The Constant FIRST_NAME. */
	public static final String FIRST_NAME="firstName";
	
	/** The Constant LAST_NAME. */
	public static final String LAST_NAME="lastName";
	
	/** The Constant EMAIL_ID. */
	public static final String EMAIL_ID="emailId";
	
	/** The Constant ACCESS_TYPE. */
	/*public static final String ACCESS_TYPE="accessType";*/
	
	/** The Constant PERMISSION_LIST. */
	/*public static final String PERMISSION_LIST="permissionList";*/

	/** The customer id. */
	/*private String customerId;*/

	/** The employee id. */
	/*private String employeeId;*/
	
	/** The customer id. */
	private String userId;
	
	/** The first name. */
	private String firstName;

	/** The last name. */
	private String lastName;
	
	/** The customer id. */
	private String emailId;
	
	/** The access Type. */
	/*private String accessType;*/

	
	////////////////////////// READ ONLY, SYSTEM MANIPULATED FIELDS BEGINING////////////////////////////
	// All below fields are SYSTEM Fields, should not get copied to                                   //
	// User Entity Object. However they will be copied from User entity                               //
	// to UserDTO as read only fields                                                                 //
    //////////////////////////READ ONLY, SYSTEM MANIPULATED FIELDS /////////////////////////////////////

	
	/** The security qna failed validation attempt. */

	////////////////////////// READ ONLY, SYSTEM MANIPULATED FIELDS END     ////////////////////////////
	// All below fields are SYSTEM Fields, should not get copied to                                   //
	// User Entity Object. However they will be copied from User entity                               //
	// to UserDTO as read only fields                                                                 //
    //////////////////////////READ ONLY, SYSTEM MANIPULATED FIELDS /////////////////////////////////////
	
	////////////////////////// READ ONLY, USED FOR USER INTERFACE ONLY      ////////////////////////////
	// All below fields are UI  Fields, should not get copied to                                      //
	// User Entity Object. However they will be copied from User entity                               //
	// to UserDTO as read only fields                                                                 //
    /** The customer name. */
	//////////////////////////READ ONLY, SYSTEM MANIPULATED FIELDS /////////////////////////////////////
	
	
	/**
	 * Instantiates a new user dto.
	 */
	public UserDTO() {
			
	}

	
	/**
	 * Instantiates a new user dto.
	 * 
	 * @param customerId
	 * @param userId
	 * @param firstName
	 * @param lastName
	 * @param emailId
	 * @param employeeId
	 * @param accessType
	 * @param mobilePhone
	 * @param fax
	 * @param accountStartDate
	 */
	/*public UserDTO(String customerId, String userId, String firstName,
			String lastName, String emailId, String employeeId, String accessType,
			String mobilePhone, String fax,  Date accountStartDate) {
		this.customerId = customerId;
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.employeeId = employeeId;
		this.accessType = accessType;
	}*/
	
	
	public UserDTO(String customerId, String userId, String firstName,
			String lastName, String emailId) {
		/*this.customerId = customerId;*/
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		/*this.employeeId = employeeId;
		this.accessType = accessType;*/
	}


	
	/**
	 * Gets the user id.
	 *
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId            the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	
	/**
	 * Gets the first name.
	 *
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets the first name.
	 *
	 * @param firstName            the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	
	/**
	 * Gets the last name.
	 *
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Sets the last name.
	 *
	 * @param lastName            the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Gets the customer id.
	 *
	 * @return the customerId
	 */
	/*public String getCustomerId() {
		return customerId;
	}*/

	/**
	 * Sets the customer id.
	 *
	 * @param customerId            the customerId to set
	 */
	/*public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
*/

	/**
	 * @return the employeeId
	 */
	/*public String getEmployeeId() {
		return employeeId;
	}*/


	/**
	 * @param employeeId the employeeId to set
	 */
	/*public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}*/


	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}


	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	/**
	 * @return the accessType
	 */
	/*public String getAccessType() {
		return accessType;
	}*/


	/**
	 * @param accessType the accessType to set
	 */
	/*public void setAccessType(String accessType) {
		this.accessType = accessType;
	}*/


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	/*@Override*/
	/*public String toString() {
		return "UserDTO [userId=" + userId 
				+ ", employeeId=" + employeeId 
				+ ", firstName=" + firstName 
				+ ", lastName=" + lastName 
				+ ", customerId=" + customerId
				+ ", emailId=" + emailId
				+ ", accessType=" + accessType
				+ "]";
	}*/

	
	public String toString() {
		return "UserDTO [userId=" + userId 				
				+ ", firstName=" + firstName 
				+ ", lastName=" + lastName 				
				+ ", emailId=" + emailId
				
				+ "]";
	}

}
//sso changes - end