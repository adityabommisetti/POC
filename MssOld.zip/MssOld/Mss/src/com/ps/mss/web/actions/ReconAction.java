/*
 * $Id: ReconAction.java,v 1.1 2014/06/26 07:56:39 praveen Exp $
 */
package com.ps.mss.web.actions;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.web.helper.SessionHelper;

/**
 * @author deepak
 * <class> ReconAction <class> is use to forward request to appropriate action base on Last SelectedTab And Menu. 
 * 	Page is submit to ReconAction when we click Recon/demo link on home page. 
 */
public class ReconAction extends Action {
	private static Logger logger=LoggerFactory.getLogger(ReconAction.class);
	/* (non-Javadoc)
	 * @see org.apache.struts.action.Action#execute(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = new SessionHelper(request);
		String flag = request.getParameter("flag");
		//This block set customer Number.
		//in case of print, flag will be null so the following block will not be executed
		if(flag != null){
			String reconCustomerNo = null;
			if (Constants.DEMO_VERSION.equals(flag)){
				reconCustomerNo = Constants.DEMO_CUSTOMER_NUMBER;
			}else if(Constants.RECON_VERSION.equals(flag)) {
				reconCustomerNo = sessionHelper.getCustomerNumber();
			}
			sessionHelper.setReconCutomserNo(reconCustomerNo);
		}
		
		//in case of print request the following block need not to be executed
		/*
		 * It checks user has acessing same link(recon/demo) from home page.If he has switched between recon/demo
		 * then we clear all ui context for last visit.
		 */
		String lastVisitedLink = (String)sessionHelper.getAttribute(Constants.SESSION_LAST_USER_STATUS);
		String sessionLastUser = Constants.RECON_VERSION;
		boolean isSessionClear = false;
		if(lastVisitedLink != null){
			if (sessionHelper.isClickOnDemo() && !Constants.DEMO_VERSION.equals(lastVisitedLink)){
				isSessionClear = clearSessionStatus(sessionHelper);
				sessionHelper.setAttribute(Constants.SESSION_LAST_USER_STATUS,Constants.DEMO_VERSION);
			} else if(! sessionHelper.isClickOnDemo() && Constants.DEMO_VERSION.equals(lastVisitedLink)) {
				isSessionClear = clearSessionStatus(sessionHelper);
				sessionHelper.setAttribute(Constants.SESSION_LAST_USER_STATUS,Constants.RECON_VERSION);
			}
		} else {
			isSessionClear =  clearSessionStatus(sessionHelper);
			sessionHelper.setAttribute(Constants.SESSION_LAST_USER_STATUS,sessionHelper.isClickOnDemo() ? Constants.DEMO_VERSION : Constants.RECON_VERSION);
		}
		String url = "/dispatchAction.do?method=PaymentDashBoard";
		if(!isSessionClear){
			List lastSelectedMenuAndTab = (List) sessionHelper.getAttribute(Constants.SESSION_LAST_SELECTED_TAB);
			url = getUrl(lastSelectedMenuAndTab);
		}
		request.getRequestDispatcher(url).forward(request,response);
		logger.info(LoggerConstants.methodEndLevel());
		return null;		
	}
	
	/**
	 * @param lastSelectedMenuAndTab
	 * @return
	 */
	private String getUrl(List lastSelectedMenuAndTab) {
		logger.info(LoggerConstants.methodStartLevel());
		if(lastSelectedMenuAndTab != null) {
			String pageName = (String) lastSelectedMenuAndTab.get(0);
			String pageType = (String) lastSelectedMenuAndTab.get(1);
			String menuName = (String) lastSelectedMenuAndTab.get(2);
			logger.info(LoggerConstants.methodEndLevel());
			if (Constants.DISCREPANCY_DETAIL.equals(pageName))
				return "/discrepancyDetailAction.do?pageType="+ pageType+"&menuName="+menuName;
			else if(Constants.PROFILE_MENU.equals(menuName)) 
				return  "/searchProfileAction.do";
			else if("plan".equals(menuName) || Constants.BENEFICIARY_MENU.equals(menuName)) 
				return  "/dispatchAction.do?method="+pageName +"&pageType="+pageType+"&menuName="+menuName;
			else if(Constants.TROOP_MENU.equals(menuName)|| Constants.PDE_MENU.equals(menuName)) 
				return "/pdeTroopAction.do?method="+pageName +"&pageType="+pageType ;
			else if (Constants.PARTD_MENU.equals(menuName))
				return "/reinsuranceAction.do?method="+pageName +"&actionType=repaint" ;
		}	
		return "/dispatchAction.do?method=PaymentDashBoard";
	}

	/**
	 * This method clear all status which is save into session.
	 * @param sesHelper HttpSErvletRequest
	 * @throws ApplicationException
	 *
	 */
	private boolean clearSessionStatus(SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		//sessionHelper.setReconCutomserNo(sessionHelper.getCustomerNumber());
		sessionHelper.removeAttribute(Constants.SESSION_DISPLAY_DISCREPANCY_SUMMARY_PARTC);
		sessionHelper.removeAttribute(Constants.SESSION_DISPLAY_PAYMENT_SUMMARY_PARTC);
//		sessionHelper.removeAttribute(Constants.SESSION_PAYMENT_DESH_STATUS);
		//Remove all filter vo
		sessionHelper.removeAttribute(Constants.SESSION_PAYMENT_DASHBOARD_FILTERVO);
		sessionHelper.removeAttribute(Constants.SESSION_PAYMENT_SUMMARY_FILTERVO);
		sessionHelper.removeAttribute(Constants.SESSION_DISCREPANCY_DASHBOARD_FILTERVO);
		sessionHelper.removeAttribute(Constants.SESSION_DISCREPANCY_DETAIL_FILTERVO);
		sessionHelper.removeAttribute(Constants.SESSION_BENEFICIARY_DETAIL_FILTERVO) ;
		sessionHelper.removeAttribute(Constants.SESSION_DISCREPANCY_SUMMARY_FILTERVO);
		sessionHelper.removeAttribute(Constants.SESSION_BENEFICIARY_PYMT_DASHBOARD_FILTERVO);
		sessionHelper.removeAttribute(Constants.SESSION_BENEFICIARY_DISC_DASHBOARD_FILTERVO);
		sessionHelper.removeAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_FILTERVO);
		sessionHelper.removeAttribute(Constants.SESSION_PDE_DASHBOARD_FILTERVO);
		sessionHelper.removeAttribute(Constants.SESSION_PDE_EVENT_DETAIL_FILTERVO);
		sessionHelper.removeAttribute(Constants.SESSION_TROOP_DASHBOARD_FILTERVO);
		sessionHelper.removeAttribute(Constants.SESSION_TROOP_DETAIL_FILTERVO);
		sessionHelper.removeAttribute(Constants.SESSION_RECONCIALIATION_FILTERVO);
		sessionHelper.removeAttribute(Constants.SESSION_PYMT_DETAIL_POP_UP_FILTERVO);
		sessionHelper.removeAttribute(Constants.SESSION_DISABLE_SHOW_DISCREPANCY);
		
		//remove map
		sessionHelper.removeAttribute(Constants.SESSION_DISCREPANCY_DETAIL_MAP);
		sessionHelper.removeAttribute(Constants.SESSION_BENEFICIARY_DISCRP_DETAIL_MAP);
		sessionHelper.removeAttribute(Constants.SESSION_TROOP_DETAIL_MAP);
		sessionHelper.removeAttribute(Constants.SESSION_PDE_EVENT_DETAIL_MAP);
		sessionHelper.removeAttribute(Constants.SESSION_READ_ONLY_DISCRP_DETAIL_MAP);
		
		
		//remove tab
		sessionHelper.removeAttribute(Constants.BENEFICIARY_DISCRP_DETAIL_MENU);
		sessionHelper.removeAttribute(Constants.SESSION_BENEFICIARY_MENU_ACTIVE);
		sessionHelper.removeAttribute(Constants.SESSION_DISPLAY_DISCRP_DETAIL);
//		sessionHelper.removeAttribute(Constants.SESSION_DISPLAY_PAYMENT_SUMMARY_PARTC);
//		sessionHelper.removeAttribute(Constants.SESSION_DISPLAY_DISCREPANCY_SUMMARY_PARTC);
		sessionHelper.removeAttribute(Constants.SESSION_PDE_LAST_SELECTED_TAB);
		sessionHelper.removeAttribute(Constants.SESSION_TROOP_LAST_SELECTED_TAB);
		sessionHelper.removeAttribute(Constants.SESSION_PLAN_LAST_SELECTED_TAB);
		sessionHelper.removeAttribute(Constants.SESSION_BENEFICIARY_LAST_SELECTED_TAB);
		
		// remove all ui context.
//		sessionHelper.removeAttribute(Constants.SESSION_DISPLAY_DISCRP_DETAIL);
//		sessionHelper.removeAttribute(Constants.SESSION_DISPLAY_DISCREPANCY_SUMMARY_PARTC);
		sessionHelper.removeAttribute(Constants.SESSION_DISPLAY_TROOP_DETAIL);
		sessionHelper.removeAttribute(Constants.SESSION_DISPLAY_PDE_EVENT_DETAIL);
		sessionHelper.removeAttribute(Constants.SESSION_PAYMENT_DESH_STATUS);
		sessionHelper.removeAttribute(Constants.SESSION_DISCREPANCY_DESH_STATUS);
		sessionHelper.removeAttribute(Constants.SESSION_PAYMENT_SUMMARY_STATUS);
		sessionHelper.removeAttribute(Constants.SESSION_DISCREPANCY_DETAIL_STATUS);
		sessionHelper.removeAttribute(Constants.SESSION_DISCREPANCY_SUMMARY_STATUS);
		sessionHelper.removeAttribute(Constants.SESSION_BENEFICIARY_PYMT_DESH_STATUS);
		sessionHelper.removeAttribute(Constants.SESSION_BENEFICIARY_DISCREPANCY_DESH_STATUS);
		sessionHelper.removeAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_STATUS);
		sessionHelper.removeAttribute(Constants.SESSION_BENEFICIARY_DISCRP_DETAIL_STATUS);
//		sessionHelper.removeAttribute(Constants.SESSION_BENEFICIARY_PYMT_DESH_STATUS);
		sessionHelper.removeAttribute(Constants.SESSION_PDE_DESH_STATUS);
		sessionHelper.removeAttribute(Constants.SESSION_PDE_EVENT_DETAIL_STATUS);
		sessionHelper.removeAttribute(Constants.SESSION_SHOW_PAYMENT_SUMMARY_STATUS);
		sessionHelper.removeAttribute(Constants.SESSION_SHOW_DISCREPANCY_SUMMARY_STATUS);
		sessionHelper.removeAttribute(Constants.SESSION_BENEFICIARY_SHOW_PYMT_SUMMARY_STATUS);
		sessionHelper.removeAttribute(Constants.SESSION_BENEFICIARY_SHOW_DISCRP_DETAIL_STATUS);
		sessionHelper.removeAttribute(Constants.SESSION_TROOP_DESH_STATUS);
		sessionHelper.removeAttribute(Constants.SESSION_TROOP_DETAIL_STATUS);
		
		
		
		sessionHelper.removeAttribute(Constants.SESSION_PROFILE_DETAIL_MAP);
		sessionHelper.removeAttribute(Constants.SESSION_PROFILE_DETAIL_FILTERVO);
//		sessionHelper.removeAttribute(Constants.SESSION_PROFILE_DETAIL_MAP);
		sessionHelper.removeAttribute(Constants.SESSION_PROFILE_DATE_RANGE);
		sessionHelper.removeAttribute(Constants.SESSION_PROFILE_PLAN_PBP_SGMT);
		sessionHelper.removeAttribute(Constants.SESSION_PROFILE_LAST_SELECTED_TAB);
		sessionHelper.removeAttribute(Constants.SESSION_PARTD_LAST_SELECTED_TAB);
		sessionHelper.removeAttribute(Constants.SESSION_REINSURANCE_FORM);
		logger.info(LoggerConstants.methodEndLevel());
		return true;
	}
	
}
