/*
 * $Id: DispatchAction.java,v 1.1 2014/06/26 07:56:41 praveen Exp $
 */
package com.ps.mss.web.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;
import com.ps.mss.framework.Constants;
import com.ps.mss.web.forms.BaseForm;
import com.ps.mss.web.helper.DispatchActionHelper;
import com.ps.mss.web.helper.SessionHelper;

/**
 * @version 	1.0
 * @author deepak
 * 
 * This Action class is corresponding to DispatchAction.do action.It will called by struts framwork.
 * This class set form bean which is used to populate jsp's.
 */
public class DispatchAction extends org.apache.struts.actions.DispatchAction {
	private static Logger logger=LoggerFactory.getLogger(DispatchAction.class);
	ModuleLog log = new ModuleLog("DispatchAction");
	
	/**
	 * This method of dispatch Action is called to move on home page
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward showHome(ActionMapping mapping, ActionForm form, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		return mapping.findForward("homePage");
	}
	
	/**
	 * This method of dispach Action is invoke by client(UI) to get paymentDashboar(in both plan and beneficiary menu)
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward PaymentDashBoard(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sesHelper = new SessionHelper(request);
		BaseForm baseForm = (BaseForm) form;
		String targetResult = "";
		DispatchActionHelper sessionHelper =  new DispatchActionHelper();
		
		//for print request set the base form's menu name from request parameter's value 
		if(request.getParameter("print") !=  null){
			baseForm.setMenuName(request.getParameter("menuName"));
		}
		
		sessionHelper.getPaymentDashboard(request,baseForm);
		// checking response target
		if(request.getParameter("print") !=  null){
			targetResult = "printPaymentDashBoard";
		}else if (Constants.BENEFICIARY_MENU.equals(baseForm.getMenuName())) { 
			targetResult = "beneficiaryPymtDeshboard";
			sesHelper.setAttribute(Constants.SESSION_BENEFICIARY_MENU_ACTIVE,"true");
			DispatchActionHelper.setTabAndFormName(request, Constants.BENEFICIARY_MENU, "BaseForm");
		} else {
			sesHelper.removeAttribute(Constants.SESSION_BENEFICIARY_MENU_ACTIVE);
			targetResult = "reconDashBoard";
			DispatchActionHelper.setTabAndFormName(request, Constants.PLAN_MENU, "BaseForm");
		}
		baseForm.init(request);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(targetResult);
	}
	
	/**
	 * This method is invoke by client(UI) to get payment summary and beneficiary payment detail.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward PaymentSummary(ActionMapping mapping, ActionForm form, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		String targetResult = "error";
		BaseForm baseForm = (BaseForm) form;
		DispatchActionHelper sessionHelper =  new DispatchActionHelper();
		SessionHelper sesHelper = new SessionHelper(request);
		String menuName = null;
		if(baseForm.getMenuName()==null && request.getParameter("menuName")!=null){
			baseForm.setMenuName(request.getParameter("menuName"));
		}
		baseForm.init(request);
		
		sessionHelper.getPaymentSummary(request, baseForm);
		//  checking response target
		if(request.getParameter("print")!=null){
			if(Constants.BENEFICIARY_MENU.equals(baseForm.getMenuName())){
				targetResult = "printBeneficiaryPymtDetail";
			}else if(Constants.PAYMENT_DETAIL.equals(baseForm.getMenuName())){
				targetResult = "printPaymentPopUp";
			}else{
				targetResult = "printPaymentSummary";
			}
		} else {
			if(Constants.PAYMENT_DETAIL.equals(baseForm.getMenuName())){
				targetResult = "pymtDetailPopUp";
			} else if(Constants.BENEFICIARY_MENU.equals(baseForm.getMenuName()) || request.getParameter("pymtDetail")!=null){
				sesHelper.setAttribute(Constants.SESSION_BENEFICIARY_MENU_ACTIVE,"true");
				// checking is request for show Payment in Beneficiary Menu
				if(Constants.READ_ONLY.equals(baseForm.getPageType()))
					targetResult = "showBeneficiaryPaymentDetail";
				else
					targetResult = "beneficiaryPymtDetail";
				DispatchActionHelper.setTabAndFormName(request, Constants.BENEFICIARY_MENU, "BaseForm");
			} else {
				sesHelper.removeAttribute(Constants.SESSION_BENEFICIARY_MENU_ACTIVE);
				if(Constants.READ_ONLY.equals(baseForm.getPageType()))
					targetResult = "showPaymentSummary";
				else 
					targetResult= "paymentSummary";
				DispatchActionHelper.setTabAndFormName(request, Constants.PLAN_MENU, "BaseForm");
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(targetResult);
	}
	
	
	/**
	 * This method is invoke by client(UI) to get discrepancy dashboard (in both plan and beneficiary menu)
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward DiscrepancyDashBoard(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		String targetResult = "error";
		BaseForm baseForm = (BaseForm) form;
		SessionHelper sesHelper = new SessionHelper(request);
		DispatchActionHelper sessionHelper =  new DispatchActionHelper();

		//for print request set the base form's menu name from request parameter's value 
		if(request.getParameter("print") !=  null){
			baseForm.setMenuName(request.getParameter("menuName"));
		}

		sessionHelper.getDiscrepancyDashBoard(request,baseForm);
		// checking response target
		if(request.getParameter("print") !=  null)
			targetResult = "printDiscrepancyDashBoard";
		else if (Constants.BENEFICIARY_MENU.equals(baseForm.getMenuName())) {  
			targetResult = "beneficiaryDiscrpDeshboard";
			sesHelper.setAttribute(Constants.SESSION_BENEFICIARY_MENU_ACTIVE,"true");
			DispatchActionHelper.setTabAndFormName(request, Constants.BENEFICIARY_MENU, "BaseForm");
		} else {
			sesHelper.removeAttribute(Constants.SESSION_BENEFICIARY_MENU_ACTIVE);
			targetResult = "discrepancyDashBoard";
			DispatchActionHelper.setTabAndFormName(request, Constants.PLAN_MENU, "BaseForm");
		}
		baseForm.init(request);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(targetResult);
	}
	
	/**
	 * This method is invoke by client(UI) to get discrepancy summary.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward DiscrepancySummary(ActionMapping mapping, ActionForm form, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		String targetResult = "error";
		BaseForm baseForm = (BaseForm) form;
		baseForm.init(request);
		DispatchActionHelper sessionHelper =  new DispatchActionHelper();
		sessionHelper.getDiscrepancySummary(request,baseForm);
		
		// checking response target
		if(request.getParameter("print")!= null) {
			targetResult = "printDiscrepancySummary";
		}else if(Constants.READ_ONLY.equals(baseForm.getPageType()))
			targetResult = "showDiscrepancySummary";
		else 
			targetResult = "discrepancySummary";
		DispatchActionHelper.setTabAndFormName(request, Constants.PLAN_MENU, "BaseForm");
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(targetResult);
	}
	
	
	/**
	 * This method is invoke by client(UI) to get payment detail on effective date which is then populate on
	 * payment effetive popup (on payment detail page).
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward PymtEffDateDetail(ActionMapping mapping, ActionForm form, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		String targetResult = "error";
		BaseForm baseForm = (BaseForm) form;
		if(baseForm.getFromDate()==null && request.getParameter("fromDate")!=null)
			baseForm.setFromDate((String)request.getParameter("fromDate"));
		if(baseForm.getMenuName()==null && request.getParameter("menuName")!=null)
			baseForm.setMenuName((String)request.getParameter("menuName"));
		if(baseForm.getPageType()==null && request.getParameter("pageType")!=null)
			baseForm.setMenuName((String)request.getParameter("pageType"));

		DispatchActionHelper sessionHelper =  new DispatchActionHelper();
		sessionHelper.pymtEffDateDetail(request,baseForm);
		//checking response target
		if(request.getParameter("print")!=null)
			targetResult = "printPymtEffDateDetail";
		else
			targetResult = "pymtEffDateDetail";
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(targetResult);
	}
	/**
	 * This method is invoke by client(UI) to get disease group detail which is then populate in diseaseGroup pop.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward DiseaseGroupDetail(ActionMapping mapping, ActionForm form, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		String targetResult = "error";
		BaseForm baseForm = (BaseForm) form;
		DispatchActionHelper sessionHelper =  new DispatchActionHelper();
		
		if(request.getParameter("print")!=null){
			//For Print specifying response target and set form 
			targetResult = "printDiseaseGroup";
			baseForm.setFromDate((String)request.getParameter("fromDate"));
			baseForm.setMenuName((String)request.getParameter("menuName"));
			baseForm.setPartName((String)request.getParameter("partName"));
		}else
			targetResult = "diseaseGroup";
		
		sessionHelper.diseaseGroupDetail(request,baseForm);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(targetResult);
	}
	
	/**
	 * This method is invoke by client(UI) to get Reconciliation pop.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward Reconciliation(ActionMapping mapping, ActionForm form, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		String targetResult = "error";
		BaseForm baseForm = (BaseForm) form;
		
		if(request.getParameter("print")!=null){
			//For Print specifying response target and set form 
			targetResult = "printReconciliation";
			baseForm.setFromDate((String)request.getParameter("fromDate"));
			baseForm.setMenuName((String)request.getParameter("menuName"));
			baseForm.setPartName((String)request.getParameter("partName"));
			baseForm.setPlanName((String)request.getParameter("planName"));
		}else
			targetResult = "reconciliation";
		
		DispatchActionHelper sessionHelper =  new DispatchActionHelper();
		sessionHelper.reconciliation(request,baseForm);
				
		
		baseForm.init(request);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(targetResult);
	}
}
