package com.ps.mss.web.forms;

import java.util.List;

/**
 * @author Dinesh Kumar
 *
 */
public class EEMEnrollLtcSearchForm extends EEMForm {

	private static final long serialVersionUID = 2911782414136925182L;

	private String customerId;
	private String memberId;
	private String effDate;
	private String ltcFacId;
	private String facilityName;
	private String facilityAddress;
	private String facilityCity;
	private String facilityState;
	private String facilityZipCode;
	private List searchResults;

	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId
	 *            the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the memberId
	 */
	public String getMemberId() {
		return memberId;
	}

	/**
	 * @param memberId
	 *            the memberId to set
	 */
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	/**
	 * @return the effDate
	 */
	public String getEffDate() {
		return effDate;
	}

	/**
	 * @param effDate the effDate to set
	 */
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}

	/**
	 * @return the ltcFacId
	 */
	public String getLtcFacId() {
		return ltcFacId;
	}

	/**
	 * @param ltcFacId
	 *            the ltcFacId to set
	 */
	public void setLtcFacId(String ltcFacId) {
		this.ltcFacId = ltcFacId;
	}

	/**
	 * @return the facilityName
	 */
	public String getFacilityName() {
		return facilityName;
	}

	/**
	 * @param facilityName
	 *            the facilityName to set
	 */
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	/**
	 * @return the facilityAddress
	 */
	public String getFacilityAddress() {
		return facilityAddress;
	}

	/**
	 * @param facilityAddress
	 *            the facilityAddress to set
	 */
	public void setFacilityAddress(String facilityAddress) {
		this.facilityAddress = facilityAddress;
	}

	/**
	 * @return the facilityCity
	 */
	public String getFacilityCity() {
		return facilityCity;
	}

	/**
	 * @param facilityCity
	 *            the facilityCity to set
	 */
	public void setFacilityCity(String facilityCity) {
		this.facilityCity = facilityCity;
	}

	/**
	 * @return the facilityState
	 */
	public String getFacilityState() {
		return facilityState;
	}

	/**
	 * @param facilityState
	 *            the facilityState to set
	 */
	public void setFacilityState(String facilityState) {
		this.facilityState = facilityState;
	}

	/**
	 * @return the facilityZipCode
	 */
	public String getFacilityZipCode() {
		return facilityZipCode;
	}

	/**
	 * @param facilityZipCode
	 *            the facilityZipCode to set
	 */
	public void setFacilityZipCode(String facilityZipCode) {
		this.facilityZipCode = facilityZipCode;
	}

	/**
	 * @return the searchResults
	 */
	public List getSearchResults() {
		return searchResults;
	}

	/**
	 * @param searchResults
	 *            the searchResults to set
	 */
	public void setSearchResults(List searchResults) {
		this.searchResults = searchResults;
	}
}