package com.ps.mss.web.forms;

import java.util.Date;
import java.util.List;

import com.ps.mss.dao.model.EmBBBDraftDetailVO;
import com.ps.mss.dao.model.EmBBBDraftHeaderVO;
import com.ps.mss.dao.model.EmBBBInvoiceDetailVO;
import com.ps.mss.dao.model.EmBBBInvoiceHeaderVO;
import com.ps.mss.dao.model.EmMbrCommentVO;
import com.ps.mss.model.EMMbrDraftSummaryVO;
import com.ps.mss.model.EMMbrInvoiceSummaryVO;

public class EEMBillDraftForm extends EEMSubMenuForm {

	private String searchInvoiceNbr;
	private String searchInvoiceId;
	
	private String searchDraftStatus;
	
	private String searchInvoiceType;
	private String searchInvoiceGroup;
	private String searchLastName;
	private String searchHicNbr;
	
	private List lstDraftStatus;
	private List lstUpdDraftStatus;
	
	private String accountType;
	private List lstAccountType;
	
	private List lstFunctionCode;
	private List lstInvoiceType;
	private List lstInvoiceGroup;
	private List lstRelatedInvoiceType;
	
	private boolean searchExpanded;
	private int selectedSearchRow;

	private List listSearchResults;
	private EmBBBDraftHeaderVO displayInvoiceHeader;
	
	private boolean detailListExpanded=true;
	private int selectedDetailRow;
	private String detailDisplayState;
	private String detailDisplayStateForMember;
	private List listDetail;
	private EMMbrDraftSummaryVO displayDraftSummary = new EMMbrDraftSummaryVO();
	private EmBBBDraftDetailVO displayDraftDetail = new EmBBBDraftDetailVO();
	private EmBBBDraftDetailVO displayDraftDetailForMember = new EmBBBDraftDetailVO();
	
	private List listComments;
	private int topDisplayCommentRow;
	private int selectedCommentRow;
	private boolean commentChanged;
	private String commentDisplayState;
	private boolean commentsExpanded;
	
	private boolean transExpanded = false;
	private String transGrpId;
	private String transName;
	private String transAmt;
	private String transDetailAmt;
	private String searchTransGrp;
	private String searchTransName;
	private String searchTransLastName;
	
	private String searchSupplId;
	
	public String getSearchSupplId() {
		return searchSupplId;
	}
	public void setSearchSupplId(String searchSupplId) {
		this.searchSupplId = searchSupplId;
	}

	
	
	private String settlementDate;

	public String getSearchInvoiceId() {
		return searchInvoiceId;
	}
	public void setSearchInvoiceId(String searchInvoiceId) {
		this.searchInvoiceId = searchInvoiceId;
	}
	public String getSearchInvoiceNbr() {
		return searchInvoiceNbr;
	}
	public void setSearchInvoiceNbr(String searchInvoiceNbr) {
		this.searchInvoiceNbr = searchInvoiceNbr;
	}
	
	public boolean getSearchExpanded() {
		return searchExpanded;
	}
	public void setSearchExpanded(boolean searchExpanded) {
		this.searchExpanded = searchExpanded;
	}

	public List getListSearchResults() {
		return listSearchResults;
	}
	public void setListSearchResults(List listSearchResults) {
		this.listSearchResults = listSearchResults;
	}
	public int getSelectedSearchRow() {
		return selectedSearchRow;
	}
	public void setSelectedSearchRow(int selectedSearchRow) {
		this.selectedSearchRow = selectedSearchRow;
	}
	
	public EmBBBDraftHeaderVO getDisplayInvoiceHeader() {
		return displayInvoiceHeader;
	}
	public void setDisplayInvoiceHeader(EmBBBDraftHeaderVO displayInvoiceHeader) {
		this.displayInvoiceHeader = displayInvoiceHeader;
	}
	public EMMbrDraftSummaryVO getDisplayDraftSummary() {
		return displayDraftSummary;
	}
	public void setDisplayDraftSummary(EMMbrDraftSummaryVO displayDraftSummary) {
		this.displayDraftSummary = displayDraftSummary;
	}
	public EmBBBDraftDetailVO getDisplayDraftDetail() {
		return displayDraftDetail;
	}
	public void setDisplayDraftDetail(
			EmBBBDraftDetailVO displayInvoiceDetail) {
		this.displayDraftDetail = displayInvoiceDetail;
	}
	
	public EmBBBDraftDetailVO getDisplayDraftDetailForMember() {
		return displayDraftDetailForMember;
	}
	public void setDisplayDraftDetailForMember(
			EmBBBDraftDetailVO displayDraftDetailForMember) {
		this.displayDraftDetailForMember = displayDraftDetailForMember;
	}
	public List getListDetail() {
		return listDetail;
	}
	public void setListDetail(List listDetail) {
		this.listDetail = listDetail;
	}
	public int getSelectedDetailRow() {
		return selectedDetailRow;
	}
	public void setSelectedDetailRow(int selectedDetailRow) {
		this.selectedDetailRow = selectedDetailRow;
	}
	public boolean isDetailListExpanded() {
		return detailListExpanded;
	}
	public void setDetailListExpanded(boolean detailListExpanded) {
		this.detailListExpanded = detailListExpanded;
	}
	public List getLstDraftStatus() {
		return lstDraftStatus;
	}
	public void setLstDraftStatus(List lstDraftStatus) {
		this.lstDraftStatus = lstDraftStatus;
	}
	public List getLstUpdDraftStatus() {
		return lstUpdDraftStatus;
	}
	public void setLstUpdDraftStatus(List lstUpdDraftStatus) {
		this.lstUpdDraftStatus = lstUpdDraftStatus;
	}
	public String getSearchDraftStatus() {
		return searchDraftStatus;
	}
	public void setSearchDraftStatus(String searchDraftStatus) {
		this.searchDraftStatus = searchDraftStatus;
	}
	public String getCommentDisplayState() {
		return commentDisplayState;
	}
	public void setCommentDisplayState(String commentDisplayState) {
		this.commentDisplayState = commentDisplayState;
	}
	public List getListComments() {
		return listComments;
	}
	public void setListComments(List listComments) {
		this.listComments = listComments;
	}
	public boolean isCommentChanged() {
		return commentChanged;
	}
	public void setCommentChanged(boolean commentChanged) {
		this.commentChanged = commentChanged;
	}
	public int getSelectedCommentRow() {
		return selectedCommentRow;
	}
	public void setSelectedCommentRow(int selectedCommentRow) {
		this.selectedCommentRow = selectedCommentRow;
	}
	public int getTopDisplayCommentRow() {
		return topDisplayCommentRow;
	}
	public void setTopDisplayCommentRow(int topDisplayCommentRow) {
		this.topDisplayCommentRow = topDisplayCommentRow;
	}
	public boolean isCommentsExpanded() {
		return commentsExpanded;
	}
	public void setCommentsExpanded(boolean commentsExpanded) {
		this.commentsExpanded = commentsExpanded;
	}
	public String getDetailDisplayState() {
		return detailDisplayState;
	}
	public void setDetailDisplayState(String detailDisplayState) {
		this.detailDisplayState = detailDisplayState;
	}
	public String getDetailDisplayStateForMember() {
		return detailDisplayStateForMember;
	}
	public void setDetailDisplayStateForMember(String detailDisplayStateForMember) {
		this.detailDisplayStateForMember = detailDisplayStateForMember;
	}
	public List getLstFunctionCode() {
		return lstFunctionCode;
	}
	public void setLstFunctionCode(List lstFunctionCode) {
		this.lstFunctionCode = lstFunctionCode;
	}
	public List getLstInvoiceType() {
		return lstInvoiceType;
	}
	public void setLstInvoiceType(List lstInvoiceType) {
		this.lstInvoiceType = lstInvoiceType;
	}
	public String getSearchInvoiceType() {
		return searchInvoiceType;
	}
	public void setSearchInvoiceType(String searchInvoiceType) {
		this.searchInvoiceType = searchInvoiceType;
	}
	public String getSearchLastName() {
		return searchLastName;
	}
	public void setSearchLastName(String searchLastName) {
		this.searchLastName = searchLastName;
	}
	public String getSearchHicNbr() {
		return searchHicNbr;
	}
	public void setSearchHicNbr(String searchHicNbr) {
		this.searchHicNbr = searchHicNbr;
	}
	public String getSearchInvoiceGroup() {
		return searchInvoiceGroup;
	}
	public void setSearchInvoiceGroup(String searchInvoiceGroup) {
		this.searchInvoiceGroup = searchInvoiceGroup;
	}
	public List getLstInvoiceGroup() {
		return lstInvoiceGroup;
	}
	public void setLstInvoiceGroup(List lstInvoiceGroup) {
		this.lstInvoiceGroup = lstInvoiceGroup;
	}
	public List getLstRelatedInvoiceType() {
		return lstRelatedInvoiceType;
	}
	public void setLstRelatedInvoiceType(List lstRelatedInvoiceType) {
		this.lstRelatedInvoiceType = lstRelatedInvoiceType;
	}
	/**
	 * @return Returns the transAmt.
	 */
	public String getTransAmt() {
		return transAmt;
	}
	/**
	 * @param transAmt The transAmt to set.
	 */
	public void setTransAmt(String transAmt) {
		this.transAmt = transAmt;
	}
	/**
	 * @return Returns the transGrpId.
	 */
	public String getTransGrpId() {
		return transGrpId;
	}
	/**
	 * @param transGrpId The transGrpId to set.
	 */
	public void setTransGrpId(String transGrpId) {
		this.transGrpId = transGrpId;
	}
	/**
	 * @return Returns the transName.
	 */
	public String getTransName() {
		return transName;
	}
	/**
	 * @param transName The transName to set.
	 */
	public void setTransName(String transName) {
		this.transName = transName;
	}
	/**
	 * @return Returns the transDetailAmt.
	 */
	public String getTransDetailAmt() {
		return transDetailAmt;
	}
	/**
	 * @param transDetailAmt The transDetailAmt to set.
	 */
	public void setTransDetailAmt(String transDetailAmt) {
		this.transDetailAmt = transDetailAmt;
	}
	/**
	 * @return Returns the transExpanded.
	 */
	public boolean isTransExpanded() {
		return transExpanded;
	}
	/**
	 * @param transExpanded The transExpanded to set.
	 */
	public void setTransExpanded(boolean transExpanded) {
		this.transExpanded = transExpanded;
	}
	/**
	 * @return Returns the searchTransGrp.
	 */
	public String getSearchTransGrp() {
		return searchTransGrp;
	}
	/**
	 * @param searchTransGrp The searchTransGrp to set.
	 */
	public void setSearchTransGrp(String searchTransGrp) {
		this.searchTransGrp = searchTransGrp;
	}
	/**
	 * @return Returns the searchTransName.
	 */
	public String getSearchTransName() {
		return searchTransName;
	}
	/**
	 * @param searchTransName The searchTransName to set.
	 */
	public void setSearchTransName(String searchTransName) {
		this.searchTransName = searchTransName;
	}
	/**
	 * @return Returns the searchTransLastName.
	 */
	public String getSearchTransLastName() {
		return searchTransLastName;
	}
	/**
	 * @param searchTransLastName The searchTransLastName to set.
	 */
	public void setSearchTransLastName(String searchTransLastName) {
		this.searchTransLastName = searchTransLastName;
	}
	public String getSettlementDate() {
		return settlementDate;
	}
	public void setSettlementDate(String settlementDate) {
		this.settlementDate = settlementDate;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public List getLstAccountType() {
		return lstAccountType;
	}
	public void setLstAccountType(List lstAccountType) {
		this.lstAccountType = lstAccountType;
	}
}
