/*
 * $Id: EEMBillPaymentsForm.java,v 1.1 2014/06/26 07:55:46 praveen Exp $
 */
package com.ps.mss.web.forms;

import java.util.List;

import com.ps.mss.dao.model.EmBBBPaymentsDetailVO;
import com.ps.mss.dao.model.EmBBBPaymentsHeaderVO;
import com.ps.util.ListBoxItem;

public class EEMBillPaymentsForm extends EEMSubMenuForm {

	private String searchPaySource;
	private String searchBatchDate;
	private String searchBatchSeqNbr;
	private String searchBatchBalance;
	private ListBoxItem[] lstBatchBalance;
	private List lstPaySource;

	private boolean searchExpanded;
	private int selectedSearchRow;
	private String headerDisplayState;
	private List listSearchResults;
	private EmBBBPaymentsHeaderVO displayPaymentsHeader = new EmBBBPaymentsHeaderVO();
	
	private boolean detailListExpanded=true;
	private int selectedDetailRow;
	private String detailDisplayState;
	private List listDetail;
	private EmBBBPaymentsDetailVO displayPaymentsDetail = new EmBBBPaymentsDetailVO();
	
	private boolean newPaymentScreen=false;
	private String newHeaderDisplayState;
	private String[] invoiceId;
	private String[] checkDate;
	private String[] checkNbr;
	private String[] paymentAmt;
	private List lstDetailRows;
	
	private String itemNumber;
	private String memberId;
	private String posted;

	public String getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getPosted() {
		return posted;
	}
	public void setPosted(String posted) {
		this.posted = posted;
	}
	
	public String getSearchPaySource() {
		return searchPaySource;
	}
	public void setSearchPaySource(String searchPaySource) {
		this.searchPaySource = searchPaySource;
	}
	public EmBBBPaymentsHeaderVO getDisplayPaymentsHeader() {
		return displayPaymentsHeader;
	}
	public void setDisplayPaymentsHeader(
			EmBBBPaymentsHeaderVO displayPaymentsHeader) {
		this.displayPaymentsHeader = displayPaymentsHeader;
	}
	public List getListSearchResults() {
		return listSearchResults;
	}
	public void setListSearchResults(List listSearchResults) {
		this.listSearchResults = listSearchResults;
	}
	public boolean isSearchExpanded() {
		return searchExpanded;
	}
	public void setSearchExpanded(boolean searchExpanded) {
		this.searchExpanded = searchExpanded;
	}
	public int getSelectedSearchRow() {
		return selectedSearchRow;
	}
	public void setSelectedSearchRow(int selectedSearchRow) {
		this.selectedSearchRow = selectedSearchRow;
	}
	public List getLstPaySource() {
		return lstPaySource;
	}
	public void setLstPaySource(List lstPaySource) {
		this.lstPaySource = lstPaySource;
	}
	public String getDetailDisplayState() {
		return detailDisplayState;
	}
	public void setDetailDisplayState(String detailDisplayState) {
		this.detailDisplayState = detailDisplayState;
	}
	public boolean isDetailListExpanded() {
		return detailListExpanded;
	}
	public void setDetailListExpanded(boolean detailListExpanded) {
		this.detailListExpanded = detailListExpanded;
	}
	public EmBBBPaymentsDetailVO getDisplayPaymentsDetail() {
		return displayPaymentsDetail;
	}
	public void setDisplayPaymentsDetail(
			EmBBBPaymentsDetailVO displayPaymentsDetail) {
		this.displayPaymentsDetail = displayPaymentsDetail;
	}
	public List getListDetail() {
		return listDetail;
	}
	public void setListDetail(List listDetail) {
		this.listDetail = listDetail;
	}
	public int getSelectedDetailRow() {
		return selectedDetailRow;
	}
	public void setSelectedDetailRow(int selectedDetailRow) {
		this.selectedDetailRow = selectedDetailRow;
	}
	public String getHeaderDisplayState() {
		return headerDisplayState;
	}
	public void setHeaderDisplayState(String headerDisplayState) {
		this.headerDisplayState = headerDisplayState;
	}
	public boolean isNewPaymentScreen() {
		return newPaymentScreen;
	}
	public void setNewPaymentScreen(boolean newPaymentScreen) {
		this.newPaymentScreen = newPaymentScreen;
	}
	public String[] getCheckDate() {
		return checkDate;
	}
	public void setCheckDate(String[] checkDate) {
		this.checkDate = checkDate;
	}
	public String[] getCheckNbr() {
		return checkNbr;
	}
	public void setCheckNbr(String[] checkNbr) {
		this.checkNbr = checkNbr;
	}
	public String[] getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(String[] invoiceId) {
		this.invoiceId = invoiceId;
	}
	public List getLstDetailRows() {
		return lstDetailRows;
	}
	public void setLstDetailRows(List lstDetailRows) {
		this.lstDetailRows = lstDetailRows;
	}
	public String[] getPaymentAmt() {
		return paymentAmt;
	}
	public void setPaymentAmt(String[] paymentAmt) {
		this.paymentAmt = paymentAmt;
	}
	public String getNewHeaderDisplayState() {
		return newHeaderDisplayState;
	}
	public void setNewHeaderDisplayState(String newHeaderDisplayState) {
		this.newHeaderDisplayState = newHeaderDisplayState;
	}
	public String getSearchBatchBalance() {
		return searchBatchBalance;
	}
	public void setSearchBatchBalance(String searchBatchBalance) {
		this.searchBatchBalance = searchBatchBalance;
	}
	public String getSearchBatchDate() {
		return searchBatchDate;
	}
	public void setSearchBatchDate(String searchBatchDate) {
		this.searchBatchDate = searchBatchDate;
	}
	public String getSearchBatchSeqNbr() {
		return searchBatchSeqNbr;
	}
	public void setSearchBatchSeqNbr(String searchBatchSeqNbr) {
		this.searchBatchSeqNbr = searchBatchSeqNbr;
	}
	public ListBoxItem[] getLstBatchBalance() {
		return lstBatchBalance;
	}
	public void setLstBatchBalance(ListBoxItem[] lstBatchBalance) {
		this.lstBatchBalance = lstBatchBalance;
	}
	
    private String searchSupplId;
	
	public String getSearchSupplId() {
		return searchSupplId;
	}
	public void setSearchSupplId(String searchSupplId) {
		this.searchSupplId = searchSupplId;
	}
}
