/*
 * $Id: LettersForm.java,v 1.1 2014/06/26 07:55:47 praveen Exp $
 */
package com.ps.mss.web.forms;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.ps.mss.model.LettersDataItem;
import com.ps.mss.model.LettersListItem;

/**
 * @author levin.alex
 */
public class LettersForm extends ActionForm {
	
	private String fileId;
	private String memberId;
    private String supplementalId;
    private String letterNbr;
    private String status;
    private String requestor;
    private String deleteInd;    
    private String requestDateFrom;
    private String requestDateTo;
    private LettersDataItem[] lettersDataItem;
    private LettersListItem[] lettersListItem;
    
    private String drillStatus;
    private String drillDeleteInd;
    
    private String method;
    private String uiContext;
    private String pageName;
    private String region;
    
    private Object pageInfo; //holds page info, e.g. the whole thing on Letters pages.
    
    private String pageType = "";
    private String searchType;

    /**
	 * @return Returns the memberId.
	 */
	public String getMemberId() {
		return memberId;
	}
	/**
	 * @param memberId The memberId to set.
	 */
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	
	/**
	 * @return Returns the supplementalId.
	 */
	public String getSupplementalId() {
		return supplementalId;
	}
	/**
	 * @param supplementalId The supplementalId to set.
	 */
	public void setSupplementalId(String supplementalId) {
		this.supplementalId = supplementalId;
	}
	
	/**
	 * @return Returns the letterNbr.
	 */
	public String getLetterNbr() {
		return letterNbr;
	}
	/**
	 * @param letterNbr The letterNbr to set.
	 */
	public void setLetterNbr(String letterNbr) {
		this.letterNbr = letterNbr;
	}
	
	/**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * @return Returns the requestor.
	 */
	public String getRequestor() {
		return requestor;
	}
	/**
	 * @param requestor The requestor to set.
	 */
	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}
	
	/**
	 * @return Returns the deleteInd.
	 */
	public String getDeleteInd() {
		return deleteInd;
	}
	/**
	 * @param deleteInd The deleteInd to set.
	 */
	public void setDeleteInd(String deleteInd) {
		this.deleteInd = deleteInd;
	}
	
	/**
	 * @return Returns the requestDateFrom.
	 */
	public String getRequestDateFrom() {
		return requestDateFrom;
	}
	/**
	 * @param requestDateFrom The requestDateFrom to set.
	 */
	public void setRequestDateFrom(String requestDateFrom) {
		this.requestDateFrom = requestDateFrom;
	}
	
	/**
	 * @return Returns the requestDateTo.
	 */
	public String getRequestDateTo() {
		return requestDateTo;
	}
	/**
	 * @param requestDateTo The requestDateTo to set.
	 */
	public void setRequestDateTo(String requestDateTo) {
		this.requestDateTo = requestDateTo;
	}
	
	/**
	 * @return Returns the lettersDataItem.
	 */
	public LettersDataItem[] getLettersDataItem() {
		return lettersDataItem;
	}
	/**
	 * @param lettersDataItem The lettersDataItem to set.
	 */
	public void setLettersDataItem(LettersDataItem[] lettersDataItem) {
		this.lettersDataItem = lettersDataItem;
	}
	
	/**
	 * @return Returns the lettersListItem.
	 */
	public LettersListItem[] getLettersListItem() {
		return lettersListItem;
	}
	/**
	 * @param lettersListItem The lettersListItem to set.
	 */
	public void setLettersListItem(LettersListItem[] lettersListItem) {
		this.lettersListItem = lettersListItem;
	}
	
	/**
	 * @return Returns the method.
	 */
	public String getMethod() {
		return method;
	}
	/**
	 * @param method The method to set.
	 */
	public void setMethod(String method) {
		this.method = method;
	}
	
	/**
	 * @return Returns the uiContext.
	 */
	public String getUiContext() {
		return uiContext;
	}
	/**
	 * @param uiContext The uiContext to set.
	 */
	public void setUiContext(String uiContext) {
		this.uiContext = uiContext;
	}
	
	/**
	 * @return Returns the pageName.
	 */
	public String getPageName() {
		return pageName;
	}
	/**
	 * @param pageName The pageName to set.
	 */
	public void setPageName(String pageName) {
		this.pageName = pageName;
	}
	
	/**
	 * @return Returns the region.
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * @param region The region to set.
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	
	/**
	 * @return Returns the pageInfo.
	 */
	public Object getPageInfo() {
		return pageInfo;
	}
	/**
	 * @param pageInfo The pageInfo to set.
	 */
	public void setPageInfo(Object pageInfo) {
		this.pageInfo = pageInfo;
	}
	
	/**
	 * @return Returns the pageType.
	 */
	public String getPageType() {
		return pageType;
	}
	/**
	 * @param pageType The pageType to set.
	 */
	public void setPageType(String pageType) {
		this.pageType = pageType;
	}
	
	/**
     * @return Returns the searchType.
     */
    public String getSearchType() {
        return searchType;
    }
    /**
     * @param searchType The searchType to set.
     */
    public void setSearchType(String searchType) {
        this.searchType = searchType;
    }

	public void reset(ActionMapping mapping, HttpServletRequest request) {
		memberId = null;
	    supplementalId = null;
	    letterNbr = null;
	    status = null;
	    requestor = null;
	    deleteInd = null;
	    requestDateFrom = null;
	    requestDateTo = null;
	    pageType = "";
	}
	/**
	 * @return Returns the fileId.
	 */
	public String getFileId() {
		return fileId;
	}
	/**
	 * @param fileId The fileId to set.
	 */
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	/**
	 * @return Returns the drillDeleteInd.
	 */
	public String getDrillDeleteInd() {
		return drillDeleteInd;
	}
	/**
	 * @param drillDeleteInd The drillDeleteInd to set.
	 */
	public void setDrillDeleteInd(String drillDeleteInd) {
		this.drillDeleteInd = drillDeleteInd;
	}
	/**
	 * @return Returns the drillStatus.
	 */
	public String getDrillStatus() {
		return drillStatus;
	}
	/**
	 * @param drillStatus The drillStatus to set.
	 */
	public void setDrillStatus(String drillStatus) {
		this.drillStatus = drillStatus;
	}
}
