/*
 * Created on Mar 11, 2008
 *
 */
package com.ps.mss.web.forms;

import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.manager.MasterManager;
import com.ps.mss.model.ProfileSearchDetailVO;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.util.DateUtil;
import com.ps.util.NameValuePair;
import com.ps.util.StringUtil;

/**
 * @author palat.pradeep
 */
public class SearchProfileForm extends ActionForm {

	private String parmCode;
	private String parmCodeText;
	private String actionType;
	private String menuName;
	private String paymentMonth;
	private String planName;
	private String parameterCode;
	private String parameterCodeAdv;
	private String pbpId;
	private String pageType;
	private String segmentId;
	private String fromDate;
	private String toDate;
	private String searchType;
	private ProfileSearchDetailVO profileSearchDetailVO;
	
	private String partName = Constants.PARTC;
	private String pdFetchList = Constants.PROFILE_PARTD_FETCH_BOTHLIST; // Fetch both Plan Level and PBP Level
	private NameValuePair[] partCParmCodeList;
	private NameValuePair[] partDParmCodeList;	
	private NameValuePair[] parmCodeList;	
	private NameValuePair[] planNameList;
	
	// Map will contain two Keys PartC and PartD, each of which will have an map of min and max dates
	private Map paymentMonthMap;  
	private NameValuePair[] partCPaymentMonthArr;
	private NameValuePair[] partDPaymentMonthArr;
	private NameValuePair[] parmDescList;
	private Map planPbpSegMap;
		
	private String showProfileList;
	private String showPDProfilePlnList;
	private String showPDProfilePBPList;	
	/*Base on activeRadioButton value we decided which radio button will active for user base on the plan are accessible to that user
	if use can access only one plan then that radio button will be active otherwise all button will be active.
	 This string can hold one of the three values 
	 "1" : when only part C plan are not accessible to user.
	 "2" : when only part D plan are not accessible to user.
	 "3" : when both plan are accessible to user.
	*/
	private String activeRadioButton ="3";			
				   
	/**
	 * @return Returns the actionType.
	 */
	public String getActionType() {
		return actionType;
	}
	/**
	 * @param actionType The actionType to set.
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	/**
	 * @return Returns the parmCode.
	 */
	public String getParmCode() {
		return parmCode;
	}
	/**
	 * @param parmCode The parmCode to set.
	 */
	public void setParmCode(String parmCode) {
		this.parmCode = parmCode;
	}
	/**
	 * @return Returns the partName.
	 */
	public String getPartName() {
		return partName;
	}
	/**
	 * @param partName The partName to set.
	 */
	public void setPartName(String partName) {
		this.partName = partName;
	}	
	/**
	 * @return Returns the parmCodeList.
	 */
	public NameValuePair[] getParmCodeList() {
		return parmCodeList;
	}
	/**
	 * @param parmCodeList The parmCodeList to set.
	 */
	public void setParmCodeList(NameValuePair[] parmCodeList) {
		this.parmCodeList = parmCodeList;
	}
	
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		super.reset(mapping, request);
		parmCode = "";
		paymentMonth = null;
		parmCodeList = null;
		partName = Constants.PARTC;
		actionType = "";
		showProfileList = "";
		showPDProfilePlnList = "";		
		showPDProfilePBPList = "";
	}
	
	public void init(HttpServletRequest request) throws ApplicationException {		
		SessionHelper sessionHelper = new SessionHelper(request);
		setPlanNameList(sessionHelper.getPlanIdArray());
		partCParmCodeList = MasterManager.getProfileParmsArr(Constants.PARTC);
		partDParmCodeList = MasterManager.getProfileParmsArr(Constants.PARTD);		
		setParmCodeList(MasterManager.getProfileParmsArr(partName));
		Map planMap = sessionHelper.getPlanForParts();
		
		boolean hasPartC = "TRUE".equals(sessionHelper.getAttribute("Recon"));
		boolean hasPartD = "TRUE".equals(sessionHelper.getAttribute("RxRecon"));				
		boolean isDemoUser = sessionHelper.isClickOnDemo();
		
		if(isDemoUser == false) {
			if(planMap != null) {
				if ( hasPartC && ! hasPartD) {
					partName = Constants.PARTC;
					activeRadioButton = "1";
				}
				if ( hasPartD && ! hasPartC) {
					activeRadioButton = "2";
					partName = Constants.PARTD;
				}			
			}
		}		
	}

	/**
	 * @return Returns the parmCodeText.
	 */
	public String getParmCodeText() {
		return parmCodeText;
	}
	/**
	 * @param parmCodeText The parmCodeText to set.
	 */
	public void setParmCodeText(String parmCodeText) {
		this.parmCodeText = parmCodeText;
	}
	/**
	 * @return Returns the planNameList.
	 */
	public NameValuePair[] getPlanNameList() {
		return planNameList;
	}
	/**
	 * @param planNameList The planNameList to set.
	 */
	public void setPlanNameList(NameValuePair[] planNameList) {
		this.planNameList = planNameList;
	}
	
	
	
	/**
	 * @return Returns the menuName.
	 */
	public String getMenuName() {
		return menuName;
	}
	/**
	 * @param menuName The menuName to set.
	 */
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	/**
	 * @return Returns the showProfileList.
	 */
	public String getShowProfileList() {
		return showProfileList;
	}
	/**
	 * @param showProfileList The showProfileList to set.
	 */
	public void setShowProfileList(String showProfileList) {
		this.showProfileList = showProfileList;
	}	


	/**
	 * @return Returns the parameterCode.
	 */
	public String getParameterCode() {
		return parameterCode;
	}
	/**
	 * @param parameterCode The parameterCode to set.
	 */
	public void setParameterCode(String parameterCode) {
		this.parameterCode = parameterCode;
	}
	/**
	 * @return Returns the parameterCodeAdv.
	 */
	public String getParameterCodeAdv() {
		return parameterCodeAdv;
	}
	/**
	 * @param parameterCodeAdv The parameterCodeAdv to set.
	 */
	public void setParameterCodeAdv(String parameterCodeAdv) {
		this.parameterCodeAdv = parameterCodeAdv;
	}

	/**
	 * @return Returns the paymentMonth.
	 */
	public String getPaymentMonth() {
		return paymentMonth;
	}
	/**
	 * @param paymentMonth The paymentMonth to set.
	 */
	public void setPaymentMonth(String paymentMonth) {
		this.paymentMonth = paymentMonth;
	}
	/**
	 * @return Returns the pbpId.
	 */
	public String getPbpId() {
		return pbpId;
	}
	/**
	 * @param pbpId The pbpId to set.
	 */
	public void setPbpId(String pbpId) {
		this.pbpId = pbpId;
	}
	/**
	 * @return Returns the planName.
	 */
	public String getPlanName() {
		return planName;
	}
	/**
	 * @param planName The planName to set.
	 */
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	/**
	 * @return Returns the segmentId.
	 */
	public String getSegmentId() {
		return segmentId;
	}
	/**
	 * @param segmentId The segmentId to set.
	 */
	public void setSegmentId(String segmentId) {
		this.segmentId = segmentId;
	}

	/**
	 * @return Returns the paymentMonthList.
	 */
	public Map getPaymentMonthMap() {
		return paymentMonthMap;
	}
	/**
	 * @param paymentMonthList The paymentMonthList to set.
	 */
	public void setPaymentMonthMap(Map paymentMonthMap) {
		this.paymentMonthMap = paymentMonthMap;
		populatePaymentMonthArr();
	}
	/**
	 * @return Returns the showPDProfilePBPList.
	 */
	public String getShowPDProfilePBPList() {
		return showPDProfilePBPList;
	}
	/**
	 * @param showPDProfilePBPList The showPDProfilePBPList to set.
	 */
	public void setShowPDProfilePBPList(String showPDProfilePBPList) {
		this.showPDProfilePBPList = showPDProfilePBPList;
	}
	/**
	 * @return Returns the showPDProfilePlnList.
	 */
	public String getShowPDProfilePlnList() {
		return showPDProfilePlnList;
	}
	/**
	 * @param showPDProfilePlnList The showPDProfilePlnList to set.
	 */
	public void setShowPDProfilePlnList(String showPDProfilePlnList) {
		this.showPDProfilePlnList = showPDProfilePlnList;
	}

	/**
	 * @return Returns the parmDescList.
	 */
	public NameValuePair[] getParmDescList() {
		return parmDescList;
	}
	/**
	 * @param parmDescList The parmDescList to set.
	 */
	public void setParmDescList(NameValuePair[] parmDescList) {
		this.parmDescList = parmDescList;
	}	
	/**
	 * @return Returns the fromDate.
	 */
	public String getFromDate() {
		return fromDate;
	}
	/**
	 * @param fromDate The fromDate to set.
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	/**
	 * @return Returns the toDate.
	 */
	public String getToDate() {
		return toDate;
	}
	/**
	 * @param toDate The toDate to set.
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	/**
	 * @return Returns the searchType.
	 */
	public String getSearchType() {
		return searchType;
	}
	/**
	 * @param searchType The searchType to set.
	 */
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	/**
	 * @return Returns the profileSearchDetailVO.
	 */
	public ProfileSearchDetailVO getProfileSearchDetailVO() {
		return profileSearchDetailVO;
	}
	/**
	 * @param profileSearchDetailVO The profileSearchDetailVO to set.
	 */
	public void setProfileSearchDetailVO(
			ProfileSearchDetailVO profileSearchDetailVO) {
		this.profileSearchDetailVO = profileSearchDetailVO;
	}
	/**
	 * @return Returns the pdFetchList.
	 */
	public String getPdFetchList() {
		return pdFetchList;
	}
	/**
	 * @param pdFetchList The pdFetchList to set.
	 */
	public void setPdFetchList(String pdFetchList) {
		this.pdFetchList = pdFetchList;
	}

	/**
	 * @return Returns the partCPaymentMonthArr.
	 */
	public NameValuePair[] getPartCPaymentMonthArr() {
		return partCPaymentMonthArr;
	}
	/**
	 * @param partCPaymentMonthArr The partCPaymentMonthArr to set.
	 */
	public void setPartCPaymentMonthArr(NameValuePair[] partCPaymentMonthArr) {
		this.partCPaymentMonthArr = partCPaymentMonthArr;
	}
	/**
	 * @return Returns the partDPaymentMonthArr.
	 */
	public NameValuePair[] getPartDPaymentMonthArr() {
		return partDPaymentMonthArr;
	}
	/**
	 * @param partDPaymentMonthArr The partDPaymentMonthArr to set.
	 */
	public void setPartDPaymentMonthArr(NameValuePair[] partDPaymentMonthArr) {
		this.partDPaymentMonthArr = partDPaymentMonthArr;
	}
	
	private void populatePaymentMonthArr(){
		
		int partCStartYear = getStartYear(paymentMonthMap, Constants.PARTC);
		int partCEndYear = getEndYear(paymentMonthMap, Constants.PARTC);
		
		int partDStartYear = getStartYear(paymentMonthMap, Constants.PARTD);
		int partDEndYear = getEndYear(paymentMonthMap, Constants.PARTD);
		
		String iStr;
		
		if ( partCStartYear > 0){
			partCPaymentMonthArr = generatePaymentYears(partCStartYear, partCEndYear);
		}

		if ( partDStartYear > 0){
			partDPaymentMonthArr = generatePaymentYears(partDStartYear, partDEndYear);
		}
		
	}
	
	private int getStartYear ( Map paymentMonthMap, String partName){
		Map partPaymentMap = (Map)paymentMonthMap.get(partName);
		int year = 0;
		
		if ( partPaymentMap != null){
			String startDateTxt = (String)partPaymentMap.get(Constants.PROFILE_DATE_RANGE_START);
			if ( ! StringUtil.isNullOrEmpty(startDateTxt)){				
				year = new Integer(startDateTxt.substring(0,4)).intValue();
			}
		}
		return year;
	}

	private int getEndYear ( Map paymentMonthMap, String partName){
		Map partPaymentMap = (Map)paymentMonthMap.get(partName);
		int year = 0;
		
		if ( partPaymentMap != null){
			String endDateTxt = (String)partPaymentMap.get(Constants.PROFILE_DATE_RANGE_END);
			if ( StringUtil.isNullOrEmpty(endDateTxt)){
				endDateTxt = new DateUtil().getTodaysDate();
			}
			year = new Integer(endDateTxt.substring(0,4)).intValue();
		}
		return year;
	}
	
	private NameValuePair[] generatePaymentYears ( int startYr, int endYr) {
		String iStr;			
		NameValuePair[] paymentYrArr = new NameValuePair[(endYr - startYr) + 1];
		int counter=0;
		for ( int i = startYr; i <= endYr; i++){
			iStr = i + "";
			paymentYrArr[counter++] = new NameValuePair(iStr, iStr);	
		}			
		return paymentYrArr;
	}
	
	/**
	 * @return Returns the planPbpSegMap.
	 */
	public Map getPlanPbpSegMap() {
		return planPbpSegMap;
	}
	/**
	 * @param planPbpSegMap The planPbpSegMap to set.
	 */
	public void setPlanPbpSegMap(Map planPbpSegMap) {
		this.planPbpSegMap = planPbpSegMap;
	}
	/**
	 * @return Returns the pageType.
	 */
	public String getPageType() {
		return pageType;
	}
	/**
	 * @param pageType The pageType to set.
	 */
	public void setPageType(String pageType) {
		this.pageType = pageType;
	}
	/**
	 * @return Returns the activeRadioButton.
	 */
	public String getActiveRadioButton() {
		return activeRadioButton;
	}
	/**
	 * @param activeRadioButton The activeRadioButton to set.
	 */
	public void setActiveRadioButton(String activeRadioButton) {
		this.activeRadioButton = activeRadioButton;
	}
	/**
	 * @return Returns the partCParmCodeList.
	 */
	public NameValuePair[] getPartCParmCodeList() {
		return partCParmCodeList;
	}
	/**
	 * @param partCParmCodeList The partCParmCodeList to set.
	 */
	public void setPartCParmCodeList(NameValuePair[] partCParmCodeList) {
		this.partCParmCodeList = partCParmCodeList;
	}
	/**
	 * @return Returns the partDParmCodeList.
	 */
	public NameValuePair[] getPartDParmCodeList() {
		return partDParmCodeList;
	}
	/**
	 * @param partDParmCodeList The partDParmCodeList to set.
	 */
	public void setPartDParmCodeList(NameValuePair[] partDParmCodeList) {
		this.partDParmCodeList = partDParmCodeList;
	}
	//Recon Work Queue changes : start
	private String autoAssignDisc;
	private String autoAssignedTo;



	/**
	 * @return the autoAssignDisc
	 */
	public String getAutoAssignDisc() {
		return autoAssignDisc;
	}
	/**
	 * @param autoAssignDisc the autoAssignDisc to set
	 */
	public void setAutoAssignDisc(String autoAssignDisc) {
		this.autoAssignDisc = autoAssignDisc;
	}
	/**
	 * @return the autoAssignedTo
	 */
	public String getAutoAssignedTo() {
		return autoAssignedTo;
	}
	/**
	 * @param autoAssignedTo the autoAssignedTo to set
	 */
	public void setAutoAssignedTo(String autoAssignedTo) {
		this.autoAssignedTo = autoAssignedTo;
	}
	
	private List assignedToList;
	/**
	 * @return the assignedToList
	 */
	public List getAssignedToList() {
		return assignedToList;
	}
	/**
	 * @param assignedToList the assignedToList to set
	 */
	public void setAssignedToList(List assignedToList) {
		this.assignedToList = assignedToList;
	}
	
	private Map userAsgnMap;

	/**
	 * @return the userAsgnMap
	 */
	public Map getUserAsgnMap() {
		return userAsgnMap;
	}
	/**
	 * @param userAsgnMap the userAsgnMap to set
	 */
	public void setUserAsgnMap(Map userAsgnMap) {
		this.userAsgnMap = userAsgnMap;
	}
	
	private String updateMessage;

	/**
	 * @return the updateMessage
	 */
	public String getUpdateMessage() {
		return updateMessage;
	}
	/**
	 * @param updateMessage the updateMessage to set
	 */
	public void setUpdateMessage(String updateMessage) {
		this.updateMessage = updateMessage;
	}
	
	
	//Recon Work Queue changes : end
	
	
}
