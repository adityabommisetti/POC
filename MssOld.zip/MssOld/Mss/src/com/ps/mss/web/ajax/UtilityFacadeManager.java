/*
 * $Id: ExportFacadeManager.java,v 1.8 2014/08/20 17:15:37 jacob Exp $
 */
package com.ps.mss.web.ajax;

import java.sql.Connection;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.HPEEncounterService;
import com.ps.mss.dao.HPEEncounterDao;
import com.ps.mss.db.DbConn;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.HPEConstants;
import com.ps.mss.manager.ExportManager;
import com.ps.mss.manager.HPEManager;
import com.ps.mss.model.HPEContext;
import com.ps.mss.model.HPEEncounterVO;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.helper.AjaxHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.web.helper.Utility;
import com.ps.util.DateUtil;

/**
 * @author Swagat kumar pattnaik
 *
 */
public class UtilityFacadeManager {	
	private static Logger logger=LoggerFactory.getLogger(UtilityFacadeManager.class);
public void setSelectedTab(String mainTabName,String encType) throws ApplicationException, Exception {
	logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		AjaxHelper.validateUser();
		sessionHelper.setAttribute(mainTabName, Utility.getDshSelectedMapArray(mainTabName,encType,sessionHelper));
	logger.info(LoggerConstants.methodEndLevel());
	}
public String addUpdatableFields(HPEEncounterVO encounterVO) {
	logger.info(LoggerConstants.methodStartLevel());
	SessionHelper sessionHelper =null;		
	HPEContext hpeContext = null;
	HPEEncounterService encounterService=null;
	StringBuffer  msgBuffer=new StringBuffer();
	Connection conn = null;
	HashMap<String,String> hm=new HashMap<String,String>();
	try{
		
		sessionHelper=AjaxHelper.getSessionHelper();
		hpeContext = HPEManager.getContext(sessionHelper.getSession());
		encounterService=hpeContext.getEncounterService();
		
		// get a connection
		conn = DbConn.getConnection();

		// use the default DB for security check
		String errorMsg = sessionHelper.validateUser(conn);
		if (errorMsg != null) {
			msgBuffer.append("ERROR:"+errorMsg);
		}else{
			// re-get the connection in case the environment is different (QA,etc.)
			conn = DbConn.reGetConnection(conn, (String) sessionHelper.getAttribute(SessionManager.HPEDB));
			/*HPEEncounterVO encounterVO=new HPEEncounterVO();
			Utility.getUpdatableParam(parmsEdit,encounterVO);*/
			encounterVO.setUserId(sessionHelper.getUserId());
			encounterVO.setEditableMfid(sessionHelper.getMfId());
			
			String fromDateFrmt="MM/dd/yyyy";
			String toDateFrmt="yyyyMMdd";
			
			encounterVO.setEditableDate(	DateUtil.covertDateFormat(encounterVO.getEditableDate(),fromDateFrmt,toDateFrmt)	);
			encounterVO.setEditableFromDt(	DateUtil.covertDateFormat(encounterVO.getEditableFromDt(),fromDateFrmt,toDateFrmt)	);
			encounterVO.setEditableThruDt(	DateUtil.covertDateFormat(encounterVO.getEditableThruDt(),fromDateFrmt,toDateFrmt)	);

			hm=encounterService.EditableUpdateCodes(conn, hpeContext, encounterVO, "ADD");
			
			
		}
	}catch(Exception ex){
		msgBuffer.append("ERROR:"+ex.getMessage());
	}
	/* Added for IFOX-00406912 Primary Procedure Code*/	
	if(!hm.isEmpty()) {
		if(hm.get("princProc")!=null && hm.get("princProc").equals("exists")) {
			msgBuffer.append("ERROR:PRINCPROCCODEDUPL:Cannot add two principal procedure codes. Please add a different one.");
		}else {
			msgBuffer=convertHMToString(hm);
		}
	}
	logger.info(LoggerConstants.methodEndLevel());
	return msgBuffer.toString();
}

/* Added for IFOX-00406912 Primary Procedure Code*/	
public String checkDupPrincipalProcCode(String mfId,String clmNbr,int clmRvNbr,int cndSqNbr,String encType, int clmSqNbr) {
	logger.info(LoggerConstants.methodStartLevel());
	Connection conn = null;
	SessionHelper sessionHelper =null;	
	StringBuffer  msgBuffer=new StringBuffer();
	HashMap<String,String> hm=new HashMap<String,String>();
	boolean isDuplicatePrincProc= false;
	boolean isOtherCode= false;
	try{
	sessionHelper=AjaxHelper.getSessionHelper();
	conn = DbConn.getConnection();
	HPEEncounterDao hpeEncounterDao = new HPEEncounterDao();

	// use the default DB for security check
	String errorMsg = sessionHelper.validateUser(conn);
	conn = DbConn.reGetConnection(conn, (String) sessionHelper.getAttribute(SessionManager.HPEDB));
	if (errorMsg != null) {
		msgBuffer.append("ERROR:"+errorMsg);
	}else{
	 isDuplicatePrincProc=hpeEncounterDao.checkDuplicatePrincipalProcCode(conn, mfId, "I", encType, "", clmNbr, clmRvNbr, cndSqNbr, 0, "", "");
	 
	 if(isDuplicatePrincProc) {
		 isOtherCode=hpeEncounterDao.isOtherProcCodesExists(conn, mfId, "I", encType, "", clmNbr, clmRvNbr, clmSqNbr,cndSqNbr, "", "","");
	 }
	}
	
	
	}catch(Exception ex){
		msgBuffer.append("ERROR:"+ex.getMessage());
	}
	if(isDuplicatePrincProc && isOtherCode) {
		
	msgBuffer.append("ERROR:PRINCPROCCODEDUPL:Cannot add two principal procedure codes. Please add a different one.");
	
	}else {
		msgBuffer.append("ERROR:NODUPLICATE");	
	}
	logger.info(LoggerConstants.methodEndLevel());
	return msgBuffer.toString();
}
StringBuffer convertHMToString(HashMap<String,String> hm){
	logger.info(LoggerConstants.methodStartLevel());
	StringBuffer  msgBuffer=new StringBuffer();
	int sqlCnt=Integer.parseInt(hm.get("sqlCnt"));
	if(sqlCnt == -5){
		msgBuffer.append("ERROR:DUPLICATE ROW");
	}
	if(sqlCnt == -1){
		msgBuffer.append("ERROR:NO ROWS UPDATED");
	}else{
		msgBuffer.append("editableSeqNbr="+hm.get("editableSeqNbr"));msgBuffer.append(",");
		msgBuffer.append("mfId="+hm.get("mfId"));
	}
	
	logger.info(LoggerConstants.methodEndLevel());
	return msgBuffer;
}
	
}
