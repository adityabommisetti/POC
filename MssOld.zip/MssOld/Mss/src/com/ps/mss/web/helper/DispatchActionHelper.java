/*
 * $Id: DispatchActionHelper.java,v 1.1 2014/06/26 07:55:06 praveen Exp $
 *
 */
package com.ps.mss.web.helper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.helper.ServiceHelper;
import com.ps.mss.manager.DiscrepancyManager;
import com.ps.mss.manager.PaymentManager;
import com.ps.mss.model.DiscrepancySummaryVOList;
import com.ps.mss.model.DiseaseGroupVOList;
import com.ps.mss.model.FilterVO;
import com.ps.mss.model.PaymentSummaryVOList;
import com.ps.mss.model.PymtEffDateDetailVO;
import com.ps.mss.model.ReconciliationListVO;
import com.ps.mss.web.forms.BaseForm;
import com.ps.util.StringUtil;

/**
 * @author deepak
 *This is session helper class for recond DashBoard action.It will interact with session.
 */
public class DispatchActionHelper {
	private static Logger logger=LoggerFactory.getLogger(DispatchActionHelper.class);
	/**
	 * This function set paymentDashBoardVO of the form Bean.
	 * @param request
	 * @param baseForm
	 * @throws ApplicationException
	 */
	public void getPaymentDashboard(HttpServletRequest request, BaseForm baseForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = new SessionHelper(request);
			
		FilterVO filterVO = null ;
		if (Constants.BENEFICIARY_MENU.equals(baseForm.getMenuName())) {//Beneficiary payment dashboard.
			filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_DASHBOARD_FILTERVO);
		} else { //paymentdashboard for plan
			filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_PAYMENT_DASHBOARD_FILTERVO);
		}
		
		if(request.getParameter("print") ==  null) {
			filterVO = setFilterVO(baseForm,filterVO);
			if (Constants.BENEFICIARY_MENU.equals(baseForm.getMenuName())) {//Beneficiary payment dashboard.
				sessionHelper.setAttribute(Constants.SESSION_BENEFICIARY_PYMT_DASHBOARD_FILTERVO,filterVO);
				//This code is for setting default filter VO for both dashboard's in beneficiary
				FilterVO beneFilterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DISC_DASHBOARD_FILTERVO);
				if("hicNbrSearch".equals(baseForm.getActionType())) {
					beneFilterVO = setFilterVO(baseForm,beneFilterVO);
					sessionHelper.setAttribute(Constants.SESSION_BENEFICIARY_DISC_DASHBOARD_FILTERVO,beneFilterVO);
				}
			} else { //paymentdashboard for plan
				sessionHelper.setAttribute(Constants.SESSION_PAYMENT_DASHBOARD_FILTERVO,filterVO);
			}
		}
		
		setBaseForm(baseForm,filterVO);
		
		String uiContextRange = "";
		//	START OF getting dashBoard Header Name String FOR PRINT WINDOW
		if(request.getParameter("print") !=  null) {
			//For Print get search crieria header and set it as request attribute
			String searchCreiteriaHeader = PaymentManager.getSearchCreiteriaHeader(filterVO, Constants.PAYMENT_DASHBOARD, baseForm.getMenuName(), sessionHelper.getActiveDataBaseName());
			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCreiteriaHeader);
			uiContextRange = request.getParameter("uiContextRange");
		}
		//	END OF getting dashBoard Header Name String FOR PRINT WINDOW
		Map planMap = sessionHelper.getPlanForParts();
		List paymentDashBoardStatus = null;
		
		if(Constants.CONSTANTS_ALL.equals(uiContextRange)) {
			paymentDashBoardStatus = new ArrayList();
			paymentDashBoardStatus.add(Constants.CONSTANTS_ALL);
		} else	if (Constants.BENEFICIARY_MENU.equals(baseForm.getMenuName())) {
			paymentDashBoardStatus = (List)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_DESH_STATUS);
		} else
			paymentDashBoardStatus = (List)sessionHelper.getAttribute(Constants.SESSION_PAYMENT_DESH_STATUS);
		
		baseForm.setPaymentDashBoardVO(PaymentManager.getPlanDashBoard(filterVO,planMap,"plan",paymentDashBoardStatus, baseForm.getMenuName() , sessionHelper.getActiveDataBaseName()));
		baseForm.setNotifyOtherHics(Boolean.FALSE);
		if (Constants.BENEFICIARY_MENU.equals(baseForm.getMenuName()) && filterVO.getHicNumberList() != null
				&& filterVO.getHicNumberList().size() != 0) //Beneficiary payment dashboard.
			baseForm.setNotifyOtherHics(Boolean.TRUE);
		if (Constants.BENEFICIARY_MENU.equals(baseForm.getMenuName())) {
			baseForm.setMemberId(filterVO.getMemberId());
			baseForm.setHicNumberList(filterVO.getHicNumberList());
		}
		baseForm.setSummarPage(false);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	/**
	 * Function set BaseForm from the filterVO for current search.
	 * @param baseForm
	 * @param filterVO
	 */
	private void setBaseForm(BaseForm baseForm, FilterVO filterVO) {
		logger.info(LoggerConstants.methodStartLevel());
		baseForm.setPlanName(filterVO.getPlanName());
		baseForm.setFromDate(filterVO.getStartDate());
		baseForm.setToDate(filterVO.getEndDate());
		baseForm.setDateType(filterVO.getDateType());
		baseForm.setPartName(filterVO.getPartName());
		baseForm.setSearchType(filterVO.getSearchType());
		baseForm.setHicNbr(filterVO.getHicNumber());
		baseForm.setDiscrepancyType(filterVO.getDiscrepancyIndicator());
		baseForm.setDiscCd(filterVO.getDiscrpCd());
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	/**
	 * <code>getPaymentSummary</code> get Payment Summary enteries from buiness layers, set to request scope
	 * and returns to appropiate UI.
	 *
	 * @param request
	 * @param baseForm
	 * @throws ApplicationException
	 */
	public void getPaymentSummary(HttpServletRequest request, BaseForm baseForm ) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		FilterVO filterVO = null ;
		List uiContext = null;
		
		SessionHelper sessionHelper = new SessionHelper(request);
		Map planMap = sessionHelper.getPlanForParts();
		
		if(Constants.PAYMENT_DETAIL.equals(baseForm.getMenuName())){ //paymentDetail for pop up
			request.setAttribute("partName",baseForm.getPartName());
			filterVO = filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_PYMT_DETAIL_POP_UP_FILTERVO);
			filterVO = setFilterVO(baseForm,filterVO);
			sessionHelper.setAttribute(Constants.SESSION_PYMT_DETAIL_POP_UP_FILTERVO,filterVO);
			if(request.getParameter("print")!=null){
				uiContext = new ArrayList();
				uiContext.add(Constants.CONSTANTS_ALL);
			}
			baseForm.setBenePymtDetailVOList(PaymentManager.getPymtDetail(filterVO,planMap,filterVO.getPartName(),uiContext,sessionHelper.getActiveDataBaseName()));
		} else if (Constants.BENEFICIARY_MENU.equals(baseForm.getMenuName())) {
			if(Constants.READ_ONLY.equals(baseForm.getPageType())) {
				filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DETAIL_FILTERVO);
				uiContext = (List)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_SHOW_PYMT_SUMMARY_STATUS);
			} else {
				//	Beneficiary payment detail.
				filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_FILTERVO);
				filterVO = setFilterVO(baseForm,filterVO);
				filterVO.setSearchType(sessionHelper.evaluteSearchType(filterVO));
				sessionHelper.setAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_FILTERVO, filterVO);
				sessionHelper.setAttribute(Constants.SESSION_DISPLAY_DISCRP_DETAIL,"true");
				uiContext = (List)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_STATUS);
			}
			
			baseForm.setBenePymtDetailVOList(PaymentManager.getBeneficiaryPymtDetail(filterVO,planMap,filterVO.getSearchType(),sessionHelper.getActiveDataBaseName(),uiContext));
		} else { //payemnt summary.
			String actionType = baseForm.getActionType();
			if(Constants.READ_ONLY.equals(baseForm.getPageType())) {
				filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_SUMMARY_FILTERVO);
				uiContext = (List)sessionHelper.getAttribute(Constants.SESSION_SHOW_PAYMENT_SUMMARY_STATUS);
			} else {
				filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_PAYMENT_SUMMARY_FILTERVO);
				filterVO = setFilterVO(baseForm,filterVO);
				filterVO.setSearchType(sessionHelper.evaluteSearchType(filterVO));
				sessionHelper.setAttribute(Constants.SESSION_PAYMENT_SUMMARY_FILTERVO,filterVO);
				sessionHelper.setAttribute(Constants.SESSION_DISPLAY_PAYMENT_SUMMARY_PARTC,"true");//this attribute is set to show payment summary tab once user has visite this.
				uiContext = (List)sessionHelper.getAttribute(Constants.SESSION_PAYMENT_SUMMARY_STATUS);
				if(filterVO != null && "A".equals(filterVO.getDateType()))
					sessionHelper.setAttribute(Constants.SESSION_DISABLE_SHOW_DISCREPANCY,"true");//this attribute is set to show disable show discrepancy tab
				else
					sessionHelper.removeAttribute(Constants.SESSION_DISABLE_SHOW_DISCREPANCY);//this attribute is set to show enable show discreapncy tab
			}
			PaymentSummaryVOList paymentSummaryVOList = PaymentManager.getPaymentSummary(filterVO,filterVO.getSearchType(),planMap,sessionHelper.getActiveDataBaseName());
			baseForm.setPaymentSummaryVOList(paymentSummaryVOList);
		}
		setBaseForm(baseForm,filterVO);
		setUiContext(uiContext,baseForm);
		baseForm.setSummarPage(true);
		
		if(request.getParameter("print")!= null){ // Print report resquest
			String searchCreiteriaHeader = PaymentManager.getSearchCreiteriaHeader(filterVO, Constants.PAYMENT_SUMMARY, baseForm.getMenuName(), sessionHelper.getActiveDataBaseName());
			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCreiteriaHeader);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	/**
	 * <code>setUiContext</code> set ui context into base form for requested page.
	 * @param uiContext
	 * @param baseForm
	 */
	private void setUiContext(List uiContext, BaseForm baseForm) {
		logger.info(LoggerConstants.methodStartLevel());
		if(uiContext != null) {
			String contextString = null;
			Iterator it = uiContext.iterator();
			while(it.hasNext()) {
				contextString = (String) it.next();
				if(Constants.PARTA.equals(contextString)) {
					baseForm.setPartA(contextString);
				} else if(Constants.PARTB.equals(contextString)) {
					baseForm.setPartB(contextString);
				} else if(Constants.PARTC.equals(contextString)) {
					baseForm.setPartC(contextString);
				} else if(Constants.PARTD.equals(contextString)) {
					baseForm.setPartD(contextString);
				} else if(Constants.DEMOGRAPHIC_INFO.equals(contextString)) {
					baseForm.setDemoGrpInfo(contextString);
					// Change for Part C UI - Start
				} else if(Constants.PARTC_PREM.equals(contextString)){
					baseForm.setPartCPrem(contextString);
				}// Change for Part C UI - End
			}
		} else { // This is for default context because in defult summary must be open
			baseForm.setPartC(Constants.PARTC);
			baseForm.setPartD(Constants.PARTD);
			
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	/**
	 * <code>getPaymentSummary</code> get Discreapncy Dashboard enteries from buiness layers, set to request scope
	 * and returns to appropiate UI.
	 *
	 * @param request
	 * @param baseForm
	 * @throws ApplicationException
	 */
	public void getDiscrepancyDashBoard(HttpServletRequest request, BaseForm baseForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		FilterVO filterVO = null ;
		SessionHelper sessionHelper = new SessionHelper(request);
		Map planMap = sessionHelper.getPlanForParts();
		
		if (Constants.BENEFICIARY_MENU.equals(baseForm.getMenuName())) {//Beneficiary discrepancyDashboard.
			filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DISC_DASHBOARD_FILTERVO);
		} else { //discrepancy dashboard for plan
			filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DASHBOARD_FILTERVO);
		}
		
		
		if(request.getParameter("print") ==  null){
			filterVO = setFilterVO(baseForm,filterVO);
			if (Constants.BENEFICIARY_MENU.equals(baseForm.getMenuName())) {//Beneficiary discrepancyDashboard.
				sessionHelper.setAttribute(Constants.SESSION_BENEFICIARY_DISC_DASHBOARD_FILTERVO,filterVO);
			} else { //discrepancy dashboard for plan
				sessionHelper.setAttribute(Constants.SESSION_DISCREPANCY_DASHBOARD_FILTERVO,filterVO);
			}
		}
		
		setBaseForm(baseForm,filterVO);
		String uiContextRange = "";
		//For Print get search crieria header and set it as request attribute
		if(request.getParameter("print") !=  null) {
			String searchCreiteriaHeader = DiscrepancyManager.getSearchCreiteriaHeader(filterVO, Constants.DISCREPANCY_DASHBOARD, baseForm.getMenuName(), sessionHelper.getActiveDataBaseName());
			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCreiteriaHeader);
			uiContextRange = request.getParameter("uiContextRange");
		}
		
		List discrepancyDashBoardStatus = null;
		if(Constants.CONSTANTS_ALL.equals(uiContextRange)){//To find detail for all plans.
			discrepancyDashBoardStatus = new ArrayList();
			discrepancyDashBoardStatus.add(Constants.CONSTANTS_ALL);
		} else if (Constants.BENEFICIARY_MENU.equals(baseForm.getMenuName())) {
			discrepancyDashBoardStatus = (List)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DISCREPANCY_DESH_STATUS);
		} else
			discrepancyDashBoardStatus = (List)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DESH_STATUS);
		
		baseForm.setDiscrepancyDashBoardVO(DiscrepancyManager.getDiscrepancyDashBoard(filterVO ,planMap ,"plan",discrepancyDashBoardStatus, baseForm.getMenuName(), sessionHelper.getActiveDataBaseName()));
		baseForm.setSummarPage(false);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	/**
	 *  <code>getPaymentSummary</code> get Discreapncy Summary enteries from buiness layers, set to request scope
	 * and returns to appropiate UI.
	 * @param request
	 * @param baseForm
	 * @throws ApplicationException
	 */
	public void getDiscrepancySummary(HttpServletRequest request, BaseForm baseForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = new SessionHelper(request);
		FilterVO filterVO = null ;
		List uiContext = null;
		//If action type is read only (action is call from show tab) then we have to use filter vo of payment summary.
		if(Constants.READ_ONLY.equals(baseForm.getPageType())) {
			filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_PAYMENT_SUMMARY_FILTERVO);
			uiContext = (List)sessionHelper.getAttribute(Constants.SESSION_SHOW_DISCREPANCY_SUMMARY_STATUS);
			filterVO.setDiscrepancyIndicator("NotClosed"); // Because we are considering "NotClosed" discrepancy only
		} else { // we have to use filter vo for discreapncy summary.
			filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_SUMMARY_FILTERVO);
			filterVO = setFilterVO(baseForm,filterVO);
			filterVO.setSearchType(sessionHelper.evaluteSearchType(filterVO));
			sessionHelper.setAttribute(Constants.SESSION_DISCREPANCY_SUMMARY_FILTERVO,filterVO);
			sessionHelper.setAttribute(Constants.SESSION_DISPLAY_DISCREPANCY_SUMMARY_PARTC,"true");
			uiContext = (List)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_SUMMARY_STATUS);
		}
		
		Map planMap = sessionHelper.getPlanForParts();
		//String planName = getPlanName(sessionHelper,filterVO);
		DiscrepancySummaryVOList discrepancySummaryVOList = DiscrepancyManager.getDiscrepancySummary(filterVO ,baseForm.getSearchType() ,filterVO.getPartName(),planMap, sessionHelper.getActiveDataBaseName());
		//discrepancySummaryVOList.setSummaryHeaderTitle(discrepancySummaryVOList.getSummaryHeaderTitle());
		baseForm.setDiscrepancySummaryVOList(discrepancySummaryVOList);
		setBaseForm(baseForm,filterVO);
		
		setUiContext(uiContext,baseForm);
		baseForm.setSummarPage(true);
		
		if(request.getParameter("print") !=  null) {
			//For Print get search crieria header and set it as request attribute
			String searchCreiteriaHeader = DiscrepancyManager.getSearchCreiteriaHeader(filterVO, Constants.DISCREPANCY_DASHBOARD, baseForm.getMenuName(), sessionHelper.getActiveDataBaseName());
			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCreiteriaHeader);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	/**
	 * Fucntion set search criteria into filterVO from baseForm.
	 * @param baseForm
	 * @param filterVO
	 * @return
	 */
	private FilterVO setFilterVO(BaseForm baseForm, FilterVO filterVO) {
		logger.info(LoggerConstants.methodStartLevel());
		String actionType = baseForm.getActionType();
		if( filterVO == null )
			filterVO = new FilterVO();

		String baseHic = StringUtil.nonNullTrim(baseForm.getHicNbr());
		String filterHic = StringUtil.nonNullTrim(filterVO.getHicNumber());
		if (!filterHic.equals(baseHic)) {
			filterVO.setMemberId(null);
			filterVO.setHicNumberList(null);
		}
		
		// Filter criteria changed only when action execute from go button.
		// a. actionType is search when we are doing search through go button.
		// b. actionType is searchDiscrepancy when we are come through discrepancy dashboart to finding discrepancySummary.
		// c. actionType is hicNbrSearch when we are comeing through discrepancyDetail by clicking hicNbr.
		if("search".equals(actionType) || "searchDiscrepancy".equals(actionType) || "hicNbrSearch".equals(actionType)) {
			filterVO.setPlanName(StringUtil.trimToNull(baseForm.getPlanName()));
			filterVO.setStartDate(StringUtil.trimToNull(baseForm.getFromDate()));
			filterVO.setEndDate(StringUtil.trimToNull(baseForm.getToDate()));
			filterVO.setDateType(StringUtil.trimToNull(baseForm.getDateType()));
			filterVO.setPartName(StringUtil.trimToNull(baseForm.getPartName()));
			filterVO.setHicNumber(StringUtil.trimToNull(baseForm.getHicNbr()));
			filterVO.setDiscrepancyIndicator(StringUtil.trimToNull(baseForm.getDiscrepancyType()));
			filterVO.setSearchType(StringUtil.trimToNull(baseForm.getSearchType()));
			filterVO.setPageHeaderMsg("");
		}
		logger.info(LoggerConstants.methodEndLevel());
		return filterVO;
	}
	
	
	
	/**
	 *  <code>getPaymentSummary</code> get payment detail on Effective Date  from buiness layers, set to request scope
	 * and returns to appropiate UI.
	 * @param request
	 * @param baseForm
	 * @throws ApplicationException
	 */
	public void pymtEffDateDetail(HttpServletRequest request, BaseForm baseForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = new SessionHelper(request);
		
		Map planMap = sessionHelper.getPlanForParts();
		String seqNbr = (String)request.getParameter("seqNbr");
		String pymtType = (String)request.getParameter("pymtType");
		String applyDate = (String)request.getParameter("applyDate");
		String isPopUp = (String)request.getParameter("isPopUp");
		
		request.setAttribute("fromDate",baseForm.getFromDate());
		request.setAttribute("menuName",baseForm.getMenuName());
		request.setAttribute("pageType",baseForm.getPageType());
		
		FilterVO filterVO = null;
			
		if(request.getParameter("print")!= null){ // Print report resquest
			filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_EFFDATE_POPUP_FILTER);
			String searchCreiteriaHeader = ServiceHelper.getSearchCreiteriaHeader(filterVO, Constants.POPUP_PYMT_DETAIL, null, pymtType);
			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCreiteriaHeader);
		}
		else { //customer just click a particular payment
			if("true".equals(isPopUp))
				filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_PYMT_DETAIL_POP_UP_FILTERVO);
			else{
				if(Constants.READ_ONLY.equals(baseForm.getPageType()))
					filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DETAIL_FILTERVO);
				else
					filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_FILTERVO);
			}
			//create a new filter and save it in session for print or export.
			filterVO = filterVO.cloneFilter();
			filterVO.setStartDate(baseForm.getFromDate());
			filterVO.setEndDate(baseForm.getFromDate());
			String searchHic = (String)request.getParameter("searchHic");
			if (StringUtil.trimToNull(searchHic) != null)
				filterVO.setHicNumber(searchHic);
			sessionHelper.setAttribute(Constants.SESSION_EFFDATE_POPUP_FILTER, filterVO);
		}
		PymtEffDateDetailVO discrepancySummaryVOList = PaymentManager.getBenePymtDetailByParts(filterVO, planMap, sessionHelper.getActiveDataBaseName(), seqNbr, pymtType);
		baseForm.setPymtEffDateDetailVO(discrepancySummaryVOList);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	/**
	 *  <code>getPaymentSummary</code> get disease detail  from buiness layers, set to request scope
	 * and returns to appropiate UI.
	 * @param request
	 * @param baseForm
	 * @throws ApplicationException
	 */
	public void diseaseGroupDetail(HttpServletRequest request, BaseForm baseForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		FilterVO filterVO = new FilterVO();
		SessionHelper sessionHelper = new SessionHelper(request);
		//get partamter from request object which are send from ui.
		String cmsValue = (String)request.getParameter("cmsValue");
		String planValue = (String)request.getParameter("planValue");
		String hicNbr = (String)request.getParameter("hicNbr");
		String pageType = (String)request.getParameter("pageType");
		String pbpId = (String)request.getParameter("pbpId");
		String planName = (String)request.getParameter("planName");
		
		request.setAttribute("fromDate",baseForm.getFromDate());
		request.setAttribute("partName",baseForm.getPartName());
		request.setAttribute("menuName",baseForm.getMenuName());
		
		/*if(Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(baseForm.getMenuName())) {
		 if(Constants.READ_ONLY.equals(pageType)) //when request is from show discrepancy (which is read only screen)
		 filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_FILTERVO);
		 else
		 filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DETAIL_FILTERVO);
		 } else
		 filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_FILTERVO);
		 */
		
		String partName = filterVO.getPartName();
		String effDate = filterVO.getStartDate();
		String endDate = filterVO.getEndDate();
		String hicNumber = filterVO.getHicNumber();
		String tempPbpId = filterVO.getPbpId();
		
		//Set filter vo to find disease group detail on effective date and for hic number.
		filterVO.setPlanName(planName);
		filterVO.setStartDate(baseForm.getFromDate());
		filterVO.setEndDate(baseForm.getFromDate());
		filterVO.setHicNumber(hicNbr);
		filterVO.setPartName(baseForm.getPartName());
		filterVO.setPbpId(pbpId);
		
		
		Map planMap = sessionHelper.getPlanForParts();
		
		if(request.getParameter("print")!= null){ // Print report resquest
			String searchCreiteriaHeader = DiscrepancyManager.getSearchCreiteriaHeader(filterVO, Constants.POPUP_DISEASE, null, sessionHelper.getActiveDataBaseName());
			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCreiteriaHeader);
		}
		
		DiseaseGroupVOList  diseaseGroupVO = DiscrepancyManager.diseaseGroupDetail(filterVO, cmsValue,planValue,sessionHelper.getActiveDataBaseName(),planMap);
		baseForm.setDiseaseGroupVOList(diseaseGroupVO);
		//Reset filter vo by default values.
		filterVO.setPartName(partName);
		filterVO.setStartDate(effDate);
		filterVO.setEndDate(endDate);
		filterVO.setHicNumber(hicNumber);
		filterVO.setPbpId(tempPbpId);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	/**
	 *  <code>getPaymentSummary</code> getReconciliation from buiness layers, set to request scope
	 * and returns to appropiate UI.
	 * @param request
	 * @param baseForm
	 * @throws ApplicationException
	 */
	public void reconciliation(HttpServletRequest request, BaseForm baseForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = new SessionHelper(request);
		FilterVO filterVO = null;

		/*if(Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(baseForm.getMenuName())) {
		 if(Constants.READ_ONLY.equals(pageType)) //when request is from show discrepancy (which is read only screen)
		 filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_FILTERVO);
		 else
		 filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DETAIL_FILTERVO);
		 } else if("paymentDetail".equals(baseForm.getMenuName())){
		 filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_FILTERVO);
		 } else 
		 filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_FILTERVO);
		 */   
		
		String hicNbr = (String)request.getParameter("hicNbr");
		String partName = baseForm.getPartName();
		if(Constants.BOTH_PARTS.equals(partName)) {
			partName = sessionHelper.getServicesToAccess();
		}
		
		//Set filter vo to find reconcilation on effective date and for hic number.
		FilterVO tempFilterVO = new FilterVO();
		tempFilterVO.setPlanName(baseForm.getPlanName());
		tempFilterVO.setStartDate(baseForm.getFromDate());
		tempFilterVO.setEndDate(baseForm.getFromDate());
		tempFilterVO.setHicNumber(hicNbr);
		tempFilterVO.setSearchType(sessionHelper.evaluteSearchType(tempFilterVO));
		tempFilterVO.setPartName(partName);
		
		if(request.getParameter("print")!= null){ // Print report resquest
			String searchCreiteriaHeader = PaymentManager.getSearchCreiteriaHeader(tempFilterVO, Constants.POPUP_RECONCILATION, null, sessionHelper.getActiveDataBaseName());
			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCreiteriaHeader);
		} else {
			request.setAttribute("fromDate", baseForm.getFromDate());
			request.setAttribute("menuName", baseForm.getMenuName());
			request.setAttribute("planName", baseForm.getPlanName());
		}
		request.setAttribute("partName", partName);
		
		Map planMap = sessionHelper.getPlanForParts();
		ReconciliationListVO reconciliationListVO = PaymentManager.getReconcilationList(tempFilterVO, planMap, sessionHelper.getActiveDataBaseName());
		baseForm.setReconciliationListVO(reconciliationListVO);
		setBaseForm(baseForm, tempFilterVO);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void setTabAndFormName(HttpServletRequest request, String menuName, String formName) {
		logger.info(LoggerConstants.methodStartLevel());
		request.setAttribute(Constants.ATTR_MENU, menuName);
		request.setAttribute(Constants.ATTR_FORM, formName);
		logger.info(LoggerConstants.methodEndLevel());
	}
}
