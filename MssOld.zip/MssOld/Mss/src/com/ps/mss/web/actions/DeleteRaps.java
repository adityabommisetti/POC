/*
 * $Id: DeleteRaps.java,v 1.1 2014/06/26 07:56:41 praveen Exp $
 */
package com.ps.mss.web.actions;

import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.DynaActionForm;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.db.DbConnWeb;
import com.ps.mss.framework.RapsConstants;
import com.ps.mss.manager.ContextManager;
import com.ps.mss.model.RapsClusterForm;
import com.ps.mss.model.RapsContext;
import com.ps.mss.model.RapsDetailInfo;
import com.ps.mss.model.RapsFilter;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.web.helper.Utility;
import com.ps.mss.manager.RapsManager;

/**
 * @author indrapradja.adriana
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DeleteRaps extends Action {
	private static Logger logger=LoggerFactory.getLogger(DeleteRaps.class);
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		RapsContext rc = (RapsContext) ContextManager.getContext(request, RapsConstants.RAPS_CONTEXT);
		DynaActionForm genericForm = (DynaActionForm) form;
		Utility.saveExpandedItems(rc, (String)genericForm.get("uiContext"), (String)genericForm.get("pageName"));
		RapsDetailInfo detailInfo = rc.getLastRapsDetail();
	    RapsFilter filter = null; Connection conn = null; boolean anyError = false;
		try {
			if (detailInfo.getDeleteType() != 0) { //check in case page is resubmitted 
				// use the default DB for security check
				conn = DbConnWeb.getConnection();
				SessionHelper sessionHelper = new SessionHelper(request);
				Utility.copyFromSessionToRequest(rc, request, sessionHelper);
				String errorMsg = sessionHelper.validateUser(conn);
				if (errorMsg != null) {
					request.setAttribute("Msg",errorMsg);
					logger.info(LoggerConstants.methodEndLevel());
					return mapping.findForward("rapsError");
				}
				
				// now get the connection to the RAPS Db
				String dbId = sessionHelper.getRapsDatabaseName();
				conn = DbConnWeb.reGetConnection(conn,dbId);
	
				String method = (String)genericForm.get("method");
				if ("setup".equals(method)) {
					logger.info(LoggerConstants.methodEndLevel());
					return mapping.findForward(RapsConstants.RAPS_DELETE);	
				}
				else if ("cancel".equals(method)) {
					if (rc.getCurrentTAB()== RapsConstants.CLAIM_TAB) {
						//return mapping.findForward((RapsConstants.RAPS_CLAIMS_DETAILS));
						logger.info(LoggerConstants.methodEndLevel());
						return mapping.findForward("buildRapsDetail");
					}
					/* Return "cancelFromRapsDetail" so that the RapsActionFC knows this and can set 
					 * RapsContext.ReuseList properly */
					logger.info(LoggerConstants.methodEndLevel());
					return mapping.findForward("cancelFromRapsDetail"); 
				}
				String comments = (String)genericForm.get("comments");
				StringBuffer errmsg = new StringBuffer(""); 
				
				//Since this is from a delete button, there's no associated entry form. Create one, and populate it
				RapsClusterForm entry = new RapsClusterForm();
				entry.setComments(comments);
				entry.setUserId(sessionHelper.getUserId());
				entry.setActDel("del");
				boolean result = RapsManager.deleteRapsDetail(conn, entry, detailInfo, errmsg);
				if (result) {
					detailInfo.setDeleteType(0); //already deleted. Now mark it as cannot be deleted.
					request.setAttribute("ERROR_MSG", "You have successfully delete the entry");
				}
				else 
					request.setAttribute("ERROR_MSG", "Delete Encounter an error");
			}
		} catch (Exception e) {
			anyError = true;
			logger.error("DeleteRaps encounters exception " + e.getMessage());
		}
		finally {
			if(conn != null){
				try {
					conn.close();
				} catch (SQLException e) {
					anyError = true;
				}
			}	
		}
		if (anyError){
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward("rapsError");
		}
		//Either going back to Claim detail or raps detail
		//TODO need to refresh the page.
		if (rc.getCurrentTAB()== RapsConstants.CLAIM_TAB){
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward((RapsConstants.RAPS_CLAIMS_DETAILS));
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(RapsConstants.RAPS_DETAIL); 
		
	}
}
