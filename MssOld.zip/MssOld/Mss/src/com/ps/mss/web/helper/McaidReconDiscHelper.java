
package com.ps.mss.web.helper;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.web.forms.McaidReconDiscForm;

public class McaidReconDiscHelper {
	private static Logger logger=LoggerFactory.getLogger(McaidReconDiscHelper.class);
	public static void saveDiscForm(SessionHelper sessionHelper, McaidReconDiscForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		sessionHelper.setAttribute("SavediscForm",form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	public static McaidReconDiscForm getDiscForm(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (McaidReconDiscForm)sessionHelper.getAttribute("SavediscForm");
	}
	
}//MCReconDiscHelper
