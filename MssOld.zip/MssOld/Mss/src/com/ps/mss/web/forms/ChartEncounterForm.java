package com.ps.mss.web.forms;

import java.util.Arrays;

import com.ps.text.DateFormatter;
import com.ps.util.GridUtil;

/**
 * @author DParker
 */
public class ChartEncounterForm extends HPEForm {

	private String displayMessage = "";    
    private String focusField;	
	// Summary search criteria
	private String searchCRSummaryDateInd = "0";
	private String searchCRSummaryFromDate = "";
	private String searchCRSummaryToDate = "";
	private String searchCRSummaryEncType = "I";
	private String searchCRSummaryType = "CR";
	private String searchCRSummaryGroupStatus = "";
	private String searchCRSummarySubmitterId = "";
	private String searchCRSummaryErrorSource = "";
	private String searchCRSummaryErrorGroup = "";
	private String searchCRSummaryErrorCode = "";
	private String rejectCode = "";	
	private String formattedErrorSource = "";
	private String selectedCRDateYrmo = "";	
	private String selectedCRErrorGroup = "";
	private GridUtil statusSummaryGrid = null;
	
	private String origFileId;
	private boolean fileTrackingFlag = false;
	
	//Editable Fileds CHS -- IFOX-00395627
	public static final int ENUM_METHOD_EDITABLE_CLAIM_CODE_SECTION = 51;
	public static final int ENUM_CHECK_DUPL_CLAIM_CODE_SECTION=901;
	public static final int ENUM_METHOD_EDITABLE_ADD_CODE_SECTION = 52;
	public static final String CHECK_DUPL_CLAIM_CODE_SECTION="checkDuplicateClaimCodesSection";
	public static final String EDITABLE_CLAIM_CODE_SECTION = "editableClaimCodesSection";
	public static final String EDITABLE_ADD_CODE_SECTION = "editableAddClaimCodesSection";
	
	public static final String EDITABLE_COND_CODE_CNSTNT ="COND_CODE";
	public static final String EDITABLE_DIAG_CODE_CNSTNT ="DIAG_CODE";
	public static final String EDITABLE_PROCEDURE_CODE_CNSTNT ="PROC_CODE";
	public static final String EDITABLE_OCCURSPAN_CODE_CNSTNT ="OCCUR_SPAN_CODE";
	public static final String EDITABLE_VALUE_CODE_CNSTNT ="VALUE_CODE";
	public static final String EDITABLE_OCCURENCE_CODE_CNSTNT ="OCCUR_CODE";
	public static final String EDITABLE_TREATMENT_CODE_CNSTNT ="TRTMNT_CODE";
	public static final String EDITABLE_EXT_INJ_CODE_CNSTNT ="EXT_INJ_CODE";

	//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : Start
	private String maoflag ="";
	
	public String getMaoflag() {
		return maoflag;
	}
	public void setMaoflag(String maoflag) {
		this.maoflag = maoflag;
	}
	//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : End
	
	//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - Start
	private String searchPayerSecId;
	private String searchSubsGrpOrPolNbr;
	
	public String getSearchPayerSecId() {
		return searchPayerSecId;
	}
	public void setSearchPayerSecId(String searchPayerSecId) {
		this.searchPayerSecId = searchPayerSecId;
	}
	public String getSearchSubsGrpOrPolNbr() {
		return searchSubsGrpOrPolNbr;
	}
	public void setSearchSubsGrpOrPolNbr(String searchSubsGrpOrPolNbr) {
		this.searchSubsGrpOrPolNbr = searchSubsGrpOrPolNbr;
	}
	//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - End
	
	//Editable Fileds CHS -- IFOX-00395627
	
	//Editable Fileds CHS -- IFOX-00395627	
	private boolean instConditionCodeExpanded = false;
	public boolean isProfConditionCodeExpanded() {
		return profConditionCodeExpanded;
	}
	public void setProfConditionCodeExpanded(boolean profConditionCodeExpanded) {
		this.profConditionCodeExpanded = profConditionCodeExpanded;
	}
	public boolean isProfDiagCodeExpanded() {
		return profDiagCodeExpanded;
	}
	public void setProfDiagCodeExpanded(boolean profDiagCodeExpanded) {
		this.profDiagCodeExpanded = profDiagCodeExpanded;
	}
	public boolean isInstProcedureCodeExpanded() {
		return instProcedureCodeExpanded;
	}
	public void setInstProcedureCodeExpanded(boolean instProcedureCodeExpanded) {
		this.instProcedureCodeExpanded = instProcedureCodeExpanded;
	}
	public boolean isInstOccurrenceSpanExpanded() {
		return instOccurrenceSpanExpanded;
	}
	public void setInstOccurrenceSpanExpanded(boolean instOccurrenceSpanExpanded) {
		this.instOccurrenceSpanExpanded = instOccurrenceSpanExpanded;
	}
	public boolean isInstValueExpanded() {
		return instValueExpanded;
	}
	public void setInstValueExpanded(boolean instValueExpanded) {
		this.instValueExpanded = instValueExpanded;
	}
	public boolean isInstOccurrenceExpanded() {
		return instOccurrenceExpanded;
	}
	public void setInstOccurrenceExpanded(boolean instOccurrenceExpanded) {
		this.instOccurrenceExpanded = instOccurrenceExpanded;
	}
	public boolean isInstTreatmentExpanded() {
		return instTreatmentExpanded;
	}
	public void setInstTreatmentExpanded(boolean instTreatmentExpanded) {
		this.instTreatmentExpanded = instTreatmentExpanded;
	}
	public boolean isInstExtCauseInjuryExpanded() {
		return instExtCauseInjuryExpanded;
	}
	public void setInstExtCauseInjuryExpanded(boolean instExtCauseInjuryExpanded) {
		this.instExtCauseInjuryExpanded = instExtCauseInjuryExpanded;
	}
	public String getHier() {
		return hier;
	}
	public void setHier(String hier) {
		this.hier = hier;
	}
	public String getEditableCode() {
		return editableCode;
	}
	public void setEditableCode(String editableCode) {
		this.editableCode = editableCode;
	}
	public String getEditableType() {
		return editableType;
	}
	public void setEditableType(String editableType) {
		this.editableType = editableType;
	}
	public String getEditablePOA() {
		return editablePOA;
	}
	public void setEditablePOA(String editablePOA) {
		this.editablePOA = editablePOA;
	}
	public String getEditableDate() {
		return editableDate;
	}
	public void setEditableDate(String editableDate) {
		this.editableDate = editableDate;
	}
	public String getEditableFromDt() {
		return editableFromDt;
	}
	public void setEditableFromDt(String editableFromDt) {
		this.editableFromDt = editableFromDt;
	}
	public String getEditableThruDt() {
		return editableThruDt;
	}
	public void setEditableThruDt(String editableThruDt) {
		this.editableThruDt = editableThruDt;
	}
	public Double getEditableAmount() {
		return editableAmount;
	}
	public void setEditableAmount(Double editableAmount) {
		this.editableAmount = editableAmount;
	}
	public String getEditableEncType() {
		return editableEncType;
	}
	public void setEditableEncType(String editableEncType) {
		this.editableEncType = editableEncType;
	}
	public String getEditableMfid() {
		return editableMfid;
	}
	public void setEditableMfid(String editableMfid) {
		this.editableMfid = editableMfid;
	}
	public String getEditableCndSeqNbr() {
		return editableCndSeqNbr;
	}
	public void setEditableCndSeqNbr(String editableCndSeqNbr) {
		this.editableCndSeqNbr = editableCndSeqNbr;
	}
	public String getEditableCodeSecMsg() {
		return editableCodeSecMsg;
	}
	public void setEditableCodeSecMsg(String editableCodeSecMsg) {
		this.editableCodeSecMsg = editableCodeSecMsg;
	}
	public String getCustSentMbiInd() {
		return CustSentMbiInd;
	}
	public void setCustSentMbiInd(String custSentMbiInd) {
		CustSentMbiInd = custSentMbiInd;
	}

	private boolean instDiagCodeExpanded = false;
	private boolean profConditionCodeExpanded = false;
	private boolean profDiagCodeExpanded = false;
	private boolean instProcedureCodeExpanded = false;
	private boolean instOccurrenceSpanExpanded = false;
	private boolean instValueExpanded = false;
	private boolean instOccurrenceExpanded = false;
	private boolean instTreatmentExpanded = false;
	private boolean instExtCauseInjuryExpanded = false;	
	
	private String hier;
	private String editableCode;
	private String editableType;
	private String editablePOA;
	private String editableDate;
	private String editableFromDt;
	private String editableThruDt;
	private Double editableAmount;
	private String editableEncType;
	
	private String editableMfid;
	private String editableCndSeqNbr;
	private String editableCodeSecMsg;
	
	
	//Editable Fileds CHS -- IFOX-00395627
	
	//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
	private String editableAdjGroupCode;
	private String editableAdjReasonCode;
	private Double editableAdjAmount;
	private int editableAdjQuantity;
	private int editableAdjudSeqNbr;
	private int editableAdjustSeqNbr;
	private String clmliSeqNbr;
	
	public String getEditableAdjGroupCode() {
		return editableAdjGroupCode;
	}
	public void setEditableAdjGroupCode(String editableAdjGroupCode) {
		this.editableAdjGroupCode = editableAdjGroupCode;
	}
	public String getEditableAdjReasonCode() {
		return editableAdjReasonCode;
	}
	public void setEditableAdjReasonCode(String editableAdjReasonCode) {
		this.editableAdjReasonCode = editableAdjReasonCode;
	}
	public Double getEditableAdjAmount() {
		return editableAdjAmount;
	}
	public void setEditableAdjAmount(Double editableAdjAmount) {
		this.editableAdjAmount = editableAdjAmount;
	}
	public int getEditableAdjQuantity() {
		return editableAdjQuantity;
	}
	public void setEditableAdjQuantity(int editableAdjQuantity) {
		this.editableAdjQuantity = editableAdjQuantity;
	}
	public int getEditableAdjudSeqNbr() {
		return editableAdjudSeqNbr;
	}
	public void setEditableAdjudSeqNbr(int editableAdjudSeqNbr) {
		this.editableAdjudSeqNbr = editableAdjudSeqNbr;
	}
	public int getEditableAdjustSeqNbr() {
		return editableAdjustSeqNbr;
	}
	public void setEditableAdjustSeqNbr(int editableAdjustSeqNbr) {
		this.editableAdjustSeqNbr = editableAdjustSeqNbr;
	}
	public String getClmliSeqNbr() {
		return clmliSeqNbr;
	}
	public void setClmliSeqNbr(String clmliSeqNbr) {
		this.clmliSeqNbr = clmliSeqNbr;
	}
	//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
	public boolean isFileTrackingFlag() {
		return fileTrackingFlag;
	}
	public void setFileTrackingFlag(boolean fileTrackingFlag) {
		this.fileTrackingFlag = fileTrackingFlag;
	}
	public String getOrigFileId() {
		return origFileId;
	}
	public void setOrigFileId(String origFileId) {
		this.origFileId = origFileId;
	}

	
	public String getFormattedErrorSource() {
		return formattedErrorSource;
	}
	public void setFormattedErrorSource(String formattedErrorSource) {
		this.formattedErrorSource = formattedErrorSource;
	}
	public String getRejectCode() {
		return rejectCode;
	}
	public void setRejectCode(String rejectCode) {
		this.rejectCode = rejectCode;
	}	

	// Detail search criteria
	private String searchCRDetailSubmitterId = "";
	private String searchCRDetailEncType = "I";
	private String searchCRDetailDateInd = "0";
	private String searchCRDetailClmType = "CR";
	private String searchCRDetailFromDate = "";
	private String searchCRDetailToDate = "";
	private String searchCRDetailClaimRefNbr = "";
	private String searchCRDetailHicNbr = "";
	private String searchCRDetailGroupStatus = "";
	private String searchCRDetailProcessStatus = "";
	private String searchCRDetailErrorSource = "";
	private String searchCRDetailErrorGroup = "";
	private String searchCRDetailErrorCode = "";

	//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start 
	private String searchVanTanNumber ="";
	//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
		
	// Claim select values
	private String selectedClaimType = "";		// TODO: s/b enum
	private String selectedClaimRefNbr = "";
	private String selectedClaimRevNbr = "";
	private String selectedClaimSeqNbr = "";

	private String firstClaimType = "";		// TODO: s/b enum
	private String firstClaimRefNbr = "";
	private String firstClaimRevNbr = "";
	private String firstClaimSeqNbr = "";

	private boolean dataChanged;
	private String claimType = "";	
	private String claimRefNbr = "";
	private String submitterId = "";
	private String prevMenu = "";
	private String prevMethod = "";
	private String dateInd = "";
	private String clmType = "";
	
	
	// Toggle fields
	private boolean instListExpanded = true;
	private boolean instErrorsExpanded = true;
	private boolean instSubscriberExpanded = false;
	private boolean instClaimExpanded = false;
	private boolean instClaimCodesExpanded = false;
	private boolean instClaimProvExpanded = false;
	private boolean instClaimProvDetailExpanded = true;
	private boolean instClaimOtherSubsExpanded = false;
	private boolean instClaimOtherSubsDetailExpanded = true;
	private boolean instClaimOtherSubsProvExpanded = false;
	private boolean instClaimOtherSubsProvDetailExpanded = true;
	private boolean instClaimLineExpanded = false;
	private boolean instClaimLineDetailExpanded = true;
	private boolean instClaimLineProvExpanded = false;
	private boolean instClaimLineProvDetailExpanded = true;
	private boolean instClaimLineAdjudExpanded = false;
	private boolean instClaimLineAdjudDetailExpanded = true;
	private boolean instClaimNotesExpanded = false;
	private boolean instProviderExpanded = false;

	private boolean profListExpanded = true;
	private boolean profErrorsExpanded = true;
	private boolean profSubscriberExpanded = false;
	private boolean profClaimExpanded = false;
	private boolean profClaimCodesExpanded = false;
	private boolean profClaimProvExpanded = false;
	private boolean profClaimProvDetailExpanded = true;
	private boolean profClaimOtherSubsExpanded = false;
	private boolean profClaimOtherSubsDetailExpanded = true;
	private boolean profClaimOtherSubsProvExpanded = false;
	private boolean profClaimOtherSubsProvDetailExpanded = true;
	private boolean profClaimLineExpanded = false;
	private boolean profClaimLineDetailExpanded = true;
	private boolean profClaimLineProvExpanded = false;
	private boolean profClaimLineProvDetailExpanded = true;
	private boolean profClaimLineAdjudExpanded = false;
	private boolean profClaimLineAdjudDetailExpanded = true;
	private boolean profProviderExpanded = false;
	
	// Detail search criteria
	private String searchDetailSubmitterId = "";
	public String getSearchDetailSubmitterId() {
		return searchDetailSubmitterId;
	}
	public void setSearchDetailSubmitterId(String searchDetailSubmitterId) {
		this.searchDetailSubmitterId = searchDetailSubmitterId;
	}
	public String getSearchDetailEncType() {
		return searchDetailEncType;
	}
	public void setSearchDetailEncType(String searchDetailEncType) {
		this.searchDetailEncType = searchDetailEncType;
	}
	public String getSearchDetailClmType() {
		return searchDetailClmType;
	}
	public void setSearchDetailClmType(String searchDetailClmType) {
		this.searchDetailClmType = searchDetailClmType;
	}
	public String getSearchDetailDateInd() {
		return searchDetailDateInd;
	}
	public void setSearchDetailDateInd(String searchDetailDateInd) {
		this.searchDetailDateInd = searchDetailDateInd;
	}
	public String getSearchDetailFromDate() {
		return searchDetailFromDate;
	}
	public void setSearchDetailFromDate(String searchDetailFromDate) {
		this.searchDetailFromDate = searchDetailFromDate;
	}
	public String getSearchDetailToDate() {
		return searchDetailToDate;
	}
	public void setSearchDetailToDate(String searchDetailToDate) {
		this.searchDetailToDate = searchDetailToDate;
	}
	public String getSearchDetailClaimRefNbr() {
		return searchDetailClaimRefNbr;
	}
	public void setSearchDetailClaimRefNbr(String searchDetailClaimRefNbr) {
		this.searchDetailClaimRefNbr = searchDetailClaimRefNbr;
	}
	public String getSearchDetailHicNbr() {
		return searchDetailHicNbr;
	}
	public void setSearchDetailHicNbr(String searchDetailHicNbr) {
		this.searchDetailHicNbr = searchDetailHicNbr;
	}
	public String getSearchDetailGroupStatus() {
		return searchDetailGroupStatus;
	}
	public void setSearchDetailGroupStatus(String searchDetailGroupStatus) {
		this.searchDetailGroupStatus = searchDetailGroupStatus;
	}
	public String getSearchDetailProcessStatus() {
		return searchDetailProcessStatus;
	}
	public void setSearchDetailProcessStatus(String searchDetailProcessStatus) {
		this.searchDetailProcessStatus = searchDetailProcessStatus;
	}
	public String getSearchDetailErrorSource() {
		return searchDetailErrorSource;
	}
	public void setSearchDetailErrorSource(String searchDetailErrorSource) {
		this.searchDetailErrorSource = searchDetailErrorSource;
	}
	public String getSearchDetailErrorGroup() {
		return searchDetailErrorGroup;
	}
	public void setSearchDetailErrorGroup(String searchDetailErrorGroup) {
		this.searchDetailErrorGroup = searchDetailErrorGroup;
	}
	public String getSearchDetailErrorCode() {
		return searchDetailErrorCode;
	}
	public void setSearchDetailErrorCode(String searchDetailErrorCode) {
		this.searchDetailErrorCode = searchDetailErrorCode;
	}

	private String searchDetailEncType = "I";
	private String searchDetailClmType = "EN";
	private String searchDetailDateInd = "0";
	private String searchDetailFromDate = "";
	private String searchDetailToDate = "";
	private String searchDetailClaimRefNbr = "";
	private String searchDetailHicNbr = "";
	private String searchDetailGroupStatus = "";
	private String searchDetailProcessStatus = "";
	private String searchDetailErrorSource = "";
	private String searchDetailErrorGroup = "";
	private String searchDetailErrorCode = "";
	
	//claim other subscriber
		private String othSubsSeqNbr;
		private String insuredGrpOrPolNbr;	
		private String benefitsAsgnCertInd;
		private String formattedCheckRemitDt;
		private String payerResponseCd;	
		private String releaseMedRcdFlg;
		private String indivRelationshipCd;
		private int miaCoveredDays;	
		private int miaLifePsychDayCnt;
		private int miaCostDayCnt;
		private String miaClmpmtRemarkCd;
		public String getOthSubsSeqNbr() {
			return othSubsSeqNbr;
		}
		public void setOthSubsSeqNbr(String othSubsSeqNbr) {
			this.othSubsSeqNbr = othSubsSeqNbr;
		}
		public String getInsuredGrpOrPolNbr() {
			return insuredGrpOrPolNbr;
		}
		public void setInsuredGrpOrPolNbr(String insuredGrpOrPolNbr) {
			this.insuredGrpOrPolNbr = insuredGrpOrPolNbr;
		}
		public String getBenefitsAsgnCertInd() {
			return benefitsAsgnCertInd;
		}
		public void setBenefitsAsgnCertInd(String benefitsAsgnCertInd) {
			this.benefitsAsgnCertInd = benefitsAsgnCertInd;
		}
		public String getFormattedCheckRemitDt() {
			return formattedCheckRemitDt;
		}
		public void setFormattedCheckRemitDt(String formattedCheckRemitDt) {
			this.formattedCheckRemitDt = formattedCheckRemitDt;
		}
		public String getPayerResponseCd() {
			return payerResponseCd;
		}
		public void setPayerResponseCd(String payerResponseCd) {
			this.payerResponseCd = payerResponseCd;
		}
		public String getReleaseMedRcdFlg() {
			return releaseMedRcdFlg;
		}
		public void setReleaseMedRcdFlg(String releaseMedRcdFlg) {
			this.releaseMedRcdFlg = releaseMedRcdFlg;
		}
		public String getIndivRelationshipCd() {
			return indivRelationshipCd;
		}
		public void setIndivRelationshipCd(String indivRelationshipCd) {
			this.indivRelationshipCd = indivRelationshipCd;
		}
		public int getMiaCoveredDays() {
			return miaCoveredDays;
		}
		public void setMiaCoveredDays(int miaCoveredDays) {
			this.miaCoveredDays = miaCoveredDays;
		}
		public int getMiaLifePsychDayCnt() {
			return miaLifePsychDayCnt;
		}
		public void setMiaLifePsychDayCnt(int miaLifePsychDayCnt) {
			this.miaLifePsychDayCnt = miaLifePsychDayCnt;
		}
		public int getMiaCostDayCnt() {
			return miaCostDayCnt;
		}
		public void setMiaCostDayCnt(int miaCostDayCnt) {
			this.miaCostDayCnt = miaCostDayCnt;
		}
		public String getMiaClmpmtRemarkCd() {
			return miaClmpmtRemarkCd;
		}
		public void setMiaClmpmtRemarkCd(String miaClmpmtRemarkCd) {
			this.miaClmpmtRemarkCd = miaClmpmtRemarkCd;
		}
		public String getMiaClmPmtRemarkCd1() {
			return miaClmPmtRemarkCd1;
		}
		public void setMiaClmPmtRemarkCd1(String miaClmPmtRemarkCd1) {
			this.miaClmPmtRemarkCd1 = miaClmPmtRemarkCd1;
		}
		public String getMiaClmPmtRemarkCd2() {
			return miaClmPmtRemarkCd2;
		}
		public void setMiaClmPmtRemarkCd2(String miaClmPmtRemarkCd2) {
			this.miaClmPmtRemarkCd2 = miaClmPmtRemarkCd2;
		}
		public String getMiaClmPmtRemarkCd3() {
			return miaClmPmtRemarkCd3;
		}
		public void setMiaClmPmtRemarkCd3(String miaClmPmtRemarkCd3) {
			this.miaClmPmtRemarkCd3 = miaClmPmtRemarkCd3;
		}
		public String getMiaClmPmtRemarkCd4() {
			return miaClmPmtRemarkCd4;
		}
		public void setMiaClmPmtRemarkCd4(String miaClmPmtRemarkCd4) {
			this.miaClmPmtRemarkCd4 = miaClmPmtRemarkCd4;
		}
		public int getFormattedMoaReimburseRate() {
			return formattedMoaReimburseRate;
		}
		public void setFormattedMoaReimburseRate(int formattedMoaReimburseRate) {
			this.formattedMoaReimburseRate = formattedMoaReimburseRate;
		}
		public String getMoaClmPmtRemarkCd1() {
			return moaClmPmtRemarkCd1;
		}
		public void setMoaClmPmtRemarkCd1(String moaClmPmtRemarkCd1) {
			this.moaClmPmtRemarkCd1 = moaClmPmtRemarkCd1;
		}
		public String getMoaClmPmtRemarkCd2() {
			return moaClmPmtRemarkCd2;
		}
		public void setMoaClmPmtRemarkCd2(String moaClmPmtRemarkCd2) {
			this.moaClmPmtRemarkCd2 = moaClmPmtRemarkCd2;
		}
		public String getMoaClmPmtRemarkCd3() {
			return moaClmPmtRemarkCd3;
		}
		public void setMoaClmPmtRemarkCd3(String moaClmPmtRemarkCd3) {
			this.moaClmPmtRemarkCd3 = moaClmPmtRemarkCd3;
		}
		public String getMoaClmPmtRemarkCd4() {
			return moaClmPmtRemarkCd4;
		}
		public void setMoaClmPmtRemarkCd4(String moaClmPmtRemarkCd4) {
			this.moaClmPmtRemarkCd4 = moaClmPmtRemarkCd4;
		}
		public String getMoaClmPmtRemarkCd5() {
			return moaClmPmtRemarkCd5;
		}
		public void setMoaClmPmtRemarkCd5(String moaClmPmtRemarkCd5) {
			this.moaClmPmtRemarkCd5 = moaClmPmtRemarkCd5;
		}
		public String getOtherClmFilingInd() {
			return otherClmFilingInd;
		}
		public void setOtherClmFilingInd(String otherClmFilingInd) {
			this.otherClmFilingInd = otherClmFilingInd;
		}
		public String getOthPayrOrgName() {
			return othPayrOrgName;
		}
		public void setOthPayrOrgName(String othPayrOrgName) {
			this.othPayrOrgName = othPayrOrgName;
		}
		public String getOthSubsPayrPayerId() {
			return othSubsPayrPayerId;
		}
		public void setOthSubsPayrPayerId(String othSubsPayrPayerId) {
			this.othSubsPayrPayerId = othSubsPayrPayerId;
		}
		public String getOthPayrClmadjInd() {
			return othPayrClmadjInd;
		}
		public void setOthPayrClmadjInd(String othPayrClmadjInd) {
			this.othPayrClmadjInd = othPayrClmadjInd;
		}
		public String getOthPayrAddrLine1() {
			return othPayrAddrLine1;
		}
		public void setOthPayrAddrLine1(String othPayrAddrLine1) {
			this.othPayrAddrLine1 = othPayrAddrLine1;
		}
		public String getOthPayrPlanId() {
			return othPayrPlanId;
		}
		public void setOthPayrPlanId(String othPayrPlanId) {
			this.othPayrPlanId = othPayrPlanId;
		}
		public String getOthPayrAddrLine2() {
			return othPayrAddrLine2;
		}
		public void setOthPayrAddrLine2(String othPayrAddrLine2) {
			this.othPayrAddrLine2 = othPayrAddrLine2;
		}
		public String getOthPayrSecId() {
			return othPayrSecId;
		}
		public void setOthPayrSecId(String othPayrSecId) {
			this.othPayrSecId = othPayrSecId;
		}
		public String getOthPayrCity() {
			return othPayrCity;
		}
		public void setOthPayrCity(String othPayrCity) {
			this.othPayrCity = othPayrCity;
		}
		public String getOthPayrState() {
			return othPayrState;
		}
		public void setOthPayrState(String othPayrState) {
			this.othPayrState = othPayrState;
		}
		public String getOthPayrZip() {
			return othPayrZip;
		}
		public void setOthPayrZip(String othPayrZip) {
			this.othPayrZip = othPayrZip;
		}
		public String getOthPayrCountry() {
			return othPayrCountry;
		}
		public void setOthPayrCountry(String othPayrCountry) {
			this.othPayrCountry = othPayrCountry;
		}
		public String getOthPayrCntrySubdCd() {
			return othPayrCntrySubdCd;
		}
		public void setOthPayrCntrySubdCd(String othPayrCntrySubdCd) {
			this.othPayrCntrySubdCd = othPayrCntrySubdCd;
		}
		public String getFormattedOthPayrTaxId() {
			return formattedOthPayrTaxId;
		}
		public void setFormattedOthPayrTaxId(String formattedOthPayrTaxId) {
			this.formattedOthPayrTaxId = formattedOthPayrTaxId;
		}
		public String getOthPayrLocNbr() {
			return othPayrLocNbr;
		}
		public void setOthPayrLocNbr(String othPayrLocNbr) {
			this.othPayrLocNbr = othPayrLocNbr;
		}
		public String getOthPayrNaic() {
			return othPayrNaic;
		}
		public void setOthPayrNaic(String othPayrNaic) {
			this.othPayrNaic = othPayrNaic;
		}
		public String getOthPayrPriorAuthNbr() {
			return othPayrPriorAuthNbr;
		}
		public void setOthPayrPriorAuthNbr(String othPayrPriorAuthNbr) {
			this.othPayrPriorAuthNbr = othPayrPriorAuthNbr;
		}
		public String getOthPayrReferralNbr() {
			return othPayrReferralNbr;
		}
		public void setOthPayrReferralNbr(String othPayrReferralNbr) {
			this.othPayrReferralNbr = othPayrReferralNbr;
		}
		public String getOthPayrClmCtrlNbr() {
			return othPayrClmCtrlNbr;
		}
		public void setOthPayrClmCtrlNbr(String othPayrClmCtrlNbr) {
			this.othPayrClmCtrlNbr = othPayrClmCtrlNbr;
		}
		public String getPatSignSrcCd() {
			return patSignSrcCd;
		}
		public void setPatSignSrcCd(String patSignSrcCd) {
			this.patSignSrcCd = patSignSrcCd;
		}
		public String getOthPayrProvLocNbr() {
			return othPayrProvLocNbr;
		}
		public void setOthPayrProvLocNbr(String othPayrProvLocNbr) {
			this.othPayrProvLocNbr = othPayrProvLocNbr;
		}
		public String getOthPayrProvLicNbr() {
			return othPayrProvLicNbr;
		}
		public void setOthPayrProvLicNbr(String othPayrProvLicNbr) {
			this.othPayrProvLicNbr = othPayrProvLicNbr;
		}
		public String getOthPayrProvUpin() {
			return othPayrProvUpin;
		}
		public void setOthPayrProvUpin(String othPayrProvUpin) {
			this.othPayrProvUpin = othPayrProvUpin;
		}
		public String getOthPayrProvCommNbr() {
			return othPayrProvCommNbr;
		}
		public void setOthPayrProvCommNbr(String othPayrProvCommNbr) {
			this.othPayrProvCommNbr = othPayrProvCommNbr;
		}
		public String getLookupOthPayrProvType() {
			return lookupOthPayrProvType;
		}
		public void setLookupOthPayrProvType(String lookupOthPayrProvType) {
			this.lookupOthPayrProvType = lookupOthPayrProvType;
		}
		public String getOthPayrProvEntityType() {
			return othPayrProvEntityType;
		}
		public void setOthPayrProvEntityType(String othPayrProvEntityType) {
			this.othPayrProvEntityType = othPayrProvEntityType;
		}

		private String miaClmPmtRemarkCd1;	
		private String miaClmPmtRemarkCd2;	
		private String miaClmPmtRemarkCd3;
		private String miaClmPmtRemarkCd4;
		private int formattedMoaReimburseRate;
		private String moaClmPmtRemarkCd1;
		private String moaClmPmtRemarkCd2;
		private String moaClmPmtRemarkCd3;	
		private String moaClmPmtRemarkCd4;
		private String moaClmPmtRemarkCd5;
		private String otherClmFilingInd;
		private String othPayrOrgName;	
		private String othSubsPayrPayerId;	
		private String othPayrClmadjInd;	
		private String othPayrAddrLine1;	
		private String othPayrPlanId;	
		private String othPayrAddrLine2;	
		private String othPayrSecId;	
		private String othPayrCity;
		private String othPayrState;
		private String othPayrZip;
		private String othPayrCountry;
		private String othPayrCntrySubdCd;	
		private String formattedOthPayrTaxId;
		private String othPayrLocNbr;
		private String othPayrNaic;
		private String othPayrPriorAuthNbr;
		private String othPayrReferralNbr;
		private String othPayrClmCtrlNbr;	
		private String patSignSrcCd;	
		
		private String othPayrProvLocNbr;
		private String othPayrProvLicNbr;
		private String othPayrProvUpin;
		private String othPayrProvCommNbr;	
		private String lookupOthPayrProvType;	
		private String othPayrProvEntityType;

    // View or Edit Fields
	private boolean subscriberChanged;
	private String subscriberDisplayState;
	
	private boolean claimChanged;
	private String claimDisplayState;	
	
	private boolean providerChanged;
	private String providerDisplayState;
	private String billProviderExist = "N";
	
	private boolean clmPrvChanged;
	private String clmProviderDisplayState;	
	private String clmProviderExist = "N";	
	
	//Subscriber Fields
	private String subsFirstName;
	private String subsMiddleName;
	private String subsLastName;
	private String subsHicNbr;
	private String mbi;
	private String CustSentMbiInd;
	private String formattedSubsSsn;
	private String formattedSubsDob;
	private String subsSex;
	private String subsAddrLine1;
	private String subsAddrLine2;
	private String subsCity;
	private String subsState;
	private String subsZip;	
	//Added for updating new feilds for Scbscriber data which are enabled in UI.
	private String subsPayerSeqCd;
	private String subsRelationCd;
	private String subsFilingIndCd;
	private String subsInsuranceTypeCd;
	private String subsEntityType;
	private String subsMemberId;
	private String subsCountry;
	private String SubsGrpName;
	private String subsCntrySubdCd;
	private String subsGrpOrPolNbr;
	private String subsPlanName;
    private String subsPatDod;	
    private int subsPatWeight;
	private String subsPatUom;
	private String subsPatPregnantInd;
	private String payerName;
	private String payerId;
	private String payerPlanId;
	private String payerAddrLine1;
	private String payerAddrLine2;
	private String payerCity;
	private String payerState;
	private String payerZip;
	private String payerCountry;
	private String payerCntrySubdCd;
	private String payerTaxId;
	private String payerLocNbr;
	private String payerNaicCd;
	private String payerSecId;
	private String billPrvCommNbr;
	private String billPrvLocNbr;
	private String propCasltyClmNbr;
	private String propCasltySubsName;
	private String propCasltySubsPhone;
	private String propCasltySubsPhnExt;
	
	//Claim Fields
	private String processStatus;
	private String placeOfService;
	private String clmFacTypeCd;
	private String admitType;
	private String admitSourceCd;
	private String admitDt;
	private String admitHour;
	private String patientStatusCd;
	private String mammogramCertNbr;
	private String cliaNbr;
	private String hospAdmitDt;
	private String hospDischargeDt;
	private String ambPickupAddrLine1;
	private String ambPickupAddrLine2;
	private String ambPickupCity;
	private String ambPickupState;
	private String ambPickupZip;
	private String ambDropoffLoc;
	private String ambDropoffAddrLine1;
	private String ambDropoffAddrLine2;
	private String ambDropoffCity;
	private String ambDropoffState;
	private String ambDropoffZip;
	
	//Claim new Feilds..
	private String patientCtrlNbr;
	private String wtxClaimRefNbr;
	private String contractVersionId;
	private String admitDiagCd;
	private String contractCd;
	private String svcFacContactName;
	private String svcFacPhone;
	private String svcFacPhoneExt;
	private String svcAuthExcptCd;
	private String statementFromDt;
	private String drgCd;
	private String statementToDt;
	private String anestSurgProcCd1;
	private String anestSurgProcCd2;
	private String visnCertCondInd;
	private String autoAccidentCountry;
	private String claimRefCd;
	private String patSignatureSrcCd;
	private String medicareCrossoverCd;
	private String labHomeRespCd;
	private String labHomeCondInd;
	private String visnCodeCategory;
	private String contractTypeCd;
	private String admitDiagType;
	private String prvAcceptAssignCd;
	private String releaseOfInfoCd;
	private String autoAccidentState;
	private String otherAccidentInd;
	private String prvSignatureOnfileInd;
	private String delayReasonCd;
	private String dischargeHour;
	private String beneAssignCertInd;
	private String visnCertCondCd1;
	private String visnCertCondCd2;
	private String visnCertCondCd3;
	private int wtxClaimRevNbr;
	private String clmFreqTypeCd;
	private String employmentAccidentInd;
	private String autoAccidentInd;
	private String epsdtCondInd1;
	private String epsdtCondInd2;
	private String epsdtCondInd3;
	private String visnCertCondCd4;
	private String visnCertCondCd5;
	private String payerClmCtrlNbr;
	private String priorAuthNbr;
	private String investigDeviceExmptId;
	private String peerRevewOrgAprvNbr;
	private String medicalRecordNbr;
	private String demonstrationProjectId;
	private String billingNotes;
	private String patVisitreasType1;
	private String patVisitreasCd1;
	private String patVisitreasType2;
	private String patVisitreasCd2;
	private String patVisitreasType3;
	private String patVisitreasCd3;
	private String repricdClmRefNbr;
	private String adjRepricdClmRefNbr;
	private String repricedApprvdDrgCd;
	private String repricedApprvdRevCd;
	private String repricerReceivedDt;
	private String repricingOrgId;
	private String repricedUom;
	private String repricedRejReasonCd;
	private String repricedPolCmpliantCd;
	private String repricedExceptionCd;
	private String valueAddNtwkTraceNbr;
	private String carePlanOversightNbr;
	private String claimNotes;
	private String referralNbr;
	private String investigDeviceExempId;
	private String demonstrationProjId;
	private String formattedIllnessOccurDt;
	private String formattedLastMenstrualPerDt;
	private String formattedDisabilityStartDt;
	private String formattedAsumdCareStartDt;
	private String patientCondCd;
	private String formattedInitialTreatmentDt;
	private String formattedLastXrayDt;
	private String formattedDisabilityEndDt;
	private String formattedAsumdCareEndDt;
	private String formattedLastSeenDt;
	private String formattedHearVisionDt;
	private String formattedLastWorkedDt;
	private String formattedFirstVisitConsultDt;
	private String formattedAcuteManifestationDt;
	private String formattedAuthReturnWorkDt;
	private String formattedAccidentDt;
	private String roundTripPurposeDesc;
	private String stretcherPurposeDesc;
	private String ambPatWeight;
	private String ambCertCondInd;
	private String ambPickupCountry;
	private String ambCertCondCd1;
	private String ambCertCondCd2;
	private String ambCertCondCd3;
	private String ambDropoffCountry;
	private String ambTranspDistance;
	private String ambTranspReasonCd;
	private String ambPickupCntrySubd;
	private String ambCertCondCd4;
	private String ambCertCondCd5;
	private String ambDropoffCntrySubd;
	
	//Billing Provider Fields
	private String billPrvFirstName;
	private String billPrvMiddleName;
	private String billPrvLastName;
	private String billPrvEntityType;
	private String billPrvOrgName;
	private String billPrvAddrLine1;
	private String billPrvAddrLine2;
	private String billPrvTaxonomyCd;
	private String billPrvNpi;
	private String billPrvLicNbr;
	private String billPrvUpin;
	private String formattedBillPrvSsn;
	private String formattedBillPrvAffilTaxId;
	private String billPrvCity;
	private String billPrvState;
	private String billPrvZip;
	private String billPrvContactName;
	private String billPrvCountry;
	private String billPrvCntrySubdCd;
	private String billPrvComNbrQual1;
	private String billPrvComNbrQual2;
	private String billPrvComNbrQual3;
	private String billPrvComNbr1;
	private String billPrvComNbr2;
	private String billPrvComNbr3;
	
	private String p2prvAddrLine1;
	private String p2prvAddrLine2;
	private String p2prvCity;
	private String p2prvState;
	private String p2prvZip;
	private String p2prvEntityType;
	private String p2prvCountry;
	private String p2prvCntrySubdCd;
	
	private String provFirstName;
	private String provMiddleName;
	private String provLastName;
	private String provOrgName;
	private String provEntityType;
	private String provAddrLine1;
	private String provAddrLine2;
	private String provCity;
	private String provState;
	private String provZip;
	private String provTaxonomyCd;
	private String provNpi;
	private String provType;
	private String provOthPayerId;
	private String provLocNbr;
	private String provLicNbr;
	private String provUpin;
	private String provCountry;
	private String provCntrySubd;
	private String provCommNbr;
	
	private String p2pOrgName;
	private String p2pPrimPayerId;
	private String p2pLocNbr;
	private String p2pAddrLine1;
	private String p2pPayerIdNbr;
	private String p2pNaicCd;
	private String p2pAddrLine2;
	private String p2pPrimPlanId;
	private String p2pTaxId;
	private String p2pCity;
	private String p2pState;
	private String p2pZip;
	private String p2pCountry;
	private String p2pCntrySubdCd;
	private String selClaimType;
	private String wtxClaimRefUniqNbr ="";//healthspring Unique id IFOX 367728*
	
	private String othPayrPrimaryId;
	private String clmliAdjudRevenueCd;
	private String prodOrSvcidQual;	
	// Getters/Setters
	
	//Updateable fields
	//Claim Line Adjudication fields
		private String othPayrPayerId;
		private String clmliBundledLineNbr;
		private String clmliAdjudSeqNbr;
		private String clmliAdjudProcCd;
		private String clmliAdjudProcMod1;
		private String clmliAdjudProcMod2;
		private String clmliAdjudProcMod3;
		private String clmliAdjudProcMod4;
		
		
		public String getOthPayrPayerId() {
			return othPayrPayerId;
		}
		public void setOthPayrPayerId(String othPayrPayerId) {
			this.othPayrPayerId = othPayrPayerId;
		}
		public String getClmliBundledLineNbr() {
			return clmliBundledLineNbr;
		}
		public void setClmliBundledLineNbr(String clmliBundledLineNbr) {
			this.clmliBundledLineNbr = clmliBundledLineNbr;
		}
		public String getClmliAdjudSeqNbr() {
			return clmliAdjudSeqNbr;
		}
		public void setClmliAdjudSeqNbr(String clmliAdjudSeqNbr) {
			this.clmliAdjudSeqNbr = clmliAdjudSeqNbr;
		}
		public String getClmliAdjudProcCd() {
			return clmliAdjudProcCd;
		}
		public void setClmliAdjudProcCd(String clmliAdjudProcCd) {
			this.clmliAdjudProcCd = clmliAdjudProcCd;
		}
		public String getClmliAdjudProcMod1() {
			return clmliAdjudProcMod1;
		}
		public void setClmliAdjudProcMod1(String clmliAdjudProcMod1) {
			this.clmliAdjudProcMod1 = clmliAdjudProcMod1;
		}
		public String getClmliAdjudProcMod2() {
			return clmliAdjudProcMod2;
		}
		public void setClmliAdjudProcMod2(String clmliAdjudProcMod2) {
			this.clmliAdjudProcMod2 = clmliAdjudProcMod2;
		}
		public String getClmliAdjudProcMod3() {
			return clmliAdjudProcMod3;
		}
		public void setClmliAdjudProcMod3(String clmliAdjudProcMod3) {
			this.clmliAdjudProcMod3 = clmliAdjudProcMod3;
		}
		public String getClmliAdjudProcMod4() {
			return clmliAdjudProcMod4;
		}
		public void setClmliAdjudProcMod4(String clmliAdjudProcMod4) {
			this.clmliAdjudProcMod4 = clmliAdjudProcMod4;
		}
		public String getClmliAdjudProcDesc() {
			return clmliAdjudProcDesc;
		}
		public void setClmliAdjudProcDesc(String clmliAdjudProcDesc) {
			this.clmliAdjudProcDesc = clmliAdjudProcDesc;
		}
		public double getClmliPaidSvcUnitCnt() {
			return clmliPaidSvcUnitCnt;
		}
		public void setClmliPaidSvcUnitCnt(double clmliPaidSvcUnitCnt) {
			this.clmliPaidSvcUnitCnt = clmliPaidSvcUnitCnt;
		}
		public String getFormattedAdjudPaymentDt() {
			return formattedAdjudPaymentDt;
		}
		public void setFormattedAdjudPaymentDt(String formattedAdjudPaymentDt) {
			this.formattedAdjudPaymentDt = formattedAdjudPaymentDt;
		}

		private String clmliAdjudProcDesc;
		
		private double clmliPaidSvcUnitCnt;
		private String formattedAdjudPaymentDt;
		
	private boolean claimOtherSubsChanged;
	private boolean clmLineChanged;
	private boolean adjudChanged;	
	private boolean clmLineProvChanged;
	private boolean claimOtherSubsProvChanged; 
	public boolean isClmLineChanged() {
		return clmLineChanged;
	}
	public void setClmLineChanged(boolean clmLineChanged) {
		this.clmLineChanged = clmLineChanged;
	}
	public boolean isAdjudChanged() {
		return adjudChanged;
	}
	public void setAdjudChanged(boolean adjudChanged) {
		this.adjudChanged = adjudChanged;
	}
	public boolean isClmLineProvChanged() {
		return clmLineProvChanged;
	}
	public void setClmLineProvChanged(boolean clmLineProvChanged) {
		this.clmLineProvChanged = clmLineProvChanged;
	}
	public boolean isClaimOtherSubsProvChanged() {
		return claimOtherSubsProvChanged;
	}
	public void setClaimOtherSubsProvChanged(boolean claimOtherSubsProvChanged) {
		this.claimOtherSubsProvChanged = claimOtherSubsProvChanged;
	}
	public String getClmOtherSubscribersExist() {
		return clmOtherSubscribersExist;
	}
	public void setClmOtherSubscribersExist(String clmOtherSubscribersExist) {
		this.clmOtherSubscribersExist = clmOtherSubscribersExist;
	}
	public String getClmLinesExist() {
		return clmLinesExist;
	}
	public void setClmLinesExist(String clmLinesExist) {
		this.clmLinesExist = clmLinesExist;
	}
	public String getClmLineAdjudExist() {
		return clmLineAdjudExist;
	}
	public void setClmLineAdjudExist(String clmLineAdjudExist) {
		this.clmLineAdjudExist = clmLineAdjudExist;
	}
	public String getClmLineProvExist() {
		return clmLineProvExist;
	}
	public void setClmLineProvExist(String clmLineProvExist) {
		this.clmLineProvExist = clmLineProvExist;
	}
	public String getClmOtherSubsProvExist() {
		return clmOtherSubsProvExist;
	}
	public void setClmOtherSubsProvExist(String clmOtherSubsProvExist) {
		this.clmOtherSubsProvExist = clmOtherSubsProvExist;
	}

	private String clmOtherSubscribersExist = "N";
	private String clmLinesExist = "N";
	private String clmLineAdjudExist = "N";
	private String clmLineProvExist = "N";
	private String clmOtherSubsProvExist = "N";
	//
	public boolean getDataChanged() {
		return dataChanged;
	}
	public void setDataChanged(boolean dataChanged) {
		this.dataChanged = dataChanged;
	}

	// Summary search results
	public GridUtil getStatusSummaryGrid() {
		return statusSummaryGrid;
	}
	public void setStatusSummaryGrid(GridUtil statusSummaryGrid) {
		this.statusSummaryGrid = statusSummaryGrid;
	}

	
	// Claim select values
	public String getSelectedClaimRefNbr() { //System.out.println("getSelectedClaimRefNbr(" + selectedClaimRefNbr + ")");
		return selectedClaimRefNbr;
	}
	public void setSelectedClaimRefNbr(String selectedClaimRefNbr) { //System.out.println("setSelectedClaimRefNbr(" + selectedClaimRefNbr + ")");
		this.selectedClaimRefNbr = selectedClaimRefNbr;
	}
	public String getSelectedClaimRevNbr() { //System.out.println("getSelectedClaimRevNbr(" + selectedClaimRevNbr + ")");
		return selectedClaimRevNbr;
	}
	public void setSelectedClaimRevNbr(String selectedClaimRevNbr) { //System.out.println("setSelectedClaimRevNbr(" + selectedClaimRevNbr + ")");
		this.selectedClaimRevNbr = selectedClaimRevNbr;
	}
	public String getSelectedClaimSeqNbr() { //System.out.println("getSelectedClaimSeqNbr(" + selectedClaimSeqNbr + ")");
		return selectedClaimSeqNbr;
	}
	public void setSelectedClaimSeqNbr(String selectedClaimSeqNbr) { //System.out.println("setSelectedClaimSeqNbr(" + selectedClaimSeqNbr + ")");
		this.selectedClaimSeqNbr = selectedClaimSeqNbr;
	}
	public String getSelectedClaimType() { //System.out.println("getSelectedClaimType(" + selectedClaimType + ")");
		return selectedClaimType;
	}
	public void setSelectedClaimType(String selectedClaimType) { //System.out.println("setSelectedClaimType(" + selectedClaimType + ")");
		this.selectedClaimType = selectedClaimType;
	}

	// Toggles - Institutional
	public boolean isInstClaimCodesExpanded() {
		return instClaimCodesExpanded;
	}
	public void setInstClaimCodesExpanded(boolean instClaimCodesExpanded) {
		this.instClaimCodesExpanded = instClaimCodesExpanded;
	}
	public boolean isInstClaimExpanded() {
		return instClaimExpanded;
	}
	public void setInstClaimExpanded(boolean instClaimExpanded) {
		this.instClaimExpanded = instClaimExpanded;
	}
	public boolean isInstClaimLineAdjudDetailExpanded() {
		return instClaimLineAdjudDetailExpanded;
	}
	public void setInstClaimLineAdjudDetailExpanded(boolean instClaimLineAdjudDetailExpanded) {
		this.instClaimLineAdjudDetailExpanded = instClaimLineAdjudDetailExpanded;
	}
	public boolean isInstClaimLineAdjudExpanded() {
		return instClaimLineAdjudExpanded;
	}
	public void setInstClaimLineAdjudExpanded(boolean instClaimLineAdjudExpanded) {
		this.instClaimLineAdjudExpanded = instClaimLineAdjudExpanded;
	}
	public boolean isInstClaimLineDetailExpanded() {
		return instClaimLineDetailExpanded;
	}
	public void setInstClaimLineDetailExpanded(boolean instClaimLineDetailExpanded) {
		this.instClaimLineDetailExpanded = instClaimLineDetailExpanded;
	}
	public boolean isInstClaimLineExpanded() {
		return instClaimLineExpanded;
	}
	public void setInstClaimLineExpanded(boolean instClaimLineExpanded) {
		this.instClaimLineExpanded = instClaimLineExpanded;
	}
	public boolean isInstClaimLineProvDetailExpanded() {
		return instClaimLineProvDetailExpanded;
	}
	public void setInstClaimLineProvDetailExpanded(boolean instClaimLineProvDetailExpanded) {
		this.instClaimLineProvDetailExpanded = instClaimLineProvDetailExpanded;
	}
	public boolean isInstClaimLineProvExpanded() {
		return instClaimLineProvExpanded;
	}
	public void setInstClaimLineProvExpanded(boolean instClaimLineProvExpanded) {
		this.instClaimLineProvExpanded = instClaimLineProvExpanded;
	}
	public boolean isInstClaimNotesExpanded() {
		return instClaimNotesExpanded;
	}
	public void setInstClaimNotesExpanded(boolean instClaimNotesExpanded) {
		this.instClaimNotesExpanded = instClaimNotesExpanded;
	}
	public boolean isInstClaimOtherSubsDetailExpanded() {
		return instClaimOtherSubsDetailExpanded;
	}
	public void setInstClaimOtherSubsDetailExpanded(boolean instClaimOtherSubsDetailExpanded) {
		this.instClaimOtherSubsDetailExpanded = instClaimOtherSubsDetailExpanded;
	}
	public boolean isInstClaimOtherSubsExpanded() {
		return instClaimOtherSubsExpanded;
	}
	public void setInstClaimOtherSubsExpanded(boolean instClaimOtherSubsExpanded) {
		this.instClaimOtherSubsExpanded = instClaimOtherSubsExpanded;
	}
	public boolean isInstClaimOtherSubsProvDetailExpanded() {
		return instClaimOtherSubsProvDetailExpanded;
	}
	public void setInstClaimOtherSubsProvDetailExpanded(boolean instClaimOtherSubsProvDetailExpanded) {
		this.instClaimOtherSubsProvDetailExpanded = instClaimOtherSubsProvDetailExpanded;
	}
	public boolean isInstClaimOtherSubsProvExpanded() {
		return instClaimOtherSubsProvExpanded;
	}
	public void setInstClaimOtherSubsProvExpanded(boolean instClaimOtherSubsProvExpanded) {
		this.instClaimOtherSubsProvExpanded = instClaimOtherSubsProvExpanded;
	}
	public boolean isInstClaimProvDetailExpanded() {
		return instClaimProvDetailExpanded;
	}
	public void setInstClaimProvDetailExpanded(boolean instClaimProvDetailExpanded) {
		this.instClaimProvDetailExpanded = instClaimProvDetailExpanded;
	}
	public boolean isInstClaimProvExpanded() {
		return instClaimProvExpanded;
	}
	public void setInstClaimProvExpanded(boolean instClaimProvExpanded) {
		this.instClaimProvExpanded = instClaimProvExpanded;
	}
	public boolean isInstErrorsExpanded() {
		return instErrorsExpanded;
	}
	public void setInstErrorsExpanded(boolean instErrorsExpanded) {
		this.instErrorsExpanded = instErrorsExpanded;
	}
	public boolean isInstListExpanded() {
		return instListExpanded;
	}
	public void setInstListExpanded(boolean instListExpanded) {
		this.instListExpanded = instListExpanded;
	}
	public boolean isInstProviderExpanded() {
		return instProviderExpanded;
	}
	public void setInstProviderExpanded(boolean instProviderExpanded) {
		this.instProviderExpanded = instProviderExpanded;
	}
	public boolean isInstSubscriberExpanded() {
		return instSubscriberExpanded;
	}
	public void setInstSubscriberExpanded(boolean instSubscriberExpanded) {
		this.instSubscriberExpanded = instSubscriberExpanded;
	}

	// Toggles - Professional
	public boolean isProfClaimCodesExpanded() {
		return profClaimCodesExpanded;
	}
	public void setProfClaimCodesExpanded(boolean profClaimCodesExpanded) {
		this.profClaimCodesExpanded = profClaimCodesExpanded;
	}
	public boolean isProfClaimExpanded() {
		return profClaimExpanded;
	}
	public void setProfClaimExpanded(boolean profClaimExpanded) {
		this.profClaimExpanded = profClaimExpanded;
	}
	public boolean isProfClaimLineAdjudDetailExpanded() {
		return profClaimLineAdjudDetailExpanded;
	}
	public void setProfClaimLineAdjudDetailExpanded(boolean profClaimLineAdjudDetailExpanded) {
		this.profClaimLineAdjudDetailExpanded = profClaimLineAdjudDetailExpanded;
	}
	public boolean isProfClaimLineAdjudExpanded() {
		return profClaimLineAdjudExpanded;
	}
	public void setProfClaimLineAdjudExpanded(boolean profClaimLineAdjudExpanded) {
		this.profClaimLineAdjudExpanded = profClaimLineAdjudExpanded;
	}
	public boolean isProfClaimLineDetailExpanded() {
		return profClaimLineDetailExpanded;
	}
	public void setProfClaimLineDetailExpanded(boolean profClaimLineDetailExpanded) {
		this.profClaimLineDetailExpanded = profClaimLineDetailExpanded;
	}
	public boolean isProfClaimLineExpanded() {
		return profClaimLineExpanded;
	}
	public void setProfClaimLineExpanded(boolean profClaimLineExpanded) {
		this.profClaimLineExpanded = profClaimLineExpanded;
	}
	public boolean isProfClaimLineProvDetailExpanded() {
		return profClaimLineProvDetailExpanded;
	}
	public void setProfClaimLineProvDetailExpanded(boolean profClaimLineProvDetailExpanded) {
		this.profClaimLineProvDetailExpanded = profClaimLineProvDetailExpanded;
	}
	public boolean isProfClaimLineProvExpanded() {
		return profClaimLineProvExpanded;
	}
	public void setProfClaimLineProvExpanded(boolean profClaimLineProvExpanded) {
		this.profClaimLineProvExpanded = profClaimLineProvExpanded;
	}
	public boolean isProfClaimOtherSubsDetailExpanded() {
		return profClaimOtherSubsDetailExpanded;
	}
	public void setProfClaimOtherSubsDetailExpanded(boolean profClaimOtherSubsDetailExpanded) {
		this.profClaimOtherSubsDetailExpanded = profClaimOtherSubsDetailExpanded;
	}
	public boolean isProfClaimOtherSubsExpanded() {
		return profClaimOtherSubsExpanded;
	}
	public void setProfClaimOtherSubsExpanded(boolean profClaimOtherSubsExpanded) {
		this.profClaimOtherSubsExpanded = profClaimOtherSubsExpanded;
	}
	public boolean isProfClaimOtherSubsProvDetailExpanded() {
		return profClaimOtherSubsProvDetailExpanded;
	}
	public void setProfClaimOtherSubsProvDetailExpanded(boolean profClaimOtherSubsProvDetailExpanded) {
		this.profClaimOtherSubsProvDetailExpanded = profClaimOtherSubsProvDetailExpanded;
	}
	public boolean isProfClaimOtherSubsProvExpanded() {
		return profClaimOtherSubsProvExpanded;
	}
	public void setProfClaimOtherSubsProvExpanded(boolean profClaimOtherSubsProvExpanded) {
		this.profClaimOtherSubsProvExpanded = profClaimOtherSubsProvExpanded;
	}
	public boolean isProfClaimProvDetailExpanded() {
		return profClaimProvDetailExpanded;
	}
	public void setProfClaimProvDetailExpanded(boolean profClaimProvDetailExpanded) {
		this.profClaimProvDetailExpanded = profClaimProvDetailExpanded;
	}
	public boolean isProfClaimProvExpanded() {
		return profClaimProvExpanded;
	}
	public void setProfClaimProvExpanded(boolean profClaimProvExpanded) {
		this.profClaimProvExpanded = profClaimProvExpanded;
	}
	public boolean isProfErrorsExpanded() {
		return profErrorsExpanded;
	}
	public void setProfErrorsExpanded(boolean profErrorsExpanded) {
		this.profErrorsExpanded = profErrorsExpanded;
	}
	public boolean isProfListExpanded() {
		return profListExpanded;
	}
	public void setProfListExpanded(boolean profListExpanded) {
		this.profListExpanded = profListExpanded;
	}
	public boolean isProfProviderExpanded() {
		return profProviderExpanded;
	}
	public void setProfProviderExpanded(boolean profProviderExpanded) {
		this.profProviderExpanded = profProviderExpanded;
	}
	public boolean isProfSubscriberExpanded() {
		return profSubscriberExpanded;
	}
	public void setProfSubscriberExpanded(boolean profSubscriberExpanded) {
		this.profSubscriberExpanded = profSubscriberExpanded;
	}
	/**
	 * @return Returns the firstClaimRefNbr.
	 */
	public String getFirstClaimRefNbr() {
		return firstClaimRefNbr;
	}
	/**
	 * @param firstClaimRefNbr The firstClaimRefNbr to set.
	 */
	public void setFirstClaimRefNbr(String firstClaimRefNbr) {
		this.firstClaimRefNbr = firstClaimRefNbr;
	}
	/**
	 * @return Returns the firstClaimRevNbr.
	 */
	public String getFirstClaimRevNbr() {
		return firstClaimRevNbr;
	}
	/**
	 * @param firstClaimRevNbr The firstClaimRevNbr to set.
	 */
	public void setFirstClaimRevNbr(String firstClaimRevNbr) {
		this.firstClaimRevNbr = firstClaimRevNbr;
	}
	/**
	 * @return Returns the firstClaimSeqNbr.
	 */
	public String getFirstClaimSeqNbr() {
		return firstClaimSeqNbr;
	}
	/**
	 * @param firstClaimSeqNbr The firstClaimSeqNbr to set.
	 */
	public void setFirstClaimSeqNbr(String firstClaimSeqNbr) {
		this.firstClaimSeqNbr = firstClaimSeqNbr;
	}
	/**
	 * @return Returns the firstClaimType.
	 */
	public String getFirstClaimType() {
		return firstClaimType;
	}
	/**
	 * @param firstClaimType The firstClaimType to set.
	 */
	public void setFirstClaimType(String firstClaimType) {
		this.firstClaimType = firstClaimType;
	}
	/**
	 * @return Returns the focusField.
	 */
	public String getFocusField() {
		return focusField;
	}
	/**
	 * @param focusField The focusField to set.
	 */
	public void setFocusField(String focusField) {
		this.focusField = focusField;
	}
	/**
	 * @return Returns the subscriberChanged.
	 */
	public boolean isSubscriberChanged() {
		return subscriberChanged;
	}
	/**
	 * @param subscriberChanged The subscriberChanged to set.
	 */
	public void setSubscriberChanged(boolean subscriberChanged) {
		this.subscriberChanged = subscriberChanged;
	}
	/**
	 * @return Returns the subscriberDisplayState.
	 */
	public String getSubscriberDisplayState() {
		return subscriberDisplayState;
	}
	/**
	 * @param subscriberDisplayState The subscriberDisplayState to set.
	 */
	public void setSubscriberDisplayState(String subscriberDisplayState) {
		this.subscriberDisplayState = subscriberDisplayState;
	}
	/**
	 * @return Returns the claimChanged.
	 */
	public boolean isClaimChanged() {
		return claimChanged;
	}
	/**
	 * @param claimChanged The claimChanged to set.
	 */
	public void setClaimChanged(boolean claimChanged) {
		this.claimChanged = claimChanged;
	}
	/**
	 * @return Returns the claimDisplayState.
	 */
	public String getClaimDisplayState() {
		return claimDisplayState;
	}
	/**
	 * @param claimDisplayState The claimDisplayState to set.
	 */
	public void setClaimDisplayState(String claimDisplayState) {
		this.claimDisplayState = claimDisplayState;
	}	
	
	/**
	 * @return Returns the providerChanged.
	 */
	public boolean isProviderChanged() {
		return providerChanged;
	}
	/**
	 * @param providerChanged The providerChanged to set.
	 */
	public void setProviderChanged(boolean providerChanged) {
		this.providerChanged = providerChanged;
	}
	/**
	 * @return Returns the providerDisplayState.
	 */
	public String getProviderDisplayState() {
		return providerDisplayState;
	}
	/**
	 * @param providerDisplayState The providerDisplayState to set.
	 */
	public void setProviderDisplayState(String providerDisplayState) {
		this.providerDisplayState = providerDisplayState;
	}
	/**
	 * @return Returns the displayMessage.
	 */
	public String getDisplayMessage() {
		return displayMessage;
	}
	/**
	 * @param displayMessage The displayMessage to set.
	 */
	public void setDisplayMessage(String displayMessage) {
		this.displayMessage = displayMessage;
	}
	
	
	/**
	 * @return Returns the subsFirstName.
	 */
	public String getSubsFirstName() {
		return subsFirstName;
	}
	/**
	 * @param subsFirstName The subsFirstName to set.
	 */
	public void setSubsFirstName(String subsFirstName) {
		this.subsFirstName = subsFirstName;
	}
	
	
	
	
	/**
	 * @return Returns the prevMenu.
	 */
	public String getPrevMenu() {
		return prevMenu;
	}
	/**
	 * @param prevMenu The prevMenu to set.
	 */
	public void setPrevMenu(String prevMenu) {
		this.prevMenu = prevMenu;
	}
	/**
	 * @return Returns the prevMethod.
	 */
	public String getPrevMethod() {
		return prevMethod;
	}
	/**
	 * @param prevMethod The prevMethod to set.
	 */
	public void setPrevMethod(String prevMethod) {
		this.prevMethod = prevMethod;
	}
	/**
	 * @return Returns the formattedSubsDob.
	 */
	public String getFormattedSubsDob() {
		return formattedSubsDob;
	}
	/**
	 * @param formattedSubsDob The formattedSubsDob to set.
	 */
	public void setFormattedSubsDob(String formattedSubsDob) {
		this.formattedSubsDob = formattedSubsDob;
	}
	/**
	 * @return Returns the formattedSubsSsn.
	 */
	public String getFormattedSubsSsn() {
		return formattedSubsSsn;
	}
	/**
	 * @param formattedSubsSsn The formattedSubsSsn to set.
	 */
	public void setFormattedSubsSsn(String formattedSubsSsn) {
		this.formattedSubsSsn = formattedSubsSsn;
	}
	/**
	 * @return Returns the processStatus.
	 */
	public String getProcessStatus() {
		return processStatus;
	}
	/**
	 * @param processStatus The processStatus to set.
	 */
	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}
	/**
	 * @return Returns the subsAddrLine1.
	 */
	public String getSubsAddrLine1() {
		return subsAddrLine1;
	}
	/**
	 * @param subsAddrLine1 The subsAddrLine1 to set.
	 */
	public void setSubsAddrLine1(String subsAddrLine1) {
		this.subsAddrLine1 = subsAddrLine1;
	}
	/**
	 * @return Returns the subsAddrLine2.
	 */
	public String getSubsAddrLine2() {
		return subsAddrLine2;
	}
	/**
	 * @param subsAddrLine2 The subsAddrLine2 to set.
	 */
	public void setSubsAddrLine2(String subsAddrLine2) {
		this.subsAddrLine2 = subsAddrLine2;
	}
	/**
	 * @return Returns the subsCity.
	 */
	public String getSubsCity() {
		return subsCity;
	}
	/**
	 * @param subsCity The subsCity to set.
	 */
	public void setSubsCity(String subsCity) {
		this.subsCity = subsCity;
	}
	/**
	 * @return Returns the subsHicNbr.
	 */
	public String getSubsHicNbr() {
		return subsHicNbr;
	}
	/**
	 * @param subsHicNbr The subsHicNbr to set.
	 */
	public void setSubsHicNbr(String subsHicNbr) {
		this.subsHicNbr = subsHicNbr;
	}
	public String getMbi() {
		return mbi;
	}
	public void setMbi(String mbi) {
		this.mbi = mbi;
	}
		// securedHicNbr
		public String getSecuredHicNbr(){
			if("M".equalsIgnoreCase(CustSentMbiInd)){
				return mbi;
			}else{
				return subsHicNbr;
			}
		}

		public String getCustmFlag() {
			return CustSentMbiInd;
		}



		public void setCustmFlag(String CustSentMbiInd) {
			this.CustSentMbiInd = CustSentMbiInd;
		}
		
	/**
	 * @return Returns the subsLastName.
	 */
	public String getSubsLastName() {
		return subsLastName;
	}
	/**
	 * @param subsLastName The subsLastName to set.
	 */
	public void setSubsLastName(String subsLastName) {
		this.subsLastName = subsLastName;
	}
	/**
	 * @return Returns the subsMiddleName.
	 */
	public String getSubsMiddleName() {
		return subsMiddleName;
	}
	/**
	 * @param subsMiddleName The subsMiddleName to set.
	 */
	public void setSubsMiddleName(String subsMiddleName) {
		this.subsMiddleName = subsMiddleName;
	}
	/**
	 * @return Returns the subsSex.
	 */
	public String getSubsSex() {
		return subsSex;
	}
	/**
	 * @param subsSex The subsSex to set.
	 */
	public void setSubsSex(String subsSex) {
		this.subsSex = subsSex;
	}
	/**
	 * @return Returns the subsState.
	 */
	public String getSubsState() {
		return subsState;
	}
	/**
	 * @param subsState The subsState to set.
	 */
	public void setSubsState(String subsState) {
		this.subsState = subsState;
	}
	/**
	 * @return Returns the subsZip.
	 */
	public String getSubsZip() {
		return subsZip;
	}
	/**
	 * @param subsZip The subsZip to set.
	 */
	public void setSubsZip(String subsZip) {
		this.subsZip = subsZip;
	}
	
	
	/**
	 * @return Returns the placeOfService.
	 */
	public String getPlaceOfService() {
		return placeOfService;
	}
	/**
	 * @param placeOfService The placeOfService to set.
	 */
	public void setPlaceOfService(String placeOfService) {
		this.placeOfService = placeOfService;
	}

	public String getClmFacTypeCd() {
		return clmFacTypeCd;
	}
	public void setClmFacTypeCd(String clmFacTypeCd) {
		this.clmFacTypeCd = clmFacTypeCd;
	}
	public String getAdmitDt() {
		return admitDt;
	}
	public String getFormattedAdmitDt() {
		return DateFormatter.reFormat(admitDt,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	public void setAdmitDt(String admitDt) {
		this.admitDt = admitDt;
	}
	public void setFormattedAdmitDt(String admitDt) {
		this.admitDt = DateFormatter.reFormat(admitDt,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}
	public String getAdmitHour() {
		return admitHour;
	}
	public void setAdmitHour(String admitHour) {
		this.admitHour = admitHour;
	}
	public String getAdmitSourceCd() {
		return admitSourceCd;
	}
	public void setAdmitSourceCd(String admitSourceCd) {
		this.admitSourceCd = admitSourceCd;
	}
	public String getAdmitType() {
		return admitType;
	}
	public void setAdmitType(String admitType) {
		this.admitType = admitType;
	}
	public String getPatientStatusCd() {
		return patientStatusCd;
	}
	public void setPatientStatusCd(String patientStatusCd) {
		this.patientStatusCd = patientStatusCd;
	}
	public String getHospAdmitDt() {
		return hospAdmitDt;
	}
	public String getFormattedHospAdmitDt() {
		return DateFormatter.reFormat(hospAdmitDt,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	public void setHospAdmitDt(String hospAdmitDt) {
		this.hospAdmitDt = hospAdmitDt;
	}
	public void setFormattedHospAdmitDt(String hospAdmitDt) {
		this.hospAdmitDt = DateFormatter.reFormat(hospAdmitDt,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}
	public String getHospDischargeDt() {
		return hospDischargeDt;
	}
	public String getFormattedHospDischargeDt() {
		return DateFormatter.reFormat(hospDischargeDt,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	public void setHospDischargeDt(String hospDischargeDt) {
		this.hospDischargeDt = hospDischargeDt;
	}
	public void setFormattedHospDischargeDt(String hospDischargeDt) {
		this.hospDischargeDt = DateFormatter.reFormat(hospDischargeDt,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}

	
	public String getAmbDropoffAddrLine1() {
		return ambDropoffAddrLine1;
	}
	public void setAmbDropoffAddrLine1(String ambDropoffAddrLine1) {
		this.ambDropoffAddrLine1 = ambDropoffAddrLine1;
	}
	public String getAmbDropoffAddrLine2() {
		return ambDropoffAddrLine2;
	}
	public void setAmbDropoffAddrLine2(String ambDropoffAddrLine2) {
		this.ambDropoffAddrLine2 = ambDropoffAddrLine2;
	}
	public String getAmbDropoffCity() {
		return ambDropoffCity;
	}
	public void setAmbDropoffCity(String ambDropoffCity) {
		this.ambDropoffCity = ambDropoffCity;
	}
	public String getAmbDropoffLoc() {
		return ambDropoffLoc;
	}
	public void setAmbDropoffLoc(String ambDropoffLoc) {
		this.ambDropoffLoc = ambDropoffLoc;
	}
	public String getAmbDropoffState() {
		return ambDropoffState;
	}
	public void setAmbDropoffState(String ambDropoffState) {
		this.ambDropoffState = ambDropoffState;
	}
	public String getAmbDropoffZip() {
		return ambDropoffZip;
	}
	public void setAmbDropoffZip(String ambDropoffZip) {
		this.ambDropoffZip = ambDropoffZip;
	}

	public String getAmbPickupAddrLine1() {
		return ambPickupAddrLine1;
	}
	public void setAmbPickupAddrLine1(String ambPickupAddrLine1) {
		this.ambPickupAddrLine1 = ambPickupAddrLine1;
	}
	public String getAmbPickupAddrLine2() {
		return ambPickupAddrLine2;
	}
	public void setAmbPickupAddrLine2(String ambPickupAddrLine2) {
		this.ambPickupAddrLine2 = ambPickupAddrLine2;
	}
	public String getAmbPickupZip() {
		return ambPickupZip;
	}
	public void setAmbPickupZip(String ambPickupZip) {
		this.ambPickupZip = ambPickupZip;
	}
	public String getAmbPickupCity() {
		return ambPickupCity;
	}
	public void setAmbPickupCity(String ambPickupCity) {
		this.ambPickupCity = ambPickupCity;
	}
	public String getAmbPickupState() {
		return ambPickupState;
	}
	public void setAmbPickupState(String ambPickupState) {
		this.ambPickupState = ambPickupState;
	}
	public String getCliaNbr() {
		return cliaNbr;
	}
	public void setCliaNbr(String cliaNbr) {
		this.cliaNbr = cliaNbr;
	}
	public String getMammogramCertNbr() {
		return mammogramCertNbr;
	}
	public void setMammogramCertNbr(String mammogramCertNbr) {
		this.mammogramCertNbr = mammogramCertNbr;
	}
	/**
	 * @return Returns the billPrvAddrLine1.
	 */
	public String getBillPrvAddrLine1() {
		return billPrvAddrLine1;
	}
	/**
	 * @param billPrvAddrLine1 The billPrvAddrLine1 to set.
	 */
	public void setBillPrvAddrLine1(String billPrvAddrLine1) {
		this.billPrvAddrLine1 = billPrvAddrLine1;
	}
	/**
	 * @return Returns the billPrvAddrLine2.
	 */
	public String getBillPrvAddrLine2() {
		return billPrvAddrLine2;
	}
	/**
	 * @param billPrvAddrLine2 The billPrvAddrLine2 to set.
	 */
	public void setBillPrvAddrLine2(String billPrvAddrLine2) {
		this.billPrvAddrLine2 = billPrvAddrLine2;
	}
	/**
	 * @return Returns the formattedBillPrvAffilTaxId.
	 */
	public String getFormattedBillPrvAffilTaxId() {
		return formattedBillPrvAffilTaxId;
	}
	/**
	 * @param billPrvAffilTaxId The billPrvAffilTaxId to set.
	 */
	public void setFormattedBillPrvAffilTaxId(String formattedBillPrvAffilTaxId) {
		this.formattedBillPrvAffilTaxId = formattedBillPrvAffilTaxId;
	}
	/**
	 * @return Returns the billPrvCity.
	 */
	public String getBillPrvCity() {
		return billPrvCity;
	}
	/**
	 * @param billPrvCity The billPrvCity to set.
	 */
	public void setBillPrvCity(String billPrvCity) {
		this.billPrvCity = billPrvCity;
	}
	/**
	 * @return Returns the billPrvComNbr1.
	 */
	public String getBillPrvComNbr1() {
		return billPrvComNbr1;
	}
	/**
	 * @param billPrvComNbr1 The billPrvComNbr1 to set.
	 */
	public void setBillPrvComNbr1(String billPrvComNbr1) {
		this.billPrvComNbr1 = billPrvComNbr1;
	}
	/**
	 * @return Returns the billPrvComNbr2.
	 */
	public String getBillPrvComNbr2() {
		return billPrvComNbr2;
	}
	/**
	 * @param billPrvComNbr2 The billPrvComNbr2 to set.
	 */
	public void setBillPrvComNbr2(String billPrvComNbr2) {
		this.billPrvComNbr2 = billPrvComNbr2;
	}
	/**
	 * @return Returns the billPrvComNbr3.
	 */
	public String getBillPrvComNbr3() {
		return billPrvComNbr3;
	}
	/**
	 * @param billPrvComNbr3 The billPrvComNbr3 to set.
	 */
	public void setBillPrvComNbr3(String billPrvComNbr3) {
		this.billPrvComNbr3 = billPrvComNbr3;
	}
	/**
	 * @return Returns the billPrvComNbrQual1.
	 */
	public String getBillPrvComNbrQual1() {
		return billPrvComNbrQual1;
	}
	/**
	 * @param billPrvComNbrQual1 The billPrvComNbrQual1 to set.
	 */
	public void setBillPrvComNbrQual1(String billPrvComNbrQual1) {
		this.billPrvComNbrQual1 = billPrvComNbrQual1;
	}
	/**
	 * @return Returns the billPrvComNbrQual2.
	 */
	public String getBillPrvComNbrQual2() {
		return billPrvComNbrQual2;
	}
	/**
	 * @param billPrvComNbrQual2 The billPrvComNbrQual2 to set.
	 */
	public void setBillPrvComNbrQual2(String billPrvComNbrQual2) {
		this.billPrvComNbrQual2 = billPrvComNbrQual2;
	}
	/**
	 * @return Returns the billPrvComNbrQual3.
	 */
	public String getBillPrvComNbrQual3() {
		return billPrvComNbrQual3;
	}
	/**
	 * @param billPrvComNbrQual3 The billPrvComNbrQual3 to set.
	 */
	public void setBillPrvComNbrQual3(String billPrvComNbrQual3) {
		this.billPrvComNbrQual3 = billPrvComNbrQual3;
	}
	/**
	 * @return Returns the billPrvNpi.
	 */
	public String getBillPrvNpi() {
		return billPrvNpi;
	}
	/**
	 * @param billPrvNpi The billPrvNpi to set.
	 */
	public void setBillPrvNpi(String billPrvNpi) {
		this.billPrvNpi = billPrvNpi;
	}
	/**
	 * @return Returns the billPrvOrgName.
	 */
	public String getBillPrvOrgName() {
		return billPrvOrgName;
	}
	/**
	 * @param billPrvOrgName The billPrvOrgName to set.
	 */
	public void setBillPrvOrgName(String billPrvOrgName) {
		this.billPrvOrgName = billPrvOrgName;
	}
	/**
	 * @return Returns the billPrvState.
	 */
	public String getBillPrvState() {
		return billPrvState;
	}
	/**
	 * @param billPrvState The billPrvState to set.
	 */
	public void setBillPrvState(String billPrvState) {
		this.billPrvState = billPrvState;
	}
	/**
	 * @return Returns the billPrvTaxonomyCd.
	 */
	public String getBillPrvTaxonomyCd() {
		return billPrvTaxonomyCd;
	}
	/**
	 * @param billPrvTaxonomyCd The billPrvTaxonomyCd to set.
	 */
	public void setBillPrvTaxonomyCd(String billPrvTaxonomyCd) {
		this.billPrvTaxonomyCd = billPrvTaxonomyCd;
	}
	/**
	 * @return Returns the billPrvZip.
	 */
	public String getBillPrvZip() {
		return billPrvZip;
	}
	/**
	 * @param billPrvZip The billPrvZip to set.
	 */
	public void setBillPrvZip(String billPrvZip) {
		this.billPrvZip = billPrvZip;
	}
	public String getBillPrvLicNbr() {
		return billPrvLicNbr;
	}
	public void setBillPrvLicNbr(String billPrvLicNbr) {
		this.billPrvLicNbr = billPrvLicNbr;
	}
	public String getFormattedBillPrvSsn() {
		return formattedBillPrvSsn;
	}
	public void setFormattedBillPrvSsn(String formattedBillPrvSsn) {
		this.formattedBillPrvSsn = formattedBillPrvSsn;
	}
	public String getBillPrvUpin() {
		return billPrvUpin;
	}
	public void setBillPrvUpin(String billPrvUpin) {
		this.billPrvUpin = billPrvUpin;
	}
	/**
	 * @return Returns the p2prvAddrLine1.
	 */
	public String getP2prvAddrLine1() {
		return p2prvAddrLine1;
	}
	/**
	 * @param addrLine1 The p2prvAddrLine1 to set.
	 */
	public void setP2prvAddrLine1(String addrLine1) {
		p2prvAddrLine1 = addrLine1;
	}
	/**
	 * @return Returns the p2prvAddrLine2.
	 */
	public String getP2prvAddrLine2() {
		return p2prvAddrLine2;
	}
	/**
	 * @param addrLine2 The p2prvAddrLine2 to set.
	 */
	public void setP2prvAddrLine2(String addrLine2) {
		p2prvAddrLine2 = addrLine2;
	}
	/**
	 * @return Returns the p2prvCity.
	 */
	public String getP2prvCity() {
		return p2prvCity;
	}
	/**
	 * @param city The p2prvCity to set.
	 */
	public void setP2prvCity(String city) {
		p2prvCity = city;
	}
	/**
	 * @return Returns the p2prvState.
	 */
	public String getP2prvState() {
		return p2prvState;
	}
	/**
	 * @param state The p2prvState to set.
	 */
	public void setP2prvState(String state) {
		p2prvState = state;
	}
	/**
	 * @return Returns the p2prvZip.
	 */
	public String getP2prvZip() {
		return p2prvZip;
	}
	/**
	 * @param zip The p2prvZip to set.
	 */
	public void setP2prvZip(String zip) {
		p2prvZip = zip;
	}	
	
	/**
	 * @return Returns the billPrvEntityType.
	 */
	public String getBillPrvEntityType() {
		return billPrvEntityType;
	}
	/**
	 * @param billPrvEntityType The billPrvEntityType to set.
	 */
	public void setBillPrvEntityType(String billPrvEntityType) {
		this.billPrvEntityType = billPrvEntityType;
	}
	/**
	 * @return Returns the billPrvFirstName.
	 */
	public String getBillPrvFirstName() {
		return billPrvFirstName;
	}
	/**
	 * @param billPrvFirstName The billPrvFirstName to set.
	 */
	public void setBillPrvFirstName(String billPrvFirstName) {
		this.billPrvFirstName = billPrvFirstName;
	}
	/**
	 * @return Returns the billPrvMiddleName.
	 */
	public String getBillPrvMiddleName() {
		return billPrvMiddleName;
	}
	/**
	 * @param billPrvMiddleName The billPrvMiddleName to set.
	 */
	public void setBillPrvMiddleName(String billPrvMiddleName) {
		this.billPrvMiddleName = billPrvMiddleName;
	}
	/**
	 * @return Returns the p2prvEntityType.
	 */
	public String getP2prvEntityType() {
		return p2prvEntityType;
	}
	/**
	 * @param entityType The p2prvEntityType to set.
	 */
	public void setP2prvEntityType(String entityType) {
		p2prvEntityType = entityType;
	}	
	
	/**
	 * @return Returns the billPrvLastName.
	 */
	public String getBillPrvLastName() {
		return billPrvLastName;
	}
	/**
	 * @param billPrvLastName The billPrvLastName to set.
	 */
	public void setBillPrvLastName(String billPrvLastName) {
		this.billPrvLastName = billPrvLastName;
	}	
	
	/**
	 * @return Returns the clmProviderDisplayState.
	 */
	public String getClmProviderDisplayState() {
		return clmProviderDisplayState;
	}
	/**
	 * @param clmProviderDisplayState The clmProviderDisplayState to set.
	 */
	public void setClmProviderDisplayState(String clmProviderDisplayState) {
		this.clmProviderDisplayState = clmProviderDisplayState;
	}
	/**
	 * @return Returns the clmPrvChanged.
	 */
	public boolean isClmPrvChanged() {
		return clmPrvChanged;
	}
	/**
	 * @param clmPrvChanged The clmPrvChanged to set.
	 */
	public void setClmPrvChanged(boolean clmPrvChanged) {
		this.clmPrvChanged = clmPrvChanged;
	}
	
	/**
	 * @return Returns the provAddrLine1.
	 */
	public String getProvAddrLine1() {
		return provAddrLine1;
	}
	/**
	 * @param provAddrLine1 The provAddrLine1 to set.
	 */
	public void setProvAddrLine1(String provAddrLine1) {
		this.provAddrLine1 = provAddrLine1;
	}
	/**
	 * @return Returns the provAddrLine2.
	 */
	public String getProvAddrLine2() {
		return provAddrLine2;
	}
	/**
	 * @param provAddrLine2 The provAddrLine2 to set.
	 */
	public void setProvAddrLine2(String provAddrLine2) {
		this.provAddrLine2 = provAddrLine2;
	}
	/**
	 * @return Returns the provCity.
	 */
	public String getProvCity() {
		return provCity;
	}
	/**
	 * @param provCity The provCity to set.
	 */
	public void setProvCity(String provCity) {
		this.provCity = provCity;
	}
	/**
	 * @return Returns the provEntityType.
	 */
	public String getProvEntityType() {
		return provEntityType;
	}
	/**
	 * @param provEntityType The provEntityType to set.
	 */
	public void setProvEntityType(String provEntityType) {
		this.provEntityType = provEntityType;
	}
	public String getProvOrgName() {
		return provOrgName;
	}
	public void setProvOrgName(String provOrgName) {
		this.provOrgName = provOrgName;
	}
	/**
	 * @return Returns the provFirstName.
	 */
	public String getProvFirstName() {
		return provFirstName;
	}
	/**
	 * @param provFirstName The provFirstName to set.
	 */
	public void setProvFirstName(String provFirstName) {
		this.provFirstName = provFirstName;
	}
	/**
	 * @return Returns the provLastName.
	 */
	public String getProvLastName() {
		return provLastName;
	}
	/**
	 * @param provLastName The provLastName to set.
	 */
	public void setProvLastName(String provLastName) {
		this.provLastName = provLastName;
	}
	/**
	 * @return Returns the provMiddleName.
	 */
	public String getProvMiddleName() {
		return provMiddleName;
	}
	/**
	 * @param provMiddleName The provMiddleName to set.
	 */
	public void setProvMiddleName(String provMiddleName) {
		this.provMiddleName = provMiddleName;
	}
	/**
	 * @return Returns the provNpi.
	 */
	public String getProvNpi() {
		return provNpi;
	}
	/**
	 * @param provNpi The provNpi to set.
	 */
	public void setProvNpi(String provNpi) {
		this.provNpi = provNpi;
	}
	/**
	 * @return Returns the provState.
	 */
	public String getProvState() {
		return provState;
	}
	/**
	 * @param provState The provState to set.
	 */
	public void setProvState(String provState) {
		this.provState = provState;
	}
	/**
	 * @return Returns the provTaxonomyCd.
	 */
	public String getProvTaxonomyCd() {
		return provTaxonomyCd;
	}
	/**
	 * @param provTaxonomyCd The provTaxonomyCd to set.
	 */
	public void setProvTaxonomyCd(String provTaxonomyCd) {
		this.provTaxonomyCd = provTaxonomyCd;
	}
	/**
	 * @return Returns the provZip.
	 */
	public String getProvZip() {
		return provZip;
	}
	/**
	 * @param provZip The provZip to set.
	 */
	public void setProvZip(String provZip) {
		this.provZip = provZip;
	}
	
	
	/**
	 * @return Returns the provCntrySubd.
	 */
	public String getProvCntrySubd() {
		return provCntrySubd;
	}
	/**
	 * @param provCntrySubd The provCntrySubd to set.
	 */
	public void setProvCntrySubd(String provCntrySubd) {
		this.provCntrySubd = provCntrySubd;
	}
	/**
	 * @return Returns the provCommNbr.
	 */
	public String getProvCommNbr() {
		return provCommNbr;
	}
	/**
	 * @param provCommNbr The provCommNbr to set.
	 */
	public void setProvCommNbr(String provCommNbr) {
		this.provCommNbr = provCommNbr;
	}
	/**
	 * @return Returns the provCountry.
	 */
	public String getProvCountry() {
		return provCountry;
	}
	/**
	 * @param provCountry The provCountry to set.
	 */
	public void setProvCountry(String provCountry) {
		this.provCountry = provCountry;
	}
	/**
	 * @return Returns the provLicNbr.
	 */
	public String getProvLicNbr() {
		return provLicNbr;
	}
	/**
	 * @param provLicNbr The provLicNbr to set.
	 */
	public void setProvLicNbr(String provLicNbr) {
		this.provLicNbr = provLicNbr;
	}
	/**
	 * @return Returns the provLocNbr.
	 */
	public String getProvLocNbr() {
		return provLocNbr;
	}
	/**
	 * @param provLocNbr The provLocNbr to set.
	 */
	public void setProvLocNbr(String provLocNbr) {
		this.provLocNbr = provLocNbr;
	}
	/**
	 * @return Returns the provOthPayerId.
	 */
	public String getProvOthPayerId() {
		return provOthPayerId;
	}
	/**
	 * @param provOthPayerId The provOthPayerId to set.
	 */
	public void setProvOthPayerId(String provOthPayerId) {
		this.provOthPayerId = provOthPayerId;
	}
	/**
	 * @return Returns the provType.
	 */
	public String getProvType() {
		return provType;
	}
	/**
	 * @param provType The provType to set.
	 */
	public void setProvType(String provType) {
		this.provType = provType;
	}
	/**
	 * @return Returns the provUpin.
	 */
	public String getProvUpin() {
		return provUpin;
	}
	/**
	 * @param provUpin The provUpin to set.
	 */
	public void setProvUpin(String provUpin) {
		this.provUpin = provUpin;
	}	
	
	/**
	 * @return Returns the clmProviderExist.
	 */
	public String getClmProviderExist() {
		return clmProviderExist;
	}
	/**
	 * @param clmProviderExist The clmProviderExist to set.
	 */
	public void setClmProviderExist(String clmProviderExist) {
		this.clmProviderExist = clmProviderExist;
	}
		
	/**
	 * @return Returns the billProviderExist.
	 */
	public String getBillProviderExist() {
		return billProviderExist;
	}
	/**
	 * @param billProviderExist The billProviderExist to set.
	 */
	public void setBillProviderExist(String billProviderExist) {
		this.billProviderExist = billProviderExist;
	}
	
	/**
	 * @return Returns the claimRefNbr.
	 */
	public String getClaimRefNbr() {
		return claimRefNbr;
	}
	/**
	 * @param claimRefNbr The claimRefNbr to set.
	 */
	public void setClaimRefNbr(String claimRefNbr) {
		this.claimRefNbr = claimRefNbr;
	}
	
	/**
	 * @return Returns the claimType.
	 */
	public String getClaimType() {
		return claimType;
	}
	/**
	 * @param claimType The claimType to set.
	 */
	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}
	/**
	 * @return Returns the submitterId.
	 */
	public String getSubmitterId() {
		return submitterId;
	}
	/**
	 * @param submitterId The submitterId to set.
	 */
	public void setSubmitterId(String submitterId) {
		this.submitterId = submitterId;
	}
	
	
	/**
	 * @return Returns the searchCRDetailClaimRefNbr.
	 */
	public String getSearchCRDetailClaimRefNbr() {
		return searchCRDetailClaimRefNbr;
	}
	/**
	 * @param searchCRDetailClaimRefNbr The searchCRDetailClaimRefNbr to set.
	 */
	public void setSearchCRDetailClaimRefNbr(String searchCRDetailClaimRefNbr) {
		this.searchCRDetailClaimRefNbr = searchCRDetailClaimRefNbr;
	}
	/**
	 * @return Returns the searchCRDetailDateInd.
	 */
	public String getSearchCRDetailDateInd() {
		return searchCRDetailDateInd;
	}
	/**
	 * @param searchCRDetailDateInd The searchCRDetailDateInd to set.
	 */
	public void setSearchCRDetailDateInd(String searchCRDetailDateInd) {
		this.searchCRDetailDateInd = searchCRDetailDateInd;
	}
	/**
	 * @return Returns the searchCRDetailEncType.
	 */
	public String getSearchCRDetailEncType() {
		return searchCRDetailEncType;
	}
	/**
	 * @param searchCRDetailEncType The searchCRDetailEncType to set.
	 */
	public void setSearchCRDetailEncType(String searchCRDetailEncType) {
		this.searchCRDetailEncType = searchCRDetailEncType;
	}
	/**
	 * @return Returns the searchCRDetailErrorCode.
	 */
	public String getSearchCRDetailErrorCode() {
		return searchCRDetailErrorCode;
	}
	/**
	 * @param searchCRDetailErrorCode The searchCRDetailErrorCode to set.
	 */
	public void setSearchCRDetailErrorCode(String searchCRDetailErrorCode) {
		this.searchCRDetailErrorCode = searchCRDetailErrorCode;
	}
	/**
	 * @return Returns the searchCRDetailErrorGroup.
	 */
	public String getSearchCRDetailErrorGroup() {
		return searchCRDetailErrorGroup;
	}
	/**
	 * @param searchCRDetailErrorGroup The searchCRDetailErrorGroup to set.
	 */
	public void setSearchCRDetailErrorGroup(String searchCRDetailErrorGroup) {
		this.searchCRDetailErrorGroup = searchCRDetailErrorGroup;
	}
	/**
	 * @return Returns the searchCRDetailErrorSource.
	 */
	public String getSearchCRDetailErrorSource() {
		return searchCRDetailErrorSource;
	}
	/**
	 * @param searchCRDetailErrorSource The searchCRDetailErrorSource to set.
	 */
	public void setSearchCRDetailErrorSource(String searchCRDetailErrorSource) {
		this.searchCRDetailErrorSource = searchCRDetailErrorSource;
	}
	/**
	 * @return Returns the searchCRDetailFromDate.
	 */
	public String getSearchCRDetailFromDate() {
		return searchCRDetailFromDate;
	}
	/**
	 * @param searchCRDetailFromDate The searchCRDetailFromDate to set.
	 */
	public void setSearchCRDetailFromDate(String searchCRDetailFromDate) {
		this.searchCRDetailFromDate = searchCRDetailFromDate;
	}
	/**
	 * @return Returns the searchCRDetailGroupStatus.
	 */
	public String getSearchCRDetailGroupStatus() {
		return searchCRDetailGroupStatus;
	}
	/**
	 * @param searchCRDetailGroupStatus The searchCRDetailGroupStatus to set.
	 */
	public void setSearchCRDetailGroupStatus(String searchCRDetailGroupStatus) {
		this.searchCRDetailGroupStatus = searchCRDetailGroupStatus;
	}
	/**
	 * @return Returns the searchCRDetailHicNbr.
	 */
	public String getSearchCRDetailHicNbr() {
		return searchCRDetailHicNbr;
	}
	/**
	 * @param searchCRDetailHicNbr The searchCRDetailHicNbr to set.
	 */
	public void setSearchCRDetailHicNbr(String searchCRDetailHicNbr) {
		this.searchCRDetailHicNbr = searchCRDetailHicNbr;
	}
	/**
	 * @return Returns the searchCRDetailProcessStatus.
	 */
	public String getSearchCRDetailProcessStatus() {
		return searchCRDetailProcessStatus;
	}
	/**
	 * @param searchCRDetailProcessStatus The searchCRDetailProcessStatus to set.
	 */
	public void setSearchCRDetailProcessStatus(
			String searchCRDetailProcessStatus) {
		this.searchCRDetailProcessStatus = searchCRDetailProcessStatus;
	}
	/**
	 * @return Returns the searchCRDetailSubmitterId.
	 */
	public String getSearchCRDetailSubmitterId() {
		return searchCRDetailSubmitterId;
	}
	/**
	 * @param searchCRDetailSubmitterId The searchCRDetailSubmitterId to set.
	 */
	public void setSearchCRDetailSubmitterId(String searchCRDetailSubmitterId) {
		this.searchCRDetailSubmitterId = searchCRDetailSubmitterId;
	}
	/**
	 * @return Returns the searchCRDetailToDate.
	 */
	public String getSearchCRDetailToDate() {
		return searchCRDetailToDate;
	}
	/**
	 * @param searchCRDetailToDate The searchCRDetailToDate to set.
	 */
	public void setSearchCRDetailToDate(String searchCRDetailToDate) {
		this.searchCRDetailToDate = searchCRDetailToDate;
	}
	/**
	 * @return Returns the searchCRSummaryDateInd.
	 */
	public String getSearchCRSummaryDateInd() {
		return searchCRSummaryDateInd;
	}
	/**
	 * @param searchCRSummaryDateInd The searchCRSummaryDateInd to set.
	 */
	public void setSearchCRSummaryDateInd(String searchCRSummaryDateInd) {
		this.searchCRSummaryDateInd = searchCRSummaryDateInd;
	}
	/**
	 * @return Returns the searchCRSummaryEncType.
	 */
	public String getSearchCRSummaryEncType() {
		return searchCRSummaryEncType;
	}
	/**
	 * @param searchCRSummaryEncType The searchCRSummaryEncType to set.
	 */
	public void setSearchCRSummaryEncType(String searchCRSummaryEncType) {
		this.searchCRSummaryEncType = searchCRSummaryEncType;
	}
	/**
	 * @return Returns the searchCRSummaryErrorCode.
	 */
	public String getSearchCRSummaryErrorCode() {
		return searchCRSummaryErrorCode;
	}
	/**
	 * @param searchCRSummaryErrorCode The searchCRSummaryErrorCode to set.
	 */
	public void setSearchCRSummaryErrorCode(String searchCRSummaryErrorCode) {
		this.searchCRSummaryErrorCode = searchCRSummaryErrorCode;
	}
	/**
	 * @return Returns the searchCRSummaryErrorGroup.
	 */
	public String getSearchCRSummaryErrorGroup() {
		return searchCRSummaryErrorGroup;
	}
	/**
	 * @param searchCRSummaryErrorGroup The searchCRSummaryErrorGroup to set.
	 */
	public void setSearchCRSummaryErrorGroup(String searchCRSummaryErrorGroup) {
		this.searchCRSummaryErrorGroup = searchCRSummaryErrorGroup;
	}
	/**
	 * @return Returns the searchCRSummaryErrorSource.
	 */
	public String getSearchCRSummaryErrorSource() {
		return searchCRSummaryErrorSource;
	}
	/**
	 * @param searchCRSummaryErrorSource The searchCRSummaryErrorSource to set.
	 */
	public void setSearchCRSummaryErrorSource(String searchCRSummaryErrorSource) {
		this.searchCRSummaryErrorSource = searchCRSummaryErrorSource;
	}
	/**
	 * @return Returns the searchCRSummaryFromDate.
	 */
	public String getSearchCRSummaryFromDate() {
		return searchCRSummaryFromDate;
	}
	/**
	 * @param searchCRSummaryFromDate The searchCRSummaryFromDate to set.
	 */
	public void setSearchCRSummaryFromDate(String searchCRSummaryFromDate) {
		this.searchCRSummaryFromDate = searchCRSummaryFromDate;
	}
	/**
	 * @return Returns the searchCRSummaryGroupStatus.
	 */
	public String getSearchCRSummaryGroupStatus() {
		return searchCRSummaryGroupStatus;
	}
	/**
	 * @param searchCRSummaryGroupStatus The searchCRSummaryGroupStatus to set.
	 */
	public void setSearchCRSummaryGroupStatus(String searchCRSummaryGroupStatus) {
		this.searchCRSummaryGroupStatus = searchCRSummaryGroupStatus;
	}
	/**
	 * @return Returns the searchCRSummarySubmitterId.
	 */
	public String getSearchCRSummarySubmitterId() {
		return searchCRSummarySubmitterId;
	}
	/**
	 * @param searchCRSummarySubmitterId The searchCRSummarySubmitterId to set.
	 */
	public void setSearchCRSummarySubmitterId(String searchCRSummarySubmitterId) {
		this.searchCRSummarySubmitterId = searchCRSummarySubmitterId;
	}
	/**
	 * @return Returns the searchCRSummaryToDate.
	 */
	public String getSearchCRSummaryToDate() {
		return searchCRSummaryToDate;
	}
	/**
	 * @param searchCRSummaryToDate The searchCRSummaryToDate to set.
	 */
	public void setSearchCRSummaryToDate(String searchCRSummaryToDate) {
		this.searchCRSummaryToDate = searchCRSummaryToDate;
	}
	/**
	 * @return Returns the selectedCRDateYrmo.
	 */
	public String getSelectedCRDateYrmo() {
		return selectedCRDateYrmo;
	}
	/**
	 * @param selectedCRDateYrmo The selectedCRDateYrmo to set.
	 */
	public void setSelectedCRDateYrmo(String selectedCRDateYrmo) {
		this.selectedCRDateYrmo = selectedCRDateYrmo;
	}
	/**
	 * @return Returns the selectedCRErrorGroup.
	 */
	public String getSelectedCRErrorGroup() {
		return selectedCRErrorGroup;
	}
	/**
	 * @param selectedCRErrorGroup The selectedCRErrorGroup to set.
	 */
	public void setSelectedCRErrorGroup(String selectedCRErrorGroup) {
		this.selectedCRErrorGroup = selectedCRErrorGroup;
	}
	
	
	/**
	 * @return Returns the adjRepricdClmRefNbr.
	 */
	public String getAdjRepricdClmRefNbr() {
		return adjRepricdClmRefNbr;
	}
	/**
	 * @param adjRepricdClmRefNbr The adjRepricdClmRefNbr to set.
	 */
	public void setAdjRepricdClmRefNbr(String adjRepricdClmRefNbr) {
		this.adjRepricdClmRefNbr = adjRepricdClmRefNbr;
	}
	/**
	 * @return Returns the admitDiagCd.
	 */
	public String getAdmitDiagCd() {
		return admitDiagCd;
	}
	/**
	 * @param admitDiagCd The admitDiagCd to set.
	 */
	public void setAdmitDiagCd(String admitDiagCd) {
		this.admitDiagCd = admitDiagCd;
	}
	/**
	 * @return Returns the admitDiagType.
	 */
	public String getAdmitDiagType() {
		return admitDiagType;
	}
	/**
	 * @param admitDiagType The admitDiagType to set.
	 */
	public void setAdmitDiagType(String admitDiagType) {
		this.admitDiagType = admitDiagType;
	}
	/**
	 * @return Returns the ambCertCondCd1.
	 */
	public String getAmbCertCondCd1() {
		return ambCertCondCd1;
	}
	/**
	 * @param ambCertCondCd1 The ambCertCondCd1 to set.
	 */
	public void setAmbCertCondCd1(String ambCertCondCd1) {
		this.ambCertCondCd1 = ambCertCondCd1;
	}
	/**
	 * @return Returns the ambCertCondCd2.
	 */
	public String getAmbCertCondCd2() {
		return ambCertCondCd2;
	}
	/**
	 * @param ambCertCondCd2 The ambCertCondCd2 to set.
	 */
	public void setAmbCertCondCd2(String ambCertCondCd2) {
		this.ambCertCondCd2 = ambCertCondCd2;
	}
	/**
	 * @return Returns the ambCertCondCd3.
	 */
	public String getAmbCertCondCd3() {
		return ambCertCondCd3;
	}
	/**
	 * @param ambCertCondCd3 The ambCertCondCd3 to set.
	 */
	public void setAmbCertCondCd3(String ambCertCondCd3) {
		this.ambCertCondCd3 = ambCertCondCd3;
	}
	/**
	 * @return Returns the ambCertCondCd4.
	 */
	public String getAmbCertCondCd4() {
		return ambCertCondCd4;
	}
	/**
	 * @param ambCertCondCd4 The ambCertCondCd4 to set.
	 */
	public void setAmbCertCondCd4(String ambCertCondCd4) {
		this.ambCertCondCd4 = ambCertCondCd4;
	}
	/**
	 * @return Returns the ambCertCondCd5.
	 */
	public String getAmbCertCondCd5() {
		return ambCertCondCd5;
	}
	/**
	 * @param ambCertCondCd5 The ambCertCondCd5 to set.
	 */
	public void setAmbCertCondCd5(String ambCertCondCd5) {
		this.ambCertCondCd5 = ambCertCondCd5;
	}
	/**
	 * @return Returns the ambCertCondInd.
	 */
	public String getAmbCertCondInd() {
		return ambCertCondInd;
	}
	/**
	 * @param ambCertCondInd The ambCertCondInd to set.
	 */
	public void setAmbCertCondInd(String ambCertCondInd) {
		this.ambCertCondInd = ambCertCondInd;
	}
	/**
	 * @return Returns the ambDropoffCntrySubd.
	 */
	public String getAmbDropoffCntrySubd() {
		return ambDropoffCntrySubd;
	}
	/**
	 * @param ambDropoffCntrySubd The ambDropoffCntrySubd to set.
	 */
	public void setAmbDropoffCntrySubd(String ambDropoffCntrySubd) {
		this.ambDropoffCntrySubd = ambDropoffCntrySubd;
	}
	/**
	 * @return Returns the ambDropoffCountry.
	 */
	public String getAmbDropoffCountry() {
		return ambDropoffCountry;
	}
	/**
	 * @param ambDropoffCountry The ambDropoffCountry to set.
	 */
	public void setAmbDropoffCountry(String ambDropoffCountry) {
		this.ambDropoffCountry = ambDropoffCountry;
	}
	/**
	 * @return Returns the ambPatWeight.
	 */
	public String getAmbPatWeight() {
		return ambPatWeight;
	}
	/**
	 * @param ambPatWeight The ambPatWeight to set.
	 */
	public void setAmbPatWeight(String ambPatWeight) {
		this.ambPatWeight = ambPatWeight;
	}
	/**
	 * @return Returns the ambPickupCntrySubd.
	 */
	public String getAmbPickupCntrySubd() {
		return ambPickupCntrySubd;
	}
	/**
	 * @param ambPickupCntrySubd The ambPickupCntrySubd to set.
	 */
	public void setAmbPickupCntrySubd(String ambPickupCntrySubd) {
		this.ambPickupCntrySubd = ambPickupCntrySubd;
	}
	/**
	 * @return Returns the ambPickupCountry.
	 */
	public String getAmbPickupCountry() {
		return ambPickupCountry;
	}
	/**
	 * @param ambPickupCountry The ambPickupCountry to set.
	 */
	public void setAmbPickupCountry(String ambPickupCountry) {
		this.ambPickupCountry = ambPickupCountry;
	}
	/**
	 * @return Returns the ambTranspDistance.
	 */
	public String getAmbTranspDistance() {
		return ambTranspDistance;
	}
	/**
	 * @param ambTranspDistance The ambTranspDistance to set.
	 */
	public void setAmbTranspDistance(String ambTranspDistance) {
		this.ambTranspDistance = ambTranspDistance;
	}
	/**
	 * @return Returns the ambTranspReasonCd.
	 */
	public String getAmbTranspReasonCd() {
		return ambTranspReasonCd;
	}
	/**
	 * @param ambTranspReasonCd The ambTranspReasonCd to set.
	 */
	public void setAmbTranspReasonCd(String ambTranspReasonCd) {
		this.ambTranspReasonCd = ambTranspReasonCd;
	}
	/**
	 * @return Returns the anestSurgProcCd1.
	 */
	public String getAnestSurgProcCd1() {
		return anestSurgProcCd1;
	}
	/**
	 * @param anestSurgProcCd1 The anestSurgProcCd1 to set.
	 */
	public void setAnestSurgProcCd1(String anestSurgProcCd1) {
		this.anestSurgProcCd1 = anestSurgProcCd1;
	}
	/**
	 * @return Returns the anestSurgProcCd2.
	 */
	public String getAnestSurgProcCd2() {
		return anestSurgProcCd2;
	}
	/**
	 * @param anestSurgProcCd2 The anestSurgProcCd2 to set.
	 */
	public void setAnestSurgProcCd2(String anestSurgProcCd2) {
		this.anestSurgProcCd2 = anestSurgProcCd2;
	}
	/**
	 * @return Returns the autoAccidentCountry.
	 */
	public String getAutoAccidentCountry() {
		return autoAccidentCountry;
	}
	/**
	 * @param autoAccidentCountry The autoAccidentCountry to set.
	 */
	public void setAutoAccidentCountry(String autoAccidentCountry) {
		this.autoAccidentCountry = autoAccidentCountry;
	}
	/**
	 * @return Returns the autoAccidentInd.
	 */
	public String getAutoAccidentInd() {
		return autoAccidentInd;
	}
	/**
	 * @param autoAccidentInd The autoAccidentInd to set.
	 */
	public void setAutoAccidentInd(String autoAccidentInd) {
		this.autoAccidentInd = autoAccidentInd;
	}
	/**
	 * @return Returns the autoAccidentState.
	 */
	public String getAutoAccidentState() {
		return autoAccidentState;
	}
	/**
	 * @param autoAccidentState The autoAccidentState to set.
	 */
	public void setAutoAccidentState(String autoAccidentState) {
		this.autoAccidentState = autoAccidentState;
	}
	/**
	 * @return Returns the beneAssignCertInd.
	 */
	public String getBeneAssignCertInd() {
		return beneAssignCertInd;
	}
	/**
	 * @param beneAssignCertInd The beneAssignCertInd to set.
	 */
	public void setBeneAssignCertInd(String beneAssignCertInd) {
		this.beneAssignCertInd = beneAssignCertInd;
	}
	/**
	 * @return Returns the billingNotes.
	 */
	public String getBillingNotes() {
		return billingNotes;
	}
	/**
	 * @param billingNotes The billingNotes to set.
	 */
	public void setBillingNotes(String billingNotes) {
		this.billingNotes = billingNotes;
	}
	/**
	 * @return Returns the billPrvCntrySubdCd.
	 */
	public String getBillPrvCntrySubdCd() {
		return billPrvCntrySubdCd;
	}
	/**
	 * @param billPrvCntrySubdCd The billPrvCntrySubdCd to set.
	 */
	public void setBillPrvCntrySubdCd(String billPrvCntrySubdCd) {
		this.billPrvCntrySubdCd = billPrvCntrySubdCd;
	}
	/**
	 * @return Returns the billPrvCommNbr.
	 */
	public String getBillPrvCommNbr() {
		return billPrvCommNbr;
	}
	/**
	 * @param billPrvCommNbr The billPrvCommNbr to set.
	 */
	public void setBillPrvCommNbr(String billPrvCommNbr) {
		this.billPrvCommNbr = billPrvCommNbr;
	}
	/**
	 * @return Returns the billPrvContactName.
	 */
	public String getBillPrvContactName() {
		return billPrvContactName;
	}
	/**
	 * @param billPrvContactName The billPrvContactName to set.
	 */
	public void setBillPrvContactName(String billPrvContactName) {
		this.billPrvContactName = billPrvContactName;
	}
	/**
	 * @return Returns the billPrvCountry.
	 */
	public String getBillPrvCountry() {
		return billPrvCountry;
	}
	/**
	 * @param billPrvCountry The billPrvCountry to set.
	 */
	public void setBillPrvCountry(String billPrvCountry) {
		this.billPrvCountry = billPrvCountry;
	}
	/**
	 * @return Returns the billPrvLocNbr.
	 */
	public String getBillPrvLocNbr() {
		return billPrvLocNbr;
	}
	/**
	 * @param billPrvLocNbr The billPrvLocNbr to set.
	 */
	public void setBillPrvLocNbr(String billPrvLocNbr) {
		this.billPrvLocNbr = billPrvLocNbr;
	}
	/**
	 * @return Returns the carePlanOversightNbr.
	 */
	public String getCarePlanOversightNbr() {
		return carePlanOversightNbr;
	}
	/**
	 * @param carePlanOversightNbr The carePlanOversightNbr to set.
	 */
	public void setCarePlanOversightNbr(String carePlanOversightNbr) {
		this.carePlanOversightNbr = carePlanOversightNbr;
	}
	/**
	 * @return Returns the claimNotes.
	 */
	public String getClaimNotes() {
		return claimNotes;
	}
	/**
	 * @param claimNotes The claimNotes to set.
	 */
	public void setClaimNotes(String claimNotes) {
		this.claimNotes = claimNotes;
	}
	/**
	 * @return Returns the claimRefCd.
	 */
	public String getClaimRefCd() {
		return claimRefCd;
	}
	/**
	 * @param claimRefCd The claimRefCd to set.
	 */
	public void setClaimRefCd(String claimRefCd) {
		this.claimRefCd = claimRefCd;
	}
	/**
	 * @return Returns the clmFreqTypeCd.
	 */
	public String getClmFreqTypeCd() {
		return clmFreqTypeCd;
	}
	/**
	 * @param clmFreqTypeCd The clmFreqTypeCd to set.
	 */
	public void setClmFreqTypeCd(String clmFreqTypeCd) {
		this.clmFreqTypeCd = clmFreqTypeCd;
	}
	/**
	 * @return Returns the contractCd.
	 */
	public String getContractCd() {
		return contractCd;
	}
	/**
	 * @param contractCd The contractCd to set.
	 */
	public void setContractCd(String contractCd) {
		this.contractCd = contractCd;
	}
	/**
	 * @return Returns the contractTypeCd.
	 */
	public String getContractTypeCd() {
		return contractTypeCd;
	}
	/**
	 * @param contractTypeCd The contractTypeCd to set.
	 */
	public void setContractTypeCd(String contractTypeCd) {
		this.contractTypeCd = contractTypeCd;
	}
	/**
	 * @return Returns the contractVersionId.
	 */
	public String getContractVersionId() {
		return contractVersionId;
	}
	/**
	 * @param contractVersionId The contractVersionId to set.
	 */
	public void setContractVersionId(String contractVersionId) {
		this.contractVersionId = contractVersionId;
	}
	/**
	 * @return Returns the delayReasonCd.
	 */
	public String getDelayReasonCd() {
		return delayReasonCd;
	}
	/**
	 * @param delayReasonCd The delayReasonCd to set.
	 */
	public void setDelayReasonCd(String delayReasonCd) {
		this.delayReasonCd = delayReasonCd;
	}
	/**
	 * @return Returns the demonstrationProjectId.
	 */
	public String getDemonstrationProjectId() {
		return demonstrationProjectId;
	}
	/**
	 * @param demonstrationProjectId The demonstrationProjectId to set.
	 */
	public void setDemonstrationProjectId(String demonstrationProjectId) {
		this.demonstrationProjectId = demonstrationProjectId;
	}
	/**
	 * @return Returns the demonstrationProjId.
	 */
	public String getDemonstrationProjId() {
		return demonstrationProjId;
	}
	/**
	 * @param demonstrationProjId The demonstrationProjId to set.
	 */
	public void setDemonstrationProjId(String demonstrationProjId) {
		this.demonstrationProjId = demonstrationProjId;
	}
	/**
	 * @return Returns the dischargeHour.
	 */
	public String getDischargeHour() {
		return dischargeHour;
	}
	/**
	 * @param dischargeHour The dischargeHour to set.
	 */
	public void setDischargeHour(String dischargeHour) {
		this.dischargeHour = dischargeHour;
	}
	/**
	 * @return Returns the drgCd.
	 */
	public String getDrgCd() {
		return drgCd;
	}
	/**
	 * @param drgCd The drgCd to set.
	 */
	public void setDrgCd(String drgCd) {
		this.drgCd = drgCd;
	}
	/**
	 * @return Returns the employmentAccidentInd.
	 */
	public String getEmploymentAccidentInd() {
		return employmentAccidentInd;
	}
	/**
	 * @param employmentAccidentInd The employmentAccidentInd to set.
	 */
	public void setEmploymentAccidentInd(String employmentAccidentInd) {
		this.employmentAccidentInd = employmentAccidentInd;
	}
	/**
	 * @return Returns the epsdtCondInd1.
	 */
	public String getEpsdtCondInd1() {
		return epsdtCondInd1;
	}
	/**
	 * @param epsdtCondInd1 The epsdtCondInd1 to set.
	 */
	public void setEpsdtCondInd1(String epsdtCondInd1) {
		this.epsdtCondInd1 = epsdtCondInd1;
	}
	/**
	 * @return Returns the epsdtCondInd2.
	 */
	public String getEpsdtCondInd2() {
		return epsdtCondInd2;
	}
	/**
	 * @param epsdtCondInd2 The epsdtCondInd2 to set.
	 */
	public void setEpsdtCondInd2(String epsdtCondInd2) {
		this.epsdtCondInd2 = epsdtCondInd2;
	}
	/**
	 * @return Returns the epsdtCondInd3.
	 */
	public String getEpsdtCondInd3() {
		return epsdtCondInd3;
	}
	/**
	 * @param epsdtCondInd3 The epsdtCondInd3 to set.
	 */
	public void setEpsdtCondInd3(String epsdtCondInd3) {
		this.epsdtCondInd3 = epsdtCondInd3;
	}
	/**
	 * @return Returns the formattedAccidentDt.
	 */
	public String getFormattedAccidentDt() {
		return formattedAccidentDt;
	}
	/**
	 * @param formattedAccidentDt The formattedAccidentDt to set.
	 */
	public void setFormattedAccidentDt(String formattedAccidentDt) {
		this.formattedAccidentDt = formattedAccidentDt;
	}
	/**
	 * @return Returns the formattedAcuteManifestationDt.
	 */
	public String getFormattedAcuteManifestationDt() {
		return formattedAcuteManifestationDt;
	}
	/**
	 * @param formattedAcuteManifestationDt The formattedAcuteManifestationDt to set.
	 */
	public void setFormattedAcuteManifestationDt(
			String formattedAcuteManifestationDt) {
		this.formattedAcuteManifestationDt = formattedAcuteManifestationDt;
	}
	/**
	 * @return Returns the formattedAsumdCareEndDt.
	 */
	public String getFormattedAsumdCareEndDt() {
		return formattedAsumdCareEndDt;
	}
	/**
	 * @param formattedAsumdCareEndDt The formattedAsumdCareEndDt to set.
	 */
	public void setFormattedAsumdCareEndDt(String formattedAsumdCareEndDt) {
		this.formattedAsumdCareEndDt = formattedAsumdCareEndDt;
	}
	/**
	 * @return Returns the formattedAsumdCareStartDt.
	 */
	public String getFormattedAsumdCareStartDt() {
		return formattedAsumdCareStartDt;
	}
	/**
	 * @param formattedAsumdCareStartDt The formattedAsumdCareStartDt to set.
	 */
	public void setFormattedAsumdCareStartDt(String formattedAsumdCareStartDt) {
		this.formattedAsumdCareStartDt = formattedAsumdCareStartDt;
	}
	/**
	 * @return Returns the formattedAuthReturnWorkDt.
	 */
	public String getFormattedAuthReturnWorkDt() {
		return formattedAuthReturnWorkDt;
	}
	/**
	 * @param formattedAuthReturnWorkDt The formattedAuthReturnWorkDt to set.
	 */
	public void setFormattedAuthReturnWorkDt(String formattedAuthReturnWorkDt) {
		this.formattedAuthReturnWorkDt = formattedAuthReturnWorkDt;
	}
	/**
	 * @return Returns the formattedDisabilityEndDt.
	 */
	public String getFormattedDisabilityEndDt() {
		return formattedDisabilityEndDt;
	}
	/**
	 * @param formattedDisabilityEndDt The formattedDisabilityEndDt to set.
	 */
	public void setFormattedDisabilityEndDt(String formattedDisabilityEndDt) {
		this.formattedDisabilityEndDt = formattedDisabilityEndDt;
	}
	/**
	 * @return Returns the formattedDisabilityStartDt.
	 */
	public String getFormattedDisabilityStartDt() {
		return formattedDisabilityStartDt;
	}
	/**
	 * @param formattedDisabilityStartDt The formattedDisabilityStartDt to set.
	 */
	public void setFormattedDisabilityStartDt(String formattedDisabilityStartDt) {
		this.formattedDisabilityStartDt = formattedDisabilityStartDt;
	}
	/**
	 * @return Returns the formattedFirstVisitConsultDt.
	 */
	public String getFormattedFirstVisitConsultDt() {
		return formattedFirstVisitConsultDt;
	}
	/**
	 * @param formattedFirstVisitConsultDt The formattedFirstVisitConsultDt to set.
	 */
	public void setFormattedFirstVisitConsultDt(
			String formattedFirstVisitConsultDt) {
		this.formattedFirstVisitConsultDt = formattedFirstVisitConsultDt;
	}
	/**
	 * @return Returns the formattedHearVisionDt.
	 */
	public String getFormattedHearVisionDt() {
		return formattedHearVisionDt;
	}
	/**
	 * @param formattedHearVisionDt The formattedHearVisionDt to set.
	 */
	public void setFormattedHearVisionDt(String formattedHearVisionDt) {
		this.formattedHearVisionDt = formattedHearVisionDt;
	}
	/**
	 * @return Returns the formattedIllnessOccurDt.
	 */
	public String getFormattedIllnessOccurDt() {
		return formattedIllnessOccurDt;
	}
	/**
	 * @param formattedIllnessOccurDt The formattedIllnessOccurDt to set.
	 */
	public void setFormattedIllnessOccurDt(String formattedIllnessOccurDt) {
		this.formattedIllnessOccurDt = formattedIllnessOccurDt;
	}
	/**
	 * @return Returns the formattedInitialTreatmentDt.
	 */
	public String getFormattedInitialTreatmentDt() {
		return formattedInitialTreatmentDt;
	}
	/**
	 * @param formattedInitialTreatmentDt The formattedInitialTreatmentDt to set.
	 */
	public void setFormattedInitialTreatmentDt(
			String formattedInitialTreatmentDt) {
		this.formattedInitialTreatmentDt = formattedInitialTreatmentDt;
	}
	/**
	 * @return Returns the formattedLastMenstrualPerDt.
	 */
	public String getFormattedLastMenstrualPerDt() {
		return formattedLastMenstrualPerDt;
	}
	/**
	 * @param formattedLastMenstrualPerDt The formattedLastMenstrualPerDt to set.
	 */
	public void setFormattedLastMenstrualPerDt(
			String formattedLastMenstrualPerDt) {
		this.formattedLastMenstrualPerDt = formattedLastMenstrualPerDt;
	}
	/**
	 * @return Returns the formattedLastSeenDt.
	 */
	public String getFormattedLastSeenDt() {
		return formattedLastSeenDt;
	}
	/**
	 * @param formattedLastSeenDt The formattedLastSeenDt to set.
	 */
	public void setFormattedLastSeenDt(String formattedLastSeenDt) {
		this.formattedLastSeenDt = formattedLastSeenDt;
	}
	/**
	 * @return Returns the formattedLastWorkedDt.
	 */
	public String getFormattedLastWorkedDt() {
		return formattedLastWorkedDt;
	}
	/**
	 * @param formattedLastWorkedDt The formattedLastWorkedDt to set.
	 */
	public void setFormattedLastWorkedDt(String formattedLastWorkedDt) {
		this.formattedLastWorkedDt = formattedLastWorkedDt;
	}
	/**
	 * @return Returns the formattedLastXrayDt.
	 */
	public String getFormattedLastXrayDt() {
		return formattedLastXrayDt;
	}
	/**
	 * @param formattedLastXrayDt The formattedLastXrayDt to set.
	 */
	public void setFormattedLastXrayDt(String formattedLastXrayDt) {
		this.formattedLastXrayDt = formattedLastXrayDt;
	}
	/**
	 * @return Returns the investigDeviceExempId.
	 */
	public String getInvestigDeviceExempId() {
		return investigDeviceExempId;
	}
	/**
	 * @param investigDeviceExempId The investigDeviceExempId to set.
	 */
	public void setInvestigDeviceExempId(String investigDeviceExempId) {
		this.investigDeviceExempId = investigDeviceExempId;
	}
	/**
	 * @return Returns the investigDeviceExmptId.
	 */
	public String getInvestigDeviceExmptId() {
		return investigDeviceExmptId;
	}
	/**
	 * @param investigDeviceExmptId The investigDeviceExmptId to set.
	 */
	public void setInvestigDeviceExmptId(String investigDeviceExmptId) {
		this.investigDeviceExmptId = investigDeviceExmptId;
	}
	/**
	 * @return Returns the labHomeCondInd.
	 */
	public String getLabHomeCondInd() {
		return labHomeCondInd;
	}
	/**
	 * @param labHomeCondInd The labHomeCondInd to set.
	 */
	public void setLabHomeCondInd(String labHomeCondInd) {
		this.labHomeCondInd = labHomeCondInd;
	}
	/**
	 * @return Returns the labHomeRespCd.
	 */
	public String getLabHomeRespCd() {
		return labHomeRespCd;
	}
	/**
	 * @param labHomeRespCd The labHomeRespCd to set.
	 */
	public void setLabHomeRespCd(String labHomeRespCd) {
		this.labHomeRespCd = labHomeRespCd;
	}
	/**
	 * @return Returns the medicalRecordNbr.
	 */
	public String getMedicalRecordNbr() {
		return medicalRecordNbr;
	}
	/**
	 * @param medicalRecordNbr The medicalRecordNbr to set.
	 */
	public void setMedicalRecordNbr(String medicalRecordNbr) {
		this.medicalRecordNbr = medicalRecordNbr;
	}
	/**
	 * @return Returns the medicareCrossoverCd.
	 */
	public String getMedicareCrossoverCd() {
		return medicareCrossoverCd;
	}
	/**
	 * @param medicareCrossoverCd The medicareCrossoverCd to set.
	 */
	public void setMedicareCrossoverCd(String medicareCrossoverCd) {
		this.medicareCrossoverCd = medicareCrossoverCd;
	}
	/**
	 * @return Returns the otherAccidentInd.
	 */
	public String getOtherAccidentInd() {
		return otherAccidentInd;
	}
	/**
	 * @param otherAccidentInd The otherAccidentInd to set.
	 */
	public void setOtherAccidentInd(String otherAccidentInd) {
		this.otherAccidentInd = otherAccidentInd;
	}
	/**
	 * @return Returns the p2pAddrLine1.
	 */
	public String getP2pAddrLine1() {
		return p2pAddrLine1;
	}
	/**
	 * @param addrLine1 The p2pAddrLine1 to set.
	 */
	public void setP2pAddrLine1(String addrLine1) {
		p2pAddrLine1 = addrLine1;
	}
	/**
	 * @return Returns the p2pAddrLine2.
	 */
	public String getP2pAddrLine2() {
		return p2pAddrLine2;
	}
	/**
	 * @param addrLine2 The p2pAddrLine2 to set.
	 */
	public void setP2pAddrLine2(String addrLine2) {
		p2pAddrLine2 = addrLine2;
	}
	/**
	 * @return Returns the p2pCity.
	 */
	public String getP2pCity() {
		return p2pCity;
	}
	/**
	 * @param city The p2pCity to set.
	 */
	public void setP2pCity(String city) {
		p2pCity = city;
	}
	/**
	 * @return Returns the p2pCntrySubdCd.
	 */
	public String getP2pCntrySubdCd() {
		return p2pCntrySubdCd;
	}
	/**
	 * @param cntrySubdCd The p2pCntrySubdCd to set.
	 */
	public void setP2pCntrySubdCd(String cntrySubdCd) {
		p2pCntrySubdCd = cntrySubdCd;
	}
	/**
	 * @return Returns the p2pCountry.
	 */
	public String getP2pCountry() {
		return p2pCountry;
	}
	/**
	 * @param country The p2pCountry to set.
	 */
	public void setP2pCountry(String country) {
		p2pCountry = country;
	}
	/**
	 * @return Returns the p2pLocNbr.
	 */
	public String getP2pLocNbr() {
		return p2pLocNbr;
	}
	/**
	 * @param locNbr The p2pLocNbr to set.
	 */
	public void setP2pLocNbr(String locNbr) {
		p2pLocNbr = locNbr;
	}
	/**
	 * @return Returns the p2pNaicCd.
	 */
	public String getP2pNaicCd() {
		return p2pNaicCd;
	}
	/**
	 * @param naicCd The p2pNaicCd to set.
	 */
	public void setP2pNaicCd(String naicCd) {
		p2pNaicCd = naicCd;
	}
	/**
	 * @return Returns the p2pOrgName.
	 */
	public String getP2pOrgName() {
		return p2pOrgName;
	}
	/**
	 * @param orgName The p2pOrgName to set.
	 */
	public void setP2pOrgName(String orgName) {
		p2pOrgName = orgName;
	}
	/**
	 * @return Returns the p2pPayerIdNbr.
	 */
	public String getP2pPayerIdNbr() {
		return p2pPayerIdNbr;
	}
	/**
	 * @param payerIdNbr The p2pPayerIdNbr to set.
	 */
	public void setP2pPayerIdNbr(String payerIdNbr) {
		p2pPayerIdNbr = payerIdNbr;
	}
	/**
	 * @return Returns the p2pPrimPayerId.
	 */
	public String getP2pPrimPayerId() {
		return p2pPrimPayerId;
	}
	/**
	 * @param primPayerId The p2pPrimPayerId to set.
	 */
	public void setP2pPrimPayerId(String primPayerId) {
		p2pPrimPayerId = primPayerId;
	}
	/**
	 * @return Returns the p2pPrimPlanId.
	 */
	public String getP2pPrimPlanId() {
		return p2pPrimPlanId;
	}
	/**
	 * @param primPlanId The p2pPrimPlanId to set.
	 */
	public void setP2pPrimPlanId(String primPlanId) {
		p2pPrimPlanId = primPlanId;
	}
	/**
	 * @return Returns the p2prvCntrySubdCd.
	 */
	public String getP2prvCntrySubdCd() {
		return p2prvCntrySubdCd;
	}
	/**
	 * @param cntrySubdCd The p2prvCntrySubdCd to set.
	 */
	public void setP2prvCntrySubdCd(String cntrySubdCd) {
		p2prvCntrySubdCd = cntrySubdCd;
	}
	/**
	 * @return Returns the p2prvCountry.
	 */
	public String getP2prvCountry() {
		return p2prvCountry;
	}
	/**
	 * @param country The p2prvCountry to set.
	 */
	public void setP2prvCountry(String country) {
		p2prvCountry = country;
	}
	/**
	 * @return Returns the p2pState.
	 */
	public String getP2pState() {
		return p2pState;
	}
	/**
	 * @param state The p2pState to set.
	 */
	public void setP2pState(String state) {
		p2pState = state;
	}
	/**
	 * @return Returns the p2pTaxId.
	 */
	public String getP2pTaxId() {
		return p2pTaxId;
	}
	/**
	 * @param taxId The p2pTaxId to set.
	 */
	public void setP2pTaxId(String taxId) {
		p2pTaxId = taxId;
	}
	/**
	 * @return Returns the p2pZip.
	 */
	public String getP2pZip() {
		return p2pZip;
	}
	/**
	 * @param zip The p2pZip to set.
	 */
	public void setP2pZip(String zip) {
		p2pZip = zip;
	}
	/**
	 * @return Returns the patientCondCd.
	 */
	public String getPatientCondCd() {
		return patientCondCd;
	}
	/**
	 * @param patientCondCd The patientCondCd to set.
	 */
	public void setPatientCondCd(String patientCondCd) {
		this.patientCondCd = patientCondCd;
	}
	/**
	 * @return Returns the patientCtrlNbr.
	 */
	public String getPatientCtrlNbr() {
		return patientCtrlNbr;
	}
	/**
	 * @param patientCtrlNbr The patientCtrlNbr to set.
	 */
	public void setPatientCtrlNbr(String patientCtrlNbr) {
		this.patientCtrlNbr = patientCtrlNbr;
	}
	/**
	 * @return Returns the patSignatureSrcCd.
	 */
	public String getPatSignatureSrcCd() {
		return patSignatureSrcCd;
	}
	/**
	 * @param patSignatureSrcCd The patSignatureSrcCd to set.
	 */
	public void setPatSignatureSrcCd(String patSignatureSrcCd) {
		this.patSignatureSrcCd = patSignatureSrcCd;
	}
	/**
	 * @return Returns the patVisitreasCd1.
	 */
	public String getPatVisitreasCd1() {
		return patVisitreasCd1;
	}
	/**
	 * @param patVisitreasCd1 The patVisitreasCd1 to set.
	 */
	public void setPatVisitreasCd1(String patVisitreasCd1) {
		this.patVisitreasCd1 = patVisitreasCd1;
	}
	/**
	 * @return Returns the patVisitreasCd2.
	 */
	public String getPatVisitreasCd2() {
		return patVisitreasCd2;
	}
	/**
	 * @param patVisitreasCd2 The patVisitreasCd2 to set.
	 */
	public void setPatVisitreasCd2(String patVisitreasCd2) {
		this.patVisitreasCd2 = patVisitreasCd2;
	}
	/**
	 * @return Returns the patVisitreasCd3.
	 */
	public String getPatVisitreasCd3() {
		return patVisitreasCd3;
	}
	/**
	 * @param patVisitreasCd3 The patVisitreasCd3 to set.
	 */
	public void setPatVisitreasCd3(String patVisitreasCd3) {
		this.patVisitreasCd3 = patVisitreasCd3;
	}
	/**
	 * @return Returns the patVisitreasType1.
	 */
	public String getPatVisitreasType1() {
		return patVisitreasType1;
	}
	/**
	 * @param patVisitreasType1 The patVisitreasType1 to set.
	 */
	public void setPatVisitreasType1(String patVisitreasType1) {
		this.patVisitreasType1 = patVisitreasType1;
	}
	/**
	 * @return Returns the patVisitreasType2.
	 */
	public String getPatVisitreasType2() {
		return patVisitreasType2;
	}
	/**
	 * @param patVisitreasType2 The patVisitreasType2 to set.
	 */
	public void setPatVisitreasType2(String patVisitreasType2) {
		this.patVisitreasType2 = patVisitreasType2;
	}
	/**
	 * @return Returns the patVisitreasType3.
	 */
	public String getPatVisitreasType3() {
		return patVisitreasType3;
	}
	/**
	 * @param patVisitreasType3 The patVisitreasType3 to set.
	 */
	public void setPatVisitreasType3(String patVisitreasType3) {
		this.patVisitreasType3 = patVisitreasType3;
	}
	/**
	 * @return Returns the payerAddrLine1.
	 */
	public String getPayerAddrLine1() {
		return payerAddrLine1;
	}
	/**
	 * @param payerAddrLine1 The payerAddrLine1 to set.
	 */
	public void setPayerAddrLine1(String payerAddrLine1) {
		this.payerAddrLine1 = payerAddrLine1;
	}
	/**
	 * @return Returns the payerAddrLine2.
	 */
	public String getPayerAddrLine2() {
		return payerAddrLine2;
	}
	/**
	 * @param payerAddrLine2 The payerAddrLine2 to set.
	 */
	public void setPayerAddrLine2(String payerAddrLine2) {
		this.payerAddrLine2 = payerAddrLine2;
	}
	/**
	 * @return Returns the payerCity.
	 */
	public String getPayerCity() {
		return payerCity;
	}
	/**
	 * @param payerCity The payerCity to set.
	 */
	public void setPayerCity(String payerCity) {
		this.payerCity = payerCity;
	}
	/**
	 * @return Returns the payerClmCtrlNbr.
	 */
	public String getPayerClmCtrlNbr() {
		return payerClmCtrlNbr;
	}
	/**
	 * @param payerClmCtrlNbr The payerClmCtrlNbr to set.
	 */
	public void setPayerClmCtrlNbr(String payerClmCtrlNbr) {
		this.payerClmCtrlNbr = payerClmCtrlNbr;
	}
	/**
	 * @return Returns the payerCntrySubdCd.
	 */
	public String getPayerCntrySubdCd() {
		return payerCntrySubdCd;
	}
	/**
	 * @param payerCntrySubdCd The payerCntrySubdCd to set.
	 */
	public void setPayerCntrySubdCd(String payerCntrySubdCd) {
		this.payerCntrySubdCd = payerCntrySubdCd;
	}
	/**
	 * @return Returns the payerCountry.
	 */
	public String getPayerCountry() {
		return payerCountry;
	}
	/**
	 * @param payerCountry The payerCountry to set.
	 */
	public void setPayerCountry(String payerCountry) {
		this.payerCountry = payerCountry;
	}
	/**
	 * @return Returns the payerId.
	 */
	public String getPayerId() {
		return payerId;
	}
	/**
	 * @param payerId The payerId to set.
	 */
	public void setPayerId(String payerId) {
		this.payerId = payerId;
	}
	/**
	 * @return Returns the payerLocNbr.
	 */
	public String getPayerLocNbr() {
		return payerLocNbr;
	}
	/**
	 * @param payerLocNbr The payerLocNbr to set.
	 */
	public void setPayerLocNbr(String payerLocNbr) {
		this.payerLocNbr = payerLocNbr;
	}
	/**
	 * @return Returns the payerNaicCd.
	 */
	public String getPayerNaicCd() {
		return payerNaicCd;
	}
	/**
	 * @param payerNaicCd The payerNaicCd to set.
	 */
	public void setPayerNaicCd(String payerNaicCd) {
		this.payerNaicCd = payerNaicCd;
	}
	/**
	 * @return Returns the payerName.
	 */
	public String getPayerName() {
		return payerName;
	}
	/**
	 * @param payerName The payerName to set.
	 */
	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}
	/**
	 * @return Returns the payerPlanId.
	 */
	public String getPayerPlanId() {
		return payerPlanId;
	}
	/**
	 * @param payerPlanId The payerPlanId to set.
	 */
	public void setPayerPlanId(String payerPlanId) {
		this.payerPlanId = payerPlanId;
	}
	/**
	 * @return Returns the payerSecId.
	 */
	public String getPayerSecId() {
		return payerSecId;
	}
	/**
	 * @param payerSecId The payerSecId to set.
	 */
	public void setPayerSecId(String payerSecId) {
		this.payerSecId = payerSecId;
	}
	/**
	 * @return Returns the payerState.
	 */
	public String getPayerState() {
		return payerState;
	}
	/**
	 * @param payerState The payerState to set.
	 */
	public void setPayerState(String payerState) {
		this.payerState = payerState;
	}
	/**
	 * @return Returns the payerTaxId.
	 */
	public String getPayerTaxId() {
		return payerTaxId;
	}
	/**
	 * @param payerTaxId The payerTaxId to set.
	 */
	public void setPayerTaxId(String payerTaxId) {
		this.payerTaxId = payerTaxId;
	}
	/**
	 * @return Returns the payerZip.
	 */
	public String getPayerZip() {
		return payerZip;
	}
	/**
	 * @param payerZip The payerZip to set.
	 */
	public void setPayerZip(String payerZip) {
		this.payerZip = payerZip;
	}
	/**
	 * @return Returns the peerRevewOrgAprvNbr.
	 */
	public String getPeerRevewOrgAprvNbr() {
		return peerRevewOrgAprvNbr;
	}
	/**
	 * @param peerRevewOrgAprvNbr The peerRevewOrgAprvNbr to set.
	 */
	public void setPeerRevewOrgAprvNbr(String peerRevewOrgAprvNbr) {
		this.peerRevewOrgAprvNbr = peerRevewOrgAprvNbr;
	}
	/**
	 * @return Returns the priorAuthNbr.
	 */
	public String getPriorAuthNbr() {
		return priorAuthNbr;
	}
	/**
	 * @param priorAuthNbr The priorAuthNbr to set.
	 */
	public void setPriorAuthNbr(String priorAuthNbr) {
		this.priorAuthNbr = priorAuthNbr;
	}
	/**
	 * @return Returns the propCasltyClmNbr.
	 */
	public String getPropCasltyClmNbr() {
		return propCasltyClmNbr;
	}
	/**
	 * @param propCasltyClmNbr The propCasltyClmNbr to set.
	 */
	public void setPropCasltyClmNbr(String propCasltyClmNbr) {
		this.propCasltyClmNbr = propCasltyClmNbr;
	}
	/**
	 * @return Returns the propCasltySubsName.
	 */
	public String getPropCasltySubsName() {
		return propCasltySubsName;
	}
	/**
	 * @param propCasltySubsName The propCasltySubsName to set.
	 */
	public void setPropCasltySubsName(String propCasltySubsName) {
		this.propCasltySubsName = propCasltySubsName;
	}
	/**
	 * @return Returns the propCasltySubsPhnExt.
	 */
	public String getPropCasltySubsPhnExt() {
		return propCasltySubsPhnExt;
	}
	/**
	 * @param propCasltySubsPhnExt The propCasltySubsPhnExt to set.
	 */
	public void setPropCasltySubsPhnExt(String propCasltySubsPhnExt) {
		this.propCasltySubsPhnExt = propCasltySubsPhnExt;
	}
	/**
	 * @return Returns the propCasltySubsPhone.
	 */
	public String getPropCasltySubsPhone() {
		return propCasltySubsPhone;
	}
	/**
	 * @param propCasltySubsPhone The propCasltySubsPhone to set.
	 */
	public void setPropCasltySubsPhone(String propCasltySubsPhone) {
		this.propCasltySubsPhone = propCasltySubsPhone;
	}
	/**
	 * @return Returns the prvAcceptAssignCd.
	 */
	public String getPrvAcceptAssignCd() {
		return prvAcceptAssignCd;
	}
	/**
	 * @param prvAcceptAssignCd The prvAcceptAssignCd to set.
	 */
	public void setPrvAcceptAssignCd(String prvAcceptAssignCd) {
		this.prvAcceptAssignCd = prvAcceptAssignCd;
	}
	/**
	 * @return Returns the prvSignatureOnfileInd.
	 */
	public String getPrvSignatureOnfileInd() {
		return prvSignatureOnfileInd;
	}
	/**
	 * @param prvSignatureOnfileInd The prvSignatureOnfileInd to set.
	 */
	public void setPrvSignatureOnfileInd(String prvSignatureOnfileInd) {
		this.prvSignatureOnfileInd = prvSignatureOnfileInd;
	}
	/**
	 * @return Returns the referralNbr.
	 */
	public String getReferralNbr() {
		return referralNbr;
	}
	/**
	 * @param referralNbr The referralNbr to set.
	 */
	public void setReferralNbr(String referralNbr) {
		this.referralNbr = referralNbr;
	}
	/**
	 * @return Returns the releaseOfInfoCd.
	 */
	public String getReleaseOfInfoCd() {
		return releaseOfInfoCd;
	}
	/**
	 * @param releaseOfInfoCd The releaseOfInfoCd to set.
	 */
	public void setReleaseOfInfoCd(String releaseOfInfoCd) {
		this.releaseOfInfoCd = releaseOfInfoCd;
	}
	/**
	 * @return Returns the repricdClmRefNbr.
	 */
	public String getRepricdClmRefNbr() {
		return repricdClmRefNbr;
	}
	/**
	 * @param repricdClmRefNbr The repricdClmRefNbr to set.
	 */
	public void setRepricdClmRefNbr(String repricdClmRefNbr) {
		this.repricdClmRefNbr = repricdClmRefNbr;
	}
	/**
	 * @return Returns the repricedApprvdDrgCd.
	 */
	public String getRepricedApprvdDrgCd() {
		return repricedApprvdDrgCd;
	}
	/**
	 * @param repricedApprvdDrgCd The repricedApprvdDrgCd to set.
	 */
	public void setRepricedApprvdDrgCd(String repricedApprvdDrgCd) {
		this.repricedApprvdDrgCd = repricedApprvdDrgCd;
	}
	/**
	 * @return Returns the repricedApprvdRevCd.
	 */
	public String getRepricedApprvdRevCd() {
		return repricedApprvdRevCd;
	}
	/**
	 * @param repricedApprvdRevCd The repricedApprvdRevCd to set.
	 */
	public void setRepricedApprvdRevCd(String repricedApprvdRevCd) {
		this.repricedApprvdRevCd = repricedApprvdRevCd;
	}
	/**
	 * @return Returns the repricedExceptionCd.
	 */
	public String getRepricedExceptionCd() {
		return repricedExceptionCd;
	}
	/**
	 * @param repricedExceptionCd The repricedExceptionCd to set.
	 */
	public void setRepricedExceptionCd(String repricedExceptionCd) {
		this.repricedExceptionCd = repricedExceptionCd;
	}
	/**
	 * @return Returns the repricedPolCmpliantCd.
	 */
	public String getRepricedPolCmpliantCd() {
		return repricedPolCmpliantCd;
	}
	/**
	 * @param repricedPolCmpliantCd The repricedPolCmpliantCd to set.
	 */
	public void setRepricedPolCmpliantCd(String repricedPolCmpliantCd) {
		this.repricedPolCmpliantCd = repricedPolCmpliantCd;
	}
	/**
	 * @return Returns the repricedRejReasonCd.
	 */
	public String getRepricedRejReasonCd() {
		return repricedRejReasonCd;
	}
	/**
	 * @param repricedRejReasonCd The repricedRejReasonCd to set.
	 */
	public void setRepricedRejReasonCd(String repricedRejReasonCd) {
		this.repricedRejReasonCd = repricedRejReasonCd;
	}
	/**
	 * @return Returns the repricedUom.
	 */
	public String getRepricedUom() {
		return repricedUom;
	}
	/**
	 * @param repricedUom The repricedUom to set.
	 */
	public void setRepricedUom(String repricedUom) {
		this.repricedUom = repricedUom;
	}
	/**
	 * @return Returns the repricerReceivedDt.
	 */
	public String getRepricerReceivedDt() {
		return repricerReceivedDt;
	}
	/**
	 * @param repricerReceivedDt The repricerReceivedDt to set.
	 */
	public void setRepricerReceivedDt(String repricerReceivedDt) {
		this.repricerReceivedDt = repricerReceivedDt;
	}
	/**
	 * @return Returns the repricingOrgId.
	 */
	public String getRepricingOrgId() {
		return repricingOrgId;
	}
	/**
	 * @param repricingOrgId The repricingOrgId to set.
	 */
	public void setRepricingOrgId(String repricingOrgId) {
		this.repricingOrgId = repricingOrgId;
	}
	/**
	 * @return Returns the roundTripPurposeDesc.
	 */
	public String getRoundTripPurposeDesc() {
		return roundTripPurposeDesc;
	}
	/**
	 * @param roundTripPurposeDesc The roundTripPurposeDesc to set.
	 */
	public void setRoundTripPurposeDesc(String roundTripPurposeDesc) {
		this.roundTripPurposeDesc = roundTripPurposeDesc;
	}
	/**
	 * @return Returns the statementFromDt.
	 */
	public String getStatementFromDt() {
		return statementFromDt;
	}
	/**
	 * @param statementFromDt The statementFromDt to set.
	 */
	public void setStatementFromDt(String statementFromDt) {
		this.statementFromDt = statementFromDt;
	}
	/**
	 * @return Returns the statementToDt.
	 */
	public String getStatementToDt() {
		return statementToDt;
	}
	/**
	 * @param statementToDt The statementToDt to set.
	 */
	public void setStatementToDt(String statementToDt) {
		this.statementToDt = statementToDt;
	}
	/**
	 * @return Returns the stretcherPurposeDesc.
	 */
	public String getStretcherPurposeDesc() {
		return stretcherPurposeDesc;
	}
	/**
	 * @param stretcherPurposeDesc The stretcherPurposeDesc to set.
	 */
	public void setStretcherPurposeDesc(String stretcherPurposeDesc) {
		this.stretcherPurposeDesc = stretcherPurposeDesc;
	}
	/**
	 * @return Returns the subsCntrySubdCd.
	 */
	public String getSubsCntrySubdCd() {
		return subsCntrySubdCd;
	}
	/**
	 * @param subsCntrySubdCd The subsCntrySubdCd to set.
	 */
	public void setSubsCntrySubdCd(String subsCntrySubdCd) {
		this.subsCntrySubdCd = subsCntrySubdCd;
	}
	/**
	 * @return Returns the subsCountry.
	 */
	public String getSubsCountry() {
		return subsCountry;
	}
	/**
	 * @param subsCountry The subsCountry to set.
	 */
	public void setSubsCountry(String subsCountry) {
		this.subsCountry = subsCountry;
	}
	/**
	 * @return Returns the subsEntityType.
	 */
	public String getSubsEntityType() {
		return subsEntityType;
	}
	/**
	 * @param subsEntityType The subsEntityType to set.
	 */
	public void setSubsEntityType(String subsEntityType) {
		this.subsEntityType = subsEntityType;
	}
	/**
	 * @return Returns the subsFilingIndCd.
	 */
	public String getSubsFilingIndCd() {
		return subsFilingIndCd;
	}
	/**
	 * @param subsFilingIndCd The subsFilingIndCd to set.
	 */
	public void setSubsFilingIndCd(String subsFilingIndCd) {
		this.subsFilingIndCd = subsFilingIndCd;
	}
	/**
	 * @return Returns the subsGrpName.
	 */
	public String getSubsGrpName() {
		return SubsGrpName;
	}
	/**
	 * @param subsGrpName The subsGrpName to set.
	 */
	public void setSubsGrpName(String subsGrpName) {
		SubsGrpName = subsGrpName;
	}
	/**
	 * @return Returns the subsGrpOrPolNbr.
	 */
	public String getSubsGrpOrPolNbr() {
		return subsGrpOrPolNbr;
	}
	/**
	 * @param subsGrpOrPolNbr The subsGrpOrPolNbr to set.
	 */
	public void setSubsGrpOrPolNbr(String subsGrpOrPolNbr) {
		this.subsGrpOrPolNbr = subsGrpOrPolNbr;
	}
	/**
	 * @return Returns the subsInsuranceTypeCd.
	 */
	public String getSubsInsuranceTypeCd() {
		return subsInsuranceTypeCd;
	}
	/**
	 * @param subsInsuranceTypeCd The subsInsuranceTypeCd to set.
	 */
	public void setSubsInsuranceTypeCd(String subsInsuranceTypeCd) {
		this.subsInsuranceTypeCd = subsInsuranceTypeCd;
	}
	/**
	 * @return Returns the subsMemberId.
	 */
	public String getSubsMemberId() {
		return subsMemberId;
	}
	/**
	 * @param subsMemberId The subsMemberId to set.
	 */
	public void setSubsMemberId(String subsMemberId) {
		this.subsMemberId = subsMemberId;
	}
	/**
	 * @return Returns the subsPatDod.
	 */
	public String getSubsPatDod() {
		return subsPatDod;
	}
	/**
	 * @param subsPatDod The subsPatDod to set.
	 */
	public void setSubsPatDod(String subsPatDod) {
		this.subsPatDod = subsPatDod;
	}
	/**
	 * @return Returns the subsPatPregnantInd.
	 */
	public String getSubsPatPregnantInd() {
		return subsPatPregnantInd;
	}
	/**
	 * @param subsPatPregnantInd The subsPatPregnantInd to set.
	 */
	public void setSubsPatPregnantInd(String subsPatPregnantInd) {
		this.subsPatPregnantInd = subsPatPregnantInd;
	}
	/**
	 * @return Returns the subsPatUom.
	 */
	public String getSubsPatUom() {
		return subsPatUom;
	}
	/**
	 * @param subsPatUom The subsPatUom to set.
	 */
	public void setSubsPatUom(String subsPatUom) {
		this.subsPatUom = subsPatUom;
	}
	/**
	 * @return Returns the subsPatWeight.
	 */
	public int getSubsPatWeight() {
		return subsPatWeight;
	}
	/**
	 * @param subsPatWeight The subsPatWeight to set.
	 */
	public void setSubsPatWeight(int subsPatWeight) {
		this.subsPatWeight = subsPatWeight;
	}
	/**
	 * @return Returns the subsPayerSeqCd.
	 */
	public String getSubsPayerSeqCd() {
		return subsPayerSeqCd;
	}
	/**
	 * @param subsPayerSeqCd The subsPayerSeqCd to set.
	 */
	public void setSubsPayerSeqCd(String subsPayerSeqCd) {
		this.subsPayerSeqCd = subsPayerSeqCd;
	}
	/**
	 * @return Returns the subsPlanName.
	 */
	public String getSubsPlanName() {
		return subsPlanName;
	}
	/**
	 * @param subsPlanName The subsPlanName to set.
	 */
	public void setSubsPlanName(String subsPlanName) {
		this.subsPlanName = subsPlanName;
	}
	/**
	 * @return Returns the subsRelationCd.
	 */
	public String getSubsRelationCd() {
		return subsRelationCd;
	}
	/**
	 * @param subsRelationCd The subsRelationCd to set.
	 */
	public void setSubsRelationCd(String subsRelationCd) {
		this.subsRelationCd = subsRelationCd;
	}
	/**
	 * @return Returns the svcAuthExcptCd.
	 */
	public String getSvcAuthExcptCd() {
		return svcAuthExcptCd;
	}
	/**
	 * @param svcAuthExcptCd The svcAuthExcptCd to set.
	 */
	public void setSvcAuthExcptCd(String svcAuthExcptCd) {
		this.svcAuthExcptCd = svcAuthExcptCd;
	}
	/**
	 * @return Returns the svcFacContactName.
	 */
	public String getSvcFacContactName() {
		return svcFacContactName;
	}
	/**
	 * @param svcFacContactName The svcFacContactName to set.
	 */
	public void setSvcFacContactName(String svcFacContactName) {
		this.svcFacContactName = svcFacContactName;
	}
	/**
	 * @return Returns the svcFacPhone.
	 */
	public String getSvcFacPhone() {
		return svcFacPhone;
	}
	/**
	 * @param svcFacPhone The svcFacPhone to set.
	 */
	public void setSvcFacPhone(String svcFacPhone) {
		this.svcFacPhone = svcFacPhone;
	}
	/**
	 * @return Returns the svcFacPhoneExt.
	 */
	public String getSvcFacPhoneExt() {
		return svcFacPhoneExt;
	}
	/**
	 * @param svcFacPhoneExt The svcFacPhoneExt to set.
	 */
	public void setSvcFacPhoneExt(String svcFacPhoneExt) {
		this.svcFacPhoneExt = svcFacPhoneExt;
	}
	/**
	 * @return Returns the valueAddNtwkTraceNbr.
	 */
	public String getValueAddNtwkTraceNbr() {
		return valueAddNtwkTraceNbr;
	}
	/**
	 * @param valueAddNtwkTraceNbr The valueAddNtwkTraceNbr to set.
	 */
	public void setValueAddNtwkTraceNbr(String valueAddNtwkTraceNbr) {
		this.valueAddNtwkTraceNbr = valueAddNtwkTraceNbr;
	}
	/**
	 * @return Returns the visnCertCondCd1.
	 */
	public String getVisnCertCondCd1() {
		return visnCertCondCd1;
	}
	/**
	 * @param visnCertCondCd1 The visnCertCondCd1 to set.
	 */
	public void setVisnCertCondCd1(String visnCertCondCd1) {
		this.visnCertCondCd1 = visnCertCondCd1;
	}
	/**
	 * @return Returns the visnCertCondCd2.
	 */
	public String getVisnCertCondCd2() {
		return visnCertCondCd2;
	}
	/**
	 * @param visnCertCondCd2 The visnCertCondCd2 to set.
	 */
	public void setVisnCertCondCd2(String visnCertCondCd2) {
		this.visnCertCondCd2 = visnCertCondCd2;
	}
	/**
	 * @return Returns the visnCertCondCd3.
	 */
	public String getVisnCertCondCd3() {
		return visnCertCondCd3;
	}
	/**
	 * @param visnCertCondCd3 The visnCertCondCd3 to set.
	 */
	public void setVisnCertCondCd3(String visnCertCondCd3) {
		this.visnCertCondCd3 = visnCertCondCd3;
	}
	/**
	 * @return Returns the visnCertCondCd4.
	 */
	public String getVisnCertCondCd4() {
		return visnCertCondCd4;
	}
	/**
	 * @param visnCertCondCd4 The visnCertCondCd4 to set.
	 */
	public void setVisnCertCondCd4(String visnCertCondCd4) {
		this.visnCertCondCd4 = visnCertCondCd4;
	}
	/**
	 * @return Returns the visnCertCondCd5.
	 */
	public String getVisnCertCondCd5() {
		return visnCertCondCd5;
	}
	/**
	 * @param visnCertCondCd5 The visnCertCondCd5 to set.
	 */
	public void setVisnCertCondCd5(String visnCertCondCd5) {
		this.visnCertCondCd5 = visnCertCondCd5;
	}
	/**
	 * @return Returns the visnCertCondInd.
	 */
	public String getVisnCertCondInd() {
		return visnCertCondInd;
	}
	/**
	 * @param visnCertCondInd The visnCertCondInd to set.
	 */
	public void setVisnCertCondInd(String visnCertCondInd) {
		this.visnCertCondInd = visnCertCondInd;
	}
	/**
	 * @return Returns the visnCodeCategory.
	 */
	public String getVisnCodeCategory() {
		return visnCodeCategory;
	}
	/**
	 * @param visnCodeCategory The visnCodeCategory to set.
	 */
	public void setVisnCodeCategory(String visnCodeCategory) {
		this.visnCodeCategory = visnCodeCategory;
	}
	/**
	 * @return Returns the wtxClaimRefNbr.
	 */
	public String getWtxClaimRefNbr() {
		return wtxClaimRefNbr;
	}
	/**
	 * @param wtxClaimRefNbr The wtxClaimRefNbr to set.
	 */
	public void setWtxClaimRefNbr(String wtxClaimRefNbr) {
		this.wtxClaimRefNbr = wtxClaimRefNbr;
	}
	/**
	 * @return Returns the wtxClaimRevNbr.
	 */
	public int getWtxClaimRevNbr() {
		return wtxClaimRevNbr;
	}
	/**
	 * @param wtxClaimRevNbr The wtxClaimRevNbr to set.
	 */
	public void setWtxClaimRevNbr(int wtxClaimRevNbr) {
		this.wtxClaimRevNbr = wtxClaimRevNbr;
	}
	
	/**
	 * @return Returns the dateInd.
	 */
	public String getDateInd() {
		return dateInd;
	}
	/**
	 * @param dateInd The dateInd to set.
	 */
	public void setDateInd(String dateInd) {
		this.dateInd = dateInd;
	}
	
	/**
	 * @return Returns the searchCRDetailClmType.
	 */
	public String getSearchCRDetailClmType() {
		return searchCRDetailClmType;
	}
	/**
	 * @param searchCRDetailClmType The searchCRDetailClmType to set.
	 */
	public void setSearchCRDetailClmType(String searchCRDetailClmType) {
		this.searchCRDetailClmType = searchCRDetailClmType;
	}
	
	/**
	 * @return Returns the searchCRSummaryType.
	 */
	public String getSearchCRSummaryType() {
		return searchCRSummaryType;
	}
	/**
	 * @param searchCRSummaryType The searchCRSummaryType to set.
	 */
	public void setSearchCRSummaryType(String searchCRSummaryType) {
		this.searchCRSummaryType = searchCRSummaryType;
	}
	
	/**
	 * @return Returns the clmType.
	 */
	public String getClmType() {
		return clmType;
	}
	/**
	 * @param clmType The clmType to set.
	 */
	public void setClmType(String clmType) {
		this.clmType = clmType;
	}
	/**
	 * @return the selClaimType
	 */
	public String getSelClaimType() {
		return selClaimType;
	}
	/**
	 * @param selClaimType the selClaimType to set
	 */
	public void setSelClaimType(String selClaimType) {
		this.selClaimType = selClaimType;
	}
	
	/*To add revision number in
	 *  claim number IFOX 367728*/
	/**
	 * @return Returns the wtxClaimRefUniqNbr.
	 */
	public String getWtxClaimRefUniqNbr() {
		
	
		return wtxClaimRefUniqNbr;
	}
	/**
	 * @param wtxClaimRefUniuqNbr The wtxClaimRefUniuqNbr to set.
	 */
	public void setWtxClaimRefUniqNbr(String wtxClaimRefUniqNbr) {
		
		/*To add revision number in	 *  claim number IFOX 367728*/
		if (!( "".equals(wtxClaimRefUniqNbr)) && !(wtxClaimRefUniqNbr == null)){
			setSearchCRDetailClaimRefNbr( wtxClaimRefUniqNbr.substring(0,3)+ "00"+ wtxClaimRefUniqNbr.substring(5));
	
		}/*To add revision number in	 *  claim number IFOX 367728*/
		this.wtxClaimRefUniqNbr = wtxClaimRefUniqNbr;
	}
	/*To add revision number in
	 *  claim number IFOX 367728*/
	
	//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
	public String getSearchVanTanNumber() {
		return searchVanTanNumber;
	}
	public void setSearchVanTanNumber(String searchVanTanNumber) {
		this.searchVanTanNumber = searchVanTanNumber;
	}
		//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
	public boolean isInstConditionCodeExpanded() {
		return instConditionCodeExpanded;
	}
	public void setInstConditionCodeExpanded(boolean instConditionCodeExpanded) {
		this.instConditionCodeExpanded = instConditionCodeExpanded;
	}
	public boolean isInstDiagCodeExpanded() {
		return instDiagCodeExpanded;
	}
	public void setInstDiagCodeExpanded(boolean instDiagCodeExpanded) {
		this.instDiagCodeExpanded = instDiagCodeExpanded;
	}
	
	
	
	boolean isStatusEligibleForUpdate(){
		String[] statusList={"REJ","COR","LV5","CCR","IGN"};
		return Arrays.asList(statusList).contains(processStatus);
		
	}
	public boolean isClaimOtherSubsChanged() {
		return claimOtherSubsChanged;
	}
	public void setClaimOtherSubsChanged(boolean claimOtherSubsChanged) {
		this.claimOtherSubsChanged = claimOtherSubsChanged;
	}
	public String getOthPayrPrimaryId() {
		return othPayrPrimaryId;
	}
	public void setOthPayrPrimaryId(String othPayrPrimaryId) {
		this.othPayrPrimaryId = othPayrPrimaryId;
	}
	public String getClmliAdjudRevenueCd() {
		return clmliAdjudRevenueCd;
	}
	public void setClmliAdjudRevenueCd(String clmliAdjudRevenueCd) {
		this.clmliAdjudRevenueCd = clmliAdjudRevenueCd;
	}
	public String getProdOrSvcidQual() {
		return prodOrSvcidQual;
	}
	public void setProdOrSvcidQual(String prodOrSvcidQual) {
		this.prodOrSvcidQual = prodOrSvcidQual;
	}
	
		
}
