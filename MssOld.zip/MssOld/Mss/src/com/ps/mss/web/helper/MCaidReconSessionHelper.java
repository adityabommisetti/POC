package com.ps.mss.web.helper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.db.SecPlanPersistence;
import com.ps.mss.model.McaidReconContext;
import com.ps.mss.model.McaidReconSessionAttributeVO;

public class MCaidReconSessionHelper {

	//private static ModuleLog log = new ModuleLog("MCaidReconHelper");
	private static Logger logger=LoggerFactory.getLogger(MCaidReconSessionHelper.class);

	public void resetSessionAttibutes(Connection connection, HttpServletRequest request, String groupId) throws SQLException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			HttpSession session  = request.getSession(false);
			McaidReconSessionAttributeVO mcaidReconSessionAttributeVO = new McaidReconSessionAttributeVO();
			mcaidReconSessionAttributeVO.setGroupId(groupId);
			this.getValuesForSessionAttributes(connection, mcaidReconSessionAttributeVO);

			session.setAttribute("Cust_type", mcaidReconSessionAttributeVO.getCustomerType());
		    session.setAttribute("Cust_name", mcaidReconSessionAttributeVO.getCustomerName());
		    session.setAttribute("Cust_nbr", mcaidReconSessionAttributeVO.getCustomerNumber());
			session.setAttribute("recon_cust_nbr", mcaidReconSessionAttributeVO.getCustomerNumber());  
		    session.setAttribute("MF_id", mcaidReconSessionAttributeVO.getMfId());
		    session.setAttribute("Plan_id", nonNullTrim(new SecPlanPersistence().getDefaultPlan(connection, mcaidReconSessionAttributeVO.getCustomerNumber())));
		    session.setAttribute("MMP", mcaidReconSessionAttributeVO.getmStatus());

		} catch (SQLException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(" MCaidReconHelper : resetSessionAttibutes : Error : " + e.getMessage());
//			logger.error(" MCaidReconHelper : resetSessionAttibutes : Error : " + e.getMessage());
			throw e;
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	private void getValuesForSessionAttributes(Connection connection, McaidReconSessionAttributeVO mcaidReconSessionAttributeVO) throws SQLException {
		logger.info(LoggerConstants.methodStartLevel());
		this.getCustomerDetails(connection, mcaidReconSessionAttributeVO);
		this.getCustomerNameAndType(connection, mcaidReconSessionAttributeVO);
		this.getStateMMPDetails(connection, mcaidReconSessionAttributeVO);
		logger.info(LoggerConstants.methodEndLevel());
	}

	private void getCustomerDetails(Connection connection, McaidReconSessionAttributeVO mcaidReconSessionAttributeVO) throws SQLException
	{
		logger.info(LoggerConstants.methodStartLevel());
		StringBuffer buffer = null;
		ResultSet resultSet = null;
		PreparedStatement preparedStatement = null;

		try {
			buffer = new StringBuffer(" SELECT CUST_NBR, MFUSER.MF_ID, MF_PWD FROM SECGROUP JOIN MFUSER ON MFUSER.MF_ID = SECGROUP.MF_ID WHERE GROUP_ID = ? ");
			preparedStatement = connection.prepareStatement(buffer.toString());
			preparedStatement.setString(1, mcaidReconSessionAttributeVO.getGroupId());
			resultSet = preparedStatement.executeQuery();

			if(resultSet.next()) {
				mcaidReconSessionAttributeVO.setCustomerNumber(nonNullTrim(resultSet.getString("CUST_NBR")));
				mcaidReconSessionAttributeVO.setMfId(nonNullTrim(resultSet.getString("MF_ID")));
			}

		} catch (SQLException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(" MCaidReconHelper : getCustomerDetails : " + e.getMessage());
//			logger.error(" MCaidReconHelper : getCustomerDetails : " + e.getMessage());
			throw e;

		} finally {
			if(null != resultSet)
				resultSet.close();
			if(null != preparedStatement)
				preparedStatement.close();
		}		
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	private void getCustomerNameAndType(Connection connection, McaidReconSessionAttributeVO mcaidReconSessionAttributeVO) throws SQLException
	{
		logger.info(LoggerConstants.methodStartLevel());
		StringBuffer buffer = null;
		ResultSet resultSet = null;
		PreparedStatement preparedStatement = null;

		try {
			buffer = new StringBuffer(" SELECT CUST_NAME, CUST_TYPE FROM CUSTOMER WHERE CUST_NBR = ? ");
			preparedStatement = connection.prepareStatement(buffer.toString());
			preparedStatement.setString(1, mcaidReconSessionAttributeVO.getCustomerNumber());
			resultSet = preparedStatement.executeQuery();

			if(resultSet.next()) {
				mcaidReconSessionAttributeVO.setCustomerName(nonNullTrim(resultSet.getString("CUST_NAME")));
				mcaidReconSessionAttributeVO.setCustomerType(nonNullTrim(resultSet.getString("CUST_TYPE")));
			}

		} catch (SQLException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(" MCaidReconHelper : getCustomerNameAndType : " + e.getMessage());
//			logger.error(" MCaidReconHelper : getCustomerNameAndType : " + e.getMessage());
			throw e;

		} finally {
			if(null != resultSet)
				resultSet.close();
			if(null != preparedStatement)
				preparedStatement.close();
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	private void getStateMMPDetails(Connection connection, McaidReconSessionAttributeVO mcaidReconSessionAttributeVO) throws SQLException
	{
		logger.info(LoggerConstants.methodStartLevel());
		StringBuffer buffer = null;
		ResultSet resultSet = null;
		PreparedStatement preparedStatement = null;

		try {
			buffer = new StringBuffer(" SELECT * FROM STATEMMP WHERE MMP_MF_ID = ? ");
			preparedStatement = connection.prepareStatement(buffer.toString());
			preparedStatement.setString(1, mcaidReconSessionAttributeVO.getMfId());
			resultSet = preparedStatement.executeQuery();

	        if (resultSet.next())
	        	mcaidReconSessionAttributeVO.setmStatus("TRUE");
	        else
	        	mcaidReconSessionAttributeVO.setmStatus("FALSE");

		} catch (SQLException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(" MCaidReconHelper : getStateMMPDetails : " + e.getMessage());
//			logger.error(" MCaidReconHelper : getStateMMPDetails : " + e.getMessage());
			throw e;

		} finally {
			if(null != resultSet)
				resultSet.close();
			if(null != preparedStatement)
				preparedStatement.close();
		}	
		logger.info(LoggerConstants.methodEndLevel());
	}
	
    private String nonNullTrim(String s) {
    	logger.info(LoggerConstants.methodStartLevel());
    	if (s == null){
    		logger.info(LoggerConstants.methodEndLevel());
    		return "";
    	}
    	logger.info(LoggerConstants.methodEndLevel());
        return s.trim();
    }
    
    public void resetMedicaidReconObjects(McaidReconContext context) {
    	logger.info(LoggerConstants.methodStartLevel());
    	context.reset();
    	logger.info(LoggerConstants.methodEndLevel());
    }

}
