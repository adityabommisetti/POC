/*
 * $Id: EEMLetterReviewHelper.java,v 1.1 2014/06/26 07:55:03 praveen Exp $
 */
package com.ps.mss.web.helper;

import java.sql.Connection;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.EEMLetterDao;
import com.ps.mss.dao.model.EEMLetterReviewQcVO;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.EEMCodeCache;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.manager.EEMManager;
import com.ps.mss.model.EEMContext;
import com.ps.mss.web.forms.EEMLetterReviewAttachmentForm;
import com.ps.mss.web.forms.EEMLetterReviewDetailForm;
import com.ps.mss.web.forms.EEMLetterReviewQCForm;
import com.ps.text.DateFormatter;
import com.ps.util.StringUtil;

public class EEMLetterReviewHelper {
	private static Logger logger=LoggerFactory.getLogger(EEMLetterReviewHelper.class);
	public static void setFormLists(EEMLetterReviewDetailForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMCodeCache objCache = EEMCodeCache.getInstance();
		form.setArrSearchTypes(objCache.getArrSourceTypes());
		form.setArrSearchStatus(objCache.getArrLetterSearchStatus());
		form.setArrUpdateStatus(objCache.getArrLetterStatus());	
		logger.info(LoggerConstants.methodEndLevel());
	}
	//IFOX-00426356: Attachment CR:start
	public static void setFormLists(EEMLetterReviewAttachmentForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMCodeCache objCache = EEMCodeCache.getInstance();
		form.setArrSearchTypes(objCache.getArrSourceTypes());
		//form.setArrSearchStatus(objCache.getArrLetterSearchStatus());
		//form.setArrUpdateStatus(objCache.getArrLetterStatus());	
		logger.info(LoggerConstants.methodEndLevel());
	}
	//IFOX-00426356: Attachment end
	public static void saveEEMDetailForm(SessionHelper sessionHelper, EEMLetterReviewDetailForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		sessionHelper.setAttribute("SaveEEMLetterReviewDetailForm",form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	public static EEMLetterReviewDetailForm getEEMDetailForm(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (EEMLetterReviewDetailForm)sessionHelper.getAttribute("SaveEEMLetterReviewDetailForm");
	}
	//IFOX-00426356: Attachment CR:start
	public static EEMLetterReviewAttachmentForm getEEMAttachForm(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (EEMLetterReviewAttachmentForm)sessionHelper.getAttribute("SaveEEMLetterReviewAttachmentForm");
	}
	//IFOX-00426356: Attachment CR: end
	public static void clearForm(EEMLetterReviewDetailForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		form.setSearchType("");
		form.setSearchId("");
		form.setSearchReqFromDate("");
		form.setSearchReqFromDate("");
		form.setSearchStatus("");
		form.setSearchBatchId("");
		form.setSearchLetterName("");
		form.setSearchDeleteInd("");
		
		form.setSearchExpanded(false);
		form.setSelectedSearchRow(0);	
		form.setListSearchResults(null);
		form.setDisplayLetterVarData(null);
		logger.info(LoggerConstants.methodEndLevel());
	}
	/*  Begin: Added for Letter Review QC */
	public static void setFormLists(EEMLetterReviewQCForm form, SessionHelper sessionHelper) throws ApplicationException, IllegalArgumentException, SQLException {
		logger.info(LoggerConstants.methodStartLevel());
			EEMLetterDao eemLetterDao = new EEMLetterDao();
			String customerId= sessionHelper.getMfId();
			EEMContext context = EEMManager.getContext(sessionHelper.getSession());
			EEMLetterReviewQcVO letterReviewQCVo = context.getLetterReviewQcVO();
			/*  CustomerId added for SummaCare  -Start */ 
			letterReviewQCVo.setCustomerId(customerId);
			letterReviewQCVo.setSearchBatchId(form.getSearchBatchId());
			/*  CustomerId added for SummaCare  -End */ 
			letterReviewQCVo.setSearchReqFromDate(DateFormatter.reFormat(form.getSearchReqFromDate(),DateFormatter.MM_DD_YYYY,DateFormatter.SQL_TIMESTAMP));
			letterReviewQCVo.setSearchReqToDate(DateFormatter.reFormat(form.getSearchReqToDate(),DateFormatter.MM_DD_YYYY,DateFormatter.SQL_TIMESTAMP));
			//IFOX - 430896 LTr QC CR : start
			letterReviewQCVo.setSearchType(StringUtil.nonNullTrim(form.getSearchType()));
			letterReviewQCVo.setSearchId(StringUtil.nonNullTrim(form.getSearchId()));
			//IFOX - 430896 LTr QC CR : end
			if(form.getSearchReqFromDate()!= null && form.getSearchReqToDate()!=null){
				Connection conn = DbConn.getConnection();
				form.setLstBatchId(eemLetterDao.getLetterReviewQcBatchId(conn, letterReviewQCVo));
				conn.close();
			}
			if(form.getSearchBatchId()!= null){
				Connection conn = DbConn.getConnection();
				/*form.setLstLetterNames(eemLetterDao.getLetterReviewQcDescription(conn, form.getSearchBatchId()));*/
				/*  CustomerId added for SummaCare  -Start */ 
				form.setLstLetterNames(eemLetterDao.getLetterReviewQcDescription(conn, letterReviewQCVo));
				/*  CustomerId added for SummaCare  -End */ 
				
				conn.close();
			}
			logger.info(LoggerConstants.methodEndLevel());
		}
	/*  End: Added for Letter Review QC */
	/*  Begin: Added for Letter Review QC */
	public static void clearQcForm(EEMLetterReviewQCForm form) {
		logger.info(LoggerConstants.methodStartLevel());
			form.setSearchReqFromDate("");
			form.setSearchReqToDate("");
			form.setSearchBatchId("");
			form.setSearchLetterName("");
			
			form.setSearchExpanded(false);
			form.setSelectedSearchRow(0);	
			form.setListSearchResults(null);
			form.setLstBatchId(null);
			form.setLstLetterNames(null);
			logger.info(LoggerConstants.methodEndLevel());
		}
	/*  End: Added for Letter Review QC */
}
