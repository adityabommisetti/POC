/*
 * $Id: HPEFTProcessing.java,v 1.2 2015/11/26 10:10:06 praveen Exp $
 */
package com.ps.mss.web.actions;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.model.HPEFTDailyFileProcessingDO;
import com.ps.mss.dao.model.HPEFTEDPSFileDshbMngtDO;
import com.ps.mss.dao.model.HPEFTFailedFileListDO;
import com.ps.mss.dao.model.HPEFTMonEncDetailsDO;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.HPEConstants;
import com.ps.mss.manager.HPEFTManager;
import com.ps.mss.model.HPEContext;
import com.ps.mss.model.HPEEncounterVO;
import com.ps.mss.model.HPEFileTrackingVO;
import com.ps.mss.web.forms.HPEFileTrackingForm;
import com.ps.mss.web.helper.HPEFileTrackHelper;
import com.ps.mss.web.helper.SessionHelper;

/**
 * This class is invoked for all user actions.
 * 
 * @author bsanthos
 */
public class HPEFTProcessing extends HPEAction {
	/**
	 * logger.
	 */
	private static Logger logger=LoggerFactory.getLogger(HPEFTProcessing.class);

	/**
	 * This method is invoked when user clicks on File Tracking switch tab.
	 * 
	 * @param conn
	 *            Connection
	 * @param sessionHelper
	 *            SessionHelper
	 * @param context
	 *            HPEContext
	 * @param hpeEncounterForm
	 *            HPEFileTrackingForm
	 * @param request
	 *            HttpServletRequest
	 * @return forward String
	 * @throws ApplicationException
	 */
	@SuppressWarnings("unchecked")
	public static String fileTrackSwitchTab(Connection conn, SessionHelper sessionHelper, HPEContext context,
			HPEFileTrackingForm hpeFTForm, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("In HPEFTProcessing : fileTrackSwitchTab() - START");
		boolean sessionFlag = false;

		HPEFTManager hpeftManager = new HPEFTManager();
		String forward = HPEConstants.HPE_ERROR;
		try {

			HPEFileTrackHelper hpeFileTrackHelper = new HPEFileTrackHelper();
			HPEEncounterVO hpeEncounterVO = context.getEncounterVO();
			HPEFileTrackingVO hpeFileTrackingVO = context.getHPEFTSearchVO();
			hpeEncounterVO.setMfId(sessionHelper.getMfId());
			hpeFileTrackingVO.setMfId(hpeEncounterVO.getMfId());
			
			
			
			List<HPEFTEDPSFileDshbMngtDO> dashMngtBySearchCriteriaSessionObject = null;
			Map<HPEFileTrackingForm, List<HPEFTMonEncDetailsDO>> sessionObjectMonEnc = null;
			List<HPEFTDailyFileProcessingDO> sessionObjectDailyFP = null;
			List<HPEFTFailedFileListDO> sessionObjectFailedFileList = null;
			List<HPEFTDailyFileProcessingDO> dashMngtByFilenameSearchSessionObject = null;			
			List<HPEFTDailyFileProcessingDO> dashMngtByFileIdSearchSessionObject = null;
			List<HPEFTDailyFileProcessingDO> claimNumberSearchObject = null;//claim number search
			
			if(hpeFTForm.getRefreshTab()!=null && !hpeFTForm.getRefreshTab().equals("TRUE"))
			{
				 dashMngtBySearchCriteriaSessionObject = (List<HPEFTEDPSFileDshbMngtDO>) sessionHelper.getAttribute("edpsFileDashMngtBySearchCriteria");
				 sessionObjectMonEnc = (Map<HPEFileTrackingForm, List<HPEFTMonEncDetailsDO>>) sessionHelper.getAttribute("searchMonEncDetails");
				 sessionObjectDailyFP = (List<HPEFTDailyFileProcessingDO>) sessionHelper.getAttribute("searchDailyFileProcesing");
				 sessionObjectFailedFileList = (List<HPEFTFailedFileListDO>)sessionHelper.getAttribute("searchFailedFileListDetails");
				 dashMngtByFilenameSearchSessionObject = (List<HPEFTDailyFileProcessingDO>)sessionHelper.getAttribute("edpsFileDashMngtByFileNameSearchCriteria");			
				 dashMngtByFileIdSearchSessionObject = (List<HPEFTDailyFileProcessingDO>)sessionHelper.getAttribute("edpsFileDashMngtByFileIdSearchCriteria");
				 claimNumberSearchObject = (List<HPEFTDailyFileProcessingDO>)sessionHelper.getAttribute("searchDailyFileProcesing");
				
			}
			
			logger.debug("dashMngtBySearchCriteriaSessionObject fileTrackSwitchTab() :"+ dashMngtBySearchCriteriaSessionObject);
			logger.debug("sessionObjectMonEnc fileTrackSwitchTab() :" + sessionObjectMonEnc);
			logger.debug("sessionObjectDailyFP fileTrackSwitchTab() :" + sessionObjectDailyFP);
			logger.debug("sessionObjectFailedFileList fileTrackSwitchTab() :"+ sessionObjectFailedFileList);
			logger.debug("dashMngtByFilenameSearchSessionObject fileTrackSwitchTab() :" + dashMngtByFilenameSearchSessionObject);
			logger.debug("dashMngtByFileIdSessionObject fileTrackSwitchTab() :" + dashMngtByFileIdSearchSessionObject);
			logger.debug("dashMngtByFileIdSessionObject fileTrackSwitchTab() :" + claimNumberSearchObject);//Added to store claim number while traversing
			
			// Get it from Session and set it to Form - Start 
			
			String submitterFromSession = (String)sessionHelper.getAttribute("submitterIdBySearchCriteria");
			
			String sourceidFromSession = (String)sessionHelper.getAttribute("sourceIdBySearchCriteria");
			
			String encTypeFromSession = (String)sessionHelper.getAttribute("encTypeBySearchCriteria");
			
			String fromDateFromSession = (String)sessionHelper.getAttribute("fromDateBySearchCriteria");
			
			String toDateFromSession = (String)sessionHelper.getAttribute("toDateBySearchCriteria");
			
			String lineOfBusinessFromSession = (String)sessionHelper.getAttribute("lineOfBusinessBySearchCriteria");
			
			String typeOfBusinessFromSession = (String)sessionHelper.getAttribute("typeOfBusinessBySearchCriteria");
			
			String spltFleStatusFromSession = (String)sessionHelper.getAttribute("spltFleStatusTempSearchMonEncDetails");
			
			String fileDsbMgmtHLFromSession = (String)sessionHelper.getAttribute("fileDsbMgmtHLSearchMonEncDetails"); 
			
			String moEncDetHL = (String)sessionHelper.getAttribute("moEncDetHLSearchDailyFP");
			
			String dailyDetHL = (String)sessionHelper.getAttribute("dailyDetHLSearchDailyFP");
			
			String searchBy = (String)sessionHelper.getAttribute("checkboxSelected");
			
			String claimRefNo = (String)sessionHelper.getAttribute("claimNumber");
			String formSearch = null;
			
			if(dashMngtBySearchCriteriaSessionObject==null && sessionObjectMonEnc==null && sessionObjectDailyFP==null && sessionObjectFailedFileList==null && dashMngtByFilenameSearchSessionObject==null && dashMngtByFileIdSearchSessionObject==null && claimNumberSearchObject==null){
				formSearch=hpeFTForm.getFormSearch();
			}else{
				formSearch=request.getParameter("formSearch");
			}

			// File name search values in session 
			String fileNameByFileNameSearchCriteria = (String)sessionHelper.getAttribute("fileNameByFileNameSearchCriteria");
			String submitterIdByFileNameSearchCriteria = (String)sessionHelper.getAttribute("submitterIdByFileNameSearchCriteria");
			String encTypeByFileNameSearchCriteria = (String)sessionHelper.getAttribute("encTypeByFileNameSearchCriteria");
			
			// File ID search values in session 
			String submitterIdByFileIdSearchCriteria = (String) sessionHelper.getAttribute("submitterIdByFileIdSearchCriteria");
			String origIntrchgNbrByFileIdSearchCriteria = (String)sessionHelper.getAttribute("origIntrchgNbrByFileIdSearchCriteria");
			String encTypeByFileIdSearchCriteria = (String)sessionHelper.getAttribute("encTypeByFileIdSearchCriteria");
			
			//Claim Number Search
			String submitterId = (String)sessionHelper.getAttribute("submitterIdSearchDailyFP");
			String claimType = (String)sessionHelper.getAttribute("searchClaimType");
			String claimNumber = (String)sessionHelper.getAttribute("searchClmRefNbr");
			
			// FailedFile values from session - start 
			String submitterIdFailedFileSession = (String)sessionHelper.getAttribute("submitterIdFailedFileSession");
			String dateYearMonthFailedSession = (String)sessionHelper.getAttribute("dateYearMonthFailedSession"); 
			String sourceIdFailedSession = (String)sessionHelper.getAttribute("sourceIdFailedSession");
			String fileDsbMgmtHLFailedSession = (String)sessionHelper.getAttribute("fileDsbMgmtHLFailedSession");
			String encTypeFailedSession = (String)sessionHelper.getAttribute("encTypeFailedSession");
			String spltFleStatusTempFailedSession = (String)sessionHelper.getAttribute("spltFleStatusTempFailedSession");
			// FailedFile values from session - end
			
			if(dashMngtBySearchCriteriaSessionObject !=null && dashMngtBySearchCriteriaSessionObject.size() > 0) {
				sessionFlag = true;
				logger.debug("session object is available in HPEFtProcessing.fileTrackSwitchTab() for edpsFileDashMngtBySearchCriteria().");
				List<HPEFTEDPSFileDshbMngtDO> temp = new ArrayList<HPEFTEDPSFileDshbMngtDO>();
				
				if(!dashMngtBySearchCriteriaSessionObject.isEmpty()) {
					temp = hpeFileTrackHelper.copySearchToDisplay(dashMngtBySearchCriteriaSessionObject);
				} 
				
				hpeFTForm.setSec1uiLst(temp);
				hpeFileTrackingVO.setSec1uiLst(temp);
				
				sessionHelper.setAttribute("edpsFileDashMngtByFileNameSearchCriteria", new ArrayList<HPEFTDailyFileProcessingDO>());
				dashMngtByFilenameSearchSessionObject = null;
				
				logger.debug("formSearch is :"+ formSearch);
				
				if(formSearch == null || !formSearch.equals("TRUE")) {
					if(submitterFromSession !=null ) {
						hpeFTForm.setSearchSubmitterId(submitterFromSession);
					}
					if(sourceidFromSession !=null ) {
						hpeFTForm.setSourceId(sourceidFromSession);
					}
					
					if(encTypeFromSession !=null ) {
						hpeFTForm.setSearchSummaryType(encTypeFromSession);
					}
					if(fromDateFromSession !=null ) {
						hpeFTForm.setSearchFromDate(fromDateFromSession);
					}
					if(toDateFromSession !=null ) {
						hpeFTForm.setSearchToDate(toDateFromSession);
					}
					if(lineOfBusinessFromSession !=null ) {
						hpeFTForm.setLineOfbusiness(lineOfBusinessFromSession);
					}
					if(typeOfBusinessFromSession !=null ) {
						hpeFTForm.setTypeOfBusiness(typeOfBusinessFromSession);
					}
					if(fileDsbMgmtHLFromSession != null) {
						hpeFTForm.setFileDsbMgmtHL(fileDsbMgmtHLFromSession);
					}
					if(moEncDetHL != null) {
						hpeFTForm.setMoEncDetHL(moEncDetHL);
					}
					if(dailyDetHL != null) {
						hpeFTForm.setDailyDetHL(dailyDetHL);
					}
					if(spltFleStatusFromSession != null) {
						String statusValue = null;
						if ("I".equals(spltFleStatusFromSession)) {
							statusValue = Integer.toString(20);
						} else if ("C".equals(spltFleStatusFromSession)) {
							statusValue = Integer.toString(10);
						} else {
							statusValue = Integer.toString(30);
						}
						hpeFTForm.setSplitFileStatus(statusValue); 
					}
				}
			}
			
			if(dashMngtByFilenameSearchSessionObject != null && dashMngtByFilenameSearchSessionObject.size() > 0) {
				sessionFlag = true;
				List<HPEFTDailyFileProcessingDO> temp = hpeFileTrackHelper.copySearchToDailyFileProcessingDisplay(dashMngtByFilenameSearchSessionObject);
				
				hpeFTForm.setDailyFileProcessingLst(temp);
				hpeFileTrackingVO.setDailyFileProcessingLst(temp);
				hpeFTForm.setDailyAcceptedFileProcessingLst(temp);
				hpeFileTrackingVO.setDailyAcceptedFileProcessingLst(temp);
				
				hpeFTForm.setFileNameSeachSession("");
				
				if(formSearch == null || !formSearch.equals("TRUE")) {

					if(submitterIdByFileNameSearchCriteria != null) {
						hpeFTForm.setSearchSubmitterId(submitterIdByFileNameSearchCriteria);
					}
					if(fileNameByFileNameSearchCriteria != null) {
						hpeFTForm.setSearchText(fileNameByFileNameSearchCriteria);
					}
					if(encTypeByFileNameSearchCriteria !=null ) {
						hpeFTForm.setSearchSummaryType(encTypeByFileNameSearchCriteria);
					}
					if(dailyDetHL != null){
						hpeFTForm.setDailyDetHL(dailyDetHL);
					}
					if(searchBy != null){
						hpeFTForm.setSearchBy(searchBy);
					}
					
					hpeFTForm.setFileNameSeachSession("fileNameSearch");
				}
				
			}
			
			if(dashMngtByFileIdSearchSessionObject != null && dashMngtByFileIdSearchSessionObject.size() > 0) {
				sessionFlag = true;
				List<HPEFTDailyFileProcessingDO> temp = hpeFileTrackHelper.copySearchToDailyFileProcessingDisplay(dashMngtByFileIdSearchSessionObject);
				hpeFTForm.setDailyFileProcessingLst(temp);
				hpeFileTrackingVO.setDailyFileProcessingLst(temp);
				hpeFTForm.setDailyAcceptedFileProcessingLst(temp);
				hpeFileTrackingVO.setDailyAcceptedFileProcessingLst(temp);
				
				hpeFTForm.setFileNameSeachSession("");
				
				if(formSearch == null || !formSearch.equals("TRUE")) {

					if(submitterIdByFileIdSearchCriteria != null) {
						hpeFTForm.setSearchSubmitterId(submitterIdByFileIdSearchCriteria);
					}
					if(origIntrchgNbrByFileIdSearchCriteria != null) {
						hpeFTForm.setSearchText(origIntrchgNbrByFileIdSearchCriteria);
					}
					if(encTypeByFileIdSearchCriteria !=null ) {
						hpeFTForm.setSearchSummaryType(encTypeByFileIdSearchCriteria);
					}
					if(dailyDetHL != null){
						hpeFTForm.setDailyDetHL(dailyDetHL);
					}
					if(searchBy != null){
						hpeFTForm.setSearchBy(searchBy);
					}
					
					hpeFTForm.setFileNameSeachSession("fileNameSearch");
				}
			}
				//Claim Number Search
				if(claimNumberSearchObject != null && claimNumberSearchObject.size() > 0) {
					sessionFlag = true;
					List<HPEFTDailyFileProcessingDO> temp = hpeFileTrackHelper.copySearchToDailyFileProcessingDisplay(claimNumberSearchObject);
					hpeFTForm.setDailyFileProcessingLst(temp);
					hpeFileTrackingVO.setDailyFileProcessingLst(temp);
					hpeFTForm.setDailyAcceptedFileProcessingLst(temp);
					hpeFileTrackingVO.setDailyAcceptedFileProcessingLst(temp);
					
					hpeFTForm.setFileNameSeachSession("");
				if(formSearch == null || !formSearch.equals("TRUE")) {

					if(submitterId != null) {
						hpeFTForm.setSearchSubmitterId(submitterId);
					}
					if(claimType != null) {
						hpeFTForm.setSearchClaimType(claimType);
					}
					if(claimNumber !=null ) {
						hpeFTForm.setSelectedClaimRefNbr(claimNumber);
					}
					if(dailyDetHL != null){
						hpeFTForm.setDailyDetHL(dailyDetHL);
					}
					if(claimRefNo != null){
						hpeFTForm.setSearchClmRefNbr(claimRefNo);
					}
					
					
					hpeFTForm.setFileNameSeachSession("fileNameSearch");
				}
			}
			
			if(sessionObjectMonEnc !=null ) { 
				sessionFlag = true;
				Map.Entry<HPEFileTrackingForm, List<HPEFTMonEncDetailsDO>> entry = sessionObjectMonEnc.entrySet().iterator().next();
				
				HPEFileTrackingForm sessionFormkey = entry.getKey();
				List<HPEFTMonEncDetailsDO> sessionMonEncDetail = entry.getValue();
								
				List<HPEFTMonEncDetailsDO> temp = hpeFileTrackHelper.copySearchToMonEncDetailsDisplay(sessionMonEncDetail,
						sessionFormkey);
				hpeFTForm.setMonEncDetailsLst(temp);
				hpeFileTrackingVO.setMonEncDetailsLst(temp);
				
			}
			
			if(sessionObjectDailyFP != null) {
				sessionFlag = true;
				hpeFTForm.setDailyFileProcessingLst(sessionObjectDailyFP);
				hpeFileTrackingVO.setDailyFileProcessingLst(sessionObjectDailyFP);
				hpeFTForm.setDailyAcceptedFileProcessingLst(sessionObjectDailyFP);
				hpeFileTrackingVO.setDailyAcceptedFileProcessingLst(sessionObjectDailyFP);
				
			}
			if(sessionObjectFailedFileList != null) {
				sessionFlag = true;
				List<HPEFTFailedFileListDO> temp = hpeFileTrackHelper.copySearchToFailedFileListDisplay(sessionObjectFailedFileList);
				
				hpeFTForm.setFailedFileLst(temp);
				hpeFileTrackingVO.setFailedFileLst(temp);
				
			}
			
			
			if((formSearch != null && formSearch.equals("TRUE")) ||( sessionFlag == false)) {
				hpeftManager.fileTrackSwitchTab(conn, context, sessionHelper, hpeFTForm, hpeFileTrackingVO);
				logger.error("No session object.");
			}
			
			forward = HPEConstants.HPE_FILETRACKTREE;

		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//logger.error(e.getMessage());
			throw new ApplicationException(e);
		}

		logger.debug("In HPEFTProcessing : fileTrackSwitchTab() - END");
		logger.info(LoggerConstants.methodEndLevel());
		return forward;
	}

	/**
	 * This method is invoked each time when user selects on Go button, any
	 * valid field in from "EDPS File Dash board Management" or
	 * "Monthly Encounter Details" section.
	 * 
	 * @param conn
	 *            Connection
	 * @param sessionHelper
	 *            SessionHelper
	 * @param context
	 *            HPEContext
	 * @param hpeEncounterForm
	 *            HPEFileTrackingForm
	 * @param request
	 *            HttpServletRequest
	 * @return forward String
	 * @throws ApplicationException
	 */
	public static String fileTrackSearch(Connection conn, SessionHelper sessionHelper, HPEContext context,
			HPEFileTrackingForm hpeFTForm, HttpServletRequest request) throws ApplicationException {
		logger.debug("In HPEFileAction : fileTrackSearch() - START");
		String forward = HPEConstants.HPE_ERROR;
		HPEFTManager hpeftManager = new HPEFTManager();

		try {
			// Get the VO
			HPEFileTrackingVO hpeFTVO = context.getHPEFTSearchVO();

			// Set customer

			if (hpeFTForm.getMethodName().equals("hpeftMonEncDetails")) {
				searchFileTrackByFileDshbMngt(conn, sessionHelper, context, hpeFTForm, request);
				hpeFTForm.setMethodName(null);
			} else if (hpeFTForm.getMethodName().equals("hpeftDailyFileProcessing")) {
				searchFileTrackByMonEncDetails(conn, sessionHelper, context, hpeFTForm, request);
				hpeFTForm.setMethodName(null);
			} else if (hpeFTForm.getMethodName().equals("failedFileLst")) {
				searchFailedFileTrackByFileDshbMngt(conn, sessionHelper, context, hpeFTForm, request);
				hpeFTForm.setMethodName(null);
			} else {
				hpeFTForm.setMethodName(null);
				hpeFTVO.setMfId(sessionHelper.getMfId());
				if (hpeFTForm.getSearchText() != null && hpeFTForm.getSearchText().length() > 0) {
					if (HPEConstants.FILETRACK_SEARCH_BY_FILEID.equalsIgnoreCase(hpeFTForm.getSearchBy())) {
						hpeFTForm.setOrig_intrchg_ctrl_nbr(getFormattedFileId(hpeFTForm.getSearchText()));
						context.getHpeftSearchVO().setSearchBy(HPEConstants.FILETRACK_SEARCH_BY_FILEID);
					} else {
						hpeFTForm.setFileName(hpeFTForm.getSearchText());
						context.getHpeftSearchVO().setSearchBy(HPEConstants.FILETRACK_SEARCH_BY_FILENAME);
					}
				}
				if (!hpeFTForm.getFileName().equals("")) {
					request.removeAttribute(HPEConstants.SESSION_VAR_SEARCH_BY_ID_OR_NAME);
					request.setAttribute(HPEConstants.SESSION_VAR_SEARCH_BY_ID_OR_NAME, "TRUE");
					hpeftManager.edpsFileDashMngtByFileNameSearchCriteria(conn, context, hpeFTForm, hpeFTVO, sessionHelper, request);
					request.setAttribute(HPEConstants.FILETRACK_EXPORT_BUTTON_VISIBILITY, "TRUE");
					
				} else if (!hpeFTForm.getOrig_intrchg_ctrl_nbr().equals("")) {
					request.removeAttribute(HPEConstants.SESSION_VAR_SEARCH_BY_ID_OR_NAME);
					request.setAttribute(HPEConstants.SESSION_VAR_SEARCH_BY_ID_OR_NAME, "TRUE");
					hpeftManager.edpsFileDashMngtByFileIdSearchCriteria(conn, context, hpeFTForm, hpeFTVO, sessionHelper, request);
					request.setAttribute(HPEConstants.FILETRACK_EXPORT_BUTTON_VISIBILITY, "TRUE");
				} else {
					
						    if(!hpeFTForm.getSearchClaimType().equals("N") && !hpeFTForm.getSearchClmRefNbr().equals("")){
					    	    request.removeAttribute(HPEConstants.SESSION_VAR_SEARCH_BY_ID_OR_NAME);
					    	    request.setAttribute(HPEConstants.SESSION_VAR_SEARCH_BY_ID_OR_NAME, "TRUE");
					    	    hpeftManager.searchClaimTypeClaimNbrMethod(conn, context, hpeFTForm, hpeFTVO, sessionHelper, request);
					    	    request.setAttribute(HPEConstants.FILETRACK_EXPORT_BUTTON_VISIBILITY, "TRUE");
				    	  
				           }else{	
				
			        	      hpeftManager.edpsFileDashMngtBySearchCriteria(conn, context, sessionHelper,  hpeFTForm, hpeFTVO, request);
			                }
					
					// clearing search fields
					//hpeFTForm.setSearchFromDate("");
					//hpeFTForm.setSearchToDate("");
					//hpeFTForm.setSourceId("");
					
				}
				// forward = HPEConstants.HPE_FILETRACKTREE;
			}

			forward = HPEConstants.HPE_FILETRACKTREE;

		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new ApplicationException(e);
		}

		return forward;
	}

	private static String getFormattedFileId(String searchText) {
		if (searchText != null) {
			return StringUtils.leftPad(searchText, 9, "0");
		}
		return searchText;
	}

	/**
	 * This method is used to fetch "Monthly Encounter Details" section.
	 * 
	 * @param conn
	 *            Connection
	 * @param sessionHelper
	 *            SessionHelper
	 * @param context
	 *            HPEContext
	 * @param hpeftSearchForm
	 *            HPEFileTrackingForm
	 * @param request
	 *            HttpServletRequest
	 * @return forward String
	 * @throws ApplicationException
	 */
	public static String searchFileTrackByFileDshbMngt(Connection conn, SessionHelper sessionHelper, HPEContext context,
			HPEFileTrackingForm hpeFTForm, HttpServletRequest request) throws ApplicationException {

		logger.debug("HPEFTProcessing.searchFileTrackByFileDshbMngt()-START");
		HPEFileTrackingVO hpeftVo = context.getHPEFTSearchVO();
		HPEFTManager hpeFTManager = new HPEFTManager();
		String forward = HPEConstants.HPE_ERROR;
		hpeftVo.setMfId(sessionHelper.getMfId());
		
		hpeFTManager.searchMonEncDetails(conn, context, hpeFTForm, hpeftVo, sessionHelper, request);
		forward = HPEConstants.HPE_FILETRACKTREE;
		logger.debug("HPEFTProcessing.searchFileTrackByFileDshbMngt()-END");

		return forward;
	}

	/**
	 * This method is used to fetch "Daily File Processing section" from "
	 * Monthly Encounter Details" section.
	 * 
	 * @param conn
	 *            Connection
	 * @param sessionHelper
	 *            SessionHelper
	 * @param context
	 *            HPEContext
	 * @param hpeftSearchForm
	 *            HPEFileTrackingForm
	 * @param request
	 *            HttpServletRequest
	 * @return forward String
	 * @throws ApplicationException
	 */
	public static String searchFileTrackByMonEncDetails(Connection conn, SessionHelper sessionHelper,
			HPEContext context, HPEFileTrackingForm hpeftForm, HttpServletRequest request) throws ApplicationException {
		logger.debug("HPEFTProcessing.searchFileTrackByMonEncDetails()-START");

		HPEFileTrackingVO hpeftVO = context.getHPEFTSearchVO();
		HPEFTManager hpeFTManager = new HPEFTManager();
		String forward = HPEConstants.HPE_ERROR;
		hpeftVO.setMfId(sessionHelper.getMfId());
		hpeFTManager.searchDailyFileProcesing(conn, context, sessionHelper, hpeftForm, hpeftVO, request);
		forward = HPEConstants.HPE_FILETRACKTREE;

		logger.debug("HPEFTProcessing.searchFileTrackByMonEncDetails()-END");

		return forward;
	}

	/**
	 * This method is invoked when user selects Failed column from
	 * "EDPS File Dash board Management" section.
	 * 
	 * @param conn
	 *            Connection
	 * @param sessionHelper
	 *            SessionHelper
	 * @param context
	 *            HPEContext
	 * @param hpeftSearchForm
	 *            HPEFileTrackingForm
	 * @param request
	 *            HttpServletRequest request)
	 * @return forward String
	 * @throws ApplicationException
	 */
	public static String searchFailedFileTrackByFileDshbMngt(Connection conn, SessionHelper sessionHelper,
			HPEContext context, HPEFileTrackingForm hpeftForm, HttpServletRequest request) throws ApplicationException {
		logger.debug("HPEFTProcessing.searchFailedFileTrackByFileDshbMngt()-START");
		// Get the VO
		HPEFileTrackingVO hpeftVO = context.getHPEFTSearchVO();
		HPEFTManager hpeFTManager = new HPEFTManager();
		String forward = HPEConstants.HPE_ERROR;
		// Set customer
		hpeftVO.setMfId(sessionHelper.getMfId());
		hpeFTManager.searchFailedFileListDetails(conn, context, hpeftForm, hpeftVO, sessionHelper);
		forward = HPEConstants.HPE_FILETRACKTREE;
		logger.debug("HPEFTProcessing.searchFailedFileTrackByFileDshbMngt()-END");
		return forward;
	}
	
	public static String exportFileNames(Connection conn, SessionHelper sessionHelper, HPEContext context,
			HPEFileTrackingForm hpeFTForm, HttpServletRequest request, HttpServletResponse response) throws ApplicationException {

		logger.debug("HPEFTProcessing.exportFileNames()-START");
		String csv = null;
		HPEFileTrackingVO hpeftVo = context.getHPEFTSearchVO();
		HPEFTManager hpeFTManager = new HPEFTManager();
		hpeftVo.setMfId(sessionHelper.getMfId());
		
		csv = hpeFTManager.exportFileNames(conn, context, hpeFTForm, hpeftVo, response);
		logger.debug("HPEFTProcessing.exportFileNames()-END");

		return csv;
	}
	
	//This method is added to export dashboard files to csv
	public static String exportFileDashBoardList(Connection conn, SessionHelper sessionHelper, HPEContext context,
			HPEFileTrackingForm hpeFTForm, HttpServletRequest request, HttpServletResponse response) throws ApplicationException {

		logger.debug("HPEFTProcessing.exportFileNames()-START");
		String csv = null;
		HPEFileTrackingVO hpeftVo = context.getHPEFTSearchVO();
		HPEFTManager hpeFTManager = new HPEFTManager();
		hpeftVo.setMfId(sessionHelper.getMfId());
		
		csv = hpeFTManager.exportFileDashBoardNames(conn, context, hpeFTForm, hpeftVo, response);
		logger.debug("HPEFTProcessing.exportFileNames()-END");

		return csv;
	}
	
	
	public static String updateRemarkSection(Connection conn, SessionHelper sessionHelper, HPEContext context,
			HPEFileTrackingForm hpeFTForm, HttpServletRequest request, HttpServletResponse response) throws ApplicationException {


		logger.debug("HPEFTProcessing.UpdateRemarkSection()-START");
		String csv = null;
		HPEFileTrackingVO hpeftVo = context.getHPEFTSearchVO();
		HPEFTManager hpeFTManager = new HPEFTManager();
		hpeftVo.setMfId(sessionHelper.getMfId());
		
		csv = hpeFTManager.updateRemarkSectionManger(conn, context, hpeFTForm, hpeftVo, response);
		logger.debug("HPEFTProcessing.UpdateRemarkSection()-END");

		return csv;
	}
	
	
	public static String retrieveRemarkSection(Connection conn, SessionHelper sessionHelper, HPEContext context,
			HPEFileTrackingForm hpeFTForm, HttpServletRequest request, HttpServletResponse response) throws ApplicationException {

		logger.debug("HPEFTProcessing.UpdateRemarkSection()-START");
		String csv = null;
		HPEFileTrackingVO hpeftVo = context.getHPEFTSearchVO();
		HPEFTManager hpeFTManager = new HPEFTManager();
		hpeftVo.setMfId(sessionHelper.getMfId());
		
		csv = hpeFTManager.retrieveRemarkSectionManger(conn, context, hpeFTForm, hpeftVo, response);
		logger.debug("HPEFTProcessing.UpdateRemarkSection()-END");

		return csv;
	}


}
