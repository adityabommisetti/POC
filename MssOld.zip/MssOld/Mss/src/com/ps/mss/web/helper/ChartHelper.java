package com.ps.mss.web.helper;

import java.io.FileInputStream;
import java.sql.Connection;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession; /*To add revision number in  claim number IFOX 367728*/

import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.ChartEncounterService;
import com.ps.mss.dao.model.Enc837ChangeClaimlogVOs;
import com.ps.mss.dao.model.Enc837iBillprvVO;
import com.ps.mss.dao.model.Enc837iClmProviderVO;
import com.ps.mss.dao.model.Enc837iClmProviderVOs;
import com.ps.mss.dao.model.Enc837iClmVO;
import com.ps.mss.dao.model.Enc837iClmVOs;
import com.ps.mss.dao.model.Enc837iSubsVO;
import com.ps.mss.dao.model.Enc837pBillprvVO;
import com.ps.mss.dao.model.Enc837pClmProviderVO;
import com.ps.mss.dao.model.Enc837pClmProviderVOs;
import com.ps.mss.dao.model.Enc837pSubsVO;
import com.ps.mss.dao.model.EncErrorstatSumVO;
import com.ps.mss.dao.model.EncErrorstatSumVOs;
import com.ps.mss.dao.model.HpeSearchVO;

import com.ps.mss.dao.model.Enc837pClmVO;
import com.ps.mss.dao.model.Enc837pClmVOs;

import com.ps.mss.dao.model.EncCmstatSumVO;
import com.ps.mss.dao.model.EncCmstatSumVOs;
import com.ps.mss.db.ENCCodeCache;

import com.ps.mss.exception.ApplicationException;

import com.ps.mss.framework.ChartConstants;
import com.ps.mss.framework.Constants;
import com.ps.mss.framework.HPEConstants;
import com.ps.mss.model.HPEContext;
import com.ps.mss.model.HPEEncounterVO;
import com.ps.mss.model.Pagination;

import com.ps.mss.web.forms.ChartEncounterForm;

import com.ps.text.DateFormatter;
import com.ps.text.DemographicFormatter;
import com.ps.util.GridUtil;
import com.ps.util.StringUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

/**
 * @author DParker
 */
public class ChartHelper {
	private static Properties prop;
	private static Logger logger=LoggerFactory.getLogger(ChartHelper.class);
	public static String getProperty(String sKey)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String sValue = null;
		try {
			if (prop == null) {
				prop = new Properties();
				prop.load(new FileInputStream("HPEProperties.properties"));
			}
			sValue = prop.getProperty(sKey);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return sValue;
	}

	public static void buildStatusSummary(Connection conn, SessionHelper sessionHelper, HPEContext context, ChartEncounterForm chartEncounterForm, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getChartEncounterVO();

			// Set customer
			encounterVO.setMfId(/* "HCFLCS4" */ sessionHelper.getMfId() /* "HCF0031" */);
			
			HpeSearchVO searchVO = null;			
			
			searchVO = (HpeSearchVO)sessionHelper.getAttribute(ChartConstants.SEARCH_CR_DASH_VO);
						
			if(searchVO != null){				
				chartEncounterForm.setSearchCRSummarySubmitterId((searchVO.getSubmitterId()));
				chartEncounterForm.setSearchCRSummaryType(searchVO.getClmType());
				chartEncounterForm.setSearchCRSummaryDateInd((searchVO.getDateInd()));				
				chartEncounterForm.setSearchCRSummaryFromDate(searchVO.getFromDate());				
				chartEncounterForm.setSearchCRSummaryToDate(searchVO.getToDate());	
				chartEncounterForm.setSelClaimType(searchVO.getClmType());
			} else {
				searchVO = (HpeSearchVO)sessionHelper.getAttribute(ChartConstants.DEFAULT_CR_SEARCH_VO);			
				
				if(searchVO != null){				
					chartEncounterForm.setSearchCRSummarySubmitterId((searchVO.getSubmitterId()));	
					chartEncounterForm.setSearchCRSummaryType(searchVO.getClmType());
					chartEncounterForm.setSearchCRSummaryDateInd((searchVO.getDateInd()));				
					chartEncounterForm.setSearchCRSummaryFromDate(searchVO.getFromDate());				
					chartEncounterForm.setSearchCRSummaryToDate(searchVO.getToDate());		
					chartEncounterForm.setSelClaimType(searchVO.getClmType());
				}
			}
			
			searchVO = (HpeSearchVO)sessionHelper.getAttribute(ChartConstants.SEARCH_CR_BACK_VO);
			if(searchVO != null){
				chartEncounterForm.setPrevMenu(searchVO.getPrevMenu());
				chartEncounterForm.setPrevMethod(searchVO.getPrevMethod());				
			}

			// Copy the search criteria to the VO
			encounterVO.setSearchSummarySubmitterId((chartEncounterForm.getSearchCRSummarySubmitterId()));
			encounterVO.setSearchSummaryClmType((chartEncounterForm.getSearchCRSummaryType()));
			encounterVO.setSearchSummaryDateInd((chartEncounterForm.getSearchCRSummaryDateInd()));
			encounterVO.setSearchSummaryFromDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRSummaryFromDate(), DateFormatter.MM_YYYY, DateFormatter.YYYYMM));
			encounterVO.setSearchSummaryToDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRSummaryToDate(), DateFormatter.MM_YYYY, DateFormatter.YYYYMM));

			// Search
			context.getChartEncounterService().searchStatusSummaryByDateRange(conn, encounterVO);

			// Refresh
			//
			EncCmstatSumVOs searchSummaryResults = encounterVO.getSearchSummaryResults();

			// Sort the summary details according to the form's grid layout
			ENCCodeCache cc = ENCCodeCache.getInstance();
			HashMap codes = cc.getHmENCDashboardStatusIndex();

			GridUtil statusSummaryGrid = new GridUtil();
			GridUtil.Year year = null;
			GridUtil.Month month = null;
			GridUtil.Totals grandTotals = null;
			GridUtil.Totals yearTotals = null;
			GridUtil.Totals monthTotals = null;
			
			Iterator iterator = searchSummaryResults.iterator();
			while (iterator.hasNext()) {
				EncCmstatSumVO encCmstatSumVO = (EncCmstatSumVO) iterator.next();
				Integer tempYear = Integer.valueOf(encCmstatSumVO.getDateYrmo().substring(0, 4));
				Integer tempMonth = Integer.valueOf(encCmstatSumVO.getDateYrmo().substring(4, 6));
				int encounters = encCmstatSumVO.getEncCount();
				if ((year == null) || (!year.getYear().equals(tempYear))) {
					year = statusSummaryGrid.getYears().addYear(tempYear);
					month = year.getMonths().addMonth(tempMonth);
				}
				if (!month.getMonth().equals(tempMonth)) {
					month = year.getMonths().addMonth(tempMonth);
				}

				if (encCmstatSumVO.getEncType().equals("I")) {
					grandTotals = statusSummaryGrid.getInstTotals();
					yearTotals = year.getInstTotals();
					monthTotals = month.getInstTotals();
				}
				if (encCmstatSumVO.getEncType().equals("P")) {
					grandTotals = statusSummaryGrid.getProfTotals();
					yearTotals = year.getProfTotals();
					monthTotals = month.getProfTotals();
				}
				//DME_Dashboard_changes
				if (encCmstatSumVO.getEncType().equals("E")) {
					grandTotals = statusSummaryGrid.getDmeTotals();
					yearTotals = year.getDmeTotals();
					monthTotals = month.getDmeTotals();
				}
				String group = (String)codes.get(encCmstatSumVO.getProcessStatus());
				if ("PEN".equals(group)) {
					grandTotals.setPending(grandTotals.getPending() + encounters);
					yearTotals.setPending(yearTotals.getPending() + encounters);
					monthTotals.setPending(monthTotals.getPending() + encounters);					
				}
				else
				if ("ACC".equals(group)) {
					grandTotals.setAccepted(grandTotals.getAccepted() + encounters);
					yearTotals.setAccepted(yearTotals.getAccepted() + encounters);
					monthTotals.setAccepted(monthTotals.getAccepted() + encounters);					
				}
				else
				if ("FAL".equals(group)) {
					grandTotals.setRejected(grandTotals.getRejected() + encounters);
					yearTotals.setRejected(yearTotals.getRejected() + encounters);
					monthTotals.setRejected(monthTotals.getRejected() + encounters);						
				}
				else
				if ("IGN".equals(group)) {
					grandTotals.setIgnored(grandTotals.getIgnored() + encounters);
					yearTotals.setIgnored(yearTotals.getIgnored() + encounters);
					monthTotals.setIgnored(monthTotals.getIgnored() + encounters);
				}
				grandTotals.setTotal(grandTotals.getTotal() + encounters);
				yearTotals.setTotal(yearTotals.getTotal() + encounters);
				monthTotals.setTotal(monthTotals.getTotal() + encounters);
			}

			// Store search results in the form
			chartEncounterForm.setStatusSummaryGrid(statusSummaryGrid);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void buildErrorStatusSummary(Connection conn, SessionHelper sessionHelper, HPEContext context, ChartEncounterForm chartEncounterForm, HttpServletRequest request)
	throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getChartEncounterVO();

			// Set customer
			encounterVO.setMfId(/* "HCFLCS4" */ sessionHelper.getMfId() /* "HCF0031" */);	
			HpeSearchVO searchVO = null;			
			
			searchVO = (HpeSearchVO)sessionHelper.getAttribute(ChartConstants.SEARCH_CR_REJECT_VO);			
			
			if(searchVO != null){				
				chartEncounterForm.setSearchCRSummarySubmitterId((searchVO.getSubmitterId()));		
				chartEncounterForm.setSearchCRSummaryType((searchVO.getClmType()));
				chartEncounterForm.setSearchCRSummaryDateInd((searchVO.getDateInd()));				
				chartEncounterForm.setSearchCRSummaryFromDate(searchVO.getFromDate());				
				chartEncounterForm.setSearchCRSummaryToDate(searchVO.getToDate());		
				chartEncounterForm.setSelClaimType(searchVO.getClmType());
			} else {
				searchVO = (HpeSearchVO)sessionHelper.getAttribute(ChartConstants.DEFAULT_CR_SEARCH_VO);
				if(searchVO != null){				
					chartEncounterForm.setSearchCRSummarySubmitterId((searchVO.getSubmitterId()));	
					chartEncounterForm.setSearchCRSummaryType((searchVO.getClmType()));
					chartEncounterForm.setSearchCRSummaryDateInd((searchVO.getDateInd()));				
					chartEncounterForm.setSearchCRSummaryFromDate(searchVO.getFromDate());				
					chartEncounterForm.setSearchCRSummaryToDate(searchVO.getToDate());	
					chartEncounterForm.setSelClaimType(searchVO.getClmType());
				}	
			}			
			
			//Copy the search criteria to the VO
			encounterVO.setSearchSummarySubmitterId((chartEncounterForm.getSearchCRSummarySubmitterId()));
			encounterVO.setSearchSummaryClmType((chartEncounterForm.getSearchCRSummaryType()));
			encounterVO.setSearchSummaryDateInd((chartEncounterForm.getSearchCRSummaryDateInd()));				
			encounterVO.setSearchSummaryFromDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRSummaryFromDate(), DateFormatter.MM_YYYY, DateFormatter.YYYYMM));
			encounterVO.setSearchSummaryToDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRSummaryToDate(), DateFormatter.MM_YYYY, DateFormatter.YYYYMM));
			
			// Search
			context.getChartEncounterService().searchErrorStatSummaryByDateRange(conn, encounterVO);
		
			// Refresh
			EncErrorstatSumVOs searchSummaryResults = encounterVO.getSearchErrorSummaryResults();
		
			// Sort the summary details according to the form's grid layout
			GridUtil statusSummaryGrid = new GridUtil();
			GridUtil.Year year = null;
			GridUtil.Month month = null;
			GridUtil.Totals grandTotals = null;
			GridUtil.Totals yearTotals = null;
			GridUtil.Totals monthTotals = null;
					
			Iterator iterator = searchSummaryResults.iterator();
			while (iterator.hasNext()) {
				EncErrorstatSumVO encErrorstatSumVO = (EncErrorstatSumVO) iterator.next();
				Integer tempYear = Integer.valueOf(encErrorstatSumVO.getDateYrmo().substring(0, 4));
				Integer tempMonth = Integer.valueOf(encErrorstatSumVO.getDateYrmo().substring(4, 6));
				int errors = encErrorstatSumVO.getErrorCnt();
				if ((year == null) || (!year.getYear().equals(tempYear))) {
					year = statusSummaryGrid.getYears().addYear(tempYear);
					month = year.getMonths().addMonth(tempMonth);
				}
				if (!month.getMonth().equals(tempMonth)) {
					month = year.getMonths().addMonth(tempMonth);
				}
		
				if (encErrorstatSumVO.getEncType().equals("I")) {
					grandTotals = statusSummaryGrid.getInstTotals();
					yearTotals = year.getInstTotals();
					monthTotals = month.getInstTotals();
				}
				if (encErrorstatSumVO.getEncType().equals("P")) {
					grandTotals = statusSummaryGrid.getProfTotals();
					yearTotals = year.getProfTotals();
					monthTotals = month.getProfTotals();
				}
				//DME_Dashboard_changes
				if (encErrorstatSumVO.getEncType().equals("E")) {
					grandTotals = statusSummaryGrid.getDmeTotals();
					yearTotals = year.getDmeTotals();
					monthTotals = month.getDmeTotals();
				}
				
				String errorSource = encErrorstatSumVO.getErrorSource();				
				if ("CCR".equals(errorSource)) {
					grandTotals.setCCR(grandTotals.getCCR() + errors);
					yearTotals.setCCR(yearTotals.getCCR() + errors);
					monthTotals.setCCR(monthTotals.getCCR() + errors);					
				}
				else 
				if ("CMS".equals(errorSource)) {
					grandTotals.setRejected(grandTotals.getRejected() + errors);
					yearTotals.setRejected(yearTotals.getRejected() + errors);
					monthTotals.setRejected(monthTotals.getRejected() + errors);					
				}			
				
				grandTotals.setTotal(grandTotals.getTotal() + errors);
				yearTotals.setTotal(yearTotals.getTotal() + errors);
				monthTotals.setTotal(monthTotals.getTotal() + errors);
			}

			// Store search results in the form
			chartEncounterForm.setStatusSummaryGrid(statusSummaryGrid);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}


	public static String selectClaims(Connection conn, SessionHelper sessionHelper, HPEContext context, ChartEncounterForm chartEncounterForm, HttpServletRequest request, String requestStatus)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String forward = ChartConstants.CHART_ERROR;
		HpeSearchVO searchVO = null,searchCRVO = null;

		try {			
			// Get the VO
			HPEEncounterVO encounterVO = context.getChartEncounterVO();

			// Set customer
			encounterVO.setMfId(/* "HCFLCS4" */ sessionHelper.getMfId() /* "HCF0031" */);
			
			if ("0".equals(requestStatus)) {
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);
				if (searchVO == null){
					searchCRVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_BACK_VO);
					if (searchCRVO != null){
						searchVO = searchCRVO;
					}
				}
			}else if ("1".equals(requestStatus)) {
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ERROR_VO);
			}
			//Traverse CR from file tracking to chart management
			else if("2".equals(requestStatus)){
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_FILE_TRACK_VO);
			}			
			
			if (searchVO != null) {				
				chartEncounterForm.setSearchCRDetailSubmitterId(searchVO.getSubmitterId());
				chartEncounterForm.setSearchCRDetailClmType(searchVO.getClmType());
				chartEncounterForm.setSearchCRDetailEncType(searchVO.getEncType());
				chartEncounterForm.setSearchCRDetailDateInd(searchVO.getDateInd());
				chartEncounterForm.setSelectedCRDateYrmo(searchVO.getSelectedDate());
				chartEncounterForm.setSearchCRDetailFromDate(searchVO.getFromDate());
				chartEncounterForm.setSearchCRDetailToDate(searchVO.getToDate());
				chartEncounterForm.setSearchCRDetailGroupStatus(searchVO.getGroupStatus());	
				chartEncounterForm.setSearchCRDetailErrorCode(searchVO.getErrorCode());
				chartEncounterForm.setSearchCRDetailErrorGroup(searchVO.getErrorGroup());
				chartEncounterForm.setSearchCRDetailErrorSource(searchVO.getErrorSource());
				chartEncounterForm.setSearchCRDetailClaimRefNbr(searchVO.getClaimRefNbr());
				chartEncounterForm.setSearchCRDetailHicNbr(searchVO.getHicNbr());
				chartEncounterForm.setPrevMenu(searchVO.getPrevMenu());
				chartEncounterForm.setPrevMethod(searchVO.getPrevMethod());
				chartEncounterForm.setProcessStatus(searchVO.getGroupStatus());	//IFOX-00397153-Fix
				//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
				chartEncounterForm.setSearchVanTanNumber(searchVO.getVanTanNumber());
				//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
				
				//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : Start
				chartEncounterForm.setMaoflag(searchVO.getMaoflag());
				//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : End
				
				//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - Start
				chartEncounterForm.setSearchPayerSecId(searchVO.getPayerSecId());
				chartEncounterForm.setSearchSubsGrpOrPolNbr(searchVO.getSubsGrpOrPolNbr());
				//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - End
				if (!("".equals(chartEncounterForm.getSelectedCRDateYrmo()))) {
					chartEncounterForm.setSearchCRDetailFromDate(DateFormatter.reFormat(chartEncounterForm.getSelectedCRDateYrmo(), DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_START));			
					chartEncounterForm.setSearchCRDetailToDate(DateFormatter.reFormat(chartEncounterForm.getSelectedCRDateYrmo(), DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_END));
				}	
				
				if (searchVO.getEncType().equals("I")) {
					chartEncounterForm.setInstListExpanded(searchVO.isListExpanded());
					chartEncounterForm.setInstErrorsExpanded(searchVO.isErrorsExpanded());
					chartEncounterForm.setInstSubscriberExpanded(searchVO.isSubscriberExpanded());
					chartEncounterForm.setInstProviderExpanded(searchVO.isProviderExpanded());
					chartEncounterForm.setInstClaimExpanded(searchVO.isClaimExpanded());
					chartEncounterForm.setInstClaimCodesExpanded(searchVO.isClaimCodesExpanded());
					chartEncounterForm.setInstClaimNotesExpanded(searchVO.isClaimNotesExpanded());
					chartEncounterForm.setInstClaimProvExpanded(searchVO.isClaimProvExpanded());
					chartEncounterForm.setInstClaimProvDetailExpanded(searchVO.isClaimProvDetailExpanded());
					chartEncounterForm.setInstClaimOtherSubsProvExpanded(searchVO.isClaimOtherSubsProvExpanded());
					chartEncounterForm.setInstClaimOtherSubsProvDetailExpanded(searchVO.isClaimOtherSubsProvDetailExpanded());
					chartEncounterForm.setInstClaimOtherSubsExpanded(searchVO.isClaimOtherSubsExpanded());
					chartEncounterForm.setInstClaimOtherSubsDetailExpanded(searchVO.isClaimOtherSubsDetailExpanded());
					chartEncounterForm.setInstClaimLineExpanded(searchVO.isClaimLineExpanded());
					chartEncounterForm.setInstClaimLineDetailExpanded(searchVO.isClaimLineDetailExpanded());
					chartEncounterForm.setInstClaimLineProvExpanded(searchVO.isClaimLineProvExpanded());
					chartEncounterForm.setInstClaimLineProvDetailExpanded(searchVO.isClaimLineProvDetailExpanded());
					chartEncounterForm.setInstClaimLineAdjudExpanded(searchVO.isClaimLineAdjudExpanded());
					chartEncounterForm.setInstClaimLineAdjudDetailExpanded(searchVO.isClaimLineAdjudDetailExpanded());
				}else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")) {
					chartEncounterForm.setProfListExpanded(searchVO.isListExpanded());
					chartEncounterForm.setProfErrorsExpanded(searchVO.isErrorsExpanded());
					chartEncounterForm.setProfSubscriberExpanded(searchVO.isSubscriberExpanded());
					chartEncounterForm.setProfProviderExpanded(searchVO.isProviderExpanded());
					chartEncounterForm.setProfClaimExpanded(searchVO.isClaimExpanded());
					chartEncounterForm.setProfClaimCodesExpanded(searchVO.isClaimCodesExpanded());					
					chartEncounterForm.setProfClaimProvExpanded(searchVO.isClaimProvExpanded());
					chartEncounterForm.setProfClaimProvDetailExpanded(searchVO.isClaimProvDetailExpanded());
					chartEncounterForm.setProfClaimOtherSubsProvExpanded(searchVO.isClaimOtherSubsProvExpanded());
					chartEncounterForm.setProfClaimOtherSubsProvDetailExpanded(searchVO.isClaimOtherSubsProvDetailExpanded());
					chartEncounterForm.setProfClaimOtherSubsExpanded(searchVO.isClaimOtherSubsExpanded());
					chartEncounterForm.setProfClaimOtherSubsDetailExpanded(searchVO.isClaimOtherSubsDetailExpanded());
					chartEncounterForm.setProfClaimLineExpanded(searchVO.isClaimLineExpanded());
					chartEncounterForm.setProfClaimLineDetailExpanded(searchVO.isClaimLineDetailExpanded());
					chartEncounterForm.setProfClaimLineProvExpanded(searchVO.isClaimLineProvExpanded());
					chartEncounterForm.setProfClaimLineProvDetailExpanded(searchVO.isClaimLineProvDetailExpanded());
					chartEncounterForm.setProfClaimLineAdjudExpanded(searchVO.isClaimLineAdjudExpanded());
					chartEncounterForm.setProfClaimLineAdjudDetailExpanded(searchVO.isClaimLineAdjudDetailExpanded());
				}
				
			} else {								
				chartEncounterForm.setSearchCRDetailSubmitterId("");
				chartEncounterForm.setSearchCRDetailClmType("CR");
				chartEncounterForm.setSearchCRDetailEncType(Utility.getEncTypeFromSelectedTab("CHART_MGMT_TAB", sessionHelper)); //DME_Dashboard_changes
				chartEncounterForm.setSearchCRDetailDateInd("0");
				chartEncounterForm.setSearchCRDetailFromDate("");
				chartEncounterForm.setSearchCRDetailToDate("");
				chartEncounterForm.setSearchCRDetailGroupStatus("");
				chartEncounterForm.setSearchCRDetailErrorCode("");
				chartEncounterForm.setSearchCRDetailErrorGroup("");
				chartEncounterForm.setSearchCRDetailErrorSource("");
			}

			// Copy the search criteria to the VO
			encounterVO.setSearchDetailSubmitterId(chartEncounterForm.getSearchCRDetailSubmitterId());
			encounterVO.setSearchDetailClmType(chartEncounterForm.getSearchCRDetailClmType());			
			encounterVO.setSearchDetailEncType(chartEncounterForm.getSearchCRDetailEncType());
			encounterVO.setSearchDetailDateInd(chartEncounterForm.getSearchCRDetailDateInd());
			encounterVO.setSearchDetailFromDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRDetailFromDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			encounterVO.setSearchDetailToDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRDetailToDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			encounterVO.setSearchDetailClaimRefNbr(chartEncounterForm.getSearchCRDetailClaimRefNbr());
			encounterVO.setSearchDetailHicNbr(chartEncounterForm.getSearchCRDetailHicNbr());
			encounterVO.setSearchDetailGroupStatus(chartEncounterForm.getSearchCRDetailGroupStatus());
			encounterVO.setSearchDetailErrorSource(chartEncounterForm.getSearchCRDetailErrorSource());
			encounterVO.setSearchDetailErrorGroup(chartEncounterForm.getSearchCRDetailErrorGroup());
			encounterVO.setSearchDetailErrorCode(chartEncounterForm.getSearchCRDetailErrorCode());

			//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
			encounterVO.setSearchVanTanNumber(chartEncounterForm.getSearchVanTanNumber());
			//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
			
			//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : Start
			encounterVO.setMaoflag(chartEncounterForm.getMaoflag());
			//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : End
			
			//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - Start
			encounterVO.setSearchPayerSecId(chartEncounterForm.getSearchPayerSecId());
			encounterVO.setSearchSubsGrpOrPolNbr(chartEncounterForm.getSearchSubsGrpOrPolNbr());
			//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - End
			if (encounterVO.getSearchDetailEncType().equals("I")) {
				pageInstClaims(conn, sessionHelper, context, chartEncounterForm, request, "first",requestStatus);
				if (searchVO != null) {					
					if (!("".equals(searchVO.getSelectedClaimType())) && !("".equals(searchVO.getSelectedClaimRefNbr())) 
							&& !("".equals(searchVO.getSelectedClaimRevNbr())) && !("".equals(searchVO.getSelectedClaimSeqNbr()))){						
						if ("0".equals(requestStatus)) {
							forward = selectClaim(conn, sessionHelper, context, chartEncounterForm, request,requestStatus);						
						} else
							forward = ChartConstants.CHART_INSTDETAIL;					
					} else 
						forward = ChartConstants.CHART_INSTDETAIL;
				} else 
					forward = ChartConstants.CHART_INSTDETAIL;
			}
			else
			if (encounterVO.getSearchDetailEncType().equals("P") || encounterVO.getSearchDetailEncType().equals("E")) {
				pageProfClaims(conn, sessionHelper, context, chartEncounterForm, request, "first",requestStatus,encounterVO.getSearchDetailEncType());//DME_Dashboard_changes
				if (searchVO != null) {					
					if (!("".equals(searchVO.getSelectedClaimType())) && !("".equals(searchVO.getSelectedClaimRefNbr())) 
							&& !("".equals(searchVO.getSelectedClaimRevNbr())) && !("".equals(searchVO.getSelectedClaimSeqNbr()))){						
						if ("0".equals(requestStatus)) {
							forward = selectClaim(conn, sessionHelper, context, chartEncounterForm, request,requestStatus);						
						} else
							forward = ChartConstants.CHART_PROFDETAIL;
					} else 
						forward = ChartConstants.CHART_PROFDETAIL;
				} else 
					forward = ChartConstants.CHART_PROFDETAIL;				
			}
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return forward;
	}
	
	/*
	 * method to retrieve error details from the database
	 */
	public static String getErrorDetails(Connection conn, SessionHelper sessionHelper, HPEContext context, ChartEncounterForm chartEncounterForm, HttpServletRequest request)
	throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String forward = ChartConstants.CHART_ERROR;
		
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getChartEncounterVO();
		
			// Set customer
			encounterVO.setMfId(/* "HCFLCS4" */ sessionHelper.getMfId() /* "HCF0031" */);			
			HpeSearchVO searchVO = null;			
			
			searchVO = (HpeSearchVO)sessionHelper.getAttribute("SearchCRVO");
			if(searchVO != null){					 
				chartEncounterForm.setSearchCRSummarySubmitterId((searchVO.getSubmitterId()));
				chartEncounterForm.setSearchCRSummaryType(searchVO.getClmType());
				chartEncounterForm.setSearchCRSummaryEncType(searchVO.getEncType());
				chartEncounterForm.setSearchCRSummaryDateInd((searchVO.getDateInd()));					
				chartEncounterForm.setSelectedCRDateYrmo(searchVO.getSelectedDate());					
				chartEncounterForm.setSearchCRSummaryFromDate(searchVO.getFromDate());				
				chartEncounterForm.setSearchCRSummaryToDate(searchVO.getToDate());					
				chartEncounterForm.setSearchCRSummaryErrorSource(searchVO.getErrorSource());
				chartEncounterForm.setSearchCRSummaryErrorGroup(searchVO.getErrorGroup());
				chartEncounterForm.setSearchCRSummaryErrorCode(searchVO.getErrorCode());					
			}			
					
			// Copy the search criteria to the VO
			encounterVO.setSearchSummarySubmitterId(chartEncounterForm.getSearchCRSummarySubmitterId());
			encounterVO.setSearchSummaryEncType(chartEncounterForm.getSearchCRSummaryEncType());
			encounterVO.setSearchSummaryClmType(chartEncounterForm.getSearchCRSummaryType());
			
			if (!("".equals(chartEncounterForm.getSelectedCRDateYrmo()))) {
				chartEncounterForm.setSearchCRSummaryFromDate(chartEncounterForm.getSelectedCRDateYrmo());			
				chartEncounterForm.setSearchCRSummaryToDate(chartEncounterForm.getSelectedCRDateYrmo());
			}
			
			encounterVO.setSearchSummaryFromDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRSummaryFromDate(), DateFormatter.MM_YYYY, DateFormatter.YYYYMM));
			encounterVO.setSearchSummaryToDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRSummaryToDate(), DateFormatter.MM_YYYY, DateFormatter.YYYYMM));
			encounterVO.setSearchSummaryErrorSource(chartEncounterForm.getSearchCRSummaryErrorSource());			
			encounterVO.setSearchSummaryErrorGroup(chartEncounterForm.getSearchCRSummaryErrorGroup());			
			encounterVO.setSearchSummaryErrorCode(chartEncounterForm.getSearchCRSummaryErrorCode());
			encounterVO.setSearchSummaryDateInd(chartEncounterForm.getSearchCRSummaryDateInd());
			
			pageErrorDetail(conn, sessionHelper, context, chartEncounterForm, request);			
		
			if (encounterVO.getSearchSummaryEncType().equals("I")) {				
				forward = ChartConstants.CHART_SUMMINSTREJECTCODES;
			}else if (encounterVO.getSearchSummaryEncType().equals("P") || encounterVO.getSearchSummaryEncType().equals("E")) {				
				forward = ChartConstants.CHART_SUMMPROFREJECTCODES;
			}			
			
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return forward;
	}
	
	/*
	 * Method to retrieve the claims based on selected error Code,error Group & error Source 
	 */
	public static String selectErrorSpecificClaims(Connection conn, SessionHelper sessionHelper, HPEContext context, ChartEncounterForm chartEncounterForm, HttpServletRequest request)
	throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String forward = ChartConstants.CHART_ERROR;
		String errorCode = "";
		String errorGroup = "";
		String rejectCode = "";
		String errorSource = "";
		int index = 0;
		HpeSearchVO searchVO = null;
		String requestStatus = null;
		
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getChartEncounterVO();
			searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ERROR_VO);
		
			if (searchVO != null) {
				rejectCode = searchVO.getRejectCode();
				errorSource = searchVO.getFormattedErrorSource();
				
				if (rejectCode.length() > 0) {
					chartEncounterForm.setRejectCode(searchVO.getRejectCode());
					chartEncounterForm.setFormattedErrorSource(searchVO.getFormattedErrorSource());					
					chartEncounterForm.setSelectedCRErrorGroup(searchVO.getErrorGroup());
				} 
				chartEncounterForm.setSearchCRDetailSubmitterId(searchVO.getSubmitterId());
				chartEncounterForm.setSearchCRDetailClmType(searchVO.getClmType());
				chartEncounterForm.setSearchCRDetailEncType(searchVO.getEncType());
				chartEncounterForm.setSearchCRDetailDateInd(searchVO.getDateInd());
				chartEncounterForm.setSearchCRDetailFromDate(DateFormatter.reFormat(searchVO.getSelectedDate(), DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_START));
				chartEncounterForm.setSearchCRDetailToDate(DateFormatter.reFormat(searchVO.getSelectedDate(), DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_END));				
				chartEncounterForm.setSearchCRDetailGroupStatus(searchVO.getGroupStatus());
				requestStatus = "1";				
			} else {
				chartEncounterForm.setRejectCode("");
				chartEncounterForm.setFormattedErrorSource("");				
				chartEncounterForm.setSelectedCRErrorGroup("");
				chartEncounterForm.setSearchCRDetailSubmitterId("");				
				chartEncounterForm.setSearchCRDetailEncType(Utility.getEncTypeFromSelectedTab("CHART_REJECT_ANALYSIS_TAB", sessionHelper));//DME_Dashboard_changes
				chartEncounterForm.setSearchCRDetailClmType("CR");
				chartEncounterForm.setSearchCRDetailDateInd("0");
				chartEncounterForm.setSearchCRDetailFromDate("");
				chartEncounterForm.setSearchCRDetailToDate("");
				chartEncounterForm.setSearchCRDetailGroupStatus("");
			}
			
			rejectCode =  chartEncounterForm.getRejectCode();
			errorSource = chartEncounterForm.getFormattedErrorSource();
		
			// Split up selected errorCode & errorGroup
			if(rejectCode.length() > 0){	
				//index = rejectCode.indexOf("_");
				//errorCode = rejectCode.substring(0,index);
				//errorGroup = rejectCode.substring(index+1,rejectCode.length());
				errorGroup = chartEncounterForm.getSelectedCRErrorGroup();
				errorCode = rejectCode;
				
				chartEncounterForm.setSearchCRDetailErrorCode(errorCode);
				chartEncounterForm.setSearchCRDetailErrorGroup(errorGroup);
			}	
			
			//Get short name of selected errorSource
			if(!("").equals(errorSource) && (errorSource!= null)){				
				if(errorSource.equals(ChartConstants.ERROR_SYNTAX)) {
					errorSource = "SYN";					
				}else if(errorSource.equals(ChartConstants.ERROR_REJECTED)) {
					errorSource = "REJ";
				}
				
				chartEncounterForm.setSearchCRDetailErrorSource(errorSource);
			}			
			
			//Set customer
			encounterVO.setMfId(/* "HCFLCS4" */ sessionHelper.getMfId() /* "HCF0031" */);			
			
			//Copy the search criteria to the VO
			encounterVO.setSearchDetailSubmitterId(chartEncounterForm.getSearchCRDetailSubmitterId());
			encounterVO.setSearchDetailClmType(chartEncounterForm.getSearchCRDetailClmType());
			encounterVO.setSearchDetailEncType(chartEncounterForm.getSearchCRDetailEncType());
			encounterVO.setSearchDetailDateInd(chartEncounterForm.getSearchCRDetailDateInd());
			encounterVO.setSearchDetailFromDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRDetailFromDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			encounterVO.setSearchDetailToDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRDetailToDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));			
			encounterVO.setSearchDetailErrorSource(errorSource);
			encounterVO.setSearchDetailErrorGroup(errorGroup);
			encounterVO.setSearchDetailErrorCode(errorCode);
			encounterVO.setSearchDetailGroupStatus(chartEncounterForm.getSearchCRDetailGroupStatus());
		
			if (encounterVO.getSearchDetailEncType().equals("I")) {
				pageInstClaims(conn, sessionHelper, context, chartEncounterForm, request, "first",requestStatus);
				if (searchVO != null) {
					chartEncounterForm.setInstListExpanded(searchVO.isListExpanded());
					chartEncounterForm.setInstErrorsExpanded(searchVO.isErrorsExpanded());
					chartEncounterForm.setInstSubscriberExpanded(searchVO.isSubscriberExpanded());
					chartEncounterForm.setInstProviderExpanded(searchVO.isProviderExpanded());
					chartEncounterForm.setInstClaimExpanded(searchVO.isClaimExpanded());
					chartEncounterForm.setInstClaimCodesExpanded(searchVO.isClaimCodesExpanded());
					chartEncounterForm.setInstClaimNotesExpanded(searchVO.isClaimNotesExpanded());
					chartEncounterForm.setInstClaimProvExpanded(searchVO.isClaimProvExpanded());
					chartEncounterForm.setInstClaimProvDetailExpanded(searchVO.isClaimProvDetailExpanded());
					chartEncounterForm.setInstClaimOtherSubsProvExpanded(searchVO.isClaimOtherSubsProvExpanded());
					chartEncounterForm.setInstClaimOtherSubsProvDetailExpanded(searchVO.isClaimOtherSubsProvDetailExpanded());
					chartEncounterForm.setInstClaimOtherSubsExpanded(searchVO.isClaimOtherSubsExpanded());
					chartEncounterForm.setInstClaimOtherSubsDetailExpanded(searchVO.isClaimOtherSubsDetailExpanded());
					chartEncounterForm.setInstClaimLineExpanded(searchVO.isClaimLineExpanded());
					chartEncounterForm.setInstClaimLineDetailExpanded(searchVO.isClaimLineDetailExpanded());
					chartEncounterForm.setInstClaimLineProvExpanded(searchVO.isClaimLineProvExpanded());
					chartEncounterForm.setInstClaimLineProvDetailExpanded(searchVO.isClaimLineProvDetailExpanded());
					chartEncounterForm.setInstClaimLineAdjudExpanded(searchVO.isClaimLineAdjudExpanded());
					chartEncounterForm.setInstClaimLineAdjudDetailExpanded(searchVO.isClaimLineAdjudDetailExpanded());	
					
					if (!("".equals(searchVO.getSelectedClaimType())) && !("".equals(searchVO.getSelectedClaimRefNbr())) 
							&& !("".equals(searchVO.getSelectedClaimRevNbr())) && !("".equals(searchVO.getSelectedClaimSeqNbr()))){
						forward = selectClaim(conn, sessionHelper, context, chartEncounterForm, request,requestStatus);				
					} else 
						forward = ChartConstants.CHART_INSTDETAIL;
				} else
					forward = ChartConstants.CHART_INSTDETAIL;
			}
			else
			if (encounterVO.getSearchDetailEncType().equals("P") || encounterVO.getSearchDetailEncType().equals("E")) {
				pageProfClaims(conn, sessionHelper, context, chartEncounterForm, request, "first",requestStatus,encounterVO.getSearchDetailEncType());//DME_Dashboard_changes
				if (searchVO != null) {
					chartEncounterForm.setProfListExpanded(searchVO.isListExpanded());
					chartEncounterForm.setProfErrorsExpanded(searchVO.isErrorsExpanded());
					chartEncounterForm.setProfSubscriberExpanded(searchVO.isSubscriberExpanded());
					chartEncounterForm.setProfProviderExpanded(searchVO.isProviderExpanded());
					chartEncounterForm.setProfClaimExpanded(searchVO.isClaimExpanded());
					chartEncounterForm.setProfClaimCodesExpanded(searchVO.isClaimCodesExpanded());					
					chartEncounterForm.setProfClaimProvExpanded(searchVO.isClaimProvExpanded());
					chartEncounterForm.setProfClaimProvDetailExpanded(searchVO.isClaimProvDetailExpanded());
					chartEncounterForm.setProfClaimOtherSubsProvExpanded(searchVO.isClaimOtherSubsProvExpanded());
					chartEncounterForm.setProfClaimOtherSubsProvDetailExpanded(searchVO.isClaimOtherSubsProvDetailExpanded());
					chartEncounterForm.setProfClaimOtherSubsExpanded(searchVO.isClaimOtherSubsExpanded());
					chartEncounterForm.setProfClaimOtherSubsDetailExpanded(searchVO.isClaimOtherSubsDetailExpanded());
					chartEncounterForm.setProfClaimLineExpanded(searchVO.isClaimLineExpanded());
					chartEncounterForm.setProfClaimLineDetailExpanded(searchVO.isClaimLineDetailExpanded());
					chartEncounterForm.setProfClaimLineProvExpanded(searchVO.isClaimLineProvExpanded());
					chartEncounterForm.setProfClaimLineProvDetailExpanded(searchVO.isClaimLineProvDetailExpanded());
					chartEncounterForm.setProfClaimLineAdjudExpanded(searchVO.isClaimLineAdjudExpanded());
					chartEncounterForm.setProfClaimLineAdjudDetailExpanded(searchVO.isClaimLineAdjudDetailExpanded());
					
					if (!("".equals(searchVO.getSelectedClaimType())) && !("".equals(searchVO.getSelectedClaimRefNbr())) 
							&& !("".equals(searchVO.getSelectedClaimRevNbr())) && !("".equals(searchVO.getSelectedClaimSeqNbr()))){
						forward = selectClaim(conn, sessionHelper, context, chartEncounterForm, request,requestStatus);				
					} else
						forward = ChartConstants.CHART_PROFDETAIL;
				} else
					forward = ChartConstants.CHART_PROFDETAIL;
			}
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return forward;
	}

	public static String pageClaims(Connection conn, SessionHelper sessionHelper, HPEContext context, ChartEncounterForm chartEncounterForm, HttpServletRequest request, String move,String requestStatus)
	throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		HPEEncounterVO encounterVO = context.getChartEncounterVO();
		HpeSearchVO searchVO = null;
		String errorCode = "";
		String errorGroup = "";
		String rejectCode = "";
		String errorSource = "";
		int index = 0;
		
		if ("0".equals(requestStatus)) {
			searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);
		}else if ("1".equals(requestStatus)) {
			searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ERROR_VO);
		}			
		
		if (searchVO != null) {				
			chartEncounterForm.setSearchCRDetailSubmitterId(searchVO.getSubmitterId());
			chartEncounterForm.setSearchCRDetailEncType(searchVO.getEncType());
			chartEncounterForm.setSearchCRDetailDateInd(searchVO.getDateInd());
			chartEncounterForm.setSelectedCRDateYrmo(searchVO.getSelectedDate());
			chartEncounterForm.setSearchCRDetailFromDate(searchVO.getFromDate());
			chartEncounterForm.setSearchCRDetailToDate(searchVO.getToDate());
			chartEncounterForm.setSearchCRDetailGroupStatus(searchVO.getGroupStatus());	
			chartEncounterForm.setSearchCRDetailErrorCode(searchVO.getErrorCode());
			chartEncounterForm.setSearchCRDetailErrorGroup(searchVO.getErrorGroup());
			chartEncounterForm.setSearchCRDetailErrorSource(searchVO.getErrorSource());
			chartEncounterForm.setSearchCRDetailClaimRefNbr(searchVO.getClaimRefNbr());
			chartEncounterForm.setSearchCRDetailHicNbr(searchVO.getHicNbr());
			
			rejectCode = searchVO.getRejectCode();
			errorSource = searchVO.getFormattedErrorSource();
			//Split up selected errorCode & errorGroup
			if(rejectCode.length() > 0){	
				//index = rejectCode.indexOf("_");
				//errorCode = rejectCode.substring(0,index);
				//errorGroup = rejectCode.substring(index+1,rejectCode.length());
				
				chartEncounterForm.setSearchCRDetailErrorCode(rejectCode);
				//chartEncounterForm.setSearchDetailErrorGroup(errorGroup);
			}	
			
			//Get short name of selected errorSource
			if(!("").equals(errorSource) && (errorSource!= null)){				
				//if(errorSource.equals(ChartConstants.ERROR_SYNTAX)) {
				//	errorSource = "SYN";					
				//}else if(errorSource.equals(ChartConstants.ERROR_REJECTED)) {
				//	errorSource = "REJ";
				//}
				
				chartEncounterForm.setSearchCRDetailErrorSource(errorSource);
			}			
			
			if (!("".equals(chartEncounterForm.getSelectedCRDateYrmo()))) {
				chartEncounterForm.setSearchCRDetailFromDate(DateFormatter.reFormat(chartEncounterForm.getSelectedCRDateYrmo(), DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_START));			
				chartEncounterForm.setSearchCRDetailToDate(DateFormatter.reFormat(chartEncounterForm.getSelectedCRDateYrmo(), DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_END));
			}
			
			if (searchVO.getIconFlag().equals("Y")) {
			if (searchVO.getEncType().equals("I")) {
				chartEncounterForm.setInstListExpanded(searchVO.isListExpanded());
				chartEncounterForm.setInstErrorsExpanded(searchVO.isErrorsExpanded());
				chartEncounterForm.setInstSubscriberExpanded(searchVO.isSubscriberExpanded());
				chartEncounterForm.setInstProviderExpanded(searchVO.isProviderExpanded());
				chartEncounterForm.setInstClaimExpanded(searchVO.isClaimExpanded());
				chartEncounterForm.setInstClaimCodesExpanded(searchVO.isClaimCodesExpanded());
				chartEncounterForm.setInstClaimNotesExpanded(searchVO.isClaimNotesExpanded());
				chartEncounterForm.setInstClaimProvExpanded(searchVO.isClaimProvExpanded());
				chartEncounterForm.setInstClaimProvDetailExpanded(searchVO.isClaimProvDetailExpanded());
				chartEncounterForm.setInstClaimOtherSubsProvExpanded(searchVO.isClaimOtherSubsProvExpanded());
				chartEncounterForm.setInstClaimOtherSubsProvDetailExpanded(searchVO.isClaimOtherSubsProvDetailExpanded());
				chartEncounterForm.setInstClaimOtherSubsExpanded(searchVO.isClaimOtherSubsExpanded());
				chartEncounterForm.setInstClaimOtherSubsDetailExpanded(searchVO.isClaimOtherSubsDetailExpanded());
				chartEncounterForm.setInstClaimLineExpanded(searchVO.isClaimLineExpanded());
				chartEncounterForm.setInstClaimLineDetailExpanded(searchVO.isClaimLineDetailExpanded());
				chartEncounterForm.setInstClaimLineProvExpanded(searchVO.isClaimLineProvExpanded());
				chartEncounterForm.setInstClaimLineProvDetailExpanded(searchVO.isClaimLineProvDetailExpanded());
				chartEncounterForm.setInstClaimLineAdjudExpanded(searchVO.isClaimLineAdjudExpanded());
				chartEncounterForm.setInstClaimLineAdjudDetailExpanded(searchVO.isClaimLineAdjudDetailExpanded());					
				}else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")) {
				chartEncounterForm.setProfListExpanded(searchVO.isListExpanded());
				chartEncounterForm.setProfErrorsExpanded(searchVO.isErrorsExpanded());
				chartEncounterForm.setProfSubscriberExpanded(searchVO.isSubscriberExpanded());
				chartEncounterForm.setProfProviderExpanded(searchVO.isProviderExpanded());
				chartEncounterForm.setProfClaimExpanded(searchVO.isClaimExpanded());
				chartEncounterForm.setProfClaimCodesExpanded(searchVO.isClaimCodesExpanded());					
				chartEncounterForm.setProfClaimProvExpanded(searchVO.isClaimProvExpanded());
				chartEncounterForm.setProfClaimProvDetailExpanded(searchVO.isClaimProvDetailExpanded());
				chartEncounterForm.setProfClaimOtherSubsProvExpanded(searchVO.isClaimOtherSubsProvExpanded());
				chartEncounterForm.setProfClaimOtherSubsProvDetailExpanded(searchVO.isClaimOtherSubsProvDetailExpanded());
				chartEncounterForm.setProfClaimOtherSubsExpanded(searchVO.isClaimOtherSubsExpanded());
				chartEncounterForm.setProfClaimOtherSubsDetailExpanded(searchVO.isClaimOtherSubsDetailExpanded());
				chartEncounterForm.setProfClaimLineExpanded(searchVO.isClaimLineExpanded());
				chartEncounterForm.setProfClaimLineDetailExpanded(searchVO.isClaimLineDetailExpanded());
				chartEncounterForm.setProfClaimLineProvExpanded(searchVO.isClaimLineProvExpanded());
				chartEncounterForm.setProfClaimLineProvDetailExpanded(searchVO.isClaimLineProvDetailExpanded());
				chartEncounterForm.setProfClaimLineAdjudExpanded(searchVO.isClaimLineAdjudExpanded());
				chartEncounterForm.setProfClaimLineAdjudDetailExpanded(searchVO.isClaimLineAdjudDetailExpanded());					
			}
			}
			
			//Copy the search criteria to the VO
			encounterVO.setSearchDetailSubmitterId(chartEncounterForm.getSearchCRDetailSubmitterId());
			encounterVO.setSearchDetailEncType(chartEncounterForm.getSearchCRDetailEncType());
			encounterVO.setSearchDetailDateInd(chartEncounterForm.getSearchCRDetailDateInd());
			encounterVO.setSearchDetailFromDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRDetailFromDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			encounterVO.setSearchDetailToDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRDetailToDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			encounterVO.setSearchDetailClaimRefNbr(chartEncounterForm.getSearchCRDetailClaimRefNbr());
			encounterVO.setSearchDetailHicNbr(chartEncounterForm.getSearchCRDetailHicNbr());
			encounterVO.setSearchDetailGroupStatus(chartEncounterForm.getSearchCRDetailGroupStatus());
			encounterVO.setSearchDetailErrorSource(chartEncounterForm.getSearchCRDetailErrorSource());
			encounterVO.setSearchDetailErrorGroup(chartEncounterForm.getSearchCRDetailErrorGroup());
			encounterVO.setSearchDetailErrorCode(chartEncounterForm.getSearchCRDetailErrorCode());
		}		

		if (encounterVO.getSearchDetailEncType().equals("I")) {
			pageInstClaims(conn,sessionHelper,context,chartEncounterForm,request,move,requestStatus);
			return ChartConstants.CHART_INSTDETAIL;
		}
		if (encounterVO.getSearchDetailEncType().equals("P") || encounterVO.getSearchDetailEncType().equals("E")) {
			pageProfClaims(conn,sessionHelper,context,chartEncounterForm,request,move,requestStatus, encounterVO.getSearchDetailEncType()); //DME Dashboard Changes
			logger.info(LoggerConstants.methodEndLevel());
			return ChartConstants.CHART_PROFDETAIL;
		}
		logger.info(LoggerConstants.methodEndLevel());
		return ChartConstants.CHART_ERROR;
	}

	public static void pageInstClaims(Connection conn, SessionHelper sessionHelper, HPEContext context, ChartEncounterForm chartEncounterForm, HttpServletRequest request, String move,String requestStatus)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getChartEncounterVO();
			HpeSearchVO searchVO = null;			
			String oldStatus = "false";
			String flagVal = (String) sessionHelper.getAttribute(ChartConstants.HPE_BACK);
			
			if ("0".equals(requestStatus)) {
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);
			}else if ("1".equals(requestStatus)) {
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ERROR_VO);
			}
			//Traverse CR from file tracking to chart management
			else if("2".equals(requestStatus)){
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_FILE_TRACK_VO);
			}
			requestStatus = null;

			if (searchVO != null) {				
				context.setCrClaimDetailPagination(searchVO.getClaimDetailPagination());
				if (!("".equals(searchVO.getMove())) && (searchVO.getMove()!= null))  {
					move=searchVO.getMove();					
				}
				oldStatus = searchVO.getOldState();				
			}else{				
				if(flagVal != null){
					if (flagVal.equalsIgnoreCase("true")){
						Pagination crClaimDetailPagination = new Pagination();
						crClaimDetailPagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
						context.setCrClaimDetailPagination(crClaimDetailPagination);
					}
				}					
			}
			
			// we want to use the data from the last Query should be here already
			Pagination claimDetailPagination = context.getCrClaimDetailPagination();
			
			// File track code start	
			//Traverse CR from file tracking to chart management
			
						if(chartEncounterForm.isFileTrackingFlag()){
							encounterVO.setFileTrackFlag(true);
							encounterVO.setOrigIntrchgCtrlNbr(chartEncounterForm.getOrigFileId());
							encounterVO.setSearchDetailGroupStatus(chartEncounterForm.getSearchCRDetailGroupStatus());
							encounterVO.setSearchDetailSubmitterId(chartEncounterForm.getSearchCRDetailSubmitterId());
						}else{
							encounterVO.setFileTrackFlag(false);
						}
						// File track code END

			// Search
			context.getChartEncounterService().selectClaimsBySearchCriteria(conn, encounterVO, claimDetailPagination, move,oldStatus);

			// Refresh
			//
			Enc837iClmVOs instClaims = encounterVO.getInstClaims();

			// Store search results in request scope
			request.setAttribute("instClaims", instClaims);

			// Pre-select first claim
			if ((instClaims != null) && (instClaims.isEmpty() == false)) {
				// Retrieve first claim
				Enc837iClmVO instClaim = (Enc837iClmVO) instClaims.get(0);

				// Set form state as if first claim were selected
				chartEncounterForm.setSelectedClaimType("I");
				chartEncounterForm.setSelectedClaimRefNbr(instClaim.getWtxClaimRefNbr());
				chartEncounterForm.setSelectedClaimRevNbr(Integer.toString(instClaim.getWtxClaimRevNbr()));
				chartEncounterForm.setSelectedClaimSeqNbr(Integer.toString(instClaim.getClmSeqNbr()));

				selectClaim(conn, sessionHelper, context, chartEncounterForm, request,requestStatus);

				// Clear form state
				chartEncounterForm.setSelectedClaimType("");
				chartEncounterForm.setSelectedClaimRefNbr("");
				chartEncounterForm.setSelectedClaimRevNbr("");
				chartEncounterForm.setSelectedClaimSeqNbr("");
			}
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void pageProfClaims(Connection conn, SessionHelper sessionHelper, HPEContext context, ChartEncounterForm chartEncounterForm, HttpServletRequest request, String move,String requestStatus, String encType)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getChartEncounterVO();
			HpeSearchVO searchVO = null;		
			String oldStatus = "false";
			String flagVal = (String) sessionHelper.getAttribute(ChartConstants.HPE_BACK);

			if ("0".equals(requestStatus)) {
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);
			}else if ("1".equals(requestStatus)) {
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ERROR_VO);
			}
			//Traverse CR from file tracking to chart management
			else if("2".equals(requestStatus)){
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_FILE_TRACK_VO);
			}
			requestStatus = null;

			if (searchVO != null) {				
				context.setCrClaimDetailPagination(searchVO.getClaimDetailPagination());
				if (!("".equals(searchVO.getMove())) && (searchVO.getMove()!= null))  {
					move=searchVO.getMove();					
				}
				oldStatus = searchVO.getOldState();				
			}else{
				if(flagVal != null){
					if (flagVal.equalsIgnoreCase("true")){
						Pagination crClaimDetailPagination = new Pagination();
						crClaimDetailPagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
						context.setCrClaimDetailPagination(crClaimDetailPagination);
					}
				}				
			}
			
			// we want to use the data from the last Query should be here already
			Pagination claimDetailPagination = context.getCrClaimDetailPagination();
			
			// File track code start	
						//Traverse CR from file tracking to chart management
						
									if(chartEncounterForm.isFileTrackingFlag()){
										encounterVO.setFileTrackFlag(true);
										encounterVO.setOrigIntrchgCtrlNbr(chartEncounterForm.getOrigFileId());
										encounterVO.setSearchDetailGroupStatus(chartEncounterForm.getSearchCRDetailGroupStatus());
										encounterVO.setSearchDetailSubmitterId(chartEncounterForm.getSearchCRDetailSubmitterId());
									}else{
										encounterVO.setFileTrackFlag(false);
									}
									// File track code END

			// Search
			context.getChartEncounterService().selectClaimsBySearchCriteria(conn, encounterVO, claimDetailPagination, move,oldStatus);

			// Refresh
			//
			Enc837pClmVOs profClaims = encounterVO.getProfClaims();

			// Store search results in request scope
			request.setAttribute("profClaims", profClaims);

			// Pre-select first claim
			if ((profClaims != null) && (profClaims.isEmpty() == false)) {
				// Retrieve first claim
				Enc837pClmVO profClaim = (Enc837pClmVO) profClaims.get(0);

				// Set form state as if first claim were selected
				chartEncounterForm.setSelectedClaimType(encType);//DME dashboard changes
				chartEncounterForm.setSelectedClaimRefNbr(profClaim.getWtxClaimRefNbr());
				chartEncounterForm.setSelectedClaimRevNbr(Integer.toString(profClaim.getWtxClaimRevNbr()));
				chartEncounterForm.setSelectedClaimSeqNbr(Integer.toString(profClaim.getClmSeqNbr()));

				selectClaim(conn, sessionHelper, context, chartEncounterForm, request,requestStatus);

				// Clear form state
				chartEncounterForm.setSelectedClaimType("");
				chartEncounterForm.setSelectedClaimRefNbr("");
				chartEncounterForm.setSelectedClaimRevNbr("");
				chartEncounterForm.setSelectedClaimSeqNbr("");
			}
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	/*
	 * method to retrieve error details for Institutional
	 */
	public static void pageErrorDetail(Connection conn, SessionHelper sessionHelper, HPEContext context, ChartEncounterForm chartEncounterForm, HttpServletRequest request)
	throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getChartEncounterVO();			
		
			// Search
			context.getChartEncounterService().selectErrorsBySearchCriteria(conn, encounterVO);
		
			// Refresh			
			EncErrorstatSumVOs errorLists = encounterVO.getSearchErrorSummaryResults();			
			
			// Store search results in request scope
			request.setAttribute("errorLists", errorLists);		
			
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static String selectClaim(Connection conn, SessionHelper sessionHelper, HPEContext context, ChartEncounterForm chartEncounterForm, HttpServletRequest request,String requestStatus)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String forward = ChartConstants.CHART_ERROR;
		HpeSearchVO searchVO = null;

		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getChartEncounterVO();

			// Set customer
			encounterVO.setMfId(/* "HCFLCS4" */ sessionHelper.getMfId() /* "HCF0031" */);
			
			if ("0".equals(requestStatus)){
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);				
			} else if("1".equals(requestStatus)) {
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ERROR_VO);			
			}	
			
			encounterVO.setUserId(sessionHelper.getUserId());								
			if (searchVO != null) {
				chartEncounterForm.setSelectedClaimType(searchVO.getSelectedClaimType());
				chartEncounterForm.setSelectedClaimRefNbr(searchVO.getSelectedClaimRefNbr());
				chartEncounterForm.setSelectedClaimRevNbr(searchVO.getSelectedClaimRevNbr());
				chartEncounterForm.setSelectedClaimSeqNbr(searchVO.getSelectedClaimSeqNbr());
				chartEncounterForm.setSearchCRDetailSubmitterId(searchVO.getSubmitterId());
				chartEncounterForm.setSearchCRDetailClmType(searchVO.getClmType());
				chartEncounterForm.setSearchCRDetailEncType(searchVO.getEncType());
				chartEncounterForm.setSearchCRDetailDateInd(searchVO.getDateInd());				
				chartEncounterForm.setSearchCRDetailFromDate(searchVO.getFromDate());
				chartEncounterForm.setSearchCRDetailToDate(searchVO.getToDate());
				chartEncounterForm.setSearchCRDetailGroupStatus(searchVO.getGroupStatus());	
				chartEncounterForm.setSearchCRDetailErrorCode(searchVO.getErrorCode());
				chartEncounterForm.setSearchCRDetailErrorGroup(searchVO.getErrorGroup());
				chartEncounterForm.setSearchCRDetailErrorSource(searchVO.getErrorSource());
				chartEncounterForm.setSearchCRDetailClaimRefNbr(searchVO.getClaimRefNbr());
				chartEncounterForm.setSearchCRDetailHicNbr(searchVO.getHicNbr());	
				if (searchVO.getEncType().equals("I")) {
					chartEncounterForm.setInstListExpanded(searchVO.isListExpanded());
					chartEncounterForm.setInstErrorsExpanded(searchVO.isErrorsExpanded());
					chartEncounterForm.setInstSubscriberExpanded(searchVO.isSubscriberExpanded());
					chartEncounterForm.setInstProviderExpanded(searchVO.isProviderExpanded());
					chartEncounterForm.setInstClaimExpanded(searchVO.isClaimExpanded());
					chartEncounterForm.setInstClaimCodesExpanded(searchVO.isClaimCodesExpanded());
					chartEncounterForm.setInstClaimNotesExpanded(searchVO.isClaimNotesExpanded());
					chartEncounterForm.setInstClaimProvExpanded(searchVO.isClaimProvExpanded());
					chartEncounterForm.setInstClaimProvDetailExpanded(searchVO.isClaimProvDetailExpanded());
					chartEncounterForm.setInstClaimOtherSubsProvExpanded(searchVO.isClaimOtherSubsProvExpanded());
					chartEncounterForm.setInstClaimOtherSubsProvDetailExpanded(searchVO.isClaimOtherSubsProvDetailExpanded());
					chartEncounterForm.setInstClaimOtherSubsExpanded(searchVO.isClaimOtherSubsExpanded());
					chartEncounterForm.setInstClaimOtherSubsDetailExpanded(searchVO.isClaimOtherSubsDetailExpanded());
					chartEncounterForm.setInstClaimLineExpanded(searchVO.isClaimLineExpanded());
					chartEncounterForm.setInstClaimLineDetailExpanded(searchVO.isClaimLineDetailExpanded());
					chartEncounterForm.setInstClaimLineProvExpanded(searchVO.isClaimLineProvExpanded());
					chartEncounterForm.setInstClaimLineProvDetailExpanded(searchVO.isClaimLineProvDetailExpanded());
					chartEncounterForm.setInstClaimLineAdjudExpanded(searchVO.isClaimLineAdjudExpanded());
					chartEncounterForm.setInstClaimLineAdjudDetailExpanded(searchVO.isClaimLineAdjudDetailExpanded());					
				} else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")) {
					chartEncounterForm.setProfListExpanded(searchVO.isListExpanded());
					chartEncounterForm.setProfErrorsExpanded(searchVO.isErrorsExpanded());
					chartEncounterForm.setProfSubscriberExpanded(searchVO.isSubscriberExpanded());
					chartEncounterForm.setProfProviderExpanded(searchVO.isProviderExpanded());
					chartEncounterForm.setProfClaimExpanded(searchVO.isClaimExpanded());
					chartEncounterForm.setProfClaimCodesExpanded(searchVO.isClaimCodesExpanded());					
					chartEncounterForm.setProfClaimProvExpanded(searchVO.isClaimProvExpanded());
					chartEncounterForm.setProfClaimProvDetailExpanded(searchVO.isClaimProvDetailExpanded());
					chartEncounterForm.setProfClaimOtherSubsProvExpanded(searchVO.isClaimOtherSubsProvExpanded());
					chartEncounterForm.setProfClaimOtherSubsProvDetailExpanded(searchVO.isClaimOtherSubsProvDetailExpanded());
					chartEncounterForm.setProfClaimOtherSubsExpanded(searchVO.isClaimOtherSubsExpanded());
					chartEncounterForm.setProfClaimOtherSubsDetailExpanded(searchVO.isClaimOtherSubsDetailExpanded());
					chartEncounterForm.setProfClaimLineExpanded(searchVO.isClaimLineExpanded());
					chartEncounterForm.setProfClaimLineDetailExpanded(searchVO.isClaimLineDetailExpanded());
					chartEncounterForm.setProfClaimLineProvExpanded(searchVO.isClaimLineProvExpanded());
					chartEncounterForm.setProfClaimLineProvDetailExpanded(searchVO.isClaimLineProvDetailExpanded());
					chartEncounterForm.setProfClaimLineAdjudExpanded(searchVO.isClaimLineAdjudExpanded());
					chartEncounterForm.setProfClaimLineAdjudDetailExpanded(searchVO.isClaimLineAdjudDetailExpanded());					
				}
				
			}			
			
			chartEncounterForm.setSubscriberDisplayState(ChartConstants.HPE_SCREEN_VIEW);
			chartEncounterForm.setClaimDisplayState(ChartConstants.HPE_SCREEN_VIEW);
			chartEncounterForm.setProviderDisplayState(ChartConstants.HPE_SCREEN_VIEW);
			chartEncounterForm.setClmProviderDisplayState(ChartConstants.HPE_SCREEN_VIEW);
			chartEncounterForm.setDataChanged(false);
			chartEncounterForm.setClmPrvChanged(false);
			
			// Copy the search criteria to the VO
			encounterVO.setSelectedClaimType(chartEncounterForm.getSelectedClaimType());
			encounterVO.setSelectedClaimRefNbr(chartEncounterForm.getSelectedClaimRefNbr());
			encounterVO.setSelectedClaimRevNbr(Integer.parseInt(chartEncounterForm.getSelectedClaimRevNbr()));
			encounterVO.setSelectedClaimSeqNbr(Integer.parseInt(chartEncounterForm.getSelectedClaimSeqNbr()));			
			encounterVO.setSearchDetailSubmitterId(chartEncounterForm.getSearchCRDetailSubmitterId());
			encounterVO.setSearchDetailClmType(chartEncounterForm.getSearchCRDetailClmType());
			encounterVO.setSearchDetailEncType(chartEncounterForm.getSearchCRDetailEncType());
			encounterVO.setSearchDetailDateInd(chartEncounterForm.getSearchCRDetailDateInd());
			encounterVO.setSearchDetailFromDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRDetailFromDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			encounterVO.setSearchDetailToDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRDetailToDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			encounterVO.setSearchDetailClaimRefNbr(chartEncounterForm.getSearchCRDetailClaimRefNbr());
			encounterVO.setSearchDetailHicNbr(chartEncounterForm.getSearchCRDetailHicNbr());
			encounterVO.setSearchDetailGroupStatus(chartEncounterForm.getSearchCRDetailGroupStatus());
			encounterVO.setSearchDetailErrorSource(chartEncounterForm.getSearchCRDetailErrorSource());
			encounterVO.setSearchDetailErrorGroup(chartEncounterForm.getSearchCRDetailErrorGroup());
			encounterVO.setSearchDetailErrorCode(chartEncounterForm.getSearchCRDetailErrorCode());

			// Search & store search results in request scope
			if (encounterVO.getSelectedClaimType().equals("I")) {
				selectInstClaim(conn, sessionHelper, context, chartEncounterForm, request);
				forward = ChartConstants.CHART_INSTDETAIL;
			}
			else
			if (encounterVO.getSearchDetailEncType().equals("P") || encounterVO.getSearchDetailEncType().equals("E")) {
				selectProfClaim(conn, sessionHelper, context, chartEncounterForm, request);
				forward = ChartConstants.CHART_PROFDETAIL;
			}
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return forward;
	}

	public static void selectInstClaim(Connection conn, SessionHelper sessionHelper, HPEContext context, ChartEncounterForm chartEncounterForm, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getChartEncounterVO();

			// Search
			context.getChartEncounterService().selectClaim(conn, encounterVO);
			
			//Editable Fileds CHS -- IFOX-00395627
			chartEncounterForm.setProcessStatus(context.getChartEncounterVO().getInstClaim().getProcessStatus());
			
			if(null != encounterVO.getInstBillingProvider())
				chartEncounterForm.setBillProviderExist("Y");
			
			if(!encounterVO.getInstClaimProviders().isEmpty())
				chartEncounterForm.setClmProviderExist("Y");
			
			// Store search results in request scope
			setInstRequest(encounterVO, request);

		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void setInstRequest(HPEEncounterVO encounterVO, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		// Store search results in request scope
		request.setAttribute("instClaims", encounterVO.getInstClaims());
		request.setAttribute("instClaim", encounterVO.getInstClaim());
		request.setAttribute("instClaimErrors", encounterVO.getInstClaimErrors());
		request.setAttribute("instSubscriber", encounterVO.getInstSubscriber());
		request.setAttribute("instBillingProvider", encounterVO.getInstBillingProvider());
		request.setAttribute("instClaimAdjustments", encounterVO.getInstClaimAdjustments());
		request.setAttribute("instClaimAttachments", encounterVO.getInstClaimAttachments());
		request.setAttribute("instClaimConditions", encounterVO.getInstClaimConditions());
		request.setAttribute("instClaimOccurrences", encounterVO.getInstClaimOccurrences());
		request.setAttribute("instClaimOccurrenceSpans", encounterVO.getInstClaimOccurrenceSpans());
		request.setAttribute("instClaimValues", encounterVO.getInstClaimValues());
		request.setAttribute("instClaimOtherDiagnoses", encounterVO.getInstClaimOtherDiagnoses());
		request.setAttribute("instClaimOtherProcedures", encounterVO.getInstClaimOtherProcedures());
		request.setAttribute("instClaimTreatments", encounterVO.getInstClaimTreatments());
		request.setAttribute("instClaimExternalInjuries", encounterVO.getInstClaimExternalInjuries());			
		request.setAttribute("instClaimProviders", encounterVO.getInstClaimProviders());
		request.setAttribute("instClaimOtherSubscribers", encounterVO.getInstClaimOtherSubscribers());
		request.setAttribute("instClaimOtherSubscriberProviders", encounterVO.getInstClaimOtherSubscriberProviders());
		request.setAttribute("instClaimLines", encounterVO.getInstClaimLines());
		request.setAttribute("instClaimLineProviders", encounterVO.getInstClaimLineProviders());
		request.setAttribute("instClaimLineAttachments", encounterVO.getInstClaimLineAttachments());
		request.setAttribute("instClaimLineAdjudications", encounterVO.getInstClaimLineAdjudications());
		request.setAttribute("instClaimLineAdjudicationAdjustments", encounterVO.getInstClaimLineAdjustments());
		request.setAttribute("instClaimNotes", encounterVO.getInstClaimNotes());
		request.setAttribute("instClmStatlog", encounterVO.getInstClmStatlog());
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void selectProfClaim(Connection conn, SessionHelper sessionHelper, HPEContext context, ChartEncounterForm chartEncounterForm, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getChartEncounterVO();

			// Search
			context.getChartEncounterService().selectClaim(conn, encounterVO);
			
			//Editable Fileds CHS -- IFOX-00395627
			chartEncounterForm.setProcessStatus(context.getChartEncounterVO().getProfClaim().getProcessStatus());
			
			if(null != encounterVO.getProfBillingProvider())
				chartEncounterForm.setBillProviderExist("Y");
			
			if(!encounterVO.getProfClaimProviders().isEmpty())
				chartEncounterForm.setClmProviderExist("Y");

			// Store search results in request scope
			setProfRequest(encounterVO, request);

		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void setProfRequest(HPEEncounterVO encounterVO, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		request.setAttribute("profClaims", encounterVO.getProfClaims());
		request.setAttribute("profClaim", encounterVO.getProfClaim());
		request.setAttribute("profClaimErrors", encounterVO.getProfClaimErrors());
		request.setAttribute("profSubscriber", encounterVO.getProfSubscriber());
		request.setAttribute("profBillingProvider", encounterVO.getProfBillingProvider());
		request.setAttribute("profClaimAdjustments", encounterVO.getProfClaimAdjustments());
		request.setAttribute("profClaimAttachments", encounterVO.getProfClaimAttachments());
		request.setAttribute("profClaimConditions", encounterVO.getProfClaimConditions());
		request.setAttribute("profClaimOtherDiagnoses", encounterVO.getProfClaimOtherDiagnoses());
		request.setAttribute("profClaimProviders", encounterVO.getProfClaimProviders());
		request.setAttribute("profClaimOtherSubscribers", encounterVO.getProfClaimOtherSubscribers());
		request.setAttribute("profClaimOtherSubscriberProviders", encounterVO.getProfClaimOtherSubscriberProviders());
		request.setAttribute("profClaimLines", encounterVO.getProfClaimLines());
		request.setAttribute("profClaimLineProviders", encounterVO.getProfClaimLineProviders());
		request.setAttribute("profClaimLineAttachments", encounterVO.getProfClaimLineAttachments());
		request.setAttribute("profClaimLineReferrals", encounterVO.getProfClaimLineReferrals());
		request.setAttribute("profClaimLineDocuments", encounterVO.getProfClaimLineDocuments());
		request.setAttribute("profClaimLineAdjudications", encounterVO.getProfClaimLineAdjudications());
		request.setAttribute("profClaimLineAdjudicationAdjustments", encounterVO.getProfClaimLineAdjustments());
		request.setAttribute("profClmStatlog", encounterVO.getProfClmStatlog());								
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static String updateFormData(Connection conn, SessionHelper sessionHelper, HPEContext context, ChartEncounterForm chartEncounterForm, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String forward = ChartConstants.CHART_ERROR;		
		
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getChartEncounterVO();					
			
			if (encounterVO.getSelectedClaimType().equals("I")) {
				
				updateInstitutional(conn, sessionHelper, context, chartEncounterForm, request);				
				chartEncounterForm.setInstSubscriberExpanded(true);
			    chartEncounterForm.setInstClaimExpanded(true);

				forward = ChartConstants.CHART_INSTDETAIL;
	    	}						    	
			else
			if (encounterVO.getSearchDetailEncType().equals("P")||encounterVO.getSearchDetailEncType().equals("E")) {

				updateProfessional(conn, sessionHelper, context, chartEncounterForm, request);
				chartEncounterForm.setProfSubscriberExpanded(true);
			    chartEncounterForm.setProfClaimExpanded(true);
				
				forward = ChartConstants.CHART_PROFDETAIL;
			}
		
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		
		logger.info(LoggerConstants.methodEndLevel());
		return forward;
		
	}


	public static void updateInstitutional(Connection conn, SessionHelper sessionHelper, HPEContext context, ChartEncounterForm chartEncounterForm, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		HPEEncounterVO encounterVO = context.getChartEncounterVO();					
		encounterVO.setDisplayMessage("");
		encounterVO.setInstClaimDirty(false);
		encounterVO.setInstSubsDirty(false);
		encounterVO.setInstOthSubsDirty(false);
		
		ChartEncounterService encounterService = context.getChartEncounterService();

		Enc837iBillprvVO newEnc837iBillprvVO = new Enc837iBillprvVO(encounterVO.getInstBillingProvider());
		newEnc837iBillprvVO.setBillPrvOrgName(chartEncounterForm.getBillPrvOrgName());
		newEnc837iBillprvVO.setBillPrvAddrLine1(chartEncounterForm.getBillPrvAddrLine1());
		newEnc837iBillprvVO.setBillPrvAddrLine2(chartEncounterForm.getBillPrvAddrLine2());
		newEnc837iBillprvVO.setBillPrvCity(chartEncounterForm.getBillPrvCity());
		newEnc837iBillprvVO.setBillPrvState(chartEncounterForm.getBillPrvState());							
		newEnc837iBillprvVO.setBillPrvZip(chartEncounterForm.getBillPrvZip());
		newEnc837iBillprvVO.setBillPrvContactName(chartEncounterForm.getBillPrvContactName());
		newEnc837iBillprvVO.setBillPrvCountry(chartEncounterForm.getBillPrvCountry());//
		newEnc837iBillprvVO.setBillPrvCntrySubdCd(chartEncounterForm.getBillPrvCntrySubdCd());//
		newEnc837iBillprvVO.setBillPrvTaxonomyCd(chartEncounterForm.getBillPrvTaxonomyCd());
		newEnc837iBillprvVO.setBillPrvNpi(chartEncounterForm.getBillPrvNpi());
		newEnc837iBillprvVO.setFormattedBillPrvAffilTaxId(chartEncounterForm.getFormattedBillPrvAffilTaxId());
		newEnc837iBillprvVO.setBillPrvComNbrQual1(chartEncounterForm.getBillPrvComNbrQual1());
		newEnc837iBillprvVO.setBillPrvComNbrQual2(chartEncounterForm.getBillPrvComNbrQual2());
		newEnc837iBillprvVO.setBillPrvComNbrQual3(chartEncounterForm.getBillPrvComNbrQual3());
		newEnc837iBillprvVO.setBillPrvComNbr1(chartEncounterForm.getBillPrvComNbr1());
		newEnc837iBillprvVO.setBillPrvComNbr2(chartEncounterForm.getBillPrvComNbr2());
		newEnc837iBillprvVO.setBillPrvComNbr3(chartEncounterForm.getBillPrvComNbr3());
		
		newEnc837iBillprvVO.setP2prvAddrLine1(chartEncounterForm.getP2prvAddrLine1());
		newEnc837iBillprvVO.setP2prvAddrLine2(chartEncounterForm.getP2prvAddrLine2());
		newEnc837iBillprvVO.setP2prvCity(chartEncounterForm.getP2prvCity());
		newEnc837iBillprvVO.setP2prvState(chartEncounterForm.getP2prvState());
		newEnc837iBillprvVO.setP2prvZip(chartEncounterForm.getP2prvZip());
		newEnc837iBillprvVO.setP2prvCountry(chartEncounterForm.getP2prvCountry());//
		newEnc837iBillprvVO.setP2prvCntrySubdCd(chartEncounterForm.getP2prvCntrySubdCd());//
		
		newEnc837iBillprvVO.setP2pOrgName(chartEncounterForm.getP2pOrgName());
		newEnc837iBillprvVO.setP2pPrimPayerId(chartEncounterForm.getP2pPrimPayerId());
		newEnc837iBillprvVO.setP2pLocNbr(chartEncounterForm.getP2pLocNbr());
		newEnc837iBillprvVO.setP2pAddrLine1(chartEncounterForm.getP2pAddrLine1());
		newEnc837iBillprvVO.setP2pPayerIdNbr(chartEncounterForm.getP2pPayerIdNbr());
		newEnc837iBillprvVO.setP2pNaicCd(chartEncounterForm.getP2pNaicCd());
		newEnc837iBillprvVO.setP2pAddrLine2(chartEncounterForm.getP2pAddrLine2());
		newEnc837iBillprvVO.setP2pPrimPlanId(chartEncounterForm.getP2pPrimPlanId());
		newEnc837iBillprvVO.setP2pTaxId(chartEncounterForm.getP2pTaxId());
		newEnc837iBillprvVO.setP2pCity(chartEncounterForm.getP2pCity());
		newEnc837iBillprvVO.setP2pState(chartEncounterForm.getP2pState());
		newEnc837iBillprvVO.setP2pZip(chartEncounterForm.getP2pZip());
		newEnc837iBillprvVO.setP2pCountry(chartEncounterForm.getP2pCountry());
		newEnc837iBillprvVO.setP2pCntrySubdCd(chartEncounterForm.getP2pCntrySubdCd());
		
		Enc837iSubsVO newEnc837iSubsVO = new Enc837iSubsVO(encounterVO.getInstSubscriber());		
		newEnc837iSubsVO.setSubsFirstName(chartEncounterForm.getSubsFirstName());
		newEnc837iSubsVO.setSubsMiddleName(chartEncounterForm.getSubsMiddleName());
		newEnc837iSubsVO.setSubsLastName(chartEncounterForm.getSubsLastName());								
		newEnc837iSubsVO.setBillPrvAffilTaxId(newEnc837iBillprvVO.getBillPrvAffilTaxId());
		newEnc837iSubsVO.setSubsHicNbr(chartEncounterForm.getSubsHicNbr());
		newEnc837iSubsVO.setMbi(chartEncounterForm.getMbi());
		newEnc837iSubsVO.setSubsSsn(DemographicFormatter.unFormatSSN(chartEncounterForm.getFormattedSubsSsn()));								
		newEnc837iSubsVO.setSubsDob(DateFormatter.reFormat(chartEncounterForm.getFormattedSubsDob(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
		newEnc837iSubsVO.setSubsSex(chartEncounterForm.getSubsSex());	
		newEnc837iSubsVO.setSubsAddrLine1(chartEncounterForm.getSubsAddrLine1());
		newEnc837iSubsVO.setSubsAddrLine2(chartEncounterForm.getSubsAddrLine2());
		newEnc837iSubsVO.setSubsCity(chartEncounterForm.getSubsCity());				
		newEnc837iSubsVO.setSubsState(chartEncounterForm.getSubsState());				
		newEnc837iSubsVO.setSubsZip(chartEncounterForm.getSubsZip());

		newEnc837iSubsVO.setSubsMemberId(chartEncounterForm.getSubsMemberId());	
		newEnc837iSubsVO.setSubsCountry(chartEncounterForm.getSubsCountry());
		newEnc837iSubsVO.setSubsGrpName(chartEncounterForm.getSubsGrpName());
		newEnc837iSubsVO.setSubsCntrySubdCd(chartEncounterForm.getSubsCntrySubdCd());				
		newEnc837iSubsVO.setSubsPayerSeqCd(chartEncounterForm.getSubsPayerSeqCd());				
		newEnc837iSubsVO.setSubsRelationCd(chartEncounterForm.getSubsRelationCd());
		newEnc837iSubsVO.setSubsFilingIndCd(chartEncounterForm.getSubsFilingIndCd());
		newEnc837iSubsVO.setSubsEntityType(chartEncounterForm.getSubsEntityType());
		newEnc837iSubsVO.setSubsGrpOrPolNbr(chartEncounterForm.getSubsGrpOrPolNbr());
		
		newEnc837iSubsVO.setPayerName(chartEncounterForm.getPayerName());	
		newEnc837iSubsVO.setPayerId(chartEncounterForm.getPayerId());
		newEnc837iSubsVO.setPayerTaxId(chartEncounterForm.getPayerTaxId());
		newEnc837iSubsVO.setPayerAddrLine1(chartEncounterForm.getPayerAddrLine1());				
		newEnc837iSubsVO.setPayerPlanId(chartEncounterForm.getPayerPlanId());				
		newEnc837iSubsVO.setPayerLocNbr(chartEncounterForm.getPayerLocNbr());
		newEnc837iSubsVO.setPayerAddrLine2(chartEncounterForm.getPayerAddrLine2());
		newEnc837iSubsVO.setPayerNaicCd(chartEncounterForm.getPayerNaicCd());
		newEnc837iSubsVO.setPayerSecId(chartEncounterForm.getPayerSecId());
		newEnc837iSubsVO.setPayerCity(chartEncounterForm.getPayerCity());				
		newEnc837iSubsVO.setPayerState(chartEncounterForm.getPayerState());				
		newEnc837iSubsVO.setPayerZip(chartEncounterForm.getPayerZip());
		newEnc837iSubsVO.setPayerCountry(chartEncounterForm.getPayerCountry());
		newEnc837iSubsVO.setPayerCntrySubdCd(chartEncounterForm.getPayerCntrySubdCd());
		newEnc837iSubsVO.setBillPrvCommNbr(chartEncounterForm.getBillPrvCommNbr());
		newEnc837iSubsVO.setBillPrvLocNbr(chartEncounterForm.getBillPrvLocNbr());
		newEnc837iSubsVO.setPropCasltyClmNbr(chartEncounterForm.getPropCasltyClmNbr());
		
		Enc837iClmVO newEnc837iClmVO = new Enc837iClmVO(encounterVO.getInstClaim());
		//00370957 - Changes
		newEnc837iClmVO.setClmFreqTypeCd(chartEncounterForm.getClmFreqTypeCd());
		newEnc837iClmVO.setProcessStatus(chartEncounterForm.getProcessStatus());
		newEnc837iClmVO.setSubsHicNbr(newEnc837iSubsVO.getSubsHicNbr());
		newEnc837iClmVO.setMbi(newEnc837iSubsVO.getMbi());
		newEnc837iClmVO.setInBillPrvAffilTaxId(newEnc837iBillprvVO.getBillPrvAffilTaxId());
		newEnc837iClmVO.setClmFacTypeCd(chartEncounterForm.getClmFacTypeCd());
		newEnc837iClmVO.setAdmitType(chartEncounterForm.getAdmitType());
		newEnc837iClmVO.setAdmitSourceCd(chartEncounterForm.getAdmitSourceCd());
		newEnc837iClmVO.setAdmitDt(chartEncounterForm.getAdmitDt());
		newEnc837iClmVO.setAdmitHour(chartEncounterForm.getAdmitHour());
		newEnc837iClmVO.setPatientStatusCd(chartEncounterForm.getPatientStatusCd());
		newEnc837iClmVO.setAmbPickupZip(chartEncounterForm.getAmbPickupZip());
		
		newEnc837iClmVO.setPatientCtrlNbr(chartEncounterForm.getPatientCtrlNbr());
		newEnc837iClmVO.setContractTypeCd(chartEncounterForm.getContractTypeCd());
		newEnc837iClmVO.setAdmitDiagType(chartEncounterForm.getAdmitDiagType());
		newEnc837iClmVO.setContractVersionId(chartEncounterForm.getContractVersionId());
		newEnc837iClmVO.setAdmitDiagCd(chartEncounterForm.getAdmitDiagCd());
		newEnc837iClmVO.setContractCd(chartEncounterForm.getContractCd());
		newEnc837iClmVO.setPrvAcceptAssignCd(chartEncounterForm.getPrvAcceptAssignCd());
		newEnc837iClmVO.setReleaseOfInfoCd(chartEncounterForm.getReleaseOfInfoCd());
		newEnc837iClmVO.setAutoAccidentState(chartEncounterForm.getAutoAccidentState());
		newEnc837iClmVO.setDelayReasonCd(chartEncounterForm.getDelayReasonCd());
		newEnc837iClmVO.setDischargeHour(chartEncounterForm.getDischargeHour());
		newEnc837iClmVO.setSvcAuthExcptCd(chartEncounterForm.getSvcAuthExcptCd());
		newEnc837iClmVO.setStatementFromDt(chartEncounterForm.getStatementFromDt());
		newEnc837iClmVO.setDrgCd(chartEncounterForm.getDrgCd());
		newEnc837iClmVO.setStatementToDt(chartEncounterForm.getStatementToDt());
		newEnc837iClmVO.setPayerClmCtrlNbr(chartEncounterForm.getPayerClmCtrlNbr());
		newEnc837iClmVO.setReferralNbr(chartEncounterForm.getReferralNbr());
		newEnc837iClmVO.setPriorAuthNbr(chartEncounterForm.getPriorAuthNbr());
		newEnc837iClmVO.setInvestigDeviceExmptId(chartEncounterForm.getInvestigDeviceExmptId());
		newEnc837iClmVO.setPeerRevewOrgAprvNbr(chartEncounterForm.getPeerRevewOrgAprvNbr());
		newEnc837iClmVO.setMedicalRecordNbr(chartEncounterForm.getMedicalRecordNbr());
		newEnc837iClmVO.setDemonstrationProjectId(chartEncounterForm.getDemonstrationProjectId());
		newEnc837iClmVO.setBillingNotes(chartEncounterForm.getBillingNotes());
		newEnc837iClmVO.setPatVisitreasType1(chartEncounterForm.getPatVisitreasType1());
		newEnc837iClmVO.setPatVisitreasCd1(chartEncounterForm.getPatVisitreasCd1());
		newEnc837iClmVO.setPatVisitreasType2(chartEncounterForm.getPatVisitreasType2());
		newEnc837iClmVO.setPatVisitreasCd2(chartEncounterForm.getPatVisitreasCd2());
		newEnc837iClmVO.setPatVisitreasType3(chartEncounterForm.getPatVisitreasType3());
		newEnc837iClmVO.setPatVisitreasCd3(chartEncounterForm.getPatVisitreasCd3());
		newEnc837iClmVO.setRepricdClmRefNbr(chartEncounterForm.getRepricdClmRefNbr());
		newEnc837iClmVO.setAdjRepricdClmRefNbr(chartEncounterForm.getAdjRepricdClmRefNbr());
		newEnc837iClmVO.setRepricedApprvdDrgCd(chartEncounterForm.getRepricedApprvdDrgCd());
		newEnc837iClmVO.setRepricedApprvdRevCd(chartEncounterForm.getRepricedApprvdRevCd());
		newEnc837iClmVO.setRepricerReceivedDt(chartEncounterForm.getRepricerReceivedDt());
		newEnc837iClmVO.setRepricingOrgId(chartEncounterForm.getRepricingOrgId());
		newEnc837iClmVO.setRepricedUom(chartEncounterForm.getRepricedUom());
		newEnc837iClmVO.setRepricedRejReasonCd(chartEncounterForm.getRepricedRejReasonCd());
		newEnc837iClmVO.setRepricedPolCmpliantCd(chartEncounterForm.getRepricedPolCmpliantCd());
		newEnc837iClmVO.setRepricedExceptionCd(chartEncounterForm.getRepricedExceptionCd());
		
		boolean lastAutoCommit = false;
		boolean inTrans = false;

		String msg = "";
		
		try {
			lastAutoCommit = conn.getAutoCommit();
			conn.setAutoCommit(false);
			inTrans = true;

			msg = encounterService.updateInstBillingProvider(conn, encounterVO, newEnc837iBillprvVO, newEnc837iClmVO);
			if (msg.equals("")) {
				msg = encounterService.updateInstSubscriber(conn, encounterVO, newEnc837iSubsVO, newEnc837iClmVO);
				if (msg.equals("")) {
					msg = encounterService.updateInstClaim(conn, encounterVO, newEnc837iClmVO);
					if (msg.equals("")) {
						msg = encounterService.updateInstOtherSubscriberFromSubscriber(conn, encounterVO, newEnc837iSubsVO);
						if (msg.equals("")) {
						
							Enc837iClmProviderVOs enc837iClmProviderVOs =  encounterVO.getInstClaimProviders();		
							Enc837iClmProviderVO oldVO;
							String frmProvType = chartEncounterForm.getProvType();
							Iterator itr = enc837iClmProviderVOs.iterator();
							int i = 0;
							while (itr.hasNext()){
								oldVO = (Enc837iClmProviderVO)itr.next();
								if (oldVO != null) {
									String provType = oldVO.getProvType();
									if (provType.equals(frmProvType)){	//IFOX-00418160 - NPI Provider fields update

										Enc837iClmProviderVO enc837iClmProviderVO = new Enc837iClmProviderVO(oldVO);
										
										//enc837iClmProviderVO.setProvEntityType(chartEncounterForm.getProvEntityType());
										if (enc837iClmProviderVO.getEffProvEntityType().equals(ChartConstants.HPE_PROVTYPE_PERSON)) {
											enc837iClmProviderVO.setProvFirstName(chartEncounterForm.getProvFirstName());
											enc837iClmProviderVO.setProvMiddleName(chartEncounterForm.getProvMiddleName());
											enc837iClmProviderVO.setProvLastName(chartEncounterForm.getProvLastName());
										} else {
											enc837iClmProviderVO.setProvFirstName("");
											enc837iClmProviderVO.setProvMiddleName("");
											enc837iClmProviderVO.setProvLastName(chartEncounterForm.getProvOrgName());										
										}
										enc837iClmProviderVO.setProvAddrLine1(chartEncounterForm.getProvAddrLine1());
										enc837iClmProviderVO.setProvAddrLine2(chartEncounterForm.getProvAddrLine2());
										enc837iClmProviderVO.setProvCity(chartEncounterForm.getProvCity());
										enc837iClmProviderVO.setProvState(chartEncounterForm.getProvState());
										enc837iClmProviderVO.setProvZip(chartEncounterForm.getProvZip());
										enc837iClmProviderVO.setProvTaxonomyCd(chartEncounterForm.getProvTaxonomyCd());//IFOX-00406065
										enc837iClmProviderVO.setProvNpi(chartEncounterForm.getProvNpi());
										enc837iClmProviderVO.setProvOthPayerId(chartEncounterForm.getProvOthPayerId());
										enc837iClmProviderVO.setProvLocNbr(chartEncounterForm.getProvLocNbr());
										enc837iClmProviderVO.setProvLicNbr(chartEncounterForm.getProvLicNbr());
										enc837iClmProviderVO.setProvUpin(chartEncounterForm.getProvUpin());								
										enc837iClmProviderVO.setProvCommNbr(chartEncounterForm.getProvCommNbr());
										//IFOX-00418160 - NPI Provider fields update - Start
										enc837iClmProviderVO.setProvType(provType);
										enc837iClmProviderVO.setProvTypeNew(frmProvType);
										enc837iClmProviderVO.setProvEntityType(chartEncounterForm.getProvEntityType());
										//IFOX-00418160 - NPI Provider fields update - End
										
										msg = encounterService.updateInstClaimProvider(conn, encounterVO,i,enc837iClmProviderVO);
										break;
									}
								}
								i++;
							}
							if (msg.equals("")) {
								conn.commit();
								inTrans = false;
								
								chartEncounterForm.setSubscriberDisplayState(ChartConstants.HPE_SCREEN_VIEW);
								chartEncounterForm.setClaimDisplayState(ChartConstants.HPE_SCREEN_VIEW);
								chartEncounterForm.setProviderDisplayState(ChartConstants.HPE_SCREEN_VIEW);
								chartEncounterForm.setClmProviderDisplayState(ChartConstants.HPE_SCREEN_VIEW);
								chartEncounterForm.setDataChanged(false);
								chartEncounterForm.setClmPrvChanged(false);
								
								encounterService.refreshUpdatedInst(conn,encounterVO);
							}
						}
					}
				}
			}
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
			msg = "Error updateing Claim";
		} finally {		
			if (inTrans) {
				try {
					conn.rollback();
				} catch(Exception e) {
				}	
			}
			try {
				conn.setAutoCommit(lastAutoCommit);
			} catch(Exception e) {
			}
		}

		// because the changed fields are not saved
		chartEncounterForm.setSubscriberDisplayState(ChartConstants.HPE_SCREEN_VIEW);
		chartEncounterForm.setClaimDisplayState(ChartConstants.HPE_SCREEN_VIEW);
		chartEncounterForm.setProviderDisplayState(ChartConstants.HPE_SCREEN_VIEW);
		chartEncounterForm.setClmProviderDisplayState(ChartConstants.HPE_SCREEN_VIEW);
		chartEncounterForm.setDataChanged(false);
		chartEncounterForm.setClmPrvChanged(false);

		if (msg.equals(""))
			msg = "Update Successful";
		
		chartEncounterForm.setDisplayMessage(msg);
		setInstRequest(encounterVO, request);
		
		chartEncounterForm.setInstSubscriberExpanded(true);
	    chartEncounterForm.setInstClaimExpanded(true);
	    chartEncounterForm.setInstProviderExpanded(true);
	    logger.info(LoggerConstants.methodEndLevel());
	}

	public static void updateProfessional(Connection conn, SessionHelper sessionHelper, HPEContext context, ChartEncounterForm chartEncounterForm, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		HPEEncounterVO encounterVO = context.getChartEncounterVO();					
		encounterVO.setDisplayMessage("");
		encounterVO.setProfClaimDirty(false);
		encounterVO.setProfSubsDirty(false);
		encounterVO.setProfOthSubsDirty(false);
		
		ChartEncounterService encounterService = context.getChartEncounterService();

		Enc837pBillprvVO newEnc837pBillprv = new Enc837pBillprvVO(encounterVO.getProfBillingProvider());
		
		newEnc837pBillprv.setBillPrvEntityType(chartEncounterForm.getBillPrvEntityType());
		if (chartEncounterForm.getBillPrvEntityType().equals(ChartConstants.HPE_PROVTYPE_PERSON)){							
			newEnc837pBillprv.setBillPrvOrgName(chartEncounterForm.getBillPrvLastName());							
			newEnc837pBillprv.setBillPrvFirstName(chartEncounterForm.getBillPrvFirstName());
			newEnc837pBillprv.setBillPrvMiddleName(chartEncounterForm.getBillPrvMiddleName());
		} else {						
			newEnc837pBillprv.setBillPrvOrgName(chartEncounterForm.getBillPrvOrgName());
			newEnc837pBillprv.setBillPrvFirstName("");
			newEnc837pBillprv.setBillPrvMiddleName("");
		}						
		newEnc837pBillprv.setBillPrvAddrLine1(chartEncounterForm.getBillPrvAddrLine1());
		newEnc837pBillprv.setBillPrvAddrLine2(chartEncounterForm.getBillPrvAddrLine2());
		newEnc837pBillprv.setBillPrvCity(chartEncounterForm.getBillPrvCity());
		newEnc837pBillprv.setBillPrvState(chartEncounterForm.getBillPrvState());
		newEnc837pBillprv.setBillPrvZip(chartEncounterForm.getBillPrvZip());	
		newEnc837pBillprv.setBillPrvCountry(chartEncounterForm.getBillPrvCountry());
		newEnc837pBillprv.setBillPrvCntrySubdCd(chartEncounterForm.getBillPrvCntrySubdCd());
		newEnc837pBillprv.setBillPrvTaxonomyCd(chartEncounterForm.getBillPrvTaxonomyCd());
		
		newEnc837pBillprv.setBillPrvNpi(chartEncounterForm.getBillPrvNpi());
		newEnc837pBillprv.setBillPrvLicNbr(chartEncounterForm.getBillPrvLicNbr());
		newEnc837pBillprv.setBillPrvUpin(chartEncounterForm.getBillPrvUpin());
		newEnc837pBillprv.setFormattedBillPrvSsn(chartEncounterForm.getFormattedBillPrvSsn());
		newEnc837pBillprv.setFormattedBillPrvAffilTaxId(chartEncounterForm.getFormattedBillPrvAffilTaxId());
		newEnc837pBillprv.setBillPrvComNbrQual1(chartEncounterForm.getBillPrvComNbrQual1());
		newEnc837pBillprv.setBillPrvComNbrQual2(chartEncounterForm.getBillPrvComNbrQual2());
		newEnc837pBillprv.setBillPrvComNbrQual3(chartEncounterForm.getBillPrvComNbrQual3());
		newEnc837pBillprv.setBillPrvComNbr1(chartEncounterForm.getBillPrvComNbr1());
		newEnc837pBillprv.setBillPrvComNbr2(chartEncounterForm.getBillPrvComNbr2());
		newEnc837pBillprv.setBillPrvComNbr3(chartEncounterForm.getBillPrvComNbr3());
		
		newEnc837pBillprv.setP2prvAddrLine1(chartEncounterForm.getP2prvAddrLine1());
		newEnc837pBillprv.setP2prvAddrLine2(chartEncounterForm.getP2prvAddrLine2());
		newEnc837pBillprv.setP2prvCity(chartEncounterForm.getP2prvCity());
		newEnc837pBillprv.setP2prvState(chartEncounterForm.getP2prvState());
		newEnc837pBillprv.setP2prvZip(chartEncounterForm.getP2prvZip());
		newEnc837pBillprv.setP2prvEntityType(chartEncounterForm.getP2prvEntityType());
		newEnc837pBillprv.setP2prvCountry(chartEncounterForm.getP2prvCountry());
		newEnc837pBillprv.setP2prvCntrySubdCd(chartEncounterForm.getP2prvCntrySubdCd());
		logger.debug("SETTING OF Country is done p2prv " +chartEncounterForm.getP2prvCountry() + "  " + chartEncounterForm.getP2prvCntrySubdCd());
			
		newEnc837pBillprv.setP2pOrgName(chartEncounterForm.getP2pOrgName());
		newEnc837pBillprv.setP2pPrimPayerId(chartEncounterForm.getP2pPrimPayerId());
		newEnc837pBillprv.setP2pLocNbr(chartEncounterForm.getP2pLocNbr());
		newEnc837pBillprv.setP2pAddrLine1(chartEncounterForm.getP2pAddrLine1());
		newEnc837pBillprv.setP2pPayerIdNbr(chartEncounterForm.getP2pPayerIdNbr());
		newEnc837pBillprv.setP2pNaicCd(chartEncounterForm.getP2pNaicCd());
		newEnc837pBillprv.setP2pAddrLine2(chartEncounterForm.getP2pAddrLine2());
		newEnc837pBillprv.setP2pPrimPlanId(chartEncounterForm.getP2pPrimPlanId());
		newEnc837pBillprv.setP2pTaxId(chartEncounterForm.getP2pTaxId());
		newEnc837pBillprv.setP2pCity(chartEncounterForm.getP2pCity());
		newEnc837pBillprv.setP2pState(chartEncounterForm.getP2pState());
		newEnc837pBillprv.setP2pZip(chartEncounterForm.getP2pZip());
		newEnc837pBillprv.setP2pCountry(chartEncounterForm.getP2pCountry());
		newEnc837pBillprv.setP2pCntrySubdCd(chartEncounterForm.getP2pCntrySubdCd());		
		
		Enc837pSubsVO newEnc837pSubs = new Enc837pSubsVO(encounterVO.getProfSubscriber());	

		newEnc837pSubs.setSubsFirstName(chartEncounterForm.getSubsFirstName());
		newEnc837pSubs.setSubsMiddleName(chartEncounterForm.getSubsMiddleName());
		newEnc837pSubs.setSubsLastName(chartEncounterForm.getSubsLastName());								
		newEnc837pSubs.setBillPrvAffilTaxId(newEnc837pBillprv.getBillPrvAffilTaxId());
		newEnc837pSubs.setSubsHicNbr(chartEncounterForm.getSubsHicNbr());
		newEnc837pSubs.setMbi(chartEncounterForm.getMbi());
		newEnc837pSubs.setSubsSsn(DemographicFormatter.unFormatSSN(chartEncounterForm.getFormattedSubsSsn()));								
		newEnc837pSubs.setSubsDob(DateFormatter.reFormat(chartEncounterForm.getFormattedSubsDob(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
		newEnc837pSubs.setSubsSex(chartEncounterForm.getSubsSex());	
		newEnc837pSubs.setSubsAddrLine1(chartEncounterForm.getSubsAddrLine1());
		newEnc837pSubs.setSubsAddrLine2(chartEncounterForm.getSubsAddrLine2());
		newEnc837pSubs.setSubsCity(chartEncounterForm.getSubsCity());				
		newEnc837pSubs.setSubsState(chartEncounterForm.getSubsState());				
		newEnc837pSubs.setSubsZip(chartEncounterForm.getSubsZip());
		newEnc837pSubs.setSubsPayerSeqCd(chartEncounterForm.getSubsPayerSeqCd());
		newEnc837pSubs.setSubsRelationCd(chartEncounterForm.getSubsRelationCd());
		newEnc837pSubs.setSubsFilingIndCd(chartEncounterForm.getSubsFilingIndCd());
		newEnc837pSubs.setSubsInsuranceTypeCd(chartEncounterForm.getSubsInsuranceTypeCd());		
		newEnc837pSubs.setSubsEntityType(chartEncounterForm.getSubsEntityType());
		newEnc837pSubs.setSubsMemberId(chartEncounterForm.getSubsMemberId());
		newEnc837pSubs.setSubsCountry(chartEncounterForm.getSubsCountry());
		newEnc837pSubs.setSubsCntrySubdCd(chartEncounterForm.getSubsCntrySubdCd());
		newEnc837pSubs.setSubsGrpOrPolNbr(chartEncounterForm.getSubsGrpOrPolNbr());
		newEnc837pSubs.setSubsPlanName(chartEncounterForm.getSubsPlanName());
		newEnc837pSubs.setSubsPatDod(chartEncounterForm.getSubsPatDod());
		newEnc837pSubs.setSubsPatWeight(chartEncounterForm.getSubsPatWeight());
		newEnc837pSubs.setSubsPatUom(chartEncounterForm.getSubsPatUom());
		newEnc837pSubs.setSubsPatPregnantInd(chartEncounterForm.getSubsPatPregnantInd());
		newEnc837pSubs.setPayerName(chartEncounterForm.getPayerName());
		newEnc837pSubs.setPayerId(chartEncounterForm.getPayerId());
		newEnc837pSubs.setPayerPlanId(chartEncounterForm.getPayerPlanId());
		newEnc837pSubs.setPayerAddrLine1(chartEncounterForm.getPayerAddrLine1());
		newEnc837pSubs.setPayerAddrLine2(chartEncounterForm.getPayerAddrLine2());
		newEnc837pSubs.setPayerCity(chartEncounterForm.getPayerCity());
		newEnc837pSubs.setPayerState(chartEncounterForm.getPayerState());
		newEnc837pSubs.setPayerZip(chartEncounterForm.getPayerZip());
		newEnc837pSubs.setPayerCountry(chartEncounterForm.getPayerCountry());
		newEnc837pSubs.setPayerCntrySubdCd(chartEncounterForm.getPayerCntrySubdCd());
		newEnc837pSubs.setPayerTaxId(chartEncounterForm.getPayerTaxId());
		newEnc837pSubs.setPayerLocNbr(chartEncounterForm.getPayerLocNbr());
		newEnc837pSubs.setPayerNaicCd(chartEncounterForm.getPayerNaicCd());
		newEnc837pSubs.setPayerSecId(chartEncounterForm.getPayerSecId());
		logger.debug(" Updated data for Payer Info ");
		
		newEnc837pSubs.setBillPrvCommNbr(chartEncounterForm.getBillPrvCommNbr());
		newEnc837pSubs.setBillPrvLocNbr(chartEncounterForm.getBillPrvLocNbr());
		newEnc837pSubs.setPropCasltyClmNbr(chartEncounterForm.getPropCasltyClmNbr());
		newEnc837pSubs.setPropCasltySubsName(chartEncounterForm.getPropCasltySubsName());
		newEnc837pSubs.setPropCasltySubsPhone(chartEncounterForm.getPropCasltySubsPhone());
		newEnc837pSubs.setPropCasltySubsPhnExt(chartEncounterForm.getPropCasltySubsPhnExt());
		
		logger.debug("Helper HPEInstHelper.java0" + newEnc837pSubs.toString());

		Enc837pClmVO newEnc837pClmVO = new Enc837pClmVO(encounterVO.getProfClaim());
		newEnc837pClmVO.setProcessStatus(chartEncounterForm.getProcessStatus());
		newEnc837pClmVO.setPlaceOfService(chartEncounterForm.getPlaceOfService());
		newEnc837pClmVO.setSubsHicNbr(newEnc837pSubs.getSubsHicNbr());
		newEnc837pClmVO.setMbi(newEnc837pSubs.getMbi());
		newEnc837pClmVO.setInBillPrvAffilTaxId(newEnc837pBillprv.getBillPrvAffilTaxId());
		newEnc837pClmVO.setMammogramCertNbr(chartEncounterForm.getMammogramCertNbr());
		newEnc837pClmVO.setCliaNbr(chartEncounterForm.getCliaNbr());
		newEnc837pClmVO.setHospAdmitDt(chartEncounterForm.getHospAdmitDt());
		newEnc837pClmVO.setHospDischargeDt(chartEncounterForm.getHospDischargeDt());
		newEnc837pClmVO.setCliaNbr(chartEncounterForm.getCliaNbr());
		newEnc837pClmVO.setAmbPickupAddrLine1(chartEncounterForm.getAmbPickupAddrLine1());
		newEnc837pClmVO.setAmbPickupAddrLine2(chartEncounterForm.getAmbPickupAddrLine2());
		newEnc837pClmVO.setAmbPickupCity(chartEncounterForm.getAmbPickupCity());
		newEnc837pClmVO.setAmbPickupState(chartEncounterForm.getAmbPickupState());
		newEnc837pClmVO.setAmbPickupZip(chartEncounterForm.getAmbPickupZip());
		newEnc837pClmVO.setAmbDropoffLoc(chartEncounterForm.getAmbDropoffLoc());
		newEnc837pClmVO.setAmbDropoffAddrLine1(chartEncounterForm.getAmbDropoffAddrLine1());
		newEnc837pClmVO.setAmbDropoffAddrLine2(chartEncounterForm.getAmbDropoffAddrLine2());
		newEnc837pClmVO.setAmbDropoffCity(chartEncounterForm.getAmbDropoffCity());
		newEnc837pClmVO.setAmbDropoffState(chartEncounterForm.getAmbDropoffState());
		newEnc837pClmVO.setAmbDropoffZip(chartEncounterForm.getAmbDropoffZip());
		
		//Setting new Feids for Claims...
		newEnc837pClmVO.setPatientCtrlNbr(chartEncounterForm.getPatientCtrlNbr());
		//newEnc837pClmVO.setWtxClaimRefNbr(chartEncounterForm.getWtxClaimRefNbr());
		newEnc837pClmVO.setContractVersionId(chartEncounterForm.getContractVersionId());
		newEnc837pClmVO.setContractCd(chartEncounterForm.getContractCd());
		newEnc837pClmVO.setSvcFacContactName(chartEncounterForm.getSvcFacContactName());
		newEnc837pClmVO.setSvcFacPhone(chartEncounterForm.getSvcFacPhone());
		newEnc837pClmVO.setSvcFacPhoneExt(chartEncounterForm.getSvcFacPhoneExt());
		newEnc837pClmVO.setSvcAuthExcptCd(chartEncounterForm.getSvcAuthExcptCd());
		newEnc837pClmVO.setAnestSurgProcCd1(chartEncounterForm.getAnestSurgProcCd1());
		newEnc837pClmVO.setAnestSurgProcCd2(chartEncounterForm.getAnestSurgProcCd2());
		newEnc837pClmVO.setVisnCertCondInd(chartEncounterForm.getVisnCertCondInd());
		newEnc837pClmVO.setAutoAccidentCountry(chartEncounterForm.getAutoAccidentCountry());
		newEnc837pClmVO.setClaimRefCd(chartEncounterForm.getClaimRefCd());
		newEnc837pClmVO.setPatSignatureSrcCd(chartEncounterForm.getPatSignatureSrcCd());
		newEnc837pClmVO.setMedicareCrossoverCd(chartEncounterForm.getMedicareCrossoverCd());
		newEnc837pClmVO.setLabHomeRespCd(chartEncounterForm.getLabHomeRespCd());
		newEnc837pClmVO.setLabHomeCondInd(chartEncounterForm.getLabHomeCondInd());
		newEnc837pClmVO.setVisnCodeCategory(chartEncounterForm.getVisnCodeCategory());
		newEnc837pClmVO.setContractTypeCd(chartEncounterForm.getContractTypeCd());
		newEnc837pClmVO.setPrvAcceptAssignCd(chartEncounterForm.getPrvAcceptAssignCd());
		newEnc837pClmVO.setReleaseOfInfoCd(chartEncounterForm.getReleaseOfInfoCd());
		newEnc837pClmVO.setAutoAccidentState(chartEncounterForm.getAutoAccidentState());
		newEnc837pClmVO.setOtherAccidentInd(chartEncounterForm.getOtherAccidentInd());
		newEnc837pClmVO.setPrvSignatureOnfileInd(chartEncounterForm.getPrvSignatureOnfileInd());
		newEnc837pClmVO.setDelayReasonCd(chartEncounterForm.getDelayReasonCd());
		newEnc837pClmVO.setBeneAssignCertInd(chartEncounterForm.getBeneAssignCertInd());
		newEnc837pClmVO.setVisnCertCondCd1(chartEncounterForm.getVisnCertCondCd1());
		newEnc837pClmVO.setVisnCertCondCd2(chartEncounterForm.getVisnCertCondCd2());
		newEnc837pClmVO.setVisnCertCondCd3(chartEncounterForm.getVisnCertCondCd3());
		//newEnc837pClmVO.setWtxClaimRevNbr(chartEncounterForm.getWtxClaimRevNbr()); /*To add revision number in  claim number IFOX 367728*/
		newEnc837pClmVO.setClmFreqTypeCd(chartEncounterForm.getClmFreqTypeCd());
		newEnc837pClmVO.setEmploymentAccidentInd(chartEncounterForm.getEmploymentAccidentInd());
		newEnc837pClmVO.setAutoAccidentInd(chartEncounterForm.getAutoAccidentInd());
		newEnc837pClmVO.setEpsdtCondInd1(chartEncounterForm.getEpsdtCondInd1());
		newEnc837pClmVO.setEpsdtCondInd2(chartEncounterForm.getEpsdtCondInd2());
		newEnc837pClmVO.setEpsdtCondInd3(chartEncounterForm.getEpsdtCondInd3());
		newEnc837pClmVO.setVisnCertCondCd4(chartEncounterForm.getVisnCertCondCd4());
		newEnc837pClmVO.setVisnCertCondCd5(chartEncounterForm.getVisnCertCondCd5());
		newEnc837pClmVO.setPayerClmCtrlNbr(chartEncounterForm.getPayerClmCtrlNbr());
		newEnc837pClmVO.setPriorAuthNbr(chartEncounterForm.getPriorAuthNbr());
		newEnc837pClmVO.setValueAddNtwkTraceNbr(chartEncounterForm.getValueAddNtwkTraceNbr());
		newEnc837pClmVO.setCarePlanOversightNbr(chartEncounterForm.getCarePlanOversightNbr());
		newEnc837pClmVO.setClaimNotes(chartEncounterForm.getClaimNotes());
		newEnc837pClmVO.setReferralNbr(chartEncounterForm.getReferralNbr());
		newEnc837pClmVO.setInvestigDeviceExempId(chartEncounterForm.getInvestigDeviceExempId());
		newEnc837pClmVO.setMedicalRecordNbr(chartEncounterForm.getMedicalRecordNbr());
		newEnc837pClmVO.setDemonstrationProjId(chartEncounterForm.getDemonstrationProjId());
		newEnc837pClmVO.setIllnessOccurDt(chartEncounterForm.getFormattedIllnessOccurDt());
		newEnc837pClmVO.setLastMenstrualPerDt(chartEncounterForm.getFormattedLastMenstrualPerDt());
		newEnc837pClmVO.setDisabilityStartDt(chartEncounterForm.getFormattedDisabilityStartDt());
		newEnc837pClmVO.setAsumdCareStartDt(chartEncounterForm.getFormattedAsumdCareStartDt());
		newEnc837pClmVO.setPatientCondCd(chartEncounterForm.getPatientCondCd());
		newEnc837pClmVO.setInitialTreatmentDt(chartEncounterForm.getFormattedInitialTreatmentDt());
		newEnc837pClmVO.setLastXrayDt(chartEncounterForm.getFormattedLastXrayDt());
		newEnc837pClmVO.setDisabilityEndDt(chartEncounterForm.getFormattedDisabilityEndDt());
		newEnc837pClmVO.setAsumdCareEndDt(chartEncounterForm.getFormattedAsumdCareEndDt());
		newEnc837pClmVO.setLastSeenDt(chartEncounterForm.getFormattedLastSeenDt());
		newEnc837pClmVO.setHearVisionDt(chartEncounterForm.getFormattedHearVisionDt());
		newEnc837pClmVO.setLastWorkedDt(chartEncounterForm.getFormattedLastWorkedDt());
		newEnc837pClmVO.setFirstVisitConsultDt(chartEncounterForm.getFormattedFirstVisitConsultDt());
		newEnc837pClmVO.setAcuteManifestationDt(chartEncounterForm.getFormattedAcuteManifestationDt());
		newEnc837pClmVO.setAuthReturnWorkDt(chartEncounterForm.getFormattedAuthReturnWorkDt());
		newEnc837pClmVO.setAccidentDt(chartEncounterForm.getFormattedAccidentDt());
		newEnc837pClmVO.setRoundTripPurposeDesc(chartEncounterForm.getRoundTripPurposeDesc());
		newEnc837pClmVO.setStretcherPurposeDesc(chartEncounterForm.getStretcherPurposeDesc());
		newEnc837pClmVO.setAmbPatWeight(chartEncounterForm.getAmbPatWeight());
		newEnc837pClmVO.setAmbCertCondInd(chartEncounterForm.getAmbCertCondInd());
		newEnc837pClmVO.setAmbPickupCountry(chartEncounterForm.getAmbPickupCountry());
		newEnc837pClmVO.setAmbCertCondCd1(chartEncounterForm.getAmbCertCondCd1());
		newEnc837pClmVO.setAmbCertCondCd2(chartEncounterForm.getAmbCertCondCd2());
		newEnc837pClmVO.setAmbCertCondCd3(chartEncounterForm.getAmbCertCondCd3());
		newEnc837pClmVO.setAmbDropoffCountry(chartEncounterForm.getAmbDropoffCountry());
		newEnc837pClmVO.setAmbTranspDistance(chartEncounterForm.getAmbTranspDistance());
		newEnc837pClmVO.setAmbTranspReasonCd(chartEncounterForm.getAmbTranspReasonCd());
		newEnc837pClmVO.setAmbPickupCntrySubd(chartEncounterForm.getAmbPickupCntrySubd());
		newEnc837pClmVO.setAmbCertCondCd4(chartEncounterForm.getAmbCertCondCd4());
		newEnc837pClmVO.setAmbCertCondCd5(chartEncounterForm.getAmbCertCondCd5());
		newEnc837pClmVO.setAmbDropoffCntrySubd(chartEncounterForm.getAmbDropoffCntrySubd());
		//end of setting new Feilds for Calims...
		
		boolean lastAutoCommit = false;
		boolean inTrans = false;

		String msg = "";
		
		try {
			lastAutoCommit = conn.getAutoCommit();
			conn.setAutoCommit(false);
			inTrans = true;

			msg = encounterService.updateProfBillingProvider(conn, encounterVO, newEnc837pBillprv, newEnc837pClmVO);
			if (msg.equals("")) {
				msg = encounterService.updateProfSubscriber(conn, encounterVO, newEnc837pSubs, newEnc837pClmVO);
				if (msg.equals("")) {
					msg = encounterService.updateProfClaim(conn, encounterVO, newEnc837pClmVO);
					if (msg.equals("")) {
						msg = encounterService.updateProfOtherSubscriberFromSubscriber(conn, encounterVO, newEnc837pSubs);
						if (msg.equals("")) {
							Enc837pClmProviderVOs enc837pClmProviderVOs =  encounterVO.getProfClaimProviders();
							String frmProvType = chartEncounterForm.getProvType();
							Enc837pClmProviderVO oldVO;
							Iterator itr = enc837pClmProviderVOs.iterator();
							int i = 0;
							while (itr.hasNext()){
								oldVO = (Enc837pClmProviderVO)itr.next();
								if (oldVO != null) {
									String provType = oldVO.getProvType();
									if (provType.equals(frmProvType)){	//IFOX-00418160 - NPI Provider fields update
										
										Enc837pClmProviderVO enc837pClmProviderVO = new Enc837pClmProviderVO(oldVO);

										enc837pClmProviderVO.setProvEntityType(StringUtil.nonNullTrim(chartEncounterForm.getProvEntityType()));
										if (enc837pClmProviderVO.getEffProvEntityType().equals(ChartConstants.HPE_PROVTYPE_PERSON)) {
											enc837pClmProviderVO.setProvFirstName(chartEncounterForm.getProvFirstName());
											enc837pClmProviderVO.setProvMiddleName(chartEncounterForm.getProvMiddleName());
											enc837pClmProviderVO.setProvLastName(chartEncounterForm.getProvLastName());
										} else {
											enc837pClmProviderVO.setProvFirstName("");
											enc837pClmProviderVO.setProvMiddleName("");
											enc837pClmProviderVO.setProvLastName(chartEncounterForm.getProvOrgName());										
										}

										enc837pClmProviderVO.setProvAddrLine1(chartEncounterForm.getProvAddrLine1());
										enc837pClmProviderVO.setProvAddrLine2(chartEncounterForm.getProvAddrLine2());
										enc837pClmProviderVO.setProvCity(chartEncounterForm.getProvCity());
										enc837pClmProviderVO.setProvState(chartEncounterForm.getProvState());
										enc837pClmProviderVO.setProvZip(chartEncounterForm.getProvZip());
										enc837pClmProviderVO.setProvTaxonomyCd(chartEncounterForm.getProvTaxonomyCd());
										enc837pClmProviderVO.setProvNpi(chartEncounterForm.getProvNpi());
										enc837pClmProviderVO.setProvOthPayerId(chartEncounterForm.getProvOthPayerId());
										enc837pClmProviderVO.setProvLocNbr(chartEncounterForm.getProvLocNbr());
										enc837pClmProviderVO.setProvLicNbr(chartEncounterForm.getProvLicNbr());
										enc837pClmProviderVO.setProvUpin(chartEncounterForm.getProvUpin());								
										enc837pClmProviderVO.setProvCommNbr(chartEncounterForm.getProvCommNbr());
										//IFOX-00418160 - NPI Provider fields update - Start
										enc837pClmProviderVO.setProvType(provType);
										enc837pClmProviderVO.setProvTypeNew(frmProvType);
										enc837pClmProviderVO.setProvEntityType(chartEncounterForm.getProvEntityType());
										//IFOX-00418160 - NPI Provider fields update - End
										
										msg = encounterService.updateProfClaimProvider(conn, encounterVO,i,enc837pClmProviderVO);
										break;

									}
								}
								i++;
							}
							if (msg.equals("")) {
								conn.commit();
								inTrans = false;
								
								chartEncounterForm.setSubscriberDisplayState(ChartConstants.HPE_SCREEN_VIEW);
								chartEncounterForm.setClaimDisplayState(ChartConstants.HPE_SCREEN_VIEW);
								chartEncounterForm.setProviderDisplayState(ChartConstants.HPE_SCREEN_VIEW);
								chartEncounterForm.setClmProviderDisplayState(ChartConstants.HPE_SCREEN_VIEW);
								chartEncounterForm.setDataChanged(false);
								chartEncounterForm.setClmPrvChanged(false);
								
								encounterService.refreshUpdatedProf(conn,encounterVO);
							}

						}						
					}
				}
			}
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
			msg = "Error updateing Claim";
		} finally {		
			if (inTrans) {
				try {
					conn.rollback();
				} catch(Exception e) {
				}	
			}
			try {
				conn.setAutoCommit(lastAutoCommit);
			} catch(Exception e) {
			}
		}

		if (msg.equals("")) {
			msg = "Update Successfull";
		}

		// because the changed fields are not saved
		chartEncounterForm.setSubscriberDisplayState(ChartConstants.HPE_SCREEN_VIEW);
		chartEncounterForm.setClaimDisplayState(ChartConstants.HPE_SCREEN_VIEW);
		chartEncounterForm.setProviderDisplayState(ChartConstants.HPE_SCREEN_VIEW);
		chartEncounterForm.setClmProviderDisplayState(ChartConstants.HPE_SCREEN_VIEW);
		chartEncounterForm.setDataChanged(false);
		chartEncounterForm.setClmPrvChanged(false);

		chartEncounterForm.setDisplayMessage(msg);
		setProfRequest(encounterVO, request);
		
		chartEncounterForm.setProfSubscriberExpanded(true);
	    chartEncounterForm.setProfClaimExpanded(true);
	    chartEncounterForm.setProfProviderExpanded(true);
	    logger.info(LoggerConstants.methodEndLevel());
	}
	
	
	/*
	 * Method to retrieve the selected claim change log details 
	 */
	public static String getClaimChangeLogDetails(Connection conn, SessionHelper sessionHelper, HPEContext context, ChartEncounterForm chartEncounterForm, HttpServletRequest request)
	throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String forward = ChartConstants.CHART_ERROR;
		String mfId = "";
		String claimRefNbr = "";
		int claimRevNbr = 0;
		int claimSeqNbr = 0;
		String claimType = "";
		String recordKey = "";
		Enc837ChangeClaimlogVOs claimLogList = null;
		boolean historyFlag = false;
		
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getChartEncounterVO();
			mfId = encounterVO.getMfId();
			claimRefNbr = encounterVO.getSelectedClaimRefNbr();
			claimRevNbr = encounterVO.getSelectedClaimRevNbr();
			claimSeqNbr = encounterVO.getSelectedClaimSeqNbr();	
			claimType = encounterVO.getSearchDetailClmType();	
			//recordKey = mfId + "|" + claimRefNbr + "|" + claimRevNbr + "|" + claimSeqNbr;
			
			claimLogList = context.getChartEncounterService().getChangeLogDetails(conn, encounterVO,historyFlag);
			
			chartEncounterForm.setSelClaimType(claimType);
			/*To add revision number in
			 *  claim number IFOX 367728*/
		
			 HttpSession session =  sessionHelper.getSession();
				
				request.setAttribute("claimRefNbr",claimRefNbr);
				
				 if("TRUE".equals(session.getAttribute(ChartConstants.UNIQUE_PROFILE))){
					 DecimalFormat df = new DecimalFormat("00");
						request.setAttribute("claimRefUnqNbr",claimRefNbr.substring(0,3)+ df.format(claimRevNbr) + claimRefNbr.substring(5));	
				}
						request.setAttribute("claimRevNbr",String.valueOf(claimRevNbr));
						/*To add revision number in
			 *  claim number IFOX 367728*/
			request.setAttribute("claimSeqNbr",String.valueOf(claimSeqNbr));
			request.setAttribute("claimType",claimType);
			request.setAttribute("historyFlag",String.valueOf(historyFlag));
			request.setAttribute("CHANGE_LOG_LIST",claimLogList);
				
			forward = ChartConstants.CHART_CHANGELOG;
			
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return forward;
	}
	
	/*
	 * Method to retrieve the selected claim change log details 
	 */
	public static String getClaimChangeLogHistory(Connection conn, SessionHelper sessionHelper, HPEContext context, ChartEncounterForm chartEncounterForm, HttpServletRequest request)
	throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String forward = ChartConstants.CHART_ERROR;
		String mfId = "";
		String claimRefNbr = "";
		int claimRevNbr = 0;/*To add revision number in  claim number IFOX 367728*/
		int claimSeqNbr = 0;
		String claimType = "";
		String recordKey = "";
		Enc837ChangeClaimlogVOs claimLogList = null;	
		boolean historyFlag = true;
		
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getChartEncounterVO();
			mfId = encounterVO.getMfId();
			claimRefNbr = encounterVO.getSelectedClaimRefNbr();
			claimRevNbr = encounterVO.getSelectedClaimRevNbr();/*To add revision number in  claim number IFOX 367728*/
			/*claimSeqNbr = encounterVO.getSelectedClaimSeqNbr();	*/
			/*To add revision number in
			 *  claim number IFOX 367728*/
		
			 HttpSession session =  sessionHelper.getSession();
				
				request.setAttribute("claimRefNbr",claimRefNbr);
				
				 if("TRUE".equals(session.getAttribute(ChartConstants.UNIQUE_PROFILE))){
					 DecimalFormat df = new DecimalFormat("00");
						request.setAttribute("claimRefUnqNbr",claimRefNbr.substring(0,3)+ df.format(claimRevNbr) + claimRefNbr.substring(5));	
				}
		
			request.setAttribute("claimRevNbr",String.valueOf(claimRevNbr));
			/*To add revision number in
			 *  claim number IFOX 367728*/
			claimType = encounterVO.getSearchDetailClmType();			
			
			claimLogList = context.getChartEncounterService().getChangeLogDetails(conn, encounterVO,historyFlag);
			
			chartEncounterForm.setSelClaimType(claimType);
			request.setAttribute("claimRefNbr",claimRefNbr);
			request.setAttribute("claimRevNbr",claimRevNbr);
			request.setAttribute("claimSeqNbr",String.valueOf(claimSeqNbr));
			request.setAttribute("claimType",claimType);
			request.setAttribute("historyFlag",String.valueOf(historyFlag));
			request.setAttribute("CHANGE_LOG_LIST",claimLogList);
				
			forward = ChartConstants.CHART_CHANGELOG;
			
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return forward;
	}
	
	public static String displayCRClaims(Connection conn, SessionHelper sessionHelper, HPEContext context, ChartEncounterForm chartEncounterForm, HttpServletRequest request)
	throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String forward = ChartConstants.CHART_ERROR;
		HpeSearchVO searchVO = null;
		String requestStatus = null;

		try {			
			// Get the VO
			HPEEncounterVO encounterVO = context.getChartEncounterVO();

			// Set customer
			encounterVO.setMfId(/* "HCFLCS4" */ sessionHelper.getMfId() /* "HCF0031" */);
			
						
			chartEncounterForm.setSearchCRDetailSubmitterId(chartEncounterForm.getSubmitterId());				
			chartEncounterForm.setSearchCRDetailEncType(chartEncounterForm.getClaimType());
			chartEncounterForm.setSearchCRDetailClmType(chartEncounterForm.getClmType());
			chartEncounterForm.setSearchCRDetailClaimRefNbr(chartEncounterForm.getClaimRefNbr());
			chartEncounterForm.setSearchCRDetailDateInd(chartEncounterForm.getDateInd());
			chartEncounterForm.setSearchCRDetailFromDate("");
			chartEncounterForm.setSearchCRDetailToDate("");
			chartEncounterForm.setSearchCRDetailGroupStatus("");
			chartEncounterForm.setSearchCRDetailErrorCode("");
			chartEncounterForm.setSearchCRDetailErrorGroup("");
			chartEncounterForm.setSearchCRDetailErrorSource("");
			chartEncounterForm.setPrevMenu(chartEncounterForm.getPrevMenu());
			chartEncounterForm.setPrevMethod(chartEncounterForm.getPrevMethod());			

			// Copy the search criteria to the VO
			encounterVO.setSearchDetailSubmitterId(chartEncounterForm.getSearchCRDetailSubmitterId());
			encounterVO.setSearchDetailClmType(chartEncounterForm.getSearchCRDetailClmType());
			encounterVO.setSearchDetailEncType(chartEncounterForm.getSearchCRDetailEncType());
			encounterVO.setSearchDetailDateInd(chartEncounterForm.getSearchCRDetailDateInd());
			encounterVO.setSearchDetailFromDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRDetailFromDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			encounterVO.setSearchDetailToDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRDetailToDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			encounterVO.setSearchDetailClaimRefNbr(chartEncounterForm.getSearchCRDetailClaimRefNbr());
			encounterVO.setSearchDetailHicNbr(chartEncounterForm.getSearchCRDetailHicNbr());
			encounterVO.setSearchDetailGroupStatus(chartEncounterForm.getSearchCRDetailGroupStatus());
			encounterVO.setSearchDetailErrorSource(chartEncounterForm.getSearchCRDetailErrorSource());
			encounterVO.setSearchDetailErrorGroup(chartEncounterForm.getSearchCRDetailErrorGroup());
			encounterVO.setSearchDetailErrorCode(chartEncounterForm.getSearchCRDetailErrorCode());

			if (encounterVO.getSearchDetailEncType().equals("I")) {
				pageInstClaims(conn, sessionHelper, context, chartEncounterForm, request, "first",requestStatus);
				forward = ChartConstants.CHART_INSTDETAIL;
			}
			else
			if (encounterVO.getSearchDetailEncType().equals("P") || encounterVO.getSearchDetailEncType().equals("E")) {
				pageProfClaims(conn, sessionHelper, context, chartEncounterForm, request, "first",requestStatus,encounterVO.getSearchDetailEncType());//DME_Dashboard_changes
				forward = ChartConstants.CHART_PROFDETAIL;				
			}
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return forward;
	}
	
	//Editable Fileds CHS -- IFOX-00395627
	
			public static String EditableUpdateCodes(Connection conn, SessionHelper sessionHelper, HPEContext context, HttpServletRequest request, ChartEncounterForm chartEncounterForm, String flagInd)
					throws ApplicationException {
				logger.info(LoggerConstants.methodStartLevel());
				String forward = HPEConstants.HPE_ERROR;
				String obj ="";
				HashMap<String,String> hm=new HashMap<String,String>();
				HPEEncounterVO encounterVO = new HPEEncounterVO();
			    
				String uid = sessionHelper.getUserId();
				
				ChartEncounterService encounterService = context.getChartEncounterService();
				int sqlCnt = -1;
				
				try {
					
					if(StringUtils.isNotEmpty(chartEncounterForm.getHier())){
						
						encounterVO.setHier(chartEncounterForm.getHier());
						encounterVO.setEditableMfid(chartEncounterForm.getEditableMfid());
						if(chartEncounterForm.getEditableCndSeqNbr()!=null){
							encounterVO.setEditableCndSeqNbr(Integer.parseInt(chartEncounterForm.getEditableCndSeqNbr()));
						}
					
						encounterVO.setSearchDetailClmType(chartEncounterForm.getSelectedClaimType());
						encounterVO.setSearchDetailEncType(chartEncounterForm.getEditableEncType());
						encounterVO.setSelectedClaimRefNbr(chartEncounterForm.getSelectedClaimRefNbr());
						encounterVO.setSelectedClaimRevNbr(Integer.parseInt(chartEncounterForm.getSelectedClaimRevNbr()));
						encounterVO.setSelectedClaimSeqNbr(Integer.parseInt(chartEncounterForm.getSelectedClaimSeqNbr()));
					//	encounterVO.setFirstClaimType(chartEncounterForm.getFirstClaimRefNbr());
						encounterVO.setUserId(uid);
						
						 if(HPEConstants.EDITABLE_COND_CODE_CNSTNT.equals(chartEncounterForm.getHier()) || HPEConstants.EDITABLE_TREATMENT_CODE_CNSTNT.equals(chartEncounterForm.getHier())){					
							 encounterVO.setEditableCode(chartEncounterForm.getEditableCode());
						 }
						 
						 if(HPEConstants.EDITABLE_DIAG_CODE_CNSTNT.equals(chartEncounterForm.getHier()) || HPEConstants.EDITABLE_EXT_INJ_CODE_CNSTNT.equals(chartEncounterForm.getHier())){
							    encounterVO.setEditableCode(chartEncounterForm.getEditableCode());
								encounterVO.setEditablePOA(chartEncounterForm.getEditablePOA());
								encounterVO.setEditableType(chartEncounterForm.getEditableType()); 
						 }
						 
						 if(HPEConstants.EDITABLE_PROCEDURE_CODE_CNSTNT.equals(chartEncounterForm.getHier())){
							 encounterVO.setEditableType(chartEncounterForm.getEditableType());
							  encounterVO.setEditableCode(chartEncounterForm.getEditableCode());
							
							  if(StringUtils.isNotEmpty(chartEncounterForm.getEditableDate())){
								    String frmDt = chartEncounterForm.getEditableDate(); 							
									String arr[] = frmDt.split("/");							
									String modDt = arr[2]+arr[0]+arr[1];
									encounterVO.setEditableDate(modDt);
							 }
						 }
						 if(HPEConstants.EDITABLE_OCCURSPAN_CODE_CNSTNT.equals(chartEncounterForm.getHier())){
							 encounterVO.setEditableCode(chartEncounterForm.getEditableCode());
							 
							 if(StringUtils.isNotEmpty(chartEncounterForm.getEditableFromDt())){
								    String frmDt = chartEncounterForm.getEditableFromDt(); 							
									String arr[] = frmDt.split("/");							
									String modDt = arr[2]+arr[0]+arr[1];
									encounterVO.setEditableFromDt(modDt);
							 }
							 if(StringUtils.isNotEmpty(chartEncounterForm.getEditableThruDt())){
								    String thruDt = chartEncounterForm.getEditableThruDt(); 							
									String arr[] = thruDt.split("/");							
									String modDt = arr[2]+arr[0]+arr[1];
									encounterVO.setEditableThruDt(modDt);
							 }						 
							
						 }
						 if(HPEConstants.EDITABLE_VALUE_CODE_CNSTNT.equals(chartEncounterForm.getHier())){
							 encounterVO.setEditableCode(chartEncounterForm.getEditableCode());
							 encounterVO.setEditableAmount(chartEncounterForm.getEditableAmount());
							 
						 }
						 if(HPEConstants.EDITABLE_OCCURENCE_CODE_CNSTNT.equals(chartEncounterForm.getHier())){
							 encounterVO.setEditableCode(chartEncounterForm.getEditableCode());
							
							 if(StringUtils.isNotEmpty(chartEncounterForm.getEditableDate())){
								    String frmDt = chartEncounterForm.getEditableDate(); 							
									String arr[] = frmDt.split("/");							
									String modDt = arr[2]+arr[0]+arr[1];
									encounterVO.setEditableDate(modDt);
							 }
						 }
						//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
						 if(HPEConstants.EDITABLE_CLMLINE_ADJUD_ADJUST.equals(chartEncounterForm.getHier())){
							 encounterVO.setAdjudGroupCode(chartEncounterForm.getEditableAdjGroupCode());
							 encounterVO.setAdjudReasonCode(chartEncounterForm.getEditableAdjReasonCode());
							 encounterVO.setAdjudAmount(chartEncounterForm.getEditableAdjAmount());
							 encounterVO.setAdjudQuantity(chartEncounterForm.getEditableAdjQuantity());
							 encounterVO.setClmliAdjudSeqNbr(chartEncounterForm.getEditableAdjudSeqNbr());
							 encounterVO.setClmliAdjustSeqNbr(chartEncounterForm.getEditableAdjustSeqNbr());
							 encounterVO.setClmliSeqNbr(Integer.parseInt(chartEncounterForm.getClmliSeqNbr().trim()));
							 
						 }
						//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
						//EDTABLEFLDS
						 hm= encounterService.EditableUpdateCodes(conn, context, encounterVO, flagInd);
						 /* Added for IFOX-00406912 Primary Procedure Code*/				 
						 if(hm.get("princProc")!=null && hm.get("princProc").equals("exists")) {
							 if (HPEConstants.EDITABLE_PROCEDURE_CODE_CNSTNT.equals(encounterVO.getHier())) {						
								 chartEncounterForm.setDisplayMessage("Cannot add two principal procedure codes");
								}
						 }else {
							//TODO get the codes based on hier
							 sqlCnt =Integer.parseInt(hm.get("sqlCnt"));
						 }
						 
					}		
					
					if(sqlCnt== -5 || sqlCnt== -10){				
						
						forward=String.valueOf(sqlCnt);
						
					}
					else if(sqlCnt!=-1 && sqlCnt!=0){
						
						
						if(StringUtils.isNotEmpty(flagInd)&& "ADD".equals(flagInd)){
							
							if (HPEConstants.EDITABLE_COND_CODE_CNSTNT.equals(encounterVO.getHier())) {						
								chartEncounterForm.setDisplayMessage("Condition Code Added Successfully");
							}
							
							if (HPEConstants.EDITABLE_DIAG_CODE_CNSTNT.equals(encounterVO.getHier())) {						
								chartEncounterForm.setDisplayMessage("Diganosis Code Added Successfully");
							}
							
							if (HPEConstants.EDITABLE_PROCEDURE_CODE_CNSTNT.equals(encounterVO.getHier())) {						
								chartEncounterForm.setDisplayMessage("Procedure Code Added Successfully");
							}
							
							if (HPEConstants.EDITABLE_VALUE_CODE_CNSTNT.equals(encounterVO.getHier())) {						
								chartEncounterForm.setDisplayMessage("Value Code Added Successfully");
							}
							
							if (HPEConstants.EDITABLE_EXT_INJ_CODE_CNSTNT.equals(encounterVO.getHier())) {						
								chartEncounterForm.setDisplayMessage("External Injury Code Added Successfully");
							}
							
							if (HPEConstants.EDITABLE_OCCURENCE_CODE_CNSTNT.equals(encounterVO.getHier())) {						
								chartEncounterForm.setDisplayMessage("Occurrence Code Added Successfully");
							}
							
							if (HPEConstants.EDITABLE_OCCURSPAN_CODE_CNSTNT.equals(encounterVO.getHier())) {						
								chartEncounterForm.setDisplayMessage("Occurrence Span Code Added Successfully");
							}
							
							if (HPEConstants.EDITABLE_TREATMENT_CODE_CNSTNT.equals(encounterVO.getHier())) {						
								chartEncounterForm.setDisplayMessage("Treatment Code Added Successfully");
							}
						
						}
						
					
					}	
						if(encounterVO.getSearchDetailClmType().equals("I")){
							forward = ChartConstants.CHART_INSTDETAIL;
						}else{
							forward = ChartConstants.CHART_PROFDETAIL;
						}
					
				
				} catch (Exception e) {
					throw new ApplicationException(e);
				}
				
				logger.info(LoggerConstants.methodEndLevel());
				return forward;
				
			}
}
