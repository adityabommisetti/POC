/*
 * Created on Apr 16, 2008
 *
 */
package com.ps.mss.web.forms;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.PdeEventDetailVoList;
import com.ps.mss.model.TroopDashBoardVOList;
import com.ps.mss.model.TroopDetailVOList;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.util.NameValuePair;

/**
 * @author deepak
 *
 */
public class PdeTroopForm  extends ActionForm {

	
    private String actionType;
    private String pageType = "";
	private String planName ;
	private String pbpId;
	private String fromDate ;
	private String toDate;
	private String searchType;
	private String hicNbr;
	private TroopDashBoardVOList troopDashBoardVOList ;
	private NameValuePair [] planNameList;
	private NameValuePair [] pbpList;
	private TroopDetailVOList troopDetailVOList ;
	
	//private PdeDashboardVO [] pdeDashBoardVOs = null;
	private Object [] pdeDashBoardVOs = null;
	private PdeEventDetailVoList pdeEventDetailVoList;
	private String showPdeEventList;
	
	private String showTroopList ;
	private String showPdeDetail ;
	private String pdeStatus;
	private String errorCode;
	private boolean detailPage;
	
	/**
	 * @return Returns the detailPage.
	 */
	public boolean isDetailPage() {
		return detailPage;
	}
	/**
	 * @param detailPage The detailPage to set.
	 */
	public void setDetailPage(boolean detailPage) {
		this.detailPage = detailPage;
	}
    /**
     * @return Returns the showPdeDetail.
     */
    public String getShowPdeDetail() {
        return showPdeDetail;
    }
    /**
     * @param showPdeDetail The showPdeDetail to set.
     */
    public void setShowPdeDetail(String showPdeDetail) {
        this.showPdeDetail = showPdeDetail;
    }
    /**
     * @return Returns the showTroopList.
     */
    public String getShowTroopList() {
        return showTroopList;
    }
    /**
     * @param showTroopList The showTroopList to set.
     */
    public void setShowTroopList(String showTroopList) {
        this.showTroopList = showTroopList;
    }
    /**
     * @return Returns the troopDetailVOList.
     */
    public TroopDetailVOList getTroopDetailVOList() {
        return troopDetailVOList;
    }
    /**
     * @param troopDetailVOList The troopDetailVOList to set.
     */
    public void setTroopDetailVOList(TroopDetailVOList troopDetailVOList) {
        this.troopDetailVOList = troopDetailVOList;
    }
    /**
     * @return Returns the planNameList.
     */
    public NameValuePair[] getPlanNameList() {
        return planNameList;
    }
    /**
     * @param planNameList The planNameList to set.
     */
    public void setPlanNameList(NameValuePair[] planNameList) {
        this.planNameList = planNameList;
    }
    /**
     * @return Returns the actionType.
     */
    public String getActionType() {
        return actionType;
    }
    /**
     * @param actionType The actionType to set.
     */
    public void setActionType(String actionType) {
        this.actionType = actionType;
    }
    /**
     * @return Returns the fromDate.
     */
    public String getFromDate() {
        return fromDate;
    }
    /**
     * @param fromDate The fromDate to set.
     */
    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }
    /**
     * @return Returns the hicNbr.
     */
    public String getHicNbr() {
    	if(hicNbr != null )
    		return hicNbr.toUpperCase() ;
    	
        return hicNbr;
    }
    /**
     * @param hicNbr The hicNbr to set.
     */
    public void setHicNbr(String hicNbr) {
        this.hicNbr = hicNbr;
    }
    /**
     * @return Returns the planName.
     */
    public String getPlanName() {
        return planName;
    }
    /**
     * @param planName The planName to set.
     */
    public void setPlanName(String planName) {
        this.planName = planName;
    }
    /**
     * @return Returns the searchType.
     */
    public String getSearchType() {
        return searchType;
    }
    /**
     * @param searchType The searchType to set.
     */
    public void setSearchType(String searchType) {
        this.searchType = searchType;
    }
    /**
     * @return Returns the toDate.
     */
    public String getToDate() {
        return toDate;
    }
    /**
     * @param toDate The toDate to set.
     */
    public void setToDate(String toDate) {
        this.toDate = toDate;
    }
    
    /**
     * @return Returns the troopDashBoardVOList.
     */
    public TroopDashBoardVOList getTroopDashBoardVOList() {
        return troopDashBoardVOList;
    }
    /**
     * @param troopDashBoardVOList The troopDashBoardVOList to set.
     */
    public void setTroopDashBoardVOList(
            TroopDashBoardVOList troopDashBoardVOList) {
        this.troopDashBoardVOList = troopDashBoardVOList;
    }
    /**
     * @param request
     * @throws ApplicationException
     */
    public void init(HttpServletRequest request) throws ApplicationException {
        SessionHelper sessionHelper = new SessionHelper(request);
		setPlanNameList(sessionHelper.getPartDPlanIdArr());
    }
    

	/**
	 * @return Returns the pdeStatus.
	 */
	public String getPdeStatus() {
		return pdeStatus;
	}
	/**
	 * @param pdeStatus The pdeStatus to set.
	 */
	public void setPdeStatus(String pdeStatus) {
		this.pdeStatus = pdeStatus;
	}
	/**
	 * @return Returns the pdeDashBoardVOs.
	 */
	public Object[] getPdeDashBoardVOs() {
		return pdeDashBoardVOs;
	}
	/**
	 * @param pdeDashBoardVOs The pdeDashBoardVOs to set.
	 */
	public void setPdeDashBoardVOs(Object[] pdeDashBoardVOs) {
		this.pdeDashBoardVOs = pdeDashBoardVOs;
	}
	/**
	 * @return Returns the pdeEventDetailVoList.
	 */
	public PdeEventDetailVoList getPdeEventDetailVoList() {
		return pdeEventDetailVoList;
	}
	/**
	 * @param pdeEventDetailVoList The pdeEventDetailVoList to set.
	 */
	public void setPdeEventDetailVoList(
			PdeEventDetailVoList pdeEventDetailVoList) {
		this.pdeEventDetailVoList = pdeEventDetailVoList;
	}
	/**
	 * @return Returns the showPdeEventList.
	 */
	public String getShowPdeEventList() {
		return showPdeEventList;
	}
	/**
	 * @param showPdeEventList The showPdeEventList to set.
	 */
	public void setShowPdeEventList(String showPdeEventList) {
		this.showPdeEventList = showPdeEventList;
	}
	
	/**
	 * @return Returns the pbpId.
	 */
	public String getPbpId() {
		return pbpId;
	}
	/**
	 * @param pbpId The pbpId to set.
	 */
	public void setPbpId(String pbpId) {
		this.pbpId = pbpId;
	}
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		actionType = null;
		planName = null;
		fromDate = null;
		toDate = null;
		searchType = null;
		planNameList = null;
		showPdeEventList = "";
		showTroopList  = "";
		showPdeDetail  = "";
		pdeStatus = "";
		troopDashBoardVOList = null;
		planNameList = null;
		troopDetailVOList = null ;
		pdeDashBoardVOs = null;
		pdeEventDetailVoList = null;
		pageType = "";
		pbpList = null;
	}
	
	/**
	 * @return Returns the pageType.
	 */
	public String getPageType() {
		return pageType;
	}
	/**
	 * @param pageType The pageType to set.
	 */
	public void setPageType(String pageType) {
		this.pageType = pageType;
	}
	/**
	 * @return Returns the pbpList.
	 */
	public NameValuePair[] getPbpList() {
		return pbpList;
	}
	/**
	 * @param pbpList The pbpList to set.
	 */
	public void setPbpList(NameValuePair[] pbpList) {
		this.pbpList = pbpList;
	}
	/**
	 * @return Returns the errorCode.
	 */
	public String getErrorCode() {
		return errorCode;
	}
	/**
	 * @param errorCode The errorCode to set.
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
}
