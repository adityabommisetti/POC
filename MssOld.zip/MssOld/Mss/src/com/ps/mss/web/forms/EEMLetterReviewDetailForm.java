/*
 * $Id: EEMLetterReviewDetailForm.java,v 1.1 2014/06/26 07:55:47 praveen Exp $
 */
package com.ps.mss.web.forms;

import java.util.List;

import com.ps.mss.dao.model.EmCorrMbrVO;
import com.ps.util.ListBoxItem;

public class EEMLetterReviewDetailForm extends EEMSubMenuForm {

	private String searchType;
	private String searchId;
	private String searchReqFromDate;
	private String searchReqToDate;
	private String searchStatus;
	private String searchBatchId;
	private String searchLetterName;
	private String searchDeleteInd;
	
	private boolean searchExpanded;
	private int selectedSearchRow;
	private List listSearchResults;

	private EmCorrMbrVO displayCorrMbr = new EmCorrMbrVO();
	private boolean displayCorrMbrChanged;
	private List displayLetterVarData;
	
	private ListBoxItem [] arrSearchTypes;
	private ListBoxItem [] arrSearchStatus;
	private ListBoxItem [] arrUpdateStatus;
	private List lstLetterNames;
	/** Triple S BasePlus Migration START **/
	// Added for TSA changes for Member Id Label Change :Start
	private String mbrLabel;
	// Added for TSA changes for Member Id Label Change :End
	public String getMbrLabel() {
		return mbrLabel;
	}
	public void setMbrLabel(String mbrLabel) {
		this.mbrLabel = mbrLabel;
	}
	/** Triple S BasePlus Migration END **/
	
	public boolean isDisplayCorrMbrChanged() {
		return displayCorrMbrChanged;
	}
	public void setDisplayCorrMbrChanged(boolean displayCorrMbrChanged) {
		this.displayCorrMbrChanged = displayCorrMbrChanged;
	}
	public List getDisplayLetterVarData() {
		return displayLetterVarData;
	}
	public void setDisplayLetterVarData(List displayLetterVarData) {
		this.displayLetterVarData = displayLetterVarData;
	}
	public EmCorrMbrVO getDisplayCorrMbr() {
		return displayCorrMbr;
	}
	public void setDisplayCorrMbr(EmCorrMbrVO displayCorrMbr) {
		this.displayCorrMbr = displayCorrMbr;
	}
	public ListBoxItem[] getArrUpdateStatus() {
		return arrUpdateStatus;
	}
	public void setArrUpdateStatus(ListBoxItem[] arrUpdateStatus) {
		this.arrUpdateStatus = arrUpdateStatus;
	}
	public ListBoxItem[] getArrSearchStatus() {
		return arrSearchStatus;
	}
	public void setArrSearchStatus(ListBoxItem[] arrSearchStatus) {
		this.arrSearchStatus = arrSearchStatus;
	}
	public ListBoxItem[] getArrSearchTypes() {
		return arrSearchTypes;
	}
	public void setArrSearchTypes(ListBoxItem[] arrSearchTypes) {
		this.arrSearchTypes = arrSearchTypes;
	}
	public List getListSearchResults() {
		return listSearchResults;
	}
	public void setListSearchResults(List listSearchResults) {
		this.listSearchResults = listSearchResults;
	}
	public List getLstLetterNames() {
		return lstLetterNames;
	}
	public void setLstLetterNames(List lstLetterNames) {
		this.lstLetterNames = lstLetterNames;
	}
	public String getSearchBatchId() {
		return searchBatchId;
	}
	public void setSearchBatchId(String searchBatchId) {
		this.searchBatchId = searchBatchId;
	}
	public String getSearchDeleteInd() {
		return searchDeleteInd;
	}
	public void setSearchDeleteInd(String searchDeleteInd) {
		this.searchDeleteInd = searchDeleteInd;
	}
	public boolean isSearchExpanded() {
		return searchExpanded;
	}
	public void setSearchExpanded(boolean searchExpanded) {
		this.searchExpanded = searchExpanded;
	}
	public String getSearchId() {
		return searchId;
	}
	public void setSearchId(String searchId) {
		this.searchId = searchId;
	}
	public String getSearchLetterName() {
		return searchLetterName;
	}
	public void setSearchLetterName(String searchLetterName) {
		this.searchLetterName = searchLetterName;
	}
	public String getSearchReqFromDate() {
		return searchReqFromDate;
	}
	public void setSearchReqFromDate(String searchReqFromDate) {
		this.searchReqFromDate = searchReqFromDate;
	}
	public String getSearchReqToDate() {
		return searchReqToDate;
	}
	public void setSearchReqToDate(String searchReqToDate) {
		this.searchReqToDate = searchReqToDate;
	}
	public String getSearchStatus() {
		return searchStatus;
	}
	public void setSearchStatus(String searchStatus) {
		this.searchStatus = searchStatus;
	}
	public String getSearchType() {
		return searchType;
	}
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	public int getSelectedSearchRow() {
		return selectedSearchRow;
	}
	public void setSelectedSearchRow(int selectedSearchRow) {
		this.selectedSearchRow = selectedSearchRow;
	}
}
