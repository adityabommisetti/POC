package com.ps.mss.web.actions;

import java.io.PrintWriter;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EEMAdminService;
import com.ps.mss.db.DbConn;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.manager.EEMManager;
import com.ps.mss.model.EEMContext;
import com.ps.mss.web.helper.SessionHelper;

public class AdminAction extends Action {
	
	private static Logger logger = LoggerFactory.getLogger(AdminAction.class);

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		PrintWriter out = response.getWriter();
		Connection conn = null;
		Map<String, String> dataMap = null;
		String methodName;
		try {
			logger.debug("Inside Admin Action.");
			
			// use the default DB for security check
			conn = DbConn.getConnection();
			SessionHelper sessionHelper = new SessionHelper(request);
			String errorMsg = sessionHelper.validateUser(conn);
			if (errorMsg != null) {
				request.setAttribute("Msg", "Login Has Timed Out");
				throw new Exception(errorMsg);
			}
			
			conn = DbConn.reGetConnection(conn, sessionHelper.getEEMDatabaseName());
			methodName = (String) request.getParameter("methodName");
			
			EEMContext context = EEMManager.getContext(sessionHelper.getSession());
			EEMAdminService adminService = context.getAdminService();
			boolean res = false;
			if("editProdData".equalsIgnoreCase(methodName)) {
				res = adminService.editProdData(request, conn, sessionHelper.getUserId(), sessionHelper.getMfId());
			} else if("editServiceAreaData".equalsIgnoreCase(methodName)) {
				res = adminService.editServiceAreaData(request, conn, sessionHelper.getUserId(), sessionHelper.getMfId());
			} else if("editGrpProdLisData".equalsIgnoreCase(methodName)) {
				res = adminService.editGrpProdLisData(request, conn, sessionHelper.getUserId(), sessionHelper.getMfId());
			} else if("editGrpProdAsscData".equalsIgnoreCase(methodName)) {
				res = adminService.editGrpProdAsscData(request, conn, sessionHelper.getUserId(), sessionHelper.getMfId());
			}
			else if("editbillingSubProdData".equalsIgnoreCase(methodName)) {
				res = adminService.editbillingSubProdData(request, conn, sessionHelper.getUserId(), sessionHelper.getMfId());
			}if("editGroupData".equalsIgnoreCase(methodName)) {
				 res = adminService.editGroupData(request, conn, sessionHelper.getUserId(), sessionHelper.getMfId());				
			}
			if(res) {
				dataMap = new HashMap<String, String>();
				dataMap.put("success", "Record updated successfully..");
			}
		} catch(ApplicationException e) {
			dataMap = new HashMap<String, String>();
			dataMap.put("error", "Failed to process." + "\n" + e.getMessage());
			logger.error("ApplicationException in AdminAction: " + e);
		} catch(Exception e) {
			dataMap = new HashMap<String, String>();
			dataMap.put("error", "Failed to process." + "\n" + e.getMessage());
			logger.error("Exception in AdminAction: " + e);
		} finally {
			if(dataMap == null) {
				dataMap = new HashMap<String, String>();
				dataMap.put("error", "Failed to Process.");
			}
			String jsonStr = prepareResponse(dataMap);
			response.setContentType("application/json");
		    out.println(jsonStr);
			out.close();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return null;
	}

	/**
	 * This method prepares the json response with the specified map fields.
	 * 
	 * @param dataMap
	 * @return jsonString
	 */
	private String prepareResponse(Map<String, String> dataMap) {
		logger.info(LoggerConstants.methodStartLevel());
		String res = "{}";
		if(dataMap != null) {
			StringBuilder sb = new StringBuilder();
			sb.append("{");
			Set<String> keySet = dataMap.keySet();
			boolean isFirstElement = true;
			for(String key : keySet) {
				if(isFirstElement) {
					isFirstElement = false;
				} else {
					sb.append(",");
				}
				sb.append("\"");
				sb.append(key);
				sb.append("\":\"");
				sb.append(dataMap.get(key));
				sb.append("\"");
			}
			sb.append("}");
			res = sb.toString();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return res;
	}

}
