package com.ps.mss.web.ajax;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.McaidILService;
import com.ps.mss.businesslogic.McaidMTService;
import com.ps.mss.businesslogic.McaidNMService;
import com.ps.mss.businesslogic.McaidTXService;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.DbConnWeb;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.manager.McaidReconManager;
import com.ps.mss.model.McaidReconAnomVO;
import com.ps.mss.model.McaidReconContext;
import com.ps.mss.model.McaidReconDiscVO;
import com.ps.mss.model.McaidReconPaymentVO;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.forms.McaidReconPaymentForm;
import com.ps.mss.web.helper.AjaxHelper;
import com.ps.mss.web.helper.McaidReconPaymentHelper;
import com.ps.mss.web.helper.SessionHelper;

public class McaidReconFacadeManager {
	private static Logger logger=LoggerFactory.getLogger(McaidReconFacadeManager.class);

	/**
	 * This function is call by UI to get  values for palnDashBoard.
	 * @param searchType : On the  basis of this value we decide search criteria. 
	 * @param filterVO : this Vo contain all the criteria to be use in searching.
	 * @return List
	 * @throws ApplicationException
	 */
	@SuppressWarnings("rawtypes")
	public List getMcaidPaymentDashboardByPBP (String pbpId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;  
    	List pbpLst = new ArrayList();
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    		//Local Dev
    		//String eemdb =  (String)sessionHelper.getAttribute(SessionManager.RECONDB);
    		// For QA
    					/*String eemdb = sessionHelper.getDBBasedOnUserId();*/
    		String eemdb = sessionHelper.getActiveDataBaseName();
    					conn = DbConn.reGetConnection(conn, eemdb);
    		//For QA
    	   	//AjaxHelper.validateUser(sessionHelper,conn);    	   	
    	   	McaidReconContext context = McaidReconManager.getContext(sessionHelper.getSession());
    	   	McaidReconPaymentVO paymentVO = context.getPaymentVO();
    	   	logger.debug(" paymentVO dateType=="+paymentVO.getDateType());
    	   	String mfId = sessionHelper.getMfId();
    	   	String state= context.getStateCode();
    	   	if(state.equals("Illinois")){
			pbpLst = new McaidILService().getMcaidPaymentDashboardByPBP(conn, mfId, pbpId, paymentVO.getMcaidPymntDsbPBPLst(),paymentVO.getDateType(),paymentVO);
    	   	}else if(state.equals("Texas")){
    			pbpLst = new McaidTXService().getMcaidPaymentDashboardByPBP(conn, mfId, pbpId, paymentVO.getMcaidPymntDsbPBPLst(),paymentVO.getDateType(),paymentVO);
    	   	}
    	   	else if(state.equals("Montana")){
    	   		pbpLst = new McaidMTService().getMcaidPaymentDashboardByPBP(conn, mfId, pbpId, paymentVO.getMcaidPymntDsbPBPLst(),paymentVO.getDateType(),paymentVO);
    	   	}
    	   	else{
    	   		pbpLst = new McaidNMService().getMcaidPaymentDashboardByPBP(conn, mfId, pbpId, paymentVO.getMcaidPymntDsbPBPLst(), paymentVO.getDateType(),paymentVO);	
    	   	}
			anyError = false;
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return pbpLst;
	}
	
	/**
	 * This function is call by UI to get  values for palnDashBoard.
	 * @param searchType : On the  basis of this value we decide search criteria. 
	 * @param filterVO : this Vo contain all the criteria to be use in searching.
	 * @return List
	 * @throws ApplicationException
	 */
	public List getMcaidPaymentDashboardByYear (String pbpId,String year) throws ApplicationException {		
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;  
    	List qtrLst = new ArrayList();
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    		// For QA
    					/*String eemdb = sessionHelper.getDBBasedOnUserId();*/
    		String eemdb = sessionHelper.getActiveDataBaseName();
    					conn = DbConn.reGetConnection(conn, eemdb);
    		//For QA
    	   //	AjaxHelper.validateUser(sessionHelper,conn);    	   	
    	   	McaidReconContext context = McaidReconManager.getContext(sessionHelper.getSession());
    	   	McaidReconPaymentVO paymentVO = context.getPaymentVO();
    	   	    	   	
    	   	String mfId = sessionHelper.getMfId();
    	   	String state= context.getStateCode();
    	   	if(state.equals("Illinois")){
			qtrLst = new McaidILService().getMcaidPaymentDashboardByYear(conn, mfId, pbpId, year, paymentVO.getMcaidPymntDsbPBPLst(),paymentVO.getDateType(),paymentVO);
    	   	}else if(state.equals("Texas")){
			qtrLst = new McaidTXService().getMcaidPaymentDashboardByYear(conn, mfId, pbpId, year, paymentVO.getMcaidPymntDsbPBPLst(),paymentVO.getDateType(),paymentVO);
    	   	}
    		else if(state.equals("Montana")){
    			qtrLst = new McaidMTService().getMcaidPaymentDashboardByYear(conn, mfId, pbpId, year, paymentVO.getMcaidPymntDsbPBPLst(),paymentVO.getDateType(),paymentVO);
    	    	     	
    		}
    	   	else{
    	   		qtrLst = new McaidNMService().getMcaidPaymentDashboardByYear(conn, mfId, pbpId, year, paymentVO.getMcaidPymntDsbPBPLst(),paymentVO.getDateType(),paymentVO);	
    	   	}
			anyError = false;
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return qtrLst;
	}
	/**
	 * This function is call by UI to get  values for palnDashBoard.
	 * @param searchType : On the  basis of this value we decide search criteria. 
	 * @param filterVO : this Vo contain all the criteria to be use in searching.
	 * @return List
	 * @throws ApplicationException
	 */
	public List getMcaidPaymentDashboardByQuarter (String pbpId,String year,String quarter) throws ApplicationException {		
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;  
    	List monthLst = new ArrayList();
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    		// For QA
    					/*String eemdb = sessionHelper.getDBBasedOnUserId();*/
    		String eemdb = sessionHelper.getActiveDataBaseName();
    					conn = DbConn.reGetConnection(conn, eemdb);
    		//For QA
    	   	//AjaxHelper.validateUser(sessionHelper,conn);    	   	
    	   	McaidReconContext context = McaidReconManager.getContext(sessionHelper.getSession());
    	   	McaidReconPaymentVO paymentVO = context.getPaymentVO();
    	   	    	   	
    	   	String mfId = sessionHelper.getMfId();
    	   	String state= context.getStateCode();
    	   	if(state.equals("Illinois")){
    	   	monthLst = new McaidILService().getMcaidPaymentDashboardByQuarter(conn, mfId, pbpId, year, quarter, paymentVO.getMcaidPymntDsbPBPLst(), paymentVO.getDateType(),paymentVO);
    	   	}else if(state.equals("Texas")){
        	   	monthLst = new McaidTXService().getMcaidPaymentDashboardByQuarter(conn, mfId, pbpId, year, quarter, paymentVO.getMcaidPymntDsbPBPLst(),paymentVO.getDateType(),paymentVO);
        	   	}
    	   	else if(state.equals("Montana")){
        	   	monthLst = new McaidMTService().getMcaidPaymentDashboardByQuarter(conn, mfId, pbpId, year, quarter, paymentVO.getMcaidPymntDsbPBPLst(),paymentVO.getDateType(),paymentVO);
        	   	}
    	   	else{
    	   		monthLst = new McaidNMService().getMcaidPaymentDashboardByQuarter(conn, mfId, pbpId, year, quarter, paymentVO.getMcaidPymntDsbPBPLst(), paymentVO.getDateType(),paymentVO);	
    	   	}
						
			anyError = false;
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return monthLst;
	}
	
///////////////************ANOMALY***************************
	
	/**
	 * This function is call by UI to get  values for palnDashBoard.
	 * @param searchType : On the  basis of this value we decide search criteria. 
	 * @param filterVO : this Vo contain all the criteria to be use in searching.
	 * @return List
	 * @throws ApplicationException
	 */
	@SuppressWarnings("rawtypes")
	public List getMcaidAnomDashboardByPBP (String pbpId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;  
    	List pbpLst = new ArrayList();
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    		// For QA
    					/*String eemdb = sessionHelper.getDBBasedOnUserId();*/
    					String eemdb = sessionHelper.getActiveDataBaseName();
    					conn = DbConn.reGetConnection(conn, eemdb);
    		//For QA
    	   //	AjaxHelper.validateUser(sessionHelper,conn);    	   	
    	   	McaidReconContext context = McaidReconManager.getContext(sessionHelper.getSession());
    	   	McaidReconAnomVO anomVO = context.getAnamolyVO();
    	   	    	   	
    	   	String mfId = sessionHelper.getMfId();
    	   	String state= context.getStateCode();
    	   	if(state.equals("Illinois")){
			pbpLst = new McaidILService().getMcaidAnomDashboardByPBP(conn, mfId, pbpId, anomVO.getMcaidAnomDsbPBPLst(), anomVO);
    	   	}else if(state.equals("Texas")){
			pbpLst = new McaidTXService().getMcaidAnomDashboardByPBP(conn, mfId, pbpId, anomVO.getMcaidAnomDsbPBPLst(), anomVO);
    	   	}
    	   	else if(state.equals("Montana")){
    			pbpLst = new McaidMTService().getMcaidAnomDashboardByPBP(conn, mfId, pbpId, anomVO.getMcaidAnomDsbPBPLst(), anomVO);
        	   	}
    	   	else{
    	   		pbpLst = new McaidNMService().getMcaidAnomDashboardByPBP(conn, mfId, pbpId, anomVO.getMcaidAnomDsbPBPLst(), anomVO);	
    	   	}
						
			anyError = false;
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return pbpLst;
	}
	
	/**
	 * This function is call by UI to get  values for palnDashBoard.
	 * @param searchType : On the  basis of this value we decide search criteria. 
	 * @param filterVO : this Vo contain all the criteria to be use in searching.
	 * @return List
	 * @throws ApplicationException
	 */
	public List getMcaidAnomDashboardByYear (String pbpId,String year) throws ApplicationException {		
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;  
    	List qtrLst = new ArrayList();
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	
    		// For QA
    					/*String eemdb = sessionHelper.getDBBasedOnUserId();*/
    		String eemdb = sessionHelper.getActiveDataBaseName();
    					conn = DbConn.reGetConnection(conn, eemdb);
    		//For QA
    		//AjaxHelper.validateUser(sessionHelper,conn);    	   	
    	   	McaidReconContext context = McaidReconManager.getContext(sessionHelper.getSession());
    		McaidReconAnomVO anomVO = context.getAnamolyVO();
    	   	    	   	
    	   	String mfId = sessionHelper.getMfId();
    	   	String state= context.getStateCode();
    	   	if(state.equals("Illinois")){
			qtrLst = new McaidILService().getMcaidAnomDashboardByYear(conn, mfId, pbpId, year, anomVO.getMcaidAnomDsbPBPLst(), anomVO);
    	   	}else if(state.equals("Texas")){
			qtrLst = new McaidTXService().getMcaidAnomDashboardByYear(conn, mfId, pbpId, year, anomVO.getMcaidAnomDsbPBPLst(), anomVO);
    	   	}
    	   	else if(state.equals("Montana")){
    			qtrLst = new McaidMTService().getMcaidAnomDashboardByYear(conn, mfId, pbpId, year, anomVO.getMcaidAnomDsbPBPLst(), anomVO);
        	   	}
    	   	else{
    	   		qtrLst = new McaidNMService().getMcaidAnomDashboardByYear(conn, mfId, pbpId, year, anomVO.getMcaidAnomDsbPBPLst(), anomVO);	
    	   	}
						
			anyError = false;
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return qtrLst;
	}
	/**
	 * This function is call by UI to get  values for palnDashBoard.
	 * @param searchType : On the  basis of this value we decide search criteria. 
	 * @param filterVO : this Vo contain all the criteria to be use in searching.
	 * @return List
	 * @throws ApplicationException
	 */
	public List getMcaidAnomDashboardByQuarter (String pbpId,String year,String quarter) throws ApplicationException {		
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;  
    	List monthLst = new ArrayList();
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    		// For QA
    					/*String eemdb = sessionHelper.getDBBasedOnUserId();*/
    		String eemdb = sessionHelper.getActiveDataBaseName();
    					conn = DbConn.reGetConnection(conn, eemdb);
    		//For QA
    		//AjaxHelper.validateUser(sessionHelper,conn);    	   	
    	   	McaidReconContext context = McaidReconManager.getContext(sessionHelper.getSession());
    	   	McaidReconAnomVO anomVO = context.getAnamolyVO();
    	   	    	   	
    	   	String mfId = sessionHelper.getMfId();
    	   	String state= context.getStateCode();
    	   	if(state.equals("Illinois")){
    	   	monthLst = new McaidILService().getMcaidAnomDashboardByQuarter(conn, mfId, pbpId, year, quarter, anomVO.getMcaidAnomDsbPBPLst(),anomVO);
    	   	}else if(state.equals("Texas")){
        	   	monthLst = new McaidTXService().getMcaidAnomDashboardByQuarter(conn, mfId, pbpId, year, quarter, anomVO.getMcaidAnomDsbPBPLst(), anomVO);
        	   	}
    	   	else if(state.equals("Montana")){
        	   	monthLst = new McaidMTService().getMcaidAnomDashboardByQuarter(conn, mfId, pbpId, year, quarter, anomVO.getMcaidAnomDsbPBPLst(), anomVO);
        	   	}
    	   	else{
    	   		monthLst = new McaidNMService().getMcaidAnomDashboardByQuarter(conn, mfId, pbpId, year, quarter, anomVO.getMcaidAnomDsbPBPLst(), anomVO);	
    	   	}
						
			anyError = false;
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return monthLst;
	}
	
	

	/**
	 * This function is call by UI to get  values for palnDashBoard.
	 * @param searchType : On the  basis of this value we decide search criteria. 
	 * @param filterVO : this Vo contain all the criteria to be use in searching.
	 * @return List
	 * @throws ApplicationException
	 */
	@SuppressWarnings("rawtypes")
	public List getMcaidDiscDashboardByPBP (String pbpId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;  
    	List pbpLst = new ArrayList();
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    		// For QA
    					/*String eemdb = sessionHelper.getDBBasedOnUserId();*/
    		String eemdb = sessionHelper.getActiveDataBaseName();
    					conn = DbConn.reGetConnection(conn, eemdb);
    		//For QA
    	   	//AjaxHelper.validateUser(sessionHelper,conn);    	   	
    	   	McaidReconContext context = McaidReconManager.getContext(sessionHelper.getSession());
    	   	McaidReconDiscVO discVO = context.getDiscrepanciesVO();
    	   	    	   	
    	   	String mfId = sessionHelper.getMfId();
    	   	String state= context.getStateCode();
    	   	if(state.equals("Illinois")){    	   
			pbpLst = new McaidILService().getMcaidDiscDashboardByPBP(conn, mfId, pbpId, discVO.getMcaidDiscDsbPBPLst(),discVO);
    	   	}else if(state.equals("Texas")){    	   
			pbpLst = new McaidTXService().getMcaidDiscDashboardByPBP(conn, mfId, pbpId, discVO.getMcaidDiscDsbPBPLst(), discVO);
    	   	}
    	   	else if(state.equals("Montana")){    	   
    			pbpLst = new McaidMTService().getMcaidDiscDashboardByPBP(conn, mfId, pbpId, discVO.getMcaidDiscDsbPBPLst(), discVO);
        	   	}
    	   	else{
    	   		pbpLst = new McaidNMService().getMcaidDiscDashboardByPBP(conn, mfId, pbpId, discVO.getMcaidDiscDsbPBPLst(),discVO);	
    	   	}
    	   
			anyError = false;
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return pbpLst;
	}
	
	/**
	 * This function is call by UI to get  values for palnDashBoard.
	 * @param searchType : On the  basis of this value we decide search criteria. 
	 * @param filterVO : this Vo contain all the criteria to be use in searching.
	 * @return List
	 * @throws ApplicationException
	 */
	public List getMcaidDiscDashboardByYear (String pbpId,String year) throws ApplicationException {		
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;  
    	List qtrLst = new ArrayList();
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    		// For QA
    					/*String eemdb = sessionHelper.getDBBasedOnUserId();*/
    		String eemdb = sessionHelper.getActiveDataBaseName();
    					conn = DbConn.reGetConnection(conn, eemdb);
    		//For QA
    	   	//AjaxHelper.validateUser(sessionHelper,conn);    	   	
    	   	McaidReconContext context = McaidReconManager.getContext(sessionHelper.getSession());
    		McaidReconDiscVO discVO = context.getDiscrepanciesVO();
    	   	    	   	
    	   	String mfId = sessionHelper.getMfId();
    		String state= context.getStateCode();
    	   	if(state.equals("Illinois")){
			qtrLst = new McaidILService().getMcaidDiscDashboardByYear(conn, mfId, pbpId, year, discVO.getMcaidDiscDsbPBPLst(),discVO);
    	   	}else if(state.equals("Texas")){
			qtrLst = new McaidTXService().getMcaidDiscDashboardByYear(conn, mfId, pbpId, year, discVO.getMcaidDiscDsbPBPLst(), discVO);
    	   	}
    	   	else if(state.equals("Montana")){
    			qtrLst = new McaidMTService().getMcaidDiscDashboardByYear(conn, mfId, pbpId, year, discVO.getMcaidDiscDsbPBPLst(), discVO);
        	   	}
			else{
				qtrLst = new McaidNMService().getMcaidDiscDashboardByYear(conn, mfId, pbpId, year, discVO.getMcaidDiscDsbPBPLst(),discVO);	
			}
			anyError = false;
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return qtrLst;
	}
	/**
	 * This function is call by UI to get  values for palnDashBoard.
	 * @param searchType : On the  basis of this value we decide search criteria. 
	 * @param filterVO : this Vo contain all the criteria to be use in searching.
	 * @return List
	 * @throws ApplicationException
	 */
	public List getMcaidDiscDashboardByQuarter (String pbpId,String year,String quarter) throws ApplicationException {		
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;  
    	List monthLst = new ArrayList();
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    		// For QA
    					/*String eemdb = sessionHelper.getDBBasedOnUserId();*/
    		String eemdb = sessionHelper.getActiveDataBaseName();
    					conn = DbConn.reGetConnection(conn, eemdb);
    		//For QA
    	   	//AjaxHelper.validateUser(sessionHelper,conn);    	   	
    	   	McaidReconContext context = McaidReconManager.getContext(sessionHelper.getSession());
    		McaidReconDiscVO discVO = context.getDiscrepanciesVO();
    	   	    	   	
    	   	String mfId = sessionHelper.getMfId();
    		String state= context.getStateCode();
    	   	if(state.equals("Illinois")){
    	   	monthLst = new McaidILService().getMcaidDiscDashboardByQuarter(conn, mfId, pbpId, year, quarter, discVO.getMcaidDiscDsbPBPLst(),discVO);
    	   	}else if(state.equals("Texas")){
        	   	monthLst = new McaidTXService().getMcaidDiscDashboardByQuarter(conn, mfId, pbpId, year, quarter, discVO.getMcaidDiscDsbPBPLst(), discVO);
        	   	}
    	   	else if(state.equals("Montana")){
        	   	monthLst = new McaidMTService().getMcaidDiscDashboardByQuarter(conn, mfId, pbpId, year, quarter, discVO.getMcaidDiscDsbPBPLst(), discVO);
        	   	}
    	   	else{
    	   	  	monthLst = new McaidNMService().getMcaidDiscDashboardByQuarter(conn, mfId, pbpId, year, quarter, discVO.getMcaidDiscDsbPBPLst(),discVO);	
    	   	}
			anyError = false;
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return monthLst;
	}
	/**
	 * This function is call by UI to get  values for palnDashBoard.
	 * @param searchType : On the  basis of this value we decide search criteria. 
	 * @param filterVO : this Vo contain all the criteria to be use in searching.
	 * @return List
	 * @throws ApplicationException
	 */
	public List getMcaidPaymentDetailsByEffDt (String effDate,String mcaidId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		long startTime = 0;
		long endTime = 0;
		startTime = System.nanoTime();
		
		Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;  
    	List pbpLst = new ArrayList();
    	try {
    		//RRRRRRRRRRRRRRRR
			/*
    		// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    		// For QA
    					String eemdb = sessionHelper.getDBBasedOnUserId();
    					conn = DbConn.reGetConnection(conn, eemdb);
    		//For QA
    	   	//AjaxHelper.validateUser(sessionHelper,conn);    	   	
    	   	McaidReconContext context = McaidReconManager.getContext(sessionHelper.getSession());
    	   	McaidReconDiscVO discVO = context.getDiscrepanciesVO();
    	   	    	   	
    	   	String mfId = sessionHelper.getMfId();
    	   	String state= context.getStateCode();
    		if(state.equals("Illinois")){
			pbpLst = new McaidILService().getMcaidPaymentDetailsByEffDt(conn, mfId, effDate,mcaidId, discVO.getMcaidViewPymntDetailLst());
    		}else{
    			pbpLst = new McaidNMService().getMcaidPaymentDetailsByEffDt(conn, mfId, effDate,mcaidId, discVO.getMcaidViewPymntDetailLst());	
    		}
			anyError = false;
			*/

    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    		//conn = DbConn.reGetConnection(conn, sessionHelper.getDBBasedOnUserId());
    		/*conn = DbConn.getConnection(sessionHelper.getDBBasedOnUserId());*/
    		conn = DbConn.getConnection(sessionHelper.getActiveDataBaseName());

    	   	McaidReconContext context = McaidReconManager.getContext(sessionHelper.getSession());
    	   	    	   	
    		if(context.getStateCode().equals("Illinois"))
    			pbpLst = new McaidILService().getMcaidPaymentDetailsByEffDt(conn, sessionHelper.getMfId(), effDate,mcaidId, context.getDiscrepanciesVO().getMcaidViewPymntDetailLst(),
    					(String) sessionHelper.getSession().getAttribute("MF_id"));
    		else if(context.getStateCode().equals("Texas"))
    			pbpLst = new McaidTXService().getMcaidPaymentDetailsByEffDt(conn, sessionHelper.getMfId(), effDate,mcaidId, context.getDiscrepanciesVO().getMcaidViewPymntDetailLst(),
    					(String) sessionHelper.getSession().getAttribute("MF_id"));
    		else if(context.getStateCode().equals("Montana"))
    			pbpLst = new McaidMTService().getMcaidPaymentDetailsByEffDt(conn, sessionHelper.getMfId(), effDate,mcaidId, context.getDiscrepanciesVO().getMcaidViewPymntDetailLst(),
    					(String) sessionHelper.getSession().getAttribute("MF_id"));
    		else
    			pbpLst = new McaidNMService().getMcaidPaymentDetailsByEffDt(conn, sessionHelper.getMfId(), effDate,mcaidId, context.getDiscrepanciesVO().getMcaidViewPymntDetailLst(),
    					(String) sessionHelper.getSession().getAttribute("MF_id"));	

    		anyError = false;			

    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
			throw new ApplicationException(errMessage);
		}
		
		endTime = System.nanoTime();
//		System.out.println(" Complete Method [" + "  (" + ( (endTime - startTime)/1000000 ) + "ms)" );
		logger.debug(" Complete Method [" + "  (" + ( (endTime - startTime)/1000000 ) + "ms)" );
		logger.info(LoggerConstants.methodEndLevel());
		return pbpLst;
	}

	
}//class
