/*
 * Created on Sep 8, 2007
 *
 */
package com.ps.mss.web.taglib;

import java.io.IOException;
import java.text.NumberFormat;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;

/**
 * CurrencyFormatorTag class generate formatted currency output.
 * @author Deepak
 *
 */
public class CurrencyFormatorTag extends BodyTagSupport{
	private String width;
	private String align;
	private String valign;
	private String zero;
	private String hrefCondition;
	private String onClick;
	private boolean dvalue = false;
	
	/* (non-Javadoc)
	 * @see javax.servlet.jsp.tagext.Tag#doStartTag()
	 */
	public int doEndTag() throws JspException {
		try {
			BodyContent body = getBodyContent();
			if(body != null) {
				String value = body.getString();
				if (dvalue) {
					NumberFormat nf = NumberFormat.getCurrencyInstance();
					value = nf.format(Double.parseDouble(value));
				}
				String css = createCss();
				JspWriter out = pageContext.getOut();
				boolean negative = false;
				if(value != null) {
					if("$0.00".equals(value) && zero == null)
						out.print("<td "+ css +" >&nbsp;</td>");
					else {
						String temp ="<td "+ css  ;
						if( value.startsWith("(") ) {
							temp += "class='red' ";
							negative = true;
						} else {
							value +="&nbsp;"; // adding white space with value +ive values
						}
						if("true".equals(hrefCondition)){ // this start start of anchor tag
							if(negative)
								temp += "><a href='#' class='red' onClick=\"" + onClick +"\">" + value + "&nbsp;</a></td>";
							else
								temp += "><a href='#' class='plan' onClick=\"" + onClick +"\">" + value + "&nbsp;</a></td>";
						} else
							temp += ">" + value + "&nbsp;</td> ";
							
						/*if("true".equals(hrefCondition)) //this apply end of anchor tag 
							temp += "&nbsp;</a></td> ";
						else
							temp += "&nbsp;</td> ";*/
						out.print(temp);
					}
				}else if("true".equals(zero)){
					out.print("<td "+ css +" >$0.00;</td>");
				}
					
			}
		} catch (IOException e) {
				System.out.print("Error in CurrencyFromator Tag Hendler" + e);
		}
		return (EVAL_PAGE);
	}
	
	/**
	 * @return
	 */
	private String createCss() {
		StringBuffer css = new StringBuffer();
		if(width != null && !"".equals(width))
			css.append(" width='").append(width).append("'");
		if(align != null && !"".equals(align))
			css.append(" align='").append(align).append("'");
		if(valign != null && !"".equals(valign))
			css.append(" valign='").append(valign).append("'");
		return css.toString();
	}

	/**
	 * @return Returns the align.
	 */
	public String getAlign() {
		return align;
	}
	/**
	 * @param align The align to set.
	 */
	public void setAlign(String align) {
		this.align = align;
	}
	/**
	 * @return Returns the valign.
	 */
	public String getValign() {
		return valign;
	}
	/**
	 * @param valign The valign to set.
	 */
	public void setValign(String valign) {
		this.valign = valign;
	}
	/**
	 * @return Returns the width.
	 */
	public String getWidth() {
		return width;
	}
	/**
	 * @param width The width to set.
	 */
	public void setWidth(String width) {
		this.width = width;
	}
	/**
	 * @return Returns the zero.
	 */
	public String getZero() {
		return zero;
	}
	/**
	 * @param zero The zero to set.
	 */
	public void setZero(String zero) {
		this.zero = zero;
	}
	/**
	 * @return Returns the hrefCondition.
	 */
	public String getHrefCondition() {
		return hrefCondition;
	}
	/**
	 * @param hrefCondition The hrefCondition to set.
	 */
	public void setHrefCondition(String hrefCondition) {
		this.hrefCondition = hrefCondition;
	}
	/**
	 * @return Returns the onClick.
	 */
	public String getOnClick() {
		return onClick;
	}
	/**
	 * @param onClick The onClick to set.
	 */
	public void setOnClick(String onClick) {
		this.onClick = onClick;
	}
	/**
	 * @return Returns the dvalue.
	 */
	public boolean isDvalue() {
		return dvalue;
	}
	/**
	 * @param dvalue The dvalue to set.
	 */
	public void setDvalue(boolean dvalue) {
		this.dvalue = dvalue;
	}
}
