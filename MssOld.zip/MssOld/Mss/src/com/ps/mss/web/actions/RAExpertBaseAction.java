/*
 * Created on Aug 20, 2009
 *
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ps.mss.web.actions;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.forms.GenericDisplayPageForm;
import com.ps.mss.web.helper.RAExpertHelper;
import com.ps.logger.LoggerConstants;
import com.ps.mss.db.BeneficiaryPersistence;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.DiseaseGroupPersistence;
import com.ps.mss.db.RAHccHistory;
import com.ps.mss.db.RAHccProjection;
import com.ps.mss.db.RAMemberFinancialReviewVO;
import com.ps.mss.db.RAYrToYrCompare;
import com.ps.mss.db.view.BeneInfo;
import com.ps.mss.model.RAPSFinancialAuditVO;
import com.ps.util.StringUtil;

/**
 * @author indrapradja.adriana
 *
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class RAExpertBaseAction extends Action {
	private static Logger logger=LoggerFactory.getLogger(RAExpertBaseAction.class);

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		try {
	        conn = DbConn.getConnection();
		    HttpSession session = SessionManager.getSession(request, conn);
		    if (session == null)
		    {
		        logger.error("No Session");
				request.setAttribute("Msg","Page Expired");
				logger.info(LoggerConstants.methodEndLevel());
				return mapping.findForward("raExpertError");
		    }
		    String User_id = (String)session.getAttribute("User_id");
		    if (User_id == null)
		    {
		       logger.error("No User_id");
				request.setAttribute("Msg","Page Expired");
				logger.info(LoggerConstants.methodEndLevel());
				return mapping.findForward("raExpertError");
		    }
		    String MF_id = (String) session.getAttribute("MF_id");
		    if (MF_id == null)
		    {
		        logger.error("No MF_id");
				request.setAttribute("Msg","Invalid Session");
				logger.info(LoggerConstants.methodEndLevel());
				return mapping.findForward("raExpertError");
		    }
		    String Cust_nbr = (String)session.getAttribute("Cust_nbr");
		    if (Cust_nbr == null)
		    {
		       logger.error("No Cust_nbr");
				request.setAttribute("Msg","Page Expired");
				logger.info(LoggerConstants.methodEndLevel());
				return mapping.findForward("raExpertError");
		    }
			
			String reconDb = (String) session.getAttribute("ReconDB");
			conn = DbConn.reGetConnection(conn,reconDb);
			logger.info(LoggerConstants.methodEndLevel());
			return execute(conn, mapping, form, MF_id, request, response); 
			
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("RAExpertBaseAction " + e.getMessage());
//			logger.error("RAExpertBaseAction " + e.getMessage());
			request.setAttribute("Msg", "Application Error");
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward("raExpertError");
		}
		finally {
	        try {
	            if (conn != null)
	                conn.close();
	        } catch(Exception e) {
	        	logger.error(LoggerConstants.exceptionMessage(e.toString()));
	        	//logger.error(e.getMessage());
	        }
		}
	}
	
	private ActionForward execute(Connection conn, ActionMapping mapping, ActionForm form, String mfId, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		String method = request.getParameter("method");
		String planId = request.getParameter("planId"); 
		String hicNumber = request.getParameter("hicNbr");
		String year = request.getParameter("paymentYear");
		String hccModd = request.getParameter("hccModel");
		int paymentYear = -1;
		if (year != null && !year.equals(""))
			paymentYear = Integer.parseInt(year);
		//validate the fields
		if (!StringUtil.isValidString(planId) || !StringUtil.isValidString(hicNumber)) {
			request.setAttribute("Msg","Invalid Characters found on input");
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward("raExpertError");
		}
		if ("memberFinancialReview".equals(method)) {
		    RAMemberFinancialReviewVO raMemberFinancialReviewVO = new RAMemberFinancialReviewVO(conn, planId, hicNumber, paymentYear);
		    request.setAttribute("expertData", raMemberFinancialReviewVO);
		    GenericDisplayPageForm rptYr = RAExpertHelper.convertForDisplay(request.getParameter("paymentYear"), false, 
		    		raMemberFinancialReviewVO.getPayBaselineMap(), raMemberFinancialReviewVO.getBaselineRAFactorMap(),
		    		raMemberFinancialReviewVO.getReconCMSMap(),raMemberFinancialReviewVO.getReconCMSRAFactorMap(), 
		    		raMemberFinancialReviewVO.getReconPlanMap(), raMemberFinancialReviewVO.getReconPlanRAFactorMap(), 
		    		raMemberFinancialReviewVO.getPlanRAPSMap(), raMemberFinancialReviewVO.getPlanRAPSRAFactorMap(), 
		    		raMemberFinancialReviewVO.getPlanHCCMODDMap(), raMemberFinancialReviewVO.getPlanHCCMODDRAFactorMap(),
					new HashMap(), new HashMap());
		        request.setAttribute("rptYr", rptYr);
		    
		    request.getSession().setAttribute("RAReportVO", raMemberFinancialReviewVO);
			DiseaseGroupPersistence diseaseGroupPersistence = new DiseaseGroupPersistence();
			
			BeneficiaryPersistence beneficiaryPersistence = new BeneficiaryPersistence();
			BeneInfo beneInfo = beneficiaryPersistence.getBeneInfo(conn, planId, hicNumber);
			request.setAttribute("beneInfo", beneInfo);
			
			// Disease Group Names
			ArrayList diseaseNameList = diseaseGroupPersistence.getDiseaseGroupByYear(conn, String.valueOf(paymentYear));
			if ( diseaseNameList == null || diseaseNameList.size() == 0 ){
				diseaseNameList = diseaseGroupPersistence.getDiseaseGroupByMaxYear(conn);
			}
			request.setAttribute("diseaseGroup", diseaseNameList);	    
		}
		else if ("yrToYr".equals(method)) {
			BeneficiaryPersistence beneficiaryPersistence = new BeneficiaryPersistence();
			BeneInfo beneInfo = beneficiaryPersistence.getBeneInfo(conn, planId, hicNumber);
			request.setAttribute("beneInfo", beneInfo);
			List results = RAYrToYrCompare.getList(conn, planId, hicNumber, paymentYear);
			request.setAttribute("yrToYrList", results);
		}
		else if ("hccHistory".equals(method)) {
			BeneficiaryPersistence beneficiaryPersistence = new BeneficiaryPersistence();
			BeneInfo beneInfo = beneficiaryPersistence.getBeneInfo(conn, planId, hicNumber);
			request.setAttribute("beneInfo", beneInfo);
			List results = RAHccHistory.getList(conn, planId, hicNumber, paymentYear,hccModd);
			request.setAttribute("items", results);
		}
		else if ("hccProjection".equals(method)) {
			BeneficiaryPersistence beneficiaryPersistence = new BeneficiaryPersistence();
			BeneInfo beneInfo = beneficiaryPersistence.getBeneInfo(conn, planId, hicNumber);
			request.setAttribute("beneInfo", beneInfo);
			List results = RAHccProjection.getList(conn, planId, hicNumber, paymentYear,hccModd);
			request.setAttribute("hccProjItems", results);
		}
		else if ("finAudit".equals(method)){
			String diagCd = request.getParameter("diagCd");
			String partCCat = request.getParameter("partCCat");
			String partDCat = request.getParameter("partDCat");
			String hcc = request.getParameter("hcc");
			
			BeneficiaryPersistence beneficiaryPersistence = new BeneficiaryPersistence();
			BeneInfo beneInfo = beneficiaryPersistence.getBeneInfo(conn, planId, hicNumber);
			request.setAttribute("beneInfo", beneInfo);
			RAPSFinancialAuditVO rapsFinancialAuditVO = new RAPSFinancialAuditVO(conn, mfId, planId, hicNumber, year, diagCd, partCCat, partDCat, hcc,hccModd);
			GenericDisplayPageForm finAuditItems = RAExpertHelper.getDisplay(rapsFinancialAuditVO.getRapsFinanceialAudit());
			request.setAttribute("finAuditItems", finAuditItems);
		} else {
			request.setAttribute("Msg","Invalid method " + method);
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward("raExpertError");
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(method);
	}
	

}
