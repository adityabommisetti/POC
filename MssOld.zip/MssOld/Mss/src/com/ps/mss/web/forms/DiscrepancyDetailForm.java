/*
 * $Id: DiscrepancyDetailForm.java,v 1.1 2014/06/26 07:55:42 praveen Exp $
 */
package com.ps.mss.web.forms;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.manager.MasterManager;
import com.ps.mss.model.DiscrepancyDetailVOList;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.util.NameValuePair;

/**
 * Form bean for a Struts application.
 * @version 	1.0
 * @author
 */
public class DiscrepancyDetailForm extends ActionForm {
	
	private String planName;
	private String fromDate;
	private String toDate;
	private String updateDateFrom;
	private String updateDateTo;
	private String discCd;
	private String hicNbr;
	private String actionType;
	private String pageType;
	private String searchType;
	private String partName = Constants.BOTH_PARTS;
	private String discrepancyType;
	private String updateId;
	private NameValuePair [] discStatusArray;
	private NameValuePair [] discrpTypeList;
	private NameValuePair [] planNameList;
	
	private DiscrepancyDetailVOList discrepancyDetailVOList;
	
	private String showDiscrpList;
	private String showPartDDiscrpList;
	private String showDiscrpDetail;
	private String showDiscrpHistory;
	private String showDemoGrpInfo;
	private String activeService;
	private String menuName;
	private String criteriaAvailable = "true";
	//Recon Demo-WorkQueue
    private String select;
    
    
			
	/**
	 * @return the select
	 */
	public String getSelect() {
		return select;
	}
	/**
	 * @param select the select to set
	 */
	public void setSelect(String select) {
		this.select = select;
	}
	//Recon Demo-WorkQueue
	/**
	 * @return Returns the showPartDDiscrpList.
	 */
	public String getShowPartDDiscrpList() {
		return showPartDDiscrpList;
	}
	/**
	 * @param showPartDDiscrpList The showPartDDiscrpList to set.
	 */
	public void setShowPartDDiscrpList(String showPartDDiscrpList) {
		this.showPartDDiscrpList = showPartDDiscrpList;
	}
	/**
	 * @return Returns the showDemoGrpInfo.
	 */
	public String getShowDemoGrpInfo() {
		return showDemoGrpInfo;
	}
	/**
	 * @param showDemoGrpInfo The showDemoGrpInfo to set.
	 */
	public void setShowDemoGrpInfo(String showDemoGrpInfo) {
		this.showDemoGrpInfo = showDemoGrpInfo;
	}
	/**
	 * @return Returns the menuName.
	 */
	public String getMenuName() {
		return menuName;
	}
	/**
	 * @param menuName The menuName to set.
	 */
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	/**
	 * @return Returns the showDiscrpDetail.
	 */
	public String getShowDiscrpDetail() {
		return showDiscrpDetail;
	}
	/**
	 * @param showDiscrpDetail The showDiscrpDetail to set.
	 */
	public void setShowDiscrpDetail(String showDiscrpDetail) {
		this.showDiscrpDetail = showDiscrpDetail;
	}
	/**
	 * @return Returns the showDiscrpHistory.
	 */
	public String getShowDiscrpHistory() {
		return showDiscrpHistory;
	}
	/**
	 * @param showDiscrpHistory The showDiscrpHistory to set.
	 */
	public void setShowDiscrpHistory(String showDiscrpHistory) {
		this.showDiscrpHistory = showDiscrpHistory;
	}
	/**
	 * @return Returns the showDiscrpList.
	 */
	public String getShowDiscrpList() {
		return showDiscrpList;
	}
	/**
	 * @param showDiscrpList The showDiscrpList to set.
	 */
	public void setShowDiscrpList(String showDiscrpList) {
		this.showDiscrpList = showDiscrpList;
	}
	/**
	 * @return Returns the updateId.
	 */
	public String getUpdateId() {
		return updateId;
	}
	/**
	 * @param updateId The updateId to set.
	 */
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}
	/**
	 * @return Returns the discrepancyType.
	 */
	public String getDiscrepancyType() {
		return discrepancyType;
	}
	/**
	 * @param discrepancyType The discrepancyType to set.
	 */
	public void setDiscrepancyType(String discrepancyType) {
		this.discrepancyType = discrepancyType;
	}
	/**
	 * @return Returns the actionType.
	 */
	public String getActionType() {
		return actionType;
	}
	/**
	 * @param actionType The actionType to set.
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	/**
	 * @return Returns the discCd.
	 */
	public String getDiscCd() {
		return discCd;
	}
	/**
	 * @param discCd The discCd to set.
	 */
	public void setDiscCd(String discCd) {
		this.discCd = discCd;
	}
	
	/**
	 * @return Returns the discrpTypeList.
	 */
	public NameValuePair[] getDiscrpTypeList() {
		return discrpTypeList;
	}
	/**
	 * @param discrpTypeList The discrpTypeList to set.
	 */
	public void setDiscrpTypeList(NameValuePair[] discrpTypeList) {
		this.discrpTypeList = discrpTypeList;
	}
	/**
	 * @return Returns the discStatusArray.
	 */
	public NameValuePair[] getDiscStatusArray() {
		return discStatusArray;
	}
	/**
	 * @param discStatusArray The discStatusArray to set.
	 */
	public void setDiscStatusArray(NameValuePair[] discStatusArray) {
		this.discStatusArray = discStatusArray;
	}
		
	/**
	 * @return Returns the fromDate.
	 */
	public String getFromDate() {
		return fromDate;
	}
	/**
	 * @param fromDate The fromDate to set.
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	/**
	 * @return Returns the toDate.
	 */
	public String getToDate() {
		return toDate;
	}
	/**
	 * @param toDate The toDate to set.
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	/**
	 * @return Returns the hicNbr.
	 */
	public String getHicNbr() {
		if(hicNbr != null)
			return hicNbr.toUpperCase();
			
		return hicNbr;
	}
	/**
	 * @param hicNbr The hicNbr to set.
	 */
	public void setHicNbr(String hicNbr) {
		this.hicNbr = hicNbr;
	}
	/**
	 * @return Returns the partName.
	 */
	public String getPartName() {
		return partName;
	}
	/**
	 * @param partName The partName to set.
	 */
	public void setPartName(String partName) {
		this.partName = partName;
	}
	/**
	 * @return Returns the planName.
	 */
	public String getPlanName() {
		return planName;
	}
	/**
	 * @param planName The planName to set.
	 */
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	/**
	 * @return Returns the searchType.
	 */
	public String getSearchType() {
		return searchType;
	}
	/**
	 * @param searchType The searchType to set.
	 */
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	/**
	 * @return Returns the updateDateFrom.
	 */
	public String getUpdateDateFrom() {
		return updateDateFrom;
	}
	/**
	 * @param updateDateFrom The updateDateFrom to set.
	 */
	public void setUpdateDateFrom(String updateDateFrom) {
		this.updateDateFrom = updateDateFrom;
	}
	/**
	 * @return Returns the updateDateTo.
	 */
	public String getUpdateDateTo() {
		return updateDateTo;
	}
	/**
	 * @param updateDateTo The updateDateTo to set.
	 */
	public void setUpdateDateTo(String updateDateTo) {
		this.updateDateTo = updateDateTo;
	}
	
	
	
	
    public void reset(ActionMapping mapping, HttpServletRequest request) {
    	showDiscrpList = "";
    	showPartDDiscrpList = "";
    	showDiscrpDetail = "";
    	showDiscrpHistory = "";
    	showDemoGrpInfo = "";
    	partName = Constants.BOTH_PARTS;
    	criteriaAvailable = "true";
    	//partCPageHist = "";
    }
    

	/**
	 * @return Returns the discrepancyDetailVOList.
	 */
	public DiscrepancyDetailVOList getDiscrepancyDetailVOList() {
		return discrepancyDetailVOList;
	}
	/**
	 * @param discrepancyDetailVOList The discrepancyDetailVOList to set.
	 */
	public void setDiscrepancyDetailVOList(
			DiscrepancyDetailVOList discrepancyDetailVOList) {
		this.discrepancyDetailVOList = discrepancyDetailVOList;
	}
	
	
	/**
	 * @return Returns the planNameList.
	 */
	public NameValuePair[] getPlanNameList() {
		return planNameList;
	}
	/**
	 * @param planNameList The planNameList to set.
	 */
	public void setPlanNameList(NameValuePair[] planNameList) {
		this.planNameList = planNameList;
	}
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {

        ActionErrors errors = new ActionErrors();
        return errors;

    }
	/**
	 * @param request
	 * @throws ApplicationException
	 */
    public void init(HttpServletRequest request) throws ApplicationException {
    	SessionHelper sessionHelper = new SessionHelper(request);
    	NameValuePair[] planIdArr = sessionHelper.getPlanIdArray();
    	setPlanNameList(planIdArr);

    	activeService = sessionHelper.getServicesToAccess();
    	if(Constants.BOTH_PARTS.equals(partName))
    		partName = activeService;

    	setDiscrpTypeList(MasterManager.getDiscrpArr(partName));
    	setDiscStatusArray(MasterManager.getDiscrpStatusArr());
    	
    }
	/**
	 * @return Returns the pageType.
	 */
	public String getPageType() {
		return pageType;
	}
	/**
	 * @param pageType The pageType to set.
	 */
	public void setPageType(String pageType) {
		this.pageType = pageType;
	}
	public String getActiveService() {
		return activeService;
	}
	public void setActiveService(String activeService) {
		this.activeService = activeService;
	}
	/**
	 * @return Returns the criteriaAvailable.
	 */
	public String getCriteriaAvailable() {
		return criteriaAvailable;
	}
	/**
	 * @param criteriaAvailable The criteriaAvailable to set.
	 */
	public void setCriteriaAvailable(String criteriaAvailable) {
		this.criteriaAvailable = criteriaAvailable;
	}
	
	private String subWorkMenu;



	/**
	 * @return the subWorkMenu
	 */
	public String getSubWorkMenu() {
		return subWorkMenu;
	}
	/**
	 * @param subWorkMenu the subWorkMenu to set
	 */
	public void setSubWorkMenu(String subWorkMenu) {
		this.subWorkMenu = subWorkMenu;
	}
	
}
