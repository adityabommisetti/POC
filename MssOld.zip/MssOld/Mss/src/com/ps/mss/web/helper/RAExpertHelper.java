/**$Id: RAExpertHelper.java,v 1.1 2014/06/26 07:55:08 praveen Exp $*/

package com.ps.mss.web.helper;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.model.RADiseaseGroup;
import com.ps.mss.web.forms.GenericDisplayPageForm;
import com.ps.util.StringUtil;

public class RAExpertHelper {
	private static Logger logger=LoggerFactory.getLogger(RAExpertHelper.class);
	public static GenericDisplayPageForm convertForDisplay(String year, boolean projectionReport, Map baselineMap, Map baselineRAFactorMap,
			Map reconCMSMap, Map reconCMSRAFactorMap, Map reconPlanMap, Map reconPlanRAFactorMap,
			Map planRAPSMap, Map planRAPSRAFactorMap, Map planHCCMODDMap, Map planHCCMODDRAFactorMap,
			Map planRAPSLAGMap, Map planRAPSLAGRAFactorMap) {
		logger.info(LoggerConstants.methodStartLevel());
		double[] dtotal = new double[12];
		String[] totals = {"", "", "", "", "", "", "", "", "", "", "", ""}; 
		GenericDisplayPageForm display = new GenericDisplayPageForm();
		List items = new ArrayList();
		
		int endMonth = (projectionReport) ? 1 : 12;
		String style = "";
		String paymentPeriod = "";
		DecimalFormat decimalFormat = new DecimalFormat(",##0.00");
		DecimalFormat factorFormat = new DecimalFormat("#0.000");
		for ( int i = 1; i <= endMonth; i++){
			paymentPeriod = year + new DecimalFormat("00").format(i);
			if (baselineMap.containsKey(paymentPeriod) 
					|| baselineRAFactorMap.containsKey(paymentPeriod)
					|| reconCMSMap.containsKey(paymentPeriod)
					|| reconCMSRAFactorMap.containsKey(paymentPeriod)
					|| reconPlanMap.containsKey(paymentPeriod)
					|| reconPlanRAFactorMap.containsKey(paymentPeriod)
					|| planRAPSMap.containsKey(paymentPeriod)
					|| planRAPSRAFactorMap.containsKey(paymentPeriod)
					|| planHCCMODDMap.containsKey(paymentPeriod)
					|| planHCCMODDRAFactorMap.containsKey(paymentPeriod)
					|| planRAPSLAGMap.containsKey(paymentPeriod)
					|| planRAPSLAGRAFactorMap.containsKey(paymentPeriod)
				) {
				
				RADiseaseGroup dg = new RADiseaseGroup();	
				dg.setPaymentPeriod(paymentPeriod);
				double d = getNumber((String) baselineMap.get(paymentPeriod));
				if ( projectionReport) dtotal[0] = d * 12; else dtotal[0] += d;
				dg.setBaseline(decimalFormat.format(d));
				
				d = getNumber((String) baselineRAFactorMap.get(paymentPeriod));
				if ( projectionReport) dtotal[1] = d * 12; else dtotal[1] += d;
				dg.setBaselineRAFactor(factorFormat.format(d));
				
				d = getNumber((String) reconCMSMap.get ( paymentPeriod));
				if ( projectionReport) dtotal[2] = d * 12; else dtotal[2] += d;
				dg.setReconCMS(decimalFormat.format(d));
				
				d = getNumber((String) reconCMSRAFactorMap.get ( paymentPeriod));
				if ( projectionReport) dtotal[3] = d * 12; else dtotal[3] += d;
				dg.setReconCMSRAFactor(factorFormat.format(d));
				
				d = getNumber((String) reconPlanMap.get ( paymentPeriod));
				if ( projectionReport) dtotal[4] = d * 12; else dtotal[4] += d;
				dg.setReconPlan(decimalFormat.format(d));
				
				d = getNumber((String) reconPlanRAFactorMap.get ( paymentPeriod));
				if ( projectionReport) dtotal[5] = d * 12; else dtotal[5] += d;
				dg.setReconPlanRAFactor(factorFormat.format(d));
				
				d = getNumber((String) planRAPSMap.get ( paymentPeriod));
				if ( projectionReport) dtotal[6] = d * 12; else dtotal[6] += d;
				dg.setRaps(decimalFormat.format(d));
				
				d = getNumber((String) planRAPSRAFactorMap.get ( paymentPeriod));
				if ( projectionReport) dtotal[7] = d * 12; else dtotal[7] += d;
				dg.setRapsRAFactor (factorFormat.format(d));
				
				d = getNumber((String) planHCCMODDMap.get ( paymentPeriod));
				if ( projectionReport) dtotal[8] = d * 12; else dtotal[8] += d;
				dg.setHccModd(decimalFormat.format(d));
				
				d = getNumber((String) planHCCMODDRAFactorMap.get ( paymentPeriod));
				if ( projectionReport) dtotal[9] = d * 12; else dtotal[9] += d;
				dg.setHccModdRAFactor(factorFormat.format(d));
				
				d = getNumber((String) planRAPSLAGMap.get ( paymentPeriod));
				if ( projectionReport) dtotal[10] = d * 12; else dtotal[10] += d;
				dg.setRapsLag(decimalFormat.format(d));
				
				d = getNumber((String) planRAPSLAGRAFactorMap.get ( paymentPeriod));
				if ( projectionReport) dtotal[11] = d * 12; else dtotal[11] += d;
				dg.setRapsLagRAFactor(factorFormat.format(d));
				
				items.add(dg);
			}
		}
		for (int j = 0; j<dtotal.length; j++) {
			totals[j] = decimalFormat.format(dtotal[j]);
		}
		if (items.size() > 0)
			display.setListObject(items);
		display.setDetail(totals);
		logger.info(LoggerConstants.methodEndLevel());
		return display;
	}
	
	public static GenericDisplayPageForm getDisplay(ArrayList list) {
		logger.info(LoggerConstants.methodStartLevel());
		GenericDisplayPageForm display = new GenericDisplayPageForm();
		if (list.size() > 0)
			display.setListObject(list);
		logger.info(LoggerConstants.methodEndLevel());
		return display;
	}
	
	private static double getNumber(String value){
		logger.info(LoggerConstants.methodStartLevel());
		if (StringUtil.isNullOrEmpty(value)){
			logger.info(LoggerConstants.methodEndLevel());
			return 0;
		}
		logger.info(LoggerConstants.methodEndLevel());
		return Double.parseDouble(value);
	}
}
