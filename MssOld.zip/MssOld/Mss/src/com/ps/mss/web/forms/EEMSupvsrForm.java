/*
 * $Id: EEMSupvsrForm.java,v 1.1 2014/06/26 07:55:48 praveen Exp $
 */
package com.ps.mss.web.forms;

import java.util.List;

import com.ps.util.ListBoxItem;

/**
 * @author Raghu.Gorur
 *
 */
public class EEMSupvsrForm extends EEMForm { 
	
	/* Search fields */
	private String searchApplStatus;
	private String searchOperId;
	private String searchApplType;
	private String searchEsrd;
	private String searchEffDt;
	private String searchApplRcvdDt;
	
	private String setAllStatus;
	
	private String customerId;
	private String applId;
	private String customerNbr;
	private String operId;
	
	private List lstApplStatus;
	private List lstApplType;
	private ListBoxItem[] lstEsrd;
	private List lstApprovalStatus;
	
	private List lstSearch;
	private String[] rowApprStatus;
	
	/**
	 * @return Returns the searchApplRcvdDt.
	 */
	public String getSearchApplRcvdDt() {
		return searchApplRcvdDt;
	}
	/**
	 * @param searchApplRcvdDt The searchApplRcvdDt to set.
	 */
	public void setSearchApplRcvdDt(String searchApplRcvdDt) {
		this.searchApplRcvdDt = searchApplRcvdDt;
	}
	/**
	 * @return Returns the searchApplStatus.
	 */
	public String getSearchApplStatus() {
		return searchApplStatus;
	}
	/**
	 * @param searchApplStatus The searchApplStatus to set.
	 */
	public void setSearchApplStatus(String searchApplStatus) {
		this.searchApplStatus = searchApplStatus;
	}
	/**
	 * @return Returns the searchApplType.
	 */
	public String getSearchApplType() {
		return searchApplType;
	}
	/**
	 * @param searchApplType The searchApplType to set.
	 */
	public void setSearchApplType(String searchApplType) {
		this.searchApplType = searchApplType;
	}
	/**
	 * @return Returns the searchEffDt.
	 */
	public String getSearchEffDt() {
		return searchEffDt;
	}
	/**
	 * @param searchEffDt The searchEffDt to set.
	 */
	public void setSearchEffDt(String searchEffDt) {
		this.searchEffDt = searchEffDt;
	}
	/**
	 * @return Returns the searchEsrd.
	 */
	public String getSearchEsrd() {
		return searchEsrd;
	}
	/**
	 * @param searchEsrd The searchEsrd to set.
	 */
	public void setSearchEsrd(String searchEsrd) {
		this.searchEsrd = searchEsrd;
	}
	/**
	 * @return Returns the searchOperId.
	 */
	public String getSearchOperId() {
		return searchOperId;
	}
	/**
	 * @param searchOperId The searchOperId to set.
	 */
	public void setSearchOperId(String searchOperId) {
		this.searchOperId = searchOperId;
	}
	/**
	 * @return Returns the customerId.
	 */
	public String getCustomerId() {
		return customerId;
	}
	/**
	 * @param customerId The customerId to set.
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	/**
	 * @return Returns the customerNbr.
	 */
	public String getCustomerNbr() {
		return customerNbr;
	}
	/**
	 * @param customerNbr The customerNbr to set.
	 */
	public void setCustomerNbr(String customerNbr) {
		this.customerNbr = customerNbr;
	}
	/**
	 * @return Returns the operId.
	 */
	public String getOperId() {
		return operId;
	}
	/**
	 * @param operId The operId to set.
	 */
	public void setOperId(String operId) {
		this.operId = operId;
	}
	/**
	 * @return Returns the lstApplStatus.
	 */
	public List getLstApplStatus() {
		return lstApplStatus;
	}
	/**
	 * @param lstApplStatus The lstApplStatus to set.
	 */
	public void setLstApplStatus(List lstApplStatus) {
		this.lstApplStatus = lstApplStatus;
	}
	/**
	 * @return Returns the lstApplType.
	 */
	public List getLstApplType() {
		return lstApplType;
	}
	/**
	 * @param lstApplType The lstApplType to set.
	 */
	public void setLstApplType(List lstApplType) {
		this.lstApplType = lstApplType;
	}
	/**
	 * @return Returns the lstApprovalStatus.
	 */
	public List getLstApprovalStatus() {
		return lstApprovalStatus;
	}
	/**
	 * @param lstApprovalStatus The lstApprovalStatus to set.
	 */
	public void setLstApprovalStatus(List lstApprovalStatus) {
		this.lstApprovalStatus = lstApprovalStatus;
	}
	/**
	 * @return Returns the lstEsrd.
	 */
	public ListBoxItem[] getLstEsrd() {
		return lstEsrd;
	}
	/**
	 * @param lstEsrd The lstEsrd to set.
	 */
	public void setLstEsrd(ListBoxItem[] lstEsrd) {
		this.lstEsrd = lstEsrd;
	}
	/**
	 * @return Returns the setAllStatus.
	 */
	public String getSetAllStatus() {
		return setAllStatus;
	}
	/**
	 * @param setAllStatus The setAllStatus to set.
	 */
	public void setSetAllStatus(String setAllStatus) {
		this.setAllStatus = setAllStatus;
	}
	/**
	 * @return Returns the lstSearch.
	 */
	public List getLstSearch() {
		return lstSearch;
	}
	/**
	 * @param lstSearch The lstSearch to set.
	 */
	public void setLstSearch(List lstSearch) {
		this.lstSearch = lstSearch;
	}
	/**
	 * @return Returns the rowApprStatus.
	 */
	public String[] getRowApprStatus() {
		return rowApprStatus;
	}
	/**
	 * @param rowApprStatus The rowApprStatus to set.
	 */
	public void setRowApprStatus(String[] rowApprStatus) {
		this.rowApprStatus = rowApprStatus;
	}
	/**
	 * @return Returns the applId.
	 */
	public String getApplId() {
		return applId;
	}
	/**
	 * @param applId The applId to set.
	 */
	public void setApplId(String applId) {
		this.applId = applId;
	}
}
