/*
 * $Id: AjaxUtil.java,v 1.1 2014/06/26 07:57:00 praveen Exp $
 */
package com.ps.mss.web.ajax;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.model.BasePaginationPage;
import com.ps.mss.model.HistoryTrail;
import com.ps.mss.model.Pagination;

public class AjaxUtil {
	private static Logger logger=LoggerFactory.getLogger(AjaxUtil.class);
	public static void setPrevDetailFromHistory(HistoryTrail pagingItem, Pagination pagination) {
		logger.info(LoggerConstants.methodStartLevel());
		String pageHist = (String) pagination.getPageHistory();
		if(pageHist != null){
			String historyStr;
			
			if(pageHist.indexOf(",") == -1)
				historyStr = pageHist;
			else {
				String [] pageHistArr = pageHist.split("[,]");				
				//	getting Last page 
				historyStr = pageHistArr[pageHistArr.length-1];
			}
			pagingItem.setFieldsBasedOnHistory(historyStr);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}  
	public static void setPagination(Pagination pagination, BasePaginationPage detailPage, int arrSize, Object firstItem, Object lastItem, String move) {
		logger.info(LoggerConstants.methodStartLevel());
		if(arrSize > 0 ){
            //**************** START BLOCK FOR CALCULATING PAGE HIST ***************************
			// ADD : When user click on NEXT button (adding prev. page First VO
			// REMOVE : When user click on PREV button (remove top entry from List (it. current loading page)
			//
			
        	String pageHist = (String) pagination.getPageHistory();
            String newPageHist = (pageHist != null) ? pageHist : "";
            
            // updating Page Hist 
            if("previous".equals(move)){
            	if(newPageHist.indexOf(",") != -1) {
                	String []pageHistArr = pageHist.split("[,]"); // spliting the list, remove last entry (CURRENT PAGE)
                	newPageHist = pageHistArr[0];
                	for(int i=1; i < pageHistArr.length-1; i++ )
                		newPageHist += "," + pageHistArr[i];
            	} else 
            		newPageHist = "";
            	
    		} else if ("next".equals(move)) {  // adding current page Paging Key Set into PDE PAGE HIST
    			HistoryTrail detailItem = (HistoryTrail) pagination.getFirstDetail();
    			if(! "".equals(newPageHist))
    				newPageHist += ",";
   				newPageHist += detailItem.getHistory();
        	}
    		
    		if(("previous".equals(move) && "".equals(newPageHist)) || "first".equals(move))
    			pagination.setPageHistory(null);
    		else
    			pagination.setPageHistory(newPageHist);
    		
            //**************** START BLOCK FOR CALCULATING PAGE HIST ***************************
    		pagination.setFirstDetail(firstItem);
    		pagination.setLastDetail(lastItem);
    		pagination.setCurrentPage(detailPage.getCurrentPage());
    		pagination.setPageNumber(detailPage.getPageNumber());
    		pagination.setSelectedLine(detailPage.getSelectedLine());
        }
		pagination.setMaxRecordCount(10);
		pagination.setAllPage(false);   
		logger.info(LoggerConstants.methodEndLevel());
    } 
}
