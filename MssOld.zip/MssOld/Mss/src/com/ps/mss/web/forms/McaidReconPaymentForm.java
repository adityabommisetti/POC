package com.ps.mss.web.forms;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import com.ps.mss.dao.model.McaidPaymentDashBoardVO;
import com.ps.mss.model.DiscrepancyDashBoardVO;
import com.ps.mss.model.DiscrepancySummaryVOList;


/**
 * Form bean for a Struts application.
 * @version 	1.0
 * @author
 */
public class McaidReconPaymentForm extends McaidReconBaseForm {

	
	private String pbpId;
	private String year;
	private String month;
	private String quarter;
	
	private String cmsPaid;
	private String planExpected;
	private String diffrence;		
		
	private List mcaidPymntDsbPBPLst;
	/*private List mcaidPymntDsbYearLst;
	private List mcaidPymntDsbQtrLst;
	private List mcaidPymntDsbMonthlst;
	*/
	private DiscrepancyDashBoardVO [] discrepancyDashBoardVO = null;
	private DiscrepancySummaryVOList discrepancySummaryVOList= null ;
	
	//--------------Payment Summary-------------------	
	
	private String summSrchPbp;
	private String summSrchYear;
	private String summSrchQtr;
	private String summSrchMonth;
	
	private String summPageLabel1;
	private String summPageLabel2;
	
	//--Summary Page section-1
	private String summDataCmsPaid;
	private String summDataPlanExpected;
	private String summDataDiffrence;
	private List mcaidPymntSummLst;
	
	//--Summary Page section-2
	private String summDetailCmsPaid;
	private String summDetailPlanExpected;
	private String summDetailDiffrence;
	private List mcaidPymntSummDetailLst;
	
	//--Summary Page section-3-Medicaid List
	private String summSrchPaymentType;
	private List mcaidPymntSummMedicaidLst;
	private int summMedicLstPageNbr;
	private String summMedicLstPageType;
	
 // - Payment Search page Values
	private String pbpIdPayment;
	private String fromDate;
	private String toDate;
	private String dateType;
	//Added for new Medicaid ID search criteria 
	private String medicaidId;
	
	private List lstpbpIdPayment;
	
	//--------------------------------------------------
	/**
	 * @return Returns the discrepancySummaryVOList.
	 */
	public DiscrepancySummaryVOList getDiscrepancySummaryVOList() {
		return discrepancySummaryVOList;
	}
	/**
	 * @param discrepancySummaryVOList The discrepancySummaryVOList to set.
	 */
	public void setDiscrepancySummaryVOList(
			DiscrepancySummaryVOList discrepancySummaryVOList) {
		this.discrepancySummaryVOList = discrepancySummaryVOList;
	}
	/**
	 * @return Returns the discrepancyDashBoardVO.
	 */
	public DiscrepancyDashBoardVO[] getDiscrepancyDashBoardVO() {
		return discrepancyDashBoardVO;
	}
	/**
	 * @param discrepancyDashBoardVO The discrepancyDashBoardVO to set.
	 */
	public void setDiscrepancyDashBoardVO(
			DiscrepancyDashBoardVO[] discrepancyDashBoardVO) {
		this.discrepancyDashBoardVO = discrepancyDashBoardVO;
	}
	
    public void reset(ActionMapping mapping, HttpServletRequest request) {

        // Reset field values here.

    }

    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {

        ActionErrors errors = new ActionErrors();
        // Validate the fields in your form, adding
        // adding each error to this.errors as found, e.g.

        // if ((field == null) || (field.length() == 0)) {
        //   errors.add("field", new org.apache.struts.action.ActionError("error.field.required"));
        // }
        return errors;

    }
	
	/**
	 * @return the pbpId
	 */
	public String getPbpId() {
		return pbpId;
	}
	/**
	 * @param pbpId the pbpId to set
	 */
	public void setPbpId(String pbpId) {
		this.pbpId = pbpId;
	}
	/**
	 * @return the cmsPaid
	 */
	public String getCmsPaid() {
		return cmsPaid;
	}
	/**
	 * @param cmsPaid the cmsPaid to set
	 */
	public void setCmsPaid(String cmsPaid) {
		this.cmsPaid = cmsPaid;
	}
	/**
	 * @return the planExpected
	 */
	public String getPlanExpected() {
		return planExpected;
	}
	/**
	 * @param planExpected the planExpected to set
	 */
	public void setPlanExpected(String planExpected) {
		this.planExpected = planExpected;
	}
	/**
	 * @return the diffrence
	 */
	public String getDiffrence() {
		return diffrence;
	}
	/**
	 * @param diffrence the diffrence to set
	 */
	public void setDiffrence(String diffrence) {
		this.diffrence = diffrence;
	}
	
	/**
	 * @return the year
	 */
	public String getYear() {
		return year;
	}
	/**
	 * @param year the year to set
	 */
	public void setYear(String year) {
		this.year = year;
	}
	/**
	 * @return the month
	 */
	public String getMonth() {
		return month;
	}
	/**
	 * @param month the month to set
	 */
	public void setMonth(String month) {
		this.month = month;
	}
	/**
	 * @return the quarter
	 */
	public String getQuarter() {
		return quarter;
	}
	/**
	 * @param quarter the quarter to set
	 */
	public void setQuarter(String quarter) {
		this.quarter = quarter;
	}
	/**
	 * @return the mcaidPymntDsbPBPLst
	 */
	public List getMcaidPymntDsbPBPLst() {
		return mcaidPymntDsbPBPLst;
	}
	/**
	 * @param mcaidPymntDsbPBPLst the mcaidPymntDsbPBPLst to set
	 */
	public void setMcaidPymntDsbPBPLst(List mcaidPymntDsbPBPLst) {
		this.mcaidPymntDsbPBPLst = mcaidPymntDsbPBPLst;
	}
	/**
	 * @return the summSrchPbp
	 */
	public String getSummSrchPbp() {
		return summSrchPbp;
	}
	/**
	 * @param summSrchPbp the summSrchPbp to set
	 */
	public void setSummSrchPbp(String summSrchPbp) {
		this.summSrchPbp = summSrchPbp;
	}
	/**
	 * @return the summSrchYear
	 */
	public String getSummSrchYear() {
		return summSrchYear;
	}
	/**
	 * @param summSrchYear the summSrchYear to set
	 */
	public void setSummSrchYear(String summSrchYear) {
		this.summSrchYear = summSrchYear;
	}
	/**
	 * @return the summSrchQtr
	 */
	public String getSummSrchQtr() {
		return summSrchQtr;
	}
	/**
	 * @param summSrchQtr the summSrchQtr to set
	 */
	public void setSummSrchQtr(String summSrchQtr) {
		this.summSrchQtr = summSrchQtr;
	}
	/**
	 * @return the summSrchMonth
	 */
	public String getSummSrchMonth() {
		return summSrchMonth;
	}
	/**
	 * @param summSrchMonth the summSrchMonth to set
	 */
	public void setSummSrchMonth(String summSrchMonth) {
		this.summSrchMonth = summSrchMonth;
	}
	/**
	 * @return the mcaidPymntSummLst
	 */
	public List getMcaidPymntSummLst() {
		return mcaidPymntSummLst;
	}
	/**
	 * @param mcaidPymntSummLst the mcaidPymntSummLst to set
	 */
	public void setMcaidPymntSummLst(List mcaidPymntSummLst) {
		this.mcaidPymntSummLst = mcaidPymntSummLst;
	}
	/**
	 * @return the mcaidPymntSummDetailLst
	 */
	public List getMcaidPymntSummDetailLst() {
		return mcaidPymntSummDetailLst;
	}
	/**
	 * @param mcaidPymntSummDetailLst the mcaidPymntSummDetailLst to set
	 */
	public void setMcaidPymntSummDetailLst(List mcaidPymntSummDetailLst) {
		this.mcaidPymntSummDetailLst = mcaidPymntSummDetailLst;
	}
	/**
	 * @return the summDataCmsPaid
	 */
	public String getSummDataCmsPaid() {
		return summDataCmsPaid;
	}
	/**
	 * @param summDataCmsPaid the summDataCmsPaid to set
	 */
	public void setSummDataCmsPaid(String summDataCmsPaid) {
		this.summDataCmsPaid = summDataCmsPaid;
	}
	/**
	 * @return the summDataPlanExpected
	 */
	public String getSummDataPlanExpected() {
		return summDataPlanExpected;
	}
	/**
	 * @param summDataPlanExpected the summDataPlanExpected to set
	 */
	public void setSummDataPlanExpected(String summDataPlanExpected) {
		this.summDataPlanExpected = summDataPlanExpected;
	}
	/**
	 * @return the summDataDiffrence
	 */
	public String getSummDataDiffrence() {
		return summDataDiffrence;
	}
	/**
	 * @param summDataDiffrence the summDataDiffrence to set
	 */
	public void setSummDataDiffrence(String summDataDiffrence) {
		this.summDataDiffrence = summDataDiffrence;
	}
	/**
	 * @return the summDetailCmsPaid
	 */
	public String getSummDetailCmsPaid() {
		return summDetailCmsPaid;
	}
	/**
	 * @param summDetailCmsPaid the summDetailCmsPaid to set
	 */
	public void setSummDetailCmsPaid(String summDetailCmsPaid) {
		this.summDetailCmsPaid = summDetailCmsPaid;
	}
	/**
	 * @return the summDetailPlanExpected
	 */
	public String getSummDetailPlanExpected() {
		return summDetailPlanExpected;
	}
	/**
	 * @param summDetailPlanExpected the summDetailPlanExpected to set
	 */
	public void setSummDetailPlanExpected(String summDetailPlanExpected) {
		this.summDetailPlanExpected = summDetailPlanExpected;
	}
	/**
	 * @return the summDetailDiffrence
	 */
	public String getSummDetailDiffrence() {
		return summDetailDiffrence;
	}
	/**
	 * @param summDetailDiffrence the summDetailDiffrence to set
	 */
	public void setSummDetailDiffrence(String summDetailDiffrence) {
		this.summDetailDiffrence = summDetailDiffrence;
	}
	/**
	 * @return the summPageLabel1
	 */
	public String getSummPageLabel1() {
		return summPageLabel1;
	}
	/**
	 * @param summPageLabel1 the summPageLabel1 to set
	 */
	public void setSummPageLabel1(String summPageLabel1) {
		this.summPageLabel1 = summPageLabel1;
	}
	/**
	 * @return the summPageLabel2
	 */
	public String getSummPageLabel2() {
		return summPageLabel2;
	}
	/**
	 * @param summPageLabel2 the summPageLabel2 to set
	 */
	public void setSummPageLabel2(String summPageLabel2) {
		this.summPageLabel2 = summPageLabel2;
	}
	/**
	 * @return the mcaidPymntSummMedicaidLst
	 */
	public List getMcaidPymntSummMedicaidLst() {
		return mcaidPymntSummMedicaidLst;
	}
	/**
	 * @param mcaidPymntSummMedicaidLst the mcaidPymntSummMedicaidLst to set
	 */
	public void setMcaidPymntSummMedicaidLst(List mcaidPymntSummMedicaidLst) {
		this.mcaidPymntSummMedicaidLst = mcaidPymntSummMedicaidLst;
	}
	
	/**
	 * @return the summMedicLstPageType
	 */
	public String getSummMedicLstPageType() {
		return summMedicLstPageType;
	}
	/**
	 * @param summMedicLstPageType the summMedicLstPageType to set
	 */
	public void setSummMedicLstPageType(String summMedicLstPageType) {
		this.summMedicLstPageType = summMedicLstPageType;
	}
	/**
	 * @return the summSrchPaymentType
	 */
	public String getSummSrchPaymentType() {
		return summSrchPaymentType;
	}
	/**
	 * @param summSrchPaymentType the summSrchPaymentType to set
	 */
	public void setSummSrchPaymentType(String summSrchPaymentType) {
		this.summSrchPaymentType = summSrchPaymentType;
	}
	/**
	 * @return the summMedicLstPageNbr
	 */
	public int getSummMedicLstPageNbr() {
		return summMedicLstPageNbr;
	}
	/**
	 * @param summMedicLstPageNbr the summMedicLstPageNbr to set
	 */
	public void setSummMedicLstPageNbr(int summMedicLstPageNbr) {
		this.summMedicLstPageNbr = summMedicLstPageNbr;
	}
	 // - Payment Search page Values -Start
	/**
	 * @return the pbpIdPayment
	 */
	public String getPbpIdPayment() {
		return pbpIdPayment;
	}
	/**
	 * @param pbpIdPayment the pbpIdPayment to set
	 */
	public void setPbpIdPayment(String pbpIdPayment) {
		this.pbpIdPayment = pbpIdPayment;
	}
	/**
	 * @return the lstpbpIdPayment
	 */
	public List getLstpbpIdPayment() {
		return lstpbpIdPayment;
	}
	/**
	 * @param lstpbpIdPayment the lstpbpIdPayment to set
	 */
	public void setLstpbpIdPayment(List lstpbpIdPayment) {
		this.lstpbpIdPayment = lstpbpIdPayment;
	}
	/**
	 * @return the fromDate
	 */
	public String getFromDate() {
		return fromDate;
	}
	/**
	 * @param fromDate the fromDate to set
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	/**
	 * @return the toDate
	 */
	public String getToDate() {
		return toDate;
	}
	/**
	 * @param toDate the toDate to set
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	/**
	 * @return the dateType
	 */
	public String getDateType() {
		return dateType;
	}
	/**
	 * @param dateType the dateType to set
	 */
	public void setDateType(String dateType) {
		this.dateType = dateType;
	}
	/**
	 * @return the medicaidId
	 */
	public String getMedicaidId() {
		return medicaidId;
	}
	/**
	 * @param medicaidId the medicaidId to set
	 */
	public void setMedicaidId(String medicaidId) {
		this.medicaidId = medicaidId;
	}
	
	
	// - Payment Search page Values -End
    
    
	
}//class
