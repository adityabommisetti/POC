package com.ps.mss.web.interceptor;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import com.ps.io.ModuleLog;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.web.helper.SessionHelper;

public class SessionValidateFilter implements Filter {
	private static Logger logger=LoggerFactory.getLogger(SessionValidateFilter.class);

	public void init(FilterConfig arg0) throws ServletException {
	}

	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		
		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		HttpServletResponse httpServletResponse = (HttpServletResponse) response;
		
		String requestURL = httpServletRequest.getRequestURI();
		//ModuleLog log = new ModuleLog("SessionValidateFilter");
		
		//logger.error("Requested URL : " + requestURL);
		
		String errorMsg = null;
		SessionHelper sessionHelper = null;
		try {
			sessionHelper = new SessionHelper(httpServletRequest, false);
			errorMsg = sessionHelper.validateUser();
		} catch (ApplicationException e) {
			errorMsg = e.getMessage();
		}
		//validate user
		if(errorMsg != null){
			String queryStr = (String) httpServletRequest.getQueryString();
			if(queryStr.indexOf("logged=true&Msg=") != -1) {
				errorMsg = queryStr.split("Msg=")[1];
			} else 	//Add log for Error
				logger.debug("Error : " + errorMsg);
			
			httpServletResponse.sendRedirect(httpServletRequest.getContextPath()+ Constants.ERROR_PAGE + "?logged=true&Msg=" +  errorMsg);	
			return;
		}
		
		chain.doFilter(request, response);
	}
}