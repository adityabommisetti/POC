/*
 * $Id: PrintAction.java,v 1.1 2014/06/26 07:56:41 praveen Exp $
 */
package com.ps.mss.web.actions;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.DynaActionForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;

/**
 * @author indrapradja.adriana
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class PrintAction extends Action {
	private static Logger logger=LoggerFactory.getLogger(PrintAction.class);
	static ModuleLog log = new ModuleLog("PrintAction");
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodEndLevel());
		DynaActionForm genericForm = (DynaActionForm) form;
		String pageName = (String)genericForm.get("pageName");
		
		if ("raps".equals(pageName.substring(0,4))){
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward("raps");
		}
		//else for future applications.
		else{ 
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward("error");
		}
	}
}
