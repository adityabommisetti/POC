package com.ps.mss.web.helper;

import java.io.FileInputStream;
import java.sql.Connection;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession; /*To add revision number in  claim number IFOX 367728*/

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.HPEEncounterService;
import com.ps.mss.dao.model.Enc837ChangeClaimlogVOs;
import com.ps.mss.dao.model.Enc837iBillprvVO;
import com.ps.mss.dao.model.Enc837iClmOthsubsVO;
import com.ps.mss.dao.model.Enc837iClmOthsubsVOs;
import com.ps.mss.dao.model.Enc837iClmProviderVO;
import com.ps.mss.dao.model.Enc837iClmProviderVOs;
import com.ps.mss.dao.model.Enc837iClmVO;
import com.ps.mss.dao.model.Enc837iClmVOs;
import com.ps.mss.dao.model.Enc837iClmlineAdjudVO;
import com.ps.mss.dao.model.Enc837iClmlineAdjudVOs;
import com.ps.mss.dao.model.Enc837iClmlineProviderVO;
import com.ps.mss.dao.model.Enc837iClmlineProviderVOs;
import com.ps.mss.dao.model.Enc837iClmlineVO;
import com.ps.mss.dao.model.Enc837iClmlineVOs;
import com.ps.mss.dao.model.Enc837iOthsubsProviderVO;
import com.ps.mss.dao.model.Enc837iOthsubsProviderVOs;
import com.ps.mss.dao.model.Enc837iSubsVO;
import com.ps.mss.dao.model.Enc837pBillprvVO;
import com.ps.mss.dao.model.Enc837pClmOthsubsVO;
import com.ps.mss.dao.model.Enc837pClmOthsubsVOs;
import com.ps.mss.dao.model.Enc837pClmProviderVO;
import com.ps.mss.dao.model.Enc837pClmProviderVOs;
import com.ps.mss.dao.model.Enc837pClmlineAdjudVO;
import com.ps.mss.dao.model.Enc837pClmlineAdjudVOs;
import com.ps.mss.dao.model.Enc837pClmlineProviderVO;
import com.ps.mss.dao.model.Enc837pClmlineProviderVOs;
import com.ps.mss.dao.model.Enc837pClmlineVO;
import com.ps.mss.dao.model.Enc837pClmlineVOs;
import com.ps.mss.dao.model.Enc837pOthsubsProviderVO;
import com.ps.mss.dao.model.Enc837pOthsubsProviderVOs;
import com.ps.mss.dao.model.Enc837pSubsVO;
import com.ps.mss.dao.model.EncErrorstatSumVO;
import com.ps.mss.dao.model.EncErrorstatSumVOs;
import com.ps.mss.dao.model.HpeSearchVO;

import com.ps.mss.dao.model.Enc837pClmVO;
import com.ps.mss.dao.model.Enc837pClmVOs;

import com.ps.mss.dao.model.EncCmstatSumVO;
import com.ps.mss.dao.model.EncCmstatSumVOs;
import com.ps.mss.db.ENCCodeCache;

import com.ps.mss.exception.ApplicationException;

import com.ps.mss.framework.HPEConstants;

import com.ps.mss.model.HPEEncounterVO;
import com.ps.mss.model.HPEContext;
import com.ps.mss.model.Pagination;

import com.ps.mss.web.forms.HPEEncounterForm;

import com.ps.text.DateFormatter;
import com.ps.text.DemographicFormatter;
import com.ps.util.DateUtil;
import com.ps.util.GridUtil;
import com.ps.util.StringUtil;

/**
 * @author DParker
 */
public class HPEInstHelper {
	private static Properties prop;
	private static Logger logger=LoggerFactory.getLogger(HPEInstHelper.class);
	public static String getProperty(String sKey)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String sValue = null;
		try {
			if (prop == null) {
				prop = new Properties();
				prop.load(new FileInputStream("HPEProperties.properties"));
			}
			sValue = prop.getProperty(sKey);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return sValue;
	}

	public static void buildStatusSummary(Connection conn, SessionHelper sessionHelper, HPEContext context, HPEEncounterForm hpeEncounterForm, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getEncounterVO();

			// Set customer
			encounterVO.setMfId(/* "HCFLCS4" */ sessionHelper.getMfId() /* "HCF0031" */);
			
			HpeSearchVO searchVO = null;			
			
			searchVO = (HpeSearchVO)sessionHelper.getAttribute(HPEConstants.SEARCH_DASH_VO);			
			
			if(searchVO != null){				
				hpeEncounterForm.setSearchSummarySubmitterId((searchVO.getSubmitterId()));				
				hpeEncounterForm.setSearchSummaryDateInd((searchVO.getDateInd()));				
				hpeEncounterForm.setSearchSummaryFromDate(searchVO.getFromDate());				
				hpeEncounterForm.setSearchSummaryToDate(searchVO.getToDate());		
				hpeEncounterForm.setSearchSummaryType(searchVO.getClmType());
				hpeEncounterForm.setSelClaimType(searchVO.getClmType());
			} else {
				searchVO = (HpeSearchVO)sessionHelper.getAttribute(HPEConstants.DEFAULT_SEARCH_VO);			
				
				if(searchVO != null){				
					hpeEncounterForm.setSearchSummarySubmitterId((searchVO.getSubmitterId()));				
					hpeEncounterForm.setSearchSummaryDateInd((searchVO.getDateInd()));				
					hpeEncounterForm.setSearchSummaryFromDate(searchVO.getFromDate());				
					hpeEncounterForm.setSearchSummaryToDate(searchVO.getToDate());	
					hpeEncounterForm.setSearchSummaryType(searchVO.getClmType());
					hpeEncounterForm.setSelClaimType(searchVO.getClmType());
				}
			}					

			// Copy the search criteria to the VO
			encounterVO.setSearchSummarySubmitterId((hpeEncounterForm.getSearchSummarySubmitterId()));
			encounterVO.setSearchSummaryDateInd((hpeEncounterForm.getSearchSummaryDateInd()));
			encounterVO.setSearchSummaryFromDate(DateFormatter.reFormat(hpeEncounterForm.getSearchSummaryFromDate(), DateFormatter.MM_YYYY, DateFormatter.YYYYMM));
			encounterVO.setSearchSummaryToDate(DateFormatter.reFormat(hpeEncounterForm.getSearchSummaryToDate(), DateFormatter.MM_YYYY, DateFormatter.YYYYMM));
			encounterVO.setSearchSummaryClmType(hpeEncounterForm.getSearchSummaryType());

			// Search
			context.getEncounterService().searchStatusSummaryByDateRange(conn, encounterVO);

			// Refresh
			//
			EncCmstatSumVOs searchSummaryResults = encounterVO.getSearchSummaryResults();

			// Sort the summary details according to the form's grid layout
			ENCCodeCache cc = ENCCodeCache.getInstance();
			HashMap codes = cc.getHmENCDashboardStatusIndex();

			GridUtil statusSummaryGrid = new GridUtil();
			GridUtil.Year year = null;
			GridUtil.Month month = null;
			GridUtil.Totals grandTotals = null;
			GridUtil.Totals yearTotals = null;
			GridUtil.Totals monthTotals = null;
			
			Iterator iterator = searchSummaryResults.iterator();
			while (iterator.hasNext()) {
				EncCmstatSumVO encCmstatSumVO = (EncCmstatSumVO) iterator.next();
				Integer tempYear = Integer.valueOf(encCmstatSumVO.getDateYrmo().substring(0, 4));
				Integer tempMonth = Integer.valueOf(encCmstatSumVO.getDateYrmo().substring(4, 6));
				int encounters = encCmstatSumVO.getEncCount();
				if ((year == null) || (!year.getYear().equals(tempYear))) {
					year = statusSummaryGrid.getYears().addYear(tempYear);
					month = year.getMonths().addMonth(tempMonth);
				}
				if (!month.getMonth().equals(tempMonth)) {
					month = year.getMonths().addMonth(tempMonth);
				}

				if (encCmstatSumVO.getEncType().equals("I")) {
					grandTotals = statusSummaryGrid.getInstTotals();
					yearTotals = year.getInstTotals();
					monthTotals = month.getInstTotals();
				}
				if (encCmstatSumVO.getEncType().equals("P")) {
					grandTotals = statusSummaryGrid.getProfTotals();
					yearTotals = year.getProfTotals();
					monthTotals = month.getProfTotals();
				}
				//DME_Dashboard_changes
				if (encCmstatSumVO.getEncType().equals("E")) {
					grandTotals = statusSummaryGrid.getDmeTotals();
					yearTotals = year.getDmeTotals();
					monthTotals = month.getDmeTotals();
				}
				String group = (String)codes.get(encCmstatSumVO.getProcessStatus());
				if ("PEN".equals(group)) {
					grandTotals.setPending(grandTotals.getPending() + encounters);
					yearTotals.setPending(yearTotals.getPending() + encounters);
					monthTotals.setPending(monthTotals.getPending() + encounters);					
				}
				else
				if ("ACC".equals(group)) {
					grandTotals.setAccepted(grandTotals.getAccepted() + encounters);
					yearTotals.setAccepted(yearTotals.getAccepted() + encounters);
					monthTotals.setAccepted(monthTotals.getAccepted() + encounters);					
				}
				else
				if ("FAL".equals(group)) {
					grandTotals.setRejected(grandTotals.getRejected() + encounters);
					yearTotals.setRejected(yearTotals.getRejected() + encounters);
					monthTotals.setRejected(monthTotals.getRejected() + encounters);						
				}
				else
				if ("IGN".equals(group)) {
					grandTotals.setIgnored(grandTotals.getIgnored() + encounters);
					yearTotals.setIgnored(yearTotals.getIgnored() + encounters);
					monthTotals.setIgnored(monthTotals.getIgnored() + encounters);
				}
				grandTotals.setTotal(grandTotals.getTotal() + encounters);
				yearTotals.setTotal(yearTotals.getTotal() + encounters);
				monthTotals.setTotal(monthTotals.getTotal() + encounters);
			}

			// Store search results in the form
			hpeEncounterForm.setStatusSummaryGrid(statusSummaryGrid);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void buildErrorStatusSummary(Connection conn, SessionHelper sessionHelper, HPEContext context, HPEEncounterForm hpeEncounterForm, HttpServletRequest request)
	throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getEncounterVO();

			// Set customer
			encounterVO.setMfId(/* "HCFLCS4" */ sessionHelper.getMfId() /* "HCF0031" */);	
			HpeSearchVO searchVO = null;			
			
			searchVO = (HpeSearchVO)sessionHelper.getAttribute(HPEConstants.SEARCH_REJECT_VO);			
			
			if(searchVO != null){				
				hpeEncounterForm.setSearchSummarySubmitterId((searchVO.getSubmitterId()));	
				hpeEncounterForm.setSearchSummaryType((searchVO.getClmType()));		
				hpeEncounterForm.setSearchSummaryDateInd((searchVO.getDateInd()));				
				hpeEncounterForm.setSearchSummaryFromDate(searchVO.getFromDate());				
				hpeEncounterForm.setSearchSummaryToDate(searchVO.getToDate());	
				hpeEncounterForm.setSelClaimType(searchVO.getClmType());
			} else {
				searchVO = (HpeSearchVO)sessionHelper.getAttribute(HPEConstants.DEFAULT_SEARCH_VO);
				if(searchVO != null){				
					hpeEncounterForm.setSearchSummarySubmitterId((searchVO.getSubmitterId()));	
					hpeEncounterForm.setSearchSummaryType((searchVO.getClmType()));	
					hpeEncounterForm.setSearchSummaryDateInd((searchVO.getDateInd()));				
					hpeEncounterForm.setSearchSummaryFromDate(searchVO.getFromDate());				
					hpeEncounterForm.setSearchSummaryToDate(searchVO.getToDate());	
					hpeEncounterForm.setSelClaimType(searchVO.getClmType());
				}	
			}			
			
			//Copy the search criteria to the VO
			encounterVO.setSearchSummarySubmitterId((hpeEncounterForm.getSearchSummarySubmitterId()));
			encounterVO.setSearchSummaryClmType((hpeEncounterForm.getSearchSummaryType()));
			encounterVO.setSearchSummaryDateInd((hpeEncounterForm.getSearchSummaryDateInd()));				
			encounterVO.setSearchSummaryFromDate(DateFormatter.reFormat(hpeEncounterForm.getSearchSummaryFromDate(), DateFormatter.MM_YYYY, DateFormatter.YYYYMM));
			encounterVO.setSearchSummaryToDate(DateFormatter.reFormat(hpeEncounterForm.getSearchSummaryToDate(), DateFormatter.MM_YYYY, DateFormatter.YYYYMM));
			
			// Search
			context.getEncounterService().searchErrorStatSummaryByDateRange(conn, encounterVO);
		
			// Refresh
			EncErrorstatSumVOs searchSummaryResults = encounterVO.getSearchErrorSummaryResults();
		
			// Sort the summary details according to the form's grid layout
			GridUtil statusSummaryGrid = new GridUtil();
			GridUtil.Year year = null;
			GridUtil.Month month = null;
			GridUtil.Totals grandTotals = null;
			GridUtil.Totals yearTotals = null;
			GridUtil.Totals monthTotals = null;
					
			Iterator iterator = searchSummaryResults.iterator();
			while (iterator.hasNext()) {
				EncErrorstatSumVO encErrorstatSumVO = (EncErrorstatSumVO) iterator.next();
				Integer tempYear = Integer.valueOf(encErrorstatSumVO.getDateYrmo().substring(0, 4));
				Integer tempMonth = Integer.valueOf(encErrorstatSumVO.getDateYrmo().substring(4, 6));
				int errors = encErrorstatSumVO.getErrorCnt();
				if ((year == null) || (!year.getYear().equals(tempYear))) {
					year = statusSummaryGrid.getYears().addYear(tempYear);
					month = year.getMonths().addMonth(tempMonth);
				}
				if (!month.getMonth().equals(tempMonth)) {
					month = year.getMonths().addMonth(tempMonth);
				}
		
				if (encErrorstatSumVO.getEncType().equals("I")) {
					grandTotals = statusSummaryGrid.getInstTotals();
					yearTotals = year.getInstTotals();
					monthTotals = month.getInstTotals();
				}
				if (encErrorstatSumVO.getEncType().equals("P")) {
					grandTotals = statusSummaryGrid.getProfTotals();
					yearTotals = year.getProfTotals();
					monthTotals = month.getProfTotals();
				}
				//DME_Dashboard_changes
				if (encErrorstatSumVO.getEncType().equals("E")) {
					grandTotals = statusSummaryGrid.getDmeTotals();
					yearTotals = year.getDmeTotals();
					monthTotals = month.getDmeTotals();
				}
				String errorSource = encErrorstatSumVO.getErrorSource();				
				if ("CCR".equals(errorSource)) {
					grandTotals.setCCR(grandTotals.getCCR() + errors);
					yearTotals.setCCR(yearTotals.getCCR() + errors);
					monthTotals.setCCR(monthTotals.getCCR() + errors);					
				}
				else 
				if ("CMS".equals(errorSource)) {
					grandTotals.setRejected(grandTotals.getRejected() + errors);
					yearTotals.setRejected(yearTotals.getRejected() + errors);
					monthTotals.setRejected(monthTotals.getRejected() + errors);					
				}			
				
				grandTotals.setTotal(grandTotals.getTotal() + errors);
				yearTotals.setTotal(yearTotals.getTotal() + errors);
				monthTotals.setTotal(monthTotals.getTotal() + errors);
			}

			// Store search results in the form
			hpeEncounterForm.setStatusSummaryGrid(statusSummaryGrid);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}


	public static String selectClaims(Connection conn, SessionHelper sessionHelper, HPEContext context, HPEEncounterForm hpeEncounterForm, HttpServletRequest request, String requestStatus)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String forward = HPEConstants.HPE_ERROR;
		HpeSearchVO searchVO = null;

		try {			
			// Get the VO
			HPEEncounterVO encounterVO = context.getEncounterVO();

			// Set customer
			encounterVO.setMfId(/* "HCFLCS4" */ sessionHelper.getMfId() /* "HCF0031" */);
			
			if ("0".equals(requestStatus)) {
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
			}else if ("1".equals(requestStatus)) {
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
			}else if("2".equals(requestStatus)){
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_FILE_TRACK_VO);
			}
			
			if (searchVO != null) {				
				hpeEncounterForm.setSearchDetailSubmitterId(searchVO.getSubmitterId());
				hpeEncounterForm.setSearchDetailClmType(searchVO.getClmType());
				hpeEncounterForm.setSearchDetailEncType(searchVO.getEncType());
				hpeEncounterForm.setSearchDetailDateInd(searchVO.getDateInd());
				hpeEncounterForm.setSelectedDateYrmo(searchVO.getSelectedDate());
				hpeEncounterForm.setSearchDetailFromDate(searchVO.getFromDate());
				hpeEncounterForm.setSearchDetailToDate(searchVO.getToDate());
				hpeEncounterForm.setSearchDetailGroupStatus(searchVO.getGroupStatus());	
				hpeEncounterForm.setSearchDetailErrorCode(searchVO.getErrorCode());
				hpeEncounterForm.setSearchDetailErrorGroup(searchVO.getErrorGroup());
				hpeEncounterForm.setSearchDetailErrorSource(searchVO.getErrorSource());
				hpeEncounterForm.setSearchDetailClaimRefNbr(searchVO.getClaimRefNbr());
				hpeEncounterForm.setSearchDetailHicNbr(searchVO.getHicNbr());
				hpeEncounterForm.setProcessStatus(searchVO.getGroupStatus());	//IFOX-00397153-Fix
				
				//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : Start
				hpeEncounterForm.setMaoflag(searchVO.getMaoflag());
				//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : End
				
				//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - Start
				hpeEncounterForm.setSearchPayerSecId(searchVO.getPayerSecId());
				hpeEncounterForm.setSearchSubsGrpOrPolNbr(searchVO.getSubsGrpOrPolNbr());
				//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - End
				if (!("".equals(hpeEncounterForm.getSelectedDateYrmo()))) {
					hpeEncounterForm.setSearchDetailFromDate(DateFormatter.reFormat(hpeEncounterForm.getSelectedDateYrmo(), DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_START));			
					hpeEncounterForm.setSearchDetailToDate(DateFormatter.reFormat(hpeEncounterForm.getSelectedDateYrmo(), DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_END));
				}	
				
				if (searchVO.getEncType().equals("I")) {
					hpeEncounterForm.setInstListExpanded(searchVO.isListExpanded());
					hpeEncounterForm.setInstErrorsExpanded(searchVO.isErrorsExpanded());
					hpeEncounterForm.setInstSubscriberExpanded(searchVO.isSubscriberExpanded());
					hpeEncounterForm.setInstProviderExpanded(searchVO.isProviderExpanded());
					hpeEncounterForm.setInstClaimExpanded(searchVO.isClaimExpanded());
					hpeEncounterForm.setInstClaimCodesExpanded(searchVO.isClaimCodesExpanded());
					hpeEncounterForm.setInstClaimNotesExpanded(searchVO.isClaimNotesExpanded());
					hpeEncounterForm.setInstClaimProvExpanded(searchVO.isClaimProvExpanded());
					hpeEncounterForm.setInstClaimProvDetailExpanded(searchVO.isClaimProvDetailExpanded());
					hpeEncounterForm.setInstClaimOtherSubsProvExpanded(searchVO.isClaimOtherSubsProvExpanded());
					hpeEncounterForm.setInstClaimOtherSubsProvDetailExpanded(searchVO.isClaimOtherSubsProvDetailExpanded());
					hpeEncounterForm.setInstClaimOtherSubsExpanded(searchVO.isClaimOtherSubsExpanded());
					hpeEncounterForm.setInstClaimOtherSubsDetailExpanded(searchVO.isClaimOtherSubsDetailExpanded());
					hpeEncounterForm.setInstClaimLineExpanded(searchVO.isClaimLineExpanded());
					hpeEncounterForm.setInstClaimLineDetailExpanded(searchVO.isClaimLineDetailExpanded());
					hpeEncounterForm.setInstClaimLineProvExpanded(searchVO.isClaimLineProvExpanded());
					hpeEncounterForm.setInstClaimLineProvDetailExpanded(searchVO.isClaimLineProvDetailExpanded());
					hpeEncounterForm.setInstClaimLineAdjudExpanded(searchVO.isClaimLineAdjudExpanded());
					hpeEncounterForm.setInstClaimLineAdjudDetailExpanded(searchVO.isClaimLineAdjudDetailExpanded());
				}else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")) {					//DME_Dashboard_changes
					hpeEncounterForm.setProfListExpanded(searchVO.isListExpanded());
					hpeEncounterForm.setProfErrorsExpanded(searchVO.isErrorsExpanded());
					hpeEncounterForm.setProfSubscriberExpanded(searchVO.isSubscriberExpanded());
					hpeEncounterForm.setProfProviderExpanded(searchVO.isProviderExpanded());
					hpeEncounterForm.setProfClaimExpanded(searchVO.isClaimExpanded());
					hpeEncounterForm.setProfClaimCodesExpanded(searchVO.isClaimCodesExpanded());					
					hpeEncounterForm.setProfClaimProvExpanded(searchVO.isClaimProvExpanded());
					hpeEncounterForm.setProfClaimProvDetailExpanded(searchVO.isClaimProvDetailExpanded());
					hpeEncounterForm.setProfClaimOtherSubsProvExpanded(searchVO.isClaimOtherSubsProvExpanded());
					hpeEncounterForm.setProfClaimOtherSubsProvDetailExpanded(searchVO.isClaimOtherSubsProvDetailExpanded());
					hpeEncounterForm.setProfClaimOtherSubsExpanded(searchVO.isClaimOtherSubsExpanded());
					hpeEncounterForm.setProfClaimOtherSubsDetailExpanded(searchVO.isClaimOtherSubsDetailExpanded());
					hpeEncounterForm.setProfClaimLineExpanded(searchVO.isClaimLineExpanded());
					hpeEncounterForm.setProfClaimLineDetailExpanded(searchVO.isClaimLineDetailExpanded());
					hpeEncounterForm.setProfClaimLineProvExpanded(searchVO.isClaimLineProvExpanded());
					hpeEncounterForm.setProfClaimLineProvDetailExpanded(searchVO.isClaimLineProvDetailExpanded());
					hpeEncounterForm.setProfClaimLineAdjudExpanded(searchVO.isClaimLineAdjudExpanded());
					hpeEncounterForm.setProfClaimLineAdjudDetailExpanded(searchVO.isClaimLineAdjudDetailExpanded());
				}
			} else {								
				hpeEncounterForm.setSearchDetailSubmitterId("");	
				hpeEncounterForm.setSearchDetailClmType("EN");
				//DME_Dashboard_changes
				hpeEncounterForm.setSearchDetailEncType(Utility.getEncTypeFromSelectedTab("EDPS_DSH_SEL_TAB_MAP", sessionHelper));//DME_Dashboard_changes
				hpeEncounterForm.setSearchDetailDateInd("0");
				hpeEncounterForm.setSearchDetailFromDate("");
				hpeEncounterForm.setSearchDetailToDate("");
				hpeEncounterForm.setSearchDetailGroupStatus("");
				hpeEncounterForm.setSearchDetailErrorCode("");
				hpeEncounterForm.setSearchDetailErrorGroup("");
				hpeEncounterForm.setSearchDetailErrorSource("");
			}

			// Copy the search criteria to the VO
			encounterVO.setSearchDetailSubmitterId(hpeEncounterForm.getSearchDetailSubmitterId());
			encounterVO.setSearchDetailClmType(hpeEncounterForm.getSearchDetailClmType());
			encounterVO.setSearchDetailEncType(hpeEncounterForm.getSearchDetailEncType());
			encounterVO.setSearchDetailDateInd(hpeEncounterForm.getSearchDetailDateInd());
			encounterVO.setSearchDetailFromDate(DateFormatter.reFormat(hpeEncounterForm.getSearchDetailFromDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			encounterVO.setSearchDetailToDate(DateFormatter.reFormat(hpeEncounterForm.getSearchDetailToDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			encounterVO.setSearchDetailClaimRefNbr(hpeEncounterForm.getSearchDetailClaimRefNbr());
			encounterVO.setSearchDetailHicNbr(hpeEncounterForm.getSearchDetailHicNbr());
			encounterVO.setSearchDetailGroupStatus(hpeEncounterForm.getSearchDetailGroupStatus());
			encounterVO.setSearchDetailErrorSource(hpeEncounterForm.getSearchDetailErrorSource());
			encounterVO.setSearchDetailErrorGroup(hpeEncounterForm.getSearchDetailErrorGroup());
			encounterVO.setSearchDetailErrorCode(hpeEncounterForm.getSearchDetailErrorCode());
			
			//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : Start
			encounterVO.setMaoflag(hpeEncounterForm.getMaoflag());
			//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : End
			
			//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - Start
			encounterVO.setSearchPayerSecId(hpeEncounterForm.getSearchPayerSecId());
			encounterVO.setSearchSubsGrpOrPolNbr(hpeEncounterForm.getSearchSubsGrpOrPolNbr());
			//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - End

			if (encounterVO.getSearchDetailEncType().equals("I")) {
				pageInstClaims(conn, sessionHelper, context, hpeEncounterForm, request, "first",requestStatus);
				if (searchVO != null) {					
					if (!("".equals(searchVO.getSelectedClaimType())) && !("".equals(searchVO.getSelectedClaimRefNbr())) 
							&& !("".equals(searchVO.getSelectedClaimRevNbr())) && !("".equals(searchVO.getSelectedClaimSeqNbr()))){						
						if ("0".equals(requestStatus)) {
							forward = selectClaim(conn, sessionHelper, context, hpeEncounterForm, request,requestStatus);						
						} else
							forward = HPEConstants.HPE_INSTDETAIL;					
					} else 
						forward = HPEConstants.HPE_INSTDETAIL;
				} else 
					forward = HPEConstants.HPE_INSTDETAIL;
			}
			else
			if (encounterVO.getSearchDetailEncType().equals("P") || encounterVO.getSearchDetailEncType().equals("E")) {
				pageProfClaims(conn, sessionHelper, context, hpeEncounterForm, request, "first",requestStatus,encounterVO.getSearchDetailEncType());//DME_Dashboard_changes
				if (searchVO != null) {					
					if (!("".equals(searchVO.getSelectedClaimType())) && !("".equals(searchVO.getSelectedClaimRefNbr())) 
							&& !("".equals(searchVO.getSelectedClaimRevNbr())) && !("".equals(searchVO.getSelectedClaimSeqNbr()))){						
						if ("0".equals(requestStatus)) {
							forward = selectClaim(conn, sessionHelper, context, hpeEncounterForm, request,requestStatus);						
						} else
							forward = HPEConstants.HPE_PROFDETAIL;
					} else 
						forward = HPEConstants.HPE_PROFDETAIL;
				} else 
					forward = HPEConstants.HPE_PROFDETAIL;				
			}
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return forward;
	}
	
	/*
	 * method to retrieve error details from the database
	 */
	public static String getErrorDetails(Connection conn, SessionHelper sessionHelper, HPEContext context, HPEEncounterForm hpeEncounterForm, HttpServletRequest request)
	throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String forward = HPEConstants.HPE_ERROR;
		
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getEncounterVO();
		
			// Set customer
			encounterVO.setMfId(/* "HCFLCS4" */ sessionHelper.getMfId() /* "HCF0031" */);			
			HpeSearchVO searchVO = null;			
			
			searchVO = (HpeSearchVO)sessionHelper.getAttribute("SearchVO");
			if(searchVO != null){					 
				hpeEncounterForm.setSearchSummarySubmitterId((searchVO.getSubmitterId()));
				hpeEncounterForm.setSearchSummaryType((searchVO.getClmType()));
				hpeEncounterForm.setSearchSummaryEncType(searchVO.getEncType());
				hpeEncounterForm.setSearchSummaryDateInd((searchVO.getDateInd()));					
				hpeEncounterForm.setSelectedDateYrmo(searchVO.getSelectedDate());					
				hpeEncounterForm.setSearchSummaryFromDate(searchVO.getFromDate());				
				hpeEncounterForm.setSearchSummaryToDate(searchVO.getToDate());					
				hpeEncounterForm.setSearchSummaryErrorSource(searchVO.getErrorSource());
				hpeEncounterForm.setSearchSummaryErrorGroup(searchVO.getErrorGroup());
				hpeEncounterForm.setSearchSummaryErrorCode(searchVO.getErrorCode());					
			}			
					
			// Copy the search criteria to the VO
			encounterVO.setSearchSummarySubmitterId(hpeEncounterForm.getSearchSummarySubmitterId());
			encounterVO.setSearchSummaryClmType(hpeEncounterForm.getSearchSummaryType());
			encounterVO.setSearchSummaryEncType(hpeEncounterForm.getSearchSummaryEncType());
			
			if (!("".equals(hpeEncounterForm.getSelectedDateYrmo()))) {
				hpeEncounterForm.setSearchSummaryFromDate(hpeEncounterForm.getSelectedDateYrmo());			
				hpeEncounterForm.setSearchSummaryToDate(hpeEncounterForm.getSelectedDateYrmo());
			}
			
			encounterVO.setSearchSummaryFromDate(DateFormatter.reFormat(hpeEncounterForm.getSearchSummaryFromDate(), DateFormatter.MM_YYYY, DateFormatter.YYYYMM));
			encounterVO.setSearchSummaryToDate(DateFormatter.reFormat(hpeEncounterForm.getSearchSummaryToDate(), DateFormatter.MM_YYYY, DateFormatter.YYYYMM));
			encounterVO.setSearchSummaryErrorSource(hpeEncounterForm.getSearchSummaryErrorSource());			
			encounterVO.setSearchSummaryErrorGroup(hpeEncounterForm.getSearchSummaryErrorGroup());			
			encounterVO.setSearchSummaryErrorCode(hpeEncounterForm.getSearchSummaryErrorCode());
			encounterVO.setSearchSummaryDateInd(hpeEncounterForm.getSearchSummaryDateInd());
			
			pageErrorDetail(conn, sessionHelper, context, hpeEncounterForm, request);			
		
			if (encounterVO.getSearchSummaryEncType().equals("I")) {				
				forward = HPEConstants.HPE_SUMMINSTREJECTCODES;
			}else if (encounterVO.getSearchSummaryEncType().equals("P") || encounterVO.getSearchSummaryEncType().equals("E")) {				
				forward = HPEConstants.HPE_SUMMPROFREJECTCODES;
			}			
			
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return forward;
	}
	
	/*
	 * Method to retrieve the claims based on selected error Code,error Group & error Source 
	 */
	public static String selectErrorSpecificClaims(Connection conn, SessionHelper sessionHelper, HPEContext context, HPEEncounterForm hpeEncounterForm, HttpServletRequest request)
	throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String forward = HPEConstants.HPE_ERROR;
		String errorCode = "";
		String errorGroup = "";
		String rejectCode = "";
		String errorSource = "";
		int index = 0;
		HpeSearchVO searchVO = null;
		String requestStatus = null;
		
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getEncounterVO();
			searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
		
			if (searchVO != null) {
				rejectCode = searchVO.getRejectCode();
				errorSource = searchVO.getFormattedErrorSource();
				
				if (rejectCode.length() > 0) {
					hpeEncounterForm.setRejectCode(searchVO.getRejectCode());
					hpeEncounterForm.setFormattedErrorSource(searchVO.getFormattedErrorSource());					
					hpeEncounterForm.setSelectedErrorGroup(searchVO.getErrorGroup());
				} 
				hpeEncounterForm.setSearchDetailSubmitterId(searchVO.getSubmitterId());
				hpeEncounterForm.setSearchDetailClmType(searchVO.getClmType());
				hpeEncounterForm.setSearchDetailEncType(searchVO.getEncType());
				hpeEncounterForm.setSearchDetailDateInd(searchVO.getDateInd());
				hpeEncounterForm.setSearchDetailFromDate(DateFormatter.reFormat(searchVO.getSelectedDate(), DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_START));
				hpeEncounterForm.setSearchDetailToDate(DateFormatter.reFormat(searchVO.getSelectedDate(), DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_END));				
				hpeEncounterForm.setSearchDetailGroupStatus(searchVO.getGroupStatus());
				requestStatus = "1";				
			} else {
				hpeEncounterForm.setRejectCode("");
				hpeEncounterForm.setFormattedErrorSource("");				
				hpeEncounterForm.setSelectedErrorGroup("");
				hpeEncounterForm.setSearchDetailSubmitterId("");	
				hpeEncounterForm.setSearchDetailClmType("EN");
				//DME_Dashboard_changes
				hpeEncounterForm.setSearchDetailEncType(Utility.getEncTypeFromSelectedTab("REJECT_ANALYSIS_SUMMARY_TAB", sessionHelper));
				hpeEncounterForm.setSearchDetailDateInd("0");
				hpeEncounterForm.setSearchDetailFromDate("");
				hpeEncounterForm.setSearchDetailToDate("");
				hpeEncounterForm.setSearchDetailGroupStatus("");
			}
			
			rejectCode =  hpeEncounterForm.getRejectCode();
			errorSource = hpeEncounterForm.getFormattedErrorSource();
		
			// Split up selected errorCode & errorGroup
			if(rejectCode.length() > 0){	
				//index = rejectCode.indexOf("_");
				//errorCode = rejectCode.substring(0,index);
				//errorGroup = rejectCode.substring(index+1,rejectCode.length());
				errorGroup = hpeEncounterForm.getSelectedErrorGroup();
				errorCode = rejectCode;
				
				hpeEncounterForm.setSearchDetailErrorCode(errorCode);
				hpeEncounterForm.setSearchDetailErrorGroup(errorGroup);
			}	
			
			//Get short name of selected errorSource
			if(!("").equals(errorSource) && (errorSource!= null)){				
				if(errorSource.equals(HPEConstants.ERROR_SYNTAX)) {
					errorSource = "SYN";					
				}else if(errorSource.equals(HPEConstants.ERROR_REJECTED)) {
					errorSource = "REJ";
				}
				
				hpeEncounterForm.setSearchDetailErrorSource(errorSource);
			}			
			
			//Set customer
			encounterVO.setMfId(/* "HCFLCS4" */ sessionHelper.getMfId() /* "HCF0031" */);			
			
			//Copy the search criteria to the VO
			encounterVO.setSearchDetailSubmitterId(hpeEncounterForm.getSearchDetailSubmitterId());
			encounterVO.setSearchDetailClmType(hpeEncounterForm.getSearchDetailClmType());
			encounterVO.setSearchDetailEncType(hpeEncounterForm.getSearchDetailEncType());
			encounterVO.setSearchDetailDateInd(hpeEncounterForm.getSearchDetailDateInd());
			encounterVO.setSearchDetailFromDate(DateFormatter.reFormat(hpeEncounterForm.getSearchDetailFromDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			encounterVO.setSearchDetailToDate(DateFormatter.reFormat(hpeEncounterForm.getSearchDetailToDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));			
			encounterVO.setSearchDetailErrorSource(errorSource);
			encounterVO.setSearchDetailErrorGroup(errorGroup);
			encounterVO.setSearchDetailErrorCode(errorCode);
			encounterVO.setSearchDetailGroupStatus(hpeEncounterForm.getSearchDetailGroupStatus());
		
			if (encounterVO.getSearchDetailEncType().equals("I")) {
				pageInstClaims(conn, sessionHelper, context, hpeEncounterForm, request, "first",requestStatus);
				if (searchVO != null) {
					hpeEncounterForm.setInstListExpanded(searchVO.isListExpanded());
					hpeEncounterForm.setInstErrorsExpanded(searchVO.isErrorsExpanded());
					hpeEncounterForm.setInstSubscriberExpanded(searchVO.isSubscriberExpanded());
					hpeEncounterForm.setInstProviderExpanded(searchVO.isProviderExpanded());
					hpeEncounterForm.setInstClaimExpanded(searchVO.isClaimExpanded());
					hpeEncounterForm.setInstClaimCodesExpanded(searchVO.isClaimCodesExpanded());
					hpeEncounterForm.setInstClaimNotesExpanded(searchVO.isClaimNotesExpanded());
					hpeEncounterForm.setInstClaimProvExpanded(searchVO.isClaimProvExpanded());
					hpeEncounterForm.setInstClaimProvDetailExpanded(searchVO.isClaimProvDetailExpanded());
					hpeEncounterForm.setInstClaimOtherSubsProvExpanded(searchVO.isClaimOtherSubsProvExpanded());
					hpeEncounterForm.setInstClaimOtherSubsProvDetailExpanded(searchVO.isClaimOtherSubsProvDetailExpanded());
					hpeEncounterForm.setInstClaimOtherSubsExpanded(searchVO.isClaimOtherSubsExpanded());
					hpeEncounterForm.setInstClaimOtherSubsDetailExpanded(searchVO.isClaimOtherSubsDetailExpanded());
					hpeEncounterForm.setInstClaimLineExpanded(searchVO.isClaimLineExpanded());
					hpeEncounterForm.setInstClaimLineDetailExpanded(searchVO.isClaimLineDetailExpanded());
					hpeEncounterForm.setInstClaimLineProvExpanded(searchVO.isClaimLineProvExpanded());
					hpeEncounterForm.setInstClaimLineProvDetailExpanded(searchVO.isClaimLineProvDetailExpanded());
					hpeEncounterForm.setInstClaimLineAdjudExpanded(searchVO.isClaimLineAdjudExpanded());
					hpeEncounterForm.setInstClaimLineAdjudDetailExpanded(searchVO.isClaimLineAdjudDetailExpanded());	
					
					if (!("".equals(searchVO.getSelectedClaimType())) && !("".equals(searchVO.getSelectedClaimRefNbr())) 
							&& !("".equals(searchVO.getSelectedClaimRevNbr())) && !("".equals(searchVO.getSelectedClaimSeqNbr()))){
						forward = selectClaim(conn, sessionHelper, context, hpeEncounterForm, request,requestStatus);				
					} else 
						forward = HPEConstants.HPE_INSTDETAIL;
				} else
					forward = HPEConstants.HPE_INSTDETAIL;
			}
			else
			if (encounterVO.getSearchDetailEncType().equals("P") || encounterVO.getSearchDetailEncType().equals("E")) {
				//DME_Dashboard_changes
				pageProfClaims(conn, sessionHelper, context, hpeEncounterForm, request, "first",requestStatus,encounterVO.getSearchDetailEncType());
				if (searchVO != null) {
					hpeEncounterForm.setProfListExpanded(searchVO.isListExpanded());
					hpeEncounterForm.setProfErrorsExpanded(searchVO.isErrorsExpanded());
					hpeEncounterForm.setProfSubscriberExpanded(searchVO.isSubscriberExpanded());
					hpeEncounterForm.setProfProviderExpanded(searchVO.isProviderExpanded());
					hpeEncounterForm.setProfClaimExpanded(searchVO.isClaimExpanded());
					hpeEncounterForm.setProfClaimCodesExpanded(searchVO.isClaimCodesExpanded());					
					hpeEncounterForm.setProfClaimProvExpanded(searchVO.isClaimProvExpanded());
					hpeEncounterForm.setProfClaimProvDetailExpanded(searchVO.isClaimProvDetailExpanded());
					hpeEncounterForm.setProfClaimOtherSubsProvExpanded(searchVO.isClaimOtherSubsProvExpanded());
					hpeEncounterForm.setProfClaimOtherSubsProvDetailExpanded(searchVO.isClaimOtherSubsProvDetailExpanded());
					hpeEncounterForm.setProfClaimOtherSubsExpanded(searchVO.isClaimOtherSubsExpanded());
					hpeEncounterForm.setProfClaimOtherSubsDetailExpanded(searchVO.isClaimOtherSubsDetailExpanded());
					hpeEncounterForm.setProfClaimLineExpanded(searchVO.isClaimLineExpanded());
					hpeEncounterForm.setProfClaimLineDetailExpanded(searchVO.isClaimLineDetailExpanded());
					hpeEncounterForm.setProfClaimLineProvExpanded(searchVO.isClaimLineProvExpanded());
					hpeEncounterForm.setProfClaimLineProvDetailExpanded(searchVO.isClaimLineProvDetailExpanded());
					hpeEncounterForm.setProfClaimLineAdjudExpanded(searchVO.isClaimLineAdjudExpanded());
					hpeEncounterForm.setProfClaimLineAdjudDetailExpanded(searchVO.isClaimLineAdjudDetailExpanded());
					
					if (!("".equals(searchVO.getSelectedClaimType())) && !("".equals(searchVO.getSelectedClaimRefNbr())) 
							&& !("".equals(searchVO.getSelectedClaimRevNbr())) && !("".equals(searchVO.getSelectedClaimSeqNbr()))){
						forward = selectClaim(conn, sessionHelper, context, hpeEncounterForm, request,requestStatus);				
					} else
						forward = HPEConstants.HPE_PROFDETAIL;
				} else
					forward = HPEConstants.HPE_PROFDETAIL;
			}
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return forward;
	}

	public static String pageClaims(Connection conn, SessionHelper sessionHelper, HPEContext context, HPEEncounterForm hpeEncounterForm, HttpServletRequest request, String move,String requestStatus)
	throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		HPEEncounterVO encounterVO = context.getEncounterVO();
		HpeSearchVO searchVO = null;
		String errorCode = "";
		String errorGroup = "";
		String rejectCode = "";
		String errorSource = "";
		int index = 0;
		
		if ("0".equals(requestStatus)) {
			searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
		}else if ("1".equals(requestStatus)) {
			searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
		}			
		
		if (searchVO != null) {				
			hpeEncounterForm.setSearchDetailSubmitterId(searchVO.getSubmitterId());
			hpeEncounterForm.setSearchDetailEncType(searchVO.getEncType());
			hpeEncounterForm.setSearchDetailDateInd(searchVO.getDateInd());
			hpeEncounterForm.setSelectedDateYrmo(searchVO.getSelectedDate());
			hpeEncounterForm.setSearchDetailFromDate(searchVO.getFromDate());
			hpeEncounterForm.setSearchDetailToDate(searchVO.getToDate());
			hpeEncounterForm.setSearchDetailGroupStatus(searchVO.getGroupStatus());	
			hpeEncounterForm.setSearchDetailErrorCode(searchVO.getErrorCode());
			hpeEncounterForm.setSearchDetailErrorGroup(searchVO.getErrorGroup());
			hpeEncounterForm.setSearchDetailErrorSource(searchVO.getErrorSource());
			hpeEncounterForm.setSearchDetailClaimRefNbr(searchVO.getClaimRefNbr());
			hpeEncounterForm.setSearchDetailHicNbr(searchVO.getHicNbr());
			
			rejectCode = searchVO.getRejectCode();
			errorSource = searchVO.getFormattedErrorSource();
			//Split up selected errorCode & errorGroup
			if(rejectCode.length() > 0){	
				//index = rejectCode.indexOf("_");
				//errorCode = rejectCode.substring(0,index);
				//errorGroup = rejectCode.substring(index+1,rejectCode.length());
				
				hpeEncounterForm.setSearchDetailErrorCode(rejectCode);
				//hpeEncounterForm.setSearchDetailErrorGroup(errorGroup);
			}	
			
			//Get short name of selected errorSource
			if(!("").equals(errorSource) && (errorSource!= null)){				
				//if(errorSource.equals(HPEConstants.ERROR_SYNTAX)) {
				//	errorSource = "SYN";					
				//}else if(errorSource.equals(HPEConstants.ERROR_REJECTED)) {
				//	errorSource = "REJ";
				//}
				
				hpeEncounterForm.setSearchDetailErrorSource(errorSource);
			}			
			
			if (!("".equals(hpeEncounterForm.getSelectedDateYrmo()))) {
				hpeEncounterForm.setSearchDetailFromDate(DateFormatter.reFormat(hpeEncounterForm.getSelectedDateYrmo(), DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_START));			
				hpeEncounterForm.setSearchDetailToDate(DateFormatter.reFormat(hpeEncounterForm.getSelectedDateYrmo(), DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_END));
			}
			
			if (searchVO.getIconFlag().equals("Y")) {
			if (searchVO.getEncType().equals("I")) {
				hpeEncounterForm.setInstListExpanded(searchVO.isListExpanded());
				hpeEncounterForm.setInstErrorsExpanded(searchVO.isErrorsExpanded());
				hpeEncounterForm.setInstSubscriberExpanded(searchVO.isSubscriberExpanded());
				hpeEncounterForm.setInstProviderExpanded(searchVO.isProviderExpanded());
				hpeEncounterForm.setInstClaimExpanded(searchVO.isClaimExpanded());
				hpeEncounterForm.setInstClaimCodesExpanded(searchVO.isClaimCodesExpanded());
				hpeEncounterForm.setInstClaimNotesExpanded(searchVO.isClaimNotesExpanded());
				hpeEncounterForm.setInstClaimProvExpanded(searchVO.isClaimProvExpanded());
				hpeEncounterForm.setInstClaimProvDetailExpanded(searchVO.isClaimProvDetailExpanded());
				hpeEncounterForm.setInstClaimOtherSubsProvExpanded(searchVO.isClaimOtherSubsProvExpanded());
				hpeEncounterForm.setInstClaimOtherSubsProvDetailExpanded(searchVO.isClaimOtherSubsProvDetailExpanded());
				hpeEncounterForm.setInstClaimOtherSubsExpanded(searchVO.isClaimOtherSubsExpanded());
				hpeEncounterForm.setInstClaimOtherSubsDetailExpanded(searchVO.isClaimOtherSubsDetailExpanded());
				hpeEncounterForm.setInstClaimLineExpanded(searchVO.isClaimLineExpanded());
				hpeEncounterForm.setInstClaimLineDetailExpanded(searchVO.isClaimLineDetailExpanded());
				hpeEncounterForm.setInstClaimLineProvExpanded(searchVO.isClaimLineProvExpanded());
				hpeEncounterForm.setInstClaimLineProvDetailExpanded(searchVO.isClaimLineProvDetailExpanded());
				hpeEncounterForm.setInstClaimLineAdjudExpanded(searchVO.isClaimLineAdjudExpanded());
				hpeEncounterForm.setInstClaimLineAdjudDetailExpanded(searchVO.isClaimLineAdjudDetailExpanded());					
				}else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")) {
				hpeEncounterForm.setProfListExpanded(searchVO.isListExpanded());
				hpeEncounterForm.setProfErrorsExpanded(searchVO.isErrorsExpanded());
				hpeEncounterForm.setProfSubscriberExpanded(searchVO.isSubscriberExpanded());
				hpeEncounterForm.setProfProviderExpanded(searchVO.isProviderExpanded());
				hpeEncounterForm.setProfClaimExpanded(searchVO.isClaimExpanded());
				hpeEncounterForm.setProfClaimCodesExpanded(searchVO.isClaimCodesExpanded());					
				hpeEncounterForm.setProfClaimProvExpanded(searchVO.isClaimProvExpanded());
				hpeEncounterForm.setProfClaimProvDetailExpanded(searchVO.isClaimProvDetailExpanded());
				hpeEncounterForm.setProfClaimOtherSubsProvExpanded(searchVO.isClaimOtherSubsProvExpanded());
				hpeEncounterForm.setProfClaimOtherSubsProvDetailExpanded(searchVO.isClaimOtherSubsProvDetailExpanded());
				hpeEncounterForm.setProfClaimOtherSubsExpanded(searchVO.isClaimOtherSubsExpanded());
				hpeEncounterForm.setProfClaimOtherSubsDetailExpanded(searchVO.isClaimOtherSubsDetailExpanded());
				hpeEncounterForm.setProfClaimLineExpanded(searchVO.isClaimLineExpanded());
				hpeEncounterForm.setProfClaimLineDetailExpanded(searchVO.isClaimLineDetailExpanded());
				hpeEncounterForm.setProfClaimLineProvExpanded(searchVO.isClaimLineProvExpanded());
				hpeEncounterForm.setProfClaimLineProvDetailExpanded(searchVO.isClaimLineProvDetailExpanded());
				hpeEncounterForm.setProfClaimLineAdjudExpanded(searchVO.isClaimLineAdjudExpanded());
				hpeEncounterForm.setProfClaimLineAdjudDetailExpanded(searchVO.isClaimLineAdjudDetailExpanded());					
			}
			}
			
			//Copy the search criteria to the VO
			encounterVO.setSearchDetailSubmitterId(hpeEncounterForm.getSearchDetailSubmitterId());
			encounterVO.setSearchDetailEncType(hpeEncounterForm.getSearchDetailEncType());
			encounterVO.setSearchDetailDateInd(hpeEncounterForm.getSearchDetailDateInd());
			encounterVO.setSearchDetailFromDate(DateFormatter.reFormat(hpeEncounterForm.getSearchDetailFromDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			encounterVO.setSearchDetailToDate(DateFormatter.reFormat(hpeEncounterForm.getSearchDetailToDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			encounterVO.setSearchDetailClaimRefNbr(hpeEncounterForm.getSearchDetailClaimRefNbr());
			encounterVO.setSearchDetailHicNbr(hpeEncounterForm.getSearchDetailHicNbr());
			encounterVO.setSearchDetailGroupStatus(hpeEncounterForm.getSearchDetailGroupStatus());
			encounterVO.setSearchDetailErrorSource(hpeEncounterForm.getSearchDetailErrorSource());
			encounterVO.setSearchDetailErrorGroup(hpeEncounterForm.getSearchDetailErrorGroup());
			encounterVO.setSearchDetailErrorCode(hpeEncounterForm.getSearchDetailErrorCode());
		}		

		if (encounterVO.getSearchDetailEncType().equals("I")) {
			pageInstClaims(conn,sessionHelper,context,hpeEncounterForm,request,move,requestStatus);
			logger.info(LoggerConstants.methodEndLevel());
			return HPEConstants.HPE_INSTDETAIL;
		}
		if (encounterVO.getSearchDetailEncType().equals("P") || encounterVO.getSearchDetailEncType().equals("E")) {
			//DME_Dashboard_changes
			pageProfClaims(conn,sessionHelper,context,hpeEncounterForm,request,move,requestStatus,encounterVO.getSearchDetailEncType());
			logger.info(LoggerConstants.methodEndLevel());
			return HPEConstants.HPE_PROFDETAIL;
		}
		logger.info(LoggerConstants.methodEndLevel());	
		return HPEConstants.HPE_ERROR;
	}

	public static void pageInstClaims(Connection conn, SessionHelper sessionHelper, HPEContext context, HPEEncounterForm hpeEncounterForm, HttpServletRequest request, String move,String requestStatus)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getEncounterVO();
			HpeSearchVO searchVO = null;			
			String oldStatus = "false";
			
			if ("0".equals(requestStatus)) {
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
			}else if ("1".equals(requestStatus)) {
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
			}else if("2".equals(requestStatus)){
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_FILE_TRACK_VO);
			}
			requestStatus = null;

			if (searchVO != null) {							
				context.setClaimDetailPagination(searchVO.getClaimDetailPagination());
				if (!("".equals(searchVO.getMove())) && (searchVO.getMove()!= null))  {
					move=searchVO.getMove();					
				}
				oldStatus = searchVO.getOldState();
			}
			
			// we want to use the data from the last Query should be here already
			Pagination claimDetailPagination = context.getClaimDetailPagination();
			
			// File track code start		
			
			if(hpeEncounterForm.isFileTrackingFlag()){
				encounterVO.setFileTrackFlag(true);
				encounterVO.setOrigIntrchgCtrlNbr(hpeEncounterForm.getOrigFileId());
				encounterVO.setSearchDetailGroupStatus(hpeEncounterForm.getSearchDetailGroupStatus());
				encounterVO.setSearchDetailSubmitterId(hpeEncounterForm.getSearchDetailSubmitterId());
			}else{
				encounterVO.setFileTrackFlag(false);
			}
			// File track code END
			
			// Search
			context.getEncounterService().selectClaimsBySearchCriteria(conn, encounterVO, claimDetailPagination, move,oldStatus);

			// Refresh
			//
			Enc837iClmVOs instClaims = encounterVO.getInstClaims();

			// Store search results in request scope
			request.setAttribute("instClaims", instClaims);

			// Pre-select first claim
			if ((instClaims != null) && (instClaims.isEmpty() == false)) {
				// Retrieve first claim
				Enc837iClmVO instClaim = (Enc837iClmVO) instClaims.get(0);

				// Set form state as if first claim were selected
				hpeEncounterForm.setSelectedClaimType("I");
				hpeEncounterForm.setSelectedClaimRefNbr(instClaim.getWtxClaimRefNbr());
				hpeEncounterForm.setSelectedClaimRevNbr(Integer.toString(instClaim.getWtxClaimRevNbr()));
				hpeEncounterForm.setSelectedClaimSeqNbr(Integer.toString(instClaim.getClmSeqNbr()));

				selectClaim(conn, sessionHelper, context, hpeEncounterForm, request,requestStatus);

				// Clear form state
				if(encounterVO.isFileTrackFlag()==true){
					hpeEncounterForm.setSelClaimType(searchVO.getClmType());
				}
				hpeEncounterForm.setSelectedClaimType("");
				hpeEncounterForm.setSelectedClaimRefNbr("");
				hpeEncounterForm.setSelectedClaimRevNbr("");
				hpeEncounterForm.setSelectedClaimSeqNbr("");
			}
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void pageProfClaims(Connection conn, SessionHelper sessionHelper, HPEContext context, HPEEncounterForm hpeEncounterForm, HttpServletRequest request, String move,String requestStatus,String encType)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getEncounterVO();
			HpeSearchVO searchVO = null;		
			String oldStatus = "false";

			if ("0".equals(requestStatus)) {
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
			}else if ("1".equals(requestStatus)) {
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
			}else if("2".equals(requestStatus)){
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_FILE_TRACK_VO);
			}
			requestStatus = null;

			if (searchVO != null) {							
				context.setClaimDetailPagination(searchVO.getClaimDetailPagination());
				if (!("".equals(searchVO.getMove())) && (searchVO.getMove()!= null))  {
					move=searchVO.getMove();					
				}
				oldStatus = searchVO.getOldState();
			}
			
			// we want to use the data from the last Query should be here already
			Pagination claimDetailPagination = context.getClaimDetailPagination();
			
			

			// File track code start		
			
			if(hpeEncounterForm.isFileTrackingFlag()){
				encounterVO.setFileTrackFlag(true);
				encounterVO.setOrigIntrchgCtrlNbr(hpeEncounterForm.getOrigFileId());
				encounterVO.setSearchDetailGroupStatus(hpeEncounterForm.getSearchDetailGroupStatus());
				encounterVO.setSearchDetailSubmitterId(hpeEncounterForm.getSearchDetailSubmitterId());
			}else{
				encounterVO.setFileTrackFlag(false);
			}
			// File track code END

			// Search
			context.getEncounterService().selectClaimsBySearchCriteria(conn, encounterVO, claimDetailPagination, move,oldStatus);

			// Refresh
			//
			Enc837pClmVOs profClaims = encounterVO.getProfClaims();

			// Store search results in request scope
			request.setAttribute("profClaims", profClaims);

			// Pre-select first claim
			if ((profClaims != null) && (profClaims.isEmpty() == false)) {
				// Retrieve first claim
				Enc837pClmVO profClaim = (Enc837pClmVO) profClaims.get(0);

				// Set form state as if first claim were selected
				hpeEncounterForm.setSelectedClaimType(encType); //DME_Dashboard_changes
				hpeEncounterForm.setSelectedClaimRefNbr(profClaim.getWtxClaimRefNbr());
				hpeEncounterForm.setSelectedClaimRevNbr(Integer.toString(profClaim.getWtxClaimRevNbr()));
				hpeEncounterForm.setSelectedClaimSeqNbr(Integer.toString(profClaim.getClmSeqNbr()));

				selectClaim(conn, sessionHelper, context, hpeEncounterForm, request,requestStatus);

				// Clear form state
				if(encounterVO.isFileTrackFlag()==true){
					hpeEncounterForm.setSelClaimType(searchVO.getClmType());
				}
				hpeEncounterForm.setSelectedClaimType("");
				hpeEncounterForm.setSelectedClaimRefNbr("");
				hpeEncounterForm.setSelectedClaimRevNbr("");
				hpeEncounterForm.setSelectedClaimSeqNbr("");
			}
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}	
	/*
	 * method to retrieve error details for Institutional
	 */
	public static void pageErrorDetail(Connection conn, SessionHelper sessionHelper, HPEContext context, HPEEncounterForm hpeEncounterForm, HttpServletRequest request)
	throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getEncounterVO();			
		
			// Search
			context.getEncounterService().selectErrorsBySearchCriteria(conn, encounterVO);
		
			// Refresh			
			EncErrorstatSumVOs errorLists = encounterVO.getSearchErrorSummaryResults();			
			
			// Store search results in request scope
			request.setAttribute("errorLists", errorLists);		
			
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static String selectClaim(Connection conn, SessionHelper sessionHelper, HPEContext context, HPEEncounterForm hpeEncounterForm, HttpServletRequest request,String requestStatus)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String forward = HPEConstants.HPE_ERROR;
		HpeSearchVO searchVO = null;

		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getEncounterVO();

			// Set customer
			encounterVO.setMfId(/* "HCFLCS4" */ sessionHelper.getMfId() /* "HCF0031" */);
			
			if ("0".equals(requestStatus)){
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
			} else if("1".equals(requestStatus)) {
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);			
			}	
			
			encounterVO.setUserId(sessionHelper.getUserId());								
			if (searchVO != null) {
				hpeEncounterForm.setSelectedClaimType(searchVO.getSelectedClaimType());
				hpeEncounterForm.setSelectedClaimRefNbr(searchVO.getSelectedClaimRefNbr());
				hpeEncounterForm.setSelectedClaimRevNbr(searchVO.getSelectedClaimRevNbr());
				hpeEncounterForm.setSelectedClaimSeqNbr(searchVO.getSelectedClaimSeqNbr());
				hpeEncounterForm.setSearchDetailSubmitterId(searchVO.getSubmitterId());
				hpeEncounterForm.setSearchDetailClmType(searchVO.getClmType());
				hpeEncounterForm.setSearchDetailEncType(searchVO.getEncType());
				hpeEncounterForm.setSearchDetailDateInd(searchVO.getDateInd());				
				hpeEncounterForm.setSearchDetailFromDate(searchVO.getFromDate());
				hpeEncounterForm.setSearchDetailToDate(searchVO.getToDate());
				hpeEncounterForm.setSearchDetailGroupStatus(searchVO.getGroupStatus());	
				hpeEncounterForm.setSearchDetailErrorCode(searchVO.getErrorCode());
				hpeEncounterForm.setSearchDetailErrorGroup(searchVO.getErrorGroup());
				hpeEncounterForm.setSearchDetailErrorSource(searchVO.getErrorSource());
				hpeEncounterForm.setSearchDetailClaimRefNbr(searchVO.getClaimRefNbr());
				hpeEncounterForm.setSearchDetailHicNbr(searchVO.getHicNbr());	
				if (searchVO.getEncType().equals("I")) {
					hpeEncounterForm.setInstListExpanded(searchVO.isListExpanded());
					hpeEncounterForm.setInstErrorsExpanded(searchVO.isErrorsExpanded());
					hpeEncounterForm.setInstSubscriberExpanded(searchVO.isSubscriberExpanded());
					hpeEncounterForm.setInstProviderExpanded(searchVO.isProviderExpanded());
					hpeEncounterForm.setInstClaimExpanded(searchVO.isClaimExpanded());
					hpeEncounterForm.setInstClaimCodesExpanded(searchVO.isClaimCodesExpanded());
					hpeEncounterForm.setInstClaimNotesExpanded(searchVO.isClaimNotesExpanded());
					hpeEncounterForm.setInstClaimProvExpanded(searchVO.isClaimProvExpanded());
					hpeEncounterForm.setInstClaimProvDetailExpanded(searchVO.isClaimProvDetailExpanded());
					hpeEncounterForm.setInstClaimOtherSubsProvExpanded(searchVO.isClaimOtherSubsProvExpanded());
					hpeEncounterForm.setInstClaimOtherSubsProvDetailExpanded(searchVO.isClaimOtherSubsProvDetailExpanded());
					hpeEncounterForm.setInstClaimOtherSubsExpanded(searchVO.isClaimOtherSubsExpanded());
					hpeEncounterForm.setInstClaimOtherSubsDetailExpanded(searchVO.isClaimOtherSubsDetailExpanded());
					hpeEncounterForm.setInstClaimLineExpanded(searchVO.isClaimLineExpanded());
					hpeEncounterForm.setInstClaimLineDetailExpanded(searchVO.isClaimLineDetailExpanded());
					hpeEncounterForm.setInstClaimLineProvExpanded(searchVO.isClaimLineProvExpanded());
					hpeEncounterForm.setInstClaimLineProvDetailExpanded(searchVO.isClaimLineProvDetailExpanded());
					hpeEncounterForm.setInstClaimLineAdjudExpanded(searchVO.isClaimLineAdjudExpanded());
					hpeEncounterForm.setInstClaimLineAdjudDetailExpanded(searchVO.isClaimLineAdjudDetailExpanded());					
				} else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")) {	//DME_Dashboard_changes
					hpeEncounterForm.setProfListExpanded(searchVO.isListExpanded());
					hpeEncounterForm.setProfErrorsExpanded(searchVO.isErrorsExpanded());
					hpeEncounterForm.setProfSubscriberExpanded(searchVO.isSubscriberExpanded());
					hpeEncounterForm.setProfProviderExpanded(searchVO.isProviderExpanded());
					hpeEncounterForm.setProfClaimExpanded(searchVO.isClaimExpanded());
					hpeEncounterForm.setProfClaimCodesExpanded(searchVO.isClaimCodesExpanded());					
					hpeEncounterForm.setProfClaimProvExpanded(searchVO.isClaimProvExpanded());
					hpeEncounterForm.setProfClaimProvDetailExpanded(searchVO.isClaimProvDetailExpanded());
					hpeEncounterForm.setProfClaimOtherSubsProvExpanded(searchVO.isClaimOtherSubsProvExpanded());
					hpeEncounterForm.setProfClaimOtherSubsProvDetailExpanded(searchVO.isClaimOtherSubsProvDetailExpanded());
					hpeEncounterForm.setProfClaimOtherSubsExpanded(searchVO.isClaimOtherSubsExpanded());
					hpeEncounterForm.setProfClaimOtherSubsDetailExpanded(searchVO.isClaimOtherSubsDetailExpanded());
					hpeEncounterForm.setProfClaimLineExpanded(searchVO.isClaimLineExpanded());
					hpeEncounterForm.setProfClaimLineDetailExpanded(searchVO.isClaimLineDetailExpanded());
					hpeEncounterForm.setProfClaimLineProvExpanded(searchVO.isClaimLineProvExpanded());
					hpeEncounterForm.setProfClaimLineProvDetailExpanded(searchVO.isClaimLineProvDetailExpanded());
					hpeEncounterForm.setProfClaimLineAdjudExpanded(searchVO.isClaimLineAdjudExpanded());
					hpeEncounterForm.setProfClaimLineAdjudDetailExpanded(searchVO.isClaimLineAdjudDetailExpanded());					
				}
				
			}			
			
			hpeEncounterForm.setSubscriberDisplayState(HPEConstants.HPE_SCREEN_VIEW);
			hpeEncounterForm.setClaimDisplayState(HPEConstants.HPE_SCREEN_VIEW);
			hpeEncounterForm.setProviderDisplayState(HPEConstants.HPE_SCREEN_VIEW);
			hpeEncounterForm.setClmProviderDisplayState(HPEConstants.HPE_SCREEN_VIEW);			
			hpeEncounterForm.setDataChanged(false);
			hpeEncounterForm.setClmPrvChanged(false);
			
			// Copy the search criteria to the VO
			encounterVO.setSelectedClaimType(hpeEncounterForm.getSelectedClaimType());
			encounterVO.setSelectedClaimRefNbr(hpeEncounterForm.getSelectedClaimRefNbr());
			encounterVO.setSelectedClaimRevNbr(Integer.parseInt(hpeEncounterForm.getSelectedClaimRevNbr()));
			encounterVO.setSelectedClaimSeqNbr(Integer.parseInt(hpeEncounterForm.getSelectedClaimSeqNbr()));			
			encounterVO.setSearchDetailSubmitterId(hpeEncounterForm.getSearchDetailSubmitterId());
			encounterVO.setSearchDetailEncType(hpeEncounterForm.getSearchDetailEncType());
			encounterVO.setSearchDetailClmType(hpeEncounterForm.getSearchDetailClmType());
			encounterVO.setSearchDetailDateInd(hpeEncounterForm.getSearchDetailDateInd());
			encounterVO.setSearchDetailFromDate(DateFormatter.reFormat(hpeEncounterForm.getSearchDetailFromDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			encounterVO.setSearchDetailToDate(DateFormatter.reFormat(hpeEncounterForm.getSearchDetailToDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			encounterVO.setSearchDetailClaimRefNbr(hpeEncounterForm.getSearchDetailClaimRefNbr());
			encounterVO.setSearchDetailHicNbr(hpeEncounterForm.getSearchDetailHicNbr());
			encounterVO.setSearchDetailGroupStatus(hpeEncounterForm.getSearchDetailGroupStatus());
			encounterVO.setSearchDetailErrorSource(hpeEncounterForm.getSearchDetailErrorSource());
			encounterVO.setSearchDetailErrorGroup(hpeEncounterForm.getSearchDetailErrorGroup());
			encounterVO.setSearchDetailErrorCode(hpeEncounterForm.getSearchDetailErrorCode());

			// Search & store search results in request scope
			if (encounterVO.getSelectedClaimType().equals("I")) {
				selectInstClaim(conn, sessionHelper, context, hpeEncounterForm, request);
				forward = HPEConstants.HPE_INSTDETAIL;
			}
			else
			if (encounterVO.getSearchDetailEncType().equals("P") || encounterVO.getSearchDetailEncType().equals("E")) { //DME_Dashboard_changes
				selectProfClaim(conn, sessionHelper, context, hpeEncounterForm, request);
				forward = HPEConstants.HPE_PROFDETAIL;
			}
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return forward;
	}

	public static void selectInstClaim(Connection conn, SessionHelper sessionHelper, HPEContext context, HPEEncounterForm hpeEncounterForm, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getEncounterVO();

			// Search
			context.getEncounterService().selectClaim(conn, encounterVO);
			
			//Editable Fileds CHS -- IFOX-00395627
			hpeEncounterForm.setProcessStatus(context.getEncounterVO().getInstClaim().getProcessStatus());
			
			if(null != encounterVO.getInstBillingProvider()){
				if(!encounterVO.getInstBillingProvider().getMfId().equals("") && encounterVO.getInstBillingProvider().getMfId()!= null)
					hpeEncounterForm.setBillProviderExist("Y");
				else
					hpeEncounterForm.setBillProviderExist("N");
			}
			else 
				hpeEncounterForm.setBillProviderExist("N");
			
			if(null != encounterVO.getInstClaimProviders()){
				if (encounterVO.getInstClaimProviders().size() > 0)
					hpeEncounterForm.setClmProviderExist("Y");
				else
					hpeEncounterForm.setClmProviderExist("N");
			}
			else
				hpeEncounterForm.setClmProviderExist("N");
			
			if(null != encounterVO.getInstClaimOtherSubscribers()){
				if (encounterVO.getInstClaimOtherSubscribers().size() > 0)
					hpeEncounterForm.setClmOtherSubscribersExist("Y");
				else
					hpeEncounterForm.setClmOtherSubscribersExist("N");
			}
			else
				hpeEncounterForm.setClmOtherSubscribersExist("N");
			
			if(null != encounterVO.getInstClaimOtherSubscriberProviders()){
				if (encounterVO.getInstClaimOtherSubscriberProviders().size() > 0)
					hpeEncounterForm.setClmOtherSubsProvExist("Y");
				else
					hpeEncounterForm.setClmOtherSubsProvExist("N");
			}
			else
				hpeEncounterForm.setClmOtherSubsProvExist("N");
			
			if(null != encounterVO.getInstClaimLines()){
				if (encounterVO.getInstClaimLines().size() > 0)
					hpeEncounterForm.setClmLinesExist("Y");
				else
					hpeEncounterForm.setClmLinesExist("N");				
			}
			else
				hpeEncounterForm.setClmLinesExist("N");
					
			if(null != encounterVO.getInstClaimLineProviders()){
				if (encounterVO.getInstClaimLineProviders().size() > 0)
					hpeEncounterForm.setClmLineProvExist("Y");
				else
					hpeEncounterForm.setClmLineProvExist("N");					
			}
			else
				hpeEncounterForm.setClmLineProvExist("N");
			
			if(null != encounterVO.getInstClaimLineAdjudications()){
				if (encounterVO.getInstClaimLineAdjudications().size() > 0)
					hpeEncounterForm.setClmLineAdjudExist("Y");
				else
					hpeEncounterForm.setClmLineAdjudExist("N");				
			}
			else
				hpeEncounterForm.setClmLineAdjudExist("N");			
			
			// Store search results in request scope
			setInstRequest(encounterVO, request);

		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void setInstRequest(HPEEncounterVO encounterVO, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		// Store search results in request scope
		request.setAttribute("instClaims", encounterVO.getInstClaims());
		request.setAttribute("instClaim", encounterVO.getInstClaim());
		request.setAttribute("instClaimErrors", encounterVO.getInstClaimErrors());
		request.setAttribute("instSubscriber", encounterVO.getInstSubscriber());
		request.setAttribute("instBillingProvider", encounterVO.getInstBillingProvider());
		request.setAttribute("instClaimAdjustments", encounterVO.getInstClaimAdjustments());
		request.setAttribute("instClaimAttachments", encounterVO.getInstClaimAttachments());
		request.setAttribute("instClaimConditions", encounterVO.getInstClaimConditions());
		request.setAttribute("instClaimOccurrences", encounterVO.getInstClaimOccurrences());
		request.setAttribute("instClaimOccurrenceSpans", encounterVO.getInstClaimOccurrenceSpans());
		request.setAttribute("instClaimValues", encounterVO.getInstClaimValues());
		request.setAttribute("instClaimOtherDiagnoses", encounterVO.getInstClaimOtherDiagnoses());
		request.setAttribute("instClaimOtherProcedures", encounterVO.getInstClaimOtherProcedures());
		request.setAttribute("instClaimTreatments", encounterVO.getInstClaimTreatments());
		request.setAttribute("instClaimExternalInjuries", encounterVO.getInstClaimExternalInjuries());			
		request.setAttribute("instClaimProviders", encounterVO.getInstClaimProviders());
		request.setAttribute("instClaimOtherSubscribers", encounterVO.getInstClaimOtherSubscribers());
		request.setAttribute("instClaimOtherSubscriberProviders", encounterVO.getInstClaimOtherSubscriberProviders());
		request.setAttribute("instClaimLines", encounterVO.getInstClaimLines());
		request.setAttribute("instClaimLineProviders", encounterVO.getInstClaimLineProviders());
		request.setAttribute("instClaimLineAttachments", encounterVO.getInstClaimLineAttachments());
		request.setAttribute("instClaimLineAdjudications", encounterVO.getInstClaimLineAdjudications());
		request.setAttribute("instClaimLineAdjudicationAdjustments", encounterVO.getInstClaimLineAdjustments());
		request.setAttribute("instClaimNotes", encounterVO.getInstClaimNotes());
		request.setAttribute("instClmStatlog", encounterVO.getInstClmStatlog());	
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void selectProfClaim(Connection conn, SessionHelper sessionHelper, HPEContext context, HPEEncounterForm hpeEncounterForm, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getEncounterVO();

			// Search
			context.getEncounterService().selectClaim(conn, encounterVO);
			
			//Editable Fileds CHS -- IFOX-00395627
			hpeEncounterForm.setProcessStatus(context.getEncounterVO().getProfClaim().getProcessStatus());
			
			if(null != encounterVO.getProfBillingProvider()){
				if (!encounterVO.getProfBillingProvider().getMfId().equalsIgnoreCase("") && !encounterVO.getProfBillingProvider().getMfId().equals(null))
					hpeEncounterForm.setBillProviderExist("Y");
				else 
					hpeEncounterForm.setBillProviderExist("N");
			}else				
				hpeEncounterForm.setBillProviderExist("N");
			
			if(null != encounterVO.getProfClaimProviders()){
				if (encounterVO.getProfClaimProviders().size() > 0)
					hpeEncounterForm.setClmProviderExist("Y");
				else 
					hpeEncounterForm.setClmProviderExist("N");				
			}
			else 
				hpeEncounterForm.setClmProviderExist("N");
			
			if(null != encounterVO.getProfClaimOtherSubscribers()){				
				if (encounterVO.getProfClaimOtherSubscribers().size() > 0)
					hpeEncounterForm.setClmOtherSubscribersExist("Y");
				else 
					hpeEncounterForm.setClmOtherSubscribersExist("N");	
			}
			else 
				hpeEncounterForm.setClmOtherSubscribersExist("N");
			
			if(null != encounterVO.getProfClaimOtherSubscriberProviders()){				
				if (encounterVO.getProfClaimOtherSubscriberProviders().size() > 0)
					hpeEncounterForm.setClmOtherSubsProvExist("Y");
				else 
					hpeEncounterForm.setClmOtherSubsProvExist("N");	
			}
			else 
				hpeEncounterForm.setClmOtherSubsProvExist("N");
			
			if(null != encounterVO.getProfClaimLines()){
				if(encounterVO.getProfClaimLines().size()> 0)
					hpeEncounterForm.setClmLinesExist("Y");
				else
					hpeEncounterForm.setClmLinesExist("N");
			}
			else 
				hpeEncounterForm.setClmLinesExist("N");
			
			if(null != encounterVO.getProfClaimLineProviders()){
				if(encounterVO.getProfClaimLineProviders().size() > 0)
					hpeEncounterForm.setClmLineProvExist("Y");
				else
					hpeEncounterForm.setClmLineProvExist("N");
			}
			else 
				hpeEncounterForm.setClmLineProvExist("N");
			
			if(null != encounterVO.getProfClaimLineAdjudications()){
				if(encounterVO.getProfClaimLineAdjudications().size() > 0)
					hpeEncounterForm.setClmLineAdjudExist("Y");
				else
					hpeEncounterForm.setClmLineAdjudExist("N");				
			}
			else 
				hpeEncounterForm.setClmLineAdjudExist("N");
			
			// Store search results in request scope
			setProfRequest(encounterVO, request);

		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void setProfRequest(HPEEncounterVO encounterVO, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		request.setAttribute("profClaims", encounterVO.getProfClaims());
		request.setAttribute("profClaim", encounterVO.getProfClaim());
		request.setAttribute("profClaimErrors", encounterVO.getProfClaimErrors());
		request.setAttribute("profSubscriber", encounterVO.getProfSubscriber());
		request.setAttribute("profBillingProvider", encounterVO.getProfBillingProvider());
		request.setAttribute("profClaimAdjustments", encounterVO.getProfClaimAdjustments());
		request.setAttribute("profClaimAttachments", encounterVO.getProfClaimAttachments());
		request.setAttribute("profClaimConditions", encounterVO.getProfClaimConditions());
		request.setAttribute("profClaimOtherDiagnoses", encounterVO.getProfClaimOtherDiagnoses());
		request.setAttribute("profClaimProviders", encounterVO.getProfClaimProviders());
		request.setAttribute("profClaimOtherSubscribers", encounterVO.getProfClaimOtherSubscribers());
		request.setAttribute("profClaimOtherSubscriberProviders", encounterVO.getProfClaimOtherSubscriberProviders());
		request.setAttribute("profClaimLines", encounterVO.getProfClaimLines());
		request.setAttribute("profClaimLineProviders", encounterVO.getProfClaimLineProviders());
		request.setAttribute("profClaimLineAttachments", encounterVO.getProfClaimLineAttachments());
		request.setAttribute("profClaimLineReferrals", encounterVO.getProfClaimLineReferrals());
		request.setAttribute("profClaimLineDocuments", encounterVO.getProfClaimLineDocuments());
		request.setAttribute("profClaimLineAdjudications", encounterVO.getProfClaimLineAdjudications());
		request.setAttribute("profClaimLineAdjudicationAdjustments", encounterVO.getProfClaimLineAdjustments());
		request.setAttribute("profClmStatlog", encounterVO.getProfClmStatlog());	
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static String updateFormData(Connection conn, SessionHelper sessionHelper, HPEContext context, HPEEncounterForm hpeEncounterForm, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String forward = HPEConstants.HPE_ERROR;		
		
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getEncounterVO();					
			
			if (encounterVO.getSelectedClaimType().equals("I")) {
				
				updateInstitutional(conn, sessionHelper, context, hpeEncounterForm, request);				
				hpeEncounterForm.setInstSubscriberExpanded(true);
			    hpeEncounterForm.setInstClaimExpanded(true);
			    hpeEncounterForm.setInstClaimProvExpanded(true);
			    hpeEncounterForm.setInstClaimProvDetailExpanded(true);
			    hpeEncounterForm.setInstClaimOtherSubsExpanded(true);
			    hpeEncounterForm.setInstClaimOtherSubsDetailExpanded(true);
			    hpeEncounterForm.setInstClaimOtherSubsProvExpanded(true);
			    hpeEncounterForm.setInstClaimOtherSubsProvDetailExpanded(true);
			    hpeEncounterForm.setInstClaimLineExpanded(true);
			    hpeEncounterForm.setInstClaimLineDetailExpanded(true);
			    hpeEncounterForm.setInstClaimLineProvExpanded(true);
			    hpeEncounterForm.setInstClaimLineProvDetailExpanded(true);
			    hpeEncounterForm.setInstClaimLineAdjudExpanded(true);
			    hpeEncounterForm.setInstClaimLineAdjudDetailExpanded(true);
			    hpeEncounterForm.setInstProviderExpanded(true);			   

				forward = HPEConstants.HPE_INSTDETAIL;
	    	}						    	
			else
			if (encounterVO.getSearchDetailEncType().equals("P") || encounterVO.getSearchDetailEncType().equals("E")) { //IFOX-00406290

				updateProfessional(conn, sessionHelper, context, hpeEncounterForm, request);
				hpeEncounterForm.setProfSubscriberExpanded(true);
			    hpeEncounterForm.setProfClaimExpanded(true);
			    hpeEncounterForm.setProfClaimProvExpanded(true);
			    hpeEncounterForm.setProfClaimProvDetailExpanded(true);
			    hpeEncounterForm.setProfClaimOtherSubsExpanded(true);
			    hpeEncounterForm.setProfClaimOtherSubsDetailExpanded(true);
			    hpeEncounterForm.setProfClaimOtherSubsProvExpanded(true);
			    hpeEncounterForm.setProfClaimOtherSubsProvDetailExpanded(true);
			    hpeEncounterForm.setProfClaimLineExpanded(true);
			    hpeEncounterForm.setProfClaimLineDetailExpanded(true);
			    hpeEncounterForm.setProfClaimLineProvExpanded(true);
			    hpeEncounterForm.setProfClaimLineProvDetailExpanded(true);
			    hpeEncounterForm.setProfClaimLineAdjudExpanded(true);
			    hpeEncounterForm.setProfClaimLineAdjudDetailExpanded(true);
			    hpeEncounterForm.setProfProviderExpanded(true);	
				
				forward = HPEConstants.HPE_PROFDETAIL;
			}
		
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		
		logger.info(LoggerConstants.methodEndLevel());
		return forward;
		
	}


	public static void updateInstitutional(Connection conn, SessionHelper sessionHelper, HPEContext context, HPEEncounterForm hpeEncounterForm, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		HPEEncounterVO encounterVO = context.getEncounterVO();					
		encounterVO.setDisplayMessage("");
		encounterVO.setInstClaimDirty(false);
		encounterVO.setInstSubsDirty(false);
		encounterVO.setInstOthSubsDirty(false);
		encounterVO.setInstClmLineDirty(false);
		encounterVO.setInstClmLinePrvDirty(false);
		encounterVO.setInstClmLineAdjudDirty(false);
		Iterator itr = null;
		
		HPEEncounterService encounterService = context.getEncounterService();

		Enc837iBillprvVO newEnc837iBillprvVO = new Enc837iBillprvVO(encounterVO.getInstBillingProvider());
		newEnc837iBillprvVO.setBillPrvOrgName(hpeEncounterForm.getBillPrvOrgName());
		newEnc837iBillprvVO.setBillPrvAddrLine1(hpeEncounterForm.getBillPrvAddrLine1());
		newEnc837iBillprvVO.setBillPrvAddrLine2(hpeEncounterForm.getBillPrvAddrLine2());
		newEnc837iBillprvVO.setBillPrvCity(hpeEncounterForm.getBillPrvCity());
		newEnc837iBillprvVO.setBillPrvState(hpeEncounterForm.getBillPrvState());							
		newEnc837iBillprvVO.setBillPrvZip(hpeEncounterForm.getBillPrvZip());
		newEnc837iBillprvVO.setBillPrvContactName(hpeEncounterForm.getBillPrvContactName());
		newEnc837iBillprvVO.setBillPrvCountry(hpeEncounterForm.getBillPrvCountry());//
		newEnc837iBillprvVO.setBillPrvCntrySubdCd(hpeEncounterForm.getBillPrvCntrySubdCd());//
		newEnc837iBillprvVO.setBillPrvTaxonomyCd(hpeEncounterForm.getBillPrvTaxonomyCd());
		newEnc837iBillprvVO.setBillPrvNpi(hpeEncounterForm.getBillPrvNpi());
		newEnc837iBillprvVO.setFormattedBillPrvAffilTaxId(hpeEncounterForm.getFormattedBillPrvAffilTaxId());
		newEnc837iBillprvVO.setBillPrvComNbrQual1(hpeEncounterForm.getBillPrvComNbrQual1());
		newEnc837iBillprvVO.setBillPrvComNbrQual2(hpeEncounterForm.getBillPrvComNbrQual2());
		newEnc837iBillprvVO.setBillPrvComNbrQual3(hpeEncounterForm.getBillPrvComNbrQual3());
		newEnc837iBillprvVO.setBillPrvComNbr1(hpeEncounterForm.getBillPrvComNbr1());
		newEnc837iBillprvVO.setBillPrvComNbr2(hpeEncounterForm.getBillPrvComNbr2());
		newEnc837iBillprvVO.setBillPrvComNbr3(hpeEncounterForm.getBillPrvComNbr3());
		
		newEnc837iBillprvVO.setP2prvAddrLine1(hpeEncounterForm.getP2prvAddrLine1());
		newEnc837iBillprvVO.setP2prvAddrLine2(hpeEncounterForm.getP2prvAddrLine2());
		newEnc837iBillprvVO.setP2prvCity(hpeEncounterForm.getP2prvCity());
		newEnc837iBillprvVO.setP2prvState(hpeEncounterForm.getP2prvState());
		newEnc837iBillprvVO.setP2prvZip(hpeEncounterForm.getP2prvZip());
		newEnc837iBillprvVO.setP2prvCountry(hpeEncounterForm.getP2prvCountry());//
		newEnc837iBillprvVO.setP2prvCntrySubdCd(hpeEncounterForm.getP2prvCntrySubdCd());//
		
		newEnc837iBillprvVO.setP2pOrgName(hpeEncounterForm.getP2pOrgName());
		newEnc837iBillprvVO.setP2pPrimPayerId(hpeEncounterForm.getP2pPrimPayerId());
		newEnc837iBillprvVO.setP2pLocNbr(hpeEncounterForm.getP2pLocNbr());
		newEnc837iBillprvVO.setP2pAddrLine1(hpeEncounterForm.getP2pAddrLine1());
		newEnc837iBillprvVO.setP2pPayerIdNbr(hpeEncounterForm.getP2pPayerIdNbr());
		newEnc837iBillprvVO.setP2pNaicCd(hpeEncounterForm.getP2pNaicCd());
		newEnc837iBillprvVO.setP2pAddrLine2(hpeEncounterForm.getP2pAddrLine2());
		newEnc837iBillprvVO.setP2pPrimPlanId(hpeEncounterForm.getP2pPrimPlanId());
		newEnc837iBillprvVO.setP2pTaxId(hpeEncounterForm.getP2pTaxId());
		newEnc837iBillprvVO.setP2pCity(hpeEncounterForm.getP2pCity());
		newEnc837iBillprvVO.setP2pState(hpeEncounterForm.getP2pState());
		newEnc837iBillprvVO.setP2pZip(hpeEncounterForm.getP2pZip());
		newEnc837iBillprvVO.setP2pCountry(hpeEncounterForm.getP2pCountry());
		newEnc837iBillprvVO.setP2pCntrySubdCd(hpeEncounterForm.getP2pCntrySubdCd());
		
		Enc837iSubsVO newEnc837iSubsVO = new Enc837iSubsVO(encounterVO.getInstSubscriber());		
		newEnc837iSubsVO.setSubsFirstName(hpeEncounterForm.getSubsFirstName());
		newEnc837iSubsVO.setSubsMiddleName(hpeEncounterForm.getSubsMiddleName());
		newEnc837iSubsVO.setSubsLastName(hpeEncounterForm.getSubsLastName());								
		newEnc837iSubsVO.setBillPrvAffilTaxId(newEnc837iBillprvVO.getBillPrvAffilTaxId());
		newEnc837iSubsVO.setSubsHicNbr(hpeEncounterForm.getSubsHicNbr());
		newEnc837iSubsVO.setMbi(hpeEncounterForm.getMbi());
		newEnc837iSubsVO.setSubsSsn(DemographicFormatter.unFormatSSN(hpeEncounterForm.getFormattedSubsSsn()));								
		newEnc837iSubsVO.setSubsDob(DateFormatter.reFormat(hpeEncounterForm.getFormattedSubsDob(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
		newEnc837iSubsVO.setSubsSex(hpeEncounterForm.getSubsSex());	
		newEnc837iSubsVO.setSubsAddrLine1(hpeEncounterForm.getSubsAddrLine1());
		newEnc837iSubsVO.setSubsAddrLine2(hpeEncounterForm.getSubsAddrLine2());
		newEnc837iSubsVO.setSubsCity(hpeEncounterForm.getSubsCity());				
		newEnc837iSubsVO.setSubsState(hpeEncounterForm.getSubsState());				
		newEnc837iSubsVO.setSubsZip(hpeEncounterForm.getSubsZip());

		newEnc837iSubsVO.setSubsMemberId(hpeEncounterForm.getSubsMemberId());	
		newEnc837iSubsVO.setSubsCountry(hpeEncounterForm.getSubsCountry());
		newEnc837iSubsVO.setSubsGrpName(hpeEncounterForm.getSubsGrpName());
		newEnc837iSubsVO.setSubsCntrySubdCd(hpeEncounterForm.getSubsCntrySubdCd());				
		newEnc837iSubsVO.setSubsPayerSeqCd(hpeEncounterForm.getSubsPayerSeqCd());				
		newEnc837iSubsVO.setSubsRelationCd(hpeEncounterForm.getSubsRelationCd());
		newEnc837iSubsVO.setSubsFilingIndCd(hpeEncounterForm.getSubsFilingIndCd());
		newEnc837iSubsVO.setSubsEntityType(hpeEncounterForm.getSubsEntityType());
		newEnc837iSubsVO.setSubsGrpOrPolNbr(hpeEncounterForm.getSubsGrpOrPolNbr());
		
		newEnc837iSubsVO.setPayerName(hpeEncounterForm.getPayerName());	
		newEnc837iSubsVO.setPayerId(hpeEncounterForm.getPayerId());
		newEnc837iSubsVO.setPayerTaxId(hpeEncounterForm.getPayerTaxId());
		newEnc837iSubsVO.setPayerAddrLine1(hpeEncounterForm.getPayerAddrLine1());				
		newEnc837iSubsVO.setPayerPlanId(hpeEncounterForm.getPayerPlanId());				
		newEnc837iSubsVO.setPayerLocNbr(hpeEncounterForm.getPayerLocNbr());
		newEnc837iSubsVO.setPayerAddrLine2(hpeEncounterForm.getPayerAddrLine2());
		newEnc837iSubsVO.setPayerNaicCd(hpeEncounterForm.getPayerNaicCd());
		newEnc837iSubsVO.setPayerSecId(hpeEncounterForm.getPayerSecId());
		newEnc837iSubsVO.setPayerCity(hpeEncounterForm.getPayerCity());				
		newEnc837iSubsVO.setPayerState(hpeEncounterForm.getPayerState());				
		newEnc837iSubsVO.setPayerZip(hpeEncounterForm.getPayerZip());
		newEnc837iSubsVO.setPayerCountry(hpeEncounterForm.getPayerCountry());
		newEnc837iSubsVO.setPayerCntrySubdCd(hpeEncounterForm.getPayerCntrySubdCd());
		newEnc837iSubsVO.setBillPrvCommNbr(hpeEncounterForm.getBillPrvCommNbr());
		newEnc837iSubsVO.setBillPrvLocNbr(hpeEncounterForm.getBillPrvLocNbr());
		newEnc837iSubsVO.setPropCasltyClmNbr(hpeEncounterForm.getPropCasltyClmNbr());
		
		Enc837iClmVO newEnc837iClmVO = new Enc837iClmVO(encounterVO.getInstClaim());
		//00370957 - Changes
		newEnc837iClmVO.setClmFreqTypeCd(hpeEncounterForm.getClmFreqTypeCd());
		newEnc837iClmVO.setProcessStatus(hpeEncounterForm.getProcessStatus());
		newEnc837iClmVO.setSubsHicNbr(newEnc837iSubsVO.getSubsHicNbr());
		newEnc837iClmVO.setMbi(newEnc837iSubsVO.getMbi());
		newEnc837iClmVO.setInBillPrvAffilTaxId(newEnc837iBillprvVO.getBillPrvAffilTaxId());
		newEnc837iClmVO.setClmFacTypeCd(hpeEncounterForm.getClmFacTypeCd());
		newEnc837iClmVO.setAdmitType(hpeEncounterForm.getAdmitType());
		newEnc837iClmVO.setAdmitSourceCd(hpeEncounterForm.getAdmitSourceCd());
		newEnc837iClmVO.setAdmitDt(hpeEncounterForm.getAdmitDt());
		newEnc837iClmVO.setAdmitHour(hpeEncounterForm.getAdmitHour());
		newEnc837iClmVO.setPatientStatusCd(hpeEncounterForm.getPatientStatusCd());
		newEnc837iClmVO.setAmbPickupZip(hpeEncounterForm.getAmbPickupZip());
		
		newEnc837iClmVO.setPatientCtrlNbr(hpeEncounterForm.getPatientCtrlNbr());
		newEnc837iClmVO.setContractTypeCd(hpeEncounterForm.getContractTypeCd());
		newEnc837iClmVO.setAdmitDiagType(hpeEncounterForm.getAdmitDiagType());
		newEnc837iClmVO.setContractVersionId(hpeEncounterForm.getContractVersionId());
		newEnc837iClmVO.setAdmitDiagCd(hpeEncounterForm.getAdmitDiagCd());
		newEnc837iClmVO.setContractCd(hpeEncounterForm.getContractCd());
		newEnc837iClmVO.setPrvAcceptAssignCd(hpeEncounterForm.getPrvAcceptAssignCd());
		newEnc837iClmVO.setReleaseOfInfoCd(hpeEncounterForm.getReleaseOfInfoCd());
		newEnc837iClmVO.setAutoAccidentState(hpeEncounterForm.getAutoAccidentState());
		newEnc837iClmVO.setDelayReasonCd(hpeEncounterForm.getDelayReasonCd());
		newEnc837iClmVO.setDischargeHour(hpeEncounterForm.getDischargeHour());
		newEnc837iClmVO.setSvcAuthExcptCd(hpeEncounterForm.getSvcAuthExcptCd());
		newEnc837iClmVO.setStatementFromDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedStatementFromDt()).trim());
		newEnc837iClmVO.setDrgCd(hpeEncounterForm.getDrgCd());
		newEnc837iClmVO.setStatementToDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedStatementToDt()).trim());
		newEnc837iClmVO.setPayerClmCtrlNbr(hpeEncounterForm.getPayerClmCtrlNbr());
		newEnc837iClmVO.setReferralNbr(hpeEncounterForm.getReferralNbr());
		newEnc837iClmVO.setPriorAuthNbr(hpeEncounterForm.getPriorAuthNbr());
		newEnc837iClmVO.setInvestigDeviceExmptId(hpeEncounterForm.getInvestigDeviceExmptId());
		newEnc837iClmVO.setPeerRevewOrgAprvNbr(hpeEncounterForm.getPeerRevewOrgAprvNbr());
		newEnc837iClmVO.setMedicalRecordNbr(hpeEncounterForm.getMedicalRecordNbr());
		newEnc837iClmVO.setDemonstrationProjectId(hpeEncounterForm.getDemonstrationProjectId());
		newEnc837iClmVO.setBillingNotes(hpeEncounterForm.getBillingNotes());
		newEnc837iClmVO.setPatVisitreasType1(hpeEncounterForm.getPatVisitreasType1());
		newEnc837iClmVO.setPatVisitreasCd1(hpeEncounterForm.getPatVisitreasCd1());
		newEnc837iClmVO.setPatVisitreasType2(hpeEncounterForm.getPatVisitreasType2());
		newEnc837iClmVO.setPatVisitreasCd2(hpeEncounterForm.getPatVisitreasCd2());
		newEnc837iClmVO.setPatVisitreasType3(hpeEncounterForm.getPatVisitreasType3());
		newEnc837iClmVO.setPatVisitreasCd3(hpeEncounterForm.getPatVisitreasCd3());
		newEnc837iClmVO.setRepricdClmRefNbr(hpeEncounterForm.getRepricdClmRefNbr());
		newEnc837iClmVO.setAdjRepricdClmRefNbr(hpeEncounterForm.getAdjRepricdClmRefNbr());
		newEnc837iClmVO.setRepricedApprvdDrgCd(hpeEncounterForm.getRepricedApprvdDrgCd());
		newEnc837iClmVO.setRepricedApprvdRevCd(hpeEncounterForm.getRepricedApprvdRevCd());
		newEnc837iClmVO.setRepricerReceivedDt(hpeEncounterForm.getRepricerReceivedDt());
		newEnc837iClmVO.setRepricingOrgId(hpeEncounterForm.getRepricingOrgId());
		newEnc837iClmVO.setRepricedUom(hpeEncounterForm.getRepricedUom());
		newEnc837iClmVO.setRepricedRejReasonCd(hpeEncounterForm.getRepricedRejReasonCd());
		newEnc837iClmVO.setRepricedPolCmpliantCd(hpeEncounterForm.getRepricedPolCmpliantCd());
		newEnc837iClmVO.setRepricedExceptionCd(hpeEncounterForm.getRepricedExceptionCd());
		
		boolean lastAutoCommit = false;
		boolean inTrans = false;

		String msg = "";
			
		try {
			lastAutoCommit = conn.getAutoCommit();
			conn.setAutoCommit(false);
			inTrans = true;

			msg = encounterService.updateInstBillingProvider(conn, encounterVO, newEnc837iBillprvVO, newEnc837iClmVO);
			if (msg.equals("")) {
				msg = encounterService.updateInstSubscriber(conn, encounterVO, newEnc837iSubsVO, newEnc837iClmVO);
				if (msg.equals("")) {
					msg = encounterService.updateInstClaim(conn, encounterVO, newEnc837iClmVO);
					if (msg.equals("")) {
						msg = encounterService.updateInstOtherSubscriberFromSubscriber(conn, encounterVO, newEnc837iSubsVO);
						if (msg.equals("")) {
							Enc837iClmOthsubsVOs enc837iClmOthsubsVOs =  encounterVO.getInstClaimOtherSubscribers();								
							Enc837iClmOthsubsVO oldOthsubsVO;
							String frmOthsubsSeqNbr = hpeEncounterForm.getOthSubsSeqNbr();
							itr = enc837iClmOthsubsVOs.iterator();
							int m = 0;
							while (itr.hasNext()){
								oldOthsubsVO = (Enc837iClmOthsubsVO)itr.next();
								if (oldOthsubsVO != null) {
									String othSubsSeqNbr = String.valueOf(oldOthsubsVO.getOthsubsSeqNbr());
									if (othSubsSeqNbr.equals(frmOthsubsSeqNbr)){
										Enc837iClmOthsubsVO enc837iClmOthsubsVO = new Enc837iClmOthsubsVO(oldOthsubsVO);
										enc837iClmOthsubsVO.setBenefitsAsgnCertInd(hpeEncounterForm.getBenefitsAsgnCertInd());
										enc837iClmOthsubsVO.setCheckRemitDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedCheckRemitDt()));
										enc837iClmOthsubsVO.setIndivRelationshipCd(hpeEncounterForm.getIndivRelationshipCd());
										enc837iClmOthsubsVO.setInsuredGrpOrPolNbr(hpeEncounterForm.getInsuredGrpOrPolNbr());
										enc837iClmOthsubsVO.setMiaClmpmtRemarkCd(hpeEncounterForm.getMiaClmpmtRemarkCd());
										enc837iClmOthsubsVO.setMiaClmPmtRemarkCd1(hpeEncounterForm.getMiaClmPmtRemarkCd1());
										enc837iClmOthsubsVO.setMiaClmPmtRemarkCd2(hpeEncounterForm.getMiaClmPmtRemarkCd2());
										enc837iClmOthsubsVO.setMiaClmPmtRemarkCd3(hpeEncounterForm.getMiaClmPmtRemarkCd3());
										enc837iClmOthsubsVO.setMiaClmPmtRemarkCd4(hpeEncounterForm.getMiaClmPmtRemarkCd4());
										enc837iClmOthsubsVO.setMiaCostDayCnt(hpeEncounterForm.getMiaCostDayCnt());
										enc837iClmOthsubsVO.setMiaCoveredDays(hpeEncounterForm.getMiaCoveredDays());
										enc837iClmOthsubsVO.setMiaLifePsychDayCnt(hpeEncounterForm.getMiaLifePsychDayCnt());
										enc837iClmOthsubsVO.setMoaClmPmtRemarkCd1(hpeEncounterForm.getMoaClmPmtRemarkCd1());
										enc837iClmOthsubsVO.setMoaClmPmtRemarkCd2(hpeEncounterForm.getMoaClmPmtRemarkCd2());
										enc837iClmOthsubsVO.setMoaClmPmtRemarkCd3(hpeEncounterForm.getMoaClmPmtRemarkCd3());
										enc837iClmOthsubsVO.setMoaClmPmtRemarkCd4(hpeEncounterForm.getMoaClmPmtRemarkCd4());
										enc837iClmOthsubsVO.setMoaClmPmtRemarkCd5(hpeEncounterForm.getMoaClmPmtRemarkCd5());
										enc837iClmOthsubsVO.setOtherClmFilingInd(hpeEncounterForm.getOtherClmFilingInd());
										enc837iClmOthsubsVO.setOthPayrAddrLine1(hpeEncounterForm.getOthPayrAddrLine1());
										enc837iClmOthsubsVO.setOthPayrAddrLine2(hpeEncounterForm.getOthPayrAddrLine2());
										enc837iClmOthsubsVO.setOthPayrCity(hpeEncounterForm.getOthPayrCity());
										enc837iClmOthsubsVO.setOthPayrClmadjInd(hpeEncounterForm.getOthPayrClmadjInd());
										enc837iClmOthsubsVO.setOthPayrClmCtrlNbr(hpeEncounterForm.getOthPayrClmCtrlNbr());
										enc837iClmOthsubsVO.setOthPayrCntrySubdCd(hpeEncounterForm.getOthPayrCntrySubdCd());
										enc837iClmOthsubsVO.setOthPayrCountry(hpeEncounterForm.getOthPayrCountry());
										enc837iClmOthsubsVO.setOthPayrLocNbr(hpeEncounterForm.getOthPayrLocNbr());
										enc837iClmOthsubsVO.setOthPayrNaic(hpeEncounterForm.getOthPayrNaic());
										enc837iClmOthsubsVO.setOthPayrOrgName(hpeEncounterForm.getOthPayrOrgName());
										enc837iClmOthsubsVO.setOthPayrPayerId(hpeEncounterForm.getOthSubsPayrPayerId());
										enc837iClmOthsubsVO.setOthPayrPlanId(hpeEncounterForm.getOthPayrPlanId());
										enc837iClmOthsubsVO.setOthPayrPriorAuthNbr(hpeEncounterForm.getOthPayrPriorAuthNbr());
										enc837iClmOthsubsVO.setOthPayrReferralNbr(hpeEncounterForm.getOthPayrReferralNbr());
										enc837iClmOthsubsVO.setOthPayrSecId(hpeEncounterForm.getOthPayrSecId());
										enc837iClmOthsubsVO.setOthPayrState(hpeEncounterForm.getOthPayrState());
										enc837iClmOthsubsVO.setOthPayrZip(hpeEncounterForm.getOthPayrZip());
										enc837iClmOthsubsVO.setOthPayrTaxId(hpeEncounterForm.getFormattedOthPayrTaxId());
										enc837iClmOthsubsVO.setPayerResponseCd(hpeEncounterForm.getPayerResponseCd());
										enc837iClmOthsubsVO.setReleaseMedRcdFlg(hpeEncounterForm.getReleaseMedRcdFlg());
										
										msg = encounterService.updateInstOtherSubscriberFromSubscriber(conn, encounterVO,m, enc837iClmOthsubsVO);
										break;
									}
								}
								m++;
							}	
							if (msg.equals("")) {
								if ("Y".equalsIgnoreCase(hpeEncounterForm.getClmOtherSubsProvExist())){
									Enc837iOthsubsProviderVOs enc837iOthsubsProviderVOs =  encounterVO.getInstClaimOtherSubscriberProviders();		
									Enc837iOthsubsProviderVO oldOthsubsProviderVO;
									String frmOthPayrProvType = hpeEncounterForm.getLookupOthPayrProvType();
									
									itr = enc837iOthsubsProviderVOs.iterator();
									int n = 0;
									while (itr.hasNext()){
										oldOthsubsProviderVO = (Enc837iOthsubsProviderVO)itr.next();
										if (oldOthsubsProviderVO != null) {
											String othPayrProvType = oldOthsubsProviderVO.getProvType();
											if (othPayrProvType.equals(frmOthPayrProvType)){
		
												Enc837iOthsubsProviderVO enc837iOthsubsProviderVO = new Enc837iOthsubsProviderVO(oldOthsubsProviderVO);
												enc837iOthsubsProviderVO.setOthPayrProvCommNbr(hpeEncounterForm.getOthPayrProvCommNbr());
												enc837iOthsubsProviderVO.setOthPayrProvLicNbr(hpeEncounterForm.getOthPayrProvLicNbr());
												enc837iOthsubsProviderVO.setOthPayrProvLocNbr(hpeEncounterForm.getOthPayrProvLocNbr());
												enc837iOthsubsProviderVO.setOthPayrProvUpin(hpeEncounterForm.getOthPayrProvUpin());												
																							
												msg = encounterService.updateInstOthsubsProvider(conn, encounterVO,n,enc837iOthsubsProviderVO);											
												break;
											}
										}
										n++;
									}										
								}
						
								if (msg.equals("")) {
								
									Enc837iClmProviderVOs enc837iClmProviderVOs =  encounterVO.getInstClaimProviders();		
									Enc837iClmProviderVO oldVO;
									String frmProvType = hpeEncounterForm.getProvType();
									itr = enc837iClmProviderVOs.iterator();
									int i = 0;
									while (itr.hasNext()){
										oldVO = (Enc837iClmProviderVO)itr.next();
										if (oldVO != null) {
											String provType = oldVO.getProvType();
											if (provType.equals(frmProvType)){	//IFOX-00418160 - NPI Provider fields update
		
												Enc837iClmProviderVO enc837iClmProviderVO = new Enc837iClmProviderVO(oldVO);
												
												//enc837iClmProviderVO.setProvEntityType(hpeEncounterForm.getProvEntityType());
												if (enc837iClmProviderVO.getEffProvEntityType().equals(HPEConstants.HPE_PROVTYPE_PERSON)) {
													enc837iClmProviderVO.setProvFirstName(hpeEncounterForm.getProvFirstName());
													enc837iClmProviderVO.setProvMiddleName(hpeEncounterForm.getProvMiddleName());
													enc837iClmProviderVO.setProvLastName(hpeEncounterForm.getProvLastName());
												} else {
													enc837iClmProviderVO.setProvFirstName("");
													enc837iClmProviderVO.setProvMiddleName("");
													enc837iClmProviderVO.setProvLastName(hpeEncounterForm.getProvOrgName());										
												}
												enc837iClmProviderVO.setProvAddrLine1(hpeEncounterForm.getProvAddrLine1());
												enc837iClmProviderVO.setProvAddrLine2(hpeEncounterForm.getProvAddrLine2());
												enc837iClmProviderVO.setProvCity(hpeEncounterForm.getProvCity());
												enc837iClmProviderVO.setProvState(hpeEncounterForm.getProvState());
												enc837iClmProviderVO.setProvZip(hpeEncounterForm.getProvZip());
												enc837iClmProviderVO.setProvTaxonomyCd(hpeEncounterForm.getProvTaxonomyCd());//IFOX-00406065
												enc837iClmProviderVO.setProvNpi(hpeEncounterForm.getProvNpi());
												enc837iClmProviderVO.setProvOthPayerId(hpeEncounterForm.getProvOthPayerId());
												enc837iClmProviderVO.setProvLocNbr(hpeEncounterForm.getProvLocNbr());
												enc837iClmProviderVO.setProvLicNbr(hpeEncounterForm.getProvLicNbr());
												enc837iClmProviderVO.setProvUpin(hpeEncounterForm.getProvUpin());								
												enc837iClmProviderVO.setProvCommNbr(hpeEncounterForm.getProvCommNbr());
												//IFOX-00418160 - NPI Provider fields update - Start
												enc837iClmProviderVO.setProvType(provType);
												enc837iClmProviderVO.setProvTypeNew(frmProvType);
												enc837iClmProviderVO.setProvEntityType(hpeEncounterForm.getProvEntityType());
												//IFOX-00418160 - NPI Provider fields update - End
												
												msg = encounterService.updateInstClaimProvider(conn, encounterVO,i,enc837iClmProviderVO);
												break;
											}
										}
										i++;
									}
									if (msg.equals("")) {								
										Enc837iClmlineVOs enc837iClmlineVOs =  encounterVO.getInstClaimLines();
										Enc837iClmlineVO oldClmlineVO;
										
										String frmClmliSeqNbr = hpeEncounterForm.getClmliSeqNbr();
										itr = enc837iClmlineVOs.iterator();
										int j = 0;
										while (itr.hasNext()){
											oldClmlineVO = (Enc837iClmlineVO)itr.next();
											if (oldClmlineVO != null) {
												String clmliSeqNbr = String.valueOf(oldClmlineVO.getClmliSeqNbr());										
												if (clmliSeqNbr.equals(frmClmliSeqNbr)){
		
													Enc837iClmlineVO enc837iClmlineVO = new Enc837iClmlineVO(oldClmlineVO);
													
													enc837iClmlineVO.setLiBeginDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedLiBeginDt()).trim());											
													enc837iClmlineVO.setLiEndDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedLiEndDt()).trim());
													enc837iClmlineVO.setLiProcCd(hpeEncounterForm.getLiProcCd());
													enc837iClmlineVO.setLiProcDesc(hpeEncounterForm.getLiProcDesc());
													enc837iClmlineVO.setLiProcMod1(hpeEncounterForm.getLiProcMod1());
													enc837iClmlineVO.setLiProcMod2(hpeEncounterForm.getLiProcMod2());
													enc837iClmlineVO.setLiProcMod3(hpeEncounterForm.getLiProcMod3());
													enc837iClmlineVO.setLiProcMod4(hpeEncounterForm.getLiProcMod4());
													enc837iClmlineVO.setExceptionCd(hpeEncounterForm.getExceptionCd());
													enc837iClmlineVO.setPricingMethodology(hpeEncounterForm.getPricingMethodology());											
													enc837iClmlineVO.setLiProdSvcidQual(hpeEncounterForm.getLiProdSvcidQual());
													enc837iClmlineVO.setLiUomQual(hpeEncounterForm.getLiUomQual());
													enc837iClmlineVO.setLiServiceUnitCnt(hpeEncounterForm.getLiServiceUnitCnt());
													enc837iClmlineVO.setNationalDrugCdQual(hpeEncounterForm.getNationalDrugCdQual());
													enc837iClmlineVO.setLiRevenueCd(hpeEncounterForm.getLiRevenueCd());
													
													enc837iClmlineVO.setLinkSequenceNbr(hpeEncounterForm.getLinkSequenceNbr());
													enc837iClmlineVO.setPrescriptionNbr(hpeEncounterForm.getPrescriptionNbr());
													enc837iClmlineVO.setLiNote(hpeEncounterForm.getLiNote());
													enc837iClmlineVO.setAdjReprcdLiRefNbr(hpeEncounterForm.getAdjReprcdLiRefNbr());
													enc837iClmlineVO.setApprovedRevenueCd(hpeEncounterForm.getApprovedRevenueCd());
													enc837iClmlineVO.setDrugUnitCnt(hpeEncounterForm.getDrugUnitCnt());
													
													enc837iClmlineVO.setDrugUomQual(hpeEncounterForm.getDrugUomQual());
													enc837iClmlineVO.setNationalDrugCd(hpeEncounterForm.getNationalDrugCd());
													enc837iClmlineVO.setReprcdApprHcpcsCd(hpeEncounterForm.getReprcdApprHcpcsCd());
													enc837iClmlineVO.setRejectReasonCd(hpeEncounterForm.getRejectReasonCd());
													enc837iClmlineVO.setReprcdDrgCd(hpeEncounterForm.getReprcdDrgCd());
													
													enc837iClmlineVO.setReprcdLiRefNbr(hpeEncounterForm.getReprcdLiRefNbr());
													enc837iClmlineVO.setReprcdOrgId(hpeEncounterForm.getReprcdOrgId());
													enc837iClmlineVO.setReprcdSvcUnitCnt(hpeEncounterForm.getReprcdSvcUnitCnt());
													enc837iClmlineVO.setReprcdUomCd(hpeEncounterForm.getReprcdUomCd());
													enc837iClmlineVO.setPolicyComplianceCd(hpeEncounterForm.getPolicyComplianceCd());
													enc837iClmlineVO.setServiceCdQual(hpeEncounterForm.getServiceCdQual());
													
													msg = encounterService.updateInstClmline(conn, encounterVO,j,enc837iClmlineVO);											
													break;
												}
											}
											j++;
										}	
										if (msg.equals("")) {	
											Enc837iClmlineProviderVOs enc837iClmlineProvidersVOs =  encounterVO.getInstClaimLineProviders();
											Enc837iClmlineProviderVO oldClmlineProvidersVO;
											
											String frmLookupProvType = hpeEncounterForm.getLookupProvType();
											itr = enc837iClmlineProvidersVOs.iterator();
											int k = 0;
											while (itr.hasNext()){
												oldClmlineProvidersVO = (Enc837iClmlineProviderVO)itr.next();
												if (oldClmlineProvidersVO != null) {
													String clmliProvType = String.valueOf(oldClmlineProvidersVO.getProvType());
													if (clmliProvType.equals(frmLookupProvType)){
			
														Enc837iClmlineProviderVO enc837iClmlineProviderVO = new Enc837iClmlineProviderVO(oldClmlineProvidersVO);
														
														enc837iClmlineProviderVO.setProvEntityType(hpeEncounterForm.getLiProvEntityType());											
														enc837iClmlineProviderVO.setProvCommNbr(hpeEncounterForm.getLiProvCommNbr());
														enc837iClmlineProviderVO.setProvFirstName(hpeEncounterForm.getLiProvFirstName());
														enc837iClmlineProviderVO.setProvMiddleName(hpeEncounterForm.getLiProvMiddleName());
														enc837iClmlineProviderVO.setProvLastName(hpeEncounterForm.getLiProvLastName());
														enc837iClmlineProviderVO.setProvLicNbr(hpeEncounterForm.getLiProvLicNbr());
														enc837iClmlineProviderVO.setProvLocNbr(hpeEncounterForm.getLiProvLocNbr());
														enc837iClmlineProviderVO.setProvNpi(hpeEncounterForm.getLiProvNpi());
														enc837iClmlineProviderVO.setProvOthPayerId(hpeEncounterForm.getLiProvOthPayerId());
														enc837iClmlineProviderVO.setProvUpin(hpeEncounterForm.getLiProvUpin());
														
																									
														msg = encounterService.updateInstClmlineProv(conn, encounterVO,k,enc837iClmlineProviderVO);											
														break;
													}
												}
												k++;
											}	
										
											if (msg.equals("")) {								
												Enc837iClmlineAdjudVOs enc837iClmlineAdjudVOs =  encounterVO.getInstClaimLineAdjudications();		
												Enc837iClmlineAdjudVO oldClmlineAdjudVO;
												
												String frmClmliAdjudSeqNbr = hpeEncounterForm.getClmliAdjudSeqNbr();
												itr = enc837iClmlineAdjudVOs.iterator();
												int l = 0;
												while (itr.hasNext()){
													oldClmlineAdjudVO = (Enc837iClmlineAdjudVO)itr.next();
													if (oldClmlineAdjudVO != null) {
														String clmliAdjudSeqNbr = String.valueOf(oldClmlineAdjudVO.getClmliAdjudSeqNbr());
														if (clmliAdjudSeqNbr.equals(frmClmliAdjudSeqNbr)){
				
															Enc837iClmlineAdjudVO enc837iClmlineAdjudVO = new Enc837iClmlineAdjudVO(oldClmlineAdjudVO);
															
															enc837iClmlineAdjudVO.setClmliSeqNbr(Integer.parseInt(hpeEncounterForm.getClmliSeqNbr()));		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts
															enc837iClmlineAdjudVO.setOthPayrPayerId(hpeEncounterForm.getOthPayrPayerId());											
															enc837iClmlineAdjudVO.setClmliBundledLineNbr(Integer.parseInt(hpeEncounterForm.getClmliBundledLineNbr()));
															enc837iClmlineAdjudVO.setClmliAdjudRevenueCd(hpeEncounterForm.getClmliAdjudRevenueCd());
															enc837iClmlineAdjudVO.setClmliAdjudProcCd(hpeEncounterForm.getClmliAdjudProcCd());
															enc837iClmlineAdjudVO.setClmliAdjudProcMod1(hpeEncounterForm.getClmliAdjudProcMod1());
															enc837iClmlineAdjudVO.setClmliAdjudProcMod2(hpeEncounterForm.getClmliAdjudProcMod2());
															enc837iClmlineAdjudVO.setClmliAdjudProcMod3(hpeEncounterForm.getClmliAdjudProcMod3());
															enc837iClmlineAdjudVO.setClmliAdjudProcMod4(hpeEncounterForm.getClmliAdjudProcMod4());
															enc837iClmlineAdjudVO.setClmliAdjudProcDesc(hpeEncounterForm.getClmliAdjudProcDesc());
															enc837iClmlineAdjudVO.setProdOrSvcidQual(hpeEncounterForm.getProdOrSvcidQual());
															enc837iClmlineAdjudVO.setAdjudPaymentDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedAdjudPaymentDt()).trim());	
															enc837iClmlineAdjudVO.setClmliPaidSvcUnitCnt(hpeEncounterForm.getClmliPaidSvcUnitCnt());
																										
															msg = encounterService.updateInstClmlineAdjud(conn, encounterVO,l,enc837iClmlineAdjudVO);											
															break;
														}
													}
													l++;
												}	
																									
												if (msg.equals("")) {
													conn.commit();
													inTrans = false;
													
													hpeEncounterForm.setSubscriberDisplayState(HPEConstants.HPE_SCREEN_VIEW);
													hpeEncounterForm.setClaimDisplayState(HPEConstants.HPE_SCREEN_VIEW);
													hpeEncounterForm.setProviderDisplayState(HPEConstants.HPE_SCREEN_VIEW);
													hpeEncounterForm.setClmProviderDisplayState(HPEConstants.HPE_SCREEN_VIEW);										
													hpeEncounterForm.setDataChanged(false);
													hpeEncounterForm.setClmPrvChanged(false);
													
													encounterService.refreshUpdatedInst(conn,encounterVO);
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
			msg = "Error Updating Claim";
		} finally {		
			if (inTrans) {
				try {
					conn.rollback();
				} catch(Exception e) {
				}	
			}
			try {
				conn.setAutoCommit(lastAutoCommit);
			} catch(Exception e) {
			}
		}

		// because the changed fields are not saved
		hpeEncounterForm.setSubscriberDisplayState(HPEConstants.HPE_SCREEN_VIEW);
		hpeEncounterForm.setClaimDisplayState(HPEConstants.HPE_SCREEN_VIEW);
		hpeEncounterForm.setProviderDisplayState(HPEConstants.HPE_SCREEN_VIEW);
		hpeEncounterForm.setClmProviderDisplayState(HPEConstants.HPE_SCREEN_VIEW);		
		hpeEncounterForm.setDataChanged(false);
		hpeEncounterForm.setClmPrvChanged(false);

		if (msg.equals(""))
			msg = "Updated Successfully";
		
		hpeEncounterForm.setDisplayMessage(msg);
		setInstRequest(encounterVO, request);
		
		hpeEncounterForm.setInstSubscriberExpanded(true);
	    hpeEncounterForm.setInstClaimExpanded(true);
	    hpeEncounterForm.setInstProviderExpanded(true);
	    logger.info(LoggerConstants.methodEndLevel());
	}

	public static void updateProfessional(Connection conn, SessionHelper sessionHelper, HPEContext context, HPEEncounterForm hpeEncounterForm, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		HPEEncounterVO encounterVO = context.getEncounterVO();					
		encounterVO.setDisplayMessage("");
		encounterVO.setProfClaimDirty(false);
		encounterVO.setProfSubsDirty(false);
		encounterVO.setProfOthSubsDirty(false);
		encounterVO.setProfOthSubsProvDirty(false);
		
		HPEEncounterService encounterService = context.getEncounterService();

		Enc837pBillprvVO newEnc837pBillprv = new Enc837pBillprvVO(encounterVO.getProfBillingProvider());
		
		newEnc837pBillprv.setBillPrvEntityType(hpeEncounterForm.getBillPrvEntityType());
		if (hpeEncounterForm.getBillPrvEntityType().equals(HPEConstants.HPE_PROVTYPE_PERSON)){							
			newEnc837pBillprv.setBillPrvOrgName(hpeEncounterForm.getBillPrvLastName());							
			newEnc837pBillprv.setBillPrvFirstName(hpeEncounterForm.getBillPrvFirstName());
			newEnc837pBillprv.setBillPrvMiddleName(hpeEncounterForm.getBillPrvMiddleName());
		} else {						
			newEnc837pBillprv.setBillPrvOrgName(hpeEncounterForm.getBillPrvOrgName());
			newEnc837pBillprv.setBillPrvFirstName("");
			newEnc837pBillprv.setBillPrvMiddleName("");
		}						
		newEnc837pBillprv.setBillPrvAddrLine1(hpeEncounterForm.getBillPrvAddrLine1());
		newEnc837pBillprv.setBillPrvAddrLine2(hpeEncounterForm.getBillPrvAddrLine2());
		newEnc837pBillprv.setBillPrvCity(hpeEncounterForm.getBillPrvCity());
		newEnc837pBillprv.setBillPrvState(hpeEncounterForm.getBillPrvState());
		newEnc837pBillprv.setBillPrvZip(hpeEncounterForm.getBillPrvZip());	
		newEnc837pBillprv.setBillPrvCountry(hpeEncounterForm.getBillPrvCountry());
		newEnc837pBillprv.setBillPrvCntrySubdCd(hpeEncounterForm.getBillPrvCntrySubdCd());
		newEnc837pBillprv.setBillPrvTaxonomyCd(hpeEncounterForm.getBillPrvTaxonomyCd());
		
		newEnc837pBillprv.setBillPrvNpi(hpeEncounterForm.getBillPrvNpi());
		newEnc837pBillprv.setBillPrvLicNbr(hpeEncounterForm.getBillPrvLicNbr());
		newEnc837pBillprv.setBillPrvUpin(hpeEncounterForm.getBillPrvUpin());
		newEnc837pBillprv.setFormattedBillPrvSsn(hpeEncounterForm.getFormattedBillPrvSsn());
		newEnc837pBillprv.setFormattedBillPrvAffilTaxId(hpeEncounterForm.getFormattedBillPrvAffilTaxId());
		newEnc837pBillprv.setBillPrvComNbrQual1(hpeEncounterForm.getBillPrvComNbrQual1());
		newEnc837pBillprv.setBillPrvComNbrQual2(hpeEncounterForm.getBillPrvComNbrQual2());
		newEnc837pBillprv.setBillPrvComNbrQual3(hpeEncounterForm.getBillPrvComNbrQual3());
		newEnc837pBillprv.setBillPrvComNbr1(hpeEncounterForm.getBillPrvComNbr1());
		newEnc837pBillprv.setBillPrvComNbr2(hpeEncounterForm.getBillPrvComNbr2());
		newEnc837pBillprv.setBillPrvComNbr3(hpeEncounterForm.getBillPrvComNbr3());
		
		newEnc837pBillprv.setP2prvAddrLine1(hpeEncounterForm.getP2prvAddrLine1());
		newEnc837pBillprv.setP2prvAddrLine2(hpeEncounterForm.getP2prvAddrLine2());
		newEnc837pBillprv.setP2prvCity(hpeEncounterForm.getP2prvCity());
		newEnc837pBillprv.setP2prvState(hpeEncounterForm.getP2prvState());
		newEnc837pBillprv.setP2prvZip(hpeEncounterForm.getP2prvZip());
		newEnc837pBillprv.setP2prvEntityType(hpeEncounterForm.getP2prvEntityType());
		newEnc837pBillprv.setP2prvCountry(hpeEncounterForm.getP2prvCountry());
		newEnc837pBillprv.setP2prvCntrySubdCd(hpeEncounterForm.getP2prvCntrySubdCd());
				
		newEnc837pBillprv.setP2pOrgName(hpeEncounterForm.getP2pOrgName());
		newEnc837pBillprv.setP2pPrimPayerId(hpeEncounterForm.getP2pPrimPayerId());
		newEnc837pBillprv.setP2pLocNbr(hpeEncounterForm.getP2pLocNbr());
		newEnc837pBillprv.setP2pAddrLine1(hpeEncounterForm.getP2pAddrLine1());
		newEnc837pBillprv.setP2pPayerIdNbr(hpeEncounterForm.getP2pPayerIdNbr());
		newEnc837pBillprv.setP2pNaicCd(hpeEncounterForm.getP2pNaicCd());
		newEnc837pBillprv.setP2pAddrLine2(hpeEncounterForm.getP2pAddrLine2());
		newEnc837pBillprv.setP2pPrimPlanId(hpeEncounterForm.getP2pPrimPlanId());
		newEnc837pBillprv.setP2pTaxId(hpeEncounterForm.getP2pTaxId());
		newEnc837pBillprv.setP2pCity(hpeEncounterForm.getP2pCity());
		newEnc837pBillprv.setP2pState(hpeEncounterForm.getP2pState());
		newEnc837pBillprv.setP2pZip(hpeEncounterForm.getP2pZip());
		newEnc837pBillprv.setP2pCountry(hpeEncounterForm.getP2pCountry());
		newEnc837pBillprv.setP2pCntrySubdCd(hpeEncounterForm.getP2pCntrySubdCd());		
		
		Enc837pSubsVO newEnc837pSubs = new Enc837pSubsVO(encounterVO.getProfSubscriber());	

		newEnc837pSubs.setSubsFirstName(hpeEncounterForm.getSubsFirstName());
		newEnc837pSubs.setSubsMiddleName(hpeEncounterForm.getSubsMiddleName());
		newEnc837pSubs.setSubsLastName(hpeEncounterForm.getSubsLastName());								
		newEnc837pSubs.setBillPrvAffilTaxId(newEnc837pBillprv.getBillPrvAffilTaxId());
		newEnc837pSubs.setSubsHicNbr(hpeEncounterForm.getSubsHicNbr());
		newEnc837pSubs.setMbi(hpeEncounterForm.getMbi());
		newEnc837pSubs.setSubsSsn(DemographicFormatter.unFormatSSN(hpeEncounterForm.getFormattedSubsSsn()));								
		newEnc837pSubs.setSubsDob(DateFormatter.reFormat(hpeEncounterForm.getFormattedSubsDob(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
		newEnc837pSubs.setSubsSex(hpeEncounterForm.getSubsSex());	
		newEnc837pSubs.setSubsAddrLine1(hpeEncounterForm.getSubsAddrLine1());
		newEnc837pSubs.setSubsAddrLine2(hpeEncounterForm.getSubsAddrLine2());
		newEnc837pSubs.setSubsCity(hpeEncounterForm.getSubsCity());				
		newEnc837pSubs.setSubsState(hpeEncounterForm.getSubsState());				
		newEnc837pSubs.setSubsZip(hpeEncounterForm.getSubsZip());
		newEnc837pSubs.setSubsPayerSeqCd(hpeEncounterForm.getSubsPayerSeqCd());
		newEnc837pSubs.setSubsRelationCd(hpeEncounterForm.getSubsRelationCd());
		newEnc837pSubs.setSubsFilingIndCd(hpeEncounterForm.getSubsFilingIndCd());
		newEnc837pSubs.setSubsInsuranceTypeCd(hpeEncounterForm.getSubsInsuranceTypeCd());		
		newEnc837pSubs.setSubsEntityType(hpeEncounterForm.getSubsEntityType());
		newEnc837pSubs.setSubsMemberId(hpeEncounterForm.getSubsMemberId());
		newEnc837pSubs.setSubsCountry(hpeEncounterForm.getSubsCountry());
		newEnc837pSubs.setSubsCntrySubdCd(hpeEncounterForm.getSubsCntrySubdCd());
		newEnc837pSubs.setSubsGrpOrPolNbr(hpeEncounterForm.getSubsGrpOrPolNbr());
		newEnc837pSubs.setSubsPlanName(hpeEncounterForm.getSubsPlanName());
		newEnc837pSubs.setSubsPatDod(hpeEncounterForm.getSubsPatDod());
		newEnc837pSubs.setSubsPatWeight(hpeEncounterForm.getSubsPatWeight());
		newEnc837pSubs.setSubsPatUom(hpeEncounterForm.getSubsPatUom());
		newEnc837pSubs.setSubsPatPregnantInd(hpeEncounterForm.getSubsPatPregnantInd());
		newEnc837pSubs.setPayerName(hpeEncounterForm.getPayerName());
		newEnc837pSubs.setPayerId(hpeEncounterForm.getPayerId());
		newEnc837pSubs.setPayerPlanId(hpeEncounterForm.getPayerPlanId());
		newEnc837pSubs.setPayerAddrLine1(hpeEncounterForm.getPayerAddrLine1());
		newEnc837pSubs.setPayerAddrLine2(hpeEncounterForm.getPayerAddrLine2());
		newEnc837pSubs.setPayerCity(hpeEncounterForm.getPayerCity());
		newEnc837pSubs.setPayerState(hpeEncounterForm.getPayerState());
		newEnc837pSubs.setPayerZip(hpeEncounterForm.getPayerZip());
		newEnc837pSubs.setPayerCountry(hpeEncounterForm.getPayerCountry());
		newEnc837pSubs.setPayerCntrySubdCd(hpeEncounterForm.getPayerCntrySubdCd());
		newEnc837pSubs.setPayerTaxId(hpeEncounterForm.getPayerTaxId());
		newEnc837pSubs.setPayerLocNbr(hpeEncounterForm.getPayerLocNbr());
		newEnc837pSubs.setPayerNaicCd(hpeEncounterForm.getPayerNaicCd());
		newEnc837pSubs.setPayerSecId(hpeEncounterForm.getPayerSecId());		
		
		newEnc837pSubs.setBillPrvCommNbr(hpeEncounterForm.getBillPrvCommNbr());
		newEnc837pSubs.setBillPrvLocNbr(hpeEncounterForm.getBillPrvLocNbr());
		newEnc837pSubs.setPropCasltyClmNbr(hpeEncounterForm.getPropCasltyClmNbr());
		newEnc837pSubs.setPropCasltySubsName(hpeEncounterForm.getPropCasltySubsName());
		newEnc837pSubs.setPropCasltySubsPhone(hpeEncounterForm.getPropCasltySubsPhone());
		newEnc837pSubs.setPropCasltySubsPhnExt(hpeEncounterForm.getPropCasltySubsPhnExt());	

		Enc837pClmVO newEnc837pClmVO = new Enc837pClmVO(encounterVO.getProfClaim());
		newEnc837pClmVO.setProcessStatus(hpeEncounterForm.getProcessStatus());
		newEnc837pClmVO.setPlaceOfService(hpeEncounterForm.getPlaceOfService());
		newEnc837pClmVO.setSubsHicNbr(newEnc837pSubs.getSubsHicNbr());
		newEnc837pClmVO.setMbi(newEnc837pSubs.getMbi());
		newEnc837pClmVO.setInBillPrvAffilTaxId(newEnc837pBillprv.getBillPrvAffilTaxId());
		newEnc837pClmVO.setMammogramCertNbr(hpeEncounterForm.getMammogramCertNbr());
		newEnc837pClmVO.setCliaNbr(hpeEncounterForm.getCliaNbr());
		newEnc837pClmVO.setHospAdmitDt(hpeEncounterForm.getHospAdmitDt());
		newEnc837pClmVO.setHospDischargeDt(hpeEncounterForm.getHospDischargeDt());
		newEnc837pClmVO.setCliaNbr(hpeEncounterForm.getCliaNbr());
		newEnc837pClmVO.setAmbPickupAddrLine1(hpeEncounterForm.getAmbPickupAddrLine1());
		newEnc837pClmVO.setAmbPickupAddrLine2(hpeEncounterForm.getAmbPickupAddrLine2());
		newEnc837pClmVO.setAmbPickupCity(hpeEncounterForm.getAmbPickupCity());
		newEnc837pClmVO.setAmbPickupState(hpeEncounterForm.getAmbPickupState());
		newEnc837pClmVO.setAmbPickupZip(hpeEncounterForm.getAmbPickupZip());
		newEnc837pClmVO.setAmbDropoffLoc(hpeEncounterForm.getAmbDropoffLoc());
		newEnc837pClmVO.setAmbDropoffAddrLine1(hpeEncounterForm.getAmbDropoffAddrLine1());
		newEnc837pClmVO.setAmbDropoffAddrLine2(hpeEncounterForm.getAmbDropoffAddrLine2());
		newEnc837pClmVO.setAmbDropoffCity(hpeEncounterForm.getAmbDropoffCity());
		newEnc837pClmVO.setAmbDropoffState(hpeEncounterForm.getAmbDropoffState());
		newEnc837pClmVO.setAmbDropoffZip(hpeEncounterForm.getAmbDropoffZip());
		
		//Setting new Feids for Claims...
		newEnc837pClmVO.setPatientCtrlNbr(hpeEncounterForm.getPatientCtrlNbr());
		//newEnc837pClmVO.setWtxClaimRefNbr(hpeEncounterForm.getWtxClaimRefNbr());
		newEnc837pClmVO.setContractVersionId(hpeEncounterForm.getContractVersionId());
		newEnc837pClmVO.setContractCd(hpeEncounterForm.getContractCd());
		newEnc837pClmVO.setSvcFacContactName(hpeEncounterForm.getSvcFacContactName());
		newEnc837pClmVO.setSvcFacPhone(hpeEncounterForm.getSvcFacPhone());
		newEnc837pClmVO.setSvcFacPhoneExt(hpeEncounterForm.getSvcFacPhoneExt());
		newEnc837pClmVO.setSvcAuthExcptCd(hpeEncounterForm.getSvcAuthExcptCd());
		newEnc837pClmVO.setAnestSurgProcCd1(hpeEncounterForm.getAnestSurgProcCd1());
		newEnc837pClmVO.setAnestSurgProcCd2(hpeEncounterForm.getAnestSurgProcCd2());
		newEnc837pClmVO.setVisnCertCondInd(hpeEncounterForm.getVisnCertCondInd());
		newEnc837pClmVO.setAutoAccidentCountry(hpeEncounterForm.getAutoAccidentCountry());
		newEnc837pClmVO.setClaimRefCd(hpeEncounterForm.getClaimRefCd());
		newEnc837pClmVO.setPatSignatureSrcCd(hpeEncounterForm.getPatSignatureSrcCd());
		newEnc837pClmVO.setMedicareCrossoverCd(hpeEncounterForm.getMedicareCrossoverCd());
		newEnc837pClmVO.setLabHomeRespCd(hpeEncounterForm.getLabHomeRespCd());
		newEnc837pClmVO.setLabHomeCondInd(hpeEncounterForm.getLabHomeCondInd());
		newEnc837pClmVO.setVisnCodeCategory(hpeEncounterForm.getVisnCodeCategory());
		newEnc837pClmVO.setContractTypeCd(hpeEncounterForm.getContractTypeCd());
		newEnc837pClmVO.setPrvAcceptAssignCd(hpeEncounterForm.getPrvAcceptAssignCd());
		newEnc837pClmVO.setReleaseOfInfoCd(hpeEncounterForm.getReleaseOfInfoCd());
		newEnc837pClmVO.setAutoAccidentState(hpeEncounterForm.getAutoAccidentState());
		newEnc837pClmVO.setOtherAccidentInd(hpeEncounterForm.getOtherAccidentInd());
		newEnc837pClmVO.setPrvSignatureOnfileInd(hpeEncounterForm.getPrvSignatureOnfileInd());
		newEnc837pClmVO.setDelayReasonCd(hpeEncounterForm.getDelayReasonCd());
		newEnc837pClmVO.setBeneAssignCertInd(hpeEncounterForm.getBeneAssignCertInd());
		newEnc837pClmVO.setVisnCertCondCd1(hpeEncounterForm.getVisnCertCondCd1());
		newEnc837pClmVO.setVisnCertCondCd2(hpeEncounterForm.getVisnCertCondCd2());
		newEnc837pClmVO.setVisnCertCondCd3(hpeEncounterForm.getVisnCertCondCd3());
		newEnc837pClmVO.setWtxClaimRevNbr(hpeEncounterForm.getWtxClaimRevNbr());
		newEnc837pClmVO.setClmFreqTypeCd(hpeEncounterForm.getClmFreqTypeCd());
		newEnc837pClmVO.setEmploymentAccidentInd(hpeEncounterForm.getEmploymentAccidentInd());
		newEnc837pClmVO.setAutoAccidentInd(hpeEncounterForm.getAutoAccidentInd());
		newEnc837pClmVO.setEpsdtCondInd1(hpeEncounterForm.getEpsdtCondInd1());
		newEnc837pClmVO.setEpsdtCondInd2(hpeEncounterForm.getEpsdtCondInd2());
		newEnc837pClmVO.setEpsdtCondInd3(hpeEncounterForm.getEpsdtCondInd3());
		newEnc837pClmVO.setVisnCertCondCd4(hpeEncounterForm.getVisnCertCondCd4());
		newEnc837pClmVO.setVisnCertCondCd5(hpeEncounterForm.getVisnCertCondCd5());
		newEnc837pClmVO.setPayerClmCtrlNbr(hpeEncounterForm.getPayerClmCtrlNbr());
		newEnc837pClmVO.setPriorAuthNbr(hpeEncounterForm.getPriorAuthNbr());
		newEnc837pClmVO.setValueAddNtwkTraceNbr(hpeEncounterForm.getValueAddNtwkTraceNbr());
		newEnc837pClmVO.setCarePlanOversightNbr(hpeEncounterForm.getCarePlanOversightNbr());
		newEnc837pClmVO.setClaimNotes(hpeEncounterForm.getClaimNotes());
		newEnc837pClmVO.setReferralNbr(hpeEncounterForm.getReferralNbr());
		newEnc837pClmVO.setInvestigDeviceExempId(hpeEncounterForm.getInvestigDeviceExempId());
		newEnc837pClmVO.setMedicalRecordNbr(hpeEncounterForm.getMedicalRecordNbr());
		newEnc837pClmVO.setDemonstrationProjId(hpeEncounterForm.getDemonstrationProjId());
		newEnc837pClmVO.setIllnessOccurDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedIllnessOccurDt()).trim());
		newEnc837pClmVO.setLastMenstrualPerDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedLastMenstrualPerDt()).trim());
		newEnc837pClmVO.setDisabilityStartDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedDisabilityStartDt()).trim());
		newEnc837pClmVO.setAsumdCareStartDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedAsumdCareStartDt()).trim());
		newEnc837pClmVO.setPatientCondCd(hpeEncounterForm.getPatientCondCd());
		newEnc837pClmVO.setInitialTreatmentDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedInitialTreatmentDt()).trim());
		newEnc837pClmVO.setLastXrayDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedLastXrayDt()).trim());
		newEnc837pClmVO.setDisabilityEndDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedDisabilityEndDt()).trim());
		newEnc837pClmVO.setAsumdCareEndDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedAsumdCareEndDt()).trim());
		newEnc837pClmVO.setLastSeenDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedLastSeenDt()).trim());
		newEnc837pClmVO.setHearVisionDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedHearVisionDt()).trim());
		newEnc837pClmVO.setLastWorkedDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedLastWorkedDt()).trim());
		newEnc837pClmVO.setFirstVisitConsultDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedFirstVisitConsultDt()).trim());
		newEnc837pClmVO.setAcuteManifestationDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedAcuteManifestationDt()).trim());
		newEnc837pClmVO.setAuthReturnWorkDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedAuthReturnWorkDt()).trim());
		newEnc837pClmVO.setAccidentDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedAccidentDt()).trim());
		newEnc837pClmVO.setRoundTripPurposeDesc(hpeEncounterForm.getRoundTripPurposeDesc());
		newEnc837pClmVO.setStretcherPurposeDesc(hpeEncounterForm.getStretcherPurposeDesc());
		newEnc837pClmVO.setAmbPatWeight(hpeEncounterForm.getAmbPatWeight());
		newEnc837pClmVO.setAmbCertCondInd(hpeEncounterForm.getAmbCertCondInd());
		newEnc837pClmVO.setAmbPickupCountry(hpeEncounterForm.getAmbPickupCountry());
		newEnc837pClmVO.setAmbCertCondCd1(hpeEncounterForm.getAmbCertCondCd1());
		newEnc837pClmVO.setAmbCertCondCd2(hpeEncounterForm.getAmbCertCondCd2());
		newEnc837pClmVO.setAmbCertCondCd3(hpeEncounterForm.getAmbCertCondCd3());
		newEnc837pClmVO.setAmbDropoffCountry(hpeEncounterForm.getAmbDropoffCountry());
		newEnc837pClmVO.setAmbTranspDistance(hpeEncounterForm.getAmbTranspDistance());
		newEnc837pClmVO.setAmbTranspReasonCd(hpeEncounterForm.getAmbTranspReasonCd());
		newEnc837pClmVO.setAmbPickupCntrySubd(hpeEncounterForm.getAmbPickupCntrySubd());
		newEnc837pClmVO.setAmbCertCondCd4(hpeEncounterForm.getAmbCertCondCd4());
		newEnc837pClmVO.setAmbCertCondCd5(hpeEncounterForm.getAmbCertCondCd5());
		newEnc837pClmVO.setAmbDropoffCntrySubd(hpeEncounterForm.getAmbDropoffCntrySubd());
		//end of setting new Feilds for Calims...
		
		boolean lastAutoCommit = false;
		boolean inTrans = false;
		Iterator itr = null;

		String msg = "";
		
		try {
			lastAutoCommit = conn.getAutoCommit();
			conn.setAutoCommit(false);
			inTrans = true;

			msg = encounterService.updateProfBillingProvider(conn, encounterVO, newEnc837pBillprv, newEnc837pClmVO);
			if (msg.equals("")) {
				msg = encounterService.updateProfSubscriber(conn, encounterVO, newEnc837pSubs, newEnc837pClmVO);
				if (msg.equals("")) {
					msg = encounterService.updateProfClaim(conn, encounterVO, newEnc837pClmVO);
					if (msg.equals("")) {
						msg = encounterService.updateProfOtherSubscriberFromSubscriber(conn, encounterVO, newEnc837pSubs);
						if (msg.equals("")) {
							Enc837pClmOthsubsVOs enc837pClmOthsubsVOs =  encounterVO.getProfClaimOtherSubscribers();								
							Enc837pClmOthsubsVO oldOthsubsVO;
							String frmOthsubsSeqNbr = hpeEncounterForm.getOthSubsSeqNbr();
							itr = enc837pClmOthsubsVOs.iterator();
							int m = 0;
							while (itr.hasNext()){
								oldOthsubsVO = (Enc837pClmOthsubsVO)itr.next();
								if (oldOthsubsVO != null) {
									String othSubsSeqNbr = String.valueOf(oldOthsubsVO.getOthsubsSeqNbr());
									if (othSubsSeqNbr.equals(frmOthsubsSeqNbr)){
										Enc837pClmOthsubsVO enc837pClmOthsubsVO = new Enc837pClmOthsubsVO(oldOthsubsVO);
										enc837pClmOthsubsVO.setBenefitsAsgnCertInd(hpeEncounterForm.getBenefitsAsgnCertInd());
										enc837pClmOthsubsVO.setCheckRemitDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedCheckRemitDt()).trim());
										enc837pClmOthsubsVO.setIndivRelationshipCd(hpeEncounterForm.getIndivRelationshipCd());
										enc837pClmOthsubsVO.setInsuredGrpOrPolNbr(hpeEncounterForm.getInsuredGrpOrPolNbr());										
										enc837pClmOthsubsVO.setMoaClmPmtRemarkCd1(hpeEncounterForm.getMoaClmPmtRemarkCd1().trim());
										enc837pClmOthsubsVO.setMoaClmPmtRemarkCd2(hpeEncounterForm.getMoaClmPmtRemarkCd2().trim());
										enc837pClmOthsubsVO.setMoaClmPmtRemarkCd3(hpeEncounterForm.getMoaClmPmtRemarkCd3().trim());
										enc837pClmOthsubsVO.setMoaClmPmtRemarkCd4(hpeEncounterForm.getMoaClmPmtRemarkCd4().trim());
										enc837pClmOthsubsVO.setMoaClmPmtRemarkCd5(hpeEncounterForm.getMoaClmPmtRemarkCd5().trim());
										enc837pClmOthsubsVO.setOtherClmFilingInd(hpeEncounterForm.getOtherClmFilingInd());
										enc837pClmOthsubsVO.setOthPayrAddrLine1(hpeEncounterForm.getOthPayrAddrLine1());
										enc837pClmOthsubsVO.setOthPayrAddrLine2(hpeEncounterForm.getOthPayrAddrLine2());
										enc837pClmOthsubsVO.setOthPayrCity(hpeEncounterForm.getOthPayrCity());
										enc837pClmOthsubsVO.setOthPayrClmadjInd(hpeEncounterForm.getOthPayrClmadjInd());
										enc837pClmOthsubsVO.setOthPayrClmCtrlNbr(hpeEncounterForm.getOthPayrClmCtrlNbr());
										enc837pClmOthsubsVO.setOthPayrCntrySubdCd(hpeEncounterForm.getOthPayrCntrySubdCd());
										enc837pClmOthsubsVO.setOthPayrCountry(hpeEncounterForm.getOthPayrCountry());
										enc837pClmOthsubsVO.setOthPayrLocNbr(hpeEncounterForm.getOthPayrLocNbr());
										enc837pClmOthsubsVO.setOthPayrNaic(hpeEncounterForm.getOthPayrNaic());
										enc837pClmOthsubsVO.setOthPayrOrgName(hpeEncounterForm.getOthPayrOrgName());
										enc837pClmOthsubsVO.setOthPayrPayerId(hpeEncounterForm.getOthSubsPayrPayerId());
										enc837pClmOthsubsVO.setOthPayrPlanId(hpeEncounterForm.getOthPayrPlanId());
										enc837pClmOthsubsVO.setOthPayrPriorAuthNbr(hpeEncounterForm.getOthPayrPriorAuthNbr());
										enc837pClmOthsubsVO.setOthPayrReferralNbr(hpeEncounterForm.getOthPayrReferralNbr());
										enc837pClmOthsubsVO.setOthPayrSecId(hpeEncounterForm.getOthPayrSecId());
										enc837pClmOthsubsVO.setOthPayrState(hpeEncounterForm.getOthPayrState());
										enc837pClmOthsubsVO.setOthPayrZip(hpeEncounterForm.getOthPayrZip());
										enc837pClmOthsubsVO.setOthPayrTaxId(hpeEncounterForm.getFormattedOthPayrTaxId());
										enc837pClmOthsubsVO.setPayerResponseCd(hpeEncounterForm.getPayerResponseCd());
										enc837pClmOthsubsVO.setReleaseMedRcdFlg(hpeEncounterForm.getReleaseMedRcdFlg());
										enc837pClmOthsubsVO.setPatSignSrcCd(hpeEncounterForm.getPatSignSrcCd());
										
										msg = encounterService.updateProfOtherSubscriberFromSubscriber(conn, encounterVO,m, enc837pClmOthsubsVO);
										break;
									}
								}
								m++;
							}	
							if (msg.equals("")) {
								if ("Y".equalsIgnoreCase(hpeEncounterForm.getClmOtherSubsProvExist())){
									Enc837pOthsubsProviderVOs enc837pOthsubsProviderVOs =  encounterVO.getProfClaimOtherSubscriberProviders();		
									Enc837pOthsubsProviderVO oldOthsubsProviderVO;
									String frmOthPayrProvType = hpeEncounterForm.getLookupOthPayrProvType();
									
									itr = enc837pOthsubsProviderVOs.iterator();
									int n = 0;
									while (itr.hasNext()){
										oldOthsubsProviderVO = (Enc837pOthsubsProviderVO)itr.next();
										if (oldOthsubsProviderVO != null) {
											String othPayrProvType = oldOthsubsProviderVO.getProvType();
											if (othPayrProvType.equals(frmOthPayrProvType)){
		
												Enc837pOthsubsProviderVO enc837pOthsubsProviderVO = new Enc837pOthsubsProviderVO(oldOthsubsProviderVO);
												enc837pOthsubsProviderVO.setOthPayrProvCommNbr(hpeEncounterForm.getOthPayrProvCommNbr());
												enc837pOthsubsProviderVO.setOthPayrProvLicNbr(hpeEncounterForm.getOthPayrProvLicNbr());
												enc837pOthsubsProviderVO.setOthPayrProvLocNbr(hpeEncounterForm.getOthPayrProvLocNbr());
												enc837pOthsubsProviderVO.setOthPayrProvUpin(hpeEncounterForm.getOthPayrProvUpin());
												enc837pOthsubsProviderVO.setOthPayrProvEntityType(hpeEncounterForm.getOthPayrProvEntityType());
																							
												msg = encounterService.updateProfOthsubsProvider(conn, encounterVO,n,enc837pOthsubsProviderVO);											
												break;
											}
										}
										n++;
									}										
								}
								if (msg.equals("")) {
									Enc837pClmProviderVOs enc837pClmProviderVOs =  encounterVO.getProfClaimProviders();
									String frmProvType = hpeEncounterForm.getProvType();
									Enc837pClmProviderVO oldVO;
									itr = enc837pClmProviderVOs.iterator();
									int i = 0;
									while (itr.hasNext()){
										oldVO = (Enc837pClmProviderVO)itr.next();
										if (oldVO != null) {
											String provType = oldVO.getProvType();
											if (provType.equals(frmProvType)){	//IFOX-00418160 - NPI Provider fields update
												
												Enc837pClmProviderVO enc837pClmProviderVO = new Enc837pClmProviderVO(oldVO);
		
												enc837pClmProviderVO.setProvEntityType(StringUtil.nonNullTrim(hpeEncounterForm.getProvEntityType()));
												if (enc837pClmProviderVO.getEffProvEntityType().equals(HPEConstants.HPE_PROVTYPE_PERSON)) {
													enc837pClmProviderVO.setProvFirstName(hpeEncounterForm.getProvFirstName());
													enc837pClmProviderVO.setProvMiddleName(hpeEncounterForm.getProvMiddleName());
													enc837pClmProviderVO.setProvLastName(hpeEncounterForm.getProvLastName());
												} else {
													enc837pClmProviderVO.setProvFirstName("");
													enc837pClmProviderVO.setProvMiddleName("");
													enc837pClmProviderVO.setProvLastName(hpeEncounterForm.getProvOrgName());										
												}
		
												enc837pClmProviderVO.setProvAddrLine1(hpeEncounterForm.getProvAddrLine1());
												enc837pClmProviderVO.setProvAddrLine2(hpeEncounterForm.getProvAddrLine2());
												enc837pClmProviderVO.setProvCity(hpeEncounterForm.getProvCity());
												enc837pClmProviderVO.setProvState(hpeEncounterForm.getProvState());
												enc837pClmProviderVO.setProvZip(hpeEncounterForm.getProvZip());
												enc837pClmProviderVO.setProvTaxonomyCd(hpeEncounterForm.getProvTaxonomyCd());
												enc837pClmProviderVO.setProvNpi(hpeEncounterForm.getProvNpi());
												enc837pClmProviderVO.setProvOthPayerId(hpeEncounterForm.getProvOthPayerId());
												enc837pClmProviderVO.setProvLocNbr(hpeEncounterForm.getProvLocNbr());
												enc837pClmProviderVO.setProvLicNbr(hpeEncounterForm.getProvLicNbr());
												enc837pClmProviderVO.setProvUpin(hpeEncounterForm.getProvUpin());								
												enc837pClmProviderVO.setProvCommNbr(hpeEncounterForm.getProvCommNbr());
												//IFOX-00418160 - NPI Provider fields update - Start
												enc837pClmProviderVO.setProvType(provType);
												enc837pClmProviderVO.setProvTypeNew(frmProvType);
												enc837pClmProviderVO.setProvEntityType(hpeEncounterForm.getProvEntityType());
												//IFOX-00418160 - NPI Provider fields update - End
												
												msg = encounterService.updateProfClaimProvider(conn, encounterVO,i,enc837pClmProviderVO);
												break;
		
											}
										}
										i++;
									}
									if (msg.equals("")) {								
										Enc837pClmlineVOs enc837pClmlineVOs =  encounterVO.getProfClaimLines();
										Enc837pClmlineVO oldClmlineVO;
										
										String frmClmliSeqNbr = hpeEncounterForm.getClmliSeqNbr();
										itr = enc837pClmlineVOs.iterator();
										int j = 0;
										while (itr.hasNext()){
											oldClmlineVO = (Enc837pClmlineVO)itr.next();
											if (oldClmlineVO != null) {
												String clmliSeqNbr = String.valueOf(oldClmlineVO.getClmliSeqNbr());										
												if (clmliSeqNbr.equals(frmClmliSeqNbr)){
		
													Enc837pClmlineVO enc837pClmlineVO = new Enc837pClmlineVO(oldClmlineVO);
													
													enc837pClmlineVO.setLiProcCd(StringUtil.nonNullTrim(hpeEncounterForm.getLiProcCd()));
													enc837pClmlineVO.setLiProcDesc(StringUtil.nonNullTrim(hpeEncounterForm.getLiProcDesc()));
													enc837pClmlineVO.setLiProcMod1(StringUtil.nonNullTrim(hpeEncounterForm.getLiProcMod1()));
													enc837pClmlineVO.setLiProcMod2(StringUtil.nonNullTrim(hpeEncounterForm.getLiProcMod2()));
													enc837pClmlineVO.setLiProcMod3(StringUtil.nonNullTrim(hpeEncounterForm.getLiProcMod3()));
													enc837pClmlineVO.setLiProcMod4(StringUtil.nonNullTrim(hpeEncounterForm.getLiProcMod4()));
													enc837pClmlineVO.setExceptionCd(StringUtil.nonNullTrim(hpeEncounterForm.getExceptionCd()));
													enc837pClmlineVO.setPricingMethodology(StringUtil.nonNullTrim(hpeEncounterForm.getPricingMethodology()));
													enc837pClmlineVO.setLiProdSvcidQual(StringUtil.nonNullTrim(hpeEncounterForm.getLiProdSvcidQual()));											
													enc837pClmlineVO.setLiUomQual(StringUtil.nonNullTrim(hpeEncounterForm.getLiUomQual()));
													enc837pClmlineVO.setLiServiceUnitCnt(hpeEncounterForm.getLiServiceUnitCnt());													
													enc837pClmlineVO.setNationalDrugCdQual(StringUtil.nonNullTrim(hpeEncounterForm.getNationalDrugCdQual()));													
													enc837pClmlineVO.setDmeCertTypeCd(StringUtil.nonNullTrim(hpeEncounterForm.getDmeCertTypeCd()));	
													enc837pClmlineVO.setDmeAttachTransmitCd(StringUtil.nonNullTrim(hpeEncounterForm.getDmeAttachTransmitCd()));
													enc837pClmlineVO.setDmeCertCondInd(StringUtil.nonNullTrim(hpeEncounterForm.getDmeCertCondInd()));
													enc837pClmlineVO.setDmeCertOnFileCd1(StringUtil.nonNullTrim(hpeEncounterForm.getDmeCertOnFileCd1()));
													enc837pClmlineVO.setDmeCertOnFileCd2(StringUtil.nonNullTrim(hpeEncounterForm.getDmeCertOnFileCd2()));
													enc837pClmlineVO.setDmeDuration(hpeEncounterForm.getDmeDuration());
													enc837pClmlineVO.setLiDmeProcCd(StringUtil.nonNullTrim(hpeEncounterForm.getLiDmeProcCd()));
													enc837pClmlineVO.setLiEpsdtInd(StringUtil.nonNullTrim(hpeEncounterForm.getLiEpsdtInd()));
													enc837pClmlineVO.setLiEmergencyInd(hpeEncounterForm.getLiEmergencyInd());
													enc837pClmlineVO.setObstetricAddlUnits(hpeEncounterForm.getObstetricAddlUnits());
													enc837pClmlineVO.setLiServiceUnitCnt(hpeEncounterForm.getLiServiceUnitCnt());
													enc837pClmlineVO.setDrugUnitCnt(hpeEncounterForm.getDrugUnitCnt());
													enc837pClmlineVO.setContractTermsDiscPct(hpeEncounterForm.getFormattedContractTermsDiscPct());
													enc837pClmlineVO.setLiDiagcdPtr1(StringUtil.nonNullTrim(hpeEncounterForm.getLiDiagcdPtr1()));
													enc837pClmlineVO.setLiDiagcdPtr2(StringUtil.nonNullTrim(hpeEncounterForm.getLiDiagcdPtr2()));
													enc837pClmlineVO.setLiDiagcdPtr3(StringUtil.nonNullTrim(hpeEncounterForm.getLiDiagcdPtr3()));
													enc837pClmlineVO.setLiDiagcdPtr4(StringUtil.nonNullTrim(hpeEncounterForm.getLiDiagcdPtr4()));
													enc837pClmlineVO.setLiLenOfMedNecessity(StringUtil.nonNullTrim(hpeEncounterForm.getLiLenOfMedNecessity()));
													enc837pClmlineVO.setLiRentalUnitPrcInd(StringUtil.nonNullTrim(hpeEncounterForm.getLiRentalUnitPrcInd()));
													enc837pClmlineVO.setHospiceEmployedPrvInd(StringUtil.nonNullTrim(hpeEncounterForm.getHospiceEmployedPrvInd()));
													enc837pClmlineVO.setPolicyComplianceCd(StringUtil.nonNullTrim(hpeEncounterForm.getPolicyComplianceCd()));
													enc837pClmlineVO.setNationalDrugCd(StringUtil.nonNullTrim(hpeEncounterForm.getNationalDrugCd()));
													enc837pClmlineVO.setNationalDrugCdQual(StringUtil.nonNullTrim(hpeEncounterForm.getNationalDrugCdQual()));
													enc837pClmlineVO.setLiFamilyPlaningInd(StringUtil.nonNullTrim(hpeEncounterForm.getLiFamilyPlaningInd()));
													enc837pClmlineVO.setLiCopayStatusCd(StringUtil.nonNullTrim(hpeEncounterForm.getLiCopayStatusCd()));
													enc837pClmlineVO.setServiceBeginDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedServiceBeginDt()).trim());
													enc837pClmlineVO.setServiceEndDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedServiceEndDt()).trim());
													enc837pClmlineVO.setPrescriptionDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedPrescriptionDt()).trim());
													enc837pClmlineVO.setHemoglobinDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedHemoglobinDt()).trim());
													enc837pClmlineVO.setLastCertificationDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedLastCertificationDt()).trim());
													enc837pClmlineVO.setTreatmentTherapyDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedTreatmentTherapyDt()).trim());
													enc837pClmlineVO.setRecertificationDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedRecertificationDt()).trim());
													enc837pClmlineVO.setSerumCreatineDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedSerumCreatineDt()).trim());
													enc837pClmlineVO.setLastXrayDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getLastXrayDt()).trim());
													enc837pClmlineVO.setBeginTherapyDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedBeginTherapyDt()).trim());
													enc837pClmlineVO.setShippedDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedShippedDt()).trim());
													enc837pClmlineVO.setInitialTreatmentDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getInitialTreatmentDt()).trim());
													enc837pClmlineVO.setTpoLineNote(StringUtil.nonNullTrim(hpeEncounterForm.getTpoLineNote()));
													enc837pClmlineVO.setImmunizationBatchNbr(StringUtil.nonNullTrim(hpeEncounterForm.getImmunizationBatchNbr()));
													enc837pClmlineVO.setLineItemControlNbr(StringUtil.nonNullTrim(hpeEncounterForm.getLineItemControlNbr()));
													enc837pClmlineVO.setMammogramCertNbr(StringUtil.nonNullTrim(hpeEncounterForm.getLiMammogramCertNbr()));
													enc837pClmlineVO.setHeightResult(StringUtil.nonNullTrim(hpeEncounterForm.getHeightResult()));
													enc837pClmlineVO.setHemoglobinResult(StringUtil.nonNullTrim(hpeEncounterForm.getHemoglobinResult()));
													enc837pClmlineVO.setHematocritResult(StringUtil.nonNullTrim(hpeEncounterForm.getHematocritResult()));
													enc837pClmlineVO.setEpoetinStartDoseRslt(StringUtil.nonNullTrim(hpeEncounterForm.getEpoetinStartDoseRslt()));
													enc837pClmlineVO.setCreatinineResult(StringUtil.nonNullTrim(hpeEncounterForm.getCreatinineResult()));
													enc837pClmlineVO.setCliaImproveAmendNbr(StringUtil.nonNullTrim(hpeEncounterForm.getCliaImproveAmendNbr()));
													enc837pClmlineVO.setReferringCliaNbr(StringUtil.nonNullTrim(hpeEncounterForm.getReferringCliaNbr()));
													enc837pClmlineVO.setOrderPrvContactName(StringUtil.nonNullTrim(hpeEncounterForm.getOrderPrvContactName()));
													enc837pClmlineVO.setOrderPrvEmail(StringUtil.nonNullTrim(hpeEncounterForm.getOrderPrvEmail()));
													enc837pClmlineVO.setOrderPrvFax(StringUtil.nonNullTrim(hpeEncounterForm.getOrderPrvFax()));
													enc837pClmlineVO.setOrderPrvPhone(StringUtil.nonNullTrim(hpeEncounterForm.getOrderPrvPhone()));
													enc837pClmlineVO.setOrderPrvPhoneExt(StringUtil.nonNullTrim(hpeEncounterForm.getOrderPrvPhoneExt()));
													enc837pClmlineVO.setLinkSeqNbr(StringUtil.nonNullTrim(hpeEncounterForm.getLinkSeqNbr()));													
													enc837pClmlineVO.setPrescriptionNbr(StringUtil.nonNullTrim(hpeEncounterForm.getPrescriptionNbr()));													
													enc837pClmlineVO.setAdjReprcdLiRefNbr(StringUtil.nonNullTrim(hpeEncounterForm.getAdjReprcdLiRefNbr()));													
													enc837pClmlineVO.setDrugUnitCnt(hpeEncounterForm.getDrugUnitCnt());													
													enc837pClmlineVO.setDrugUomQual(StringUtil.nonNullTrim(hpeEncounterForm.getDrugUomQual()));
													enc837pClmlineVO.setNationalDrugCd(StringUtil.nonNullTrim(hpeEncounterForm.getNationalDrugCd()));													
													enc837pClmlineVO.setRejectReasonCd(StringUtil.nonNullTrim(hpeEncounterForm.getRejectReasonCd()));																										
													enc837pClmlineVO.setReprcdLiRefNbr(StringUtil.nonNullTrim(hpeEncounterForm.getReprcdLiRefNbr()));
													enc837pClmlineVO.setReprcdOrgId(StringUtil.nonNullTrim(hpeEncounterForm.getReprcdOrgId()));
													enc837pClmlineVO.setReprcdSvcUnitCnt(hpeEncounterForm.getReprcdSvcUnitCnt());
													enc837pClmlineVO.setReprcdUomCd(StringUtil.nonNullTrim(hpeEncounterForm.getReprcdUomCd()));
													enc837pClmlineVO.setPolicyComplianceCd(StringUtil.nonNullTrim(hpeEncounterForm.getPolicyComplianceCd()));
													enc837pClmlineVO.setServiceCdQual(StringUtil.nonNullTrim(hpeEncounterForm.getServiceCdQual()));													
													enc837pClmlineVO.setReprcdAprvAmbpatgrpcd(StringUtil.nonNullTrim(hpeEncounterForm.getReprcdAprvAmbpatgrpcd()));
													enc837pClmlineVO.setReprcdAprvHcpcsCd(StringUtil.nonNullTrim(hpeEncounterForm.getReprcdAprvHcpcsCd()));
													enc837pClmlineVO.setAmbPickupAddrLine1(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbPickupAddrLine1()));
													enc837pClmlineVO.setAmbPickupAddrLine2(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbPickupAddrLine2()));
													enc837pClmlineVO.setAmbPatientWeight(hpeEncounterForm.getAmbPatientWeight());
													enc837pClmlineVO.setAmbTransportDistance(hpeEncounterForm.getAmbTransportDistance());
													enc837pClmlineVO.setAmbCertCondInd(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbCertCondInd()));
													enc837pClmlineVO.setAmbTransportReasCd(StringUtil.nonNullTrim(hpeEncounterForm.getAmbTransportReasCd()));													
													enc837pClmlineVO.setAmbPickupCity(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbPickupCity()));
													enc837pClmlineVO.setAmbPickupState(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbPickupState()));
													enc837pClmlineVO.setAmbPickupZip(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbPickupZip()));
													enc837pClmlineVO.setAmbPickupCountry(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbPickupCountry()));
													enc837pClmlineVO.setAmbPickupCntrySubd(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbPickupCntrySubd()));													
													enc837pClmlineVO.setAmbCertCondCd1(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbCertCondCd1()));
													enc837pClmlineVO.setAmbCertCondCd2(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbCertCondCd2()));
													enc837pClmlineVO.setAmbCertCondCd3(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbCertCondCd3()));
													enc837pClmlineVO.setAmbCertCondCd4(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbCertCondCd4()));
													enc837pClmlineVO.setAmbCertCondCd5(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbCertCondCd5()));
													enc837pClmlineVO.setAmbCertCondInd(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbCertCondInd()));													
													enc837pClmlineVO.setAmbDropoffAddrLine1(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbDropoffAddrLine1()));
													enc837pClmlineVO.setAmbDropoffAddrLine2(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbDropoffAddrLine2()));
													enc837pClmlineVO.setAmbDropoffCity(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbDropoffCity()));
													enc837pClmlineVO.setAmbDropoffCntrySubd(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbDropoffCntrySubd()));
													enc837pClmlineVO.setAmbDropoffCountry(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbDropoffCountry()));
													enc837pClmlineVO.setAmbDropoffLoc(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbDropoffLoc()));
													enc837pClmlineVO.setAmbDropoffState(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbDropoffState()));
													enc837pClmlineVO.setAmbDropoffZip(StringUtil.nonNullTrim(hpeEncounterForm.getLiAmbDropoffZip()));
													enc837pClmlineVO.setAmbRoundTripPurpDesc(StringUtil.nonNullTrim(hpeEncounterForm.getAmbRoundTripPurpDesc()));
													enc837pClmlineVO.setAmbStretcherPurpDesc(StringUtil.nonNullTrim(hpeEncounterForm.getAmbStretcherPurpDesc()));
													enc837pClmlineVO.setLiNoteCd(StringUtil.nonNullTrim(hpeEncounterForm.getLiNoteCd()));
													enc837pClmlineVO.setLiNoteText(StringUtil.nonNullTrim(hpeEncounterForm.getLiNoteText()));
													enc837pClmlineVO.setLiPlaceOfServiceCd(StringUtil.nonNullTrim(hpeEncounterForm.getLiPlaceOfServiceCd()));
													enc837pClmlineVO.setContractVersionId(StringUtil.nonNullTrim(hpeEncounterForm.getLiContractVersionId()));
													enc837pClmlineVO.setContractTypeCd(StringUtil.nonNullTrim(hpeEncounterForm.getLiContractTypeCd()));		//IFOX-00429335 - User is unable to update Contract Type Code
													
													msg = encounterService.updateProfClmline(conn, encounterVO,j,enc837pClmlineVO);											
													break;
												}
											}
											j++;
										}	
										if (msg.equals("")) {	
											Enc837pClmlineProviderVOs enc837pClmlineProvidersVOs =  encounterVO.getProfClaimLineProviders();
											Enc837pClmlineProviderVO oldClmlineProvidersVO;
											
											String frmLookupProvType = hpeEncounterForm.getLookupProvType();
											itr = enc837pClmlineProvidersVOs.iterator();
											int k = 0;
											while (itr.hasNext()){
												oldClmlineProvidersVO = (Enc837pClmlineProviderVO)itr.next();
												if (oldClmlineProvidersVO != null) {
													String clmliProvType = String.valueOf(oldClmlineProvidersVO.getProvType());
													if (clmliProvType.equals(frmLookupProvType)){
			
														Enc837pClmlineProviderVO enc837pClmlineProviderVO = new Enc837pClmlineProviderVO(oldClmlineProvidersVO);
														
														enc837pClmlineProviderVO.setProvEntityType(hpeEncounterForm.getLiProvEntityType());											
														enc837pClmlineProviderVO.setProvCommNbr(hpeEncounterForm.getLiProvCommNbr());
														enc837pClmlineProviderVO.setProvFirstName(hpeEncounterForm.getLiProvFirstName());
														enc837pClmlineProviderVO.setProvMiddleName(hpeEncounterForm.getLiProvMiddleName());
														enc837pClmlineProviderVO.setProvLastName(hpeEncounterForm.getLiProvLastName());
														enc837pClmlineProviderVO.setProvLicNbr(hpeEncounterForm.getLiProvLicNbr());
														enc837pClmlineProviderVO.setProvLocNbr(hpeEncounterForm.getLiProvLocNbr());
														enc837pClmlineProviderVO.setProvNpi(hpeEncounterForm.getLiProvNpi());
														enc837pClmlineProviderVO.setProvOthPayerId(hpeEncounterForm.getLiProvOthPayerId());
														enc837pClmlineProviderVO.setProvUpin(hpeEncounterForm.getLiProvUpin());
														enc837pClmlineProviderVO.setProvAddrLine1(hpeEncounterForm.getLiProvAddrLine1());
														enc837pClmlineProviderVO.setProvAddrLine2(hpeEncounterForm.getLiProvAddrLine2());
														enc837pClmlineProviderVO.setProvCity(hpeEncounterForm.getLiProvCity());
														enc837pClmlineProviderVO.setProvState(hpeEncounterForm.getLiProvState());
														enc837pClmlineProviderVO.setProvZip(hpeEncounterForm.getLiProvZip());
														enc837pClmlineProviderVO.setProvCountry(hpeEncounterForm.getLiProvCountry());
														enc837pClmlineProviderVO.setProvCntrySubd(hpeEncounterForm.getLiProvCntrySubd());
														enc837pClmlineProviderVO.setProvTaxonomyCd(hpeEncounterForm.getLiProvTaxonomyCd());
														
																									
														msg = encounterService.updateProfClmlineProv(conn, encounterVO,k,enc837pClmlineProviderVO);											
														break;
													}
												}
												k++;
											}	
										
											if (msg.equals("")) {								
												Enc837pClmlineAdjudVOs enc837pClmlineAdjudVOs =  encounterVO.getProfClaimLineAdjudications();		
												Enc837pClmlineAdjudVO oldClmlineAdjudVO;
												
												String frmClmliAdjudSeqNbr = hpeEncounterForm.getClmliAdjudSeqNbr();
												itr = enc837pClmlineAdjudVOs.iterator();
												int l = 0;
												while (itr.hasNext()){
													oldClmlineAdjudVO = (Enc837pClmlineAdjudVO)itr.next();
													if (oldClmlineAdjudVO != null) {
														String clmliAdjudSeqNbr = String.valueOf(oldClmlineAdjudVO.getClmliAdjudSeqNbr());
														if (clmliAdjudSeqNbr.equals(frmClmliAdjudSeqNbr)){
				
															Enc837pClmlineAdjudVO enc837pClmlineAdjudVO = new Enc837pClmlineAdjudVO(oldClmlineAdjudVO);
															enc837pClmlineAdjudVO.setClmliSeqNbr(Integer.parseInt(hpeEncounterForm.getClmliSeqNbr()));		//IFOX-00413184 - Opening of Claim Adjudication fields and amounts
															enc837pClmlineAdjudVO.setOthPayrPrimaryId(hpeEncounterForm.getOthPayrPrimaryId());											
															enc837pClmlineAdjudVO.setClmliBundledLineNbr(Integer.parseInt(hpeEncounterForm.getClmliBundledLineNbr()));
															enc837pClmlineAdjudVO.setClmliAdjudRevenueCd(hpeEncounterForm.getClmliAdjudRevenueCd());
															enc837pClmlineAdjudVO.setClmliAdjudProcCd(hpeEncounterForm.getClmliAdjudProcCd());
															enc837pClmlineAdjudVO.setClmliAdjudProcMod1(hpeEncounterForm.getClmliAdjudProcMod1());
															enc837pClmlineAdjudVO.setClmliAdjudProcMod2(hpeEncounterForm.getClmliAdjudProcMod2());
															enc837pClmlineAdjudVO.setClmliAdjudProcMod3(hpeEncounterForm.getClmliAdjudProcMod3());
															enc837pClmlineAdjudVO.setClmliAdjudProcMod4(hpeEncounterForm.getClmliAdjudProcMod4());
															enc837pClmlineAdjudVO.setClmliAdjudProcDesc(hpeEncounterForm.getClmliAdjudProcDesc());
															enc837pClmlineAdjudVO.setProdSvcidQual(hpeEncounterForm.getProdOrSvcidQual());
															enc837pClmlineAdjudVO.setAdjudPaymentDt(DateUtil.changedDateFormatForMonthAndEmpty(hpeEncounterForm.getFormattedAdjudPaymentDt()).trim());	
															enc837pClmlineAdjudVO.setClmliPaidSvcUnitCnt(hpeEncounterForm.getClmliPaidSvcUnitCnt());
																										
															msg = encounterService.updateProfClmlineAdjud(conn, encounterVO,l,enc837pClmlineAdjudVO);											
															break;
														}
													}
													l++;
												}
		
												if (msg.equals("")) {
													conn.commit();
													inTrans = false;
													
													hpeEncounterForm.setSubscriberDisplayState(HPEConstants.HPE_SCREEN_VIEW);
													hpeEncounterForm.setClaimDisplayState(HPEConstants.HPE_SCREEN_VIEW);
													hpeEncounterForm.setProviderDisplayState(HPEConstants.HPE_SCREEN_VIEW);
													hpeEncounterForm.setClmProviderDisplayState(HPEConstants.HPE_SCREEN_VIEW);								
													hpeEncounterForm.setDataChanged(false);
													hpeEncounterForm.setClmPrvChanged(false);
													
													encounterService.refreshUpdatedProf(conn,encounterVO);
												}
											}
										}
									}
								}
							}
						}						
					}
				}
			}
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
			msg = "Error Updating Claim";
		} finally {		
			if (inTrans) {
				try {
					conn.rollback();
				} catch(Exception e) {
				}	
			}
			try {
				conn.setAutoCommit(lastAutoCommit);
			} catch(Exception e) {
			}
		}

		if (msg.equals("")) {
			msg = "Updated Successfully";
		}

		// because the changed fields are not saved
		hpeEncounterForm.setSubscriberDisplayState(HPEConstants.HPE_SCREEN_VIEW);
		hpeEncounterForm.setClaimDisplayState(HPEConstants.HPE_SCREEN_VIEW);
		hpeEncounterForm.setProviderDisplayState(HPEConstants.HPE_SCREEN_VIEW);
		hpeEncounterForm.setClmProviderDisplayState(HPEConstants.HPE_SCREEN_VIEW);	
		hpeEncounterForm.setDataChanged(false);
		hpeEncounterForm.setClmPrvChanged(false);

		hpeEncounterForm.setDisplayMessage(msg);
		setProfRequest(encounterVO, request);
		
		hpeEncounterForm.setProfSubscriberExpanded(true);
	    hpeEncounterForm.setProfClaimExpanded(true);
	    hpeEncounterForm.setProfProviderExpanded(true);
	    logger.info(LoggerConstants.methodEndLevel());
	}
	
	
	/*
	 * Method to retrieve the selected claim change log details 
	 */
	public static String getClaimChangeLogDetails(Connection conn, SessionHelper sessionHelper, HPEContext context, HPEEncounterForm hpeEncounterForm, HttpServletRequest request)
	throws ApplicationException {
		 logger.info(LoggerConstants.methodStartLevel());
		String forward = HPEConstants.HPE_ERROR;
		String mfId = "";
		String claimRefNbr = "";
		int claimRevNbr = 0;
		int claimSeqNbr = 0;
		String claimType = "";
		String recordKey = "";
		Enc837ChangeClaimlogVOs claimLogList = null;	
		boolean historyFlag = false;
		
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getEncounterVO();
			mfId = encounterVO.getMfId();
			claimRefNbr = encounterVO.getSelectedClaimRefNbr();
			claimRevNbr = encounterVO.getSelectedClaimRevNbr();
			claimSeqNbr = encounterVO.getSelectedClaimSeqNbr();	
			claimType = encounterVO.getSearchDetailClmType();	
			recordKey = mfId + "|" + claimRefNbr + "|" + claimRevNbr + "|" + claimSeqNbr;
			
			claimLogList = context.getEncounterService().getChangeLogDetails(conn, encounterVO,historyFlag);
			hpeEncounterForm.setSelClaimType(claimType);
			/*To add revision number in
			 *  claim number IFOX 367728*/
		
			 HttpSession session =  sessionHelper.getSession();
				
				request.setAttribute("claimRefNbr",claimRefNbr);
				
				 if("TRUE".equals(session.getAttribute(HPEConstants.UNIQUE_PROFILE))){
					 DecimalFormat df = new DecimalFormat("00");
						request.setAttribute("claimRefUnqNbr",claimRefNbr.substring(0,3)+ df.format(claimRevNbr) + claimRefNbr.substring(5));	
				}
		
			request.setAttribute("claimRevNbr",String.valueOf(claimRevNbr));
			/*To add revision number in
			 *  claim number IFOX 367728*/
			request.setAttribute("claimSeqNbr",String.valueOf(claimSeqNbr));
			request.setAttribute("claimType",claimType);
			request.setAttribute("historyFlag",String.valueOf(historyFlag));
			request.setAttribute("CHANGE_LOG_LIST",claimLogList);
				
			forward = HPEConstants.HPE_CHANGELOG;
			
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		 logger.info(LoggerConstants.methodEndLevel());
		return forward;
	}
	
	/*
	 * Method to retrieve the selected claim change log details 
	 */
	public static String getClaimChangeLogHistory(Connection conn, SessionHelper sessionHelper, HPEContext context, HPEEncounterForm hpeEncounterForm, HttpServletRequest request)
	throws ApplicationException {
		 logger.info(LoggerConstants.methodStartLevel());
		String forward = HPEConstants.HPE_ERROR;
		String mfId = "";
		String claimRefNbr = "";
		int claimRevNbr = 0;/*To add revision number in  claim number IFOX 367728*/
		int claimSeqNbr = 0;
		String claimType = "";
		String recordKey = "";
		Enc837ChangeClaimlogVOs claimLogList = null;	
		boolean historyFlag = true;
		
		try {
			// Get the VO
			HPEEncounterVO encounterVO = context.getEncounterVO();
			mfId = encounterVO.getMfId();
			claimRefNbr = encounterVO.getSelectedClaimRefNbr();
			/*To add revision number in
			 *  claim number IFOX 367728*/
			claimRevNbr = encounterVO.getSelectedClaimRevNbr();
			/*claimSeqNbr = encounterVO.getSelectedClaimSeqNbr();	*/
			claimType = encounterVO.getSearchDetailClmType();	
			
						
			claimLogList = context.getEncounterService().getChangeLogDetails(conn, encounterVO,historyFlag);
			hpeEncounterForm.setSelClaimType(claimType);
			HttpSession session =  sessionHelper.getSession();
		
			request.setAttribute("claimRefNbr",claimRefNbr);
			
			 if("TRUE".equals(session.getAttribute("UNIQUE"))){
				 DecimalFormat df = new DecimalFormat("00");
					request.setAttribute("claimRefUnqNbr",claimRefNbr.substring(0,3)+ df.format(claimRevNbr) + claimRefNbr.substring(5));	
			}
			
			request.setAttribute("claimRevNbr",String.valueOf(claimRevNbr));
			/*To add revision number in
			 *  claim number IFOX 367728*/
			request.setAttribute("claimSeqNbr",String.valueOf(claimSeqNbr));
			request.setAttribute("claimType",claimType);
			request.setAttribute("historyFlag",String.valueOf(historyFlag));
			request.setAttribute("CHANGE_LOG_LIST",claimLogList);
				
			forward = HPEConstants.HPE_CHANGELOG;
			
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		 logger.info(LoggerConstants.methodEndLevel());
		return forward;
	}
	
	
	//Editable Fileds CHS -- IFOX-00395627
	
	public static String EditableUpdateCodes(Connection conn, SessionHelper sessionHelper, HPEContext context, HttpServletRequest request, HPEEncounterForm hpeEncounterForm, String flagInd)
			throws ApplicationException {
		 logger.info(LoggerConstants.methodStartLevel());
		String forward = HPEConstants.HPE_ERROR;
		String obj ="";
		HashMap<String,String> hm=new HashMap<String,String>();
		HPEEncounterVO encounterVO = new HPEEncounterVO();
	    
		String uid = sessionHelper.getUserId();
		
		HPEEncounterService encounterService = context.getEncounterService();
		int sqlCnt = -1;
		
		try {
			
			if(StringUtils.isNotEmpty(hpeEncounterForm.getHier())){
				
				encounterVO.setHier(hpeEncounterForm.getHier());
				encounterVO.setEditableMfid(hpeEncounterForm.getEditableMfid());
				if(hpeEncounterForm.getEditableCndSeqNbr()!=null){
					encounterVO.setEditableCndSeqNbr(Integer.parseInt(hpeEncounterForm.getEditableCndSeqNbr()));
				}
			
				encounterVO.setSearchDetailClmType(hpeEncounterForm.getSelectedClaimType());
				encounterVO.setSearchDetailEncType(hpeEncounterForm.getEditableEncType());
				encounterVO.setSelectedClaimRefNbr(hpeEncounterForm.getSelectedClaimRefNbr());
				encounterVO.setSelectedClaimRevNbr(Integer.parseInt(hpeEncounterForm.getSelectedClaimRevNbr()));
				encounterVO.setSelectedClaimSeqNbr(Integer.parseInt(hpeEncounterForm.getSelectedClaimSeqNbr()));
				encounterVO.setUserId(uid);
				
				 if(HPEConstants.EDITABLE_COND_CODE_CNSTNT.equals(hpeEncounterForm.getHier()) || HPEConstants.EDITABLE_TREATMENT_CODE_CNSTNT.equals(hpeEncounterForm.getHier())){					
					 encounterVO.setEditableCode(hpeEncounterForm.getEditableCode());
				 }
				 
				 if(HPEConstants.EDITABLE_DIAG_CODE_CNSTNT.equals(hpeEncounterForm.getHier()) || HPEConstants.EDITABLE_EXT_INJ_CODE_CNSTNT.equals(hpeEncounterForm.getHier())){
					    encounterVO.setEditableCode(hpeEncounterForm.getEditableCode());
						encounterVO.setEditablePOA(hpeEncounterForm.getEditablePOA());
						encounterVO.setEditableType(hpeEncounterForm.getEditableType()); 
				 }
				 
				 if(HPEConstants.EDITABLE_PROCEDURE_CODE_CNSTNT.equals(hpeEncounterForm.getHier())){
					 encounterVO.setEditableType(hpeEncounterForm.getEditableType());
					  encounterVO.setEditableCode(hpeEncounterForm.getEditableCode());
					
					  if(StringUtils.isNotEmpty(hpeEncounterForm.getEditableDate())){
						    String frmDt = hpeEncounterForm.getEditableDate(); 							
							String arr[] = frmDt.split("/");							
							String modDt = arr[2]+arr[0]+arr[1];
							encounterVO.setEditableDate(modDt);
					 }
				 }
				 if(HPEConstants.EDITABLE_OCCURSPAN_CODE_CNSTNT.equals(hpeEncounterForm.getHier())){
					 encounterVO.setEditableCode(hpeEncounterForm.getEditableCode());
					 
					 if(StringUtils.isNotEmpty(hpeEncounterForm.getEditableFromDt())){
						    String frmDt = hpeEncounterForm.getEditableFromDt(); 							
							String arr[] = frmDt.split("/");							
							String modDt = arr[2]+arr[0]+arr[1];
							encounterVO.setEditableFromDt(modDt);
					 }
					 if(StringUtils.isNotEmpty(hpeEncounterForm.getEditableThruDt())){
						    String thruDt = hpeEncounterForm.getEditableThruDt(); 							
							String arr[] = thruDt.split("/");							
							String modDt = arr[2]+arr[0]+arr[1];
							encounterVO.setEditableThruDt(modDt);
					 }						 
					
				 }
				 if(HPEConstants.EDITABLE_VALUE_CODE_CNSTNT.equals(hpeEncounterForm.getHier())){
					 encounterVO.setEditableCode(hpeEncounterForm.getEditableCode());
					 encounterVO.setEditableAmount(hpeEncounterForm.getEditableAmount());
					 
				 }
				 if(HPEConstants.EDITABLE_OCCURENCE_CODE_CNSTNT.equals(hpeEncounterForm.getHier())){
					 encounterVO.setEditableCode(hpeEncounterForm.getEditableCode());
					
					 if(StringUtils.isNotEmpty(hpeEncounterForm.getEditableDate())){
						    String frmDt = hpeEncounterForm.getEditableDate(); 							
							String arr[] = frmDt.split("/");							
							String modDt = arr[2]+arr[0]+arr[1];
							encounterVO.setEditableDate(modDt);
					 }
				 }
				//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
				 if(HPEConstants.EDITABLE_CLMLINE_ADJUD_ADJUST.equals(hpeEncounterForm.getHier())){
					 encounterVO.setAdjudGroupCode(hpeEncounterForm.getEditableAdjGroupCode());
					 encounterVO.setAdjudReasonCode(hpeEncounterForm.getEditableAdjReasonCode());
					 encounterVO.setAdjudAmount(hpeEncounterForm.getEditableAdjAmount());
					 encounterVO.setAdjudQuantity(hpeEncounterForm.getEditableAdjQuantity());
					 encounterVO.setClmliAdjudSeqNbr(hpeEncounterForm.getEditableAdjudSeqNbr());
					 encounterVO.setClmliAdjustSeqNbr(hpeEncounterForm.getEditableAdjustSeqNbr());
					 encounterVO.setClmliSeqNbr(Integer.parseInt(hpeEncounterForm.getClmliSeqNbr().trim()));
					 
				 }
				//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
				//EDTABLEFLDS
				 hm= encounterService.EditableUpdateCodes(conn, context, encounterVO, flagInd);
				 //TODO get the codes based on hier
				 /* Added for IFOX-00406912 Primary Procedure Code*/			
				 if(hm.get("princProc")!=null && hm.get("princProc").equals("exists")) {
					 if (HPEConstants.EDITABLE_PROCEDURE_CODE_CNSTNT.equals(encounterVO.getHier())) {						
							hpeEncounterForm.setDisplayMessage("Cannot add two principal procedure codes");
						}
				 }else {
				 sqlCnt =Integer.parseInt(hm.get("sqlCnt"));
				 }
			}		
			
			if(sqlCnt== -5 || sqlCnt== -10){				
				
				forward=String.valueOf(sqlCnt);
				
			}
			else if(sqlCnt!=-1 && sqlCnt!=0){
				
				
				if(StringUtils.isNotEmpty(flagInd)&& "ADD".equals(flagInd)){
					
					if (HPEConstants.EDITABLE_COND_CODE_CNSTNT.equals(encounterVO.getHier())) {						
						hpeEncounterForm.setDisplayMessage("Condition Code Added Successfully");
					}
					
					if (HPEConstants.EDITABLE_DIAG_CODE_CNSTNT.equals(encounterVO.getHier())) {						
						hpeEncounterForm.setDisplayMessage("Diganosis Code Added Successfully");
					}
					
					if (HPEConstants.EDITABLE_PROCEDURE_CODE_CNSTNT.equals(encounterVO.getHier())) {						
						hpeEncounterForm.setDisplayMessage("Procedure Code Added Successfully");
					}
					
					if (HPEConstants.EDITABLE_VALUE_CODE_CNSTNT.equals(encounterVO.getHier())) {						
						hpeEncounterForm.setDisplayMessage("Value Code Added Successfully");
					}
					
					if (HPEConstants.EDITABLE_EXT_INJ_CODE_CNSTNT.equals(encounterVO.getHier())) {						
						hpeEncounterForm.setDisplayMessage("External Injury Code Added Successfully");
					}
					
					if (HPEConstants.EDITABLE_OCCURENCE_CODE_CNSTNT.equals(encounterVO.getHier())) {						
						hpeEncounterForm.setDisplayMessage("Occurrence Code Added Successfully");
					}
					
					if (HPEConstants.EDITABLE_OCCURSPAN_CODE_CNSTNT.equals(encounterVO.getHier())) {						
						hpeEncounterForm.setDisplayMessage("Occurrence Span Code Added Successfully");
					}
					
					if (HPEConstants.EDITABLE_TREATMENT_CODE_CNSTNT.equals(encounterVO.getHier())) {						
						hpeEncounterForm.setDisplayMessage("Treatment Code Added Successfully");
					}
				
				}
				
			
			}	
				if(encounterVO.getSearchDetailClmType().equals("I")){
					forward = HPEConstants.HPE_INSTDETAIL;
				}else{
					forward = HPEConstants.HPE_PROFDETAIL;
				}
			
		
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		
		 logger.info(LoggerConstants.methodEndLevel());
		return forward;
		
	}
	
	
	
	

	
	/*//Editable Fileds CHS -- IFOX-00395627	
	public static String checkDuplicateEditableCodes(Connection conn, SessionHelper sessionHelper, HPEContext context, HttpServletRequest request, HPEEncounterForm hpeEncounterForm, String flagInd)
			throws ApplicationException {

		String responseString ="" ;
		
		HPEEncounterVO encounterVO = new HPEEncounterVO();
	    
		String uid = sessionHelper.getUserId();
		
		HPEEncounterService encounterService = context.getEncounterService();

		
		try {
			
			if(StringUtils.isNotEmpty(hpeEncounterForm.getHier())){
				
				encounterVO.setHier(hpeEncounterForm.getHier());
				encounterVO.setEditableMfid(hpeEncounterForm.getEditableMfid());
				if(hpeEncounterForm.getEditableCndSeqNbr()!=null){
					encounterVO.setEditableCndSeqNbr(Integer.parseInt(hpeEncounterForm.getEditableCndSeqNbr()));
				}
			
				encounterVO.setSearchDetailClmType(hpeEncounterForm.getSelectedClaimType());
				encounterVO.setSearchDetailEncType(hpeEncounterForm.getEditableEncType());
				encounterVO.setSelectedClaimRefNbr(hpeEncounterForm.getSelectedClaimRefNbr());
				encounterVO.setSelectedClaimRevNbr(Integer.parseInt(hpeEncounterForm.getSelectedClaimRevNbr()));
				encounterVO.setSelectedClaimSeqNbr(Integer.parseInt(hpeEncounterForm.getSelectedClaimSeqNbr()));
				encounterVO.setUserId(uid);
				
				 if(HPEConstants.EDITABLE_COND_CODE_CNSTNT.equals(hpeEncounterForm.getHier()) || HPEConstants.EDITABLE_TREATMENT_CODE_CNSTNT.equals(hpeEncounterForm.getHier())){					
					 encounterVO.setEditableCode(hpeEncounterForm.getEditableCode());
				 }
				 
				 if(HPEConstants.EDITABLE_DIAG_CODE_CNSTNT.equals(hpeEncounterForm.getHier()) || HPEConstants.EDITABLE_EXT_INJ_CODE_CNSTNT.equals(hpeEncounterForm.getHier())){
					    encounterVO.setEditableCode(hpeEncounterForm.getEditableCode());
						encounterVO.setEditablePOA(hpeEncounterForm.getEditablePOA());
						encounterVO.setEditableType(hpeEncounterForm.getEditableType()); 
				 }
				 
				 if(HPEConstants.EDITABLE_PROCEDURE_CODE_CNSTNT.equals(hpeEncounterForm.getHier())){
					 encounterVO.setEditableType(hpeEncounterForm.getEditableType());
					  encounterVO.setEditableCode(hpeEncounterForm.getEditableCode());
					
					  if(StringUtils.isNotEmpty(hpeEncounterForm.getEditableDate())){
						    String frmDt = hpeEncounterForm.getEditableDate(); 							
							String arr[] = frmDt.split("/");							
							String modDt = arr[2]+arr[0]+arr[1];
							encounterVO.setEditableDate(modDt);
					 }
				 }
				 if(HPEConstants.EDITABLE_OCCURSPAN_CODE_CNSTNT.equals(hpeEncounterForm.getHier())){
					 encounterVO.setEditableCode(hpeEncounterForm.getEditableCode());
					 
					 if(StringUtils.isNotEmpty(hpeEncounterForm.getEditableFromDt())){
						    String frmDt = hpeEncounterForm.getEditableFromDt(); 							
							String arr[] = frmDt.split("/");							
							String modDt = arr[2]+arr[0]+arr[1];
							encounterVO.setEditableFromDt(modDt);
					 }
					 if(StringUtils.isNotEmpty(hpeEncounterForm.getEditableThruDt())){
						    String thruDt = hpeEncounterForm.getEditableThruDt(); 							
							String arr[] = thruDt.split("/");							
							String modDt = arr[2]+arr[0]+arr[1];
							encounterVO.setEditableThruDt(modDt);
					 }						 
					
				 }
				 if(HPEConstants.EDITABLE_VALUE_CODE_CNSTNT.equals(hpeEncounterForm.getHier())){
					 encounterVO.setEditableCode(hpeEncounterForm.getEditableCode());
					 encounterVO.setEditableAmount(hpeEncounterForm.getEditableAmount());
					 
				 }
				 if(HPEConstants.EDITABLE_OCCURENCE_CODE_CNSTNT.equals(hpeEncounterForm.getHier())){
					 encounterVO.setEditableCode(hpeEncounterForm.getEditableCode());
					
					 if(StringUtils.isNotEmpty(hpeEncounterForm.getEditableDate())){
						    String frmDt = hpeEncounterForm.getEditableDate(); 							
							String arr[] = frmDt.split("/");							
							String modDt = arr[2]+arr[0]+arr[1];
							encounterVO.setEditableDate(modDt);
					 }
				 }
				//EDTABLEFLDS
				 boolean isDuplicate = encounterService.isDuplicateEditableCodes(conn, context, encounterVO, flagInd);
				 responseString =String.valueOf(isDuplicate);
			}
			
		
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		
		
		return responseString;
		
	}	
	*/
}
