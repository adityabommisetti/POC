package com.ps.mss.web.forms;

import com.ps.util.GridUtil;

import java.util.Arrays;

import com.ps.text.DateFormatter;

/**
 * @author DParker
 */
public class HPEEncounterForm extends HPEForm {

	private String displayMessage = "";    
    private String focusField;	
	// Summary search criteria
	private String searchSummaryDateInd = "0";
	private String searchSummaryFromDate = "";
	private String searchSummaryToDate = "";
	private String searchSummaryEncType = "I";	
	private String searchSummaryType = "EN";
	private String searchSummaryGroupStatus = "";
	private String searchSummarySubmitterId = "";
	private String searchSummaryErrorSource = "";
	private String searchSummaryErrorGroup = "";
	private String searchSummaryErrorCode = "";
	private String rejectCode = "";	
	private String formattedErrorSource = "";
	private String selectedDateYrmo = "";	
	private String selectedErrorGroup = "";
	private GridUtil statusSummaryGrid = null;

	//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : Start
	private String maoflag = "";
	
	
	public String getMaoflag() {
		return maoflag;
	}
	public void setMaoflag(String maoflag) {
		this.maoflag = maoflag;
	}
	//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : End
	
	/**
	 * @return Returns the searchSummaryErrorGroup.
	 */
	public String getSearchSummaryErrorGroup() {
		return searchSummaryErrorGroup;
	}
	/**
	 * @param searchSummaryErrorGroup The searchSummaryErrorGroup to set.
	 */
	public void setSearchSummaryErrorGroup(String searchSummaryErrorGroup) {
		this.searchSummaryErrorGroup = searchSummaryErrorGroup;
	}
	/**
	 * @return Returns the selectedErrorGroup.
	 */
	public String getSelectedErrorGroup() {
		return selectedErrorGroup;
	}
	/**
	 * @param selectedErrorGroup The selectedErrorGroup to set.
	 */
	public void setSelectedErrorGroup(String selectedErrorGroup) {
		this.selectedErrorGroup = selectedErrorGroup;
	}
	public String getSelectedDateYrmo() {
		return selectedDateYrmo;
	}
	public void setSelectedDateYrmo(String selectedDateYrmo) {
		this.selectedDateYrmo = selectedDateYrmo;
	}
	
	public String getFormattedErrorSource() {
		return formattedErrorSource;
	}
	public void setFormattedErrorSource(String formattedErrorSource) {
		this.formattedErrorSource = formattedErrorSource;
	}
	public String getRejectCode() {
		return rejectCode;
	}
	public void setRejectCode(String rejectCode) {
		this.rejectCode = rejectCode;
	}
	public String getSearchSummaryErrorCode() {
		return searchSummaryErrorCode;
	}
	public void setSearchSummaryErrorCode(String searchSummaryErrorCode) {
		this.searchSummaryErrorCode = searchSummaryErrorCode;
	}
	public String getSearchSummaryErrorSource() {
		return searchSummaryErrorSource;
	}
	public void setSearchSummaryErrorSource(String searchSummaryErrorSource) {
		this.searchSummaryErrorSource = searchSummaryErrorSource;
	}
	public void setSearchSummarySubmitterId(String searchSummarySubmitterId) {
		this.searchSummarySubmitterId = searchSummarySubmitterId;
	}
	public String getSearchSummarySubmitterId() {
		return searchSummarySubmitterId;
	}

	// Detail search criteria
	private String searchDetailSubmitterId = "";
	private String searchDetailEncType = "I";
	private String searchDetailClmType = "EN";
	private String searchDetailDateInd = "0";
	private String searchDetailFromDate = "";
	private String searchDetailToDate = "";
	private String searchDetailClaimRefNbr = "";
	private String searchDetailHicNbr = "";
	private String searchDetailGroupStatus = "";
	private String searchDetailProcessStatus = "";
	private String searchDetailErrorSource = "";
	private String searchDetailErrorGroup = "";
	private String searchDetailErrorCode = "";

	public String getSearchDetailErrorCode() {
		return searchDetailErrorCode;
	}
	public void setSearchDetailErrorCode(String searchDetailErrorCode) {
		this.searchDetailErrorCode = searchDetailErrorCode;
	}
	public String getSearchDetailErrorGroup() {
		return searchDetailErrorGroup;
	}
	public void setSearchDetailErrorGroup(String searchDetailErrorGroup) {
		this.searchDetailErrorGroup = searchDetailErrorGroup;
	}
	public String getSearchDetailErrorSource() {
		return searchDetailErrorSource;
	}
	public void setSearchDetailErrorSource(String searchDetailErrorSource) {
		this.searchDetailErrorSource = searchDetailErrorSource;
	}
	
	
	// Claim select values
	private String selectedClaimType = "";		// TODO: s/b enum
	private String selectedClaimRefNbr = "";
	private String selectedClaimRevNbr = "";
	private String selectedClaimSeqNbr = "";

	private String firstClaimType = "";		// TODO: s/b enum
	private String firstClaimRefNbr = "";
	private String firstClaimRevNbr = "";
	private String firstClaimSeqNbr = "";

	private boolean dataChanged;	
	private String prevMenu = "";
	private String prevMethod = "";
	
	
	// Toggle fields
	private boolean instListExpanded = true;
	private boolean instErrorsExpanded = true;
	private boolean instSubscriberExpanded = false;
	private boolean instClaimExpanded = false;
	private boolean instClaimCodesExpanded = false;
	private boolean instClaimProvExpanded = false;
	private boolean instClaimProvDetailExpanded = true;
	private boolean instClaimOtherSubsExpanded = false;
	private boolean instClaimOtherSubsDetailExpanded = true;
	private boolean instClaimOtherSubsProvExpanded = false;
	private boolean instClaimOtherSubsProvDetailExpanded = true;
	private boolean instClaimLineExpanded = false;
	private boolean instClaimLineDetailExpanded = true;
	private boolean instClaimLineProvExpanded = false;
	private boolean instClaimLineProvDetailExpanded = true;
	private boolean instClaimLineAdjudExpanded = false;
	private boolean instClaimLineAdjudDetailExpanded = true;
	private boolean instClaimNotesExpanded = false;
	private boolean instProviderExpanded = false;

	private boolean profListExpanded = true;
	private boolean profErrorsExpanded = true;
	private boolean profSubscriberExpanded = false;
	private boolean profClaimExpanded = false;
	private boolean profClaimCodesExpanded = false;
	private boolean profClaimProvExpanded = false;
	private boolean profClaimProvDetailExpanded = true;
	private boolean profClaimOtherSubsExpanded = false;
	private boolean profClaimOtherSubsDetailExpanded = true;
	private boolean profClaimOtherSubsProvExpanded = false;
	private boolean profClaimOtherSubsProvDetailExpanded = true;
	private boolean profClaimLineExpanded = false;
	private boolean profClaimLineDetailExpanded = true;
	private boolean profClaimLineProvExpanded = false;
	private boolean profClaimLineProvDetailExpanded = true;
	private boolean profClaimLineAdjudExpanded = false;
	private boolean profClaimLineAdjudDetailExpanded = true;
	private boolean profProviderExpanded = false;

    // View or Edit Fields
	private boolean subscriberChanged;
	private String subscriberDisplayState;
	
	private boolean claimChanged;
	private String claimDisplayState;	
	
	private boolean providerChanged;
	private String providerDisplayState;
	private String billProviderExist = "N";
	
	private boolean clmPrvChanged;
	private String clmProviderDisplayState;	
	private String clmProviderExist = "N";	
	
	private boolean clmLineChanged;
	private boolean adjudChanged;	
	private boolean clmLineProvChanged;
	private boolean claimOtherSubsChanged;
	private boolean claimOtherSubsProvChanged; 
	private String clmOtherSubscribersExist = "N";
	private String clmLinesExist = "N";
	private String clmLineAdjudExist = "N";
	private String clmLineProvExist = "N";
	private String clmOtherSubsProvExist = "N";
	
	//Subscriber Fields
	private String subsFirstName;
	private String subsMiddleName;
	private String subsLastName;
	private String subsHicNbr;
	private String mbi;
	private String CustSentMbiInd;
	private String formattedSubsSsn;
	private String formattedSubsDob;
	private String subsSex;
	private String subsAddrLine1;
	private String subsAddrLine2;
	private String subsCity;
	private String subsState;
	private String subsZip;	
	//Added for updating new feilds for Scbscriber data which are enabled in UI.
	private String subsPayerSeqCd;
	private String subsRelationCd;
	private String subsFilingIndCd;
	private String subsInsuranceTypeCd;
	private String subsEntityType;
	private String subsMemberId;
	private String subsCountry;
	private String SubsGrpName;
	private String subsCntrySubdCd;
	private String subsGrpOrPolNbr;
	private String subsPlanName;
    private String subsPatDod;	
    private int subsPatWeight;
	private String subsPatUom;
	private String subsPatPregnantInd;
	private String payerName;
	private String payerId;
	private String payerPlanId;
	private String payerAddrLine1;
	private String payerAddrLine2;
	private String payerCity;
	private String payerState;
	private String payerZip;
	private String payerCountry;
	private String payerCntrySubdCd;
	private String payerTaxId;
	private String payerLocNbr;
	private String payerNaicCd;
	private String payerSecId;
	private String billPrvCommNbr;
	private String billPrvLocNbr;
	private String propCasltyClmNbr;
	private String propCasltySubsName;
	private String propCasltySubsPhone;
	private String propCasltySubsPhnExt;
	
//	End for updating new feilds for Scbscriber data which are enabled in UI.
	//Claim Fields
	private String processStatus;
	private String placeOfService;
	private String clmFacTypeCd;
	private String admitType;
	private String admitSourceCd;
	private String admitDt;
	private String admitHour;
	private String patientStatusCd;
	private String mammogramCertNbr;
	private String cliaNbr;
	private String hospAdmitDt;
	private String hospDischargeDt;
	private String ambPickupAddrLine1;
	private String ambPickupAddrLine2;
	private String ambPickupCity;
	private String ambPickupState;
	private String ambPickupZip;
	private String ambDropoffLoc;
	private String ambDropoffAddrLine1;
	private String ambDropoffAddrLine2;
	private String ambDropoffCity;
	private String ambDropoffState;
	private String ambDropoffZip;
	
	//Claim new Feilds..
	private String patientCtrlNbr;
	private String wtxClaimRefNbr;
	private String contractVersionId;
	private String admitDiagCd;
	private String contractCd;
	private String svcFacContactName;
	private String svcFacPhone;
	private String svcFacPhoneExt;
	private String svcAuthExcptCd;
	private String formattedStatementFromDt;
	private String drgCd;
	private String formattedStatementToDt;
	private String anestSurgProcCd1;
	private String anestSurgProcCd2;
	private String visnCertCondInd;
	private String autoAccidentCountry;
	private String claimRefCd;
	private String patSignatureSrcCd;
	private String medicareCrossoverCd;
	private String labHomeRespCd;
	private String labHomeCondInd;
	private String visnCodeCategory;
	private String contractTypeCd;
	private String admitDiagType;
	private String prvAcceptAssignCd;
	private String releaseOfInfoCd;
	private String autoAccidentState;
	private String otherAccidentInd;
	private String prvSignatureOnfileInd;
	private String delayReasonCd;
	private String dischargeHour;
	private String beneAssignCertInd;
	private String visnCertCondCd1;
	private String visnCertCondCd2;
	private String visnCertCondCd3;
	private int wtxClaimRevNbr;
	private String clmFreqTypeCd;
	private String employmentAccidentInd;
	private String autoAccidentInd;
	private String epsdtCondInd1;
	private String epsdtCondInd2;
	private String epsdtCondInd3;
	private String visnCertCondCd4;
	private String visnCertCondCd5;
	private String payerClmCtrlNbr;
	private String priorAuthNbr;
	private String investigDeviceExmptId;
	private String peerRevewOrgAprvNbr;
	private String medicalRecordNbr;
	private String demonstrationProjectId;
	private String billingNotes;
	private String patVisitreasType1;
	private String patVisitreasCd1;
	private String patVisitreasType2;
	private String patVisitreasCd2;
	private String patVisitreasType3;
	private String patVisitreasCd3;
	private String repricdClmRefNbr;
	private String adjRepricdClmRefNbr;
	private String repricedApprvdDrgCd;
	private String repricedApprvdRevCd;
	private String repricerReceivedDt;
	private String repricingOrgId;
	private String repricedUom;
	private String repricedRejReasonCd;
	private String repricedPolCmpliantCd;
	private String repricedExceptionCd;
	private String valueAddNtwkTraceNbr;
	private String carePlanOversightNbr;
	private String claimNotes;
	private String referralNbr;
	private String investigDeviceExempId;
	private String demonstrationProjId;
	private String formattedIllnessOccurDt;
	private String formattedLastMenstrualPerDt;
	private String formattedDisabilityStartDt;
	private String formattedAsumdCareStartDt;
	private String patientCondCd;
	private String formattedInitialTreatmentDt;
	private String formattedLastXrayDt;
	private String formattedDisabilityEndDt;
	private String formattedAsumdCareEndDt;
	private String formattedLastSeenDt;
	private String formattedHearVisionDt;
	private String formattedLastWorkedDt;
	private String formattedFirstVisitConsultDt;
	private String formattedAcuteManifestationDt;
	private String formattedAuthReturnWorkDt;
	private String formattedAccidentDt;
	private String roundTripPurposeDesc;
	private String stretcherPurposeDesc;
	private String ambPatWeight;
	private String ambCertCondInd;
	private String ambPickupCountry;
	private String ambCertCondCd1;
	private String ambCertCondCd2;
	private String ambCertCondCd3;
	private String ambDropoffCountry;
	private String ambTranspDistance;
	private String ambTranspReasonCd;
	private String ambPickupCntrySubd;
	private String ambCertCondCd4;
	private String ambCertCondCd5;
	private String ambDropoffCntrySubd;
	
	//Billing Provider Fields
	private String billPrvFirstName;
	private String billPrvMiddleName;
	private String billPrvLastName;
	private String billPrvEntityType;
	private String billPrvOrgName;
	private String billPrvAddrLine1;
	private String billPrvAddrLine2;
	private String billPrvTaxonomyCd;
	private String billPrvNpi;
	private String billPrvLicNbr;
	private String billPrvUpin;
	private String formattedBillPrvSsn;
	private String formattedBillPrvAffilTaxId;
	private String billPrvCity;
	private String billPrvState;
	private String billPrvZip;
	private String billPrvContactName;
	private String billPrvCountry;
	private String billPrvCntrySubdCd;
	private String billPrvComNbrQual1;
	private String billPrvComNbrQual2;
	private String billPrvComNbrQual3;
	private String billPrvComNbr1;
	private String billPrvComNbr2;
	private String billPrvComNbr3;
	
	private String p2prvAddrLine1;
	private String p2prvAddrLine2;
	private String p2prvCity;
	private String p2prvState;
	private String p2prvZip;
	private String p2prvEntityType;
	private String p2prvCountry;
	private String p2prvCntrySubdCd;
	
	private String provFirstName;
	private String provMiddleName;
	private String provLastName;
	private String provOrgName;
	private String provEntityType;
	private String provAddrLine1;
	private String provAddrLine2;
	private String provCity;
	private String provState;
	private String provZip;
	private String provTaxonomyCd;
	private String provNpi;
	private String provType;
	private String provOthPayerId;
	private String provLocNbr;
	private String provLicNbr;
	private String provUpin;
	private String provCountry;
	private String provCntrySubd;
	private String provCommNbr;
	
	private String p2pOrgName;
	private String p2pPrimPayerId;
	private String p2pLocNbr;
	private String p2pAddrLine1;
	private String p2pPayerIdNbr;
	private String p2pNaicCd;
	private String p2pAddrLine2;
	private String p2pPrimPlanId;
	private String p2pTaxId;
	private String p2pCity;
	private String p2pState;
	private String p2pZip;
	private String p2pCountry;
	private String p2pCntrySubdCd;
	
	private String selClaimType;	
	//Claim Line Adjudication fields
	private String othPayrPayerId;
	private String clmliBundledLineNbr;
	private String clmliAdjudSeqNbr;
	private String clmliAdjudProcCd;
	private String clmliAdjudProcMod1;
	private String clmliAdjudProcMod2;
	private String clmliAdjudProcMod3;
	private String clmliAdjudProcMod4;
	private String clmliAdjudProcDesc;
	private String clmliAdjudRevenueCd;
	private String prodOrSvcidQual;	
	private double clmliPaidSvcUnitCnt;
	private String formattedAdjudPaymentDt;
	private String othPayrPrimaryId;
	
	//Claim Line fields	
	private String liRevenueCd;	
	private String liProdSvcidQual;
	private String liProcMod1;
	private String liProcMod2;
	private String liProcMod3;
	private String liProcMod4;
	private String liProcDesc;	
	private String liProcCd;
	private String clmliSeqNbr;
	private String formattedLiBeginDt;
	private String formattedLiEndDt;
	private String liUomQual;
	private String nationalDrugCdQual;
	private double liServiceUnitCnt;
	private String pricingMethodology;
	private String exceptionCd;	
	private String reprcdLiRefNbr;	
	private String adjReprcdLiRefNbr;
	private String liNote;
	private String reprcdOrgId;
	private String reprcdDrgCd;
	private String approvedRevenueCd;
	private String serviceCdQual;	
	private String reprcdApprHcpcsCd;
	private String reprcdUomCd;
	private double reprcdSvcUnitCnt;
	private String rejectReasonCd;
	private String policyComplianceCd;
	private String nationalDrugCd;
	private int drugUnitCnt;
	private String drugUomQual;
	private String linkSequenceNbr;	
	private String prescriptionNbr;		
	// Getters/Setters
	
	private String dmeCertTypeCd;
	private String dmeAttachTransmitCd;
	private String dmeCertCondInd;
	private String liDmeProcCd;
	private int dmeDuration;
	private String dmeCertOnFileCd1;
	private String dmeCertOnFileCd2;
	private String liEpsdtInd;
	private String liEmergencyInd;
	private int obstetricAddlUnits;
	private String liDiagcdPtr1;
	private String liDiagcdPtr3;
	private String liPlaceOfServiceCd;
	private String liDiagcdPtr2;
	private String liDiagcdPtr4;
	private String liLenOfMedNecessity;
	private String liFamilyPlaningInd;
	private String liRentalUnitPrcInd;
	private String liCopayStatusCd;
	private String liContractVersionId;
	private String hospiceEmployedPrvInd;
	private String liContractTypeCd;
	private double formattedContractPct;
	private double formattedContractTermsDiscPct;
	private String formattedServiceBeginDt;
	private String formattedPrescriptionDt;
	private String formattedRecertificationDt;
	private String formattedBeginTherapyDt;
	private String formattedServiceEndDt;
	private String formattedHemoglobinDt;
	private String formattedSerumCreatineDt;
	private String formattedShippedDt;
	private String formattedLastCertificationDt;
	private String formattedTreatmentTherapyDt;
	private String lastXrayDt;
	private String initialTreatmentDt;
	private String liNoteCd;
	private String liNoteText;
	private String tpoLineNote;
	private String immunizationBatchNbr;
	private String lineItemControlNbr;
	private String liMammogramCertNbr;
	private String heightResult;
	private String hemoglobinResult;
	private String hematocritResult;
	private String epoetinStartDoseRslt;
	private String creatinineResult;
	private String cliaImproveAmendNbr;
	private String referringCliaNbr;
	private String orderPrvContactName;
	private String orderPrvEmail;
	private String orderPrvFax;
	private String orderPrvPhone;
	private String orderPrvPhoneExt;
	private String linkSeqNbr;
	private String reprcdAprvAmbpatgrpcd;
	private String reprcdAprvHcpcsCd;
	private String liAmbPickupAddrLine1;
	private String liAmbPickupAddrLine2;
	private String liAmbPickupCity;
	private String liAmbPickupState;
	private String liAmbPickupZip;
	private String liAmbDropoffLoc;
	private String liAmbDropoffAddrLine1;
	private String liAmbDropoffAddrLine2;
	private String liAmbDropoffCity;
	private String liAmbDropoffState;
	private String liAmbDropoffZip;
	
	private int ambPatientWeight;
	private int ambTransportDistance;
	private String liAmbCertCondInd;
	private String ambTransportReasCd;
	private String liAmbPickupCountry;
	private String liAmbPickupCntrySubd;
	private String liAmbCertCondCd1;
	private String liAmbCertCondCd2;
	private String liAmbCertCondCd3;
	private String liAmbCertCondCd4;
	private String liAmbCertCondCd5;
	private String liAmbDropoffCountry;
	private String liAmbDropoffCntrySubd;
	private String ambRoundTripPurpDesc;
	private String ambStretcherPurpDesc;
	
	
//	Claim Line Provider fields
	private String liProvLocNbr;	
	private String liProvEntityType;
	private String liProvFirstName;
	private String liProvMiddleName;
	private String liProvLastName;
	private String liProvLicNbr;
	private String liProvNpi;	
	private String liProvUpin;
	private String liProvCommNbr;
	private String liProvOthPayerId;
	private String lookupProvType;
	private String liProvAddrLine1;
	private String liProvAddrLine2;
	private String liProvTaxonomyCd;
	private String liProvCity;
	private String liProvState;
	private String liProvZip;
	private String liProvCountry;
	private String liProvCntrySubd;
	
	//claim other subscriber
	private String othSubsSeqNbr;
	private String insuredGrpOrPolNbr;	
	private String benefitsAsgnCertInd;
	private String formattedCheckRemitDt;
	private String payerResponseCd;	
	private String releaseMedRcdFlg;
	private String indivRelationshipCd;
	private int miaCoveredDays;	
	private int miaLifePsychDayCnt;
	private int miaCostDayCnt;
	private String miaClmpmtRemarkCd;
	private String miaClmPmtRemarkCd1;	
	private String miaClmPmtRemarkCd2;	
	private String miaClmPmtRemarkCd3;
	private String miaClmPmtRemarkCd4;
	private int formattedMoaReimburseRate;
	private String moaClmPmtRemarkCd1;
	private String moaClmPmtRemarkCd2;
	private String moaClmPmtRemarkCd3;	
	private String moaClmPmtRemarkCd4;
	private String moaClmPmtRemarkCd5;
	private String otherClmFilingInd;
	private String othPayrOrgName;	
	private String othSubsPayrPayerId;	
	private String othPayrClmadjInd;	
	private String othPayrAddrLine1;	
	private String othPayrPlanId;	
	private String othPayrAddrLine2;	
	private String othPayrSecId;	
	private String othPayrCity;
	private String othPayrState;
	private String othPayrZip;
	private String othPayrCountry;
	private String othPayrCntrySubdCd;	
	private String formattedOthPayrTaxId;
	private String othPayrLocNbr;
	private String othPayrNaic;
	private String othPayrPriorAuthNbr;
	private String othPayrReferralNbr;
	private String othPayrClmCtrlNbr;	
	private String patSignSrcCd;	
	
	private String othPayrProvLocNbr;
	private String othPayrProvLicNbr;
	private String othPayrProvUpin;
	private String othPayrProvCommNbr;	
	private String lookupOthPayrProvType;	
	private String othPayrProvEntityType;
	private String wtxClaimRefUniqNbr ="";//healthspring Unique id IFOX 367728*
	
	private String origFileId;
	private boolean fileTrackingFlag = false;
	
	//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - Start
	private String searchPayerSecId;
	private String searchSubsGrpOrPolNbr;
	//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - End
	//Editable Fileds CHS -- IFOX-00395627	
	private boolean instConditionCodeExpanded = false;
	private boolean instDiagCodeExpanded = false;
	private boolean profConditionCodeExpanded = false;
	private boolean profDiagCodeExpanded = false;
	private boolean instProcedureCodeExpanded = false;
	private boolean instOccurrenceSpanExpanded = false;
	private boolean instValueExpanded = false;
	private boolean instOccurrenceExpanded = false;
	private boolean instTreatmentExpanded = false;
	private boolean instExtCauseInjuryExpanded = false;	
	
	private String hier;
	private String editableCode;
	private String editableType;
	private String editablePOA;
	private String editableDate;
	private String editableFromDt;
	private String editableThruDt;
	private Double editableAmount;
	private String editableEncType;
	
	private String editableMfid;
	private String editableCndSeqNbr;
	private String editableCodeSecMsg;
	
	
	//Editable Fileds CHS -- IFOX-00395627
	
	//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
	private String editableAdjGroupCode;
	private String editableAdjReasonCode;
	private Double editableAdjAmount;
	private int editableAdjQuantity;
	private int editableAdjudSeqNbr;
	private int editableAdjustSeqNbr;
	public String getEditableAdjGroupCode() {
		return editableAdjGroupCode;
	}
	public void setEditableAdjGroupCode(String editableAdjGroupCode) {
		this.editableAdjGroupCode = editableAdjGroupCode;
	}
	public String getEditableAdjReasonCode() {
		return editableAdjReasonCode;
	}
	public void setEditableAdjReasonCode(String editableAdjReasonCode) {
		this.editableAdjReasonCode = editableAdjReasonCode;
	}
	public Double getEditableAdjAmount() {
		return editableAdjAmount;
	}
	public void setEditableAdjAmount(Double editableAdjAmount) {
		this.editableAdjAmount = editableAdjAmount;
	}
	public int getEditableAdjQuantity() {
		return editableAdjQuantity;
	}
	public void setEditableAdjQuantity(int editableAdjQuantity) {
		this.editableAdjQuantity = editableAdjQuantity;
	}
	public int getEditableAdjudSeqNbr() {
		return editableAdjudSeqNbr;
	}
	public void setEditableAdjudSeqNbr(int editableAdjudSeqNbr) {
		this.editableAdjudSeqNbr = editableAdjudSeqNbr;
	}
	public int getEditableAdjustSeqNbr() {
		return editableAdjustSeqNbr;
	}
	public void setEditableAdjustSeqNbr(int editableAdjustSeqNbr) {
		this.editableAdjustSeqNbr = editableAdjustSeqNbr;
	}
	//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
	public boolean isFileTrackingFlag() {
		return fileTrackingFlag;
	}
	public boolean isProfConditionCodeExpanded() {
		return profConditionCodeExpanded;
	}
	public void setProfConditionCodeExpanded(boolean profConditionCodeExpanded) {
		this.profConditionCodeExpanded = profConditionCodeExpanded;
	}
	public boolean isProfDiagCodeExpanded() {
		return profDiagCodeExpanded;
	}
	public void setProfDiagCodeExpanded(boolean profDiagCodeExpanded) {
		this.profDiagCodeExpanded = profDiagCodeExpanded;
	}
	public String getEditableCodeSecMsg() {
		return editableCodeSecMsg;
	}
	public void setEditableCodeSecMsg(String editableCodeSecMsg) {
		this.editableCodeSecMsg = editableCodeSecMsg;
	}
	public String getEditableEncType() {
		return editableEncType;
	}
	public void setEditableEncType(String editableEncType) {
		this.editableEncType = editableEncType;
	}
	public String getEditableMfid() {
		return editableMfid;
	}
	public void setEditableMfid(String editableMfid) {
		this.editableMfid = editableMfid;
	}
	public String getEditableCndSeqNbr() {
		return editableCndSeqNbr;
	}
	public void setEditableCndSeqNbr(String editableCndSeqNbr) {
		this.editableCndSeqNbr = editableCndSeqNbr;
	}
	
	public Double getEditableAmount() {
		return editableAmount;
	}
	public void setEditableAmount(Double editableAmount) {
		this.editableAmount = editableAmount;
	}
	public String getHier() {
		return hier;
	}
	public void setHier(String hier) {
		this.hier = hier;
	}
	public String getEditableCode() {
		return editableCode;
	}
	public void setEditableCode(String editableCode) {
		this.editableCode = editableCode;
	}
	public String getEditableType() {
		return editableType;
	}
	public void setEditableType(String editableType) {
		this.editableType = editableType;
	}
	public String getEditablePOA() {
		return editablePOA;
	}
	public void setEditablePOA(String editablePOA) {
		this.editablePOA = editablePOA;
	}
	public String getEditableDate() {
		return editableDate;
	}
	public void setEditableDate(String editableDate) {
		this.editableDate = editableDate;
	}
	public String getEditableFromDt() {
		return editableFromDt;
	}
	public void setEditableFromDt(String editableFromDt) {
		this.editableFromDt = editableFromDt;
	}
	public String getEditableThruDt() {
		return editableThruDt;
	}
	public void setEditableThruDt(String editableThruDt) {
		this.editableThruDt = editableThruDt;
	}
	
	public boolean isInstConditionCodeExpanded() {
		return instConditionCodeExpanded;
	}
	public void setInstConditionCodeExpanded(boolean instConditionCodeExpanded) {
		this.instConditionCodeExpanded = instConditionCodeExpanded;
	}
	public boolean isInstDiagCodeExpanded() {
		return instDiagCodeExpanded;
	}
	public void setInstDiagCodeExpanded(boolean instDiagCodeExpanded) {
		this.instDiagCodeExpanded = instDiagCodeExpanded;
	}
	public boolean isInstProcedureCodeExpanded() {
		return instProcedureCodeExpanded;
	}
	public void setInstProcedureCodeExpanded(boolean instProcedureCodeExpanded) {
		this.instProcedureCodeExpanded = instProcedureCodeExpanded;
	}
	public boolean isInstOccurrenceSpanExpanded() {
		return instOccurrenceSpanExpanded;
	}
	public void setInstOccurrenceSpanExpanded(boolean instOccurrenceSpanExpanded) {
		this.instOccurrenceSpanExpanded = instOccurrenceSpanExpanded;
	}
	public boolean isInstValueExpanded() {
		return instValueExpanded;
	}
	public void setInstValueExpanded(boolean instValueExpanded) {
		this.instValueExpanded = instValueExpanded;
	}
	public boolean isInstOccurrenceExpanded() {
		return instOccurrenceExpanded;
	}
	public void setInstOccurrenceExpanded(boolean instOccurrenceExpanded) {
		this.instOccurrenceExpanded = instOccurrenceExpanded;
	}
	public boolean isInstTreatmentExpanded() {
		return instTreatmentExpanded;
	}
	public void setInstTreatmentExpanded(boolean instTreatmentExpanded) {
		this.instTreatmentExpanded = instTreatmentExpanded;
	}
	public boolean isInstExtCauseInjuryExpanded() {
		return instExtCauseInjuryExpanded;
	}
	public void setInstExtCauseInjuryExpanded(boolean instExtCauseInjuryExpanded) {
		this.instExtCauseInjuryExpanded = instExtCauseInjuryExpanded;
	}
	public void setFileTrackingFlag(boolean fileTrackingFlag) {
		this.fileTrackingFlag = fileTrackingFlag;
	}
	public String getOrigFileId() {
		return origFileId;
	}
	public void setOrigFileId(String origFileId) {
		this.origFileId = origFileId;
	}
	public boolean getDataChanged() {
		return dataChanged;
	}
	public void setDataChanged(boolean dataChanged) {
		this.dataChanged = dataChanged;
	}

	// Summary search criteria
	public String getSearchSummaryDateInd() { //System.out.println("getSearchSummaryDateInd(" + searchSummaryDateInd + ")");
		return searchSummaryDateInd;
	}
	public void setSearchSummaryDateInd(String searchSummaryDateInd) { //System.out.println("setSearchSummaryDateInd(" + searchSummaryDateInd + ")");
		this.searchSummaryDateInd = searchSummaryDateInd;
	}
	public String getSearchSummaryEncType() { //System.out.println("getSearchSummaryEncType(" + searchSummaryEncType + ")");
		return searchSummaryEncType;
	}
	public void setSearchSummaryEncType(String searchSummaryEncType) { //System.out.println("setSearchSummaryEncType(" + searchSummaryEncType + ")");
		this.searchSummaryEncType = searchSummaryEncType;
	}
	public String getSearchSummaryFromDate() { //System.out.println("getSearchSummaryFromDate(" + searchSummaryFromDate + ")");
		return searchSummaryFromDate;
	}
	public void setSearchSummaryFromDate(String searchSummaryFromDate) { //System.out.println("setSearchSummaryFromDate(" + searchSummaryFromDate + ")");
		this.searchSummaryFromDate = searchSummaryFromDate;
	}
	public String getSearchSummaryGroupStatus() { //System.out.println("getSearchSummaryGroupStatus(" + searchSummaryGroupStatus + ")");
		return searchSummaryGroupStatus;
	}
	public void setSearchSummaryGroupStatus(String searchSummaryGroupStatus) { //System.out.println("setSearchSummaryGroupStatus(" + searchSummaryGroupStatus + ")");
		this.searchSummaryGroupStatus = searchSummaryGroupStatus;
	}
	public String getSearchSummaryToDate() { //System.out.println("getSearchSummaryToDate(" + searchSummaryToDate + ")");
		return searchSummaryToDate;
	}
	public void setSearchSummaryToDate(String searchSummaryToDate) { //System.out.println("setSearchSummaryToDate(" + searchSummaryToDate + ")");
		this.searchSummaryToDate = searchSummaryToDate;
	}

	// Summary search results
	public GridUtil getStatusSummaryGrid() {
		return statusSummaryGrid;
	}
	public void setStatusSummaryGrid(GridUtil statusSummaryGrid) {
		this.statusSummaryGrid = statusSummaryGrid;
	}

	// Detail search criteria
	public String getSearchDetailClaimRefNbr() { //System.out.println("getSearchDetailClaimRefNbr(" + searchDetailClaimRefNbr + ")");
		return searchDetailClaimRefNbr;
	}
	public void setSearchDetailClaimRefNbr(String searchDetailClaimRefNbr) { //System.out.println("setSearchDetailClaimRefNbr(" + searchDetailClaimRefNbr + ")");
		this.searchDetailClaimRefNbr = searchDetailClaimRefNbr;
	}
	public String getSearchDetailDateInd() { //System.out.println("getSearchDetailDateInd(" + searchDetailDateInd + ")");
		return searchDetailDateInd;
	}
	public void setSearchDetailDateInd(String searchDetailDateInd) { //System.out.println("setSearchDetailDateInd(" + searchDetailDateInd + ")");
		this.searchDetailDateInd = searchDetailDateInd;
	}
	public String getSearchDetailEncType() { //System.out.println("getSearchDetailEncType(" + searchDetailEncType + ")");
		return searchDetailEncType;
	}
	public void setSearchDetailEncType(String searchDetailEncType) { //System.out.println("setSearchDetailEncType(" + searchDetailEncType + ")");
		this.searchDetailEncType = searchDetailEncType;
	}
	public String getSearchDetailFromDate() { //System.out.println("getSearchDetailFromDate(" + searchDetailFromDate + ")");
		return searchDetailFromDate;
	}
	public void setSearchDetailFromDate(String searchDetailFromDate) { //System.out.println("setSearchDetailFromDate(" + searchDetailFromDate + ")");
		this.searchDetailFromDate = searchDetailFromDate;
	}
	public String getSearchDetailProcessStatus() {
		return searchDetailProcessStatus;
	}
	public void setSearchDetailProcessStatus(String searchDetailProcessStatus) {
		this.searchDetailProcessStatus = searchDetailProcessStatus;
	}
	public String getSearchDetailGroupStatus() { //System.out.println("getSearchDetailGroupStatus(" + searchDetailGroupStatus + ")");
		return searchDetailGroupStatus;
	}
	public void setSearchDetailGroupStatus(String searchDetailGroupStatus) { //System.out.println("setSearchDetailGroupStatus(" + searchDetailGroupStatus + ")");
		this.searchDetailGroupStatus = searchDetailGroupStatus;
	}
	public String getSearchDetailHicNbr() { //System.out.println("getSearchDetailHicNbr(" + searchDetailHicNbr + ")");
		return searchDetailHicNbr;
	}
	public void setSearchDetailHicNbr(String searchDetailHicNbr) { //System.out.println("setSearchDetailHicNbr(" + searchDetailHicNbr + ")");
		this.searchDetailHicNbr = searchDetailHicNbr;
	}
	public String getSearchDetailToDate() { //System.out.println("getSearchDetailToDate(" + searchDetailToDate + ")");
		return searchDetailToDate;
	}
	public void setSearchDetailToDate(String searchDetailToDate) { //System.out.println("setSearchDetailToDate(" + searchDetailToDate + ")");
		this.searchDetailToDate = searchDetailToDate;
	}
	public String getSearchDetailSubmitterId() { //System.out.println("getSearchDetailSubmitterId(" + searchDetailSubmitterId + ")");
		return searchDetailSubmitterId;
	}
	public void setSearchDetailSubmitterId(String searchDetailSubmitterId) { //System.out.println("setSearchDetailSubmitterId(" + searchDetailSubmitterId + ")");
		this.searchDetailSubmitterId = searchDetailSubmitterId;
	}

	// Claim select values
	public String getSelectedClaimRefNbr() { //System.out.println("getSelectedClaimRefNbr(" + selectedClaimRefNbr + ")");
		return selectedClaimRefNbr;
	}
	public void setSelectedClaimRefNbr(String selectedClaimRefNbr) { //System.out.println("setSelectedClaimRefNbr(" + selectedClaimRefNbr + ")");
		this.selectedClaimRefNbr = selectedClaimRefNbr;
	}
	public String getSelectedClaimRevNbr() { //System.out.println("getSelectedClaimRevNbr(" + selectedClaimRevNbr + ")");
		return selectedClaimRevNbr;
	}
	public void setSelectedClaimRevNbr(String selectedClaimRevNbr) { //System.out.println("setSelectedClaimRevNbr(" + selectedClaimRevNbr + ")");
		this.selectedClaimRevNbr = selectedClaimRevNbr;
	}
	public String getSelectedClaimSeqNbr() { //System.out.println("getSelectedClaimSeqNbr(" + selectedClaimSeqNbr + ")");
		return selectedClaimSeqNbr;
	}
	public void setSelectedClaimSeqNbr(String selectedClaimSeqNbr) { //System.out.println("setSelectedClaimSeqNbr(" + selectedClaimSeqNbr + ")");
		this.selectedClaimSeqNbr = selectedClaimSeqNbr;
	}
	public String getSelectedClaimType() { //System.out.println("getSelectedClaimType(" + selectedClaimType + ")");
		return selectedClaimType;
	}
	public void setSelectedClaimType(String selectedClaimType) { //System.out.println("setSelectedClaimType(" + selectedClaimType + ")");
		this.selectedClaimType = selectedClaimType;
	}

	// Toggles - Institutional
	public boolean isInstClaimCodesExpanded() {
		return instClaimCodesExpanded;
	}
	public void setInstClaimCodesExpanded(boolean instClaimCodesExpanded) {
		this.instClaimCodesExpanded = instClaimCodesExpanded;
	}
	public boolean isInstClaimExpanded() {
		return instClaimExpanded;
	}
	public void setInstClaimExpanded(boolean instClaimExpanded) {
		this.instClaimExpanded = instClaimExpanded;
	}
	public boolean isInstClaimLineAdjudDetailExpanded() {
		return instClaimLineAdjudDetailExpanded;
	}
	public void setInstClaimLineAdjudDetailExpanded(boolean instClaimLineAdjudDetailExpanded) {
		this.instClaimLineAdjudDetailExpanded = instClaimLineAdjudDetailExpanded;
	}
	public boolean isInstClaimLineAdjudExpanded() {
		return instClaimLineAdjudExpanded;
	}
	public void setInstClaimLineAdjudExpanded(boolean instClaimLineAdjudExpanded) {
		this.instClaimLineAdjudExpanded = instClaimLineAdjudExpanded;
	}
	public boolean isInstClaimLineDetailExpanded() {
		return instClaimLineDetailExpanded;
	}
	public void setInstClaimLineDetailExpanded(boolean instClaimLineDetailExpanded) {
		this.instClaimLineDetailExpanded = instClaimLineDetailExpanded;
	}
	public boolean isInstClaimLineExpanded() {
		return instClaimLineExpanded;
	}
	public void setInstClaimLineExpanded(boolean instClaimLineExpanded) {
		this.instClaimLineExpanded = instClaimLineExpanded;
	}
	public boolean isInstClaimLineProvDetailExpanded() {
		return instClaimLineProvDetailExpanded;
	}
	public void setInstClaimLineProvDetailExpanded(boolean instClaimLineProvDetailExpanded) {
		this.instClaimLineProvDetailExpanded = instClaimLineProvDetailExpanded;
	}
	public boolean isInstClaimLineProvExpanded() {
		return instClaimLineProvExpanded;
	}
	public void setInstClaimLineProvExpanded(boolean instClaimLineProvExpanded) {
		this.instClaimLineProvExpanded = instClaimLineProvExpanded;
	}
	public boolean isInstClaimNotesExpanded() {
		return instClaimNotesExpanded;
	}
	public void setInstClaimNotesExpanded(boolean instClaimNotesExpanded) {
		this.instClaimNotesExpanded = instClaimNotesExpanded;
	}
	public boolean isInstClaimOtherSubsDetailExpanded() {
		return instClaimOtherSubsDetailExpanded;
	}
	public void setInstClaimOtherSubsDetailExpanded(boolean instClaimOtherSubsDetailExpanded) {
		this.instClaimOtherSubsDetailExpanded = instClaimOtherSubsDetailExpanded;
	}
	public boolean isInstClaimOtherSubsExpanded() {
		return instClaimOtherSubsExpanded;
	}
	public void setInstClaimOtherSubsExpanded(boolean instClaimOtherSubsExpanded) {
		this.instClaimOtherSubsExpanded = instClaimOtherSubsExpanded;
	}
	public boolean isInstClaimOtherSubsProvDetailExpanded() {
		return instClaimOtherSubsProvDetailExpanded;
	}
	public void setInstClaimOtherSubsProvDetailExpanded(boolean instClaimOtherSubsProvDetailExpanded) {
		this.instClaimOtherSubsProvDetailExpanded = instClaimOtherSubsProvDetailExpanded;
	}
	public boolean isInstClaimOtherSubsProvExpanded() {
		return instClaimOtherSubsProvExpanded;
	}
	public void setInstClaimOtherSubsProvExpanded(boolean instClaimOtherSubsProvExpanded) {
		this.instClaimOtherSubsProvExpanded = instClaimOtherSubsProvExpanded;
	}
	public boolean isInstClaimProvDetailExpanded() {
		return instClaimProvDetailExpanded;
	}
	public void setInstClaimProvDetailExpanded(boolean instClaimProvDetailExpanded) {
		this.instClaimProvDetailExpanded = instClaimProvDetailExpanded;
	}
	public boolean isInstClaimProvExpanded() {
		return instClaimProvExpanded;
	}
	public void setInstClaimProvExpanded(boolean instClaimProvExpanded) {
		this.instClaimProvExpanded = instClaimProvExpanded;
	}
	public boolean isInstErrorsExpanded() {
		return instErrorsExpanded;
	}
	public void setInstErrorsExpanded(boolean instErrorsExpanded) {
		this.instErrorsExpanded = instErrorsExpanded;
	}
	public boolean isInstListExpanded() {
		return instListExpanded;
	}
	public void setInstListExpanded(boolean instListExpanded) {
		this.instListExpanded = instListExpanded;
	}
	public boolean isInstProviderExpanded() {
		return instProviderExpanded;
	}
	public void setInstProviderExpanded(boolean instProviderExpanded) {
		this.instProviderExpanded = instProviderExpanded;
	}
	public boolean isInstSubscriberExpanded() {
		return instSubscriberExpanded;
	}
	public void setInstSubscriberExpanded(boolean instSubscriberExpanded) {
		this.instSubscriberExpanded = instSubscriberExpanded;
	}

	// Toggles - Professional
	public boolean isProfClaimCodesExpanded() {
		return profClaimCodesExpanded;
	}
	public void setProfClaimCodesExpanded(boolean profClaimCodesExpanded) {
		this.profClaimCodesExpanded = profClaimCodesExpanded;
	}
	public boolean isProfClaimExpanded() {
		return profClaimExpanded;
	}
	public void setProfClaimExpanded(boolean profClaimExpanded) {
		this.profClaimExpanded = profClaimExpanded;
	}
	public boolean isProfClaimLineAdjudDetailExpanded() {
		return profClaimLineAdjudDetailExpanded;
	}
	public void setProfClaimLineAdjudDetailExpanded(boolean profClaimLineAdjudDetailExpanded) {
		this.profClaimLineAdjudDetailExpanded = profClaimLineAdjudDetailExpanded;
	}
	public boolean isProfClaimLineAdjudExpanded() {
		return profClaimLineAdjudExpanded;
	}
	public void setProfClaimLineAdjudExpanded(boolean profClaimLineAdjudExpanded) {
		this.profClaimLineAdjudExpanded = profClaimLineAdjudExpanded;
	}
	public boolean isProfClaimLineDetailExpanded() {
		return profClaimLineDetailExpanded;
	}
	public void setProfClaimLineDetailExpanded(boolean profClaimLineDetailExpanded) {
		this.profClaimLineDetailExpanded = profClaimLineDetailExpanded;
	}
	public boolean isProfClaimLineExpanded() {
		return profClaimLineExpanded;
	}
	public void setProfClaimLineExpanded(boolean profClaimLineExpanded) {
		this.profClaimLineExpanded = profClaimLineExpanded;
	}
	public boolean isProfClaimLineProvDetailExpanded() {
		return profClaimLineProvDetailExpanded;
	}
	public void setProfClaimLineProvDetailExpanded(boolean profClaimLineProvDetailExpanded) {
		this.profClaimLineProvDetailExpanded = profClaimLineProvDetailExpanded;
	}
	public boolean isProfClaimLineProvExpanded() {
		return profClaimLineProvExpanded;
	}
	public void setProfClaimLineProvExpanded(boolean profClaimLineProvExpanded) {
		this.profClaimLineProvExpanded = profClaimLineProvExpanded;
	}
	public boolean isProfClaimOtherSubsDetailExpanded() {
		return profClaimOtherSubsDetailExpanded;
	}
	public void setProfClaimOtherSubsDetailExpanded(boolean profClaimOtherSubsDetailExpanded) {
		this.profClaimOtherSubsDetailExpanded = profClaimOtherSubsDetailExpanded;
	}
	public boolean isProfClaimOtherSubsExpanded() {
		return profClaimOtherSubsExpanded;
	}
	public void setProfClaimOtherSubsExpanded(boolean profClaimOtherSubsExpanded) {
		this.profClaimOtherSubsExpanded = profClaimOtherSubsExpanded;
	}
	public boolean isProfClaimOtherSubsProvDetailExpanded() {
		return profClaimOtherSubsProvDetailExpanded;
	}
	public void setProfClaimOtherSubsProvDetailExpanded(boolean profClaimOtherSubsProvDetailExpanded) {
		this.profClaimOtherSubsProvDetailExpanded = profClaimOtherSubsProvDetailExpanded;
	}
	public boolean isProfClaimOtherSubsProvExpanded() {
		return profClaimOtherSubsProvExpanded;
	}
	public void setProfClaimOtherSubsProvExpanded(boolean profClaimOtherSubsProvExpanded) {
		this.profClaimOtherSubsProvExpanded = profClaimOtherSubsProvExpanded;
	}
	public boolean isProfClaimProvDetailExpanded() {
		return profClaimProvDetailExpanded;
	}
	public void setProfClaimProvDetailExpanded(boolean profClaimProvDetailExpanded) {
		this.profClaimProvDetailExpanded = profClaimProvDetailExpanded;
	}
	public boolean isProfClaimProvExpanded() {
		return profClaimProvExpanded;
	}
	public void setProfClaimProvExpanded(boolean profClaimProvExpanded) {
		this.profClaimProvExpanded = profClaimProvExpanded;
	}
	public boolean isProfErrorsExpanded() {
		return profErrorsExpanded;
	}
	public void setProfErrorsExpanded(boolean profErrorsExpanded) {
		this.profErrorsExpanded = profErrorsExpanded;
	}
	public boolean isProfListExpanded() {
		return profListExpanded;
	}
	public void setProfListExpanded(boolean profListExpanded) {
		this.profListExpanded = profListExpanded;
	}
	public boolean isProfProviderExpanded() {
		return profProviderExpanded;
	}
	public void setProfProviderExpanded(boolean profProviderExpanded) {
		this.profProviderExpanded = profProviderExpanded;
	}
	public boolean isProfSubscriberExpanded() {
		return profSubscriberExpanded;
	}
	public void setProfSubscriberExpanded(boolean profSubscriberExpanded) {
		this.profSubscriberExpanded = profSubscriberExpanded;
	}
	/**
	 * @return Returns the firstClaimRefNbr.
	 */
	public String getFirstClaimRefNbr() {
		return firstClaimRefNbr;
	}
	/**
	 * @param firstClaimRefNbr The firstClaimRefNbr to set.
	 */
	public void setFirstClaimRefNbr(String firstClaimRefNbr) {
		this.firstClaimRefNbr = firstClaimRefNbr;
	}
	/**
	 * @return Returns the firstClaimRevNbr.
	 */
	public String getFirstClaimRevNbr() {
		return firstClaimRevNbr;
	}
	/**
	 * @param firstClaimRevNbr The firstClaimRevNbr to set.
	 */
	public void setFirstClaimRevNbr(String firstClaimRevNbr) {
		this.firstClaimRevNbr = firstClaimRevNbr;
	}
	/**
	 * @return Returns the firstClaimSeqNbr.
	 */
	public String getFirstClaimSeqNbr() {
		return firstClaimSeqNbr;
	}
	/**
	 * @param firstClaimSeqNbr The firstClaimSeqNbr to set.
	 */
	public void setFirstClaimSeqNbr(String firstClaimSeqNbr) {
		this.firstClaimSeqNbr = firstClaimSeqNbr;
	}
	/**
	 * @return Returns the firstClaimType.
	 */
	public String getFirstClaimType() {
		return firstClaimType;
	}
	/**
	 * @param firstClaimType The firstClaimType to set.
	 */
	public void setFirstClaimType(String firstClaimType) {
		this.firstClaimType = firstClaimType;
	}
	/**
	 * @return Returns the focusField.
	 */
	public String getFocusField() {
		return focusField;
	}
	/**
	 * @param focusField The focusField to set.
	 */
	public void setFocusField(String focusField) {
		this.focusField = focusField;
	}
	/**
	 * @return Returns the subscriberChanged.
	 */
	public boolean isSubscriberChanged() {
		return subscriberChanged;
	}
	/**
	 * @param subscriberChanged The subscriberChanged to set.
	 */
	public void setSubscriberChanged(boolean subscriberChanged) {
		this.subscriberChanged = subscriberChanged;
	}
	/**
	 * @return Returns the subscriberDisplayState.
	 */
	public String getSubscriberDisplayState() {
		return subscriberDisplayState;
	}
	/**
	 * @param subscriberDisplayState The subscriberDisplayState to set.
	 */
	public void setSubscriberDisplayState(String subscriberDisplayState) {
		this.subscriberDisplayState = subscriberDisplayState;
	}
	/**
	 * @return Returns the claimChanged.
	 */
	public boolean isClaimChanged() {
		return claimChanged;
	}
	/**
	 * @param claimChanged The claimChanged to set.
	 */
	public void setClaimChanged(boolean claimChanged) {
		this.claimChanged = claimChanged;
	}
	/**
	 * @return Returns the claimDisplayState.
	 */
	public String getClaimDisplayState() {
		return claimDisplayState;
	}
	/**
	 * @param claimDisplayState The claimDisplayState to set.
	 */
	public void setClaimDisplayState(String claimDisplayState) {
		this.claimDisplayState = claimDisplayState;
	}	
	
	/**
	 * @return Returns the providerChanged.
	 */
	public boolean isProviderChanged() {
		return providerChanged;
	}
	/**
	 * @param providerChanged The providerChanged to set.
	 */
	public void setProviderChanged(boolean providerChanged) {
		this.providerChanged = providerChanged;
	}
	/**
	 * @return Returns the providerDisplayState.
	 */
	public String getProviderDisplayState() {
		return providerDisplayState;
	}
	/**
	 * @param providerDisplayState The providerDisplayState to set.
	 */
	public void setProviderDisplayState(String providerDisplayState) {
		this.providerDisplayState = providerDisplayState;
	}
	/**
	 * @return Returns the displayMessage.
	 */
	public String getDisplayMessage() {
		return displayMessage;
	}
	/**
	 * @param displayMessage The displayMessage to set.
	 */
	public void setDisplayMessage(String displayMessage) {
		this.displayMessage = displayMessage;
	}
	
	
	/**
	 * @return Returns the subsFirstName.
	 */
	public String getSubsFirstName() {
		return subsFirstName;
	}
	/**
	 * @param subsFirstName The subsFirstName to set.
	 */
	public void setSubsFirstName(String subsFirstName) {
		this.subsFirstName = subsFirstName;
	}
	
	
	
	
	/**
	 * @return Returns the prevMenu.
	 */
	public String getPrevMenu() {
		return prevMenu;
	}
	/**
	 * @param prevMenu The prevMenu to set.
	 */
	public void setPrevMenu(String prevMenu) {
		this.prevMenu = prevMenu;
	}
	/**
	 * @return Returns the prevMethod.
	 */
	public String getPrevMethod() {
		return prevMethod;
	}
	/**
	 * @param prevMethod The prevMethod to set.
	 */
	public void setPrevMethod(String prevMethod) {
		this.prevMethod = prevMethod;
	}
	/**
	 * @return Returns the formattedSubsDob.
	 */
	public String getFormattedSubsDob() {
		return formattedSubsDob;
	}
	/**
	 * @param formattedSubsDob The formattedSubsDob to set.
	 */
	public void setFormattedSubsDob(String formattedSubsDob) {
		this.formattedSubsDob = formattedSubsDob;
	}
	/**
	 * @return Returns the formattedSubsSsn.
	 */
	public String getFormattedSubsSsn() {
		return formattedSubsSsn;
	}
	/**
	 * @param formattedSubsSsn The formattedSubsSsn to set.
	 */
	public void setFormattedSubsSsn(String formattedSubsSsn) {
		this.formattedSubsSsn = formattedSubsSsn;
	}
	/**
	 * @return Returns the processStatus.
	 */
	public String getProcessStatus() {
		return processStatus;
	}
	/**
	 * @param processStatus The processStatus to set.
	 */
	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}
	/**
	 * @return Returns the subsAddrLine1.
	 */
	public String getSubsAddrLine1() {
		return subsAddrLine1;
	}
	/**
	 * @param subsAddrLine1 The subsAddrLine1 to set.
	 */
	public void setSubsAddrLine1(String subsAddrLine1) {
		this.subsAddrLine1 = subsAddrLine1;
	}
	/**
	 * @return Returns the subsAddrLine2.
	 */
	public String getSubsAddrLine2() {
		return subsAddrLine2;
	}
	/**
	 * @param subsAddrLine2 The subsAddrLine2 to set.
	 */
	public void setSubsAddrLine2(String subsAddrLine2) {
		this.subsAddrLine2 = subsAddrLine2;
	}
	/**
	 * @return Returns the subsCity.
	 */
	public String getSubsCity() {
		return subsCity;
	}
	/**
	 * @param subsCity The subsCity to set.
	 */
	public void setSubsCity(String subsCity) {
		this.subsCity = subsCity;
	}
	/**
	 * @return Returns the subsHicNbr.
	 */
	public String getSubsHicNbr() {
		return subsHicNbr;
	}
	/**
	 * @param subsHicNbr The subsHicNbr to set.
	 */
	public void setSubsHicNbr(String subsHicNbr) {
		this.subsHicNbr = subsHicNbr;
	}
	
	public String getMbi() {
		return mbi;
	}
	public void setMbi(String mbi) {
		this.mbi = mbi;
	}
	
	// securedHicNbr
		public String getSecuredHicNbr() {
			if ("M".equalsIgnoreCase(CustSentMbiInd)) {
				return mbi;
			} else {
				return subsHicNbr;
			}
		}

		public String getCustmFlag() {
			return CustSentMbiInd;
		}

		public void setCustmFlag(String CustSentMbiInd) {
			this.CustSentMbiInd = CustSentMbiInd;
		}
	/**
	 * @return Returns the subsLastName.
	 */
	public String getSubsLastName() {
		return subsLastName;
	}
	/**
	 * @param subsLastName The subsLastName to set.
	 */
	public void setSubsLastName(String subsLastName) {
		this.subsLastName = subsLastName;
	}
	/**
	 * @return Returns the subsMiddleName.
	 */
	public String getSubsMiddleName() {
		return subsMiddleName;
	}
	/**
	 * @param subsMiddleName The subsMiddleName to set.
	 */
	public void setSubsMiddleName(String subsMiddleName) {
		this.subsMiddleName = subsMiddleName;
	}
	/**
	 * @return Returns the subsSex.
	 */
	public String getSubsSex() {
		return subsSex;
	}
	/**
	 * @param subsSex The subsSex to set.
	 */
	public void setSubsSex(String subsSex) {
		this.subsSex = subsSex;
	}
	/**
	 * @return Returns the subsState.
	 */
	public String getSubsState() {
		return subsState;
	}
	/**
	 * @param subsState The subsState to set.
	 */
	public void setSubsState(String subsState) {
		this.subsState = subsState;
	}
	/**
	 * @return Returns the subsZip.
	 */
	public String getSubsZip() {
		return subsZip;
	}
	/**
	 * @param subsZip The subsZip to set.
	 */
	public void setSubsZip(String subsZip) {
		this.subsZip = subsZip;
	}
	
	
	/**
	 * @return Returns the placeOfService.
	 */
	public String getPlaceOfService() {
		return placeOfService;
	}
	/**
	 * @param placeOfService The placeOfService to set.
	 */
	public void setPlaceOfService(String placeOfService) {
		this.placeOfService = placeOfService;
	}

	public String getClmFacTypeCd() {
		return clmFacTypeCd;
	}
	public void setClmFacTypeCd(String clmFacTypeCd) {
		this.clmFacTypeCd = clmFacTypeCd;
	}
	public String getAdmitDt() {
		return admitDt;
	}
	public String getFormattedAdmitDt() {
		return DateFormatter.reFormat(admitDt,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	public void setAdmitDt(String admitDt) {
		this.admitDt = admitDt;
	}
	public void setFormattedAdmitDt(String admitDt) {
		this.admitDt = DateFormatter.reFormat(admitDt,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}
	public String getAdmitHour() {
		return admitHour;
	}
	public void setAdmitHour(String admitHour) {
		this.admitHour = admitHour;
	}
	public String getAdmitSourceCd() {
		return admitSourceCd;
	}
	public void setAdmitSourceCd(String admitSourceCd) {
		this.admitSourceCd = admitSourceCd;
	}
	public String getAdmitType() {
		return admitType;
	}
	public void setAdmitType(String admitType) {
		this.admitType = admitType;
	}
	public String getPatientStatusCd() {
		return patientStatusCd;
	}
	public void setPatientStatusCd(String patientStatusCd) {
		this.patientStatusCd = patientStatusCd;
	}
	public String getHospAdmitDt() {
		return hospAdmitDt;
	}
	public String getFormattedHospAdmitDt() {
		return DateFormatter.reFormat(hospAdmitDt,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	public void setHospAdmitDt(String hospAdmitDt) {
		this.hospAdmitDt = hospAdmitDt;
	}
	public void setFormattedHospAdmitDt(String hospAdmitDt) {
		this.hospAdmitDt = DateFormatter.reFormat(hospAdmitDt,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}
	public String getHospDischargeDt() {
		return hospDischargeDt;
	}
	public String getFormattedHospDischargeDt() {
		return DateFormatter.reFormat(hospDischargeDt,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
	}
	public void setHospDischargeDt(String hospDischargeDt) {
		this.hospDischargeDt = hospDischargeDt;
	}
	public void setFormattedHospDischargeDt(String hospDischargeDt) {
		this.hospDischargeDt = DateFormatter.reFormat(hospDischargeDt,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
	}

	
	public String getAmbDropoffAddrLine1() {
		return ambDropoffAddrLine1;
	}
	public void setAmbDropoffAddrLine1(String ambDropoffAddrLine1) {
		this.ambDropoffAddrLine1 = ambDropoffAddrLine1;
	}
	public String getAmbDropoffAddrLine2() {
		return ambDropoffAddrLine2;
	}
	public void setAmbDropoffAddrLine2(String ambDropoffAddrLine2) {
		this.ambDropoffAddrLine2 = ambDropoffAddrLine2;
	}
	public String getAmbDropoffCity() {
		return ambDropoffCity;
	}
	public void setAmbDropoffCity(String ambDropoffCity) {
		this.ambDropoffCity = ambDropoffCity;
	}
	public String getAmbDropoffLoc() {
		return ambDropoffLoc;
	}
	public void setAmbDropoffLoc(String ambDropoffLoc) {
		this.ambDropoffLoc = ambDropoffLoc;
	}
	public String getAmbDropoffState() {
		return ambDropoffState;
	}
	public void setAmbDropoffState(String ambDropoffState) {
		this.ambDropoffState = ambDropoffState;
	}
	public String getAmbDropoffZip() {
		return ambDropoffZip;
	}
	public void setAmbDropoffZip(String ambDropoffZip) {
		this.ambDropoffZip = ambDropoffZip;
	}

	public String getAmbPickupAddrLine1() {
		return ambPickupAddrLine1;
	}
	public void setAmbPickupAddrLine1(String ambPickupAddrLine1) {
		this.ambPickupAddrLine1 = ambPickupAddrLine1;
	}
	public String getAmbPickupAddrLine2() {
		return ambPickupAddrLine2;
	}
	public void setAmbPickupAddrLine2(String ambPickupAddrLine2) {
		this.ambPickupAddrLine2 = ambPickupAddrLine2;
	}
	public String getAmbPickupZip() {
		return ambPickupZip;
	}
	public void setAmbPickupZip(String ambPickupZip) {
		this.ambPickupZip = ambPickupZip;
	}
	public String getAmbPickupCity() {
		return ambPickupCity;
	}
	public void setAmbPickupCity(String ambPickupCity) {
		this.ambPickupCity = ambPickupCity;
	}
	public String getAmbPickupState() {
		return ambPickupState;
	}
	public void setAmbPickupState(String ambPickupState) {
		this.ambPickupState = ambPickupState;
	}
	public String getCliaNbr() {
		return cliaNbr;
	}
	public void setCliaNbr(String cliaNbr) {
		this.cliaNbr = cliaNbr;
	}
	public String getMammogramCertNbr() {
		return mammogramCertNbr;
	}
	public void setMammogramCertNbr(String mammogramCertNbr) {
		this.mammogramCertNbr = mammogramCertNbr;
	}
	/**
	 * @return Returns the billPrvAddrLine1.
	 */
	public String getBillPrvAddrLine1() {
		return billPrvAddrLine1;
	}
	/**
	 * @param billPrvAddrLine1 The billPrvAddrLine1 to set.
	 */
	public void setBillPrvAddrLine1(String billPrvAddrLine1) {
		this.billPrvAddrLine1 = billPrvAddrLine1;
	}
	/**
	 * @return Returns the billPrvAddrLine2.
	 */
	public String getBillPrvAddrLine2() {
		return billPrvAddrLine2;
	}
	/**
	 * @param billPrvAddrLine2 The billPrvAddrLine2 to set.
	 */
	public void setBillPrvAddrLine2(String billPrvAddrLine2) {
		this.billPrvAddrLine2 = billPrvAddrLine2;
	}
	/**
	 * @return Returns the formattedBillPrvAffilTaxId.
	 */
	public String getFormattedBillPrvAffilTaxId() {
		return formattedBillPrvAffilTaxId;
	}
	/**
	 * @param billPrvAffilTaxId The billPrvAffilTaxId to set.
	 */
	public void setFormattedBillPrvAffilTaxId(String formattedBillPrvAffilTaxId) {
		this.formattedBillPrvAffilTaxId = formattedBillPrvAffilTaxId;
	}
	/**
	 * @return Returns the billPrvCity.
	 */
	public String getBillPrvCity() {
		return billPrvCity;
	}
	/**
	 * @param billPrvCity The billPrvCity to set.
	 */
	public void setBillPrvCity(String billPrvCity) {
		this.billPrvCity = billPrvCity;
	}
	/**
	 * @return Returns the billPrvComNbr1.
	 */
	public String getBillPrvComNbr1() {
		return billPrvComNbr1;
	}
	/**
	 * @param billPrvComNbr1 The billPrvComNbr1 to set.
	 */
	public void setBillPrvComNbr1(String billPrvComNbr1) {
		this.billPrvComNbr1 = billPrvComNbr1;
	}
	/**
	 * @return Returns the billPrvComNbr2.
	 */
	public String getBillPrvComNbr2() {
		return billPrvComNbr2;
	}
	/**
	 * @param billPrvComNbr2 The billPrvComNbr2 to set.
	 */
	public void setBillPrvComNbr2(String billPrvComNbr2) {
		this.billPrvComNbr2 = billPrvComNbr2;
	}
	/**
	 * @return Returns the billPrvComNbr3.
	 */
	public String getBillPrvComNbr3() {
		return billPrvComNbr3;
	}
	/**
	 * @param billPrvComNbr3 The billPrvComNbr3 to set.
	 */
	public void setBillPrvComNbr3(String billPrvComNbr3) {
		this.billPrvComNbr3 = billPrvComNbr3;
	}
	/**
	 * @return Returns the billPrvComNbrQual1.
	 */
	public String getBillPrvComNbrQual1() {
		return billPrvComNbrQual1;
	}
	/**
	 * @param billPrvComNbrQual1 The billPrvComNbrQual1 to set.
	 */
	public void setBillPrvComNbrQual1(String billPrvComNbrQual1) {
		this.billPrvComNbrQual1 = billPrvComNbrQual1;
	}
	/**
	 * @return Returns the billPrvComNbrQual2.
	 */
	public String getBillPrvComNbrQual2() {
		return billPrvComNbrQual2;
	}
	/**
	 * @param billPrvComNbrQual2 The billPrvComNbrQual2 to set.
	 */
	public void setBillPrvComNbrQual2(String billPrvComNbrQual2) {
		this.billPrvComNbrQual2 = billPrvComNbrQual2;
	}
	/**
	 * @return Returns the billPrvComNbrQual3.
	 */
	public String getBillPrvComNbrQual3() {
		return billPrvComNbrQual3;
	}
	/**
	 * @param billPrvComNbrQual3 The billPrvComNbrQual3 to set.
	 */
	public void setBillPrvComNbrQual3(String billPrvComNbrQual3) {
		this.billPrvComNbrQual3 = billPrvComNbrQual3;
	}
	/**
	 * @return Returns the billPrvNpi.
	 */
	public String getBillPrvNpi() {
		return billPrvNpi;
	}
	/**
	 * @param billPrvNpi The billPrvNpi to set.
	 */
	public void setBillPrvNpi(String billPrvNpi) {
		this.billPrvNpi = billPrvNpi;
	}
	/**
	 * @return Returns the billPrvOrgName.
	 */
	public String getBillPrvOrgName() {
		return billPrvOrgName;
	}
	/**
	 * @param billPrvOrgName The billPrvOrgName to set.
	 */
	public void setBillPrvOrgName(String billPrvOrgName) {
		this.billPrvOrgName = billPrvOrgName;
	}
	/**
	 * @return Returns the billPrvState.
	 */
	public String getBillPrvState() {
		return billPrvState;
	}
	/**
	 * @param billPrvState The billPrvState to set.
	 */
	public void setBillPrvState(String billPrvState) {
		this.billPrvState = billPrvState;
	}
	/**
	 * @return Returns the billPrvTaxonomyCd.
	 */
	public String getBillPrvTaxonomyCd() {
		return billPrvTaxonomyCd;
	}
	/**
	 * @param billPrvTaxonomyCd The billPrvTaxonomyCd to set.
	 */
	public void setBillPrvTaxonomyCd(String billPrvTaxonomyCd) {
		this.billPrvTaxonomyCd = billPrvTaxonomyCd;
	}
	/**
	 * @return Returns the billPrvZip.
	 */
	public String getBillPrvZip() {
		return billPrvZip;
	}
	/**
	 * @param billPrvZip The billPrvZip to set.
	 */
	public void setBillPrvZip(String billPrvZip) {
		this.billPrvZip = billPrvZip;
	}
	
	/**
	 * @return Returns the billPrvCountry.
	 */
	public String getBillPrvCountry() {
		return billPrvCountry;
	}
	/**
	 * @param billPrvCountry The billPrvCountry to set.
	 */
	public void setBillPrvCountry(String billPrvCountry) {
		this.billPrvCountry = billPrvCountry;
	}

	/**
	 * @return Returns the billPrvCntrySubdCd.
	 */
	public String getBillPrvCntrySubdCd() {
		return billPrvCntrySubdCd;
	}
	/**
	 * @param billPrvCntrySubdCd The billPrvCntrySubdCd to set.
	 */
	public void setBillPrvCntrySubdCd(String billPrvCntrySubdCd) {
		this.billPrvCntrySubdCd = billPrvCntrySubdCd;
	}
	public String getBillPrvLicNbr() {
		return billPrvLicNbr;
	}
	public void setBillPrvLicNbr(String billPrvLicNbr) {
		this.billPrvLicNbr = billPrvLicNbr;
	}
	public String getFormattedBillPrvSsn() {
		return formattedBillPrvSsn;
	}
	public void setFormattedBillPrvSsn(String formattedBillPrvSsn) {
		this.formattedBillPrvSsn = formattedBillPrvSsn;
	}
	public String getBillPrvUpin() {
		return billPrvUpin;
	}
	public void setBillPrvUpin(String billPrvUpin) {
		this.billPrvUpin = billPrvUpin;
	}
	/**
	 * @return Returns the p2prvAddrLine1.
	 */
	public String getP2prvAddrLine1() {
		return p2prvAddrLine1;
	}
	/**
	 * @param addrLine1 The p2prvAddrLine1 to set.
	 */
	public void setP2prvAddrLine1(String addrLine1) {
		p2prvAddrLine1 = addrLine1;
	}
	/**
	 * @return Returns the p2prvAddrLine2.
	 */
	public String getP2prvAddrLine2() {
		return p2prvAddrLine2;
	}
	/**
	 * @param addrLine2 The p2prvAddrLine2 to set.
	 */
	public void setP2prvAddrLine2(String addrLine2) {
		p2prvAddrLine2 = addrLine2;
	}
	/**
	 * @return Returns the p2prvCity.
	 */
	public String getP2prvCity() {
		return p2prvCity;
	}
	/**
	 * @param city The p2prvCity to set.
	 */
	public void setP2prvCity(String city) {
		p2prvCity = city;
	}
	/**
	 * @return Returns the p2prvState.
	 */
	public String getP2prvState() {
		return p2prvState;
	}
	/**
	 * @param state The p2prvState to set.
	 */
	public void setP2prvState(String state) {
		p2prvState = state;
	}
	/**
	 * @return Returns the p2prvZip.
	 */
	public String getP2prvZip() {
		return p2prvZip;
	}
	/**
	 * @param zip The p2prvZip to set.
	 */
	public void setP2prvZip(String zip) {
		p2prvZip = zip;
	}	
	
	/**
	 * @return Returns the billPrvEntityType.
	 */
	public String getBillPrvEntityType() {
		return billPrvEntityType;
	}
	/**
	 * @param billPrvEntityType The billPrvEntityType to set.
	 */
	public void setBillPrvEntityType(String billPrvEntityType) {
		this.billPrvEntityType = billPrvEntityType;
	}
	/**
	 * @return Returns the billPrvFirstName.
	 */
	public String getBillPrvFirstName() {
		return billPrvFirstName;
	}
	/**
	 * @param billPrvFirstName The billPrvFirstName to set.
	 */
	public void setBillPrvFirstName(String billPrvFirstName) {
		this.billPrvFirstName = billPrvFirstName;
	}
	/**
	 * @return Returns the billPrvMiddleName.
	 */
	public String getBillPrvMiddleName() {
		return billPrvMiddleName;
	}
	/**
	 * @param billPrvMiddleName The billPrvMiddleName to set.
	 */
	public void setBillPrvMiddleName(String billPrvMiddleName) {
		this.billPrvMiddleName = billPrvMiddleName;
	}
	/**
	 * @return Returns the p2prvEntityType.
	 */
	public String getP2prvEntityType() {
		return p2prvEntityType;
	}
	/**
	 * @param entityType The p2prvEntityType to set.
	 */
	public void setP2prvEntityType(String entityType) {
		p2prvEntityType = entityType;
	}	
	
	
	/**
	 * @return Returns the p2prvCountry.
	 */
	public String getP2prvCountry() {
		return p2prvCountry;
	}
	/**
	 * @param country The p2prvCountry to set.
	 */
	public void setP2prvCountry(String country) {
		p2prvCountry = country;
	}
	
	
	/**
	 * @return Returns the p2prvCntrySubdCd.
	 */
	public String getP2prvCntrySubdCd() {
		return p2prvCntrySubdCd;
	}
	/**
	 * @param cntrySubdCd The p2prvCntrySubdCd to set.
	 */
	public void setP2prvCntrySubdCd(String cntrySubdCd) {
		
		p2prvCntrySubdCd = cntrySubdCd;
		System.out.println(" From Form p2prvCntrySubdCd==  " + p2prvCntrySubdCd);
	}
	/**
	 * @return Returns the billPrvLastName.
	 */
	public String getBillPrvLastName() {
		return billPrvLastName;
	}
	/**
	 * @param billPrvLastName The billPrvLastName to set.
	 */
	public void setBillPrvLastName(String billPrvLastName) {
		this.billPrvLastName = billPrvLastName;
	}	
	
	/**
	 * @return Returns the clmProviderDisplayState.
	 */
	public String getClmProviderDisplayState() {
		return clmProviderDisplayState;
	}
	/**
	 * @param clmProviderDisplayState The clmProviderDisplayState to set.
	 */
	public void setClmProviderDisplayState(String clmProviderDisplayState) {
		this.clmProviderDisplayState = clmProviderDisplayState;
	}
	/**
	 * @return Returns the clmPrvChanged.
	 */
	public boolean isClmPrvChanged() {
		return clmPrvChanged;
	}
	/**
	 * @param clmPrvChanged The clmPrvChanged to set.
	 */
	public void setClmPrvChanged(boolean clmPrvChanged) {
		this.clmPrvChanged = clmPrvChanged;
	}
	
	/**
	 * @return Returns the provAddrLine1.
	 */
	public String getProvAddrLine1() {
		return provAddrLine1;
	}
	/**
	 * @param provAddrLine1 The provAddrLine1 to set.
	 */
	public void setProvAddrLine1(String provAddrLine1) {
		this.provAddrLine1 = provAddrLine1;
	}
	/**
	 * @return Returns the provAddrLine2.
	 */
	public String getProvAddrLine2() {
		return provAddrLine2;
	}
	/**
	 * @param provAddrLine2 The provAddrLine2 to set.
	 */
	public void setProvAddrLine2(String provAddrLine2) {
		this.provAddrLine2 = provAddrLine2;
	}
	/**
	 * @return Returns the provCity.
	 */
	public String getProvCity() {
		return provCity;
	}
	/**
	 * @param provCity The provCity to set.
	 */
	public void setProvCity(String provCity) {
		this.provCity = provCity;
	}
	/**
	 * @return Returns the provEntityType.
	 */
	public String getProvEntityType() {
		return provEntityType;
	}
	/**
	 * @param provEntityType The provEntityType to set.
	 */
	public void setProvEntityType(String provEntityType) {
		this.provEntityType = provEntityType;
	}
	public String getProvOrgName() {
		return provOrgName;
	}
	public void setProvOrgName(String provOrgName) {
		this.provOrgName = provOrgName;
	}
	/**
	 * @return Returns the provFirstName.
	 */
	public String getProvFirstName() {
		return provFirstName;
	}
	/**
	 * @param provFirstName The provFirstName to set.
	 */
	public void setProvFirstName(String provFirstName) {
		this.provFirstName = provFirstName;
	}
	/**
	 * @return Returns the provLastName.
	 */
	public String getProvLastName() {
		return provLastName;
	}
	/**
	 * @param provLastName The provLastName to set.
	 */
	public void setProvLastName(String provLastName) {
		this.provLastName = provLastName;
	}
	/**
	 * @return Returns the provMiddleName.
	 */
	public String getProvMiddleName() {
		return provMiddleName;
	}
	/**
	 * @param provMiddleName The provMiddleName to set.
	 */
	public void setProvMiddleName(String provMiddleName) {
		this.provMiddleName = provMiddleName;
	}
	/**
	 * @return Returns the provNpi.
	 */
	public String getProvNpi() {
		return provNpi;
	}
	/**
	 * @param provNpi The provNpi to set.
	 */
	public void setProvNpi(String provNpi) {
		this.provNpi = provNpi;
	}
	/**
	 * @return Returns the provState.
	 */
	public String getProvState() {
		return provState;
	}
	/**
	 * @param provState The provState to set.
	 */
	public void setProvState(String provState) {
		this.provState = provState;
	}
	/**
	 * @return Returns the provTaxonomyCd.
	 */
	public String getProvTaxonomyCd() {
		return provTaxonomyCd;
	}
	/**
	 * @param provTaxonomyCd The provTaxonomyCd to set.
	 */
	public void setProvTaxonomyCd(String provTaxonomyCd) {
		this.provTaxonomyCd = provTaxonomyCd;
	}
	/**
	 * @return Returns the provZip.
	 */
	public String getProvZip() {
		return provZip;
	}
	/**
	 * @param provZip The provZip to set.
	 */
	public void setProvZip(String provZip) {
		this.provZip = provZip;
	}
	
	
	/**
	 * @return Returns the provCntrySubd.
	 */
	public String getProvCntrySubd() {
		return provCntrySubd;
	}
	/**
	 * @param provCntrySubd The provCntrySubd to set.
	 */
	public void setProvCntrySubd(String provCntrySubd) {
		this.provCntrySubd = provCntrySubd;
	}
	/**
	 * @return Returns the provCommNbr.
	 */
	public String getProvCommNbr() {
		return provCommNbr;
	}
	/**
	 * @param provCommNbr The provCommNbr to set.
	 */
	public void setProvCommNbr(String provCommNbr) {
		this.provCommNbr = provCommNbr;
	}
	/**
	 * @return Returns the provCountry.
	 */
	public String getProvCountry() {
		return provCountry;
	}
	/**
	 * @param provCountry The provCountry to set.
	 */
	public void setProvCountry(String provCountry) {
		this.provCountry = provCountry;
	}
	/**
	 * @return Returns the provLicNbr.
	 */
	public String getProvLicNbr() {
		return provLicNbr;
	}
	/**
	 * @param provLicNbr The provLicNbr to set.
	 */
	public void setProvLicNbr(String provLicNbr) {
		this.provLicNbr = provLicNbr;
	}
	/**
	 * @return Returns the provLocNbr.
	 */
	public String getProvLocNbr() {
		return provLocNbr;
	}
	/**
	 * @param provLocNbr The provLocNbr to set.
	 */
	public void setProvLocNbr(String provLocNbr) {
		this.provLocNbr = provLocNbr;
	}
	/**
	 * @return Returns the provOthPayerId.
	 */
	public String getProvOthPayerId() {
		return provOthPayerId;
	}
	/**
	 * @param provOthPayerId The provOthPayerId to set.
	 */
	public void setProvOthPayerId(String provOthPayerId) {
		this.provOthPayerId = provOthPayerId;
	}
	/**
	 * @return Returns the provType.
	 */
	public String getProvType() {
		return provType;
	}
	/**
	 * @param provType The provType to set.
	 */
	public void setProvType(String provType) {
		this.provType = provType;
	}
	/**
	 * @return Returns the provUpin.
	 */
	public String getProvUpin() {
		return provUpin;
	}
	/**
	 * @param provUpin The provUpin to set.
	 */
	public void setProvUpin(String provUpin) {
		this.provUpin = provUpin;
	}	
	
	/**
	 * @return Returns the clmProviderExist.
	 */
	public String getClmProviderExist() {
		return clmProviderExist;
	}
	/**
	 * @param clmProviderExist The clmProviderExist to set.
	 */
	public void setClmProviderExist(String clmProviderExist) {
		this.clmProviderExist = clmProviderExist;
	}
		
	/**
	 * @return Returns the billProviderExist.
	 */
	public String getBillProviderExist() {
		return billProviderExist;
	}
	/**
	 * @param billProviderExist The billProviderExist to set.
	 */
	public void setBillProviderExist(String billProviderExist) {
		this.billProviderExist = billProviderExist;
	}
	/**
	 * @return Returns the subsCntrySubdCd.
	 */
	public String getSubsCntrySubdCd() {
		return subsCntrySubdCd;
	}
	/**
	 * @param subsCntrySubdCd The subsCntrySubdCd to set.
	 */
	public void setSubsCntrySubdCd(String subsCntrySubdCd) {
		this.subsCntrySubdCd = subsCntrySubdCd;
	}
	/**
	 * @return Returns the subsCountry.
	 */
	public String getSubsCountry() {
		return subsCountry;
	}
	/**
	 * @param subsCountry The subsCountry to set.
	 */
	public void setSubsCountry(String subsCountry) {
		this.subsCountry = subsCountry;
	}
	/**
	 * @return Returns the subsEntityType.
	 */
	public String getSubsEntityType() {
		return subsEntityType;
	}
	/**
	 * @param subsEntityType The subsEntityType to set.
	 */
	public void setSubsEntityType(String subsEntityType) {
		this.subsEntityType = subsEntityType;
	}
	/**
	 * @return Returns the subsFilingIndCd.
	 */
	public String getSubsFilingIndCd() {
		return subsFilingIndCd;
	}
	/**
	 * @param subsFilingIndCd The subsFilingIndCd to set.
	 */
	public void setSubsFilingIndCd(String subsFilingIndCd) {
		this.subsFilingIndCd = subsFilingIndCd;
	}
	/**
	 * @return Returns the subsGrpOrPolNbr.
	 */
	public String getSubsGrpOrPolNbr() {
		return subsGrpOrPolNbr;
	}
	/**
	 * @param subsGrpOrPolNbr The subsGrpOrPolNbr to set.
	 */
	public void setSubsGrpOrPolNbr(String subsGrpOrPolNbr) {
		this.subsGrpOrPolNbr = subsGrpOrPolNbr;
	}
	/**
	 * @return Returns the subsInsuranceTypeCd.
	 */
	public String getSubsInsuranceTypeCd() {
		return subsInsuranceTypeCd;
	}
	/**
	 * @param subsInsuranceTypeCd The subsInsuranceTypeCd to set.
	 */
	public void setSubsInsuranceTypeCd(String subsInsuranceTypeCd) {
		this.subsInsuranceTypeCd = subsInsuranceTypeCd;
	}
	/**
	 * @return Returns the subsMemberId.
	 */
	public String getSubsMemberId() {
		return subsMemberId;
	}
	/**
	 * @param subsMemberId The subsMemberId to set.
	 */
	public void setSubsMemberId(String subsMemberId) {
		this.subsMemberId = subsMemberId;
	}
	/**
	 * @return Returns the subsPatDod.
	 */
	public String getSubsPatDod() {
		return subsPatDod;
	}
	/**
	 * @param subsPatDod The subsPatDod to set.
	 */
	public void setSubsPatDod(String subsPatDod) {
		this.subsPatDod = subsPatDod;
	}
	/**
	 * @return Returns the subsPatPregnantInd.
	 */
	public String getSubsPatPregnantInd() {
		return subsPatPregnantInd;
	}
	/**
	 * @param subsPatPregnantInd The subsPatPregnantInd to set.
	 */
	public void setSubsPatPregnantInd(String subsPatPregnantInd) {
		this.subsPatPregnantInd = subsPatPregnantInd;
	}
	/**
	 * @return Returns the subsPatUom.
	 */
	public String getSubsPatUom() {
		return subsPatUom;
	}
	/**
	 * @param subsPatUom The subsPatUom to set.
	 */
	public void setSubsPatUom(String subsPatUom) {
		this.subsPatUom = subsPatUom;
	}
	/**
	 * @return Returns the subsPatWeight.
	 */
	public int getSubsPatWeight() {
		return subsPatWeight;
	}
	/**
	 * @param subsPatWeight The subsPatWeight to set.
	 */
	public void setSubsPatWeight(int subsPatWeight) {
		this.subsPatWeight = subsPatWeight;
	}
	/**
	 * @return Returns the subsPayerSeqCd.
	 */
	public String getSubsPayerSeqCd() {
		return subsPayerSeqCd;
	}
	/**
	 * @param subsPayerSeqCd The subsPayerSeqCd to set.
	 */
	public void setSubsPayerSeqCd(String subsPayerSeqCd) {
		this.subsPayerSeqCd = subsPayerSeqCd;
	}
	/**
	 * @return Returns the subsPlanName.
	 */
	public String getSubsPlanName() {
		return subsPlanName;
	}
	/**
	 * @param subsPlanName The subsPlanName to set.
	 */
	public void setSubsPlanName(String subsPlanName) {
		this.subsPlanName = subsPlanName;
	}
	/**
	 * @return Returns the subsRelationCd.
	 */
	public String getSubsRelationCd() {
		return subsRelationCd;
	}
	/**
	 * @param subsRelationCd The subsRelationCd to set.
	 */
	public void setSubsRelationCd(String subsRelationCd) {
		this.subsRelationCd = subsRelationCd;
	}
	/**
	 * @return Returns the payerAddrLine1.
	 */
	public String getPayerAddrLine1() {
		return payerAddrLine1;
	}
	/**
	 * @param payerAddrLine1 The payerAddrLine1 to set.
	 */
	public void setPayerAddrLine1(String payerAddrLine1) {
		this.payerAddrLine1 = payerAddrLine1;
	}
	/**
	 * @return Returns the payerAddrLine2.
	 */
	public String getPayerAddrLine2() {
		return payerAddrLine2;
	}
	/**
	 * @param payerAddrLine2 The payerAddrLine2 to set.
	 */
	public void setPayerAddrLine2(String payerAddrLine2) {
		this.payerAddrLine2 = payerAddrLine2;
	}
	/**
	 * @return Returns the payerCity.
	 */
	public String getPayerCity() {
		return payerCity;
	}
	/**
	 * @param payerCity The payerCity to set.
	 */
	public void setPayerCity(String payerCity) {
		this.payerCity = payerCity;
	}
	/**
	 * @return Returns the payerCntrySubdCd.
	 */
	public String getPayerCntrySubdCd() {
		return payerCntrySubdCd;
	}
	/**
	 * @param payerCntrySubdCd The payerCntrySubdCd to set.
	 */
	public void setPayerCntrySubdCd(String payerCntrySubdCd) {
		this.payerCntrySubdCd = payerCntrySubdCd;
	}
	/**
	 * @return Returns the payerCountry.
	 */
	public String getPayerCountry() {
		return payerCountry;
	}
	/**
	 * @param payerCountry The payerCountry to set.
	 */
	public void setPayerCountry(String payerCountry) {
		this.payerCountry = payerCountry;
	}
	/**
	 * @return Returns the payerId.
	 */
	public String getPayerId() {
		return payerId;
	}
	/**
	 * @param payerId The payerId to set.
	 */
	public void setPayerId(String payerId) {
		this.payerId = payerId;
	}
	/**
	 * @return Returns the payerLocNbr.
	 */
	public String getPayerLocNbr() {
		return payerLocNbr;
	}
	/**
	 * @param payerLocNbr The payerLocNbr to set.
	 */
	public void setPayerLocNbr(String payerLocNbr) {
		this.payerLocNbr = payerLocNbr;
	}
	/**
	 * @return Returns the payerNaicCd.
	 */
	public String getPayerNaicCd() {
		return payerNaicCd;
	}
	/**
	 * @param payerNaicCd The payerNaicCd to set.
	 */
	public void setPayerNaicCd(String payerNaicCd) {
		this.payerNaicCd = payerNaicCd;
	}
	/**
	 * @return Returns the payerName.
	 */
	public String getPayerName() {
		return payerName;
	}
	/**
	 * @param payerName The payerName to set.
	 */
	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}
	/**
	 * @return Returns the payerPlanId.
	 */
	public String getPayerPlanId() {
		return payerPlanId;
	}
	/**
	 * @param payerPlanId The payerPlanId to set.
	 */
	public void setPayerPlanId(String payerPlanId) {
		this.payerPlanId = payerPlanId;
	}
	/**
	 * @return Returns the payerState.
	 */
	public String getPayerState() {
		return payerState;
	}
	/**
	 * @param payerState The payerState to set.
	 */
	public void setPayerState(String payerState) {
		this.payerState = payerState;
	}
	/**
	 * @return Returns the payerTaxId.
	 */
	public String getPayerTaxId() {
		return payerTaxId;
	}
	/**
	 * @param payerTaxId The payerTaxId to set.
	 */
	public void setPayerTaxId(String payerTaxId) {
		this.payerTaxId = payerTaxId;
	}
	/**
	 * @return Returns the payerZip.
	 */
	public String getPayerZip() {
		return payerZip;
	}
	/**
	 * @param payerZip The payerZip to set.
	 */
	public void setPayerZip(String payerZip) {
		this.payerZip = payerZip;
	}
	/**
	 * @return Returns the billPrvCommNbr.
	 */
	public String getBillPrvCommNbr() {
		return billPrvCommNbr;
	}
	/**
	 * @param billPrvCommNbr The billPrvCommNbr to set.
	 */
	public void setBillPrvCommNbr(String billPrvCommNbr) {
		this.billPrvCommNbr = billPrvCommNbr;
	}
	/**
	 * @return Returns the billPrvLocNbr.
	 */
	public String getBillPrvLocNbr() {
		return billPrvLocNbr;
	}
	/**
	 * @param billPrvLocNbr The billPrvLocNbr to set.
	 */
	public void setBillPrvLocNbr(String billPrvLocNbr) {
		this.billPrvLocNbr = billPrvLocNbr;
	}
	/**
	 * @return Returns the propCasltyClmNbr.
	 */
	public String getPropCasltyClmNbr() {
		return propCasltyClmNbr;
	}
	/**
	 * @param propCasltyClmNbr The propCasltyClmNbr to set.
	 */
	public void setPropCasltyClmNbr(String propCasltyClmNbr) {
		this.propCasltyClmNbr = propCasltyClmNbr;
	}
	/**
	 * @return Returns the propCasltySubsName.
	 */
	public String getPropCasltySubsName() {
		return propCasltySubsName;
	}
	/**
	 * @param propCasltySubsName The propCasltySubsName to set.
	 */
	public void setPropCasltySubsName(String propCasltySubsName) {
		this.propCasltySubsName = propCasltySubsName;
	}
	/**
	 * @return Returns the propCasltySubsPhnExt.
	 */
	public String getPropCasltySubsPhnExt() {
		return propCasltySubsPhnExt;
	}
	/**
	 * @param propCasltySubsPhnExt The propCasltySubsPhnExt to set.
	 */
	public void setPropCasltySubsPhnExt(String propCasltySubsPhnExt) {
		this.propCasltySubsPhnExt = propCasltySubsPhnExt;
	}
	/**
	 * @return Returns the propCasltySubsPhone.
	 */
	public String getPropCasltySubsPhone() {
		return propCasltySubsPhone;
	}
	/**
	 * @param propCasltySubsPhone The propCasltySubsPhone to set.
	 */
	public void setPropCasltySubsPhone(String propCasltySubsPhone) {
		this.propCasltySubsPhone = propCasltySubsPhone;
	}
	
	
	
	/**
	 * @return Returns the p2pAddrLine1.
	 */
	public String getP2pAddrLine1() {
		return p2pAddrLine1;
	}
	/**
	 * @param addrLine1 The p2pAddrLine1 to set.
	 */
	public void setP2pAddrLine1(String addrLine1) {
		p2pAddrLine1 = addrLine1;
	}
	/**
	 * @return Returns the p2pAddrLine2.
	 */
	public String getP2pAddrLine2() {
		return p2pAddrLine2;
	}
	/**
	 * @param addrLine2 The p2pAddrLine2 to set.
	 */
	public void setP2pAddrLine2(String addrLine2) {
		p2pAddrLine2 = addrLine2;
	}
	/**
	 * @return Returns the p2pCity.
	 */
	public String getP2pCity() {
		return p2pCity;
	}
	/**
	 * @param city The p2pCity to set.
	 */
	public void setP2pCity(String city) {
		p2pCity = city;
	}
	/**
	 * @return Returns the p2pCntrySubdCd.
	 */
	public String getP2pCntrySubdCd() {
		return p2pCntrySubdCd;
	}
	/**
	 * @param cntrySubdCd The p2pCntrySubdCd to set.
	 */
	public void setP2pCntrySubdCd(String cntrySubdCd) {
		p2pCntrySubdCd = cntrySubdCd;
	}
	/**
	 * @return Returns the p2pCountry.
	 */
	public String getP2pCountry() {
		return p2pCountry;
	}
	/**
	 * @param country The p2pCountry to set.
	 */
	public void setP2pCountry(String country) {
		p2pCountry = country;
	}
	/**
	 * @return Returns the p2pLocNbr.
	 */
	public String getP2pLocNbr() {
		return p2pLocNbr;
	}
	/**
	 * @param locNbr The p2pLocNbr to set.
	 */
	public void setP2pLocNbr(String locNbr) {
		p2pLocNbr = locNbr;
	}
	/**
	 * @return Returns the p2pNaicCd.
	 */
	public String getP2pNaicCd() {
		return p2pNaicCd;
	}
	/**
	 * @param naicCd The p2pNaicCd to set.
	 */
	public void setP2pNaicCd(String naicCd) {
		p2pNaicCd = naicCd;
	}
	/**
	 * @return Returns the p2pOrgName.
	 */
	public String getP2pOrgName() {
		return p2pOrgName;
	}
	/**
	 * @param orgName The p2pOrgName to set.
	 */
	public void setP2pOrgName(String orgName) {
		p2pOrgName = orgName;
	}
	/**
	 * @return Returns the p2pPayerIdNbr.
	 */
	public String getP2pPayerIdNbr() {
		return p2pPayerIdNbr;
	}
	/**
	 * @param payerIdNbr The p2pPayerIdNbr to set.
	 */
	public void setP2pPayerIdNbr(String payerIdNbr) {
		p2pPayerIdNbr = payerIdNbr;
	}
	/**
	 * @return Returns the p2pPrimPayerId.
	 */
	public String getP2pPrimPayerId() {
		return p2pPrimPayerId;
	}
	/**
	 * @param primPayerId The p2pPrimPayerId to set.
	 */
	public void setP2pPrimPayerId(String primPayerId) {
		p2pPrimPayerId = primPayerId;
	}
	/**
	 * @return Returns the p2pPrimPlanId.
	 */
	public String getP2pPrimPlanId() {
		return p2pPrimPlanId;
	}
	/**
	 * @param primPlanId The p2pPrimPlanId to set.
	 */
	public void setP2pPrimPlanId(String primPlanId) {
		p2pPrimPlanId = primPlanId;
	}
	/**
	 * @return Returns the p2pState.
	 */
	public String getP2pState() {
		return p2pState;
	}
	/**
	 * @param state The p2pState to set.
	 */
	public void setP2pState(String state) {
		p2pState = state;
	}
	/**
	 * @return Returns the p2pTaxId.
	 */
	public String getP2pTaxId() {
		return p2pTaxId;
	}
	/**
	 * @param taxId The p2pTaxId to set.
	 */
	public void setP2pTaxId(String taxId) {
		p2pTaxId = taxId;
	}
	/**
	 * @return Returns the p2pZip.
	 */
	public String getP2pZip() {
		return p2pZip;
	}
	/**
	 * @param zip The p2pZip to set.
	 */
	public void setP2pZip(String zip) {
		p2pZip = zip;
	}
	
	
	/**
	 * @return Returns the payerSecId.
	 */
	public String getPayerSecId() {
		return payerSecId;
	}
	/**
	 * @param payerSecId The payerSecId to set.
	 */
	public void setPayerSecId(String payerSecId) {
		this.payerSecId = payerSecId;
	}
	
	
	
	/**
	 * @return Returns the ambCertCondCd1.
	 */
	public String getAmbCertCondCd1() {
		return ambCertCondCd1;
	}
	/**
	 * @param ambCertCondCd1 The ambCertCondCd1 to set.
	 */
	public void setAmbCertCondCd1(String ambCertCondCd1) {
		this.ambCertCondCd1 = ambCertCondCd1;
	}
	/**
	 * @return Returns the ambCertCondCd2.
	 */
	public String getAmbCertCondCd2() {
		return ambCertCondCd2;
	}
	/**
	 * @param ambCertCondCd2 The ambCertCondCd2 to set.
	 */
	public void setAmbCertCondCd2(String ambCertCondCd2) {
		this.ambCertCondCd2 = ambCertCondCd2;
	}
	/**
	 * @return Returns the ambCertCondCd3.
	 */
	public String getAmbCertCondCd3() {
		return ambCertCondCd3;
	}
	/**
	 * @param ambCertCondCd3 The ambCertCondCd3 to set.
	 */
	public void setAmbCertCondCd3(String ambCertCondCd3) {
		this.ambCertCondCd3 = ambCertCondCd3;
	}
	/**
	 * @return Returns the ambCertCondCd4.
	 */
	public String getAmbCertCondCd4() {
		return ambCertCondCd4;
	}
	/**
	 * @param ambCertCondCd4 The ambCertCondCd4 to set.
	 */
	public void setAmbCertCondCd4(String ambCertCondCd4) {
		this.ambCertCondCd4 = ambCertCondCd4;
	}
	/**
	 * @return Returns the ambCertCondCd5.
	 */
	public String getAmbCertCondCd5() {
		return ambCertCondCd5;
	}
	/**
	 * @param ambCertCondCd5 The ambCertCondCd5 to set.
	 */
	public void setAmbCertCondCd5(String ambCertCondCd5) {
		this.ambCertCondCd5 = ambCertCondCd5;
	}
	/**
	 * @return Returns the ambCertCondInd.
	 */
	public String getAmbCertCondInd() {
		return ambCertCondInd;
	}
	/**
	 * @param ambCertCondInd The ambCertCondInd to set.
	 */
	public void setAmbCertCondInd(String ambCertCondInd) {
		this.ambCertCondInd = ambCertCondInd;
	}
	/**
	 * @return Returns the ambDropoffCntrySubd.
	 */
	public String getAmbDropoffCntrySubd() {
		return ambDropoffCntrySubd;
	}
	/**
	 * @param ambDropoffCntrySubd The ambDropoffCntrySubd to set.
	 */
	public void setAmbDropoffCntrySubd(String ambDropoffCntrySubd) {
		this.ambDropoffCntrySubd = ambDropoffCntrySubd;
	}
	/**
	 * @return Returns the ambDropoffCountry.
	 */
	public String getAmbDropoffCountry() {
		return ambDropoffCountry;
	}
	/**
	 * @param ambDropoffCountry The ambDropoffCountry to set.
	 */
	public void setAmbDropoffCountry(String ambDropoffCountry) {
		this.ambDropoffCountry = ambDropoffCountry;
	}
	/**
	 * @return Returns the ambPatWeight.
	 */
	public String getAmbPatWeight() {
		return ambPatWeight;
	}
	/**
	 * @param ambPatWeight The ambPatWeight to set.
	 */
	public void setAmbPatWeight(String ambPatWeight) {
		this.ambPatWeight = ambPatWeight;
	}
	/**
	 * @return Returns the ambPickupCntrySubd.
	 */
	public String getAmbPickupCntrySubd() {
		return ambPickupCntrySubd;
	}
	/**
	 * @param ambPickupCntrySubd The ambPickupCntrySubd to set.
	 */
	public void setAmbPickupCntrySubd(String ambPickupCntrySubd) {
		this.ambPickupCntrySubd = ambPickupCntrySubd;
	}
	/**
	 * @return Returns the ambPickupCountry.
	 */
	public String getAmbPickupCountry() {
		return ambPickupCountry;
	}
	/**
	 * @param ambPickupCountry The ambPickupCountry to set.
	 */
	public void setAmbPickupCountry(String ambPickupCountry) {
		this.ambPickupCountry = ambPickupCountry;
	}
	/**
	 * @return Returns the ambTranspDistance.
	 */
	public String getAmbTranspDistance() {
		return ambTranspDistance;
	}
	/**
	 * @param ambTranspDistance The ambTranspDistance to set.
	 */
	public void setAmbTranspDistance(String ambTranspDistance) {
		this.ambTranspDistance = ambTranspDistance;
	}
	/**
	 * @return Returns the ambTranspReasonCd.
	 */
	public String getAmbTranspReasonCd() {
		return ambTranspReasonCd;
	}
	/**
	 * @param ambTranspReasonCd The ambTranspReasonCd to set.
	 */
	public void setAmbTranspReasonCd(String ambTranspReasonCd) {
		this.ambTranspReasonCd = ambTranspReasonCd;
	}
	/**
	 * @return Returns the anestSurgProcCd1.
	 */
	public String getAnestSurgProcCd1() {
		return anestSurgProcCd1;
	}
	/**
	 * @param anestSurgProcCd1 The anestSurgProcCd1 to set.
	 */
	public void setAnestSurgProcCd1(String anestSurgProcCd1) {
		this.anestSurgProcCd1 = anestSurgProcCd1;
	}
	/**
	 * @return Returns the anestSurgProcCd2.
	 */
	public String getAnestSurgProcCd2() {
		return anestSurgProcCd2;
	}
	/**
	 * @param anestSurgProcCd2 The anestSurgProcCd2 to set.
	 */
	public void setAnestSurgProcCd2(String anestSurgProcCd2) {
		this.anestSurgProcCd2 = anestSurgProcCd2;
	}
	/**
	 * @return Returns the autoAccidentCountry.
	 */
	public String getAutoAccidentCountry() {
		return autoAccidentCountry;
	}
	/**
	 * @param autoAccidentCountry The autoAccidentCountry to set.
	 */
	public void setAutoAccidentCountry(String autoAccidentCountry) {
		this.autoAccidentCountry = autoAccidentCountry;
	}
	/**
	 * @return Returns the autoAccidentInd.
	 */
	public String getAutoAccidentInd() {
		return autoAccidentInd;
	}
	/**
	 * @param autoAccidentInd The autoAccidentInd to set.
	 */
	public void setAutoAccidentInd(String autoAccidentInd) {
		this.autoAccidentInd = autoAccidentInd;
	}
	/**
	 * @return Returns the autoAccidentState.
	 */
	public String getAutoAccidentState() {
		return autoAccidentState;
	}
	/**
	 * @param autoAccidentState The autoAccidentState to set.
	 */
	public void setAutoAccidentState(String autoAccidentState) {
		this.autoAccidentState = autoAccidentState;
	}
	/**
	 * @return Returns the beneAssignCertInd.
	 */
	public String getBeneAssignCertInd() {
		return beneAssignCertInd;
	}
	/**
	 * @param beneAssignCertInd The beneAssignCertInd to set.
	 */
	public void setBeneAssignCertInd(String beneAssignCertInd) {
		this.beneAssignCertInd = beneAssignCertInd;
	}
	/**
	 * @return Returns the carePlanOversightNbr.
	 */
	public String getCarePlanOversightNbr() {
		return carePlanOversightNbr;
	}
	/**
	 * @param carePlanOversightNbr The carePlanOversightNbr to set.
	 */
	public void setCarePlanOversightNbr(String carePlanOversightNbr) {
		this.carePlanOversightNbr = carePlanOversightNbr;
	}
	/**
	 * @return Returns the claimNotes.
	 */
	public String getClaimNotes() {
		return claimNotes;
	}
	/**
	 * @param claimNotes The claimNotes to set.
	 */
	public void setClaimNotes(String claimNotes) {
		this.claimNotes = claimNotes;
	}
	/**
	 * @return Returns the claimRefCd.
	 */
	public String getClaimRefCd() {
		return claimRefCd;
	}
	/**
	 * @param claimRefCd The claimRefCd to set.
	 */
	public void setClaimRefCd(String claimRefCd) {
		this.claimRefCd = claimRefCd;
	}
	/**
	 * @return Returns the clmFreqTypeCd.
	 */
	public String getClmFreqTypeCd() {
		return clmFreqTypeCd;
	}
	/**
	 * @param clmFreqTypeCd The clmFreqTypeCd to set.
	 */
	public void setClmFreqTypeCd(String clmFreqTypeCd) {
		this.clmFreqTypeCd = clmFreqTypeCd;
	}
	/**
	 * @return Returns the contractCd.
	 */
	public String getContractCd() {
		return contractCd;
	}
	/**
	 * @param contractCd The contractCd to set.
	 */
	public void setContractCd(String contractCd) {
		this.contractCd = contractCd;
	}
	/**
	 * @return Returns the contractTypeCd.
	 */
	public String getContractTypeCd() {
		return contractTypeCd;
	}
	/**
	 * @param contractTypeCd The contractTypeCd to set.
	 */
	public void setContractTypeCd(String contractTypeCd) {
		this.contractTypeCd = contractTypeCd;
	}
	/**
	 * @return Returns the contractVersionId.
	 */
	public String getContractVersionId() {
		return contractVersionId;
	}
	/**
	 * @param contractVersionId The contractVersionId to set.
	 */
	public void setContractVersionId(String contractVersionId) {
		this.contractVersionId = contractVersionId;
	}
	/**
	 * @return Returns the delayReasonCd.
	 */
	public String getDelayReasonCd() {
		return delayReasonCd;
	}
	/**
	 * @param delayReasonCd The delayReasonCd to set.
	 */
	public void setDelayReasonCd(String delayReasonCd) {
		this.delayReasonCd = delayReasonCd;
	}
	/**
	 * @return Returns the demonstrationProjId.
	 */
	public String getDemonstrationProjId() {
		return demonstrationProjId;
	}
	/**
	 * @param demonstrationProjId The demonstrationProjId to set.
	 */
	public void setDemonstrationProjId(String demonstrationProjId) {
		this.demonstrationProjId = demonstrationProjId;
	}
	/**
	 * @return Returns the employmentAccidentInd.
	 */
	public String getEmploymentAccidentInd() {
		return employmentAccidentInd;
	}
	/**
	 * @param employmentAccidentInd The employmentAccidentInd to set.
	 */
	public void setEmploymentAccidentInd(String employmentAccidentInd) {
		this.employmentAccidentInd = employmentAccidentInd;
	}
	/**
	 * @return Returns the epsdtCondInd1.
	 */
	public String getEpsdtCondInd1() {
		return epsdtCondInd1;
	}
	/**
	 * @param epsdtCondInd1 The epsdtCondInd1 to set.
	 */
	public void setEpsdtCondInd1(String epsdtCondInd1) {
		this.epsdtCondInd1 = epsdtCondInd1;
	}
	/**
	 * @return Returns the epsdtCondInd2.
	 */
	public String getEpsdtCondInd2() {
		return epsdtCondInd2;
	}
	/**
	 * @param epsdtCondInd2 The epsdtCondInd2 to set.
	 */
	public void setEpsdtCondInd2(String epsdtCondInd2) {
		this.epsdtCondInd2 = epsdtCondInd2;
	}
	/**
	 * @return Returns the epsdtCondInd3.
	 */
	public String getEpsdtCondInd3() {
		return epsdtCondInd3;
	}
	/**
	 * @param epsdtCondInd3 The epsdtCondInd3 to set.
	 */
	public void setEpsdtCondInd3(String epsdtCondInd3) {
		this.epsdtCondInd3 = epsdtCondInd3;
	}
	/**
	 * @return Returns the formattedAccidentDt.
	 */
	public String getFormattedAccidentDt() {
		return formattedAccidentDt;
	}
	/**
	 * @param formattedAccidentDt The formattedAccidentDt to set.
	 */
	public void setFormattedAccidentDt(String formattedAccidentDt) {
		this.formattedAccidentDt = formattedAccidentDt;
	}
	/**
	 * @return Returns the formattedAcuteManifestationDt.
	 */
	public String getFormattedAcuteManifestationDt() {
		return formattedAcuteManifestationDt;
	}
	/**
	 * @param formattedAcuteManifestationDt The formattedAcuteManifestationDt to set.
	 */
	public void setFormattedAcuteManifestationDt(
			String formattedAcuteManifestationDt) {
		this.formattedAcuteManifestationDt = formattedAcuteManifestationDt;
	}
	/**
	 * @return Returns the formattedAsumdCareEndDt.
	 */
	public String getFormattedAsumdCareEndDt() {
		return formattedAsumdCareEndDt;
	}
	/**
	 * @param formattedAsumdCareEndDt The formattedAsumdCareEndDt to set.
	 */
	public void setFormattedAsumdCareEndDt(String formattedAsumdCareEndDt) {
		this.formattedAsumdCareEndDt = formattedAsumdCareEndDt;
	}
	/**
	 * @return Returns the formattedAsumdCareStartDt.
	 */
	public String getFormattedAsumdCareStartDt() {
		return formattedAsumdCareStartDt;
	}
	/**
	 * @param formattedAsumdCareStartDt The formattedAsumdCareStartDt to set.
	 */
	public void setFormattedAsumdCareStartDt(String formattedAsumdCareStartDt) {
		this.formattedAsumdCareStartDt = formattedAsumdCareStartDt;
	}
	/**
	 * @return Returns the formattedAuthReturnWorkDt.
	 */
	public String getFormattedAuthReturnWorkDt() {
		return formattedAuthReturnWorkDt;
	}
	/**
	 * @param formattedAuthReturnWorkDt The formattedAuthReturnWorkDt to set.
	 */
	public void setFormattedAuthReturnWorkDt(String formattedAuthReturnWorkDt) {
		this.formattedAuthReturnWorkDt = formattedAuthReturnWorkDt;
	}
	/**
	 * @return Returns the formattedDisabilityEndDt.
	 */
	public String getFormattedDisabilityEndDt() {
		return formattedDisabilityEndDt;
	}
	/**
	 * @param formattedDisabilityEndDt The formattedDisabilityEndDt to set.
	 */
	public void setFormattedDisabilityEndDt(String formattedDisabilityEndDt) {
		this.formattedDisabilityEndDt = formattedDisabilityEndDt;
	}
	/**
	 * @return Returns the formattedDisabilityStartDt.
	 */
	public String getFormattedDisabilityStartDt() {
		return formattedDisabilityStartDt;
	}
	/**
	 * @param formattedDisabilityStartDt The formattedDisabilityStartDt to set.
	 */
	public void setFormattedDisabilityStartDt(String formattedDisabilityStartDt) {
		this.formattedDisabilityStartDt = formattedDisabilityStartDt;
	}
	/**
	 * @return Returns the formattedFirstVisitConsultDt.
	 */
	public String getFormattedFirstVisitConsultDt() {
		return formattedFirstVisitConsultDt;
	}
	/**
	 * @param formattedFirstVisitConsultDt The formattedFirstVisitConsultDt to set.
	 */
	public void setFormattedFirstVisitConsultDt(
			String formattedFirstVisitConsultDt) {
		this.formattedFirstVisitConsultDt = formattedFirstVisitConsultDt;
	}
	/**
	 * @return Returns the formattedHearVisionDt.
	 */
	public String getFormattedHearVisionDt() {
		return formattedHearVisionDt;
	}
	/**
	 * @param formattedHearVisionDt The formattedHearVisionDt to set.
	 */
	public void setFormattedHearVisionDt(String formattedHearVisionDt) {
		this.formattedHearVisionDt = formattedHearVisionDt;
	}
	/**
	 * @return Returns the formattedIllnessOccurDt.
	 */
	public String getFormattedIllnessOccurDt() {
		return formattedIllnessOccurDt;
	}
	/**
	 * @param formattedIllnessOccurDt The formattedIllnessOccurDt to set.
	 */
	public void setFormattedIllnessOccurDt(String formattedIllnessOccurDt) {
		this.formattedIllnessOccurDt = formattedIllnessOccurDt;
	}
	/**
	 * @return Returns the formattedInitialTreatmentDt.
	 */
	public String getFormattedInitialTreatmentDt() {
		return formattedInitialTreatmentDt;
	}
	/**
	 * @param formattedInitialTreatmentDt The formattedInitialTreatmentDt to set.
	 */
	public void setFormattedInitialTreatmentDt(
			String formattedInitialTreatmentDt) {
		this.formattedInitialTreatmentDt = formattedInitialTreatmentDt;
	}
	/**
	 * @return Returns the formattedLastMenstrualPerDt.
	 */
	public String getFormattedLastMenstrualPerDt() {
		return formattedLastMenstrualPerDt;
	}
	/**
	 * @param formattedLastMenstrualPerDt The formattedLastMenstrualPerDt to set.
	 */
	public void setFormattedLastMenstrualPerDt(
			String formattedLastMenstrualPerDt) {
		this.formattedLastMenstrualPerDt = formattedLastMenstrualPerDt;
	}
	/**
	 * @return Returns the formattedLastSeenDt.
	 */
	public String getFormattedLastSeenDt() {
		return formattedLastSeenDt;
	}
	/**
	 * @param formattedLastSeenDt The formattedLastSeenDt to set.
	 */
	public void setFormattedLastSeenDt(String formattedLastSeenDt) {
		this.formattedLastSeenDt = formattedLastSeenDt;
	}
	/**
	 * @return Returns the formattedLastWorkedDt.
	 */
	public String getFormattedLastWorkedDt() {
		return formattedLastWorkedDt;
	}
	/**
	 * @param formattedLastWorkedDt The formattedLastWorkedDt to set.
	 */
	public void setFormattedLastWorkedDt(String formattedLastWorkedDt) {
		this.formattedLastWorkedDt = formattedLastWorkedDt;
	}
	/**
	 * @return Returns the formattedLastXrayDt.
	 */
	public String getFormattedLastXrayDt() {
		return formattedLastXrayDt;
	}
	/**
	 * @param formattedLastXrayDt The formattedLastXrayDt to set.
	 */
	public void setFormattedLastXrayDt(String formattedLastXrayDt) {
		this.formattedLastXrayDt = formattedLastXrayDt;
	}
	/**
	 * @return Returns the investigDeviceExempId.
	 */
	public String getInvestigDeviceExempId() {
		return investigDeviceExempId;
	}
	/**
	 * @param investigDeviceExempId The investigDeviceExempId to set.
	 */
	public void setInvestigDeviceExempId(String investigDeviceExempId) {
		this.investigDeviceExempId = investigDeviceExempId;
	}
	/**
	 * @return Returns the labHomeCondInd.
	 */
	public String getLabHomeCondInd() {
		return labHomeCondInd;
	}
	/**
	 * @param labHomeCondInd The labHomeCondInd to set.
	 */
	public void setLabHomeCondInd(String labHomeCondInd) {
		this.labHomeCondInd = labHomeCondInd;
	}
	/**
	 * @return Returns the labHomeRespCd.
	 */
	public String getLabHomeRespCd() {
		return labHomeRespCd;
	}
	/**
	 * @param labHomeRespCd The labHomeRespCd to set.
	 */
	public void setLabHomeRespCd(String labHomeRespCd) {
		this.labHomeRespCd = labHomeRespCd;
	}
	/**
	 * @return Returns the medicalRecordNbr.
	 */
	public String getMedicalRecordNbr() {
		return medicalRecordNbr;
	}
	/**
	 * @param medicalRecordNbr The medicalRecordNbr to set.
	 */
	public void setMedicalRecordNbr(String medicalRecordNbr) {
		this.medicalRecordNbr = medicalRecordNbr;
	}
	/**
	 * @return Returns the medicareCrossoverCd.
	 */
	public String getMedicareCrossoverCd() {
		return medicareCrossoverCd;
	}
	/**
	 * @param medicareCrossoverCd The medicareCrossoverCd to set.
	 */
	public void setMedicareCrossoverCd(String medicareCrossoverCd) {
		this.medicareCrossoverCd = medicareCrossoverCd;
	}
	/**
	 * @return Returns the otherAccidentInd.
	 */
	public String getOtherAccidentInd() {
		return otherAccidentInd;
	}
	/**
	 * @param otherAccidentInd The otherAccidentInd to set.
	 */
	public void setOtherAccidentInd(String otherAccidentInd) {
		this.otherAccidentInd = otherAccidentInd;
	}
	/**
	 * @return Returns the patientCondCd.
	 */
	public String getPatientCondCd() {
		return patientCondCd;
	}
	/**
	 * @param patientCondCd The patientCondCd to set.
	 */
	public void setPatientCondCd(String patientCondCd) {
		this.patientCondCd = patientCondCd;
	}
	/**
	 * @return Returns the patientCtrlNbr.
	 */
	public String getPatientCtrlNbr() {
		return patientCtrlNbr;
	}
	/**
	 * @param patientCtrlNbr The patientCtrlNbr to set.
	 */
	public void setPatientCtrlNbr(String patientCtrlNbr) {
		this.patientCtrlNbr = patientCtrlNbr;
	}
	/**
	 * @return Returns the patSignatureSrcCd.
	 */
	public String getPatSignatureSrcCd() {
		return patSignatureSrcCd;
	}
	/**
	 * @param patSignatureSrcCd The patSignatureSrcCd to set.
	 */
	public void setPatSignatureSrcCd(String patSignatureSrcCd) {
		this.patSignatureSrcCd = patSignatureSrcCd;
	}
	/**
	 * @return Returns the payerClmCtrlNbr.
	 */
	public String getPayerClmCtrlNbr() {
		return payerClmCtrlNbr;
	}
	/**
	 * @param payerClmCtrlNbr The payerClmCtrlNbr to set.
	 */
	public void setPayerClmCtrlNbr(String payerClmCtrlNbr) {
		this.payerClmCtrlNbr = payerClmCtrlNbr;
	}
	/**
	 * @return Returns the priorAuthNbr.
	 */
	public String getPriorAuthNbr() {
		return priorAuthNbr;
	}
	/**
	 * @param priorAuthNbr The priorAuthNbr to set.
	 */
	public void setPriorAuthNbr(String priorAuthNbr) {
		this.priorAuthNbr = priorAuthNbr;
	}
	/**
	 * @return Returns the prvAcceptAssignCd.
	 */
	public String getPrvAcceptAssignCd() {
		return prvAcceptAssignCd;
	}
	/**
	 * @param prvAcceptAssignCd The prvAcceptAssignCd to set.
	 */
	public void setPrvAcceptAssignCd(String prvAcceptAssignCd) {
		this.prvAcceptAssignCd = prvAcceptAssignCd;
	}
	/**
	 * @return Returns the prvSignatureOnfileInd.
	 */
	public String getPrvSignatureOnfileInd() {
		return prvSignatureOnfileInd;
	}
	/**
	 * @param prvSignatureOnfileInd The prvSignatureOnfileInd to set.
	 */
	public void setPrvSignatureOnfileInd(String prvSignatureOnfileInd) {
		this.prvSignatureOnfileInd = prvSignatureOnfileInd;
	}
	/**
	 * @return Returns the referralNbr.
	 */
	public String getReferralNbr() {
		return referralNbr;
	}
	/**
	 * @param referralNbr The referralNbr to set.
	 */
	public void setReferralNbr(String referralNbr) {
		this.referralNbr = referralNbr;
	}
	/**
	 * @return Returns the releaseOfInfoCd.
	 */
	public String getReleaseOfInfoCd() {
		return releaseOfInfoCd;
	}
	/**
	 * @param releaseOfInfoCd The releaseOfInfoCd to set.
	 */
	public void setReleaseOfInfoCd(String releaseOfInfoCd) {
		this.releaseOfInfoCd = releaseOfInfoCd;
	}
	/**
	 * @return Returns the roundTripPurposeDesc.
	 */
	public String getRoundTripPurposeDesc() {
		return roundTripPurposeDesc;
	}
	/**
	 * @param roundTripPurposeDesc The roundTripPurposeDesc to set.
	 */
	public void setRoundTripPurposeDesc(String roundTripPurposeDesc) {
		this.roundTripPurposeDesc = roundTripPurposeDesc;
	}
	/**
	 * @return Returns the stretcherPurposeDesc.
	 */
	public String getStretcherPurposeDesc() {
		return stretcherPurposeDesc;
	}
	/**
	 * @param stretcherPurposeDesc The stretcherPurposeDesc to set.
	 */
	public void setStretcherPurposeDesc(String stretcherPurposeDesc) {
		this.stretcherPurposeDesc = stretcherPurposeDesc;
	}
	/**
	 * @return Returns the svcAuthExcptCd.
	 */
	public String getSvcAuthExcptCd() {
		return svcAuthExcptCd;
	}
	/**
	 * @param svcAuthExcptCd The svcAuthExcptCd to set.
	 */
	public void setSvcAuthExcptCd(String svcAuthExcptCd) {
		this.svcAuthExcptCd = svcAuthExcptCd;
	}
	/**
	 * @return Returns the svcFacContactName.
	 */
	public String getSvcFacContactName() {
		return svcFacContactName;
	}
	/**
	 * @param svcFacContactName The svcFacContactName to set.
	 */
	public void setSvcFacContactName(String svcFacContactName) {
		this.svcFacContactName = svcFacContactName;
	}
	/**
	 * @return Returns the svcFacPhone.
	 */
	public String getSvcFacPhone() {
		return svcFacPhone;
	}
	/**
	 * @param svcFacPhone The svcFacPhone to set.
	 */
	public void setSvcFacPhone(String svcFacPhone) {
		this.svcFacPhone = svcFacPhone;
	}
	/**
	 * @return Returns the svcFacPhoneExt.
	 */
	public String getSvcFacPhoneExt() {
		return svcFacPhoneExt;
	}
	/**
	 * @param svcFacPhoneExt The svcFacPhoneExt to set.
	 */
	public void setSvcFacPhoneExt(String svcFacPhoneExt) {
		this.svcFacPhoneExt = svcFacPhoneExt;
	}
	/**
	 * @return Returns the valueAddNtwkTraceNbr.
	 */
	public String getValueAddNtwkTraceNbr() {
		return valueAddNtwkTraceNbr;
	}
	/**
	 * @param valueAddNtwkTraceNbr The valueAddNtwkTraceNbr to set.
	 */
	public void setValueAddNtwkTraceNbr(String valueAddNtwkTraceNbr) {
		this.valueAddNtwkTraceNbr = valueAddNtwkTraceNbr;
	}
	/**
	 * @return Returns the visnCertCondCd1.
	 */
	public String getVisnCertCondCd1() {
		return visnCertCondCd1;
	}
	/**
	 * @param visnCertCondCd1 The visnCertCondCd1 to set.
	 */
	public void setVisnCertCondCd1(String visnCertCondCd1) {
		this.visnCertCondCd1 = visnCertCondCd1;
	}
	/**
	 * @return Returns the visnCertCondCd2.
	 */
	public String getVisnCertCondCd2() {
		return visnCertCondCd2;
	}
	/**
	 * @param visnCertCondCd2 The visnCertCondCd2 to set.
	 */
	public void setVisnCertCondCd2(String visnCertCondCd2) {
		this.visnCertCondCd2 = visnCertCondCd2;
	}
	/**
	 * @return Returns the visnCertCondCd3.
	 */
	public String getVisnCertCondCd3() {
		return visnCertCondCd3;
	}
	/**
	 * @param visnCertCondCd3 The visnCertCondCd3 to set.
	 */
	public void setVisnCertCondCd3(String visnCertCondCd3) {
		this.visnCertCondCd3 = visnCertCondCd3;
	}
	/**
	 * @return Returns the visnCertCondCd4.
	 */
	public String getVisnCertCondCd4() {
		return visnCertCondCd4;
	}
	/**
	 * @param visnCertCondCd4 The visnCertCondCd4 to set.
	 */
	public void setVisnCertCondCd4(String visnCertCondCd4) {
		this.visnCertCondCd4 = visnCertCondCd4;
	}
	/**
	 * @return Returns the visnCertCondCd5.
	 */
	public String getVisnCertCondCd5() {
		return visnCertCondCd5;
	}
	/**
	 * @param visnCertCondCd5 The visnCertCondCd5 to set.
	 */
	public void setVisnCertCondCd5(String visnCertCondCd5) {
		this.visnCertCondCd5 = visnCertCondCd5;
	}
	/**
	 * @return Returns the visnCertCondInd.
	 */
	public String getVisnCertCondInd() {
		return visnCertCondInd;
	}
	/**
	 * @param visnCertCondInd The visnCertCondInd to set.
	 */
	public void setVisnCertCondInd(String visnCertCondInd) {
		this.visnCertCondInd = visnCertCondInd;
	}
	/**
	 * @return Returns the visnCodeCategory.
	 */
	public String getVisnCodeCategory() {
		return visnCodeCategory;
	}
	/**
	 * @param visnCodeCategory The visnCodeCategory to set.
	 */
	public void setVisnCodeCategory(String visnCodeCategory) {
		this.visnCodeCategory = visnCodeCategory;
	}
	/**
	 * @return Returns the wtxClaimRefNbr.
	 */
	public String getWtxClaimRefNbr() {
		return wtxClaimRefNbr;
	}
	/**
	 * @param wtxClaimRefNbr The wtxClaimRefNbr to set.
	 */
	public void setWtxClaimRefNbr(String wtxClaimRefNbr) {
		this.wtxClaimRefNbr = wtxClaimRefNbr;
	}
	
	/**
	 * @return Returns the wtxClaimRevNbr.
	 */
	public int getWtxClaimRevNbr() {
		return wtxClaimRevNbr;
	}
	/**
	 * @param wtxClaimRevNbr The wtxClaimRevNbr to set.
	 */
	public void setWtxClaimRevNbr(int wtxClaimRevNbr) {
		this.wtxClaimRevNbr = wtxClaimRevNbr;
	}
	/**
	 * @return Returns the adjRepricdClmRefNbr.
	 */
	public String getAdjRepricdClmRefNbr() {
		return adjRepricdClmRefNbr;
	}
	/**
	 * @param adjRepricdClmRefNbr The adjRepricdClmRefNbr to set.
	 */
	public void setAdjRepricdClmRefNbr(String adjRepricdClmRefNbr) {
		this.adjRepricdClmRefNbr = adjRepricdClmRefNbr;
	}
	/**
	 * @return Returns the admitDiagCd.
	 */
	public String getAdmitDiagCd() {
		return admitDiagCd;
	}
	/**
	 * @param admitDiagCd The admitDiagCd to set.
	 */
	public void setAdmitDiagCd(String admitDiagCd) {
		this.admitDiagCd = admitDiagCd;
	}
	/**
	 * @return Returns the admitDiagType.
	 */
	public String getAdmitDiagType() {
		return admitDiagType;
	}
	/**
	 * @param admitDiagType The admitDiagType to set.
	 */
	public void setAdmitDiagType(String admitDiagType) {
		this.admitDiagType = admitDiagType;
	}
	/**
	 * @return Returns the billingNotes.
	 */
	public String getBillingNotes() {
		return billingNotes;
	}
	/**
	 * @param billingNotes The billingNotes to set.
	 */
	public void setBillingNotes(String billingNotes) {
		this.billingNotes = billingNotes;
	}
	/**
	 * @return Returns the billPrvContactName.
	 */
	public String getBillPrvContactName() {
		return billPrvContactName;
	}
	/**
	 * @param billPrvContactName The billPrvContactName to set.
	 */
	public void setBillPrvContactName(String billPrvContactName) {
		this.billPrvContactName = billPrvContactName;
	}
	/**
	 * @return Returns the demonstrationProjectId.
	 */
	public String getDemonstrationProjectId() {
		return demonstrationProjectId;
	}
	/**
	 * @param demonstrationProjectId The demonstrationProjectId to set.
	 */
	public void setDemonstrationProjectId(String demonstrationProjectId) {
		this.demonstrationProjectId = demonstrationProjectId;
	}
	/**
	 * @return Returns the dischargeHour.
	 */
	public String getDischargeHour() {
		return dischargeHour;
	}
	/**
	 * @param dischargeHour The dischargeHour to set.
	 */
	public void setDischargeHour(String dischargeHour) {
		this.dischargeHour = dischargeHour;
	}
	/**
	 * @return Returns the drgCd.
	 */
	public String getDrgCd() {
		return drgCd;
	}
	/**
	 * @param drgCd The drgCd to set.
	 */
	public void setDrgCd(String drgCd) {
		this.drgCd = drgCd;
	}
	/**
	 * @return Returns the investigDeviceExmptId.
	 */
	public String getInvestigDeviceExmptId() {
		return investigDeviceExmptId;
	}
	/**
	 * @param investigDeviceExmptId The investigDeviceExmptId to set.
	 */
	public void setInvestigDeviceExmptId(String investigDeviceExmptId) {
		this.investigDeviceExmptId = investigDeviceExmptId;
	}
	/**
	 * @return Returns the patVisitreasCd1.
	 */
	public String getPatVisitreasCd1() {
		return patVisitreasCd1;
	}
	/**
	 * @param patVisitreasCd1 The patVisitreasCd1 to set.
	 */
	public void setPatVisitreasCd1(String patVisitreasCd1) {
		this.patVisitreasCd1 = patVisitreasCd1;
	}
	/**
	 * @return Returns the patVisitreasCd2.
	 */
	public String getPatVisitreasCd2() {
		return patVisitreasCd2;
	}
	/**
	 * @param patVisitreasCd2 The patVisitreasCd2 to set.
	 */
	public void setPatVisitreasCd2(String patVisitreasCd2) {
		this.patVisitreasCd2 = patVisitreasCd2;
	}
	/**
	 * @return Returns the patVisitreasCd3.
	 */
	public String getPatVisitreasCd3() {
		return patVisitreasCd3;
	}
	/**
	 * @param patVisitreasCd3 The patVisitreasCd3 to set.
	 */
	public void setPatVisitreasCd3(String patVisitreasCd3) {
		this.patVisitreasCd3 = patVisitreasCd3;
	}
	/**
	 * @return Returns the patVisitreasType1.
	 */
	public String getPatVisitreasType1() {
		return patVisitreasType1;
	}
	/**
	 * @param patVisitreasType1 The patVisitreasType1 to set.
	 */
	public void setPatVisitreasType1(String patVisitreasType1) {
		this.patVisitreasType1 = patVisitreasType1;
	}
	/**
	 * @return Returns the patVisitreasType2.
	 */
	public String getPatVisitreasType2() {
		return patVisitreasType2;
	}
	/**
	 * @param patVisitreasType2 The patVisitreasType2 to set.
	 */
	public void setPatVisitreasType2(String patVisitreasType2) {
		this.patVisitreasType2 = patVisitreasType2;
	}
	/**
	 * @return Returns the patVisitreasType3.
	 */
	public String getPatVisitreasType3() {
		return patVisitreasType3;
	}
	/**
	 * @param patVisitreasType3 The patVisitreasType3 to set.
	 */
	public void setPatVisitreasType3(String patVisitreasType3) {
		this.patVisitreasType3 = patVisitreasType3;
	}
	/**
	 * @return Returns the peerRevewOrgAprvNbr.
	 */
	public String getPeerRevewOrgAprvNbr() {
		return peerRevewOrgAprvNbr;
	}
	/**
	 * @param peerRevewOrgAprvNbr The peerRevewOrgAprvNbr to set.
	 */
	public void setPeerRevewOrgAprvNbr(String peerRevewOrgAprvNbr) {
		this.peerRevewOrgAprvNbr = peerRevewOrgAprvNbr;
	}
	/**
	 * @return Returns the repricdClmRefNbr.
	 */
	public String getRepricdClmRefNbr() {
		return repricdClmRefNbr;
	}
	/**
	 * @param repricdClmRefNbr The repricdClmRefNbr to set.
	 */
	public void setRepricdClmRefNbr(String repricdClmRefNbr) {
		this.repricdClmRefNbr = repricdClmRefNbr;
	}
	/**
	 * @return Returns the repricedApprvdDrgCd.
	 */
	public String getRepricedApprvdDrgCd() {
		return repricedApprvdDrgCd;
	}
	/**
	 * @param repricedApprvdDrgCd The repricedApprvdDrgCd to set.
	 */
	public void setRepricedApprvdDrgCd(String repricedApprvdDrgCd) {
		this.repricedApprvdDrgCd = repricedApprvdDrgCd;
	}
	/**
	 * @return Returns the repricedApprvdRevCd.
	 */
	public String getRepricedApprvdRevCd() {
		return repricedApprvdRevCd;
	}
	/**
	 * @param repricedApprvdRevCd The repricedApprvdRevCd to set.
	 */
	public void setRepricedApprvdRevCd(String repricedApprvdRevCd) {
		this.repricedApprvdRevCd = repricedApprvdRevCd;
	}
	/**
	 * @return Returns the repricedExceptionCd.
	 */
	public String getRepricedExceptionCd() {
		return repricedExceptionCd;
	}
	/**
	 * @param repricedExceptionCd The repricedExceptionCd to set.
	 */
	public void setRepricedExceptionCd(String repricedExceptionCd) {
		this.repricedExceptionCd = repricedExceptionCd;
	}
	/**
	 * @return Returns the repricedPolCmpliantCd.
	 */
	public String getRepricedPolCmpliantCd() {
		return repricedPolCmpliantCd;
	}
	/**
	 * @param repricedPolCmpliantCd The repricedPolCmpliantCd to set.
	 */
	public void setRepricedPolCmpliantCd(String repricedPolCmpliantCd) {
		this.repricedPolCmpliantCd = repricedPolCmpliantCd;
	}
	/**
	 * @return Returns the repricedRejReasonCd.
	 */
	public String getRepricedRejReasonCd() {
		return repricedRejReasonCd;
	}
	/**
	 * @param repricedRejReasonCd The repricedRejReasonCd to set.
	 */
	public void setRepricedRejReasonCd(String repricedRejReasonCd) {
		this.repricedRejReasonCd = repricedRejReasonCd;
	}
	/**
	 * @return Returns the repricedUom.
	 */
	public String getRepricedUom() {
		return repricedUom;
	}
	/**
	 * @param repricedUom The repricedUom to set.
	 */
	public void setRepricedUom(String repricedUom) {
		this.repricedUom = repricedUom;
	}
	/**
	 * @return Returns the repricerReceivedDt.
	 */
	public String getRepricerReceivedDt() {
		return repricerReceivedDt;
	}
	/**
	 * @param repricerReceivedDt The repricerReceivedDt to set.
	 */
	public void setRepricerReceivedDt(String repricerReceivedDt) {
		this.repricerReceivedDt = repricerReceivedDt;
	}
	/**
	 * @return Returns the repricingOrgId.
	 */
	public String getRepricingOrgId() {
		return repricingOrgId;
	}
	/**
	 * @param repricingOrgId The repricingOrgId to set.
	 */
	public void setRepricingOrgId(String repricingOrgId) {
		this.repricingOrgId = repricingOrgId;
	}
	
	/**
	 * @return Returns the formattedStatementFromDt.
	 */
	public String getFormattedStatementFromDt() {
		return formattedStatementFromDt;
	}
	/**
	 * @param formattedStatementFromDt The formattedStatementFromDt to set.
	 */
	public void setFormattedStatementFromDt(String formattedStatementFromDt) {
		this.formattedStatementFromDt = formattedStatementFromDt;
	}
	
	/**
	 * @return Returns the formattedStatementToDt.
	 */
	public String getFormattedStatementToDt() {
		return formattedStatementToDt;
	}
	/**
	 * @param formattedStatementToDt The formattedStatementToDt to set.
	 */
	public void setFormattedStatementToDt(String formattedStatementToDt) {
		this.formattedStatementToDt = formattedStatementToDt;
	}
	/**
	 * @return Returns the subsGrpName.
	 */
	public String getSubsGrpName() {
		return SubsGrpName;
	}
	/**
	 * @param subsGrpName The subsGrpName to set.
	 */
	public void setSubsGrpName(String subsGrpName) {
		SubsGrpName = subsGrpName;
	}
	
	/**
	 * @return Returns the searchSummaryType.
	 */
	public String getSearchSummaryType() {
		return searchSummaryType;
	}
	/**
	 * @param searchSummaryType The searchSummaryType to set.
	 */
	public void setSearchSummaryType(String searchSummaryType) {
		this.searchSummaryType = searchSummaryType;
	}
	
	/**
	 * @return Returns the searchDetailClmType.
	 */
	public String getSearchDetailClmType() {
		return searchDetailClmType;
	}
	/**
	 * @param searchDetailClmType The searchDetailClmType to set.
	 */
	public void setSearchDetailClmType(String searchDetailClmType) {
		this.searchDetailClmType = searchDetailClmType;
	}
	/**
	 * @return the selClaimType
	 */
	public String getSelClaimType() {
		return selClaimType;
	}
	/**
	 * @param selClaimType the selClaimType to set
	 */
	public void setSelClaimType(String selClaimType) {
		this.selClaimType = selClaimType;
	}
	
	
	
	/**
	 * @return Returns the adjudChanged.
	 */
	public boolean isAdjudChanged() {
		return adjudChanged;
	}
	/**
	 * @param adjudChanged The adjudChanged to set.
	 */
	public void setAdjudChanged(boolean adjudChanged) {
		this.adjudChanged = adjudChanged;
	}
		
	/**
	 * @return Returns the clmliSeqNbr.
	 */
	public String getClmliSeqNbr() {
		return clmliSeqNbr;
	}
	/**
	 * @param clmliSeqNbr The clmliSeqNbr to set.
	 */
	public void setClmliSeqNbr(String clmliSeqNbr) {
		this.clmliSeqNbr = clmliSeqNbr;
	}
	/**
	 * @return Returns the clmliBundledLineNbr.
	 */
	public String getClmliBundledLineNbr() {
		return clmliBundledLineNbr;
	}
	/**
	 * @param clmliBundledLineNbr The clmliBundledLineNbr to set.
	 */
	public void setClmliBundledLineNbr(String clmliBundledLineNbr) {
		this.clmliBundledLineNbr = clmliBundledLineNbr;
	}
	/**
	 * @return Returns the othPayrPayerId.
	 */
	public String getOthPayrPayerId() {
		return othPayrPayerId;
	}
	/**
	 * @param othPayrPayerId The othPayrPayerId to set.
	 */
	public void setOthPayrPayerId(String othPayrPayerId) {
		this.othPayrPayerId = othPayrPayerId;
	}
	
	/**
	 * @return Returns the clmliAdjudSeqNbr.
	 */
	public String getClmliAdjudSeqNbr() {
		return clmliAdjudSeqNbr;
	}
	/**
	 * @param clmliAdjudSeqNbr The clmliAdjudSeqNbr to set.
	 */
	public void setClmliAdjudSeqNbr(String clmliAdjudSeqNbr) {
		this.clmliAdjudSeqNbr = clmliAdjudSeqNbr;
	}
	
	
	/**
	 * @return Returns the clmLineChanged.
	 */
	public boolean isClmLineChanged() {
		return clmLineChanged;
	}
	/**
	 * @param clmLineChanged The clmLineChanged to set.
	 */
	public void setClmLineChanged(boolean clmLineChanged) {
		this.clmLineChanged = clmLineChanged;
	}		
	
	/**
	 * @return Returns the formattedLiBeginDt.
	 */
	public String getFormattedLiBeginDt() {
		return formattedLiBeginDt;
	}
	/**
	 * @param formattedLiBeginDt The formattedLiBeginDt to set.
	 */
	public void setFormattedLiBeginDt(String formattedLiBeginDt) {
		this.formattedLiBeginDt = formattedLiBeginDt;
	}
	/**
	 * @return Returns the formattedLiEndDt.
	 */
	public String getFormattedLiEndDt() {
		return formattedLiEndDt;
	}
	/**
	 * @param formattedLiEndDt The formattedLiEndDt to set.
	 */
	public void setFormattedLiEndDt(String formattedLiEndDt) {
		this.formattedLiEndDt = formattedLiEndDt;
	}
	/**
	 * @return Returns the liProcCd.
	 */
	public String getLiProcCd() {
		return liProcCd;
	}
	/**
	 * @param liProcCd The liProcCd to set.
	 */
	public void setLiProcCd(String liProcCd) {
		this.liProcCd = liProcCd;
	}
	/**
	 * @return Returns the liProcDesc.
	 */
	public String getLiProcDesc() {
		return liProcDesc;
	}
	/**
	 * @param liProcDesc The liProcDesc to set.
	 */
	public void setLiProcDesc(String liProcDesc) {
		this.liProcDesc = liProcDesc;
	}
	/**
	 * @return Returns the liProcMod1.
	 */
	public String getLiProcMod1() {
		return liProcMod1;
	}
	/**
	 * @param liProcMod1 The liProcMod1 to set.
	 */
	public void setLiProcMod1(String liProcMod1) {
		this.liProcMod1 = liProcMod1;
	}
	/**
	 * @return Returns the liProcMod2.
	 */
	public String getLiProcMod2() {
		return liProcMod2;
	}
	/**
	 * @param liProcMod2 The liProcMod2 to set.
	 */
	public void setLiProcMod2(String liProcMod2) {
		this.liProcMod2 = liProcMod2;
	}
	/**
	 * @return Returns the liProcMod3.
	 */
	public String getLiProcMod3() {
		return liProcMod3;
	}
	/**
	 * @param liProcMod3 The liProcMod3 to set.
	 */
	public void setLiProcMod3(String liProcMod3) {
		this.liProcMod3 = liProcMod3;
	}
	/**
	 * @return Returns the liProcMod4.
	 */
	public String getLiProcMod4() {
		return liProcMod4;
	}
	/**
	 * @param liProcMod4 The liProcMod4 to set.
	 */
	public void setLiProcMod4(String liProcMod4) {
		this.liProcMod4 = liProcMod4;
	}
	/**
	 * @return Returns the liProdSvcidQual.
	 */
	public String getLiProdSvcidQual() {
		return liProdSvcidQual;
	}
	/**
	 * @param liProdSvcidQual The liProdSvcidQual to set.
	 */
	public void setLiProdSvcidQual(String liProdSvcidQual) {
		this.liProdSvcidQual = liProdSvcidQual;
	}
	/**
	 * @return Returns the liRevenueCd.
	 */
	public String getLiRevenueCd() {
		return liRevenueCd;
	}
	/**
	 * @param liRevenueCd The liRevenueCd to set.
	 */
	public void setLiRevenueCd(String liRevenueCd) {
		this.liRevenueCd = liRevenueCd;
	}
	
	
	/**
	 * @return Returns the clmliAdjudProcCd.
	 */
	public String getClmliAdjudProcCd() {
		return clmliAdjudProcCd;
	}
	/**
	 * @param clmliAdjudProcCd The clmliAdjudProcCd to set.
	 */
	public void setClmliAdjudProcCd(String clmliAdjudProcCd) {
		this.clmliAdjudProcCd = clmliAdjudProcCd;
	}
	/**
	 * @return Returns the clmliAdjudProcDesc.
	 */
	public String getClmliAdjudProcDesc() {
		return clmliAdjudProcDesc;
	}
	/**
	 * @param clmliAdjudProcDesc The clmliAdjudProcDesc to set.
	 */
	public void setClmliAdjudProcDesc(String clmliAdjudProcDesc) {
		this.clmliAdjudProcDesc = clmliAdjudProcDesc;
	}
	/**
	 * @return Returns the clmliAdjudProcMod1.
	 */
	public String getClmliAdjudProcMod1() {
		return clmliAdjudProcMod1;
	}
	/**
	 * @param clmliAdjudProcMod1 The clmliAdjudProcMod1 to set.
	 */
	public void setClmliAdjudProcMod1(String clmliAdjudProcMod1) {
		this.clmliAdjudProcMod1 = clmliAdjudProcMod1;
	}
	/**
	 * @return Returns the clmliAdjudProcMod2.
	 */
	public String getClmliAdjudProcMod2() {
		return clmliAdjudProcMod2;
	}
	/**
	 * @param clmliAdjudProcMod2 The clmliAdjudProcMod2 to set.
	 */
	public void setClmliAdjudProcMod2(String clmliAdjudProcMod2) {
		this.clmliAdjudProcMod2 = clmliAdjudProcMod2;
	}
	/**
	 * @return Returns the clmliAdjudProcMod3.
	 */
	public String getClmliAdjudProcMod3() {
		return clmliAdjudProcMod3;
	}
	/**
	 * @param clmliAdjudProcMod3 The clmliAdjudProcMod3 to set.
	 */
	public void setClmliAdjudProcMod3(String clmliAdjudProcMod3) {
		this.clmliAdjudProcMod3 = clmliAdjudProcMod3;
	}
	/**
	 * @return Returns the clmliAdjudProcMod4.
	 */
	public String getClmliAdjudProcMod4() {
		return clmliAdjudProcMod4;
	}
	/**
	 * @param clmliAdjudProcMod4 The clmliAdjudProcMod4 to set.
	 */
	public void setClmliAdjudProcMod4(String clmliAdjudProcMod4) {
		this.clmliAdjudProcMod4 = clmliAdjudProcMod4;
	}
	/**
	 * @return Returns the clmliAdjudRevenueCd.
	 */
	public String getClmliAdjudRevenueCd() {
		return clmliAdjudRevenueCd;
	}
	/**
	 * @param clmliAdjudRevenueCd The clmliAdjudRevenueCd to set.
	 */
	public void setClmliAdjudRevenueCd(String clmliAdjudRevenueCd) {
		this.clmliAdjudRevenueCd = clmliAdjudRevenueCd;
	}
	/**
	 * @return Returns the exceptionCd.
	 */
	public String getExceptionCd() {
		return exceptionCd;
	}
	/**
	 * @param exceptionCd The exceptionCd to set.
	 */
	public void setExceptionCd(String exceptionCd) {
		this.exceptionCd = exceptionCd;
	}
	
	/**
	 * @return Returns the liServiceUnitCnt.
	 */
	public double getLiServiceUnitCnt() {
		return liServiceUnitCnt;
	}
	/**
	 * @param liServiceUnitCnt The liServiceUnitCnt to set.
	 */
	public void setLiServiceUnitCnt(double liServiceUnitCnt) {
		this.liServiceUnitCnt = liServiceUnitCnt;
	}
	/**
	 * @return Returns the liUomQual.
	 */
	public String getLiUomQual() {
		return liUomQual;
	}
	/**
	 * @param liUomQual The liUomQual to set.
	 */
	public void setLiUomQual(String liUomQual) {
		this.liUomQual = liUomQual;
	}
	/**
	 * @return Returns the nationalDrugCdQual.
	 */
	public String getNationalDrugCdQual() {
		return nationalDrugCdQual;
	}
	/**
	 * @param nationalDrugCdQual The nationalDrugCdQual to set.
	 */
	public void setNationalDrugCdQual(String nationalDrugCdQual) {
		this.nationalDrugCdQual = nationalDrugCdQual;
	}
	/**
	 * @return Returns the pricingMethodology.
	 */
	public String getPricingMethodology() {
		return pricingMethodology;
	}
	/**
	 * @param pricingMethodology The pricingMethodology to set.
	 */
	public void setPricingMethodology(String pricingMethodology) {
		this.pricingMethodology = pricingMethodology;
	}
	/**
	 * @return Returns the prodOrSvcidQual.
	 */
	public String getProdOrSvcidQual() {
		return prodOrSvcidQual;
	}
	/**
	 * @param prodOrSvcidQual The prodOrSvcidQual to set.
	 */
	public void setProdOrSvcidQual(String prodOrSvcidQual) {
		this.prodOrSvcidQual = prodOrSvcidQual;
	}
	
	/**
	 * @return Returns the adjReprcdLiRefNbr.
	 */
	public String getAdjReprcdLiRefNbr() {
		return adjReprcdLiRefNbr;
	}
	/**
	 * @param adjReprcdLiRefNbr The adjReprcdLiRefNbr to set.
	 */
	public void setAdjReprcdLiRefNbr(String adjReprcdLiRefNbr) {
		this.adjReprcdLiRefNbr = adjReprcdLiRefNbr;
	}
	/**
	 * @return Returns the approvedRevenueCd.
	 */
	public String getApprovedRevenueCd() {
		return approvedRevenueCd;
	}
	/**
	 * @param approvedRevenueCd The approvedRevenueCd to set.
	 */
	public void setApprovedRevenueCd(String approvedRevenueCd) {
		this.approvedRevenueCd = approvedRevenueCd;
	}
	
	/**
	 * @return Returns the drugUnitCnt.
	 */
	public int getDrugUnitCnt() {
		return drugUnitCnt;
	}
	/**
	 * @param drugUnitCnt The drugUnitCnt to set.
	 */
	public void setDrugUnitCnt(int drugUnitCnt) {
		this.drugUnitCnt = drugUnitCnt;
	}
	/**
	 * @return Returns the drugUomQual.
	 */
	public String getDrugUomQual() {
		return drugUomQual;
	}
	/**
	 * @param drugUomQual The drugUomQual to set.
	 */
	public void setDrugUomQual(String drugUomQual) {
		this.drugUomQual = drugUomQual;
	}	
	
	/**
	 * @return Returns the linkSequenceNbr.
	 */
	public String getLinkSequenceNbr() {
		return linkSequenceNbr;
	}
	/**
	 * @param linkSequenceNbr The linkSequenceNbr to set.
	 */
	public void setLinkSequenceNbr(String linkSequenceNbr) {
		this.linkSequenceNbr = linkSequenceNbr;
	}
	/**
	 * @return Returns the liNote.
	 */
	public String getLiNote() {
		return liNote;
	}
	/**
	 * @param liNote The liNote to set.
	 */
	public void setLiNote(String liNote) {
		this.liNote = liNote;
	}
	/**
	 * @return Returns the nationalDrugCd.
	 */
	public String getNationalDrugCd() {
		return nationalDrugCd;
	}
	/**
	 * @param nationalDrugCd The nationalDrugCd to set.
	 */
	public void setNationalDrugCd(String nationalDrugCd) {
		this.nationalDrugCd = nationalDrugCd;
	}
	/**
	 * @return Returns the policyComplianceCd.
	 */
	public String getPolicyComplianceCd() {
		return policyComplianceCd;
	}
	/**
	 * @param policyComplianceCd The policyComplianceCd to set.
	 */
	public void setPolicyComplianceCd(String policyComplianceCd) {
		this.policyComplianceCd = policyComplianceCd;
	}
	/**
	 * @return Returns the prescriptionNbr.
	 */
	public String getPrescriptionNbr() {
		return prescriptionNbr;
	}
	/**
	 * @param prescriptionNbr The prescriptionNbr to set.
	 */
	public void setPrescriptionNbr(String prescriptionNbr) {
		this.prescriptionNbr = prescriptionNbr;
	}
	/**
	 * @return Returns the rejectReasonCd.
	 */
	public String getRejectReasonCd() {
		return rejectReasonCd;
	}
	/**
	 * @param rejectReasonCd The rejectReasonCd to set.
	 */
	public void setRejectReasonCd(String rejectReasonCd) {
		this.rejectReasonCd = rejectReasonCd;
	}
	/**
	 * @return Returns the reprcdApprHcpcsCd.
	 */
	public String getReprcdApprHcpcsCd() {
		return reprcdApprHcpcsCd;
	}
	/**
	 * @param reprcdApprHcpcsCd The reprcdApprHcpcsCd to set.
	 */
	public void setReprcdApprHcpcsCd(String reprcdApprHcpcsCd) {
		this.reprcdApprHcpcsCd = reprcdApprHcpcsCd;
	}
	/**
	 * @return Returns the reprcdDrgCd.
	 */
	public String getReprcdDrgCd() {
		return reprcdDrgCd;
	}
	/**
	 * @param reprcdDrgCd The reprcdDrgCd to set.
	 */
	public void setReprcdDrgCd(String reprcdDrgCd) {
		this.reprcdDrgCd = reprcdDrgCd;
	}
	/**
	 * @return Returns the reprcdLiRefNbr.
	 */
	public String getReprcdLiRefNbr() {
		return reprcdLiRefNbr;
	}
	/**
	 * @param reprcdLiRefNbr The reprcdLiRefNbr to set.
	 */
	public void setReprcdLiRefNbr(String reprcdLiRefNbr) {
		this.reprcdLiRefNbr = reprcdLiRefNbr;
	}
	/**
	 * @return Returns the reprcdOrgId.
	 */
	public String getReprcdOrgId() {
		return reprcdOrgId;
	}
	/**
	 * @param reprcdOrgId The reprcdOrgId to set.
	 */
	public void setReprcdOrgId(String reprcdOrgId) {
		this.reprcdOrgId = reprcdOrgId;
	}
	
	/**
	 * @return Returns the reprcdSvcUnitCnt.
	 */
	public double getReprcdSvcUnitCnt() {
		return reprcdSvcUnitCnt;
	}
	/**
	 * @param reprcdSvcUnitCnt The reprcdSvcUnitCnt to set.
	 */
	public void setReprcdSvcUnitCnt(double reprcdSvcUnitCnt) {
		this.reprcdSvcUnitCnt = reprcdSvcUnitCnt;
	}
	/**
	 * @return Returns the reprcdUomCd.
	 */
	public String getReprcdUomCd() {
		return reprcdUomCd;
	}
	/**
	 * @param reprcdUomCd The reprcdUomCd to set.
	 */
	public void setReprcdUomCd(String reprcdUomCd) {
		this.reprcdUomCd = reprcdUomCd;
	}
	/**
	 * @return Returns the serviceCdQual.
	 */
	public String getServiceCdQual() {
		return serviceCdQual;
	}
	/**
	 * @param serviceCdQual The serviceCdQual to set.
	 */
	public void setServiceCdQual(String serviceCdQual) {
		this.serviceCdQual = serviceCdQual;
	}
	
	/**
	 * @return Returns the clmliPaidSvcUnitCnt.
	 */
	public double getClmliPaidSvcUnitCnt() {
		return clmliPaidSvcUnitCnt;
	}
	/**
	 * @param clmliPaidSvcUnitCnt The clmliPaidSvcUnitCnt to set.
	 */
	public void setClmliPaidSvcUnitCnt(double clmliPaidSvcUnitCnt) {
		this.clmliPaidSvcUnitCnt = clmliPaidSvcUnitCnt;
	}
	/**
	 * @return Returns the formattedAdjudPaymentDt.
	 */
	public String getFormattedAdjudPaymentDt() {
		return formattedAdjudPaymentDt;
	}
	/**
	 * @param formattedAdjudPaymentDt The formattedAdjudPaymentDt to set.
	 */
	public void setFormattedAdjudPaymentDt(String formattedAdjudPaymentDt) {
		this.formattedAdjudPaymentDt = formattedAdjudPaymentDt;
	}
	
	/**
	 * @return Returns the liProvCommNbr.
	 */
	public String getLiProvCommNbr() {
		return liProvCommNbr;
	}
	/**
	 * @param liProvCommNbr The liProvCommNbr to set.
	 */
	public void setLiProvCommNbr(String liProvCommNbr) {
		this.liProvCommNbr = liProvCommNbr;
	}
	/**
	 * @return Returns the liProvEntityType.
	 */
	public String getLiProvEntityType() {
		return liProvEntityType;
	}
	/**
	 * @param liProvEntityType The liProvEntityType to set.
	 */
	public void setLiProvEntityType(String liProvEntityType) {
		this.liProvEntityType = liProvEntityType;
	}
	/**
	 * @return Returns the liProvFirstName.
	 */
	public String getLiProvFirstName() {
		return liProvFirstName;
	}
	/**
	 * @param liProvFirstName The liProvFirstName to set.
	 */
	public void setLiProvFirstName(String liProvFirstName) {
		this.liProvFirstName = liProvFirstName;
	}
	/**
	 * @return Returns the liProvLastName.
	 */
	public String getLiProvLastName() {
		return liProvLastName;
	}
	/**
	 * @param liProvLastName The liProvLastName to set.
	 */
	public void setLiProvLastName(String liProvLastName) {
		this.liProvLastName = liProvLastName;
	}
	/**
	 * @return Returns the liProvLicNbr.
	 */
	public String getLiProvLicNbr() {
		return liProvLicNbr;
	}
	/**
	 * @param liProvLicNbr The liProvLicNbr to set.
	 */
	public void setLiProvLicNbr(String liProvLicNbr) {
		this.liProvLicNbr = liProvLicNbr;
	}
	/**
	 * @return Returns the liProvLocNbr.
	 */
	public String getLiProvLocNbr() {
		return liProvLocNbr;
	}
	/**
	 * @param liProvLocNbr The liProvLocNbr to set.
	 */
	public void setLiProvLocNbr(String liProvLocNbr) {
		this.liProvLocNbr = liProvLocNbr;
	}
	/**
	 * @return Returns the liProvMiddleName.
	 */
	public String getLiProvMiddleName() {
		return liProvMiddleName;
	}
	/**
	 * @param liProvMiddleName The liProvMiddleName to set.
	 */
	public void setLiProvMiddleName(String liProvMiddleName) {
		this.liProvMiddleName = liProvMiddleName;
	}
	/**
	 * @return Returns the liProvNpi.
	 */
	public String getLiProvNpi() {
		return liProvNpi;
	}
	/**
	 * @param liProvNpi The liProvNpi to set.
	 */
	public void setLiProvNpi(String liProvNpi) {
		this.liProvNpi = liProvNpi;
	}
	/**
	 * @return Returns the liProvOthPayerId.
	 */
	public String getLiProvOthPayerId() {
		return liProvOthPayerId;
	}
	/**
	 * @param liProvOthPayerId The liProvOthPayerId to set.
	 */
	public void setLiProvOthPayerId(String liProvOthPayerId) {
		this.liProvOthPayerId = liProvOthPayerId;
	}
	/**
	 * @return Returns the liProvUpin.
	 */
	public String getLiProvUpin() {
		return liProvUpin;
	}
	/**
	 * @param liProvUpin The liProvUpin to set.
	 */
	public void setLiProvUpin(String liProvUpin) {
		this.liProvUpin = liProvUpin;
	}
	
	/**
	 * @return Returns the clmLineProvChanged.
	 */
	public boolean isClmLineProvChanged() {
		return clmLineProvChanged;
	}
	/**
	 * @param clmLineProvChanged The clmLineProvChanged to set.
	 */
	public void setClmLineProvChanged(boolean clmLineProvChanged) {
		this.clmLineProvChanged = clmLineProvChanged;
	}
	
	/**
	 * @return Returns the lookupProvType.
	 */
	public String getLookupProvType() {
		return lookupProvType;
	}
	/**
	 * @param lookupProvType The lookupProvType to set.
	 */
	public void setLookupProvType(String lookupProvType) {
		this.lookupProvType = lookupProvType;
	}
	
	/**
	 * @return Returns the claimOtherSubsChanged.
	 */
	public boolean isClaimOtherSubsChanged() {
		return claimOtherSubsChanged;
	}
	/**
	 * @param claimOtherSubsChanged The claimOtherSubsChanged to set.
	 */
	public void setClaimOtherSubsChanged(boolean claimOtherSubsChanged) {
		this.claimOtherSubsChanged = claimOtherSubsChanged;
	}
	
	
	
	/**
	 * @return Returns the benefitsAsgnCertInd.
	 */
	public String getBenefitsAsgnCertInd() {
		return benefitsAsgnCertInd;
	}
	/**
	 * @param benefitsAsgnCertInd The benefitsAsgnCertInd to set.
	 */
	public void setBenefitsAsgnCertInd(String benefitsAsgnCertInd) {
		this.benefitsAsgnCertInd = benefitsAsgnCertInd;
	}
	/**
	 * @return Returns the formattedCheckRemitDt.
	 */
	public String getFormattedCheckRemitDt() {
		return formattedCheckRemitDt;
	}
	/**
	 * @param formattedCheckRemitDt The formattedCheckRemitDt to set.
	 */
	public void setFormattedCheckRemitDt(String formattedCheckRemitDt) {
		this.formattedCheckRemitDt = formattedCheckRemitDt;
	}
	/**
	 * @return Returns the formattedMoaReimburseRate.
	 */
	public int getFormattedMoaReimburseRate() {
		return formattedMoaReimburseRate;
	}
	/**
	 * @param formattedMoaReimburseRate The formattedMoaReimburseRate to set.
	 */
	public void setFormattedMoaReimburseRate(int formattedMoaReimburseRate) {
		this.formattedMoaReimburseRate = formattedMoaReimburseRate;
	}
	/**
	 * @return Returns the formattedOthPayrTaxId.
	 */
	public String getFormattedOthPayrTaxId() {
		return formattedOthPayrTaxId;
	}
	/**
	 * @param formattedOthPayrTaxId The formattedOthPayrTaxId to set.
	 */
	public void setFormattedOthPayrTaxId(String formattedOthPayrTaxId) {
		this.formattedOthPayrTaxId = formattedOthPayrTaxId;
	}
	/**
	 * @return Returns the indivRelationshipCd.
	 */
	public String getIndivRelationshipCd() {
		return indivRelationshipCd;
	}
	/**
	 * @param indivRelationshipCd The indivRelationshipCd to set.
	 */
	public void setIndivRelationshipCd(String indivRelationshipCd) {
		this.indivRelationshipCd = indivRelationshipCd;
	}
	/**
	 * @return Returns the insuredGrpOrPolNbr.
	 */
	public String getInsuredGrpOrPolNbr() {
		return insuredGrpOrPolNbr;
	}
	/**
	 * @param insuredGrpOrPolNbr The insuredGrpOrPolNbr to set.
	 */
	public void setInsuredGrpOrPolNbr(String insuredGrpOrPolNbr) {
		this.insuredGrpOrPolNbr = insuredGrpOrPolNbr;
	}
	/**
	 * @return Returns the miaClmpmtRemarkCd.
	 */
	public String getMiaClmpmtRemarkCd() {
		return miaClmpmtRemarkCd;
	}
	/**
	 * @param miaClmpmtRemarkCd The miaClmpmtRemarkCd to set.
	 */
	public void setMiaClmpmtRemarkCd(String miaClmpmtRemarkCd) {
		this.miaClmpmtRemarkCd = miaClmpmtRemarkCd;
	}
	/**
	 * @return Returns the miaClmPmtRemarkCd1.
	 */
	public String getMiaClmPmtRemarkCd1() {
		return miaClmPmtRemarkCd1;
	}
	/**
	 * @param miaClmPmtRemarkCd1 The miaClmPmtRemarkCd1 to set.
	 */
	public void setMiaClmPmtRemarkCd1(String miaClmPmtRemarkCd1) {
		this.miaClmPmtRemarkCd1 = miaClmPmtRemarkCd1;
	}
	/**
	 * @return Returns the miaClmPmtRemarkCd2.
	 */
	public String getMiaClmPmtRemarkCd2() {
		return miaClmPmtRemarkCd2;
	}
	/**
	 * @param miaClmPmtRemarkCd2 The miaClmPmtRemarkCd2 to set.
	 */
	public void setMiaClmPmtRemarkCd2(String miaClmPmtRemarkCd2) {
		this.miaClmPmtRemarkCd2 = miaClmPmtRemarkCd2;
	}
	/**
	 * @return Returns the miaClmPmtRemarkCd3.
	 */
	public String getMiaClmPmtRemarkCd3() {
		return miaClmPmtRemarkCd3;
	}
	/**
	 * @param miaClmPmtRemarkCd3 The miaClmPmtRemarkCd3 to set.
	 */
	public void setMiaClmPmtRemarkCd3(String miaClmPmtRemarkCd3) {
		this.miaClmPmtRemarkCd3 = miaClmPmtRemarkCd3;
	}
	/**
	 * @return Returns the miaClmPmtRemarkCd4.
	 */
	public String getMiaClmPmtRemarkCd4() {
		return miaClmPmtRemarkCd4;
	}
	/**
	 * @param miaClmPmtRemarkCd4 The miaClmPmtRemarkCd4 to set.
	 */
	public void setMiaClmPmtRemarkCd4(String miaClmPmtRemarkCd4) {
		this.miaClmPmtRemarkCd4 = miaClmPmtRemarkCd4;
	}
	/**
	 * @return Returns the miaCostDayCnt.
	 */
	public int getMiaCostDayCnt() {
		return miaCostDayCnt;
	}
	/**
	 * @param miaCostDayCnt The miaCostDayCnt to set.
	 */
	public void setMiaCostDayCnt(int miaCostDayCnt) {
		this.miaCostDayCnt = miaCostDayCnt;
	}
	/**
	 * @return Returns the miaCoveredDays.
	 */
	public int getMiaCoveredDays() {
		return miaCoveredDays;
	}
	/**
	 * @param miaCoveredDays The miaCoveredDays to set.
	 */
	public void setMiaCoveredDays(int miaCoveredDays) {
		this.miaCoveredDays = miaCoveredDays;
	}
	/**
	 * @return Returns the miaLifePsychDayCnt.
	 */
	public int getMiaLifePsychDayCnt() {
		return miaLifePsychDayCnt;
	}
	/**
	 * @param miaLifePsychDayCnt The miaLifePsychDayCnt to set.
	 */
	public void setMiaLifePsychDayCnt(int miaLifePsychDayCnt) {
		this.miaLifePsychDayCnt = miaLifePsychDayCnt;
	}
	/**
	 * @return Returns the moaClmPmtRemarkCd1.
	 */
	public String getMoaClmPmtRemarkCd1() {
		return moaClmPmtRemarkCd1;
	}
	/**
	 * @param moaClmPmtRemarkCd1 The moaClmPmtRemarkCd1 to set.
	 */
	public void setMoaClmPmtRemarkCd1(String moaClmPmtRemarkCd1) {
		this.moaClmPmtRemarkCd1 = moaClmPmtRemarkCd1;
	}
	/**
	 * @return Returns the moaClmPmtRemarkCd2.
	 */
	public String getMoaClmPmtRemarkCd2() {
		return moaClmPmtRemarkCd2;
	}
	/**
	 * @param moaClmPmtRemarkCd2 The moaClmPmtRemarkCd2 to set.
	 */
	public void setMoaClmPmtRemarkCd2(String moaClmPmtRemarkCd2) {
		this.moaClmPmtRemarkCd2 = moaClmPmtRemarkCd2;
	}
	/**
	 * @return Returns the moaClmPmtRemarkCd3.
	 */
	public String getMoaClmPmtRemarkCd3() {
		return moaClmPmtRemarkCd3;
	}
	/**
	 * @param moaClmPmtRemarkCd3 The moaClmPmtRemarkCd3 to set.
	 */
	public void setMoaClmPmtRemarkCd3(String moaClmPmtRemarkCd3) {
		this.moaClmPmtRemarkCd3 = moaClmPmtRemarkCd3;
	}
	/**
	 * @return Returns the moaClmPmtRemarkCd4.
	 */
	public String getMoaClmPmtRemarkCd4() {
		return moaClmPmtRemarkCd4;
	}
	/**
	 * @param moaClmPmtRemarkCd4 The moaClmPmtRemarkCd4 to set.
	 */
	public void setMoaClmPmtRemarkCd4(String moaClmPmtRemarkCd4) {
		this.moaClmPmtRemarkCd4 = moaClmPmtRemarkCd4;
	}
	/**
	 * @return Returns the moaClmPmtRemarkCd5.
	 */
	public String getMoaClmPmtRemarkCd5() {
		return moaClmPmtRemarkCd5;
	}
	/**
	 * @param moaClmPmtRemarkCd5 The moaClmPmtRemarkCd5 to set.
	 */
	public void setMoaClmPmtRemarkCd5(String moaClmPmtRemarkCd5) {
		this.moaClmPmtRemarkCd5 = moaClmPmtRemarkCd5;
	}
	/**
	 * @return Returns the otherClmFilingInd.
	 */
	public String getOtherClmFilingInd() {
		return otherClmFilingInd;
	}
	/**
	 * @param otherClmFilingInd The otherClmFilingInd to set.
	 */
	public void setOtherClmFilingInd(String otherClmFilingInd) {
		this.otherClmFilingInd = otherClmFilingInd;
	}
	/**
	 * @return Returns the othPayrAddrLine1.
	 */
	public String getOthPayrAddrLine1() {
		return othPayrAddrLine1;
	}
	/**
	 * @param othPayrAddrLine1 The othPayrAddrLine1 to set.
	 */
	public void setOthPayrAddrLine1(String othPayrAddrLine1) {
		this.othPayrAddrLine1 = othPayrAddrLine1;
	}
	/**
	 * @return Returns the othPayrAddrLine2.
	 */
	public String getOthPayrAddrLine2() {
		return othPayrAddrLine2;
	}
	/**
	 * @param othPayrAddrLine2 The othPayrAddrLine2 to set.
	 */
	public void setOthPayrAddrLine2(String othPayrAddrLine2) {
		this.othPayrAddrLine2 = othPayrAddrLine2;
	}
	/**
	 * @return Returns the othPayrCity.
	 */
	public String getOthPayrCity() {
		return othPayrCity;
	}
	/**
	 * @param othPayrCity The othPayrCity to set.
	 */
	public void setOthPayrCity(String othPayrCity) {
		this.othPayrCity = othPayrCity;
	}
	/**
	 * @return Returns the othPayrClmadjInd.
	 */
	public String getOthPayrClmadjInd() {
		return othPayrClmadjInd;
	}
	/**
	 * @param othPayrClmadjInd The othPayrClmadjInd to set.
	 */
	public void setOthPayrClmadjInd(String othPayrClmadjInd) {
		this.othPayrClmadjInd = othPayrClmadjInd;
	}
	/**
	 * @return Returns the othPayrClmCtrlNbr.
	 */
	public String getOthPayrClmCtrlNbr() {
		return othPayrClmCtrlNbr;
	}
	/**
	 * @param othPayrClmCtrlNbr The othPayrClmCtrlNbr to set.
	 */
	public void setOthPayrClmCtrlNbr(String othPayrClmCtrlNbr) {
		this.othPayrClmCtrlNbr = othPayrClmCtrlNbr;
	}
	/**
	 * @return Returns the othPayrCntrySubdCd.
	 */
	public String getOthPayrCntrySubdCd() {
		return othPayrCntrySubdCd;
	}
	/**
	 * @param othPayrCntrySubdCd The othPayrCntrySubdCd to set.
	 */
	public void setOthPayrCntrySubdCd(String othPayrCntrySubdCd) {
		this.othPayrCntrySubdCd = othPayrCntrySubdCd;
	}
	/**
	 * @return Returns the othPayrCountry.
	 */
	public String getOthPayrCountry() {
		return othPayrCountry;
	}
	/**
	 * @param othPayrCountry The othPayrCountry to set.
	 */
	public void setOthPayrCountry(String othPayrCountry) {
		this.othPayrCountry = othPayrCountry;
	}
	/**
	 * @return Returns the othPayrLocNbr.
	 */
	public String getOthPayrLocNbr() {
		return othPayrLocNbr;
	}
	/**
	 * @param othPayrLocNbr The othPayrLocNbr to set.
	 */
	public void setOthPayrLocNbr(String othPayrLocNbr) {
		this.othPayrLocNbr = othPayrLocNbr;
	}
	/**
	 * @return Returns the othPayrNaic.
	 */
	public String getOthPayrNaic() {
		return othPayrNaic;
	}
	/**
	 * @param othPayrNaic The othPayrNaic to set.
	 */
	public void setOthPayrNaic(String othPayrNaic) {
		this.othPayrNaic = othPayrNaic;
	}
	/**
	 * @return Returns the othPayrOrgName.
	 */
	public String getOthPayrOrgName() {
		return othPayrOrgName;
	}
	/**
	 * @param othPayrOrgName The othPayrOrgName to set.
	 */
	public void setOthPayrOrgName(String othPayrOrgName) {
		this.othPayrOrgName = othPayrOrgName;
	}
	/**
	 * @return Returns the othPayrPlanId.
	 */
	public String getOthPayrPlanId() {
		return othPayrPlanId;
	}
	/**
	 * @param othPayrPlanId The othPayrPlanId to set.
	 */
	public void setOthPayrPlanId(String othPayrPlanId) {
		this.othPayrPlanId = othPayrPlanId;
	}
	/**
	 * @return Returns the othPayrPriorAuthNbr.
	 */
	public String getOthPayrPriorAuthNbr() {
		return othPayrPriorAuthNbr;
	}
	/**
	 * @param othPayrPriorAuthNbr The othPayrPriorAuthNbr to set.
	 */
	public void setOthPayrPriorAuthNbr(String othPayrPriorAuthNbr) {
		this.othPayrPriorAuthNbr = othPayrPriorAuthNbr;
	}
	/**
	 * @return Returns the othPayrReferralNbr.
	 */
	public String getOthPayrReferralNbr() {
		return othPayrReferralNbr;
	}
	/**
	 * @param othPayrReferralNbr The othPayrReferralNbr to set.
	 */
	public void setOthPayrReferralNbr(String othPayrReferralNbr) {
		this.othPayrReferralNbr = othPayrReferralNbr;
	}
	/**
	 * @return Returns the othPayrSecId.
	 */
	public String getOthPayrSecId() {
		return othPayrSecId;
	}
	/**
	 * @param othPayrSecId The othPayrSecId to set.
	 */
	public void setOthPayrSecId(String othPayrSecId) {
		this.othPayrSecId = othPayrSecId;
	}
	/**
	 * @return Returns the othPayrState.
	 */
	public String getOthPayrState() {
		return othPayrState;
	}
	/**
	 * @param othPayrState The othPayrState to set.
	 */
	public void setOthPayrState(String othPayrState) {
		this.othPayrState = othPayrState;
	}
	/**
	 * @return Returns the othPayrZip.
	 */
	public String getOthPayrZip() {
		return othPayrZip;
	}
	/**
	 * @param othPayrZip The othPayrZip to set.
	 */
	public void setOthPayrZip(String othPayrZip) {
		this.othPayrZip = othPayrZip;
	}
	/**
	 * @return Returns the othSubsPayrPayerId.
	 */
	public String getOthSubsPayrPayerId() {
		return othSubsPayrPayerId;
	}
	/**
	 * @param othSubsPayrPayerId The othSubsPayrPayerId to set.
	 */
	public void setOthSubsPayrPayerId(String othSubsPayrPayerId) {
		this.othSubsPayrPayerId = othSubsPayrPayerId;
	}
	/**
	 * @return Returns the payerResponseCd.
	 */
	public String getPayerResponseCd() {
		return payerResponseCd;
	}
	/**
	 * @param payerResponseCd The payerResponseCd to set.
	 */
	public void setPayerResponseCd(String payerResponseCd) {
		this.payerResponseCd = payerResponseCd;
	}
	/**
	 * @return Returns the releaseMedRcdFlg.
	 */
	public String getReleaseMedRcdFlg() {
		return releaseMedRcdFlg;
	}
	/**
	 * @param releaseMedRcdFlg The releaseMedRcdFlg to set.
	 */
	public void setReleaseMedRcdFlg(String releaseMedRcdFlg) {
		this.releaseMedRcdFlg = releaseMedRcdFlg;
	}
	
	/**
	 * @return Returns the othSubsSeqNbr.
	 */
	public String getOthSubsSeqNbr() {
		return othSubsSeqNbr;
	}
	/**
	 * @param othSubsSeqNbr The othSubsSeqNbr to set.
	 */
	public void setOthSubsSeqNbr(String othSubsSeqNbr) {
		this.othSubsSeqNbr = othSubsSeqNbr;
	}
	
	/**
	 * @return Returns the clmLineAdjudExist.
	 */
	public String getClmLineAdjudExist() {
		return clmLineAdjudExist;
	}
	/**
	 * @param clmLineAdjudExist The clmLineAdjudExist to set.
	 */
	public void setClmLineAdjudExist(String clmLineAdjudExist) {
		this.clmLineAdjudExist = clmLineAdjudExist;
	}
	/**
	 * @return Returns the clmLinesExist.
	 */
	public String getClmLinesExist() {
		return clmLinesExist;
	}
	/**
	 * @param clmLinesExist The clmLinesExist to set.
	 */
	public void setClmLinesExist(String clmLinesExist) {
		this.clmLinesExist = clmLinesExist;
	}
	/**
	 * @return Returns the clmOtherSubscribersExist.
	 */
	public String getClmOtherSubscribersExist() {
		return clmOtherSubscribersExist;
	}
	/**
	 * @param clmOtherSubscribersExist The clmOtherSubscribersExist to set.
	 */
	public void setClmOtherSubscribersExist(String clmOtherSubscribersExist) {
		this.clmOtherSubscribersExist = clmOtherSubscribersExist;
	}
	
	/**
	 * @return Returns the clmLineProvExist.
	 */
	public String getClmLineProvExist() {
		return clmLineProvExist;
	}
	/**
	 * @param clmLineProvExist The clmLineProvExist to set.
	 */
	public void setClmLineProvExist(String clmLineProvExist) {
		this.clmLineProvExist = clmLineProvExist;
	}
	
	/**
	 * @return Returns the claimOtherSubsProvChanged.
	 */
	public boolean isClaimOtherSubsProvChanged() {
		return claimOtherSubsProvChanged;
	}
	/**
	 * @param claimOtherSubsProvChanged The claimOtherSubsProvChanged to set.
	 */
	public void setClaimOtherSubsProvChanged(boolean claimOtherSubsProvChanged) {
		this.claimOtherSubsProvChanged = claimOtherSubsProvChanged;
	}
	/**
	 * @return Returns the clmOtherSubsProvExist.
	 */
	public String getClmOtherSubsProvExist() {
		return clmOtherSubsProvExist;
	}
	/**
	 * @param clmOtherSubsProvExist The clmOtherSubsProvExist to set.
	 */
	public void setClmOtherSubsProvExist(String clmOtherSubsProvExist) {
		this.clmOtherSubsProvExist = clmOtherSubsProvExist;
	}
	
	/**
	 * @return Returns the othPayrProvCommNbr.
	 */
	public String getOthPayrProvCommNbr() {
		return othPayrProvCommNbr;
	}
	/**
	 * @param othPayrProvCommNbr The othPayrProvCommNbr to set.
	 */
	public void setOthPayrProvCommNbr(String othPayrProvCommNbr) {
		this.othPayrProvCommNbr = othPayrProvCommNbr;
	}
	/**
	 * @return Returns the othPayrProvLicNbr.
	 */
	public String getOthPayrProvLicNbr() {
		return othPayrProvLicNbr;
	}
	/**
	 * @param othPayrProvLicNbr The othPayrProvLicNbr to set.
	 */
	public void setOthPayrProvLicNbr(String othPayrProvLicNbr) {
		this.othPayrProvLicNbr = othPayrProvLicNbr;
	}
	/**
	 * @return Returns the othPayrProvLocNbr.
	 */
	public String getOthPayrProvLocNbr() {
		return othPayrProvLocNbr;
	}
	/**
	 * @param othPayrProvLocNbr The othPayrProvLocNbr to set.
	 */
	public void setOthPayrProvLocNbr(String othPayrProvLocNbr) {
		this.othPayrProvLocNbr = othPayrProvLocNbr;
	}
	/**
	 * @return Returns the othPayrProvUpin.
	 */
	public String getOthPayrProvUpin() {
		return othPayrProvUpin;
	}
	/**
	 * @param othPayrProvUpin The othPayrProvUpin to set.
	 */
	public void setOthPayrProvUpin(String othPayrProvUpin) {
		this.othPayrProvUpin = othPayrProvUpin;
	}
	
	/**
	 * @return Returns the lookupOthPayrProvType.
	 */
	public String getLookupOthPayrProvType() {
		return lookupOthPayrProvType;
	}
	/**
	 * @param lookupOthPayrProvType The lookupOthPayrProvType to set.
	 */
	public void setLookupOthPayrProvType(String lookupOthPayrProvType) {
		this.lookupOthPayrProvType = lookupOthPayrProvType;
	}
	
	/**
	 * @return Returns the patSignSrcCd.
	 */
	public String getPatSignSrcCd() {
		return patSignSrcCd;
	}
	/**
	 * @param patSignSrcCd The patSignSrcCd to set.
	 */
	public void setPatSignSrcCd(String patSignSrcCd) {
		this.patSignSrcCd = patSignSrcCd;
	}
	
	/**
	 * @return Returns the othPayrProvEntityType.
	 */
	public String getOthPayrProvEntityType() {
		return othPayrProvEntityType;
	}
	/**
	 * @param othPayrProvEntityType The othPayrProvEntityType to set.
	 */
	public void setOthPayrProvEntityType(String othPayrProvEntityType) {
		this.othPayrProvEntityType = othPayrProvEntityType;
	}
	
	/**
	 * @return Returns the ambPatientWeight.
	 */
	public int getAmbPatientWeight() {
		return ambPatientWeight;
	}
	/**
	 * @param ambPatientWeight The ambPatientWeight to set.
	 */
	public void setAmbPatientWeight(int ambPatientWeight) {
		this.ambPatientWeight = ambPatientWeight;
	}
	/**
	 * @return Returns the ambRoundTripPurpDesc.
	 */
	public String getAmbRoundTripPurpDesc() {
		return ambRoundTripPurpDesc;
	}
	/**
	 * @param ambRoundTripPurpDesc The ambRoundTripPurpDesc to set.
	 */
	public void setAmbRoundTripPurpDesc(String ambRoundTripPurpDesc) {
		this.ambRoundTripPurpDesc = ambRoundTripPurpDesc;
	}
	/**
	 * @return Returns the ambStretcherPurpDesc.
	 */
	public String getAmbStretcherPurpDesc() {
		return ambStretcherPurpDesc;
	}
	/**
	 * @param ambStretcherPurpDesc The ambStretcherPurpDesc to set.
	 */
	public void setAmbStretcherPurpDesc(String ambStretcherPurpDesc) {
		this.ambStretcherPurpDesc = ambStretcherPurpDesc;
	}
	/**
	 * @return Returns the ambTransportDistance.
	 */
	public int getAmbTransportDistance() {
		return ambTransportDistance;
	}
	/**
	 * @param ambTransportDistance The ambTransportDistance to set.
	 */
	public void setAmbTransportDistance(int ambTransportDistance) {
		this.ambTransportDistance = ambTransportDistance;
	}
	/**
	 * @return Returns the ambTransportReasCd.
	 */
	public String getAmbTransportReasCd() {
		return ambTransportReasCd;
	}
	/**
	 * @param ambTransportReasCd The ambTransportReasCd to set.
	 */
	public void setAmbTransportReasCd(String ambTransportReasCd) {
		this.ambTransportReasCd = ambTransportReasCd;
	}
	/**
	 * @return Returns the cliaImproveAmendNbr.
	 */
	public String getCliaImproveAmendNbr() {
		return cliaImproveAmendNbr;
	}
	/**
	 * @param cliaImproveAmendNbr The cliaImproveAmendNbr to set.
	 */
	public void setCliaImproveAmendNbr(String cliaImproveAmendNbr) {
		this.cliaImproveAmendNbr = cliaImproveAmendNbr;
	}
	/**
	 * @return Returns the creatinineResult.
	 */
	public String getCreatinineResult() {
		return creatinineResult;
	}
	/**
	 * @param creatinineResult The creatinineResult to set.
	 */
	public void setCreatinineResult(String creatinineResult) {
		this.creatinineResult = creatinineResult;
	}
	/**
	 * @return Returns the dmeAttachTransmitCd.
	 */
	public String getDmeAttachTransmitCd() {
		return dmeAttachTransmitCd;
	}
	/**
	 * @param dmeAttachTransmitCd The dmeAttachTransmitCd to set.
	 */
	public void setDmeAttachTransmitCd(String dmeAttachTransmitCd) {
		this.dmeAttachTransmitCd = dmeAttachTransmitCd;
	}
	/**
	 * @return Returns the dmeCertCondInd.
	 */
	public String getDmeCertCondInd() {
		return dmeCertCondInd;
	}
	/**
	 * @param dmeCertCondInd The dmeCertCondInd to set.
	 */
	public void setDmeCertCondInd(String dmeCertCondInd) {
		this.dmeCertCondInd = dmeCertCondInd;
	}
	/**
	 * @return Returns the dmeCertOnFileCd1.
	 */
	public String getDmeCertOnFileCd1() {
		return dmeCertOnFileCd1;
	}
	/**
	 * @param dmeCertOnFileCd1 The dmeCertOnFileCd1 to set.
	 */
	public void setDmeCertOnFileCd1(String dmeCertOnFileCd1) {
		this.dmeCertOnFileCd1 = dmeCertOnFileCd1;
	}
	/**
	 * @return Returns the dmeCertOnFileCd2.
	 */
	public String getDmeCertOnFileCd2() {
		return dmeCertOnFileCd2;
	}
	/**
	 * @param dmeCertOnFileCd2 The dmeCertOnFileCd2 to set.
	 */
	public void setDmeCertOnFileCd2(String dmeCertOnFileCd2) {
		this.dmeCertOnFileCd2 = dmeCertOnFileCd2;
	}
	/**
	 * @return Returns the dmeCertTypeCd.
	 */
	public String getDmeCertTypeCd() {
		return dmeCertTypeCd;
	}
	/**
	 * @param dmeCertTypeCd The dmeCertTypeCd to set.
	 */
	public void setDmeCertTypeCd(String dmeCertTypeCd) {
		this.dmeCertTypeCd = dmeCertTypeCd;
	}
	/**
	 * @return Returns the dmeDuration.
	 */
	public int getDmeDuration() {
		return dmeDuration;
	}
	/**
	 * @param dmeDuration The dmeDuration to set.
	 */
	public void setDmeDuration(int dmeDuration) {
		this.dmeDuration = dmeDuration;
	}
	/**
	 * @return Returns the epoetinStartDoseRslt.
	 */
	public String getEpoetinStartDoseRslt() {
		return epoetinStartDoseRslt;
	}
	/**
	 * @param epoetinStartDoseRslt The epoetinStartDoseRslt to set.
	 */
	public void setEpoetinStartDoseRslt(String epoetinStartDoseRslt) {
		this.epoetinStartDoseRslt = epoetinStartDoseRslt;
	}
	/**
	 * @return Returns the formattedBeginTherapyDt.
	 */
	public String getFormattedBeginTherapyDt() {
		return formattedBeginTherapyDt;
	}
	/**
	 * @param formattedBeginTherapyDt The formattedBeginTherapyDt to set.
	 */
	public void setFormattedBeginTherapyDt(String formattedBeginTherapyDt) {
		this.formattedBeginTherapyDt = formattedBeginTherapyDt;
	}
	/**
	 * @return Returns the formattedContractPct.
	 */
	public double getFormattedContractPct() {
		return formattedContractPct;
	}
	/**
	 * @param formattedContractPct The formattedContractPct to set.
	 */
	public void setFormattedContractPct(double formattedContractPct) {
		this.formattedContractPct = formattedContractPct;
	}
	/**
	 * @return Returns the formattedContractTermsDiscPct.
	 */
	public double getFormattedContractTermsDiscPct() {
		return formattedContractTermsDiscPct;
	}
	/**
	 * @param formattedContractTermsDiscPct The formattedContractTermsDiscPct to set.
	 */
	public void setFormattedContractTermsDiscPct(
			double formattedContractTermsDiscPct) {
		this.formattedContractTermsDiscPct = formattedContractTermsDiscPct;
	}
	/**
	 * @return Returns the formattedHemoglobinDt.
	 */
	public String getFormattedHemoglobinDt() {
		return formattedHemoglobinDt;
	}
	/**
	 * @param formattedHemoglobinDt The formattedHemoglobinDt to set.
	 */
	public void setFormattedHemoglobinDt(String formattedHemoglobinDt) {
		this.formattedHemoglobinDt = formattedHemoglobinDt;
	}
	/**
	 * @return Returns the formattedLastCertificationDt.
	 */
	public String getFormattedLastCertificationDt() {
		return formattedLastCertificationDt;
	}
	/**
	 * @param formattedLastCertificationDt The formattedLastCertificationDt to set.
	 */
	public void setFormattedLastCertificationDt(
			String formattedLastCertificationDt) {
		this.formattedLastCertificationDt = formattedLastCertificationDt;
	}
	/**
	 * @return Returns the formattedPrescriptionDt.
	 */
	public String getFormattedPrescriptionDt() {
		return formattedPrescriptionDt;
	}
	/**
	 * @param formattedPrescriptionDt The formattedPrescriptionDt to set.
	 */
	public void setFormattedPrescriptionDt(String formattedPrescriptionDt) {
		this.formattedPrescriptionDt = formattedPrescriptionDt;
	}
	/**
	 * @return Returns the formattedRecertificationDt.
	 */
	public String getFormattedRecertificationDt() {
		return formattedRecertificationDt;
	}
	/**
	 * @param formattedRecertificationDt The formattedRecertificationDt to set.
	 */
	public void setFormattedRecertificationDt(String formattedRecertificationDt) {
		this.formattedRecertificationDt = formattedRecertificationDt;
	}
	/**
	 * @return Returns the formattedSerumCreatineDt.
	 */
	public String getFormattedSerumCreatineDt() {
		return formattedSerumCreatineDt;
	}
	/**
	 * @param formattedSerumCreatineDt The formattedSerumCreatineDt to set.
	 */
	public void setFormattedSerumCreatineDt(String formattedSerumCreatineDt) {
		this.formattedSerumCreatineDt = formattedSerumCreatineDt;
	}
	/**
	 * @return Returns the formattedServiceBeginDt.
	 */
	public String getFormattedServiceBeginDt() {
		return formattedServiceBeginDt;
	}
	/**
	 * @param formattedServiceBeginDt The formattedServiceBeginDt to set.
	 */
	public void setFormattedServiceBeginDt(String formattedServiceBeginDt) {
		this.formattedServiceBeginDt = formattedServiceBeginDt;
	}
	/**
	 * @return Returns the formattedServiceEndDt.
	 */
	public String getFormattedServiceEndDt() {
		return formattedServiceEndDt;
	}
	/**
	 * @param formattedServiceEndDt The formattedServiceEndDt to set.
	 */
	public void setFormattedServiceEndDt(String formattedServiceEndDt) {
		this.formattedServiceEndDt = formattedServiceEndDt;
	}
	/**
	 * @return Returns the formattedShippedDt.
	 */
	public String getFormattedShippedDt() {
		return formattedShippedDt;
	}
	/**
	 * @param formattedShippedDt The formattedShippedDt to set.
	 */
	public void setFormattedShippedDt(String formattedShippedDt) {
		this.formattedShippedDt = formattedShippedDt;
	}
	/**
	 * @return Returns the formattedTreatmentTherapyDt.
	 */
	public String getFormattedTreatmentTherapyDt() {
		return formattedTreatmentTherapyDt;
	}
	/**
	 * @param formattedTreatmentTherapyDt The formattedTreatmentTherapyDt to set.
	 */
	public void setFormattedTreatmentTherapyDt(
			String formattedTreatmentTherapyDt) {
		this.formattedTreatmentTherapyDt = formattedTreatmentTherapyDt;
	}
	/**
	 * @return Returns the heightResult.
	 */
	public String getHeightResult() {
		return heightResult;
	}
	/**
	 * @param heightResult The heightResult to set.
	 */
	public void setHeightResult(String heightResult) {
		this.heightResult = heightResult;
	}
	/**
	 * @return Returns the hematocritResult.
	 */
	public String getHematocritResult() {
		return hematocritResult;
	}
	/**
	 * @param hematocritResult The hematocritResult to set.
	 */
	public void setHematocritResult(String hematocritResult) {
		this.hematocritResult = hematocritResult;
	}
	/**
	 * @return Returns the hemoglobinResult.
	 */
	public String getHemoglobinResult() {
		return hemoglobinResult;
	}
	/**
	 * @param hemoglobinResult The hemoglobinResult to set.
	 */
	public void setHemoglobinResult(String hemoglobinResult) {
		this.hemoglobinResult = hemoglobinResult;
	}
	/**
	 * @return Returns the hospiceEmployedPrvInd.
	 */
	public String getHospiceEmployedPrvInd() {
		return hospiceEmployedPrvInd;
	}
	/**
	 * @param hospiceEmployedPrvInd The hospiceEmployedPrvInd to set.
	 */
	public void setHospiceEmployedPrvInd(String hospiceEmployedPrvInd) {
		this.hospiceEmployedPrvInd = hospiceEmployedPrvInd;
	}
	/**
	 * @return Returns the immunizationBatchNbr.
	 */
	public String getImmunizationBatchNbr() {
		return immunizationBatchNbr;
	}
	/**
	 * @param immunizationBatchNbr The immunizationBatchNbr to set.
	 */
	public void setImmunizationBatchNbr(String immunizationBatchNbr) {
		this.immunizationBatchNbr = immunizationBatchNbr;
	}
	/**
	 * @return Returns the initialTreatmentDt.
	 */
	public String getInitialTreatmentDt() {
		return initialTreatmentDt;
	}
	/**
	 * @param initialTreatmentDt The initialTreatmentDt to set.
	 */
	public void setInitialTreatmentDt(String initialTreatmentDt) {
		this.initialTreatmentDt = initialTreatmentDt;
	}
	/**
	 * @return Returns the lastXrayDt.
	 */
	public String getLastXrayDt() {
		return lastXrayDt;
	}
	/**
	 * @param lastXrayDt The lastXrayDt to set.
	 */
	public void setLastXrayDt(String lastXrayDt) {
		this.lastXrayDt = lastXrayDt;
	}
	/**
	 * @return Returns the liAmbCertCondCd1.
	 */
	public String getLiAmbCertCondCd1() {
		return liAmbCertCondCd1;
	}
	/**
	 * @param liAmbCertCondCd1 The liAmbCertCondCd1 to set.
	 */
	public void setLiAmbCertCondCd1(String liAmbCertCondCd1) {
		this.liAmbCertCondCd1 = liAmbCertCondCd1;
	}
	/**
	 * @return Returns the liAmbCertCondCd2.
	 */
	public String getLiAmbCertCondCd2() {
		return liAmbCertCondCd2;
	}
	/**
	 * @param liAmbCertCondCd2 The liAmbCertCondCd2 to set.
	 */
	public void setLiAmbCertCondCd2(String liAmbCertCondCd2) {
		this.liAmbCertCondCd2 = liAmbCertCondCd2;
	}
	/**
	 * @return Returns the liAmbCertCondCd3.
	 */
	public String getLiAmbCertCondCd3() {
		return liAmbCertCondCd3;
	}
	/**
	 * @param liAmbCertCondCd3 The liAmbCertCondCd3 to set.
	 */
	public void setLiAmbCertCondCd3(String liAmbCertCondCd3) {
		this.liAmbCertCondCd3 = liAmbCertCondCd3;
	}
	/**
	 * @return Returns the liAmbCertCondCd4.
	 */
	public String getLiAmbCertCondCd4() {
		return liAmbCertCondCd4;
	}
	/**
	 * @param liAmbCertCondCd4 The liAmbCertCondCd4 to set.
	 */
	public void setLiAmbCertCondCd4(String liAmbCertCondCd4) {
		this.liAmbCertCondCd4 = liAmbCertCondCd4;
	}
	/**
	 * @return Returns the liAmbCertCondCd5.
	 */
	public String getLiAmbCertCondCd5() {
		return liAmbCertCondCd5;
	}
	/**
	 * @param liAmbCertCondCd5 The liAmbCertCondCd5 to set.
	 */
	public void setLiAmbCertCondCd5(String liAmbCertCondCd5) {
		this.liAmbCertCondCd5 = liAmbCertCondCd5;
	}
	/**
	 * @return Returns the liAmbCertCondInd.
	 */
	public String getLiAmbCertCondInd() {
		return liAmbCertCondInd;
	}
	/**
	 * @param liAmbCertCondInd The liAmbCertCondInd to set.
	 */
	public void setLiAmbCertCondInd(String liAmbCertCondInd) {
		this.liAmbCertCondInd = liAmbCertCondInd;
	}
	/**
	 * @return Returns the liAmbDropoffAddrLine1.
	 */
	public String getLiAmbDropoffAddrLine1() {
		return liAmbDropoffAddrLine1;
	}
	/**
	 * @param liAmbDropoffAddrLine1 The liAmbDropoffAddrLine1 to set.
	 */
	public void setLiAmbDropoffAddrLine1(String liAmbDropoffAddrLine1) {
		this.liAmbDropoffAddrLine1 = liAmbDropoffAddrLine1;
	}
	/**
	 * @return Returns the liAmbDropoffAddrLine2.
	 */
	public String getLiAmbDropoffAddrLine2() {
		return liAmbDropoffAddrLine2;
	}
	/**
	 * @param liAmbDropoffAddrLine2 The liAmbDropoffAddrLine2 to set.
	 */
	public void setLiAmbDropoffAddrLine2(String liAmbDropoffAddrLine2) {
		this.liAmbDropoffAddrLine2 = liAmbDropoffAddrLine2;
	}
	/**
	 * @return Returns the liAmbDropoffCity.
	 */
	public String getLiAmbDropoffCity() {
		return liAmbDropoffCity;
	}
	/**
	 * @param liAmbDropoffCity The liAmbDropoffCity to set.
	 */
	public void setLiAmbDropoffCity(String liAmbDropoffCity) {
		this.liAmbDropoffCity = liAmbDropoffCity;
	}
	/**
	 * @return Returns the liAmbDropoffCntrySubd.
	 */
	public String getLiAmbDropoffCntrySubd() {
		return liAmbDropoffCntrySubd;
	}
	/**
	 * @param liAmbDropoffCntrySubd The liAmbDropoffCntrySubd to set.
	 */
	public void setLiAmbDropoffCntrySubd(String liAmbDropoffCntrySubd) {
		this.liAmbDropoffCntrySubd = liAmbDropoffCntrySubd;
	}
	/**
	 * @return Returns the liAmbDropoffCountry.
	 */
	public String getLiAmbDropoffCountry() {
		return liAmbDropoffCountry;
	}
	/**
	 * @param liAmbDropoffCountry The liAmbDropoffCountry to set.
	 */
	public void setLiAmbDropoffCountry(String liAmbDropoffCountry) {
		this.liAmbDropoffCountry = liAmbDropoffCountry;
	}
	/**
	 * @return Returns the liAmbDropoffLoc.
	 */
	public String getLiAmbDropoffLoc() {
		return liAmbDropoffLoc;
	}
	/**
	 * @param liAmbDropoffLoc The liAmbDropoffLoc to set.
	 */
	public void setLiAmbDropoffLoc(String liAmbDropoffLoc) {
		this.liAmbDropoffLoc = liAmbDropoffLoc;
	}
	/**
	 * @return Returns the liAmbDropoffState.
	 */
	public String getLiAmbDropoffState() {
		return liAmbDropoffState;
	}
	/**
	 * @param liAmbDropoffState The liAmbDropoffState to set.
	 */
	public void setLiAmbDropoffState(String liAmbDropoffState) {
		this.liAmbDropoffState = liAmbDropoffState;
	}
	/**
	 * @return Returns the liAmbDropoffZip.
	 */
	public String getLiAmbDropoffZip() {
		return liAmbDropoffZip;
	}
	/**
	 * @param liAmbDropoffZip The liAmbDropoffZip to set.
	 */
	public void setLiAmbDropoffZip(String liAmbDropoffZip) {
		this.liAmbDropoffZip = liAmbDropoffZip;
	}
	/**
	 * @return Returns the liAmbPickupAddrLine1.
	 */
	public String getLiAmbPickupAddrLine1() {
		return liAmbPickupAddrLine1;
	}
	/**
	 * @param liAmbPickupAddrLine1 The liAmbPickupAddrLine1 to set.
	 */
	public void setLiAmbPickupAddrLine1(String liAmbPickupAddrLine1) {
		this.liAmbPickupAddrLine1 = liAmbPickupAddrLine1;
	}
	/**
	 * @return Returns the liAmbPickupAddrLine2.
	 */
	public String getLiAmbPickupAddrLine2() {
		return liAmbPickupAddrLine2;
	}
	/**
	 * @param liAmbPickupAddrLine2 The liAmbPickupAddrLine2 to set.
	 */
	public void setLiAmbPickupAddrLine2(String liAmbPickupAddrLine2) {
		this.liAmbPickupAddrLine2 = liAmbPickupAddrLine2;
	}
	/**
	 * @return Returns the liAmbPickupCity.
	 */
	public String getLiAmbPickupCity() {
		return liAmbPickupCity;
	}
	/**
	 * @param liAmbPickupCity The liAmbPickupCity to set.
	 */
	public void setLiAmbPickupCity(String liAmbPickupCity) {
		this.liAmbPickupCity = liAmbPickupCity;
	}
	/**
	 * @return Returns the liAmbPickupCntrySubd.
	 */
	public String getLiAmbPickupCntrySubd() {
		return liAmbPickupCntrySubd;
	}
	/**
	 * @param liAmbPickupCntrySubd The liAmbPickupCntrySubd to set.
	 */
	public void setLiAmbPickupCntrySubd(String liAmbPickupCntrySubd) {
		this.liAmbPickupCntrySubd = liAmbPickupCntrySubd;
	}
	/**
	 * @return Returns the liAmbPickupCountry.
	 */
	public String getLiAmbPickupCountry() {
		return liAmbPickupCountry;
	}
	/**
	 * @param liAmbPickupCountry The liAmbPickupCountry to set.
	 */
	public void setLiAmbPickupCountry(String liAmbPickupCountry) {
		this.liAmbPickupCountry = liAmbPickupCountry;
	}
	/**
	 * @return Returns the liAmbPickupState.
	 */
	public String getLiAmbPickupState() {
		return liAmbPickupState;
	}
	/**
	 * @param liAmbPickupState The liAmbPickupState to set.
	 */
	public void setLiAmbPickupState(String liAmbPickupState) {
		this.liAmbPickupState = liAmbPickupState;
	}
	/**
	 * @return Returns the liAmbPickupZip.
	 */
	public String getLiAmbPickupZip() {
		return liAmbPickupZip;
	}
	/**
	 * @param liAmbPickupZip The liAmbPickupZip to set.
	 */
	public void setLiAmbPickupZip(String liAmbPickupZip) {
		this.liAmbPickupZip = liAmbPickupZip;
	}
	/**
	 * @return Returns the liContractTypeCd.
	 */
	public String getLiContractTypeCd() {
		return liContractTypeCd;
	}
	/**
	 * @param liContractTypeCd The liContractTypeCd to set.
	 */
	public void setLiContractTypeCd(String liContractTypeCd) {
		this.liContractTypeCd = liContractTypeCd;
	}
	/**
	 * @return Returns the liContractVersionId.
	 */
	public String getLiContractVersionId() {
		return liContractVersionId;
	}
	/**
	 * @param liContractVersionId The liContractVersionId to set.
	 */
	public void setLiContractVersionId(String liContractVersionId) {
		this.liContractVersionId = liContractVersionId;
	}
	/**
	 * @return Returns the liCopayStatusCd.
	 */
	public String getLiCopayStatusCd() {
		return liCopayStatusCd;
	}
	/**
	 * @param liCopayStatusCd The liCopayStatusCd to set.
	 */
	public void setLiCopayStatusCd(String liCopayStatusCd) {
		this.liCopayStatusCd = liCopayStatusCd;
	}
	/**
	 * @return Returns the liDiagcdPtr1.
	 */
	public String getLiDiagcdPtr1() {
		return liDiagcdPtr1;
	}
	/**
	 * @param liDiagcdPtr1 The liDiagcdPtr1 to set.
	 */
	public void setLiDiagcdPtr1(String liDiagcdPtr1) {
		this.liDiagcdPtr1 = liDiagcdPtr1;
	}
	/**
	 * @return Returns the liDiagcdPtr2.
	 */
	public String getLiDiagcdPtr2() {
		return liDiagcdPtr2;
	}
	/**
	 * @param liDiagcdPtr2 The liDiagcdPtr2 to set.
	 */
	public void setLiDiagcdPtr2(String liDiagcdPtr2) {
		this.liDiagcdPtr2 = liDiagcdPtr2;
	}
	/**
	 * @return Returns the liDiagcdPtr3.
	 */
	public String getLiDiagcdPtr3() {
		return liDiagcdPtr3;
	}
	/**
	 * @param liDiagcdPtr3 The liDiagcdPtr3 to set.
	 */
	public void setLiDiagcdPtr3(String liDiagcdPtr3) {
		this.liDiagcdPtr3 = liDiagcdPtr3;
	}
	/**
	 * @return Returns the liDiagcdPtr4.
	 */
	public String getLiDiagcdPtr4() {
		return liDiagcdPtr4;
	}
	/**
	 * @param liDiagcdPtr4 The liDiagcdPtr4 to set.
	 */
	public void setLiDiagcdPtr4(String liDiagcdPtr4) {
		this.liDiagcdPtr4 = liDiagcdPtr4;
	}
	/**
	 * @return Returns the liDmeProcCd.
	 */
	public String getLiDmeProcCd() {
		return liDmeProcCd;
	}
	/**
	 * @param liDmeProcCd The liDmeProcCd to set.
	 */
	public void setLiDmeProcCd(String liDmeProcCd) {
		this.liDmeProcCd = liDmeProcCd;
	}
	/**
	 * @return Returns the liEmergencyInd.
	 */
	public String getLiEmergencyInd() {
		return liEmergencyInd;
	}
	/**
	 * @param liEmergencyInd The liEmergencyInd to set.
	 */
	public void setLiEmergencyInd(String liEmergencyInd) {
		this.liEmergencyInd = liEmergencyInd;
	}
	/**
	 * @return Returns the liEpsdtInd.
	 */
	public String getLiEpsdtInd() {
		return liEpsdtInd;
	}
	/**
	 * @param liEpsdtInd The liEpsdtInd to set.
	 */
	public void setLiEpsdtInd(String liEpsdtInd) {
		this.liEpsdtInd = liEpsdtInd;
	}
	/**
	 * @return Returns the liFamilyPlaningInd.
	 */
	public String getLiFamilyPlaningInd() {
		return liFamilyPlaningInd;
	}
	/**
	 * @param liFamilyPlaningInd The liFamilyPlaningInd to set.
	 */
	public void setLiFamilyPlaningInd(String liFamilyPlaningInd) {
		this.liFamilyPlaningInd = liFamilyPlaningInd;
	}
	/**
	 * @return Returns the liLenOfMedNecessity.
	 */
	public String getLiLenOfMedNecessity() {
		return liLenOfMedNecessity;
	}
	/**
	 * @param liLenOfMedNecessity The liLenOfMedNecessity to set.
	 */
	public void setLiLenOfMedNecessity(String liLenOfMedNecessity) {
		this.liLenOfMedNecessity = liLenOfMedNecessity;
	}
	/**
	 * @return Returns the liMammogramCertNbr.
	 */
	public String getLiMammogramCertNbr() {
		return liMammogramCertNbr;
	}
	/**
	 * @param liMammogramCertNbr The liMammogramCertNbr to set.
	 */
	public void setLiMammogramCertNbr(String liMammogramCertNbr) {
		this.liMammogramCertNbr = liMammogramCertNbr;
	}
	/**
	 * @return Returns the lineItemControlNbr.
	 */
	public String getLineItemControlNbr() {
		return lineItemControlNbr;
	}
	/**
	 * @param lineItemControlNbr The lineItemControlNbr to set.
	 */
	public void setLineItemControlNbr(String lineItemControlNbr) {
		this.lineItemControlNbr = lineItemControlNbr;
	}
	/**
	 * @return Returns the linkSeqNbr.
	 */
	public String getLinkSeqNbr() {
		return linkSeqNbr;
	}
	/**
	 * @param linkSeqNbr The linkSeqNbr to set.
	 */
	public void setLinkSeqNbr(String linkSeqNbr) {
		this.linkSeqNbr = linkSeqNbr;
	}
	/**
	 * @return Returns the liNoteCd.
	 */
	public String getLiNoteCd() {
		return liNoteCd;
	}
	/**
	 * @param liNoteCd The liNoteCd to set.
	 */
	public void setLiNoteCd(String liNoteCd) {
		this.liNoteCd = liNoteCd;
	}
	/**
	 * @return Returns the liNoteText.
	 */
	public String getLiNoteText() {
		return liNoteText;
	}
	/**
	 * @param liNoteText The liNoteText to set.
	 */
	public void setLiNoteText(String liNoteText) {
		this.liNoteText = liNoteText;
	}
	/**
	 * @return Returns the liPlaceOfServiceCd.
	 */
	public String getLiPlaceOfServiceCd() {
		return liPlaceOfServiceCd;
	}
	/**
	 * @param liPlaceOfServiceCd The liPlaceOfServiceCd to set.
	 */
	public void setLiPlaceOfServiceCd(String liPlaceOfServiceCd) {
		this.liPlaceOfServiceCd = liPlaceOfServiceCd;
	}
	/**
	 * @return Returns the liRentalUnitPrcInd.
	 */
	public String getLiRentalUnitPrcInd() {
		return liRentalUnitPrcInd;
	}
	/**
	 * @param liRentalUnitPrcInd The liRentalUnitPrcInd to set.
	 */
	public void setLiRentalUnitPrcInd(String liRentalUnitPrcInd) {
		this.liRentalUnitPrcInd = liRentalUnitPrcInd;
	}
	/**
	 * @return Returns the obstetricAddlUnits.
	 */
	public int getObstetricAddlUnits() {
		return obstetricAddlUnits;
	}
	/**
	 * @param obstetricAddlUnits The obstetricAddlUnits to set.
	 */
	public void setObstetricAddlUnits(int obstetricAddlUnits) {
		this.obstetricAddlUnits = obstetricAddlUnits;
	}
	/**
	 * @return Returns the orderPrvContactName.
	 */
	public String getOrderPrvContactName() {
		return orderPrvContactName;
	}
	/**
	 * @param orderPrvContactName The orderPrvContactName to set.
	 */
	public void setOrderPrvContactName(String orderPrvContactName) {
		this.orderPrvContactName = orderPrvContactName;
	}
	/**
	 * @return Returns the orderPrvEmail.
	 */
	public String getOrderPrvEmail() {
		return orderPrvEmail;
	}
	/**
	 * @param orderPrvEmail The orderPrvEmail to set.
	 */
	public void setOrderPrvEmail(String orderPrvEmail) {
		this.orderPrvEmail = orderPrvEmail;
	}
	/**
	 * @return Returns the orderPrvFax.
	 */
	public String getOrderPrvFax() {
		return orderPrvFax;
	}
	/**
	 * @param orderPrvFax The orderPrvFax to set.
	 */
	public void setOrderPrvFax(String orderPrvFax) {
		this.orderPrvFax = orderPrvFax;
	}
	/**
	 * @return Returns the orderPrvPhone.
	 */
	public String getOrderPrvPhone() {
		return orderPrvPhone;
	}
	/**
	 * @param orderPrvPhone The orderPrvPhone to set.
	 */
	public void setOrderPrvPhone(String orderPrvPhone) {
		this.orderPrvPhone = orderPrvPhone;
	}
	/**
	 * @return Returns the orderPrvPhoneExt.
	 */
	public String getOrderPrvPhoneExt() {
		return orderPrvPhoneExt;
	}
	/**
	 * @param orderPrvPhoneExt The orderPrvPhoneExt to set.
	 */
	public void setOrderPrvPhoneExt(String orderPrvPhoneExt) {
		this.orderPrvPhoneExt = orderPrvPhoneExt;
	}
	/**
	 * @return Returns the referringCliaNbr.
	 */
	public String getReferringCliaNbr() {
		return referringCliaNbr;
	}
	/**
	 * @param referringCliaNbr The referringCliaNbr to set.
	 */
	public void setReferringCliaNbr(String referringCliaNbr) {
		this.referringCliaNbr = referringCliaNbr;
	}
	/**
	 * @return Returns the reprcdAprvAmbpatgrpcd.
	 */
	public String getReprcdAprvAmbpatgrpcd() {
		return reprcdAprvAmbpatgrpcd;
	}
	/**
	 * @param reprcdAprvAmbpatgrpcd The reprcdAprvAmbpatgrpcd to set.
	 */
	public void setReprcdAprvAmbpatgrpcd(String reprcdAprvAmbpatgrpcd) {
		this.reprcdAprvAmbpatgrpcd = reprcdAprvAmbpatgrpcd;
	}
	/**
	 * @return Returns the reprcdAprvHcpcsCd.
	 */
	public String getReprcdAprvHcpcsCd() {
		return reprcdAprvHcpcsCd;
	}
	/**
	 * @param reprcdAprvHcpcsCd The reprcdAprvHcpcsCd to set.
	 */
	public void setReprcdAprvHcpcsCd(String reprcdAprvHcpcsCd) {
		this.reprcdAprvHcpcsCd = reprcdAprvHcpcsCd;
	}
	/**
	 * @return Returns the tpoLineNote.
	 */
	public String getTpoLineNote() {
		return tpoLineNote;
	}
	/**
	 * @param tpoLineNote The tpoLineNote to set.
	 */
	public void setTpoLineNote(String tpoLineNote) {
		this.tpoLineNote = tpoLineNote;
	}
	
	/**
	 * @return Returns the liProvAddrLine1.
	 */
	public String getLiProvAddrLine1() {
		return liProvAddrLine1;
	}
	/**
	 * @param liProvAddrLine1 The liProvAddrLine1 to set.
	 */
	public void setLiProvAddrLine1(String liProvAddrLine1) {
		this.liProvAddrLine1 = liProvAddrLine1;
	}
	/**
	 * @return Returns the liProvAddrLine2.
	 */
	public String getLiProvAddrLine2() {
		return liProvAddrLine2;
	}
	/**
	 * @param liProvAddrLine2 The liProvAddrLine2 to set.
	 */
	public void setLiProvAddrLine2(String liProvAddrLine2) {
		this.liProvAddrLine2 = liProvAddrLine2;
	}
	/**
	 * @return Returns the liProvCity.
	 */
	public String getLiProvCity() {
		return liProvCity;
	}
	/**
	 * @param liProvCity The liProvCity to set.
	 */
	public void setLiProvCity(String liProvCity) {
		this.liProvCity = liProvCity;
	}
	/**
	 * @return Returns the liProvCntrySubd.
	 */
	public String getLiProvCntrySubd() {
		return liProvCntrySubd;
	}
	/**
	 * @param liProvCntrySubd The liProvCntrySubd to set.
	 */
	public void setLiProvCntrySubd(String liProvCntrySubd) {
		this.liProvCntrySubd = liProvCntrySubd;
	}
	/**
	 * @return Returns the liProvCountry.
	 */
	public String getLiProvCountry() {
		return liProvCountry;
	}
	/**
	 * @param liProvCountry The liProvCountry to set.
	 */
	public void setLiProvCountry(String liProvCountry) {
		this.liProvCountry = liProvCountry;
	}
	/**
	 * @return Returns the liProvState.
	 */
	public String getLiProvState() {
		return liProvState;
	}
	/**
	 * @param liProvState The liProvState to set.
	 */
	public void setLiProvState(String liProvState) {
		this.liProvState = liProvState;
	}
	/**
	 * @return Returns the liProvTaxonomyCd.
	 */
	public String getLiProvTaxonomyCd() {
		return liProvTaxonomyCd;
	}
	/**
	 * @param liProvTaxonomyCd The liProvTaxonomyCd to set.
	 */
	public void setLiProvTaxonomyCd(String liProvTaxonomyCd) {
		this.liProvTaxonomyCd = liProvTaxonomyCd;
	}
	/**
	 * @return Returns the liProvZip.
	 */
	public String getLiProvZip() {
		return liProvZip;
	}
	/**
	 * @param liProvZip The liProvZip to set.
	 */
	public void setLiProvZip(String liProvZip) {
		this.liProvZip = liProvZip;
	}
	
	/**
	 * @return Returns the othPayrPrimaryId.
	 */
	public String getOthPayrPrimaryId() {
		return othPayrPrimaryId;
	}
	/**
	 * @param othPayrPrimaryId The othPayrPrimaryId to set.
	 */
	public void setOthPayrPrimaryId(String othPayrPrimaryId) {
		this.othPayrPrimaryId = othPayrPrimaryId;
	}
	/*To add revision number in
	 *  claim number IFOX 367728*/
	/**
	 * @return Returns the wtxClaimRefUniqNbr.
	 */
	public String getWtxClaimRefUniqNbr() {
		
	
		return wtxClaimRefUniqNbr;
	}
	/**
	 * @param wtxClaimRefUniuqNbr The wtxClaimRefUniuqNbr to set.
	 */
	public void setWtxClaimRefUniqNbr(String wtxClaimRefUniqNbr) {
		
		/*To add revision number in	 *  claim number IFOX 367728*/
		if (!( "".equals(wtxClaimRefUniqNbr)) && !(wtxClaimRefUniqNbr == null)){
			setSearchDetailClaimRefNbr( wtxClaimRefUniqNbr.substring(0,3)+ "00"+ wtxClaimRefUniqNbr.substring(5));
	
		}/*To add revision number in	 *  claim number IFOX 367728*/
		this.wtxClaimRefUniqNbr = wtxClaimRefUniqNbr;
	}
	/*To add revision number in
	 *  claim number IFOX 367728*/
	boolean isStatusEligibleForUpdate(){
		String[] statusList={"REJ","COR","LV5","CCR","IGN"};
		return Arrays.asList(statusList).contains(processStatus);
		
	}
	//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - Start
	public String getSearchPayerSecId() {
		return searchPayerSecId;
	}
	public void setSearchPayerSecId(String searchPayerSecId) {
		this.searchPayerSecId = searchPayerSecId;
	}
	public String getSearchSubsGrpOrPolNbr() {
		return searchSubsGrpOrPolNbr;
	}
	public void setSearchSubsGrpOrPolNbr(String searchSubsGrpOrPolNbr) {
		this.searchSubsGrpOrPolNbr = searchSubsGrpOrPolNbr;
	}
	//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - End
	
}
