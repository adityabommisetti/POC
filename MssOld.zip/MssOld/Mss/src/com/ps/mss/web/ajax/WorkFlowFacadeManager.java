package com.ps.mss.web.ajax;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EEMWorkFlowService;
import com.ps.mss.db.DbConnWeb;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.RapsConstants;
import com.ps.mss.manager.ContextManager;
import com.ps.mss.manager.EEMManager;
import com.ps.mss.manager.RapsManager;
import com.ps.mss.model.EEMContext;
import com.ps.mss.model.EEMWorkFLowVO;
import com.ps.mss.model.Pagination;
import com.ps.mss.model.RapsContext;
import com.ps.mss.model.RapsDetailItem;
import com.ps.mss.model.RapsDetailPage;
import com.ps.mss.model.RapsFilter;
import com.ps.mss.web.helper.AjaxHelper;
import com.ps.mss.web.helper.SessionHelper;

public class WorkFlowFacadeManager {
	static ModuleLog log = new ModuleLog("WorkFlowFacadeManager");
	private static Logger logger=LoggerFactory.getLogger(WorkFlowFacadeManager.class);
	/**
	 * This method will retrieve queue lst of a user based upon search by supervisor.
	 * @param txn holds transaction type (add/update/delete)
	 * @param prty holds priority method (Critical/High/Medium/Low)
	 * @param selUserId holds user Id for which queue data to be modified.
	 * @return List of queues with queue_CD and Queue_name. 
	 */
	@SuppressWarnings("rawtypes")
	public List getSupWFUsrQueChangesLst(String transaction, String priority, String prtyMtd,
			String selUserId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
    	Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;  
    	List queuesLst = new ArrayList();
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	AjaxHelper.validateUser(sessionHelper,conn);
    	   	
			// now get the connection to the EEM DB
    	    String custId = sessionHelper.getMfId();
			String dbId = sessionHelper.getEEMDatabaseName();
			conn = DbConnWeb.reGetConnection(conn,dbId);
			//RapsContext rc = (RapsContext) ContextManager.getContext(sessionHelper.getSession(), RapsConstants.RAPS_CONTEXT);
			queuesLst = new EEMWorkFlowService().getSupWFUsrQueChangesLst(conn, transaction, priority,
					prtyMtd, selUserId, custId);
			
			
			anyError = false;
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
    		logger.debug(errMessage);
//    		log.println(errMessage);
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return queuesLst; 

    }//getSupWFUsrQueChangesLst()
	
	/**
	 * This method will update queue data of a user by the supervisor.
	 * @param txn holds transaction type (add/update/delete)
	 * @param prty holds priority method (Critical/High/Medium/Low)
	 * @param queue holds queue code
	 * @param selUserId holds user Id for which queue data to be modified.
	 * @param supUserId holds supervisor user Id.
	 * @return boolean whether transaction success/failure.
	 */
	public boolean supWorkFlowUserQueUpdate(String transaction, String priority, String queue, 
			String selUserId, String supUserId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
    	Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;
    	boolean success = false; 
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	AjaxHelper.validateUser(sessionHelper,conn);
    	   	
			// now get the connection to the EEM DB
    	    String custId = sessionHelper.getMfId();
			String dbId = sessionHelper.getEEMDatabaseName();
			conn = DbConnWeb.reGetConnection(conn,dbId);
			success = new EEMWorkFlowService().supWorkFlowUserQueUpdate(conn, transaction, priority,
					queue, selUserId, supUserId, custId);
			
			
			anyError = false;
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
    		logger.debug(errMessage);
//    		log.println(errMessage);
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return success; 

    }//detailPage.
	
	/**
	 * This method will retrieve queue lst of a user based upon search by supervisor.
	 * @param selUserId holds user Id for which queue data to be modified.
	 * @return List of queues with queue_CD and Queue_name. 
	 */
	@SuppressWarnings("rawtypes")
	public List getUserQNames(String selUserId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;  
    	List queuesLst = new ArrayList();
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	AjaxHelper.validateUser(sessionHelper,conn);
    	   	
			// now get the connection to the EEM DB
    	    String custId = sessionHelper.getMfId();
			String dbId = sessionHelper.getEEMDatabaseName();
			conn = DbConnWeb.reGetConnection(conn,dbId);
			queuesLst = new EEMWorkFlowService().getUserQueueListDwr(conn, custId, selUserId);
			
			anyError = false;
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
    		logger.debug(errMessage);
//    		log.println(errMessage);
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return queuesLst; 

    }//getUserQNames()
	
	@SuppressWarnings("rawtypes")
	public List getAdminHistSuprvLst(String adminId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;  
    	List suprvLst = new ArrayList();
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	AjaxHelper.validateUser(sessionHelper,conn);
    	   	EEMContext context = EEMManager.getContext(sessionHelper.getSession());
    	   	EEMWorkFLowVO workFlowVO = context.getWorkFlowVO();
    	   	
			// now get the connection to the EEM DB
    	    String custId = sessionHelper.getMfId();
			String dbId = sessionHelper.getEEMDatabaseName();
			conn = DbConnWeb.reGetConnection(conn,dbId);
			suprvLst = new EEMWorkFlowService().adminHistLoadSuprvsDwr(conn, custId, adminId);
			workFlowVO.setAdminHistSuprvs(suprvLst);
			
			anyError = false;
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
    		logger.debug(errMessage);
//    		log.println(errMessage);
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return suprvLst; 

    }//adminHistLoadSuprvs()
	
	@SuppressWarnings("rawtypes")
	public List getAdminHistUserLst(String suprvId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;  
    	List userLst = new ArrayList();
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	AjaxHelper.validateUser(sessionHelper,conn);
    	   	EEMContext context = EEMManager.getContext(sessionHelper.getSession());
    	   	EEMWorkFLowVO workFlowVO = context.getWorkFlowVO();
    	   	
			// now get the connection to the EEM DB
    	    String custId = sessionHelper.getMfId();
			String dbId = sessionHelper.getEEMDatabaseName();
			conn = DbConnWeb.reGetConnection(conn,dbId);
			userLst = new EEMWorkFlowService().adminHistLoadUsersDwr(conn, custId, suprvId);
			workFlowVO.setAdminHistUsrs(userLst);
			
			anyError = false;
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
    		logger.debug(errMessage);
//    		log.println(errMessage);
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return userLst; 

    }//adminHistLoadUsers()

}//class
