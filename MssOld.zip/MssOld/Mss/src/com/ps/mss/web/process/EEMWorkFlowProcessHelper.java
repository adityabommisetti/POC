package com.ps.mss.web.process;

import com.ps.mss.web.actions.EEMAction;

public class EEMWorkFlowProcessHelper extends EEMAction{

}
