package com.ps.mss.web.forms;

import java.util.List;

import com.ps.mss.dao.model.HPEFTDailyFileProcessingDO;
import com.ps.mss.dao.model.HPEFTEDPSFileDshbMngtDO;
import com.ps.mss.dao.model.HPEFTFailedFileListDO;
import com.ps.mss.dao.model.HPEFTMonEncDetailsDO;


/**
 * @author DParker
 */
public class HPEFileTrackingForm extends HPEEncounterForm {
	
	
	/* File Track Code - Start*/
	
	// File Track search criteria
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String searchFromDate = "";
	private String searchToDate = "";
	private String searchSubmitterId = "";
	private String selectedDateYrmo = "";
	private String sourceId = "";
	private String fileName = "";	
	private String searchBy = "";
	private String searchText = "";
	private String searchFile = "";
	
	private String lineOfbusiness = "";	
	private String typeOfBusiness = "";
	
	private String searchEncType = "I";
	private String searchClaimType ;
	private String searchClmRefNbr = "";
	private String wtxClaimRefUniqNbr ="";//healthspring Unique id IFOX 367728*
	private List<HPEFTEDPSFileDshbMngtDO> sec1uiLst = null;
	
	private String fileDsbMgmtHL="";
	private String moEncDetHL="";
	private String dailyDetHL="";
	private String remarks="";
	private String remarksFileId="";
		
	// For storing values into Session - File Tracking- start
	private String formSearch="TRUE";
	private String fileNameSeachSession;
	// For storing values into Session - File Tracking- end
	private String refreshTab;
	private String fileTrackExportTab="False";
	
	//Monthly Encounters Details search
	
		private String year="";
		private String month="";
		private String status = "";
		private String methodName = "";
		private int dateYRMO;
		private String intrchg_recvr_id="";
		private String cust_source_id="";
		public String splitFileStatus = "";
		
		private List<HPEFTMonEncDetailsDO> monEncDetailsLst = null;
		
	//Daily File Processing search
		private String encType="";
		private String submissionDate="";
		private String orig_intrchg_ctrl_nbr="";
		private String custFileId="";//IFOX-00416789 - Add customer ICN in File management
		
		private List<HPEFTDailyFileProcessingDO> dailyFileProcessingLst = null;
		private List<HPEFTDailyFileProcessingDO> dailyAcceptedFileProcessingLst = null;

	// Failed File List Search	
		private List<HPEFTFailedFileListDO> FailedFileLst = null;
		
		
	//Search Detail 
		
		
		
		
		public String getSearchEncType() {
			return searchEncType;
		}
		public String getFileTrackExportTab() {
			return fileTrackExportTab;
		}
		public void setFileTrackExportTab(String fileTrackExportTab) {
			this.fileTrackExportTab = fileTrackExportTab;
		}
		public String getRefreshTab() {
			return refreshTab;
		}
		public void setRefreshTab(String refreshTab) {
			this.refreshTab = refreshTab;
		}
		public void setSearchEncType(String searchEncType) {
			this.searchEncType = searchEncType;
		}
		public String getSearchClaimType() {
			return searchClaimType;
		}
		public void setSearchClaimType(String searchClaimType) {
			this.searchClaimType = searchClaimType;
		}
		public String getSearchClmRefNbr() {
			return searchClmRefNbr;
		}
		public void setSearchClmRefNbr(String searchClmRefNbr) {
			this.searchClmRefNbr = searchClmRefNbr;
		}
		/*To add revision number in
		 *  claim number IFOX 367728*/
		/**
		 * @return Returns the wtxClaimRefUniqNbr.
		 */
		public String getWtxClaimRefUniqNbr() {
			
		
			return wtxClaimRefUniqNbr;
		}
		/**
		 * @param wtxClaimRefUniuqNbr The wtxClaimRefUniuqNbr to set.
		 */
		public void setWtxClaimRefUniqNbr(String wtxClaimRefUniqNbr) {
			
			/*To add revision number in	 *  claim number IFOX 367728*/
			if (!( "".equals(wtxClaimRefUniqNbr)) && !(wtxClaimRefUniqNbr == null)){
				setSearchDetailClaimRefNbr( wtxClaimRefUniqNbr.substring(0,3)+ "00"+ wtxClaimRefUniqNbr.substring(5));
		
			}/*To add revision number in	 *  claim number IFOX 367728*/
			this.wtxClaimRefUniqNbr = wtxClaimRefUniqNbr;
		}
		/*To add revision number in
		 *  claim number IFOX 367728*/


	//others
	public String getRemarksFileId() {
			return remarksFileId;
		}
		public void setRemarksFileId(String remarksFileId) {
			this.remarksFileId = remarksFileId;
		}
	public String getRemarks() {
			return remarks;
		}
		public void setRemarks(String remarks) {
			this.remarks = remarks;
		}
	/**
	 * @return the searchFromDate
	 */
	public String getSearchFromDate() {
		return searchFromDate;
	}
	public List<HPEFTDailyFileProcessingDO> getDailyAcceptedFileProcessingLst() {
		return dailyAcceptedFileProcessingLst;
	}
	public void setDailyAcceptedFileProcessingLst(List<HPEFTDailyFileProcessingDO> dailyAcceptedFileProcessingLst) {
		this.dailyAcceptedFileProcessingLst = dailyAcceptedFileProcessingLst;
	}
	/**
	 * @param searchFromDate the searchFromDate to set
	 */
	public void setSearchFromDate(String searchFromDate) {
		this.searchFromDate = searchFromDate;
	}
	/**
	 * @return the searchToDate
	 */
	public String getSearchToDate() {
		return searchToDate;
	}
	/**
	 * @param searchToDate the searchToDate to set
	 */
	public void setSearchToDate(String searchToDate) {
		this.searchToDate = searchToDate;
	}
	/**
	 * @return the searchSubmitterId
	 */
	public String getSearchSubmitterId() {
		return searchSubmitterId;
	}
	/**
	 * @param searchSubmitterId the searchSubmitterId to set
	 */
	public void setSearchSubmitterId(String searchSubmitterId) {
		this.searchSubmitterId = searchSubmitterId;
	}
	/**
	 * @return the selectedDateYrmo
	 */
	public String getSelectedDateYrmo() {
		return selectedDateYrmo;
	}
	/**
	 * @param selectedDateYrmo the selectedDateYrmo to set
	 */
	public void setSelectedDateYrmo(String selectedDateYrmo) {
		this.selectedDateYrmo = selectedDateYrmo;
	}
	/**
	 * @return the sourceId
	 */
	public String getSourceId() {
		return sourceId;
	}
	/**
	 * @param sourceId the sourceId to set
	 */
	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}
	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	
	public String getSearchBy() {
		return searchBy;
	}
	public void setSearchBy(String searchBy) {
		this.searchBy = searchBy;
	}
	public String getSearchText() {
		return searchText;
	}
	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}
	
	/**
	 * @return the lineOfbusiness
	 */
	public String getLineOfbusiness() {
		return lineOfbusiness;
	}
	/**
	 * @param lineOfbusiness the lineOfbusiness to set
	 */
	public void setLineOfbusiness(String lineOfbusiness) {
		this.lineOfbusiness = lineOfbusiness;
	}
	/**
	 * @return the typeOfBusiness
	 */
	public String getTypeOfBusiness() {
		return typeOfBusiness;
	}
	/**
	 * @param typeOfBusiness the typeOfBusiness to set
	 */
	public void setTypeOfBusiness(String typeOfBusiness) {
		this.typeOfBusiness = typeOfBusiness;
	}
	/**
	 * @return the sec1uiLst
	 */
	public List<HPEFTEDPSFileDshbMngtDO> getSec1uiLst() {
		return sec1uiLst;
	}
	/**
	 * @param sec1uiLst the sec1uiLst to set
	 */
	public void setSec1uiLst(List sec1uiLst) {
		this.sec1uiLst = sec1uiLst;
	}
	/**
	 * @return the monEncDetailsLst
	 */
	public List<HPEFTMonEncDetailsDO> getMonEncDetailsLst() {
		return monEncDetailsLst;
	}
	/**
	 * @param monEncDetailsLst the monEncDetailsLst to set
	 */
	public void setMonEncDetailsLst(List<HPEFTMonEncDetailsDO> monEncDetailsLst) {
		this.monEncDetailsLst = monEncDetailsLst;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the methodName
	 */
	public String getMethodName() {
		return methodName;
	}
	/**
	 * @param methodName the methodName to set
	 */
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}
	/**
	 * @return the dateYRMO
	 */
	public int getDateYRMO() {
		return dateYRMO;
	}
	/**
	 * @param dateYRMO the dateYRMO to set
	 */
	public void setDateYRMO(int dateYRMO) {
		this.dateYRMO = dateYRMO;
	}
	/**
	 * @return the intrchg_recvr_id
	 */
	public String getIntrchg_recvr_id() {
		return intrchg_recvr_id;
	}
	/**
	 * @param intrchg_recvr_id the intrchg_recvr_id to set
	 */
	public void setIntrchg_recvr_id(String intrchg_recvr_id) {
		this.intrchg_recvr_id = intrchg_recvr_id;
	}
	/**
	 * @return the cust_source_id
	 */
	public String getCust_source_id() {
		return cust_source_id;
	}
	/**
	 * @param cust_source_id the cust_source_id to set
	 */
	public void setCust_source_id(String cust_source_id) {
		this.cust_source_id = cust_source_id;
	}
	/**
	 * @return the splitFileStatus
	 */
	public String getSplitFileStatus() {
		return splitFileStatus;
	}
	/**
	 * @param splitFileStatus the splitFileStatus to set
	 */
	public void setSplitFileStatus(String splitFileStatus) {
		this.splitFileStatus = splitFileStatus;
	}
	/**
	 * @return the year
	 */
	public String getYear() {
		return year;
	}
	/**
	 * @param year the year to set
	 */
	public void setYear(String year) {
		this.year = year;
	}
	/**
	 * @return the month
	 */
	public String getMonth() {
		return month;
	}
	/**
	 * @param month the month to set
	 */
	public void setMonth(String month) {
		this.month = month;
	}
	/**
	 * @return the submissionDate
	 */
	public String getSubmissionDate() {
		return submissionDate;
	}
	/**
	 * @param submissionDate the submissionDate to set
	 */
	public void setSubmissionDate(String submissionDate) {
		this.submissionDate = submissionDate;
	}
	/**
	 * @return the orig_intrchg_ctrl_nbr
	 */
	public String getOrig_intrchg_ctrl_nbr() {
		return orig_intrchg_ctrl_nbr;
	}
	/**
	 * @param orig_intrchg_ctrl_nbr the orig_intrchg_ctrl_nbr to set
	 */
	public void setOrig_intrchg_ctrl_nbr(String orig_intrchg_ctrl_nbr) {
		this.orig_intrchg_ctrl_nbr = orig_intrchg_ctrl_nbr;
	}

	//IFOX-00416789 - Add customer ICN in File management Starts
	public String getCustFileId() {
		return custFileId;
	}
	public void setCustFileId(String custFileId) {
		this.custFileId = custFileId;
	}
	//IFOX-00416789 - Add customer ICN in File management Ends
		
	/**
	 * @return the dailyFileProcessingLst
	 */
	public List<HPEFTDailyFileProcessingDO> getDailyFileProcessingLst() {
		return dailyFileProcessingLst;
	}
	/**
	 * @param dailyFileProcessingLst the dailyFileProcessingLst to set
	 */
	public void setDailyFileProcessingLst(List<HPEFTDailyFileProcessingDO> dailyFileProcessingLst) {
		this.dailyFileProcessingLst = dailyFileProcessingLst;
	}
	/**
	 * @return the failedFileLst
	 */
	public List<HPEFTFailedFileListDO> getFailedFileLst() {
		return FailedFileLst;
	}
	/**
	 * @param failedFileLst the failedFileLst to set
	 */
	public void setFailedFileLst(List<HPEFTFailedFileListDO> failedFileLst) {
		FailedFileLst = failedFileLst;
	}
	/**
	 * @return the encType
	 */
	public String getEncType() {
		return encType;
	}
	/**
	 * @param encType the encType to set
	 */
	public void setEncType(String encType) {
		this.encType = encType;
	}
	/**
	 * @return the fileDsbMgmtHL
	 */
	public String getFileDsbMgmtHL() {
		return fileDsbMgmtHL;
	}
	/**
	 * @param fileDsbMgmtHL the fileDsbMgmtHL to set
	 */
	public void setFileDsbMgmtHL(String fileDsbMgmtHL) {
		this.fileDsbMgmtHL = fileDsbMgmtHL;
	}
	/**
	 * @return the moEncDetHL
	 */
	public String getMoEncDetHL() {
		return moEncDetHL;
	}
	/**
	 * @param moEncDetHL the moEncDetHL to set
	 */
	public void setMoEncDetHL(String moEncDetHL) {
		this.moEncDetHL = moEncDetHL;
	}
	public String getDailyDetHL() {
		return dailyDetHL;
	}
	public void setDailyDetHL(String dailyDetHL) {
		this.dailyDetHL = dailyDetHL;
	}
	public String getFormSearch() {
		return formSearch;
	}
	public void setFormSearch(String formSearch) {
		this.formSearch = formSearch;
	}
	public String getFileNameSeachSession() {
		return fileNameSeachSession;
	}
	public void setFileNameSeachSession(String fileNameSeachSession) {
		this.fileNameSeachSession = fileNameSeachSession;
	}

	/* File Track Code - End*/
	
}
