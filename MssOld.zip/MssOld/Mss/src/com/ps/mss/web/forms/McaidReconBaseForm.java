/*
 * $Id: BaseForm.java,v 1.2 2009/09/10 16:44:02 AIndrapradja Exp $
 */
package com.ps.mss.web.forms;




import org.apache.struts.action.ActionForm;




/**
 * Form bean for a Struts application.
 * @version 	1.0
 * @author prare
 */
public class McaidReconBaseForm extends ActionForm {
	
	
	private static final long serialVersionUID = 1L;
	private String method;
    private String menu; 
    private String subMenu; 
    private String message;
    
    
	/**
	 * @return the method
	 */
	public String getMethod() {
		return method;
	}
	/**
	 * @param method the method to set
	 */
	public void setMethod(String method) {
		this.method = method;
	}
	/**
	 * @return the menu
	 */
	public String getMenu() {
		return menu;
	}
	/**
	 * @param menu the menu to set
	 */
	public void setMenu(String menu) {
		this.menu = menu;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @return the subMenu
	 */
	public String getSubMenu() {
		return subMenu;
	}
	/**
	 * @param subMenu the subMenu to set
	 */
	public void setSubMenu(String subMenu) {
		this.subMenu = subMenu;
	}

}
