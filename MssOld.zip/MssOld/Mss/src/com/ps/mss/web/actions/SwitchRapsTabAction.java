/*
 * $Id: SwitchRapsTabAction.java,v 1.1 2014/06/26 07:56:47 praveen Exp $
 */
package com.ps.mss.web.actions;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.DynaActionForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;
import com.ps.util.NameValuePair;
import com.ps.mss.dao.CodeCacheDao;
import com.ps.mss.model.MenuHistory;
import com.ps.mss.model.RapsContext;
import com.ps.mss.model.RapsClusterForm;
import com.ps.mss.model.RapsDetailInfo;
import com.ps.mss.framework.RapsConstants;
import com.ps.mss.manager.ContextManager;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.web.helper.Utility;
/**
 * @author indrapradja.adriana
 *
 * This action is called whenever a new tab is selected. It will basically save the current 
 * page history for the old tab, together with the "expanded" list items. Then it will forward to the right
 * page.
 */
public class SwitchRapsTabAction extends Action {
	static ModuleLog log = new ModuleLog("SwitchRapsTabAction");
	private static Logger logger=LoggerFactory.getLogger(SwitchRapsTabAction.class);
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		RapsContext rc = (RapsContext) ContextManager.getContext(request, RapsConstants.RAPS_CONTEXT);
		SessionHelper sessionHelper = new SessionHelper(request);
		Utility.copyFromSessionToRequest(rc, request, sessionHelper);
		DynaActionForm genericForm = (DynaActionForm) form;
		Utility.saveExpandedItems(rc, (String)genericForm.get("uiContext"), (String)genericForm.get("pageName"));
		String targetResult = "";
		
		//Save the CURRENTLY displayed pagename. We're leaving this page
		int index = rc.getCurrentTAB();		
		MenuHistory ph = rc.getPageHistory(index);
		String pageBeingDisplayed = (String)genericForm.get("pageName");
		if (RapsConstants.RAPS_CLAIMS_DETAILS_POP.equals(pageBeingDisplayed) ||
			RapsConstants.RAPS_DETAIL_POP.equals(pageBeingDisplayed) ||
			RapsConstants.RAPS_DELETE.equals(pageBeingDisplayed)) {
			/* Since the above screen can only be reached specially, NOT THRU selecting a TAB, they should
			 * never be put in the history.
			 * Therefore set pageBeingDisplayed to the last screen before them.
			 */
			if (index == RapsConstants.CLAIM_TAB)
				pageBeingDisplayed = RapsConstants.RAPS_CLAIMS_DETAILS;
			else
				pageBeingDisplayed = RapsConstants.RAPS_DETAIL;
		}
		
		/*need to check if transition is valid. This is as a result of F5 (resubmit page). e.g.: you're displaying
		 * raps entry, and then customer clicks F5. As a result of this, previous page is resubmitted. So the 
		 * pageName in the request is not correct. It's like you're already displaying raps entry, and you're getting
		 * another request to switch to raps entry, from let's say, raps detail screen.
		 */
		
		boolean validTransition = false;
		switch (index) {
		case RapsConstants.RAPS_TAB1 : //cluster dashbord
			if (RapsConstants.RAPS_DASHBOARD.equals(pageBeingDisplayed) ||
				RapsConstants.RAPS_DETAIL.equals(pageBeingDisplayed) ||
				RapsConstants.RAPS_CLAIMS_DETAILS_POP.equals(pageBeingDisplayed))
				validTransition = true;
			break;
		case RapsConstants.RAPS_TAB2: //claim
			if (RapsConstants.RAPS_CLAIMS_DASHBOARD.equals(pageBeingDisplayed) ||
					RapsConstants.RAPS_CLAIMS_DETAILS.equals(pageBeingDisplayed) ||
					RapsConstants.RAPS_DETAIL_POP.equals(pageBeingDisplayed))
					validTransition = true;
				break;
		case RapsConstants.RAPS_TAB4: //entry
			if (RapsConstants.RAPS_ENTRY.equals(pageBeingDisplayed))
				validTransition = true;
			break;
		case RapsConstants.RAPS_TAB5:
			if (RapsConstants.RAPS_STATISTIC.equals(pageBeingDisplayed))
				validTransition = true;
			break;
		}
		if (validTransition)
			ph.setPageName(pageBeingDisplayed);
			
		String menuName = (String)genericForm.get("menuName"); // the tab that we're switching TO
		if (RapsConstants.RAPS_TAB2_STR.equals(menuName)) {
			targetResult = RapsConstants.RAPS_CLAIMS_DASHBOARD; //this is the default value if there's no history yet
			index = RapsConstants.RAPS_TAB2;
		}
		else if (RapsConstants.RAPS_TAB3_STR.equals(menuName)) { 
			targetResult = RapsConstants.RAPS_WORKFLOW; //this is the default value if there's no history yet
			index = RapsConstants.RAPS_TAB3;
		}
		else if (RapsConstants.RAPS_TAB4_STR.equals(menuName)) { 
			targetResult = RapsConstants.RAPS_ENTRY; //this is the default value if there's no history yet
			index = RapsConstants.RAPS_TAB4;
			RapsClusterForm entry = rc.getRapsEntry();
			NameValuePair[] cache = CodeCacheDao.getInstance().getProviderTypes();
			NameValuePair[] provList = new NameValuePair[cache.length];
			for (int i=0; i< cache.length; i++) {
				provList[i] = new NameValuePair();
				provList[i].setValue(cache[i].getValue());
				provList[i].setName(cache[i].getValue().concat(" - ").concat(cache[i].getName()));
			}
			entry.setProviderList(provList);
			//Always clear all the informations when coming to this page
			rc.setRapsDetailEntry(new RapsDetailInfo()); 
			entry.reset();
			entry.setStatus(RapsConstants.STATUS_INIT);
		}
		else if (RapsConstants.RAPS_TAB5_STR.equals(menuName)) { 
			targetResult = RapsConstants.RAPS_STATISTIC; //this is the default value if there's no history yet
			index = RapsConstants.RAPS_TAB5;
		}
		else {
			targetResult = RapsConstants.RAPS_DASHBOARD; //this is the default value if there's no history yet
			index = RapsConstants.RAPS_TAB1;			
		}
		//Now set the form to the new tab
		rc.setCurrentTAB(index);
		ph = rc.getPageHistory(index); //now it points to the history of the page we're going to jump
		
		if (ph.getPageName() != null) 
			targetResult = ph.getPageName(); //can be RAPS_DASHBOARD, RAPS_DETAIL, RAPS_CLAIMS_DASHBOARD, etc
											 //it should be unique names for all the pages.
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(targetResult);
	}

}
