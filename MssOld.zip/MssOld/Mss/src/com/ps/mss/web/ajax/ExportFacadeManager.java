/*
 * $Id: ExportFacadeManager.java,v 1.1 2014/06/26 07:57:00 praveen Exp $
 */
package com.ps.mss.web.ajax;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.PdeTroopService;
import com.ps.mss.db.DbConnWeb;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.framework.RapsConstants;
import com.ps.mss.manager.ContextManager;
import com.ps.mss.manager.ExportManager;
import com.ps.mss.manager.HPEManager;
import com.ps.mss.manager.RapsManager;
import com.ps.mss.model.FilterVO;
import com.ps.mss.model.HPEContext;
import com.ps.mss.model.PdeContext;
import com.ps.mss.model.ReinsuranceContext;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.helper.AjaxHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.web.helper.Utility;
import com.ps.util.StringUtil;
import com.ps.mss.model.RapsContext;

/**
 * @author deepak
 *
 */
public class ExportFacadeManager {
	private static Logger logger=LoggerFactory.getLogger(ExportFacadeManager.class);

	public String[] createExport(String tableName,  String exportType, String uiContextRange , String menuName ,
			  String searchType,  String pageType, String partName,Map parameterMap, String expandedItems ) throws ApplicationException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		
		//for Discrepancy Detail set 'plan' as menu name to use for PDF and CSV reports 
		if(Constants.DISCREPANCY_DETAIL.equals(tableName) && (!Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(menuName)))
			menuName = "plan";
		
		
		Map detailMap = null;
		Map planmap = sessionHelper.getPlanForParts();
		List pageStatusList = null;
		String cmsValue = null;
		String planValue = null;		
		String seqNbr = null;
		String pymtType = null;		
		String applyDate = null;
		String exportFileName = tableName;
		FilterVO filterVO = null;
		Object appContext = null;
		HPEContext hpeContext = null;
		
		if("export".equals(tableName) ) { 
			exportFileName = "EncounterDetail";
			exportType = "CSV";
			hpeContext = HPEManager.getContext(sessionHelper.getSession());
			logger.debug("Encounter Vo Details: "+ hpeContext.getEncounterVO());
			
			String tempFileName = ExportManager.createExport(tableName, hpeContext, null, exportType, uiContextRange, (String)sessionHelper.getAttribute(SessionManager.HPEDB));
			logger.info(LoggerConstants.methodEndLevel());
			return new String [] {tempFileName ,tableName};			
		}
		
		if ("raps".equals(tableName.substring(0, 4))) {
			//tableName is == pageName. Don't ask me why....
			//call to ExportManager for export to PDF and CSV
			appContext = ContextManager.getContext(sessionHelper.getSession(), RapsConstants.RAPS_CONTEXT);
			Utility.saveExpandedItems((RapsContext) appContext, expandedItems, tableName);			
			String tempFileName = ExportManager.createExport(tableName, appContext, null, exportType, uiContextRange, sessionHelper.getRapsDatabaseName());
			exportFileName = tableName;			
			logger.info(LoggerConstants.methodEndLevel());
			return new String [] {tempFileName ,exportFileName};			
		}

		if (Constants.PARTD_MENU.equals(menuName)) {
			appContext = (ReinsuranceContext)sessionHelper.getAttribute(Constants.SESSION_REINSURANCE_FORM);
			String tempFileName = ExportManager.createExport(tableName, appContext, null, exportType, uiContextRange, sessionHelper.getActiveDataBaseName());
			logger.info(LoggerConstants.methodEndLevel());
			return new String [] {tempFileName ,tableName};			
		}		
		//get filterVO, pageStatus and relative map(if needed) for different pages  
		else if(Constants.POPUP_RECONCILATION.equals(tableName) ) {//Reconciliation POPUP
			exportFileName = "reconciliation";
			if(parameterMap == null){
				logger.info(LoggerConstants.methodEndLevel());
				return null;
			}
			String hicNbr = (String)parameterMap.get("hicNbr");
			String fromDate = (String)parameterMap.get("fromDate");
			String planName = (String)parameterMap.get("planName");
			
			filterVO = new FilterVO();
			filterVO.setPlanName(planName);
			filterVO.setStartDate(fromDate);
			filterVO.setEndDate(fromDate);
			filterVO.setHicNumber(hicNbr);
			filterVO.setPartName(partName);
			filterVO.setSearchType(sessionHelper.evaluteSearchType(filterVO));
			
			pageStatusList = new ArrayList();
			pageStatusList.add(partName);
		}else if(Constants.POPUP_DISEASE.equals(tableName)){//Disease Group POPUP
			if(parameterMap == null){
				logger.info(LoggerConstants.methodEndLevel());
				return null;
			}
			exportFileName = "disease_group";
			cmsValue = (String)parameterMap.get("cmsValue");
			planValue = (String)parameterMap.get("planValue");
			String hicNbr = (String)parameterMap.get("hicNbr");
			String fromDate = (String)parameterMap.get("fromDate");
			String pbpId = (String)parameterMap.get("pbpId");
			String planName = (String)parameterMap.get("planName");
			
			filterVO = new FilterVO();
			filterVO.setStartDate(fromDate);
			filterVO.setEndDate(fromDate);
			filterVO.setHicNumber(hicNbr);
			filterVO.setPartName(partName);
			filterVO.setPbpId(pbpId);
			filterVO.setPlanName(planName);
			
			pageStatusList = new ArrayList();
			pageStatusList.add(partName);
		}else if(Constants.POPUP_PYMT_DETAIL.equals(tableName)){//Payment Detail part A/B POPUP
			//Fix BUG - filter is never reset. If you leave the page and comes back, filter is updated.
			if(parameterMap == null){
				logger.info(LoggerConstants.methodEndLevel());
				return null;
			}
			exportFileName = "payment_detail_part_AB";
			seqNbr = StringUtil.trimToNull((String)parameterMap.get("seqNbr"));
			pymtType = (String)parameterMap.get("pymtType");
			//String fromDate = (String)parameterMap.get("fromDate");
			//String isPopUp = (String)parameterMap.get("isPopUp");	
			applyDate = (String)parameterMap.get("applyDate");
			
			filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_EFFDATE_POPUP_FILTER);
			pageStatusList = new ArrayList();
			pageStatusList.add("");
		} else {
			if(Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(menuName)){
				if(Constants.READ_ONLY.equals(pageType)) {//when request is from Beneficiary show discrepancy (which is read only screen)
					exportFileName = "beneficiary_show_discrepancies";
					filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_FILTERVO);
					if(filterVO!=null){
						filterVO.setPartName(partName);
						filterVO.setDiscrpStatus("NotClosed"); // Because we are considering "NotClosed" discrepancy only
					}
					pageStatusList = (List)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_SHOW_DISCRP_DETAIL_STATUS);
					detailMap = (Map) sessionHelper.getAttribute(Constants.SESSION_READ_ONLY_DISCRP_DETAIL_MAP);
				}else{//when request is from Beneficiary Discrepancy Detail
					exportFileName = "beneficiary_discrepancy_detail";
					filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DETAIL_FILTERVO);
					pageStatusList = (List) sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DISCRP_DETAIL_STATUS);
					detailMap = (Map) sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DISCRP_DETAIL_MAP);
				}
			}else if(Constants.BENEFICIARY_MENU.equals(menuName) || Constants.PAYMENT_DETAIL.equals(menuName)){
				if(Constants.PAYMENT_DASHBOARD.equals(tableName)) { //if request is from Beneficiary Payment Dashboard
					exportFileName = "beneficiary_payment_dashboard";
					filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_DASHBOARD_FILTERVO);
					pageStatusList = (List) sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_DESH_STATUS);
				} else if(Constants.DISCREPANCY_DASHBOARD.equals(tableName)){//if request is from Beneficiary Discrepancy Dashboard
					exportFileName = "beneficiary_discrepancy_dashboard";
					filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DISC_DASHBOARD_FILTERVO);
					pageStatusList = (List) sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DISCREPANCY_DESH_STATUS);
				} else if(Constants.PAYMENT_SUMMARY.equals(tableName)){
					if(Constants.READ_ONLY.equals(pageType)){//if request is from Beneficiary Show Payments
						exportFileName = "beneficiary_show_payments";						
						filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DETAIL_FILTERVO);
						pageStatusList = (List) sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_SHOW_PYMT_SUMMARY_STATUS);
					} else {
						exportFileName = "beneficiary_payment_details";
						if(Constants.PAYMENT_DETAIL.equals(menuName)){//if request is from Payment Details POPUP
							filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_PYMT_DETAIL_POP_UP_FILTERVO);
							pageStatusList = new ArrayList();
							pageStatusList.add(partName);
							pageStatusList.add(Constants.CONSTANTS_ALL);
						}else{//if request is from Beneficiary Payment Details
							filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_FILTERVO);
							pageStatusList = (List) sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_STATUS);
						}	
					}
					tableName = Constants.PAGE_BENEFICIARY_PYMT_DETAILS;
				}
			}else {
				if(Constants.DISCREPANCY_SUMMARY.equals(tableName)) {
					if(Constants.READ_ONLY.equals(pageType)) {//if request is from Plan Show Discrepancy
						exportFileName = "plan_show_discrepancies";
						filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_PAYMENT_SUMMARY_FILTERVO);
						pageStatusList = (List) sessionHelper.getAttribute(Constants.SESSION_SHOW_DISCREPANCY_SUMMARY_STATUS);	
					} else {//if request is from Discrepancy Summary
						exportFileName = "plan_discrepancy_summary";
						filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_SUMMARY_FILTERVO);
						pageStatusList = (List) sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_SUMMARY_STATUS);
					}
				}else if(Constants.PAYMENT_DASHBOARD.equals(tableName)){//if request is from Plan Payment Dashboard
					exportFileName = "plan_payment_dashboard";
					filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_PAYMENT_DASHBOARD_FILTERVO);
					pageStatusList = (List) sessionHelper.getAttribute(Constants.SESSION_PAYMENT_DESH_STATUS);
				}else if(Constants.DISCREPANCY_DASHBOARD.equals(tableName)){//if request is from Plan Discrepancy Dashboard
					exportFileName = "plan_discrepancy_dashboard";
					filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DASHBOARD_FILTERVO);
					pageStatusList = (List) sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DESH_STATUS);
				}else if(Constants.PAYMENT_SUMMARY.equals(tableName)){
					if(Constants.READ_ONLY.equals(pageType)){//if request is from Plan Show Payments
						exportFileName = "plan_show_payments";
						filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_SUMMARY_FILTERVO);
						pageStatusList = (List) sessionHelper.getAttribute(Constants.SESSION_SHOW_PAYMENT_SUMMARY_STATUS);
					} else {//if request is from Payment Summary
						exportFileName = "plan_payment_summary";
						filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_PAYMENT_SUMMARY_FILTERVO);
						pageStatusList = (List) sessionHelper.getAttribute(Constants.SESSION_PAYMENT_SUMMARY_STATUS);
					}
				} else if(Constants.DISCREPANCY_DETAIL.equals(tableName)){//if request is from Plan Discrepancy Detail
					exportFileName = "discrepancy_detail";
					filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_FILTERVO);
					detailMap = (Map) sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_MAP);
					pageStatusList = (List) sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_STATUS);
				} 
				//Recon-Work Queue Changes : start
				else if(Constants.WORK_QUEUE_MENU.equals(tableName)){//if request is from Plan Discrepancy Detail
					exportFileName = "work_queue";
					filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_WORK_QUEUE_FILTERVO);
					detailMap = (Map) sessionHelper.getAttribute(Constants.SESSION_WORK_QUEUE_MAP);
					pageStatusList = (List) sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_STATUS);
				} 
				//Recon-Work Queue Changes : end
				else if(Constants.TROOP_DASHBOARD.equals(tableName)){//if request is from Troop Dashboard
					exportFileName = "troop_dashboard";
					filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_TROOP_DASHBOARD_FILTERVO);
					pageStatusList = (List) sessionHelper.getAttribute(Constants.SESSION_TROOP_DESH_STATUS);
				} else if(Constants.TROOP_DETAIL.equals(tableName)){//if request is from Troop Detail
					exportFileName = "troop_details";
					filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_TROOP_DETAIL_FILTERVO);
					detailMap = (Map) sessionHelper.getAttribute(Constants.SESSION_TROOP_DETAIL_MAP);
					pageStatusList = (List) sessionHelper.getAttribute(Constants.SESSION_TROOP_DETAIL_STATUS);
				} else if(Constants.PDE_DASHBOARD.equals(tableName)){//if request is from PDE Dashboard
					exportFileName = "pde_dashboard";
					filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_PDE_DASHBOARD_FILTERVO);
					pageStatusList = (List) sessionHelper.getAttribute(Constants.SESSION_PDE_DESH_STATUS);
				} else if(Constants.PDE_EVENT_DETAIL.equals(tableName)){//if request is from PDE Event Detail
					exportFileName = "pde_event_details";
					filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_PDE_EVENT_DETAIL_FILTERVO);
					detailMap = (Map) sessionHelper.getAttribute(Constants.SESSION_PDE_EVENT_DETAIL_MAP);
					pageStatusList = (List) sessionHelper.getAttribute(Constants.SESSION_PDE_EVENT_DETAIL_STATUS);
				} else if(Constants.PROFILE_SEARCH.equals(tableName)){//if request is from Profile Search
					exportFileName = "profile_search";
					filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_PROFILE_DETAIL_FILTERVO);
					detailMap = (Map) sessionHelper.getAttribute(Constants.SESSION_PROFILE_DETAIL_MAP);
					pageStatusList = (List) sessionHelper.getAttribute(Constants.SESSION_PROFILE_DETAIL_STATUS);				
				} else if (Constants.PDE_ERR_DASHBOARD.equals(tableName)) {
					appContext = sessionHelper.getAttribute(Constants.SESSION_PDE_CONTEXT);	
					filterVO = ((PdeContext)appContext).getErrDashBoardFilter();
				} else if (Constants.PDE_ERR_CODES.equals(tableName)) {
					appContext = sessionHelper.getAttribute(Constants.SESSION_PDE_CONTEXT);	
					filterVO = ((PdeContext)appContext).getErrCodesFilter();		
				} else if (Constants.PDE_ERR_DETAIL.equals(tableName)) {
					appContext = sessionHelper.getAttribute(Constants.SESSION_PDE_CONTEXT);	
					filterVO = ((PdeContext)appContext).getErrDetailFilter();		
				}
			}
		}
		
		if (filterVO != null) {
			if(filterVO.getSearchType()!= null)
				searchType = filterVO.getSearchType();
				
			String planId = filterVO.getPlanName();
			if (StringUtil.isNullOrEmpty(planId)) {
				planId = "All Plans";
			}
			
			// overwritting page Status List in case of uiContext "ALL" or export to CSV
			if (Constants.CONSTANTS_ALL.equals(uiContextRange) || Constants.FILE_TYPE_CSV.equals(exportType)) {
				pageStatusList = new ArrayList();
				pageStatusList.add(Constants.CONSTANTS_ALL);
			}
			
			String custName = (String) sessionHelper.getAttribute(Constants.SESSION_CUSTOMER_NAME);
			String userId = (String) sessionHelper.getAttribute(Constants.SESSION_USER_ID);
			String writeOffSerivce = (String) sessionHelper.getAttribute(Constants.SESSION_WRITE_OFF_REQUEST_SERVICE);
			boolean hasWriteOffService = ("TRUE".equals(writeOffSerivce)) ? true : false;
			
			//call to ExportManager for export to PDF and CSV
			String tempFileName = ExportManager.createExport(tableName, appContext, filterVO, planmap, searchType, planId, pageStatusList,
					uiContextRange, sessionHelper.getActiveDataBaseName(), detailMap, exportType, menuName, custName, userId, cmsValue, planValue, seqNbr, pymtType, applyDate, hasWriteOffService);
			logger.info(LoggerConstants.methodEndLevel());
			return new String [] {tempFileName ,exportFileName};
		}
		logger.info(LoggerConstants.methodEndLevel());
		return null;
	}
	
	/**
	 * This method check that whether export request valid or not base on total no of records(Based on search criteria).
	 * All new "print all" request should come here.
	 * @author  
	 * @return "TRUE" or Max valid Number of records to show
	 * @throws ApplicationException
	 */
	public String isExportRequestValid(String pageName)throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null; boolean anyError = true; String errMessage = null;
    	String result = null;
    	try {
        	logger.debug("Inside isExportRapsDetailRequestValid");
			AjaxHelper.validateUser();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			String dbId = sessionHelper.getRapsDatabaseName();
			
			if (Constants.PDE_ERR_DETAIL.equals(pageName)) {
				//This one is the old style, it doesn't require the connection object.
				PdeTroopService service = new PdeTroopService(dbId);
				PdeContext appContext = (PdeContext)sessionHelper.getAttribute(Constants.SESSION_PDE_CONTEXT);	
				FilterVO filterVO = appContext.getErrDetailFilter();		
				Map detailMap = (Map)sessionHelper.getAttribute(Constants.SESSION_PDE_EVENT_DETAIL_MAP);
				logger.info(LoggerConstants.methodEndLevel());
				return service.isExportPdeErrDetailRequestValid(filterVO,detailMap);				
			}
			
			if(StringUtil.isNullOrEmpty(dbId))
				conn = DbConnWeb.getConnection();
			else
				conn = DbConnWeb.getConnection(dbId);  
			
			if (RapsConstants.RAPS_CLAIMS_DETAILS.equals(pageName) || RapsConstants.RAPS_DETAIL.equals(pageName)
					|| RapsConstants.RAPS_ERRORS.equals(pageName)) {
				//request is for RAPS application
				RapsContext rc = (RapsContext) ContextManager.getContext(sessionHelper.getSession(), RapsConstants.RAPS_CONTEXT);
				result = RapsManager.isExportRequestValid(conn, rc, pageName);
			}
			//else ... for future applications.
			
	 		anyError = false;
	 	} catch(Exception e) {
	 		logger.error(LoggerConstants.exceptionMessage(e.toString()));
	 		errMessage = e.getMessage();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				errMessage = e.getMessage();				
			}
		}
		if (anyError)
			throw new ApplicationException(errMessage);
		logger.info(LoggerConstants.methodEndLevel());
		return result;		
	}
	
	public String[] createEncounterExport(String tableName,  String exportType,String claimType,boolean historyFlag,String uiContextRange) throws ApplicationException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();		
		HPEContext hpeContext = null;
		
		if(!("".equals(tableName)) && (tableName != null)) {		
			hpeContext = HPEManager.getContext(sessionHelper.getSession());
			//DME_Dashboard_changes	IFOX-00398979
			String tempFileName = ExportManager.createExport(tableName, hpeContext, null, exportType, claimType,historyFlag,uiContextRange, sessionHelper);			
			logger.info(LoggerConstants.methodEndLevel());
			return new String [] {tempFileName ,tableName};			
		}
		logger.info(LoggerConstants.methodEndLevel());
		return null;
	}
public String[] createFileTrackExport(String subId, String subFrom, String subTo, String fName, String typBus,String tableName, String exportType, String claimType,boolean historyFlag,String uiContextRange) throws ApplicationException, Exception {
	logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();		
		HPEContext hpeContext = null;
		
		if(!("".equals(tableName)) && (tableName != null)) {		
			hpeContext = HPEManager.getContext(sessionHelper.getSession());	
			hpeContext.getHpeftSearchVO().setSearchSubmitterId(subId);
			hpeContext.getHpeftSearchVO().setSearchFromDate(subFrom);
			hpeContext.getHpeftSearchVO().setSearchToDate(subTo);
			hpeContext.getHpeftSearchVO().setFileName(fName);
			hpeContext.getHpeftSearchVO().setTypeOfBusiness(typBus);
			String tempFileName = ExportManager.createExport(tableName, hpeContext, null, exportType, claimType,historyFlag,uiContextRange, sessionHelper);			
			logger.info(LoggerConstants.methodEndLevel());
			return new String [] {tempFileName ,tableName};			
		}
		logger.info(LoggerConstants.methodEndLevel());
		return null;
	}
}
