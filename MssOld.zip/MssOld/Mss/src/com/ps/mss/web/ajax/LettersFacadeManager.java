/*
 * $Id: LettersFacadeManager.java,v 1.1 2014/06/26 07:56:59 praveen Exp $
 */
package com.ps.mss.web.ajax;

import java.sql.Connection;
import java.util.ArrayList;
import org.slf4j.Logger;
import java.util.List;
import org.slf4j.LoggerFactory;
import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.EEMLetterDao;
import com.ps.mss.db.DbConnWeb;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.manager.LettersManager;
import com.ps.mss.model.BasePaginationPage;
import com.ps.mss.model.BasePagingItem;
import com.ps.mss.model.HistoryTrail;
import com.ps.mss.model.LettersContext;
import com.ps.mss.model.LettersDashboardList;
import com.ps.mss.model.LettersDetailInfo;
import com.ps.mss.model.LettersFilter;
import com.ps.mss.model.LettersItem;
import com.ps.mss.model.LettersListItem;
import com.ps.mss.model.Pagination;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.helper.AjaxHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.text.DateFormatter;

/**
 * @author levin.alex
 */
public class LettersFacadeManager {
	//static ModuleLog log = new ModuleLog("LettersFacadeManager");
	private static Logger logger=LoggerFactory.getLogger(LettersFacadeManager.class);

    public LettersDashboardList getLettersDashboardList(String region, String move) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;
    	LettersDashboardList lettersDashboardList = null;
    	
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	AjaxHelper.validateUser(sessionHelper,conn);
    	   	
			String qadvDb = (String)sessionHelper.getAttribute(SessionManager.QADVDB);
			conn = DbConnWeb.reGetConnection(conn,qadvDb);
			
    	   	LettersContext lc = LettersManager.getContext(sessionHelper.getSession(), region);
			lc.setReuseList(false); //always get fresh page.
			Pagination pagination = lc.getDashboardPagination();

			LettersFilter filter = lc.getDashboardFilter();
			lettersDashboardList = LettersManager.getLettersDashboardList(conn, lc, filter, move);

			anyError = false;
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
    		logger.debug(errMessage);
//    		logger.error(errMessage);
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return lettersDashboardList; 
    }

    public LettersItem updateLetterStatus(String region, int rowId, LettersItem item, String newStatus, String newDeleteInd) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;
   	
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	AjaxHelper.validateUser(sessionHelper,conn);
    	   	
			String qadvDb = (String)sessionHelper.getAttribute(SessionManager.QADVDB);
			conn = DbConnWeb.reGetConnection(conn,qadvDb);
			
    	   	String userId = sessionHelper.getUserId();
    	   	LettersContext lc = LettersManager.getContext(sessionHelper.getSession(), region);
    	   	
    	   	LettersDetailInfo lastLettersDetail = lc.getLastLettersDetail();
    	   	
    	   	boolean rslt = LettersManager.updateLettersStatus(conn, item, userId, newStatus, newDeleteInd);
    	   	if (rslt) {
    	   		lastLettersDetail.setStatus(item.getStatus());
    	   		lastLettersDetail.setDeleteInd(item.getDeleteInd());
    	   		lastLettersDetail.setDeleteIndValue(item.getDeleteIndValue());
    	   		lastLettersDetail.setLastUpdateId(item.getLastUpdateId());
    	   		lastLettersDetail.setLastUpdateTime(item.getLastUpdateTime());
    			return item;
    	   	}
    	   	
			anyError = false;
			
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
			logger.debug(errMessage);
//			logger.error(errMessage);
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return null; 
    }
    
    
	/**
 	 * TAB	 : 	Letters List
	 * SUBTAB:	Letters Details
	 * Called whenever a customer selects "<<" "<" or ">" on Letters page. 
	 * This will end up querying db to populate the following:
	 * 		+ Letters List - the 10 items on the list
	 *  	+ Letters Details portion 
	 *  	+ Letters Data portion 
     * @param move
     * @return LettersListItem
     * @throws ApplicationException
     */
    public LettersListItem getLettersListItem(String region, String move) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;
    	LettersListItem lettersListItem = null;
    	
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	AjaxHelper.validateUser(sessionHelper,conn);

			String qadvDb = (String)sessionHelper.getAttribute(SessionManager.QADVDB);
			conn = DbConnWeb.reGetConnection(conn,qadvDb);
			
			LettersContext lc = LettersManager.getContext(sessionHelper.getSession(), region);
			lc.setReuseList(false); //always get fresh page.
			Pagination pagination = lc.getLettersPagination();
			
			if("previous".equals(move)){
				LettersItem lettersItem = new LettersItem();
				setPrevDetailFromHistory(lettersItem, pagination);
				pagination.setFirstDetail(lettersItem);
			}
			
			LettersFilter filter = lc.getLettersFilter();
			lettersListItem = LettersManager.getLettersListItem(conn, lc, filter, move);
	 
			if (lettersListItem != null) {
				int count = 0;
				LettersItem firstItem = null, lastItem = null;
				LettersItem[] detailArr = lettersListItem.getLettersItem();
				if (detailArr != null) {
					count = detailArr.length;
					firstItem = detailArr[0];
					if (count > 0)
						lastItem = detailArr[count - 1];
					lc.setLastLettersDetail(lettersListItem.getLettersDetailInfo()); //save the last fetched letterItem.
				} 
				setPagination(pagination, lettersListItem, count, firstItem, lastItem, move);
			}
			anyError = false;
    	} catch(Exception e) {
    		errMessage = e.getMessage();
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    	 		errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
    		logger.debug(errMessage);
//    		logger.error(errMessage);
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return lettersListItem; 
    }
	
	/**
 	 * TAB	 : 	Letters List
	 * SUBTAB:	Letters Details
	 * Called whenever a customer selects a row on Letters page. 
	 * This will end up querying db to populate the following:
	 *  	+ Letters Details portion 
	 *  	+ Letter Data portion 
     * @param seqNum : additional field for db query. May need additional fields....
     * @param rowId : the selected row on the page
     * @param menuName : "detail"
     * @return
     * @throws ApplicationException
     * 
     */
    public LettersListItem getLettersDetail(String region, int rowId, LettersItem lettersItem) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
    	Connection conn = null; boolean anyError = true; String errMessage = null;
    	LettersListItem lettersListItem = null;
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	AjaxHelper.validateUser(sessionHelper,conn);
    	   	
			String qadvDb = (String)sessionHelper.getAttribute(SessionManager.QADVDB);
			conn = DbConnWeb.reGetConnection(conn,qadvDb);
			
			LettersContext lc = LettersManager.getContext(sessionHelper.getSession(), region);
	
	    	Pagination pagination = lc.getLettersPagination();
	    	pagination.setSelectedLine(rowId);
	    	//LettersItem[] lettersItemArr = (LettersItem[])lc.getDetailList();
	    	//LettersItem lettersItem = (LettersItem)lettersItemArr[rowId];
	    	lettersListItem = LettersManager.getLettersDataItem(conn, lc, lettersItem);
			//lc.setLastLettersItem(lettersListItem.getCurrentLettersItem()); //save the last fetched data.
	    	lc.setLastLettersDetail(lettersListItem.getLettersDetailInfo()); //save the last fetched letterItem.
			anyError = false;
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			errMessage = e.getMessage();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				errMessage = e.getMessage();
			}
		}
		if (anyError) {
    		logger.debug(errMessage);
//    		logger.error(errMessage);
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return lettersListItem;
	}
    
    
    /**
     * 
     * @param pagingItem object to be populated by item stored in history
     * @param pagination
     */
	private void setPrevDetailFromHistory(BasePagingItem pagingItem, Pagination pagination) {
		logger.info(LoggerConstants.methodStartLevel());
		String pageHist = (String) pagination.getPageHistory();
		if(pageHist != null){
			String historyStr;
			
			if(pageHist.indexOf(",") == -1)
				historyStr = pageHist;
			else {
				String [] pageHistArr = pageHist.split("[,]");				
				//	getting Last page 
				historyStr = pageHistArr[pageHistArr.length-1];
			}
			pagingItem.setFieldsBasedOnHistory(historyStr);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	/**
	 * 
	 * @param pagination
	 * @param detailPage
	 * @param arrSize
	 * @param firstItem
	 * @param lastItem
	 * @param move
	 */
    private void setPagination(Pagination pagination, BasePaginationPage detailPage, int arrSize, Object firstItem, Object lastItem, String move) {
    	logger.info(LoggerConstants.methodStartLevel());
    	if(arrSize > 0 ){
            //**************** START BLOCK FOR CALCULATING PAGE HIST ***************************
			// ADD : When user click on NEXT button (adding prev. page First VO
			// REMOVE : When user click on PREV button (remove top entry from List (it. current loading page)
			//
			
        	String pageHist = (String) pagination.getPageHistory();
            String newPageHist = (pageHist != null) ? pageHist : "";
            
            // updating Page Hist 
            if("previous".equals(move)){
            	if(newPageHist.indexOf(",") != -1) {
                	String []pageHistArr = pageHist.split("[,]"); // spliting the list, remove last entry (CURRENT PAGE)
                	newPageHist = pageHistArr[0];
                	for(int i=1; i < pageHistArr.length-1; i++ )
                		newPageHist += "," + pageHistArr[i];
            	} else 
            		newPageHist = "";
            	
    		} else if ("next".equals(move)) {  // adding current page Paging Key Set into PDE PAGE HIST
    			BasePagingItem detailItem = (BasePagingItem) pagination.getFirstDetail();
    			if(! "".equals(newPageHist))
    				newPageHist += ",";
   				newPageHist += detailItem.getHistory();
        	}
    		
    		if(("previous".equals(move) && "".equals(newPageHist)) || "first".equals(move))
    			pagination.setPageHistory(null);
    		else
    			pagination.setPageHistory(newPageHist);
    		
            //**************** START BLOCK FOR CALCULATING PAGE HIST ***************************
    		pagination.setFirstDetail(firstItem);
    		pagination.setLastDetail(lastItem);
    		pagination.setCurrentPage(detailPage.getCurrentPage());
    		pagination.setPageNumber(detailPage.getPageNumber());
    		pagination.setSelectedLine(detailPage.getSelectedLine());
        }
		pagination.setMaxRecordCount(10);
		pagination.setAllPage(false);   
		logger.info(LoggerConstants.methodEndLevel());
    } 
    
    private void setPagination(Pagination pagination, int arrSize, Object firstItem, Object lastItem, String move) {
    	logger.info(LoggerConstants.methodStartLevel());
    	if(arrSize > 0 ){
            //**************** START BLOCK FOR CALCULATING PAGE HIST ***************************
			// ADD : When user click on NEXT button (adding prev. page First VO
			// REMOVE : When user click on PREV button (remove top entry from List (it. current loading page)
			//		
        	String pageHist = (String) pagination.getPageHistory();
            String newPageHist = (pageHist != null) ? pageHist : "";
            
            // updating Page Hist 
            if("previous".equals(move)){
            	
            	if(newPageHist.indexOf(",") != -1) {
                	String []pageHistArr = pageHist.split("[,]"); // spliting the list, remove last entry (CURRENT PAGE)
                	newPageHist = pageHistArr[0];
                	for(int i=1; i < pageHistArr.length-1; i++ )
                		newPageHist += "," + pageHistArr[i];
            	} else {
            		newPageHist = "";
            	}
            	
    		} else if ("next".equals(move)) {  // adding current page Paging Key Set into PAGE HIST
    			HistoryTrail detailItem = (HistoryTrail) pagination.getFirstDetail();
    			if(! "".equals(newPageHist))
    				newPageHist += ",";
   				newPageHist += detailItem.getHistory();
    		}
    		
    		if(("previous".equals(move) && "".equals(newPageHist)) || "first".equals(move)) {
    			pagination.setPageHistory(null);
    		} else
    			pagination.setPageHistory(newPageHist);
    		
            //**************** START BLOCK FOR CALCULATING PAGE HIST ***************************
    		pagination.setFirstDetail(firstItem);
    		pagination.setLastDetail(lastItem);
    		//pagination.setCurrentPage(detailPage.getCurrentPage());
    		
        }
		pagination.setMaxRecordCount(10);
		pagination.setAllPage(false);        
		logger.info(LoggerConstants.methodEndLevel());
		}
    
    public int massUpdateLetterStatus(String region, LettersFilter criteria) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;
    	int updateCnt = -1;
    	
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	AjaxHelper.validateUser(sessionHelper,conn);

			String qadvDb = (String)sessionHelper.getAttribute(SessionManager.QADVDB);
			conn = DbConnWeb.reGetConnection(conn,qadvDb);
			
			LettersContext lc = LettersManager.getContext(sessionHelper.getSession(), region);
			criteria.setSiteId(lc.getSiteId());
			criteria.setRegion(lc.getRegion());

    	   	String userId = sessionHelper.getUserId();
    	   	String mfId = sessionHelper.getMfId();
    	   	criteria.setMfId(mfId);

    	   	DateFormatter df = new DateFormatter();
    	   	criteria.setRequestDateFrom(df.reFormatDate(criteria.getRequestDateFrom(),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD));
    	   	criteria.setRequestDateTo(df.reFormatDate(criteria.getRequestDateTo(),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD));
    	   	
    	   	updateCnt = LettersManager.massUpdateLettersStatus(conn, criteria, userId);
    	   	
			anyError = false;
			
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
    		logger.debug(errMessage);
//    		logger.error(errMessage);
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return updateCnt; 
    }

    public int lettersGenerateRequest(String region) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	Connection conn = null; 
    	boolean anyError = true; 
    	String errMessage = null;
    	int rslt = -1;
    	
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	AjaxHelper.validateUser(sessionHelper,conn);

			String qadvDb = (String)sessionHelper.getAttribute(SessionManager.QADVDB);
			conn = DbConnWeb.reGetConnection(conn,qadvDb);
			
			LettersContext lc = LettersManager.getContext(sessionHelper.getSession(), region);
    	   	String userId = sessionHelper.getUserId();
    	   	String mfId = sessionHelper.getMfId();
    	   	
    	   	rslt = LettersManager.lettersGenerateRequest(conn,mfId,lc.getSiteId(),lc.getRegion(),userId);
			anyError = false;
			
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
    		logger.debug(errMessage);
//    		logger.error(errMessage);
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return rslt;    	
    }
    public List getFileBatchId(String fromDate, String toDate) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
    	Connection conn = null; 
    	boolean anyError = false; 
    	String errMessage = null;
    	int rslt = -1;
    	String searchReqFromDate=DateFormatter.reFormat(fromDate,DateFormatter.MM_DD_YYYY,DateFormatter.SQL_TIMESTAMP);
		String searchReqToDate=DateFormatter.reFormat(toDate,DateFormatter.MM_DD_YYYY,DateFormatter.SQL_TIMESTAMP);
		List lstBatchId = new ArrayList();
		
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    		String customerId = sessionHelper.getMfId();
			//logger.info(" LettersFacadeManager : getFileBatchId : customerId [" + customerId + "] ");
    	   	AjaxHelper.validateUser(sessionHelper,conn);

			String qadvDb = (String)sessionHelper.getAttribute(SessionManager.QADVDB);
			conn = DbConnWeb.reGetConnection(conn,qadvDb);
			
			 lstBatchId = (List)new EEMLetterDao().getDwrLetterReviewQcBatchId(conn,searchReqFromDate,searchReqToDate,customerId);
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		//e.printStackTrace();
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
			logger.debug(errMessage);
//			logger.error(errMessage);
    		
		}	
		logger.info(LoggerConstants.methodEndLevel());
    	return lstBatchId;
    }
    public List getLetterDesc(String batchId) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
    	Connection conn = null; 
    	boolean anyError = false; 
    	String errMessage = null;
    	int rslt = -1;
    	
		List lstLtrDesc = new ArrayList();
		
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    		String mfId = sessionHelper.getMfId();
    	   	AjaxHelper.validateUser(sessionHelper,conn);

			String qadvDb = (String)sessionHelper.getAttribute(SessionManager.QADVDB);
			conn = DbConnWeb.reGetConnection(conn,qadvDb);
			
			lstLtrDesc = (List)new EEMLetterDao().getDwrLetterReviewQcDescription(conn,batchId,mfId);
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		//e.printStackTrace();
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
			logger.debug(errMessage);
//			logger.error(errMessage);
    		
		}	
		logger.info(LoggerConstants.methodEndLevel());
    	return lstLtrDesc;
    }
}