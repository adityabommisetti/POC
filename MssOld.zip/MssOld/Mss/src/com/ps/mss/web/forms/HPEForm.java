/*
 * $Id: HPEForm.java,v 1.1 2014/06/26 07:55:45 praveen Exp $
 */
package com.ps.mss.web.forms;

import org.apache.struts.action.ActionForm;

/**
 * @author nenne.robert
 */
public class HPEForm extends ActionForm {

    /* Main form fields */
	private String method;
    private String menu;
    private String pageName;
    
	/**
	 * @return Returns the menu.
	 */
	public String getMenu() {
		return menu;
	}
	/**
	 * @param menu The menu to set.
	 */
	public void setMenu(String menu) {
		this.menu = menu;
	}
	/**
	 * @return Returns the method.
	 */
	public String getMethod() {
		return method;
	}
	/**
	 * @param method The method to set.
	 */
	public void setMethod(String method) {
		this.method = method;
	}
	
	public String getPageName() {
		return pageName;
	}
	public void setPageName(String pageName) {
		this.pageName = pageName;
	}
}
