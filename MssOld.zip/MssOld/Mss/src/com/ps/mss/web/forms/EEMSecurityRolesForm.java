package com.ps.mss.web.forms;

import java.util.HashMap;
import java.util.List;
/**
 * This class is used as bean on controller side
 * 
 * @author Pramod 
 *
 *@version 1.0, 15th Oct 2013
 */
public class EEMSecurityRolesForm extends EEMForm {
	/**
	 * Holds user Id
	 */
	private String userID;
	/**
	 * holds customer Id
	 */
	private String customerID;
	/**
	 * Holds user name
	 */
	private String userName;
	/**
	 * Holds user details
	 */
	private HashMap userDetails;
	/**
	 * Holds the list of roles
	 */
	private List userRole;
	/**
	 * holds the role is updated or not 
	 */
	private boolean userUpdate;
	/**
	 * Holds the selected user role
	 */
	private String selUserRole;
	/**
	 * Holds the selected user id
	 */
	private String selecteduserID;
	
	private String userRoles;
	private String selRole;
	/**
	 * @return the userID
	 */
	public String getUserID() {
		return userID;
	}
	/**
	 * @param userID the userID to set
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}
	/**
	 * @return the customerID
	 */
	public String getCustomerID() {
		return customerID;
	}
	/**
	 * @param customerID the customerID to set
	 */
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the userDetails
	 */
	public HashMap getUserDetails() {
		return userDetails;
	}
	/**
	 * @param userDetails the userDetails to set
	 */
	public void setUserDetails(HashMap userDetails) {
		this.userDetails = userDetails;
	}
	/**
	 * @return the userRole
	 */
	public List getUserRole() {
		return userRole;
	}
	/**
	 * @param userRole the userRole to set
	 */
	public void setUserRole(List userRole) {
		this.userRole = userRole;
	}
	/**
	 * @return the userUpdate
	 */
	public boolean isUserUpdate() {
		return userUpdate;
	}
	/**
	 * @param userUpdate the userUpdate to set
	 */
	public void setUserUpdate(boolean userUpdate) {
		this.userUpdate = userUpdate;
	}
	/**
	 * @return the selUserRole
	 */
	public String getSelUserRole() {
		return selUserRole;
	}
	/**
	 * @param selUserRole the selUserRole to set
	 */
	public void setSelUserRole(String selUserRole) {
		this.selUserRole = selUserRole;
	}
	/**
	 * @return the selecteduserID
	 */
	public String getSelecteduserID() {
		return selecteduserID;
	}
	/**
	 * @param selecteduserID the selecteduserID to set
	 */
	public void setSelecteduserID(String selecteduserID) {
		this.selecteduserID = selecteduserID;
	}
	/**
	 * @return the userRoles
	 */
	public String getUserRoles() {
		return userRoles;
	}
	/**
	 * @param userRoles the userRoles to set
	 */
	public void setUserRoles(String userRoles) {
		this.userRoles = userRoles;
	}
	/**
	 * @return the selRole
	 */
	public String getSelRole() {
		return selRole;
	}
	/**
	 * @param selRole the selRole to set
	 */
	public void setSelRole(String selRole) {
		this.selRole = selRole;
	}
	
	
	
	
}
