/*
 * $Id: Utility.java,v 1.1 2014/06/26 07:55:10 praveen Exp $
 */
package com.ps.mss.web.helper;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;

import com.ps.mss.framework.RapsConstants;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.framework.Constants;
import com.ps.mss.framework.HPEConstants;
import com.ps.mss.model.RapsContext;

/**
 * @author indrapradja.adriana
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Utility {
	private static Logger logger=LoggerFactory.getLogger(Utility.class);
	public static void copyFromSessionToRequest(RapsContext rc, HttpServletRequest request, SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		request.setAttribute(RapsConstants.RAPS_CONTEXT, rc);
		request.setAttribute(Constants.SESSION_USER_ID, sessionHelper.getUserId());
		String custName = (String) sessionHelper.getAttribute(Constants.SESSION_CUSTOMER_NAME);
		request.setAttribute(Constants.SESSION_CUSTOMER_NAME, custName);
		logger.info(LoggerConstants.methodEndLevel());
	}
	/**
	 * This function saves uiContext found in the form into RapsContext (which is stored in session). 
	 * @param rc  - RapsContext 
	 * @param rf - RAPSForm
	 */
	public static void saveExpandedItems(RapsContext rc, String expandedListString, String pageName) {
		logger.info(LoggerConstants.methodStartLevel());
		List expandedList = null ;
		if (expandedListString != null  && !"".equals(expandedListString.trim())) {		
			String[] uiContext = expandedListString.split("\\|"); //need to escape it.
			if(uiContext != null) 
				expandedList = Arrays.asList(uiContext);
		}
	    if(RapsConstants.RAPS_DASHBOARD.equals(pageName)){
	    	/* This will be something like "H9988", "T9988", "T9998-2006", etc. */
	    	rc.setDashBoardExpandedItems(expandedList); 
		} 
	    else if(RapsConstants.RAPS_CLAIMS_DASHBOARD.equals(pageName)){
	    	/* This will be something like "H9988", "T9988", "T9998-2006", etc. */
	    	rc.setClaimsDashboardExpandedItems(expandedList); 
		} 
	    else if(RapsConstants.RAPS_STATISTIC.equals(pageName)){
	    	/* This will be something like "H9988", "T9988", "T9998-2006", etc. */
	    	rc.setStatisticExpandedItems(expandedList); 
		} 
	    else if(RapsConstants.RAPS_CLAIMS_DETAILS.equals(pageName)){
			/* This will be like "list", "detail", or "history" */
    		rc.setListOnClaimsDetailExpanded(false);
			rc.setDetailsOnClaimsDetailExpanded(false);
			rc.setHistoryOnClaimsDetailExpanded(false);
			rc.setAdditionalClaimInfoExpanded(false);
			if (expandedList == null) return;
			Iterator it = expandedList.iterator();
			while(it.hasNext()) {
				String expandedItem = (String) it.next();
				if(RapsConstants.RAPS_EXPANDABLE_LIST.equals(expandedItem)) 
					rc.setListOnClaimsDetailExpanded(true);
				else if (RapsConstants.RAPS_EXPANDABLE_DETAILS.equals(expandedItem))
					rc.setDetailsOnClaimsDetailExpanded(true);
				else if (RapsConstants.RAPS_EXPANDABLE_MOREINFO.equals(expandedItem))
					rc.setAdditionalClaimInfoExpanded(true);
				else if(RapsConstants.RAPS_EXPANDABLE_HISTORY.equals(expandedItem))
					rc.setHistoryOnClaimsDetailExpanded(true);
			}		
		}
	    else if (RapsConstants.RAPS_CLAIMS_DETAILS_POP.equals(pageName) || RapsConstants.RAPS_DETAIL_POP.equals(pageName)) {
	    	rc.setAdditionalInfoOnPopupExpanded(false);
	    	rc.setDetailsOnPopupExpanded(false);
	    	rc.setHistoryOnPopupExpanded(false);
			if (expandedList == null) return;
			Iterator it = expandedList.iterator();
			while(it.hasNext()) {
				String expandedItem = (String) it.next();
				if (RapsConstants.RAPS_EXPANDABLE_DETAILS.equals(expandedItem))
					rc.setDetailsOnPopupExpanded(true);
				else if (RapsConstants.RAPS_EXPANDABLE_MOREINFO.equals(expandedItem))
					rc.setAdditionalInfoOnPopupExpanded(true);
				else if(RapsConstants.RAPS_EXPANDABLE_HISTORY.equals(expandedItem))
					rc.setHistoryOnPopupExpanded(true);
			}
	    }
	    else if(RapsConstants.RAPS_DETAIL.equals(pageName)){
			/* This will be like "list", "detail", or "history" */
    		rc.setListOnSummaryDetailExpanded(false);
			rc.setDetailsOnSummaryDetailExpanded(false);
			rc.setHistoryOnSummaryDetailExpanded(false);
			if (expandedList == null) return;
			Iterator it = expandedList.iterator();
			while(it.hasNext()) {
				String expandedItem = (String) it.next();
				if(RapsConstants.RAPS_EXPANDABLE_LIST.equals(expandedItem)) 
					rc.setListOnSummaryDetailExpanded(true);
				else if (RapsConstants.RAPS_EXPANDABLE_DETAILS.equals(expandedItem))
					rc.setDetailsOnSummaryDetailExpanded(true);
				else if(RapsConstants.RAPS_EXPANDABLE_HISTORY.equals(expandedItem))
					rc.setHistoryOnSummaryDetailExpanded(true);
			}		
		}
	    else if (RapsConstants.RAPS_ENTRY.equals(pageName)) {
	    	rc.getRapsEntry().setDetailExpanded(false);
	    	if (expandedList != null) {
				Iterator it = expandedList.iterator();
				while(it.hasNext()) {
					String expandedItem = (String) it.next();
					if (RapsConstants.RAPS_EXPANDABLE_DETAILS.equals(expandedItem))
						rc.getRapsEntry().setDetailExpanded(true);
				}	
	    	}
	    }
	    else if(RapsConstants.RAPS_WORKFLOW.equals(pageName)){
			/* This will be like "list", "detail", or "history" */
    		rc.setListOnWorkflowExpanded(false);
			rc.setDetailsOnWorkflowExpanded(false);
			rc.setHistoryOnWorkflowExpanded(false);
			if (expandedList == null) return;
			Iterator it = expandedList.iterator();
			while(it.hasNext()) {
				String expandedItem = (String) it.next();
				if(RapsConstants.RAPS_EXPANDABLE_LIST.equals(expandedItem)) 
					rc.setListOnWorkflowExpanded(true);
				else if (RapsConstants.RAPS_EXPANDABLE_DETAILS.equals(expandedItem))
					rc.setDetailsOnWorkflowExpanded(true);
				else if(RapsConstants.RAPS_EXPANDABLE_HISTORY.equals(expandedItem))
					rc.setHistoryOnWorkflowExpanded(true);
			}		
		}
	    else if(RapsConstants.RAPS_ERRORS.equals(pageName)){
			/* This will be like "list", "detail", or "history" */
    		rc.setListOnErrorsExpanded(false);
			rc.setDetailsOnErrorsExpanded(false);
			rc.setHistoryOnErrorsExpanded(false);
			if (expandedList == null) return;
			Iterator it = expandedList.iterator();
			while(it.hasNext()) {
				String expandedItem = (String) it.next();
				if(RapsConstants.RAPS_EXPANDABLE_LIST.equals(expandedItem)) 
					rc.setListOnErrorsExpanded(true);
				else if (RapsConstants.RAPS_EXPANDABLE_DETAILS.equals(expandedItem))
					rc.setDetailsOnErrorsExpanded(true);
				else if(RapsConstants.RAPS_EXPANDABLE_HISTORY.equals(expandedItem))
					rc.setHistoryOnErrorsExpanded(true);
			}		
		}
	    logger.info(LoggerConstants.methodEndLevel());
	}
	
    public static String buildPlanPBPArray(Map map) {
    	logger.info(LoggerConstants.methodStartLevel());
    	/*	 Create the Plan/PBP/Segment array with the following structure
    	planPBPSegment =  ['H9998',[['001'],['002']]],
    					  ['T9998',[['003'],['014']]]
    					 
    	*/	
    	TreeMap tree = (TreeMap)map;
		if (tree == null) return "[]";
    	StringBuffer result = new StringBuffer("");
    	Set set = tree.entrySet();
    	Iterator it = set.iterator();
    	int i = 0;
    	while (it.hasNext()) {
    	       Map.Entry entry =  ( Map.Entry ) it.next () ; 
    	       if (i >0) result.append(",");
    	       result.append("['").append(entry.getKey()).append("',");
    	       TreeMap children = (TreeMap) entry.getValue();
    	       int j = 0;
    	       Set pbps = children.entrySet();
    	       if (pbps.size() == 0) 
    	       		result.append("[['']]");
    	       else {
    	       		result.append("[");
	    	       Iterator childIt = pbps.iterator();
	    	       while (childIt.hasNext()) {
	    	       		Map.Entry pbp = (Map.Entry) childIt.next();
	    	       		if (j>0) result.append(",");
	    	       		result.append("['").append(pbp.getKey()).append("']");
	    	       		j++;
	    	       }
	    	      result.append("]");
    	       }
	    	   result.append("]");
	    	   i++;
    	}
    	logger.info(LoggerConstants.methodEndLevel());
    	return result.toString();
    }
   public static String[] getDshSelectedMapArray( String mainTab,String encType,SessionHelper sessionHelper){
	   logger.info(LoggerConstants.methodStartLevel());
	   String[] dsh_selTab=null;
    	Object dshSelectedMap= sessionHelper.getAttribute(mainTab);
		try{
	    	if(dshSelectedMap==null){
	    		dsh_selTab=new String[3] ;
	    	}else{	
	    		dsh_selTab=(String[])dshSelectedMap;	    		
	    	}
			if("I".equalsIgnoreCase(encType)){dsh_selTab[0]="block";dsh_selTab[1]="none";dsh_selTab[2]="none";}
			if("P".equalsIgnoreCase(encType)){dsh_selTab[0]="none";dsh_selTab[1]="block";dsh_selTab[2]="none";}
			if("E".equalsIgnoreCase(encType)){dsh_selTab[0]="none";dsh_selTab[1]="none";dsh_selTab[2]="block";}
		}catch(Exception ex){
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			logger.debug("getDshSelectedMapArray Exception: "+ex.getMessage());
//			logger.error("getDshSelectedMapArray Exception: "+ex.getMessage());
		}
		logger.info(LoggerConstants.methodEndLevel());
    	return dsh_selTab;
    }
   public static String getEncTypeFromSelectedTab( String mainTab,SessionHelper sessionHelper){
	   logger.info(LoggerConstants.methodStartLevel());
	   String encType="I";
   	String[] dsh_selTab=null;
   	Object dshSelectedMap=null; 
   	dshSelectedMap=sessionHelper.getAttribute(mainTab);
   	if(dshSelectedMap!=null){
   		try{
   		
   		dsh_selTab=(String[])dshSelectedMap;

	   	if(HPEConstants.BLOCK.equalsIgnoreCase(dsh_selTab[0])){
	   		encType="I";
	   	}else if(HPEConstants.BLOCK.equalsIgnoreCase(dsh_selTab[1])){
	   		encType="P";
	   	}else if(HPEConstants.BLOCK.equalsIgnoreCase(dsh_selTab[2])){
	   		encType="E";
	   	}	   	
   		
   		}catch(Exception ex){
   			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
   			logger.debug("getEncTypeFromSelectedTab Exception: "+ex.getMessage());
//   			logger.error("getEncTypeFromSelectedTab Exception: "+ex.getMessage());
   		}
   	}   	
   	logger.info(LoggerConstants.methodEndLevel());
   	return encType;
   }
}

