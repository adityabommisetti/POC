/*
 * $Id: DiscrepancyDetailForm.java,v 1.1 2014/06/26 07:55:42 praveen Exp $
 */
package com.ps.mss.web.forms;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.manager.MasterManager;
import com.ps.mss.model.DiscrepancyDetailVOList;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.util.NameValuePair;

/**
 * Form bean for a Struts application.
 * @version 	1.0
 * @author
 */
public class WorkQueueForm extends ActionForm {
	
	private String planName;
	private String fromDate;
	private String toDate;
	private String wqupdateDateFrom;
	private String wqupdateDateTo;
	private String discCd;
	private String hicNbr;
	private String actionType;
	private String pageType;
	private String searchType;
	private String partName = Constants.BOTH_PARTS;
	private String discrepancyType;
	
	private String wqupdateId;
	private NameValuePair [] discStatusArray;
	private NameValuePair [] discrpTypeList;
	private NameValuePair [] planNameList;
	
	private DiscrepancyDetailVOList discrepancyDetailVOList;
	
	private String showDiscrpList;
	private String showPartDDiscrpList;
	private String showDiscrpDetail;
	private String showDiscrpHistory;
	private String showDemoGrpInfo;
	private String activeService;
	private String menuName;
	private String criteriaAvailable = "true";
	//Recon Demo-WorkQueue
    private String select;
    private String wqassignedBy;
    private List assignedByList;
    private String wqassignedTo;
    private List assignedToList;
    private String wqfromAssignDate;
    private String wqtoAssignDate;
    
    //AWork Queue- Assign task
    private String reassignedTo;
    private String reassignComment;
    
    
			
	/**
	 * @return the fromAssignDate
	 */
	public String getWqfromAssignDate() {
		return wqfromAssignDate;
	}
	/**
	 * @param fromAssignDate the fromAssignDate to set
	 */
	public void setWqfromAssignDate(String fromAssignDate) {
		this.wqfromAssignDate = fromAssignDate;
	}
	/**
	 * @return the toAssignDate
	 */
	public String getWqtoAssignDate() {
		return wqtoAssignDate;
	}
	/**
	 * @param toAssignDate the toAssignDate to set
	 */
	public void setWqtoAssignDate(String toAssignDate) {
		this.wqtoAssignDate = toAssignDate;
	}
	/**
	 * @return the assignedBy
	 */
	public String getWqassignedBy() {
		return wqassignedBy;
	}
	/**
	 * @param assignedBy the assignedBy to set
	 */
	public void setWqassignedBy(String assignedBy) {
		this.wqassignedBy = assignedBy;
	}
	/**
	 * @return the assignedByList
	 */
	public List getAssignedByList() {
		return assignedByList;
	}
	/**
	 * @param assignedByList the assignedByList to set
	 */
	public void setAssignedByList(List assignedByList) {
		this.assignedByList = assignedByList;
	}
	/**
	 * @return the assignedTo
	 */
	public String getWqassignedTo() {
		return wqassignedTo;
	}
	/**
	 * @param assignedTo the assignedTo to set
	 */
	public void setWqassignedTo(String assignedTo) {
		this.wqassignedTo = assignedTo;
	}
	/**
	 * @return the assignedToList
	 */
	public List getAssignedToList() {
		return assignedToList;
	}
	/**
	 * @param assignedToList the assignedToList to set
	 */
	public void setAssignedToList(List assignedToList) {
		this.assignedToList = assignedToList;
	}
	/**
	 * @return the select
	 */
	public String getSelect() {
		return select;
	}
	/**
	 * @param select the select to set
	 */
	public void setSelect(String select) {
		this.select = select;
	}
	//Recon Demo-WorkQueue
	/**
	 * @return Returns the showPartDDiscrpList.
	 */
	public String getShowPartDDiscrpList() {
		return showPartDDiscrpList;
	}
	/**
	 * @param showPartDDiscrpList The showPartDDiscrpList to set.
	 */
	public void setShowPartDDiscrpList(String showPartDDiscrpList) {
		this.showPartDDiscrpList = showPartDDiscrpList;
	}
	/**
	 * @return Returns the showDemoGrpInfo.
	 */
	public String getShowDemoGrpInfo() {
		return showDemoGrpInfo;
	}
	/**
	 * @param showDemoGrpInfo The showDemoGrpInfo to set.
	 */
	public void setShowDemoGrpInfo(String showDemoGrpInfo) {
		this.showDemoGrpInfo = showDemoGrpInfo;
	}
	/**
	 * @return Returns the menuName.
	 */
	public String getMenuName() {
		return menuName;
	}
	/**
	 * @param menuName The menuName to set.
	 */
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	/**
	 * @return Returns the showDiscrpDetail.
	 */
	public String getShowDiscrpDetail() {
		return showDiscrpDetail;
	}
	/**
	 * @param showDiscrpDetail The showDiscrpDetail to set.
	 */
	public void setShowDiscrpDetail(String showDiscrpDetail) {
		this.showDiscrpDetail = showDiscrpDetail;
	}
	/**
	 * @return Returns the showDiscrpHistory.
	 */
	public String getShowDiscrpHistory() {
		return showDiscrpHistory;
	}
	/**
	 * @param showDiscrpHistory The showDiscrpHistory to set.
	 */
	public void setShowDiscrpHistory(String showDiscrpHistory) {
		this.showDiscrpHistory = showDiscrpHistory;
	}
	/**
	 * @return Returns the showDiscrpList.
	 */
	public String getShowDiscrpList() {
		return showDiscrpList;
	}
	/**
	 * @param showDiscrpList The showDiscrpList to set.
	 */
	public void setShowDiscrpList(String showDiscrpList) {
		this.showDiscrpList = showDiscrpList;
	}
	/**
	 * @return Returns the updateId.
	 */
	public String getWqupdateId() {
		return wqupdateId;
	}
	/**
	 * @param updateId The updateId to set.
	 */
	public void setWqupdateId(String updateId) {
		this.wqupdateId = updateId;
	}
	/**
	 * @return Returns the discrepancyType.
	 */
	public String getDiscrepancyType() {
		return discrepancyType;
	}
	/**
	 * @param discrepancyType The discrepancyType to set.
	 */
	public void setDiscrepancyType(String discrepancyType) {
		this.discrepancyType = discrepancyType;
	}
	/**
	 * @return Returns the actionType.
	 */
	public String getActionType() {
		return actionType;
	}
	/**
	 * @param actionType The actionType to set.
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	/**
	 * @return Returns the discCd.
	 */
	public String getDiscCd() {
		return discCd;
	}
	/**
	 * @param discCd The discCd to set.
	 */
	public void setDiscCd(String discCd) {
		this.discCd = discCd;
	}
	
	/**
	 * @return Returns the discrpTypeList.
	 */
	public NameValuePair[] getDiscrpTypeList() {
		return discrpTypeList;
	}
	/**
	 * @param discrpTypeList The discrpTypeList to set.
	 */
	public void setDiscrpTypeList(NameValuePair[] discrpTypeList) {
		this.discrpTypeList = discrpTypeList;
	}
	/**
	 * @return Returns the discStatusArray.
	 */
	public NameValuePair[] getDiscStatusArray() {
		return discStatusArray;
	}
	/**
	 * @param discStatusArray The discStatusArray to set.
	 */
	public void setDiscStatusArray(NameValuePair[] discStatusArray) {
		this.discStatusArray = discStatusArray;
	}
		
	/**
	 * @return Returns the fromDate.
	 */
	public String getFromDate() {
		return fromDate;
	}
	/**
	 * @param fromDate The fromDate to set.
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	/**
	 * @return Returns the toDate.
	 */
	public String getToDate() {
		return toDate;
	}
	/**
	 * @param toDate The toDate to set.
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	/**
	 * @return Returns the hicNbr.
	 */
	public String getHicNbr() {
		if(hicNbr != null)
			return hicNbr.toUpperCase();
			
		return hicNbr;
	}
	/**
	 * @param hicNbr The hicNbr to set.
	 */
	public void setHicNbr(String hicNbr) {
		this.hicNbr = hicNbr;
	}
	/**
	 * @return Returns the partName.
	 */
	public String getPartName() {
		return partName;
	}
	/**
	 * @param partName The partName to set.
	 */
	public void setPartName(String partName) {
		this.partName = partName;
	}
	/**
	 * @return Returns the planName.
	 */
	public String getPlanName() {
		return planName;
	}
	/**
	 * @param planName The planName to set.
	 */
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	/**
	 * @return Returns the searchType.
	 */
	public String getSearchType() {
		return searchType;
	}
	/**
	 * @param searchType The searchType to set.
	 */
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	/**
	 * @return Returns the updateDateFrom.
	 */
	public String getWqupdateDateFrom() {
		return wqupdateDateFrom;
	}
	/**
	 * @param updateDateFrom The updateDateFrom to set.
	 */
	public void setWqupdateDateFrom(String updateDateFrom) {
		this.wqupdateDateFrom = updateDateFrom;
	}
	/**
	 * @return Returns the updateDateTo.
	 */
	public String getWqupdateDateTo() {
		return wqupdateDateTo;
	}
	/**
	 * @param updateDateTo The updateDateTo to set.
	 */
	public void setWqupdateDateTo(String updateDateTo) {
		this.wqupdateDateTo = updateDateTo;
	}
	
	
	
	
    public void reset(ActionMapping mapping, HttpServletRequest request) {
    	showDiscrpList = "";
    	showPartDDiscrpList = "";
    	showDiscrpDetail = "";
    	showDiscrpHistory = "";
    	showDemoGrpInfo = "";
    	partName = Constants.BOTH_PARTS;
    	criteriaAvailable = "true";
    	//partCPageHist = "";
    }
    

	/**
	 * @return Returns the discrepancyDetailVOList.
	 */
	public DiscrepancyDetailVOList getDiscrepancyDetailVOList() {
		return discrepancyDetailVOList;
	}
	/**
	 * @param discrepancyDetailVOList The discrepancyDetailVOList to set.
	 */
	public void setDiscrepancyDetailVOList(
			DiscrepancyDetailVOList discrepancyDetailVOList) {
		this.discrepancyDetailVOList = discrepancyDetailVOList;
	}
	
	
	/**
	 * @return Returns the planNameList.
	 */
	public NameValuePair[] getPlanNameList() {
		return planNameList;
	}
	/**
	 * @param planNameList The planNameList to set.
	 */
	public void setPlanNameList(NameValuePair[] planNameList) {
		this.planNameList = planNameList;
	}
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {

        ActionErrors errors = new ActionErrors();
        return errors;

    }
	/**
	 * @param request
	 * @throws ApplicationException
	 */
    public void init(HttpServletRequest request) throws ApplicationException {
    	SessionHelper sessionHelper = new SessionHelper(request);
    	NameValuePair[] planIdArr = sessionHelper.getPlanIdArray();
    	setPlanNameList(planIdArr);

    	activeService = sessionHelper.getServicesToAccess();
    	if(Constants.BOTH_PARTS.equals(partName))
    		partName = activeService;

    	setDiscrpTypeList(MasterManager.getDiscrpArrWrkQ(partName));
    	setDiscStatusArray(MasterManager.getDiscrpStatusArr());
    	
    }
	/**
	 * @return Returns the pageType.
	 */
	public String getPageType() {
		return pageType;
	}
	/**
	 * @param pageType The pageType to set.
	 */
	public void setPageType(String pageType) {
		this.pageType = pageType;
	}
	public String getActiveService() {
		return activeService;
	}
	public void setActiveService(String activeService) {
		this.activeService = activeService;
	}
	/**
	 * @return Returns the criteriaAvailable.
	 */
	public String getCriteriaAvailable() {
		return criteriaAvailable;
	}
	/**
	 * @param criteriaAvailable The criteriaAvailable to set.
	 */
	public void setCriteriaAvailable(String criteriaAvailable) {
		this.criteriaAvailable = criteriaAvailable;
	}
	
	private String subWorkMenu;



	/**
	 * @return the subWorkMenu
	 */
	public String getSubWorkMenu() {
		return subWorkMenu;
	}
	/**
	 * @param subWorkMenu the subWorkMenu to set
	 */
	public void setSubWorkMenu(String subWorkMenu) {
		this.subWorkMenu = subWorkMenu;
	}
	private String searchcomment;



	/**
	 * @return the searchcomment
	 */
	public String getSearchcomment() {
		return searchcomment;
	}
	/**
	 * @param searchcomment the searchcomment to set
	 */
	public void setSearchcomment(String searchcomment) {
		this.searchcomment = searchcomment;
	}
	/**
	 * @return the reassignedTo
	 */
	public String getReassignedTo() {
		return reassignedTo;
	}
	/**
	 * @param reassignedTo the reassignedTo to set
	 */
	public void setReassignedTo(String reassignedTo) {
		this.reassignedTo = reassignedTo;
	}
	/**
	 * @return the reassignComment
	 */
	public String getReassignComment() {
		return reassignComment;
	}
	/**
	 * @param reassignComment the reassignComment to set
	 */
	public void setReassignComment(String reassignComment) {
		this.reassignComment = reassignComment;
	}
	
	private String selectedIndexes;


	/**
	 * @return the selectedIndexes
	 */
	public String getSelectedIndexes() {
		System.out.println("in getter of selectedIndex"+selectedIndexes);
		return selectedIndexes;
	}
	/**
	 * @param selectedIndexes the selectedIndexes to set
	 */
	public void setSelectedIndexes(String selectedIndexes) {
		System.out.println("in setter of selectedIndex"+selectedIndexes);
		this.selectedIndexes = selectedIndexes;
	}
	private String updateMessage;

	/**
	 * @return the updateMessge
	 */
	public String getUpdateMessage() {
		return updateMessage;
	}
	/**
	 * @param updateMessage the updateMessage to set
	 */
	public void setUpdateMessage(String updateMessage) {
		this.updateMessage = updateMessage;
	}
	
	
	private String autoAssignDisc;
	private String autoAssignedTo;



	/**
	 * @return the autoAssignDisc
	 */
	public String getAutoAssignDisc() {
		return autoAssignDisc;
	}
	/**
	 * @param autoAssignDisc the autoAssignDisc to set
	 */
	public void setAutoAssignDisc(String autoAssignDisc) {
		this.autoAssignDisc = autoAssignDisc;
	}
	/**
	 * @return the autoAssignedTo
	 */
	public String getAutoAssignedTo() {
		return autoAssignedTo;
	}
	/**
	 * @param autoAssignedTo the autoAssignedTo to set
	 */
	public void setAutoAssignedTo(String autoAssignedTo) {
		this.autoAssignedTo = autoAssignedTo;
	}
private int WRKQTotalRec;
private int WRKQTotalPages;



/**
 * @return the wRKQTotalRec
 */
public int getWRKQTotalRec() {
	return WRKQTotalRec;
}
/**
 * @param wRKQTotalRec the wRKQTotalRec to set
 */
public void setWRKQTotalRec(int wRKQTotalRec) {
	WRKQTotalRec = wRKQTotalRec;
}
/**
 * @return the wRKQTotalPages
 */
public int getWRKQTotalPages() {
	return WRKQTotalPages;
}
/**
 * @param wRKQTotalPages the wRKQTotalPages to set
 */
public void setWRKQTotalPages(int wRKQTotalPages) {
	WRKQTotalPages = wRKQTotalPages;
}
private String defaultComment;



/**
 * @return the defaultComment
 */
public String getDefaultComment() {
	return defaultComment;
}
/**
 * @param defaultComment the defaultComment to set
 */
public void setDefaultComment(String defaultComment) {
	this.defaultComment = defaultComment;
}

private String selectedPageNo;



public String getSelectedPageNo() {
	return selectedPageNo;
}
public void setSelectedPageNo(String selectedPageNo) {
	this.selectedPageNo = selectedPageNo;
}


	
}
