package com.ps.mss.web.actions;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.mss.framework.Constants;
import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EEMCobFlowService;
import com.ps.mss.businesslogic.EEMTimersService;
import com.ps.mss.dao.model.EEMCobFlowVO;
import com.ps.mss.dao.model.EMTimersSearchVO;
import com.ps.mss.dao.model.EMTimersVO;
import com.ps.mss.db.DbConn;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.manager.EEMManager;
import com.ps.mss.model.EEMContext;
import com.ps.mss.model.Pagination;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.forms.EEMCobFlowForm;
import com.ps.mss.web.forms.EEMForm;
import com.ps.mss.web.forms.EEMTimersForm;
import com.ps.mss.web.helper.EEMCobHelper;
import com.ps.mss.web.helper.EEMTimersHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.web.util.EEMSwitchUtil;

public class EEMCobAction extends Action {
	private static Logger logger = LoggerFactory.getLogger(EEMCobAction.class);
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		try {
			EEMForm eemForm = (EEMForm) form;
			String method = eemForm.getMethod();
			
			
			// use the default DB for security check
			conn = DbConn.getConnection();
			SessionHelper sessionHelper = new SessionHelper(request);
			String errorMsg = sessionHelper.validateUser(conn);
			if (errorMsg != null) {
				request.setAttribute("Msg", "Login Has Timed Out");
				throw new Exception(errorMsg);
			}
			
			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			EEMContext context = EEMManager.getContext(sessionHelper.getSession());
			String selectedMenu = context.getSelectedMenu();
			eemForm.setMessage(null);
			
			if ("switchMenu".equals(method) || "".equals(method)) {
				logger.info(LoggerConstants.methodEndLevel());
				return EEMSwitchUtil.switchMenu( mapping, conn, context,  form, eemForm,  sessionHelper,  request,  response);			
			}
			else if (EEMConstants.MENU_COB.equals(selectedMenu)) {
				
				if (eemForm instanceof EEMCobFlowForm) {
				
						EEMCobHelper.setCobFormList(
								(EEMCobFlowForm) eemForm, sessionHelper);
				}
			 if ("cobFlowSearch".equals(method)){
				 logger.info(LoggerConstants.methodEndLevel());
			 return eemCobSearch(conn, sessionHelper, context,
							mapping, eemForm, request);
			 }

				else if("cobFlowUpdate".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemCobUpdate(conn, sessionHelper, context, mapping,form, request);
				}
				
				else{
					context.setSelectedMenu(EEMConstants.MENU_COB);	
					logger.info(LoggerConstants.methodEndLevel());
					return mapping.findForward(EEMConstants.EEM_COB_WF);
				}
			}
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward("eemError");
		}catch(Exception e){		
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward("eemError");	
	}
	
	private ActionForward eemCobSearch(Connection conn,
		SessionHelper sessionHelper, EEMContext context,
		ActionMapping mapping, ActionForm form, HttpServletRequest request)
		throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
	logger.debug("Timer Search : Begin : ");  
//	logger.info("Timer Search : Begin : ");  

	EEMCobFlowForm eemCobForm = (EEMCobFlowForm) form;
	EEMCobFlowVO filterVO = context.getCobFlowVO();
	EEMCobHelper.setFormToVO(eemCobForm, filterVO, sessionHelper);

	String custId = sessionHelper.getMfId();

	// Get the form fields
	EEMCobFlowService service = context.getCobService();
	filterVO = service.getSearchList(conn, filterVO, "",
			"first",custId);
	if(filterVO !=null )
		EEMCobHelper.setVOToForm(filterVO, eemCobForm, sessionHelper);
	logger.info("Timer Search : End : ");  
	eemCobForm.setMethod("");
	context.setSelectedMenu(EEMConstants.MENU_COB);	
	logger.info(LoggerConstants.methodEndLevel());
	return mapping.findForward(EEMConstants.EEM_COB_WF);
	}

	private ActionForward eemCobUpdate(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)
			throws ApplicationException, SQLException{
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("Timer Update: Begin : ");  
//		logger.info("Timer Update: Begin : ");  
		EEMCobFlowForm eemCobForm = (EEMCobFlowForm) form;
		EEMCobFlowVO filterVO = context.getCobFlowVO();
		String custId = sessionHelper.getMfId();
		EEMCobHelper.setFormToVO(eemCobForm, filterVO, sessionHelper);		
		// Get the form fields                                                                                             
		EEMCobFlowService service = context.getCobService();
		boolean update = service.cobFlowUpdate(conn, filterVO, "", custId);
		if(update){
			eemCobForm.setMessage("Updated Succesfully");
			
		}
		else{
			eemCobForm.setMessage("Update Failed");
		}

		EEMCobHelper.setVOToForm(filterVO, eemCobForm, sessionHelper);
		logger.info("Timer Update: End : ");  
		eemCobForm.setMethod("");
		context.setSelectedMenu(EEMConstants.MENU_COB);	
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_COB_WF);
		
	}

}
