package com.ps.mss.web.process;

import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.mss.framework.McaidReconConstants;
import com.ps.mss.manager.McaidManagerFactory;
import com.ps.mss.manager.McaidReconAbsManager;
import com.ps.mss.model.McaidReconAnomVO;
import com.ps.mss.model.McaidReconContext;
import com.ps.mss.model.McaidReconDiscVO;
import com.ps.mss.model.McaidReconPaymentVO;
import com.ps.mss.web.forms.McaidReconAnomForm;
import com.ps.mss.web.forms.McaidReconBaseForm;
import com.ps.mss.web.forms.McaidReconDiscForm;
//import com.ps.mss.web.forms.McaidReconFCLOForm;
import com.ps.mss.web.forms.McaidReconFileForm;
import com.ps.mss.web.forms.McaidReconPaymentForm;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.util.StringUtil;

//common class for all states
public class McaidReconProcess {
	private static Logger logger = LoggerFactory.getLogger(McaidReconProcess.class);
	public McaidReconProcess(){}
	
	private McaidReconAbsManager getManagerInstance(SessionHelper sessionHelper){
		return McaidManagerFactory.getReconStateManager( (String)sessionHelper.getAttribute(McaidReconConstants.USER_STATE) );		
	}//getManagerInstance()

	
	
//***********************************************************************************
	
	//common method for all states
	public String initDisc(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconDiscForm mcaidDiscForm, HttpServletRequest request){
		String mapping  = "";
		
		McaidReconAbsManager manager = getManagerInstance(sessionHelper);
		if(mcaidDiscForm.getSubMenu() != null && mcaidDiscForm.getSubMenu().equals(McaidReconConstants.SUBMENU_DISC_SUMMARY)){
			logger.info("DISPLAYING BACK DISC_SUMMARY");	
			McaidReconAnomVO discAnomVO = context.getDiscAnamolyVO();
			mapping  = manager.setDiscAnomSummDataVOToForm(discAnomVO,mcaidDiscForm, sessionHelper.getMfId());
		}
		if(mcaidDiscForm.getSubMenu() != null && mcaidDiscForm.getSubMenu().equals(McaidReconConstants.SUBMENU_DISC_DASHBOARD_DETAIL)){
			
			//mapping  = manager.discInitialization(conn, sessionHelper, context, mcaidDiscForm, request);
			mapping = "NMmcaidDiscDetail";
			mcaidDiscForm.setSubMenu(McaidReconConstants.SUBMENU_DISC_DASHBOARD_DETAIL);
		}
		//IFOX-00407694-FCLO/WRTO Changes: start
		if(mcaidDiscForm.getSubMenu() != null && mcaidDiscForm.getSubMenu().equals(McaidReconConstants.SUBMENU_DISC_FORCE_CLOSE)){
			mcaidDiscForm.setSubMenu(McaidReconConstants.SUBMENU_DISC_FORCE_CLOSE);
		}
		//IFOX-00407694-FCLO/WRTO Changes: end
		else{
			mapping  = manager.discInitialization(conn, sessionHelper, context, mcaidDiscForm, request);
			mcaidDiscForm.setSubMenu(McaidReconConstants.SUBMENU_DISC_DASHBOARD);
		}
		
		
		return mapping;
	}//initDisc()
		
	
	
	//common method for all Files
	public String initFile(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconFileForm mcaidFileForm, HttpServletRequest request){
		String mapping  = "";
		
		McaidReconAbsManager manager = getManagerInstance(sessionHelper);
		mapping  = manager.fileInitialization(conn, sessionHelper, context, mcaidFileForm, request);
		//mcaidDiscForm.setSubMenu(McaidReconConstants.SUBMENU_DISC_DASHBOARD);
		
		//mapping = "NMmcaidFileInventory";
		
		return mapping;
	}//initFile()
		
	
	
	public String initPayment(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconPaymentForm mcaidPaymentForm, HttpServletRequest request){
		String mapping  = "";
		McaidReconAbsManager manager = getManagerInstance(sessionHelper);
		if(mcaidPaymentForm.getSubMenu() != null && mcaidPaymentForm.getSubMenu().equals(McaidReconConstants.SUBMENU_PAYMENT_SUMMARY)){
			logger.debug("DISPLAYING BACK PAYMENT_SUMMARY");
			McaidReconPaymentVO paymentVO = context.getPaymentVO();	
			/*mcaidPaymentForm.setMcaidPymntSummLst(paymentVO.getMcaidPymntSummLst());
			mcaidPaymentForm.setMcaidPymntSummDetailLst(paymentVO.getMcaidPymntSummDetailLst());*/
			manager.setPaySummDataVOtoForm( mcaidPaymentForm, paymentVO,sessionHelper.getMfId());
			mapping  = "ILmcaidPaymentSummary";			
		}else{
			mapping  = manager.paymentInitialization(conn, sessionHelper, context, mcaidPaymentForm, request);
			mcaidPaymentForm.setSubMenu(McaidReconConstants.SUBMENU_PAYMENT_DASHBOARD);
		}
		return mapping;
	}//initPayment()
	
		
	
	
	public String initAnamoly(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconAnomForm mcaidAnomForm, HttpServletRequest request){
		String mapping  = "";
		McaidReconAbsManager manager = getManagerInstance(sessionHelper);
		McaidReconAnomVO anomVO = context.getAnamolyVO();
		if(mcaidAnomForm.getSubMenu() != null && mcaidAnomForm.getSubMenu().equals(McaidReconConstants.SUBMENU_ANOM_SUMMARY)){
			logger.info("DISPLAYING BACK ANOMALY_SUMMARY");	
			
			mapping = manager.setAnomSummDataVOtoForm( mcaidAnomForm, anomVO,sessionHelper.getMfId());
						
		}else{	
		if(mcaidAnomForm.getSubMenu() != null && mcaidAnomForm.getSubMenu().equals(McaidReconConstants.SUBMENU_ANOM_DASHBOARD_DETAIL)){
			//mapping  = manager.discInitialization(conn, sessionHelper, context, mcaidDiscForm, request);
			if(mcaidAnomForm.getMethod().equals(McaidReconConstants.DISC_SUMM_OPT)){ 
				/*mapping = manager.discSummDetailSearch(conn, sessionHelper, context, mcaidAnomForm, request);	*/
			}else{
			logger.info(" in detaulsss=== mapping :: "+mapping);
			mcaidAnomForm.setSubMenu(McaidReconConstants.SUBMENU_ANOM_DASHBOARD_DETAIL);
			mapping = manager.setAnomSummDataVOtoForm( mcaidAnomForm, anomVO,sessionHelper.getMfId());
			mapping = manager.getAnomSummDetailsData(conn, sessionHelper, context, mcaidAnomForm, "first", "DETAILS");
			}
			
			mapping = "ILmcaidAnomDetail";
							
		}
			mapping = manager.setAnomSummDataVOtoForm( mcaidAnomForm, anomVO,sessionHelper.getMfId());
		 mapping  = manager.anomalyInitialization(conn, sessionHelper, context, mcaidAnomForm, request);
		 mcaidAnomForm.setSubMenu(McaidReconConstants.SUBMENU_ANOM_DASHBOARD);
		}
		return mapping;
	}//initAnamoly()
	
	
//***********************************************************************************

	public String discrepancyMenu(Connection conn, SessionHelper sessionHelper, McaidReconContext context, ActionForm form, HttpServletRequest request, HttpServletResponse response, String method) {
		String mappingTarget = "error";
		McaidReconDiscForm mcaidDiscForm = (McaidReconDiscForm)form;
		McaidReconAbsManager manager = getManagerInstance(sessionHelper);
		McaidReconAnomVO discVO = context.getDiscAnamolyVO();
		logger.debug(" manager--"+manager.getClass());
		logger.debug("McaidReconProcess.discrepancyMenu():::subMenu:::"+mcaidDiscForm.getSubMenu());
		String mfId = sessionHelper.getMfId();
		
		if(request.getParameter("method") != null && request.getParameter("method").equals("discPrint")){
			logger.info("In DISC PRINT");
			String printSubMenu = request.getParameter("printSubMenu");
			String pageRange = request.getParameter("printPageRange");
			String printOption = request.getParameter("printOpt");
			logger.debug("printSubMenu="+printSubMenu+" :: pageRange="+pageRange+" :: printOption="+printOption);
			
			mappingTarget = manager.printMcaidDisc(conn, sessionHelper, context, request, response, mcaidDiscForm, printOption, printSubMenu, pageRange);
			
			return mappingTarget;			
		}
		
		if(mcaidDiscForm.getSubMenu().equals("") || mcaidDiscForm.getSubMenu().equals(StringUtil.nonNullTrim((McaidReconConstants.SUBMENU_DISC_DASHBOARD)))){
			logger.info("HI, I AM IN DISC DASHBOARD");			
			if(mcaidDiscForm.getMethod().equals(McaidReconConstants.DISC_DASH_OPT)){ 
				mappingTarget = manager.discDashboardSearch(conn, sessionHelper, context, mcaidDiscForm, request);	
			}
			
			else{
				mappingTarget = manager.discDsbSubMenuSelect(conn, sessionHelper, context, mcaidDiscForm, request);	
			}
			
		}else if(mcaidDiscForm.getSubMenu().equals(McaidReconConstants.SUBMENU_DISC_SUMMARY)){
			logger.info("HI, I AM IN DISC SUMMARY");
			if(mcaidDiscForm.getMethod().equals(McaidReconConstants.SELECT_DISC_SUMM_LIST)){
				discVO.setDiscrpDetailsTotalLst(null);
				mappingTarget = manager.getDiscSummListData(conn, sessionHelper, context, mcaidDiscForm, "det", "DASHBOARD");
			}				
			else if(mcaidDiscForm.getMethod().equals(McaidReconConstants.ANOM_SUMM_LIST_PAGE_FIRST)){
				mappingTarget = manager.getDiscSummListData(conn, sessionHelper, context, mcaidDiscForm, "first", null);
			}
			else if(mcaidDiscForm.getMethod().equals(McaidReconConstants.ANOM_SUMM_LIST_PAGE_NEXT)){
				mappingTarget = manager.getDiscSummListData(conn, sessionHelper, context, mcaidDiscForm, "next", null);
			}
			else if(mcaidDiscForm.getMethod().equals(McaidReconConstants.ANOM_SUMM_LIST_PAGE_PREV)){
				mappingTarget = manager.getDiscSummListData(conn, sessionHelper, context, mcaidDiscForm, "prev", null);
			}
			else if(mcaidDiscForm.getMethod().equals(McaidReconConstants.SELECT_DISC_SUMM_DETAILS)){
				mappingTarget = manager.getDiscSummDetailData(conn, sessionHelper, context, discVO, mcaidDiscForm, mcaidDiscForm.getSummSrchListRowSelect());
			}
			else if(mcaidDiscForm.getMethod().equals(McaidReconConstants.SELECT_DISC_SUMM_STATUS_UPDATE)){
				mappingTarget = manager.updateDiscStatus(conn, sessionHelper, context, mcaidDiscForm);
			}
			else if(mcaidDiscForm.getMethod().equals(McaidReconConstants.SUMM_GO_OPT)){
				discVO.setDiscrpDetailsTotalLst(null);
				mappingTarget = manager.getDiscSummListData(conn, sessionHelper, context, mcaidDiscForm, "go", "SEARCH");
			}else if(mcaidDiscForm.getMethod().equals(McaidReconConstants.VIEW_PAYMENT_DETAILS)){
				logger.debug("HI, I AM IN Disc view payment"+mcaidDiscForm.getPbpId());
				mappingTarget = manager.getViewPaymentDetails(conn, sessionHelper, context, mcaidDiscForm);
				request.setAttribute(McaidReconConstants.FORM_DISC, mcaidDiscForm);
			}
			else if(mcaidDiscForm.getMethod().equals(McaidReconConstants.VIEW_RECONCILIATION)){
					 mappingTarget = manager.getViewReconciliation(conn, sessionHelper, context, mcaidDiscForm);
			}
			// Added for Extract All Records Changes : start
			else if (mcaidDiscForm.getMethod().equals(McaidReconConstants.DISC_DET_EXTRACTALL)){
				mappingTarget = manager.extractAllRecords(conn, sessionHelper, context, mcaidDiscForm, "disc", null);
			}
			// Added for Extract All Records Changes : end
			else{
				McaidReconAnomVO discAnomVO = context.getDiscAnamolyVO();
				mappingTarget = manager.setDiscAnomSummDataVOToForm(discAnomVO,mcaidDiscForm, sessionHelper.getMfId());
			}			
			//mappingTarget = "ILmcaidDiscSummary";
			
	}else if(mcaidDiscForm.getSubMenu() != null && mcaidDiscForm.getSubMenu().equals(McaidReconConstants.SUBMENU_DISC_DASHBOARD_DETAIL)){
		
		//mapping  = manager.discInitialization(conn, sessionHelper, context, mcaidDiscForm, request);
		if(mcaidDiscForm.getMethod().equals(McaidReconConstants.DISC_SUMM_OPT)){ 
			mappingTarget = manager.discSummDetailSearch(conn, sessionHelper, context, mcaidDiscForm, request);	
		}else{
		logger.debug(" in detaulsss=== mapping :: "+mappingTarget);
		mcaidDiscForm.setSubMenu(McaidReconConstants.SUBMENU_DISC_DASHBOARD_DETAIL);
		mappingTarget = manager.getDiscSummDetailsData(conn, sessionHelper, context, mcaidDiscForm, "first", "DETAILS");
		}
		
		mappingTarget = "NMmcaidDiscDetail";
	//IFOX-00407694-FCLO/WRTO Changes: start
	}else if(mcaidDiscForm.getSubMenu() != null && mcaidDiscForm.getSubMenu().equals(McaidReconConstants.SUBMENU_DISC_FORCE_CLOSE)){
		System.out.println("HI, I AM IN FORCE CLOSE!");
		if (mcaidDiscForm.getMethod().equals(McaidReconConstants.FCLO_GO_OPT)){
			mappingTarget = manager.discFcloSearch(conn, sessionHelper, context, mcaidDiscForm, request);
		}
		else if (mcaidDiscForm.getMethod().equals(McaidReconConstants.DISC_FCLO_UPDATE)){
			 mappingTarget = manager.updateFcloStatus(conn, sessionHelper, context, mcaidDiscForm);
		}
		else{
			mcaidDiscForm.setSubMenu(McaidReconConstants.SUBMENU_DISC_FORCE_CLOSE);
			mappingTarget = manager.fcloInitialization(conn, sessionHelper, context, mcaidDiscForm, request);
		}
		
	}
	//IFOX-00407694-FCLO/WRTO Changes: end	
	else{
		mappingTarget = manager.discDsbSubMenuSelect(conn, sessionHelper, context, mcaidDiscForm, request);				
	}
	
		
		return mappingTarget;
	}//discrepancyMenu()
	
	
	
	
	
	
	public String paymentMenu(Connection conn, SessionHelper sessionHelper, McaidReconContext context, ActionForm form, HttpServletRequest request,HttpServletResponse response, String method) {
		String mappingTarget = "error";
		McaidReconPaymentForm mcaidPaymentForm = (McaidReconPaymentForm)form;
		McaidReconAbsManager manager = getManagerInstance(sessionHelper);
		String mfId = sessionHelper.getMfId();
		
		if(request.getParameter("method") != null && request.getParameter("method").equals("paymentPrint")){
			logger.info("In PAYMENT PRINT");
			String printSubMenu = request.getParameter("printSubMenu");
			String pageRange = request.getParameter("printPageRange");
			String printOption = request.getParameter("printOpt");
			logger.info("printSubMenu="+printSubMenu+" :: pageRange="+pageRange+" :: printOption="+printOption);
			
			mappingTarget = manager.printMcaidPayment(conn, sessionHelper, context, request, response, mcaidPaymentForm, printOption, printSubMenu, pageRange);
			
			return mappingTarget;			
		}
		if(null == mcaidPaymentForm.getSubMenu() || mcaidPaymentForm.getSubMenu().equals("") || mcaidPaymentForm.getSubMenu().equals(McaidReconConstants.SUBMENU_PAYMENT_DASHBOARD)){
			logger.info("HI, I AM IN PAYMENT DASHBOARD");
			if(mcaidPaymentForm.getMethod().equals(McaidReconConstants.SELECT_PAYMENT_DASHBOARD_SEARCH)){				
				mappingTarget = manager.getpaymentDashboardSearch(conn, sessionHelper, context, mcaidPaymentForm);
			}
			else{
				mappingTarget = manager.paymentDsbSubMenuSelect(conn, sessionHelper, context, mcaidPaymentForm, request);			
			}
			//mappingTarget = "ILmcaidPayment";
		}else if(mcaidPaymentForm.getSubMenu().equals(McaidReconConstants.SUBMENU_PAYMENT_SUMMARY)){
			logger.info("HI, I AM IN PAYMENT SUMMARY");			
			if(mcaidPaymentForm.getMethod().equals(McaidReconConstants.SELECT_PAYMENT_SUMM_DATA)){
				mappingTarget = manager.getpaymentSummData(conn, sessionHelper, context, mcaidPaymentForm);
			}
			else if(mcaidPaymentForm.getMethod().equals(McaidReconConstants.SELECT_PAYMENT_SEARCH)){				
				mappingTarget = manager.getpaymentSearch(conn, sessionHelper, context, mcaidPaymentForm);
			}			
			else if(mcaidPaymentForm.getMethod().equals(McaidReconConstants.SELECT_PAYMENT_SUMM_DETAILS)){
				mappingTarget = manager.getpaymentSummDetails(conn, sessionHelper, context, mcaidPaymentForm);
			}
			else if(mcaidPaymentForm.getMethod().equals(McaidReconConstants.SELECT_PAY_SUMM_MEDCAID_DET)){
				mappingTarget = manager.getpaymentSummMedicaids(conn, sessionHelper, context, mcaidPaymentForm, "det");				
			}			
			/*Payment Summary pagination - Start*/
			else if(mcaidPaymentForm.getMethod().equals(McaidReconConstants.PAY_SUMM_MEDCAID_PAGE_FIRST)){
				mappingTarget = manager.getpaymentSummMedicaids(conn, sessionHelper, context, mcaidPaymentForm, "first");
			}
			else if(mcaidPaymentForm.getMethod().equals(McaidReconConstants.PAY_SUMM_MEDCAID_PAGE_NEXT)){
				mappingTarget = manager.getpaymentSummMedicaids(conn, sessionHelper, context, mcaidPaymentForm, "next");
			}
			else if(mcaidPaymentForm.getMethod().equals(McaidReconConstants.PAY_SUMM_MEDCAID_PAGE_PREV)){
				mappingTarget = manager.getpaymentSummMedicaids(conn, sessionHelper, context, mcaidPaymentForm, "prev");
			}
			/*Payment Summary pagination - End*/
			else{
				McaidReconPaymentVO paymentVO = context.getPaymentVO();	
				mappingTarget = manager.setPaySummDataVOtoForm( mcaidPaymentForm, paymentVO,mfId);
			}
			
			//mappingTarget = "ILmcaidPaymentSummary";
		}else{
			mappingTarget = manager.paymentDsbSubMenuSelect(conn, sessionHelper, context, mcaidPaymentForm, request);			
		}
		
		return mappingTarget;
	}//paymentMenuSelect
	
	
	
	
	
	
	
	
	public String anamolyMenu(Connection conn, SessionHelper sessionHelper, McaidReconContext context, ActionForm form, HttpServletRequest request,HttpServletResponse response, String method) {
		String mappingTarget = "error";
		McaidReconAnomForm mcaidAnomForm = (McaidReconAnomForm)form;
		McaidReconAbsManager manager = getManagerInstance(sessionHelper);
		McaidReconAnomVO anomVO = context.getAnamolyVO();
		
		
		
		if(request.getParameter("method") != null && request.getParameter("method").equals("anomPrint")){
			logger.info("In ANOM PRINT");
			String printSubMenu = request.getParameter("printSubMenu");
			String pageRange = request.getParameter("printPageRange");
			String printOption = request.getParameter("printOpt");
			logger.debug("printSubMenu="+printSubMenu+" :: pageRange="+pageRange+" :: printOption="+printOption);
			
			mappingTarget = manager.printMcaidAnom(conn, sessionHelper, context, request, response, mcaidAnomForm, printOption, printSubMenu, pageRange);
			
			return mappingTarget;			
		}
		
		if(mcaidAnomForm.getSubMenu().equals("") || mcaidAnomForm.getSubMenu().equals(McaidReconConstants.SUBMENU_ANOM_DASHBOARD)){
				logger.info("HI, I AM IN ANOMALY DASHBOARD");
				if(mcaidAnomForm.getMethod().equals(McaidReconConstants.ANOM_DASH_OPT)){ 
					mappingTarget = manager.AnomDashboardSearch(conn, sessionHelper, context, mcaidAnomForm, request);	
				}
				
				else{
				mappingTarget = manager.anomDsbSubMenuSelect(conn, sessionHelper, context, mcaidAnomForm, request);			
				}
				//mappingtarget = "ILmcaidAnom";
		}else if(mcaidAnomForm.getSubMenu().equals(McaidReconConstants.SUBMENU_ANOM_SUMMARY)){
				logger.info("HI, I AM IN ANOMALY SUMMARY");
				if(mcaidAnomForm.getMethod().equals(McaidReconConstants.SELECT_ANOM_SUMM_LIST)){
					anomVO.setSummAnomTotalLst(null);
					mappingTarget = manager.getAnomSummListData(conn, sessionHelper, context, mcaidAnomForm, "det","DASHBOARD");
				}				
				else if(mcaidAnomForm.getMethod().equals(McaidReconConstants.ANOM_SUMM_LIST_PAGE_FIRST)){
					mappingTarget = manager.getAnomSummListData(conn, sessionHelper, context, mcaidAnomForm, "first",null);
				}
				else if(mcaidAnomForm.getMethod().equals(McaidReconConstants.ANOM_SUMM_LIST_PAGE_NEXT)){
					mappingTarget = manager.getAnomSummListData(conn, sessionHelper, context, mcaidAnomForm, "next",null);
				}
				else if(mcaidAnomForm.getMethod().equals(McaidReconConstants.ANOM_SUMM_LIST_PAGE_PREV)){
					mappingTarget = manager.getAnomSummListData(conn, sessionHelper, context, mcaidAnomForm, "prev",null);
				}
				else if(mcaidAnomForm.getMethod().equals(McaidReconConstants.SELECT_ANOM_SUMM_DETAILS)){
					mappingTarget = manager.getAnomSummDetailData(conn, sessionHelper, context, mcaidAnomForm, mcaidAnomForm.getSummSrchListRowSelect());
				}
				else if(mcaidAnomForm.getMethod().equals(McaidReconConstants.SELECT_ANOM_SUMM_STATUS_UPDATE)){
					mappingTarget = manager.updateAnamolyStatus(conn, sessionHelper, context, mcaidAnomForm);
				}else if(mcaidAnomForm.getMethod().equals(McaidReconConstants.SUMM_GO_OPT)){
					anomVO.setSummAnomTotalLst(null);
					mappingTarget = manager.getAnomSummListData(conn, sessionHelper, context, mcaidAnomForm, "go", "SEARCH");
				}
				else if(mcaidAnomForm.getMethod().equals(McaidReconConstants.VIEW_RECONCILIATION)){
					 mappingTarget = manager.getViewReconciliation(conn, sessionHelper, context, mcaidAnomForm);
				}else if(mcaidAnomForm.getMethod().equals(McaidReconConstants.VIEW_PAYMENT_DETAILS)){
						mappingTarget = manager.getViewPaymentDetailsForAnom(conn, sessionHelper, context, mcaidAnomForm);
						request.setAttribute(McaidReconConstants.FORM_ANOM, mcaidAnomForm);
				}
				// Added for Extract All Records Changes : start
				else if (mcaidAnomForm.getMethod().equals(McaidReconConstants.DISC_DET_EXTRACTALL)){
					mappingTarget = manager.extractAllAnomRecords(conn, sessionHelper, context, mcaidAnomForm, "anom", null);
				}
				// Added for Extract All Records Changes : end
				else{
					//McaidReconAnomVO anomVO = context.getAnamolyVO();	
					mappingTarget = manager.setAnomSummDataVOtoForm( mcaidAnomForm, anomVO,sessionHelper.getMfId());
				}
				
				//mappingtarget = "ILmcaidAnomSummary";
		
			
			 
			
		}else if(mcaidAnomForm.getSubMenu() != null && mcaidAnomForm.getSubMenu().equals(McaidReconConstants.SUBMENU_ANOM_DASHBOARD_DETAIL)){
			
			//mapping  = manager.discInitialization(conn, sessionHelper, context, mcaidDiscForm, request);
			if(mcaidAnomForm.getMethod().equals(McaidReconConstants.ANOM_SUMM_OPT)){ 
				mappingTarget = manager.anomSummDetailSearch(conn, sessionHelper, context, mcaidAnomForm, request);
			}else{
			logger.debug(" in detaulsss=== mapping :: "+mappingTarget);
			mcaidAnomForm.setSubMenu(McaidReconConstants.SUBMENU_ANOM_DASHBOARD_DETAIL);
			mappingTarget = manager.getAnomSummDetailsData(conn, sessionHelper, context, mcaidAnomForm, "first", "DETAILS");
			}
			
			mappingTarget = "NMmcaidAnomDetail";
		}
		else{
			mappingTarget = manager.anomDsbSubMenuSelect(conn, sessionHelper, context, mcaidAnomForm, request);		
		}
		
		return mappingTarget;
	}//anamolyMenuSelect
	
	

	public String fileMenu(Connection conn, SessionHelper sessionHelper, McaidReconContext context, ActionForm form, HttpServletRequest request,HttpServletResponse response, String method) {
		String mappingTarget = "error";
		McaidReconFileForm mcaidFileForm = (McaidReconFileForm)form;
		McaidReconAbsManager manager = getManagerInstance(sessionHelper);
		String mfId = sessionHelper.getMfId();
		mcaidFileForm.setMethod(StringUtil.nonNullTrim(request.getParameter("method")));
		
		if(request.getParameter("method") != null && request.getParameter("method").equals("filePrint")){
			logger.info("In File PRINT");
			String printSubMenu = request.getParameter("printSubMenu");
			String pageRange = request.getParameter("printPageRange");
			String printOption = request.getParameter("printOpt");
			logger.debug("printSubMenu="+printSubMenu+" :: pageRange="+pageRange+" :: printOption="+printOption);
			
			mappingTarget = manager.printMcaidFile(conn, sessionHelper, context, request, response, mcaidFileForm, printOption, printSubMenu, pageRange);
			
			return "NMmcaidFileInventory";			
		}
		
		if(mcaidFileForm.getMethod().equals("goFileSearch")){				
			mappingTarget = manager.getFileListSearch(conn, sessionHelper, context, mcaidFileForm, "first");
		}	
		else if(mcaidFileForm.getMethod().equals("filesLstPageFirst")){
			mappingTarget = manager.getFileListSearch(conn, sessionHelper, context, mcaidFileForm, "first");
		}
		else if(mcaidFileForm.getMethod().equals("filesLstPageNext")){
			mappingTarget = manager.getFileListSearch(conn, sessionHelper, context, mcaidFileForm, "next");
		}
		else if(mcaidFileForm.getMethod().equals("filesLstPagePrev")){
			mappingTarget = manager.getFileListSearch(conn, sessionHelper, context, mcaidFileForm, "prev");
		}
		
		return mappingTarget;
	}//paymentMenuSelect
	
	
	
	
	
	
	
	
	
	
	
	
}//class
	