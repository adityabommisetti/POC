/*
 * $Id: EEMApplForm.java,v 1.15 2014/12/10 10:04:10 praveen Exp $
 */
package com.ps.mss.web.forms;

import java.util.List;

import com.ps.mss.dao.model.EmApplLepAttestInfoVO;
import com.ps.mss.dao.model.EmLepSummaryVO;
import com.ps.mss.dao.model.EmMbrOevInfoVO;
import com.ps.mss.db.MBD;
import com.ps.text.DateFormatter;
import com.ps.util.DateUtil;
import com.ps.util.ListBoxItem;

import com.ps.mss.dao.model.LepPtnlUncovMthsVO;

/**
 * @author nenne.robert
 */
public class EEMApplForm extends EEMForm {

	//original application start
		private int orig;
	public int getOrig() {
		return orig;
	}
	public void setOrig(int orig) {
		this.orig = orig;
	}
	public int getOriginalButton() {
		return originalButton;
	}
	public void setOriginalButton(int originalButton) {
		this.originalButton = originalButton;
	}
	private int originalButton;
	private String frmtDate;
	private String customerId;
	private String customerNbr;
	private String elgOveride;
	
	/* Update checks */
	private String statusRFI;
	private String updateRec="N";
	private String isChanged="N";
	private String needMBDUpdate;
	private String lstUpdtAppl;
	private String lstUpdtPrimAddr;
	private String lstUpdtMailAddr;
	private String lstUpdtAuthAddr;
	private String lstUpdtAgent;
	private String lstUpdtOtherCov;
	private String lstUpdtAttest;
	private String lstUpdtPlan;
	private String lstUpdtOtherPlan;
	
    /* Search fields */
    private String searchHicNo;      
    private String searchLastName;   
    private String searchBirthDt;
    private String searchApplId;
    private String searchStatus;     

    private List lstSearch;
    private String visible="Y";
    
    /* Application type fields */
    private String applType;
    private List lstApplType;
    private String applId;          
    private String applDate;        
    private String applStatus;
    private String currStatus;
    private List lstApplStatus;
    private List lstUsrApplStatus;
    private String operId;
    private String applCategory="FRM";
    private List lstApplCategory;
    private String lstUpdtApplUser;
    private String createApplUser;
    private String createApplTime;
    
    /* Personal Information fields */
    private String mbrApplNo;
    private String mbrPrefix;
    private List lstPrefix;
    private String mbrFirstName;
    private String mbrMiddleName;
    private String mbrLastName;
    private String mbrHicNbr;
    private String dtLstChked = "00/00/0000";
    private String mbrId;
    private String altMbrId;
    private String mbrSsn;
    private String mbrRxId;
    private String mbrPhone;
    private String mbrBirthDt;
    private String mbrGender;
    private String mbrEmail;
    private String insCardName;
    private String mbrSuffix;
    
    private MBD mbd = new MBD();
    private String mbdState;
    private String mbdCounty;
    private String receiptDate;
    private String outOfArea;
    private String perAdd1;
    private String perAdd2;
    private String perAdd3;
    private String perCity;
    private String perState;
    private String perZip5;
    private String perZip4;
    private String perCounty;
    private String perPhone;
    private String perCell;
    private String perWorkPhone;
    private String perFax;
    
    private String mailFirstName;
    private String mailMiddleName;
    private String mailLastName;
    private String mailAdd1;
    private String mailAdd2;
    private String mailAdd3;
    private String mailCity;
    private String mailState;
    private String mailZip5;
    private String mailZip4;
    private String mailCounty;
    private String mailCountry;
    private String mailSuffix;
    
    private String emergName;
    private String emergPhone;
    private String emergRelation;
    private String email;
    
    private String billFirstName;
    private String billLastName;
    private String billMiddleName;
    private String billSuffix;
    
    private String stateCd;
    private List lstStates;
    private String countyCd;
    private List lstCounty;
    private String countryCd;
    private List lstCountry;
    private List lstCity;
    private String sourceCity;
    private String sourceZip5;
    private String sourceZip4;
    private String sourceState;
    private String sourceCounty;
    /* RX Info Enrolled / Enrolled in */
    private String currGroupName;
    private String currGroup;
    private String currProduct;
    private String currProdName;
    private String currPlan;
    private String currPbp;
    private String currSegment;
    private String currPymtAmt = "0";
    private String currPlanDesgn;
    
    private String enrollGroupName;
    private String enrollGroup;
    private String enrollProduct;
    private String enrollProdName;
    private String enrollPlan;
    private String enrollPbp;
    private String enrollSegment;
    private String enrollPymtAmt;
    private String enrollPlanDesgn;
    private String enrollEndDate;
    
    private String elcDerivedInd;
    
    private String searchGroup;
    private String searchProd;
	private String searchGroupId;
    private String searchProdId;
	private String searchZip5;
    private String searchZip4;
    private String searchPlan;
    private String searchPbp;
    private String searchSegment;
    
    private String searchOffCd;
    private String searchLocId;
    private String searchDocName;
    private String searchCurrPatnt;
 
	private List products;
    
    private String reqDtCov;
    private String language="ENG";
    private List lstLanguages;
    private String altCorrespondenceInd;
    private List lstAltCorrespondences;
    private String enrollSrceCd="B";
    private List lstEnrollSrce;
    private String pcpCode;
    private String pcpName;
    private String pcpOfficeCd;
    private String pcpOffCatCd;
    private String pcpCurrPatnt="N";
    private String pcpLocationId;
    
  
	
	private List lstPcpNames;
    private String sepReason;
    private List lstSepReasons;
    
    /* Medicare card information */
    private String partAEffDt;
    private String partBEffDt;
    private String partDEffDt;
    private String partAEffEndDt;
    private String partBEffEndDt; 
    // BEQ Short term solution --Start
    private String eligOverrideInd;
    // BEQ Short term solution --End
    
    /* Your Plan Premium */
    private String pwOption = "D";
    private List lstPWOptions;
    
    /* Questions to be answered */
    private String esrd = "N";
    private String pcoInd = "N";
    private String esrdStDt;
    private String esrdEndDt;
    private String dialysis = "N";
    private String drugCov = "N";
    private String otherCov;
    private String covId;
    private String groupNo;
    private String longTerm = "N";
    private String longTermStDt;
    private String longTermEndDt;
    private String nameInstitute;
    private String instPhoneNo;
    private String instStreet;
    private String stMedicaid = "N";
    private String medicaidStDt;
    private String medicaidEndDt;
    private String spouseWork = "N";
    private String covBin;
    private String covPcn;
    private String esrdChange;
    private String longTermChange;
    private String medicaidChange;
    private String medicaidId;
    
    private String healthPlanNews;
   /*  IFOX-00431133 -CMS Changes Start  */ 
    private String doYouWork = "N";
    private String emailOptIn = "N";
    
    /*  IFOX-00431133 -CMS Changes End  */ 
    
    private List lstInstitutes;
    private List lstPCO;
    /**
	 * Cambia_Election Logic---Start
	 */

	private String[] sepInd;
	private String[] sepQueNo;

	/**
	 * Cambia_Election Logic---End
	 */
    
    /* Attestation of Eligibility */
    private String electionType;
    private String electionDesc;
    private List lstElectionTypes;
    private String electionDt;
    private List lstSepExceptions;
    private List lstAttestation;
    private String[] sepException;
    private String[] attestDt;
    private String editOverride;
    
    /* Signature and Authorized representitive */
    private String signOnFile = " ";   //AAH CR-Start -426569 
    private String signDt;
    private String ovrrdSignDt;
    private String authRepFirstName;
    private String authRepMidName;
    private String authRepLastName;
    private String authRepStreet;
    private String authRepCity;
    private String authRepState;
    private String authRepZip5;
    private String authRepZip4;
    private String authRepPhone;
    private String authRepRelation;
    private List lstRelations;
    
    /* Broker, Agent, Company Sales Rep */
    private String commAgencyId;
    private List lstAgencyIds;
    private String commName;
    private String brokerType;
    private List lstAgentTypes;
    private String brokAgentId;
    private List lstBrokAgentIds;
    private String agentDt;
    private String brokerName;
    private String fieldAgentId;
    private List lstFldAgentIds;
    private String fieldName;
    private int agencySrchPageNbr;
    private String agencySrchPageType;
    private String agencySrchMove;
    
    /* Comments */
    private String comment;
    private String[] commentRows;
    private String[] insertRows;
    private List lstComments;
    
    private String createTime;
    private String createUser;
    private String updtTime;
    private String updtUser;
    
    //DupAppl-start
    private String appDuplicateCheck; 
    
    
    /**
	 * @return Returns the appDuplicateCheck.
	 */
	public String getAppDuplicateCheck() {
		return appDuplicateCheck;
	}
	/**
	 * @param appDuplicateCheck The appDuplicateCheck to set.
	 */
	public void setAppDuplicateCheck(String appDuplicateCheck) {
		this.appDuplicateCheck = appDuplicateCheck;
	}
	
	//end
    
    private String obc1TimerCheck;
	private String obc2TimerCheck;
	private String le21TimerCheck;
	private String obc3TimerCheck;
	
	public String getObc1TimerCheck() {
		return obc1TimerCheck;
	}
	public void setObc1TimerCheck(String obc1TimerCheck) {
		this.obc1TimerCheck = obc1TimerCheck;
	}
	public String getObc2TimerCheck() {
		return obc2TimerCheck;
	}
	public void setObc2TimerCheck(String obc2TimerCheck) {
		this.obc2TimerCheck = obc2TimerCheck;
	}
	public String getLe21TimerCheck() {
		return le21TimerCheck;
	}
	public void setLe21TimerCheck(String le21TimerCheck) {
		this.le21TimerCheck = le21TimerCheck;
	}
	public String getObc3TimerCheck() {
		return obc3TimerCheck;
	}
	public void setObc3TimerCheck(String obc3TimerCheck) {
		this.obc3TimerCheck = obc3TimerCheck;
	}
    

    private String beqCheck; //Added for IFOX-00364414

    
    private String subscriberId;
    
    private String isSubscriberIdRequired;
    
    /** Triple S BasePlus Migration START **/
    //TSA Changes :Start
    private String isSubscriberIdMandatory;
    //TSA Changes :End
    /** Triple S BasePlus Migration END **/
    
    
 // IFOX-00381706 - COB Fix CR Summacare - Start
    private String isInCmpltCOB;
 // IFOX-00381706 - COB Fix CR Summacare - End
 // Start IFOX-00397126
    private String mbrXrefNbr;
    
    
    
    public String getMbrXrefNbr() {
		return mbrXrefNbr;
	}
	public void setMbrXrefNbr(String mbrXrefNbr) {
		this.mbrXrefNbr = mbrXrefNbr;
	}
	// End IFOX-00397126
    /**
   	 * Cambia_Application Cancellation- Start 
   	 */
       
       /**
        * rejectButton : To check whether Application cancellation button is clicked or not
        */
       private boolean rejectButton;
       /**
        * reasonPDP : Holds the reason code for Application Cancellation
        */
       private String reasonPDP;
       /**
        * date : Holds the processed date
        */
   	private String date;
   /*	*//**
   	 * frmtDate : Holds the current date
   	 *//*
   	private String frmtDate;
   	*//**
   	 * btnClicked : Holds the value of the button
   	 *//*
   	private String btnClicked;*/
      /**
       * reasonList : Holds the reason for application cancellation
       */
        private List reasonList;
   	
   /**
   	 * Cambia_Application Cancellation- End 
   	 */
    
    /**
	 * UseCaseName 015_Highmark_SUC_Denials for Enrollment and Disenrollment -
	 * Start
	 */
	private String denialDate;
	private String denialDateFrmt;
	private String denialReasonCd;
	private List<ListBoxItem> applDenialReasons;
	private String btnClicked;
    
    
    
	  /**
     * Cambia_PRE-SET NOTES- Start
     */
     /**
      * preSetNoteList : Holds the List of the preset notes
      */
    private List preSetNoteList;
    /**
     * preSet : Holds the selected value from the dropdown
     */
 	private String preSet;
 	/**
 	 * radioCheck : Holds the value of the radio button
 	 */
 	private String radioCheck;
 	/**
 	 * ind : Holds the value of the button clicked
 	 */
 	private String ind;
 	/**
 	 * preSetDisplayState : Holds the value of the display of the screen
 	 */
 	private String preSetDisplayState;
 	private String preSetKeyValue;
 	/**
 	 * preSetNote : Holds the new preset note
 	 */
 	private String preSetNoteM;
 	/**
 	 * preSetNoteDesc : Holds the new preset note description
 	 */
 	private String preSetNoteDescr;
 	/**
 	 * preSetKey : Holds the index of the selected preset note
 	 */
 	private String preSetKey;
 	
    private String maxId;
    
    /**
     * Cambia_PRE-SET NOTES- End
     */   
    
    /**
     * Cambia_OEVProcess-Start
     */
       private String oevUpdtdate;
   	private boolean oevDateNext;
   	/**
   	 * oevInfo VO object for oev calls
   	 */
   	private EmMbrOevInfoVO oevInfo = new EmMbrOevInfoVO();
   	/**
   	 * oevRetInfo VO object for return calls
   	 */
   	private EmMbrOevInfoVO oevRetInfo = new EmMbrOevInfoVO();
   	/**
   	 * oevInfoChanged holds whether oev info updated
   	 */
   	private boolean oevInfoChanged;
   	/**
   	 * oevReturnInfoChanged holds whether return info updated
   	 */
   	private boolean oevReturnInfoChanged;
   	/**
   	 * oevDateCheck boolean check for date diff
   	 */
   	private boolean oevDateCheck;
   	/**
   	 * oevCheck boolean check for updation
   	 */
   	private boolean oevCheck;
   	/**
   	 * oevTimerCheck boolean check for oev timer
   	 */
   	private String oevTimerCheck = "false";

   	private boolean oev2TimerCheck;
   	/**
   	 * oevButton holds value for OEV button
   	 */
   	private String oevButton;
   	/**
   	 * oevAgentCheck holds value for valid agent details
   	 */
   	private boolean oevAgentCheck;

   	/**
   	 * oevCallStatusDrop holds values for oev call status
   	 */
   	private List oevCallStatusDrop;
   	/**
   	 * oevCallSubReasonDrop holds values for oev call subsetReason
   	 */
   	private List oevCallSubReasonDrop;
   	/**
   	 * oevCallAttempts holds oev calls data
   	 */
   	private List oevCallAttempts;
   	/**
   	 * oevCallStatus holds oev calls finished
   	 */
   	private List oevCallStatus;
   	/**
   	 * oevCallStatusSaved holds oev calls saved
   	 */
   	private List oevCallStatusSaved;
   	/**
   	 * oevRetStatus holds finished oev retuen calls
   	 */
   	private List oevRetStatus;
   	/**
   	 * oevRetStatusSaved holds saved oev return calls
   	 */
   	private List oevRetStatusSaved;
   	/**
   	 * returnCalls holds OEV return call data
   	 */
   	private List returnCalls;


   	
   	//Oev Script-Start
   	private String premium;
       private String primCoPay;
   	private String spclCoPay;
   	private String tier1;
   	private String brandTier;

   	private String fedralConrtStmt;
   	private String userName;
   	private String approvalCode;
   	private String oevplanName;
   	
   	//Oev Script-End
       
   	/**
   	  * Cambia_OEVProcess-End
   	  */
   	
	private String searchAgencyId;	
	private String searchAgencyName;
	private String agencyName;
	private List lstAgencies;
	
	//Fix for IFOX-00415856 START
	private String searchAgentId;	
	private String searchAgentName;
	private String searchAgencyType;	
	private String searchAgentType;
	private String AgentId;
	private String AgentName;
	private String AgencyType;
	private String AgentType;
	//Fix for IFOX-00415856 END
	
	/**
	 * Cambia-ACH Banking Data-Start
	 */

	private String achBillPayMethod;
	/**
	 * achBillingName holds Name
	 */
	private String achBillingName;
	/**
	 * achDraftDay holds  draft day value
	 */
	private String achDraftDay;
	/**
	 * achDraftOverrideAmt holds override ind
	 */
	private String achDraftOverrideAmt;
	/**
   	 * achBankName holds Name on bank
   	 */	
	private String achBankName;
 	/**
   	 * achNameOnAct holds Name on the account
   	 */
	private String achNameOnAct;	
	/**
   	 * achAccountType holds type of account
   	 */
	private String achAccountType;
	/**
   	 * achAbaRoutingNb holds ABA Rounting Number
   	 */
	private String achAbaRoutingNbr;
	/**
   	 * achbankAcctNbr holds bank account number
   	 */
	private String achbankAcctNbr;
	/**
   	 * achBillFrequency holds Bill Frequency value
   	 */
	private String achBillFrequency = "M";
	/**
   	 * achLstActType holds List of account type
   	 */
	private List  achLstActType;
	/**
	 * achLstBillPayMethod holds list of bill pay methods
	 */
	private List achLstBillPayMethod;
	/**
   	 * achLstBillFrequency holds List of Billing Frequency Values
   	 */
	private List  achLstBillFrequency;
	
	
	/**
	 * Cambia-ACH Banking Data-End
	 */
	/**
	 * Cambia-LIS Information-Start
	 */	
	private String lisEffStartDate;
	private String lisEffEndDate;
	private String liCoPayCd;
	private String lisPctCd;
	private List validLiPercents;
	private List validLiCopays;
	private boolean isLisChanged;
	/**
	 * Cambia-LIS Information-End
	 */
	/** Triple S BasePlus Migration START **/
	/* Fix for IFOX-00378075 -- START */
    private String  paramcd;
    /* Fix for IFOX-00378075 -- END */
    /*IFOX-00354933 START*/
    private String compaignId;
    private String contractorNo;
    /*IFOX-00354933 END*/
    /** Triple S BasePlus Migration END **/
	  //LEP Start
    private String lepCalcFlag;
    private String prtdCnt;
    private String rdsCnt;
    private String trigger_Type;
     //LEP End
    // fixed issue # 245 base + : start
    private String OBC1OR2Open;    
    
	public void setOBC1OR2Open(String isOBC1OR2Open) {
		this.OBC1OR2Open = isOBC1OR2Open;
	}
	public String getOBC1OR2Open() {
		//System.out.println("true".equalsIgnoreCase(this.obc1TimerCheck) || "true".equalsIgnoreCase(this.obc2TimerCheck) ? "TRUE" : "FALSE");
		return "true".equalsIgnoreCase(this.obc1TimerCheck) || "true".equalsIgnoreCase(this.obc2TimerCheck) ? "TRUE" : "FALSE";
	}
	// fixed issue # 245 base + : end
  //Added new form property for the read only HIC field on UI : start
    private String displayHic;
    

	/**
	 * @return the displayHic
	 */
	public String getDisplayHic() {
		return displayHic;
	}
	/**
	 * @param displayHic the displayHic to set
	 */
	public void setDisplayHic(String displayHic) {
		this.displayHic = displayHic;
	}
	
	//Added new form property for the read only HIC field on UI : end
	//Added new form property for the MBI field on UI : start
    private String mbiNbr;
    

	/**
	 * @return the displayHic
	 */
	public String getMbiNbr() {
		return mbiNbr;
	}
	/**
	 * @param displayHic the displayHic to set
	 */
	public void setMbiNbr(String mbiNbr) {
		this.mbiNbr = mbiNbr;
	}
	
	//Added new form property for the read only HIC field on UI : end

	//Added new form property to hold indicator for HIC or MBI : start
	
	
	/**
	 * @return the isHicOrMbi
	 */
	
	//Added new form property to hold indicator for HIC or MBI : end
	
	/**
	 * @return Returns the receiptDate.
	 */
	public String getReceiptDate() {
		return receiptDate;
	}
	/**
	 * @param receiptDate The receiptDate to set.
	 */
	public void setReceiptDate(String receiptDate) {
		this.receiptDate = receiptDate;
	}
	/**
	 * @return Returns the isSubscriberIdRequired.
	 */
	public String getIsSubscriberIdRequired() {
		return isSubscriberIdRequired;
	}
	/**
	 * @param isSubscriberIdRequired The isSubscriberIdRequired to set.
	 */
	public void setIsSubscriberIdRequired(String isSubscriberIdRequired) {
		this.isSubscriberIdRequired = isSubscriberIdRequired;
	}
	/**
	 * @return Returns the subscriberId.
	 */

	public String getSubscriberId() {
		return subscriberId;
	}
	/**
	 * @param subscriberId The subscriberId to set.
	 */
	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}
	/**
	 * @return Returns the needMBDUpdate.
	 */
	public String getNeedMBDUpdate() {
		return needMBDUpdate;
	}
	/**
	 * @param needMBDUpdate The needMBDUpdate to set.
	 */
	public void setNeedMBDUpdate(String needMBDUpdate) {
		this.needMBDUpdate = needMBDUpdate;
	}
	/**
	 * @return Returns the products.
	 */
	public List getProducts() {
		return products;
	}
	/**
	 * @param products The products to set.
	 */
	public void setProducts(List products) {
		this.products = products;
	}
	
	/**
	 * @return Returns the currProdName.
	 */
	public String getCurrProdName() {
		return currProdName;
	}
	/**
	 * @param currProdName The currProdName to set.
	 */
	public void setCurrProdName(String currProdName) {
		this.currProdName = currProdName;
	}
	/**
	 * @return Returns the enrollProdName.
	 */
	public String getEnrollProdName() {
		return enrollProdName;
	}
	/**
	 * @param enrollProdName The enrollProdName to set.
	 */
	public void setEnrollProdName(String enrollProdName) {
		this.enrollProdName = enrollProdName;
	}
    /**
	 * @return Returns the searchApplStatus.
	 */
	public String getSearchStatus() {
		return searchStatus;
	}
	/**
	 * @param searchApplStatus The searchApplStatus to set.
	 */
	public void setSearchStatus(String searchStatus) {
		this.searchStatus = searchStatus;
	}
	
	public String getSearchApplId() {
		return searchApplId;
	}
	public void setSearchApplId(String searchApplId) {
		this.searchApplId = searchApplId;
	}
	/**
	 * @return Returns the searchBirthDt.
	 */
	public String getSearchBirthDt() {
		return searchBirthDt;
	}
	/**
	 * @param searchBirthDt The searchBirthDt to set.
	 */
	public void setSearchBirthDt(String searchBirthDt) {
		this.searchBirthDt = searchBirthDt;
	}
	/**
	 * @return Returns the searchHicNo.
	 */
	public String getSearchHicNo() {
		return searchHicNo;
	}
	/**
	 * @param searchHicNo The searchHicNo to set.
	 */
	public void setSearchHicNo(String searchHicNo) {
		this.searchHicNo = searchHicNo;
	}
	/**
	 * @return Returns the searchLastName.
	 */
	public String getSearchLastName() {
		return searchLastName;
	}
	/**
	 * @param searchLastName The searchLastName to set.
	 */
	public void setSearchLastName(String searchLastName) {
		this.searchLastName = searchLastName;
	}
	/**
	 * @return Returns the applType.
	 */
	public String getApplType() {
		return applType;
	}
	/**
	 * @param applType The applType to set.
	 */
	public void setApplType(String applType) {
		this.applType = applType;
	}
	/**
	 * @return Returns the applId.
	 */
	public String getApplId() {
		return applId;
	}
	/**
	 * @param applId The applId to set.
	 */
	public void setApplId(String applId) {
		this.applId = applId;
	}
	/**
	 * @return Returns the applDate.
	 */
	public String getApplDate() {
		return applDate;
	}
	/**
	 * @param applDate The applDate to set.
	 */
	public void setApplDate(String applDate) {
		this.applDate = applDate;
	}
	/**
	 * @return Returns the applStatus.
	 */
	public String getApplStatus() {
		return applStatus;
	}
	/**
	 * @param applStatus The applStatus to set.
	 */
	public void setApplStatus(String applStatus) {
		this.applStatus = applStatus;
	}
	/**
	 * @return Returns the operId.
	 */
	public String getOperId() {
		return operId;
	}
	/**
	 * @param operId The operId to set.
	 */
	public void setOperId(String operId) {
		this.operId = operId;
	}
	/**
	 * @return Returns the lstSearch.
	 */
	public List getLstSearch() {
		return lstSearch;
	}
	/**
	 * @param lstSearch The lstSearch to set.
	 */
	public void setLstSearch(List lstSearch) {
		this.lstSearch = lstSearch;
	}
	/**
	 * @return Returns the altMbrId.
	 */
	public String getAltMbrId() {
		return altMbrId;
	}
	/**
	 * @param altMbrId The altMbrId to set.
	 */
	public void setAltMbrId(String altMbrId) {
		this.altMbrId = altMbrId;
	}
	/**
	 * @return Returns the dtLstChked.
	 */
	public String getDtLstChked() {
		return dtLstChked;
	}
	/**
	 * @param dtLstChked The dtLstChked to set.
	 */
	public void setDtLstChked(String dtLstChked) {
		this.dtLstChked = dtLstChked;
	}
	/**
	 * @return Returns the mbrApplNo.
	 */
	public String getMbrApplNo() {
		return mbrApplNo;
	}
	/**
	 * @param mbrApplNo The mbrApplNo to set.
	 */
	public void setMbrApplNo(String mbrApplNo) {
		this.mbrApplNo = mbrApplNo;
	}
	/**
	 * @return Returns the mbrFirstName.
	 */
	public String getMbrFirstName() {
		return mbrFirstName;
	}
	/**
	 * @param mbrFirstName The mbrFirstName to set.
	 */
	public void setMbrFirstName(String mbrFirstName) {
		this.mbrFirstName = mbrFirstName;
	}
	/**
	 * @return Returns the mbrHicNbr.
	 */
	public String getMbrHicNbr() {
		return mbrHicNbr;
	}
	/**
	 * @param mbrHicNbr The mbrHicNbr to set.
	 */
	public void setMbrHicNbr(String mbrHicNbr) {
		this.mbrHicNbr = mbrHicNbr;
	}
	/**
	 * @return Returns the mbrId.
	 */
	public String getMbrId() {
		return mbrId;
	}
	/**
	 * @param mbrId The mbrId to set.
	 */
	public void setMbrId(String mbrId) {
		this.mbrId = mbrId;
	}
	/**
	 * @return Returns the mbrLastName.
	 */
	public String getMbrLastName() {
		return mbrLastName;
	}
	/**
	 * @param mbrLastName The mbrLastName to set.
	 */
	public void setMbrLastName(String mbrLastName) {
		this.mbrLastName = mbrLastName;
	}
	/**
	 * @return Returns the mbrMiddleName.
	 */
	public String getMbrMiddleName() {
		return mbrMiddleName;
	}
	/**
	 * @param mbrMiddleName The mbrMiddleName to set.
	 */
	public void setMbrMiddleName(String mbrMiddleName) {
		this.mbrMiddleName = mbrMiddleName;
	}
	/**
	 * @return Returns the mbrPrefix.
	 */
	public String getMbrPrefix() {
		return mbrPrefix;
	}
	/**
	 * @param mbrPrefix The mbrPrefix to set.
	 */
	public void setMbrPrefix(String mbrPrefix) {
		this.mbrPrefix = mbrPrefix;
	}
	/**
	 * @return Returns the mbrSsn.
	 */
	public String getMbrSsn() {
		return mbrSsn;
	}
	/**
	 * @param mbrSsn The mbrSsn to set.
	 */
	public void setMbrSsn(String mbrSsn) {
		this.mbrSsn = mbrSsn;
	}
	
	
	/**
	 * @return Returns the mbrBirthDt.
	 */
	public String getMbrBirthDt() {
		return mbrBirthDt;
	}
	/**
	 * @param mbrBirthDt The mbrBirthDt to set.
	 */
	public void setMbrBirthDt(String mbrBirthDt) {
		this.mbrBirthDt = mbrBirthDt;
	}
	/**
	 * @return Returns the mbrPhone.
	 */
	public String getMbrPhone() {
		return mbrPhone;
	}
	/**
	 * @param mbrPhone The mbrPhone to set.
	 */
	public void setMbrPhone(String mbrPhone) {
		this.mbrPhone = mbrPhone;
	}
	/**
	 * @return Returns the mbrRxId.
	 */
	public String getMbrRxId() {
		return mbrRxId;
	}
	/**
	 * @param mbrRxId The mbrRxId to set.
	 */
	public void setMbrRxId(String mbrRxId) {
		this.mbrRxId = mbrRxId;
	}

	/**
	 * @return Returns the perAdd1.
	 */
	public String getPerAdd1() {
		return perAdd1;
	}
	/**
	 * @param perAdd1 The perAdd1 to set.
	 */
	public void setPerAdd1(String perAdd1) {
		this.perAdd1 = perAdd1;
	}
	/**
	 * @return Returns the perAdd2.
	 */
	public String getPerAdd2() {
		return perAdd2;
	}
	/**
	 * @param perAdd2 The perAdd2 to set.
	 */
	public void setPerAdd2(String perAdd2) {
		this.perAdd2 = perAdd2;
	}
	/**
	 * @return Returns the perAdd3.
	 */
	public String getPerAdd3() {
		return perAdd3;
	}
	/**
	 * @param perAdd3 The perAdd3 to set.
	 */
	public void setPerAdd3(String perAdd3) {
		this.perAdd3 = perAdd3;
	}
	/**
	 * @return Returns the perCity.
	 */
	public String getPerCity() {
		return perCity;
	}
	/**
	 * @param perCity The perCity to set.
	 */
	public void setPerCity(String perCity) {
		this.perCity = perCity;
	}
	/**
	 * @return Returns the perCounty.
	 */
	public String getPerCounty() {
		return perCounty;
	}
	/**
	 * @param perCounty The perCounty to set.
	 */
	public void setPerCounty(String perCounty) {
		this.perCounty = perCounty;
	}
	/**
	 * @return Returns the perState.
	 */
	public String getPerState() {
		return perState;
	}
	/**
	 * @param perState The perState to set.
	 */
	public void setPerState(String perState) {
		this.perState = perState;
	}
	/**
	 * @return Returns the perZip.
	 */
	public String getPerZip5() {
		return perZip5;
	}
	/**
	 * @param perZip The perZip to set.
	 */
	public void setPerZip5(String perZip5) {
		this.perZip5 = perZip5;
	}
	/**
	 * @return Returns the perZip4.
	 */
	public String getPerZip4() {
		return perZip4;
	}
	/**
	 * @param perZip4 The perZip4 to set.
	 */
	public void setPerZip4(String perZip4) {
		this.perZip4 = perZip4;
	}
	/**
	 * @return Returns the mailAdd1.
	 */
	public String getMailAdd1() {
		return mailAdd1;
	}
	/**
	 * @param mailAdd1 The mailAdd1 to set.
	 */
	public void setMailAdd1(String mailAdd1) {
		this.mailAdd1 = mailAdd1;
	}
	/**
	 * @return Returns the mailAdd2.
	 */
	public String getMailAdd2() {
		return mailAdd2;
	}
	/**
	 * @param mailAdd2 The mailAdd2 to set.
	 */
	public void setMailAdd2(String mailAdd2) {
		this.mailAdd2 = mailAdd2;
	}
	/**
	 * @return Returns the mailAdd3.
	 */
	public String getMailAdd3() {
		return mailAdd3;
	}
	/**
	 * @param mailAdd3 The mailAdd3 to set.
	 */
	public void setMailAdd3(String mailAdd3) {
		this.mailAdd3 = mailAdd3;
	}
	/**
	 * @return Returns the mailCity.
	 */
	public String getMailCity() {
		return mailCity;
	}
	/**
	 * @param mailCity The mailCity to set.
	 */
	public void setMailCity(String mailCity) {
		this.mailCity = mailCity;
	}
	/**
	 * @return Returns the mailCounty.
	 */
	public String getMailCounty() {
		return mailCounty;
	}
	/**
	 * @param mailCounty The mailCounty to set.
	 */
	public void setMailCounty(String mailCounty) {
		this.mailCounty = mailCounty;
	}
	/**
	 * @return Returns the mailFirstName.
	 */
	public String getMailFirstName() {
		return mailFirstName;
	}
	/**
	 * @param mailFirstName The mailFirstName to set.
	 */
	public void setMailFirstName(String mailFirstName) {
		this.mailFirstName = mailFirstName;
	}
	/**
	 * @return Returns the mailLastName.
	 */
	public String getMailLastName() {
		return mailLastName;
	}
	/**
	 * @param mailLastName The mailLastName to set.
	 */
	public void setMailLastName(String mailLastName) {
		this.mailLastName = mailLastName;
	}
	/**
	 * @return Returns the mailMiddleName.
	 */
	public String getMailMiddleName() {
		return mailMiddleName;
	}
	/**
	 * @param mailMiddleName The mailMiddleName to set.
	 */
	public void setMailMiddleName(String mailMiddleName) {
		this.mailMiddleName = mailMiddleName;
	}
	/**
	 * @return Returns the mailState.
	 */
	public String getMailState() {
		return mailState;
	}
	/**
	 * @param mailState The mailState to set.
	 */
	public void setMailState(String mailState) {
		this.mailState = mailState;
	}
	/**
	 * @return Returns the mailZip4.
	 */
	public String getMailZip4() {
		return mailZip4;
	}
	/**
	 * @param mailZip4 The mailZip4 to set.
	 */
	public void setMailZip4(String mailZip4) {
		this.mailZip4 = mailZip4;
	}
	/**
	 * @return Returns the mailZip5.
	 */
	public String getMailZip5() {
		return mailZip5;
	}
	/**
	 * @param mailZip5 The mailZip5 to set.
	 */
	public void setMailZip5(String mailZip5) {
		this.mailZip5 = mailZip5;
	}
	/**
	 * @return Returns the mbrGender.
	 */
	public String getMbrGender() {
		return mbrGender;
	}
	/**
	 * @param mbrGender The mbrGender to set.
	 */
	public void setMbrGender(String mbrGender) {
		this.mbrGender = mbrGender;
	}
	
	/**
	 * @return Returns the perPhone.
	 */
	public String getPerPhone() {
		return perPhone;
	}
	/**
	 * @param perPhone The perPhone to set.
	 */
	public void setPerPhone(String perPhone) {
		this.perPhone = perPhone;
	}
	
	/**
	 * @return Returns the currPbp.
	 */
	public String getCurrPbp() {
		return currPbp;
	}
	/**
	 * @param currPbp The currPbp to set.
	 */
	public void setCurrPbp(String currPbp) {
		this.currPbp = currPbp;
	}
	/**
	 * @return Returns the currPlan.
	 */
	public String getCurrPlan() {
		return currPlan;
	}
	/**
	 * @param currPlan The currPlan to set.
	 */
	public void setCurrPlan(String currPlan) {
		this.currPlan = currPlan;
	}
	/**
	 * @return Returns the currProduct.
	 */
	public String getCurrProduct() {
		return currProduct;
	}
	/**
	 * @param currProduct The currProduct to set.
	 */
	public void setCurrProduct(String currProduct) {
		this.currProduct = currProduct;
	}
	/**
	 * @return Returns the currPymtAmt.
	 */
	public String getCurrPymtAmt() {
		return currPymtAmt;
	}
	/**
	 * @param currPymtAmt The currPymtAmt to set.
	 */
	public void setCurrPymtAmt(String currPymtAmt) {
		this.currPymtAmt = currPymtAmt;
	}
	/**
	 * @return Returns the currSegment.
	 */
	public String getCurrSegment() {
		return currSegment;
	}
	/**
	 * @param currSegment The currSegment to set.
	 */
	public void setCurrSegment(String currSegment) {
		this.currSegment = currSegment;
	}
	/**
	 * @return Returns the enrollPbp.
	 */
	public String getEnrollPbp() {
		return enrollPbp;
	}
	/**
	 * @param enrollPbp The enrollPbp to set.
	 */
	public void setEnrollPbp(String enrollPbp) {
		this.enrollPbp = enrollPbp;
	}
	/**
	 * @return Returns the enrollPlan.
	 */
	public String getEnrollPlan() {
		return enrollPlan;
	}
	/**
	 * @param enrollPlan The enrollPlan to set.
	 */
	public void setEnrollPlan(String enrollPlan) {
		this.enrollPlan = enrollPlan;
	}
	/**
	 * @return Returns the enrollProduct.
	 */
	public String getEnrollProduct() {
		return enrollProduct;
	}
	/**
	 * @param enrollProduct The enrollProduct to set.
	 */
	public void setEnrollProduct(String enrollProduct) {
		this.enrollProduct = enrollProduct;
	}
	/**
	 * @return Returns the enrollPymtAmt.
	 */
	public String getEnrollPymtAmt() {
		return enrollPymtAmt;
	}
	/**
	 * @param enrollPymtAmt The enrollPymtAmt to set.
	 */
	public void setEnrollPymtAmt(String enrollPymtAmt) {
		this.enrollPymtAmt = enrollPymtAmt;
	}
	/**
	 * @return Returns the enrollSegment.
	 */
	public String getEnrollSegment() {
		return enrollSegment;
	}
	/**
	 * @param enrollSegment The enrollSegment to set.
	 */
	public void setEnrollSegment(String enrollSegment) {
		this.enrollSegment = enrollSegment;
	}
	
	/**
	 * @return Returns the searchPbp.
	 */
	public String getSearchPbp() {
		return searchPbp;
	}
	/**
	 * @param searchPbp The searchPbp to set.
	 */
	public void setSearchPbp(String searchPbp) {
		this.searchPbp = searchPbp;
	}
	/**
	 * @return Returns the searchPlan.
	 */
	public String getSearchPlan() {
		return searchPlan;
	}
	/**
	 * @param searchPlan The searchPlan to set.
	 */
	public void setSearchPlan(String searchPlan) {
		this.searchPlan = searchPlan;
	}
	/**
	 * @return Returns the searchSegment.
	 */
	public String getSearchSegment() {
		return searchSegment;
	}
	/**
	 * @param searchSegment The searchSegment to set.
	 */
	public void setSearchSegment(String searchSegment) {
		this.searchSegment = searchSegment;
	}
	/**
	 * @return Returns the searchZip5.
	 */
	public String getSearchZip5() {
		return searchZip5;
	}
	/**
	 * @param searchZip5 The searchZip5 to set.
	 */
	public void setSearchZip5(String searchZip5) {
		this.searchZip5 = searchZip5;
	}
	/**
	 * @return Returns the searchZip4.
	 */
	public String getSearchZip4() {
		return searchZip4;
	}
	/**
	 * @param searchZip4 The searchZip4 to set.
	 */
	public void setSearchZip4(String searchZip4) {
		this.searchZip4 = searchZip4;
	}
	/**
	 * @return Returns the searchProd.
	 */
	public String getSearchProd() {
		return searchProd;
	}
	/**
	 * @param searchProd The searchProd to set.
	 */
	public void setSearchProd(String searchProd) {
		this.searchProd = searchProd;
	}
	public String getSearchGroup() {
		return searchGroup;
	}
	public void setSearchGroup(String searchGroup) {
		this.searchGroup = searchGroup;
	}
	/**
	 * @return Returns the lstApplStatus.
	 */
	public List getLstApplStatus() {
		return lstApplStatus;
	}
	/**
	 * @param lstApplStatus The lstApplStatus to set.
	 */
	public void setLstApplStatus(List lstApplStatus) {
		this.lstApplStatus = lstApplStatus;
	}
	
	/**
	 * @return Returns the lstApplType.
	 */
	public List getLstApplType() {
		return lstApplType;
	}
	/**
	 * @param lstApplType The lstApplType to set.
	 */
	public void setLstApplType(List lstApplType) {
		this.lstApplType = lstApplType;
	}
	
	/**
	 * @return Returns the lstStates.
	 */
	public List getLstStates() {
		return lstStates;
	}
	/**
	 * @param lstStates The lstStates to set.
	 */
	public void setLstStates(List lstStates) {
		this.lstStates = lstStates;
	}
	
	/**
	 * @return Returns the lstCounty.
	 */
	public List getLstCounty() {
		return lstCounty;
	}
	/**
	 * @param lstCounty The lstCounty to set.
	 */
	public void setLstCounty(List lstCounty) {
		this.lstCounty = lstCounty;
	}
	
	/**
	 * @return Returns the language.
	 */
	public String getLanguage() {
		return language;
	}
	/**
	 * @param language The language to set.
	 */
	public void setLanguage(String language) {
		this.language = language;
	}
	/**
	 * @return Returns the lstLanguages.
	 */
	public List getLstLanguages() {
		return lstLanguages;
	}
	/**
	 * @param lstLanguages The lstLanguages to set.
	 */
	public void setLstLanguages(List lstLanguages) {
		this.lstLanguages = lstLanguages;
	}
	
	public List getLstAltCorrespondences() {
		return lstAltCorrespondences;
	}
	public void setLstAltCorrespondences(List lstAltCorrespondences) {
		this.lstAltCorrespondences = lstAltCorrespondences;
	}
	/**
	 * @return Returns the partAEffDt.
	 */
	public String getPartAEffDt() {
		return partAEffDt;
	}
	/**
	 * @param partAEffDt The partAEffDt to set.
	 */
	public void setPartAEffDt(String partAEffDt) {
		this.partAEffDt = partAEffDt;
	}
	/**
	 * @return Returns the partBEffDt.
	 */
	public String getPartBEffDt() {
		return partBEffDt;
	}
	/**
	 * @param partBEffDt The partBEffDt to set.
	 */
	public void setPartBEffDt(String partBEffDt) {
		this.partBEffDt = partBEffDt;
	}
	/**
	 * @return Returns the partDEffDt.
	 */
	public String getPartDEffDt() {
		return partDEffDt;
	}
	/**
	 * @param partDEffDt The partDEffDt to set.
	 */
	public void setPartDEffDt(String partDEffDt) {
		this.partDEffDt = partDEffDt;
	}
	
	/**
	 * @return the partAEffEndDt
	 */
	public String getPartAEffEndDt() {
		return partAEffEndDt;
	}
	/**
	 * @param partAEffEndDt the partAEffEndDt to set
	 */
	public void setPartAEffEndDt(String partAEffEndDt) {
		this.partAEffEndDt = partAEffEndDt;
	}
	/**
	 * @return the partBEffEndDt
	 */
	public String getPartBEffEndDt() {
		return partBEffEndDt;
	}
	/**
	 * @param partBEffEndDt the partBEffEndDt to set
	 */
	public void setPartBEffEndDt(String partBEffEndDt) {
		this.partBEffEndDt = partBEffEndDt;
	}
	/**
	 * @return Returns the lstPWOptions.
	 */
	public List getLstPWOptions() {
		return lstPWOptions;
	}
	/**
	 * @param lstPWOptions The lstPWOptions to set.
	 */
	public void setLstPWOptions(List lstPWOptions) {
		this.lstPWOptions = lstPWOptions;
	}
	/**
	 * @return Returns the pwOption.
	 */
	public String getPwOption() {
		return pwOption;
	}
	/**
	 * @param pwOption The pwOption to set.
	 */
	public void setPwOption(String pwOption) {
		this.pwOption = pwOption;
	}
	
	/**
	 * @return Returns the covId.
	 */
	public String getCovId() {
		return covId;
	}
	/**
	 * @param covId The covId to set.
	 */
	public void setCovId(String covId) {
		this.covId = covId;
	}
	/**
	 * @return Returns the dialysis.
	 */
	public String getDialysis() {
		return dialysis;
	}
	/**
	 * @param dialysis The dialysis to set.
	 */
	public void setDialysis(String dialysis) {
		this.dialysis = dialysis;
	}
	/**
	 * @return Returns the drugCov.
	 */
	public String getDrugCov() {
		return drugCov;
	}
	/**
	 * @param drugCov The drugCov to set.
	 */
	public void setDrugCov(String drugCov) {
		this.drugCov = drugCov;
	}
	/**
	 * @return Returns the esrd.
	 */
	public String getEsrd() {
		return esrd;
	}
	/**
	 * @param esrd The esrd to set.
	 */
	public void setEsrd(String esrd) {
		this.esrd = esrd;
	}
	/**
	 * @return Returns the esrdEndDt.
	 */
	public String getEsrdEndDt() {
		return esrdEndDt;
	}
	/**
	 * @param esrdEndDt The esrdEndDt to set.
	 */
	public void setEsrdEndDt(String esrdEndDt) {
		this.esrdEndDt = esrdEndDt;
	}
	/**
	 * @return Returns the esrdStDt.
	 */
	public String getEsrdStDt() {
		return esrdStDt;
	}
	/**
	 * @param esrdStDt The esrdStDt to set.
	 */
	public void setEsrdStDt(String esrdStDt) {
		this.esrdStDt = esrdStDt;
	}
	/**
	 * @return Returns the groupNo.
	 */
	public String getGroupNo() {
		return groupNo;
	}
	/**
	 * @param groupNo The groupNo to set.
	 */
	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}
	/**
	 * @return Returns the instPhoneNo.
	 */
	public String getInstPhoneNo() {
		return instPhoneNo;
	}
	/**
	 * @param instPhoneNo The instPhoneNo to set.
	 */
	public void setInstPhoneNo(String instPhoneNo) {
		this.instPhoneNo = instPhoneNo;
	}
	/**
	 * @return Returns the instStreet.
	 */
	public String getInstStreet() {
		return instStreet;
	}
	/**
	 * @param instStreet The instStreet to set.
	 */
	public void setInstStreet(String instStreet) {
		this.instStreet = instStreet;
	}
	/**
	 * @return Returns the longTerm.
	 */
	public String getLongTerm() {
		return longTerm;
	}
	/**
	 * @param longTerm The longTerm to set.
	 */
	public void setLongTerm(String longTerm) {
		this.longTerm = longTerm;
	}
	/**
	 * @return Returns the longTermEndDt.
	 */
	public String getLongTermEndDt() {
		return longTermEndDt;
	}
	/**
	 * @param longTermEndDt The longTermEndDt to set.
	 */
	public void setLongTermEndDt(String longTermEndDt) {
		this.longTermEndDt = longTermEndDt;
	}
	/**
	 * @return Returns the longTermStDt.
	 */
	public String getLongTermStDt() {
		return longTermStDt;
	}
	/**
	 * @param longTermStDt The longTermStDt to set.
	 */
	public void setLongTermStDt(String longTermStDt) {
		this.longTermStDt = longTermStDt;
	}
	/**
	 * @return Returns the medicaidEndDt.
	 */
	public String getMedicaidEndDt() {
		return medicaidEndDt;
	}
	/**
	 * @param medicaidEndDt The medicaidEndDt to set.
	 */
	public void setMedicaidEndDt(String medicaidEndDt) {
		this.medicaidEndDt = medicaidEndDt;
	}
	/**
	 * @return Returns the medicaidStDt.
	 */
	public String getMedicaidStDt() {
		return medicaidStDt;
	}
	/**
	 * @param medicaidStDt The medicaidStDt to set.
	 */
	public void setMedicaidStDt(String medicaidStDt) {
		this.medicaidStDt = medicaidStDt;
	}
	/**
	 * @return Returns the nameInstitute.
	 */
	public String getNameInstitute() {
		return nameInstitute;
	}
	/**
	 * @param nameInstitute The nameInstitute to set.
	 */
	public void setNameInstitute(String nameInstitute) {
		this.nameInstitute = nameInstitute;
	}
	/**
	 * @return Returns the otherCov.
	 */
	public String getOtherCov() {
		return otherCov;
	}
	/**
	 * @param otherCov The otherCov to set.
	 */
	public void setOtherCov(String otherCov) {
		this.otherCov = otherCov;
	}
	/**
	 * @return Returns the spouseWork.
	 */
	public String getSpouseWork() {
		return spouseWork;
	}
	/**
	 * @param spouseWork The spouseWork to set.
	 */
	public void setSpouseWork(String spouseWork) {
		this.spouseWork = spouseWork;
	}
	/**
	 * @return Returns the stMedicaid.
	 */
	public String getStMedicaid() {
		return stMedicaid;
	}
	/**
	 * @param stMedicaid The stMedicaid to set.
	 */
	public void setStMedicaid(String stMedicaid) {
		this.stMedicaid = stMedicaid;
	}
	
	/**
	 * @return Returns the electionType.
	 */
	public String getElectionType() {
		return electionType;
	}
	/**
	 * @param electionType The electionType to set.
	 */
	public void setElectionType(String electionType) {
		this.electionType = electionType;
	}
	/**
	 * @return Returns the lstElectionTypes.
	 */
	public List getLstElectionTypes() {
		return lstElectionTypes;
	}
	/**
	 * @param lstElectionTypes The lstElectionTypes to set.
	 */
	public void setLstElectionTypes(List lstElectionTypes) {
		this.lstElectionTypes = lstElectionTypes;
	}
	/**
	 * @return Returns the lstSepExceptions.
	 */
	public List getLstSepExceptions() {
		return lstSepExceptions;
	}
	/**
	 * @param lstSepExceptions The lstSepExceptions to set.
	 */
	public void setLstSepExceptions(List lstSepExceptions) {
		this.lstSepExceptions = lstSepExceptions;
	}
	/**
	 * @return Returns the electionDt.
	 */
	public String getElectionDt() {
		return electionDt;
	}
	/**
	 * @param electionDt The electionDt to set.
	 */
	public void setElectionDt(String electionDt) {
		this.electionDt = electionDt;
	}
	/**
	 * @return Returns the authRepCity.
	 */
	public String getAuthRepCity() {
		return authRepCity;
	}
	/**
	 * @param authRepCity The authRepCity to set.
	 */
	public void setAuthRepCity(String authRepCity) {
		this.authRepCity = authRepCity;
	}
	public String getAuthRepFirstName() {
		return authRepFirstName;
	}
	public void setAuthRepFirstName(String authRepFirstName) {
		this.authRepFirstName = authRepFirstName;
	}
	public String getAuthRepLastName() {
		return authRepLastName;
	}
	public void setAuthRepLastName(String authRepLastName) {
		this.authRepLastName = authRepLastName;
	}
	public String getAuthRepMidName() {
		return authRepMidName;
	}
	public void setAuthRepMidName(String authRepMidName) {
		this.authRepMidName = authRepMidName;
	}
	/**
	 * @return Returns the authRepPhone.
	 */
	public String getAuthRepPhone() {
		return authRepPhone;
	}
	/**
	 * @param authRepPhone The authRepPhone to set.
	 */
	public void setAuthRepPhone(String authRepPhone) {
		this.authRepPhone = authRepPhone;
	}
	/**
	 * @return Returns the authRepRelation.
	 */
	public String getAuthRepRelation() {
		return authRepRelation;
	}
	/**
	 * @param authRepRelation The authRepRelation to set.
	 */
	public void setAuthRepRelation(String authRepRelation) {
		this.authRepRelation = authRepRelation;
	}
	/**
	 * @return Returns the authRepState.
	 */
	public String getAuthRepState() {
		return authRepState;
	}
	/**
	 * @param authRepState The authRepState to set.
	 */
	public void setAuthRepState(String authRepState) {
		this.authRepState = authRepState;
	}
	/**
	 * @return Returns the authRepStreet.
	 */
	public String getAuthRepStreet() {
		return authRepStreet;
	}
	/**
	 * @param authRepStreet The authRepStreet to set.
	 */
	public void setAuthRepStreet(String authRepStreet) {
		this.authRepStreet = authRepStreet;
	}
	/**
	 * @return Returns the authRepZip4.
	 */
	public String getAuthRepZip4() {
		return authRepZip4;
	}
	/**
	 * @param authRepZip4 The authRepZip4 to set.
	 */
	public void setAuthRepZip4(String authRepZip4) {
		this.authRepZip4 = authRepZip4;
	}
	/**
	 * @return Returns the authRepZip5.
	 */
	public String getAuthRepZip5() {
		return authRepZip5;
	}
	/**
	 * @param authRepZip5 The authRepZip5 to set.
	 */
	public void setAuthRepZip5(String authRepZip5) {
		this.authRepZip5 = authRepZip5;
	}
	/**
	 * @return Returns the lstRelations.
	 */
	public List getLstRelations() {
		return lstRelations;
	}
	/**
	 * @param lstRelations The lstRelations to set.
	 */
	public void setLstRelations(List lstRelations) {
		this.lstRelations = lstRelations;
	}
	/**
	 * @return Returns the signDt.
	 */
	public String getSignDt() {
		return signDt;
	}
	/**
	 * @param signDt The signDt to set.
	 */
	public void setSignDt(String signDt) {
		this.signDt = signDt;
	}
	/**
	 * @return Returns the ovrrdSignDt.
	 */
	public String getOvrrdSignDt() {
		return ovrrdSignDt;
	}
	/**
	 * @param ovrrdSignDt The ovrrdSignDt to set.
	 */
	public void setOvrrdSignDt(String ovrrdSignDt) {
		this.ovrrdSignDt = ovrrdSignDt;
	}
	/**
	 * @return Returns the signOnFile.
	 */
	public String getSignOnFile() {
		return signOnFile;
	}
	/**
	 * @param signOnFile The signOnFile to set.
	 */
	public void setSignOnFile(String signOnFile) {
		this.signOnFile = signOnFile;
	}
	/**
	 * @return Returns the brokAgentId.
	 */
	public String getBrokAgentId() {
		return brokAgentId;
	}
	/**
	 * @param brokAgentId The brokAgentId to set.
	 */
	public void setBrokAgentId(String brokAgentId) {
		this.brokAgentId = brokAgentId;
	}
	/**
	 * @return Returns the brokerName.
	 */
	public String getBrokerName() {
		return brokerName;
	}
	/**
	 * @param brokerName The brokerName to set.
	 */
	public void setBrokerName(String brokerName) {
		this.brokerName = brokerName;
	}
	/**
	 * @return Returns the brokerType.
	 */
	public String getBrokerType() {
		return brokerType;
	}
	/**
	 * @param brokerType The brokerType to set.
	 */
	public void setBrokerType(String brokerType) {
		this.brokerType = brokerType;
	}
	/**
	 * @return Returns the commAgencyId.
	 */
	public String getCommAgencyId() {
		return commAgencyId;
	}
	/**
	 * @param commAgencyId The commAgencyId to set.
	 */
	public void setCommAgencyId(String commAgencyId) {
		this.commAgencyId = commAgencyId;
	}
	/**
	 * @return Returns the commName.
	 */
	public String getCommName() {
		return commName;
	}
	/**
	 * @param commName The commName to set.
	 */
	public void setCommName(String commName) {
		this.commName = commName;
	}
	/**
	 * @return Returns the fieldAgentId.
	 */
	public String getFieldAgentId() {
		return fieldAgentId;
	}
	/**
	 * @param fieldAgentId The fieldAgentId to set.
	 */
	public void setFieldAgentId(String fieldAgentId) {
		this.fieldAgentId = fieldAgentId;
	}
	/**
	 * @return Returns the fieldName.
	 */
	public String getFieldName() {
		return fieldName;
	}
	/**
	 * @param fieldName The fieldName to set.
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	/**
	 * @return Returns the lstAgentTypes.
	 */
	public List getLstAgentTypes() {
		return lstAgentTypes;
	}
	/**
	 * @param lstAgentTypes The lstAgentTypes to set.
	 */
	public void setLstAgentTypes(List lstAgentTypes) {
		this.lstAgentTypes = lstAgentTypes;
	}
	/**
	 * @return Returns the lstAgencyIds.
	 */
	public List getLstAgencyIds() {
		return lstAgencyIds;
	}
	/**
	 * @param lstAgencyIds The lstAgencyIds to set.
	 */
	public void setLstAgencyIds(List lstAgencyIds) {
		this.lstAgencyIds = lstAgencyIds;
	}
	/**
	 * @return Returns the lstBrokAgentIds.
	 */
	public List getLstBrokAgentIds() {
		return lstBrokAgentIds;
	}
	/**
	 * @param lstBrokAgentIds The lstBrokAgentIds to set.
	 */
	public void setLstBrokAgentIds(List lstBrokAgentIds) {
		this.lstBrokAgentIds = lstBrokAgentIds;
	}
	/**
	 * @return Returns the lstFldAgentIds.
	 */
	public List getLstFldAgentIds() {
		return lstFldAgentIds;
	}
	/**
	 * @param lstFldAgentIds The lstFldAgentIds to set.
	 */
	public void setLstFldAgentIds(List lstFldAgentIds) {
		this.lstFldAgentIds = lstFldAgentIds;
	}
	/**
	 * @return Returns the lstPrefix.
	 */
	public List getLstPrefix() {
		return lstPrefix;
	}
	/**
	 * @param lstPrefix The lstPrefix to set.
	 */
	public void setLstPrefix(List lstPrefix) {
		this.lstPrefix = lstPrefix;
	}
	/**
	 * @return Returns the mbd.
	 */
	public MBD getMbd() {
		return mbd;
	}
	/**
	 * @param mbd The mbd to set.
	 */
	public void setMbd(MBD mbd) {
		this.mbd = mbd;
	}
	/**
	 * @return Returns the countyCd.
	 */
	public String getCountyCd() {
		return countyCd;
	}
	/**
	 * @param countyCd The countyCd to set.
	 */
	public void setCountyCd(String countyCd) {
		this.countyCd = countyCd;
	}
	/**
	 * @return Returns the stateCd.
	 */
	public String getStateCd() {
		return stateCd;
	}
	/**
	 * @param stateCd The stateCd to set.
	 */
	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}
	/**
	 * @return Returns the comment.
	 */
	public String getComment() {
		return comment;
	}
	/**
	 * @param comment The comment to set.
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}
	/**
	 * @return Returns the commentRows.
	 */
	public String[] getCommentRows() {
		return commentRows;
	}
	/**
	 * @param commentRows The commentRows to set.
	 */
	public void setCommentRows(String[] commentRows) {
		this.commentRows = commentRows;
	}
	/**
	 * @return Returns the lstComments.
	 */
	public List getLstComments() {
		return lstComments;
	}
	/**
	 * @param lstComments The lstComments to set.
	 */
	public void setLstComments(List lstComments) {
		this.lstComments = lstComments;
	}
	/**
	 * @return Returns the insertRows.
	 */
	public String[] getInsertRows() {
		return insertRows;
	}
	/**
	 * @param insertRows The insertRows to set.
	 */
	public void setInsertRows(String[] insertRows) {
		this.insertRows = insertRows;
	}
	/**
	 * @return Returns the outOfArea.
	 */
	public String getOutOfArea() {
		return outOfArea;
	}
	/**
	 * @param outOfArea The outOfArea to set.
	 */
	public void setOutOfArea(String outOfArea) {
		this.outOfArea = outOfArea;
	}
	/**
	 * @return Returns the mailCountry.
	 */
	public String getMailCountry() {
		return mailCountry;
	}
	/**
	 * @param mailCountry The mailCountry to set.
	 */
	public void setMailCountry(String mailCountry) {
		this.mailCountry = mailCountry;
	}
	/**
	 * @return Returns the lstCountry.
	 */
	public List getLstCountry() {
		return lstCountry;
	}
	/**
	 * @param lstCountry The lstCountry to set.
	 */
	public void setLstCountry(List lstCountry) {
		this.lstCountry = lstCountry;
	}
	/**
	 * @return Returns the countryCd.
	 */
	public String getCountryCd() {
		return countryCd;
	}
	/**
	 * @param countryCd The countryCd to set.
	 */
	public void setCountryCd(String countryCd) {
		this.countryCd = countryCd;
	}
	/**
	 * @return Returns the enrollSrceCd.
	 */
	public String getEnrollSrceCd() {
		return enrollSrceCd;
	}
	/**
	 * @param enrollSrceCd The enrollSrceCd to set.
	 */
	public void setEnrollSrceCd(String enrollSrceCd) {
		this.enrollSrceCd = enrollSrceCd;
	}
	/**
	 * @return Returns the lstEnrollSrce.
	 */
	public List getLstEnrollSrce() {
		return lstEnrollSrce;
	}
	/**
	 * @param lstEnrollSrce The lstEnrollSrce to set.
	 */
	public void setLstEnrollSrce(List lstEnrollSrce) {
		this.lstEnrollSrce = lstEnrollSrce;
	}
	/**
	 * @return Returns the email.
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email The email to set.
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return Returns the emergName.
	 */
	public String getEmergName() {
		return emergName;
	}
	/**
	 * @param emergName The emergName to set.
	 */
	public void setEmergName(String emergName) {
		this.emergName = emergName;
	}
	/**
	 * @return Returns the emergPhone.
	 */
	public String getEmergPhone() {
		return emergPhone;
	}
	/**
	 * @param emergPhone The emergPhone to set.
	 */
	public void setEmergPhone(String emergPhone) {
		this.emergPhone = emergPhone;
	}
	/**
	 * @return Returns the emergRelation.
	 */
	public String getEmergRelation() {
		return emergRelation;
	}
	/**
	 * @param emergRelation The emergRelation to set.
	 */
	public void setEmergRelation(String emergRelation) {
		this.emergRelation = emergRelation;
	}
	/**
	 * @return Returns the customerId.
	 */
	public String getCustomerId() {
		return customerId;
	}
	/**
	 * @param customerId The customerId to set.
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	/**
	 * @return Returns the createTime.
	 */
	public String getCreateTime() {
		return createTime;
	}
	/**
	 * @param createTime The createTime to set.
	 */
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	/**
	 * @return Returns the createUser.
	 */
	public String getCreateUser() {
		return createUser;
	}
	/**
	 * @param createUser The createUser to set.
	 */
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	/**
	 * @return Returns the updtTime.
	 */
	public String getUpdtTime() {
		return updtTime;
	}
	/**
	 * @param updtTime The updtTime to set.
	 */
	public void setUpdtTime(String updtTime) {
		this.updtTime = updtTime;
	}
	/**
	 * @return Returns the updtUser.
	 */
	public String getUpdtUser() {
		return updtUser;
	}
	/**
	 * @param updtUser The updtUser to set.
	 */
	public void setUpdtUser(String updtUser) {
		this.updtUser = updtUser;
	}
	/**
	 * @return Returns the mbrEmail.
	 */
	public String getMbrEmail() {
		return mbrEmail;
	}
	/**
	 * @param mbrEmail The mbrEmail to set.
	 */
	public void setMbrEmail(String mbrEmail) {
		this.mbrEmail = mbrEmail;
	}
	/**
	 * @return Returns the insCardName.
	 */
	public String getInsCardName() {
		return insCardName;
	}
	/**
	 * @param insCardName The insCardName to set.
	 */
	public void setInsCardName(String insCardName) {
		this.insCardName = insCardName;
	}
	/**
	 * @return Returns the updateRec.
	 */
	public String getUpdateRec() {
		return updateRec;
	}
	/**
	 * @param updateRec The updateRec to set.
	 */
	public void setUpdateRec(String updateRec) {
		this.updateRec = updateRec;
	}
	/**
	 * @return Returns the reqDtCov.
	 */
	public String getReqDtCov() {
		return reqDtCov;
	}
	/**
	 * @param reqDtCov The reqDtCov to set.
	 */
	public void setReqDtCov(String reqDtCov) {
		this.reqDtCov = reqDtCov;
	}
	/**
	 * @return Returns the lstInstitutes.
	 */
	public List getLstInstitutes() {
		return lstInstitutes;
	}
	/**
	 * @param lstInstitutes The lstInstitutes to set.
	 */
	public void setLstInstitutes(List lstInstitutes) {
		this.lstInstitutes = lstInstitutes;
	}
	/**
	 * @return Returns the pcoInd.
	 */
	public String getPcoInd() {
		return pcoInd;
	}
	/**
	 * @param pcoInd The pcoInd to set.
	 */
	public void setPcoInd(String pcoInd) {
		this.pcoInd = pcoInd;
	}
	/**
	 * @return Returns the lstPcpNames.
	 */
	public List getLstPcpNames() {
		return lstPcpNames;
	}
	/**
	 * @param lstPcpNames The lstPcpNames to set.
	 */
	public void setLstPcpNames(List lstPcpNames) {
		this.lstPcpNames = lstPcpNames;
	}
	/**
	 * @return Returns the pcpCode.
	 */
	public String getPcpCode() {
		return pcpCode;
	}
	/**
	 * @param pcpCode The pcpCode to set.
	 */
	public void setPcpCode(String pcpCode) {
		this.pcpCode = pcpCode;
	}
	/**
	 * @return Returns the attestDt.
	 */
	public String[] getAttestDt() {
		return attestDt;
	}
	/**
	 * @param attestDt The attestDt to set.
	 */
	public void setAttestDt(String[] attestDt) {
		this.attestDt = attestDt;
	}
	/**
	 * @return Returns the lstAttestation.
	 */
	public List getLstAttestation() {
		return lstAttestation;
	}
	/**
	 * @param lstAttestation The lstAttestation to set.
	 */
	public void setLstAttestation(List lstAttestation) {
		this.lstAttestation = lstAttestation;
	}
	/**
	 * @return Returns the sepException.
	 */
	public String[] getSepException() {
		return sepException;
	}
	/**
	 * @param sepException The sepException to set.
	 */
	public void setSepException(String[] sepException) {
		this.sepException = sepException;
	}
	/**
	 * @return Returns the lstPCO.
	 */
	public List getLstPCO() {
		return lstPCO;
	}
	/**
	 * @param lstPCO The lstPCO to set.
	 */
	public void setLstPCO(List lstPCO) {
		this.lstPCO = lstPCO;
	}
	/**
	 * @return Returns the agentDt.
	 */
	public String getAgentDt() {
		return agentDt;
	}
	/**
	 * @param agentDt The agentDt to set.
	 */
	public void setAgentDt(String agentDt) {
		this.agentDt = agentDt;
	}
	/**
	 * @return Returns the visible.
	 */
	public String getVisible() {
		return visible;
	}
	/**
	 * @param visible The visible to set.
	 */
	public void setVisible(String visible) {
		this.visible = visible;
	}
	/**
	 * @return Returns the electionDesc.
	 */
	public String getElectionDesc() {
		return electionDesc;
	}
	/**
	 * @param electionDesc The electionDesc to set.
	 */
	public void setElectionDesc(String electionDesc) {
		this.electionDesc = electionDesc;
	}
	/**
	 * @return Returns the isChanged.
	 */
	public String getIsChanged() {
		return isChanged;
	}
	/**
	 * @param isChanged The isChanged to set.
	 */
	public void setIsChanged(String isChanged) {
		this.isChanged = isChanged;
	}
	/**
	 * @return Returns the lstSepReasons.
	 */
	public List getLstSepReasons() {
		return lstSepReasons;
	}
	/**
	 * @param lstSepReasons The lstSepReasons to set.
	 */
	public void setLstSepReasons(List lstSepReasons) {
		this.lstSepReasons = lstSepReasons;
	}
	/**
	 * @return Returns the sepReason.
	 */
	public String getSepReason() {
		return sepReason;
	}
	/**
	 * @param sepReason The sepReason to set.
	 */
	public void setSepReason(String sepReason) {
		this.sepReason = sepReason;
	}
	/**
	 * @return Returns the currGroup.
	 */
	public String getCurrGroup() {
		return currGroup;
	}
	/**
	 * @param currGroup The currGroup to set.
	 */
	public void setCurrGroup(String currGroup) {
		this.currGroup = currGroup;
	}
	/**
	 * @return Returns the enrollGroup.
	 */
	public String getEnrollGroup() {
		return enrollGroup;
	}
	/**
	 * @param enrollGroup The enrollGroup to set.
	 */
	public void setEnrollGroup(String enrollGroup) {
		this.enrollGroup = enrollGroup;
	}
	/**
	 * @return Returns the lstUpdtAgent.
	 */
	public String getLstUpdtAgent() {
		return lstUpdtAgent;
	}
	/**
	 * @param lstUpdtAgent The lstUpdtAgent to set.
	 */
	public void setLstUpdtAgent(String lstUpdtAgent) {
		this.lstUpdtAgent = lstUpdtAgent;
	}
	/**
	 * @return Returns the lstUpdtAppl.
	 */
	public String getLstUpdtAppl() {
		return lstUpdtAppl;
	}
	public String getFrmtLstUpdtAppl() {
		return DateFormatter.reFormat(lstUpdtAppl, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS);
	}
	/**
	 * @param lstUpdtAppl The lstUpdtAppl to set.
	 */
	public void setLstUpdtAppl(String lstUpdtAppl) {
		this.lstUpdtAppl = lstUpdtAppl;
	}
	/**
	 * @return Returns the lstUpdtAttest.
	 */
	public String getLstUpdtAttest() {
		return lstUpdtAttest;
	}
	/**
	 * @param lstUpdtAttest The lstUpdtAttest to set.
	 */
	public void setLstUpdtAttest(String lstUpdtAttest) {
		this.lstUpdtAttest = lstUpdtAttest;
	}
	/**
	 * @return Returns the lstUpdtOtherCov.
	 */
	public String getLstUpdtOtherCov() {
		return lstUpdtOtherCov;
	}
	/**
	 * @param lstUpdtOtherCov The lstUpdtOtherCov to set.
	 */
	public void setLstUpdtOtherCov(String lstUpdtOtherCov) {
		this.lstUpdtOtherCov = lstUpdtOtherCov;
	}
	/**
	 * @return Returns the lstUpdtOtherPlan.
	 */
	public String getLstUpdtOtherPlan() {
		return lstUpdtOtherPlan;
	}
	/**
	 * @param lstUpdtOtherPlan The lstUpdtOtherPlan to set.
	 */
	public void setLstUpdtOtherPlan(String lstUpdtOtherPlan) {
		this.lstUpdtOtherPlan = lstUpdtOtherPlan;
	}
	/**
	 * @return Returns the lstUpdtPlan.
	 */
	public String getLstUpdtPlan() {
		return lstUpdtPlan;
	}
	/**
	 * @param lstUpdtPlan The lstUpdtPlan to set.
	 */
	public void setLstUpdtPlan(String lstUpdtPlan) {
		this.lstUpdtPlan = lstUpdtPlan;
	}
	/**
	 * @return Returns the lstUpdtAuthAddr.
	 */
	public String getLstUpdtAuthAddr() {
		return lstUpdtAuthAddr;
	}
	/**
	 * @param lstUpdtAuthAddr The lstUpdtAuthAddr to set.
	 */
	public void setLstUpdtAuthAddr(String lstUpdtAuthAddr) {
		this.lstUpdtAuthAddr = lstUpdtAuthAddr;
	}
	/**
	 * @return Returns the lstUpdtMailAddr.
	 */
	public String getLstUpdtMailAddr() {
		return lstUpdtMailAddr;
	}
	/**
	 * @param lstUpdtMailAddr The lstUpdtMailAddr to set.
	 */
	public void setLstUpdtMailAddr(String lstUpdtMailAddr) {
		this.lstUpdtMailAddr = lstUpdtMailAddr;
	}
	/**
	 * @return Returns the lstUpdtPrimAddr.
	 */
	public String getLstUpdtPrimAddr() {
		return lstUpdtPrimAddr;
	}
	/**
	 * @param lstUpdtPrimAddr The lstUpdtPrimAddr to set.
	 */
	public void setLstUpdtPrimAddr(String lstUpdtPrimAddr) {
		this.lstUpdtPrimAddr = lstUpdtPrimAddr;
	}
	/**
	 * @return Returns the mailSuffix.
	 */
	public String getMailSuffix() {
		return mailSuffix;
	}
	/**
	 * @param mailSuffix The mailSuffix to set.
	 */
	public void setMailSuffix(String mailSuffix) {
		this.mailSuffix = mailSuffix;
	}
	/**
	 * @return Returns the mbrSuffix.
	 */
	public String getMbrSuffix() {
		return mbrSuffix;
	}
	/**
	 * @param mbrSuffix The mbrSuffix to set.
	 */
	public void setMbrSuffix(String mbrSuffix) {
		this.mbrSuffix = mbrSuffix;
	}
	/**
	 * @return Returns the billFirstName.
	 */
	public String getBillFirstName() {
		return billFirstName;
	}
	/**
	 * @param billFirstName The billFirstName to set.
	 */
	public void setBillFirstName(String billFirstName) {
		this.billFirstName = billFirstName;
	}
	/**
	 * @return Returns the billLastName.
	 */
	public String getBillLastName() {
		return billLastName;
	}
	/**
	 * @param billLastName The billLastName to set.
	 */
	public void setBillLastName(String billLastName) {
		this.billLastName = billLastName;
	}
	/**
	 * @return Returns the billMiddleName.
	 */
	public String getBillMiddleName() {
		return billMiddleName;
	}
	/**
	 * @param billMiddleName The billMiddleName to set.
	 */
	public void setBillMiddleName(String billMiddleName) {
		this.billMiddleName = billMiddleName;
	}
	/**
	 * @return Returns the billSuffix.
	 */
	public String getBillSuffix() {
		return billSuffix;
	}
	/**
	 * @param billSuffix The billSuffix to set.
	 */
	public void setBillSuffix(String billSuffix) {
		this.billSuffix = billSuffix;
	}
	/**
	 * @return Returns the elgOveride.
	 */
	public String getElgOveride() {
		return elgOveride;
	}
	/**
	 * @param elgOveride The elgOveride to set.
	 */
	public void setElgOveride(String elgOveride) {
		this.elgOveride = elgOveride;
	}
	/**
	 * @return Returns the lstUsrApplStatus.
	 */
	public List getLstUsrApplStatus() {
		return lstUsrApplStatus;
	}
	/**
	 * @param lstUsrApplStatus The lstUsrApplStatus to set.
	 */
	public void setLstUsrApplStatus(List lstUsrApplStatus) {
		this.lstUsrApplStatus = lstUsrApplStatus;
	}
	/**
	 * @return Returns the currStatus.
	 */
	public String getCurrStatus() {
		return currStatus;
	}
	/**
	 * @param currStatus The currStatus to set.
	 */
	public void setCurrStatus(String currStatus) {
		this.currStatus = currStatus;
	}
	/**
	 * @return Returns the mbdCounty.
	 */
	public String getMbdCounty() {
		return mbdCounty;
	}
	/**
	 * @param mbdCounty The mbdCounty to set.
	 */
	public void setMbdCounty(String mbdCounty) {
		this.mbdCounty = mbdCounty;
	}
	/**
	 * @return Returns the mbdState.
	 */
	public String getMbdState() {
		return mbdState;
	}
	/**
	 * @param mbdState The mbdState to set.
	 */
	public void setMbdState(String mbdState) {
		this.mbdState = mbdState;
	}
	/**
	 * @return Returns the applCategory.
	 */
	public String getApplCategory() {
		return applCategory;
	}
	/**
	 * @param applCategory The applCategory to set.
	 */
	public void setApplCategory(String applCategory) {
		this.applCategory = applCategory;
	}
	/**
	 * @return Returns the lstApplCategory.
	 */
	public List getLstApplCategory() {
		return lstApplCategory;
	}
	/**
	 * @param lstApplCategory The lstApplCategory to set.
	 */
	public void setLstApplCategory(List lstApplCategory) {
		this.lstApplCategory = lstApplCategory;
	}
	/**
	 * @return Returns the covBin.
	 */
	public String getCovBin() {
		return covBin;
	}
	/**
	 * @param covBin The covBin to set.
	 */
	public void setCovBin(String covBin) {
		this.covBin = covBin;
	}
	/**
	 * @return Returns the covPcn.
	 */
	public String getCovPcn() {
		return covPcn;
	}
	/**
	 * @param covPcn The covPcn to set.
	 */
	public void setCovPcn(String covPcn) {
		this.covPcn = covPcn;
	}
	/**
	 * @return Returns the customerNbr.
	 */
	public String getCustomerNbr() {
		return customerNbr;
	}
	/**
	 * @param customerNbr The customerNbr to set.
	 */
	public void setCustomerNbr(String customerNbr) {
		this.customerNbr = customerNbr;
	}
	/**
	 * @return Returns the perCell.
	 */
	public String getPerCell() {
		return perCell;
	}
	/**
	 * @param perCell The perCell to set.
	 */
	public void setPerCell(String perCell) {
		this.perCell = perCell;
	}
	/**
	 * @return Returns the currPlanDesgn.
	 */
	public String getCurrPlanDesgn() {
		return currPlanDesgn;
	}
	/**
	 * @param currPlanDesgn The currPlanDesgn to set.
	 */
	public void setCurrPlanDesgn(String currPlanDesgn) {
		this.currPlanDesgn = currPlanDesgn;
	}
	/**
	 * @return Returns the enrollPlanDesgn.
	 */
	public String getEnrollPlanDesgn() {
		return enrollPlanDesgn;
	}
	/**
	 * @param enrollPlanDesgn The enrollPlanDesgn to set.
	 */
	public void setEnrollPlanDesgn(String enrollPlanDesgn) {
		this.enrollPlanDesgn = enrollPlanDesgn;
	}
	/**
	 * @return Returns the elcDerivedInd.
	 */
	public String getElcDerivedInd() {
		return elcDerivedInd;
	}
	/**
	 * @param elcDerivedInd The elcDerivedInd to set.
	 */
	public void setElcDerivedInd(String elcDerivedInd) {
		this.elcDerivedInd = elcDerivedInd;
	}
	/**
	 * @return Returns the perFax.
	 */
	public String getPerFax() {
		return perFax;
	}
	/**
	 * @param perFax The perFax to set.
	 */
	public void setPerFax(String perFax) {
		this.perFax = perFax;
	}
	/**
	 * @return Returns the perWorkPhone.
	 */
	public String getPerWorkPhone() {
		return perWorkPhone;
	}
	/**
	 * @param perWorkPhone The perWorkPhone to set.
	 */
	public void setPerWorkPhone(String perWorkPhone) {
		this.perWorkPhone = perWorkPhone;
	}
	/**
	 * @return Returns the pcpCurrPatnt.
	 */
	public String getPcpCurrPatnt() {
		return pcpCurrPatnt;
	}
	/**
	 * @param pcpCurrPatnt The pcpCurrPatnt to set.
	 */
	public void setPcpCurrPatnt(String pcpCurrPatnt) {
		this.pcpCurrPatnt = pcpCurrPatnt;
	}
	/**
	 * @return Returns the pcpName.
	 */
	public String getPcpName() {
		return pcpName;
	}
	/**
	 * @param pcpName The pcpName to set.
	 */
	public void setPcpName(String pcpName) {
		this.pcpName = pcpName;
	}
	/**
	 * @return Returns the pcpOffCatCd.
	 */
	public String getPcpOffCatCd() {
		return pcpOffCatCd;
	}
	/**
	 * @param pcpOffCatCd The pcpOffCatCd to set.
	 */
	public void setPcpOffCatCd(String pcpOffCatCd) {
		this.pcpOffCatCd = pcpOffCatCd;
	}
	/**
	 * @return Returns the pcpOfficeCd.
	 */
	public String getPcpOfficeCd() {
		return pcpOfficeCd;
	}
	/**
	 * @param pcpOfficeCd The pcpOfficeCd to set.
	 */
	public void setPcpOfficeCd(String pcpOfficeCd) {
		this.pcpOfficeCd = pcpOfficeCd;
	}
	/**
	 * @return Returns the searchDocName.
	 */
	public String getSearchDocName() {
		return searchDocName;
	}
	/**
	 * @param searchDocName The searchDocName to set.
	 */
	public void setSearchDocName(String searchDocName) {
		this.searchDocName = searchDocName;
	}
	/**
	 * @return Returns the searchOffCd.
	 */
	public String getSearchOffCd() {
		return searchOffCd;
	}
	/**
	 * @param searchOffCd The searchOffCd to set.
	 */
	public void setSearchOffCd(String searchOffCd) {
		this.searchOffCd = searchOffCd;
	}
	/**
	 * @return Returns the searchCurrPatnt.
	 */
	public String getSearchCurrPatnt() {
		return searchCurrPatnt;
	}
	/**
	 * @param searchCurrPatnt The searchCurrPatnt to set.
	 */
	public void setSearchCurrPatnt(String searchCurrPatnt) {
		this.searchCurrPatnt = searchCurrPatnt;
	}
	/**
	 * @return Returns the esrdChange.
	 */
	public String getEsrdChange() {
		return esrdChange;
	}
	/**
	 * @param esrdChange The esrdChange to set.
	 */
	public void setEsrdChange(String esrdChange) {
		this.esrdChange = esrdChange;
	}
	/**
	 * @return Returns the longTermChange.
	 */
	public String getLongTermChange() {
		return longTermChange;
	}
	/**
	 * @param longTermChange The longTermChange to set.
	 */
	public void setLongTermChange(String longTermChange) {
		this.longTermChange = longTermChange;
	}
	/**
	 * @return Returns the medicaidChange.
	 */
	public String getMedicaidChange() {
		return medicaidChange;
	}
	/**
	 * @param medicaidChange The medicaidChange to set.
	 */
	public void setMedicaidChange(String medicaidChange) {
		this.medicaidChange = medicaidChange;
	}
	/**
	 * @return Returns the pcpLocationId.
	 */
	public String getPcpLocationId() {
		return pcpLocationId;
	}
	/**
	 * @param pcpLocationId The pcpLocationId to set.
	 */
	public void setPcpLocationId(String pcpLocationId) {
		this.pcpLocationId = pcpLocationId;
	}
	/**
	 * @return Returns the medicaidId.
	 */
	public String getMedicaidId() {
		return medicaidId;
	}
	/**
	 * @param medicaidId The medicaidId to set.
	 */
	public void setMedicaidId(String medicaidId) {
		this.medicaidId = medicaidId;
	}
	/**
	 * @return Returns the enrollEndDate.
	 */
	public String getEnrollEndDate() {
		return enrollEndDate;
	}
	/**
	 * @param enrollEndDate The enrollEndDate to set.
	 */
	public void setEnrollEndDate(String enrollEndDate) {
		this.enrollEndDate = enrollEndDate;
	}
	/**
	 * @return Returns the createApplTime.
	 */
	public String getCreateApplTime() {
		return createApplTime;
	}
	public String getFrmtCreateApplTime() {
		return DateFormatter.reFormat(createApplTime, DateFormatter.DB2_TIMESTAMP, DateFormatter.MM_DD_YYYY_HH_MM_SS);
	}
	/**
	 * @param createApplTime The createApplTime to set.
	 */
	public void setCreateApplTime(String createApplTime) {
		this.createApplTime = createApplTime;
	}
	/**
	 * @return Returns the createApplUser.
	 */
	public String getCreateApplUser() {
		return createApplUser;
	}
	/**
	 * @param createApplUser The createApplUser to set.
	 */
	public void setCreateApplUser(String createApplUser) {
		this.createApplUser = createApplUser;
	}
	/**
	 * @return Returns the lstUpdtApplUser.
	 */
	public String getLstUpdtApplUser() {
		return lstUpdtApplUser;
	}
	/**
	 * @param lstUpdtApplUser The lstUpdtApplUser to set.
	 */
	public void setLstUpdtApplUser(String lstUpdtApplUser) {
		this.lstUpdtApplUser = lstUpdtApplUser;
	}
	/**
	 * @return Returns the statusRFI.
	 */
	public String getStatusRFI() {
		return statusRFI;
	}
	/**
	 * @param statusRFI The statusRFI to set.
	 */
	public void setStatusRFI(String statusRFI) {
		this.statusRFI = statusRFI;
	}
	/**
	 * @return Returns the searchLocId.
	 */
	public String getSearchLocId() {
		return searchLocId;
	}
	/**
	 * @param searchLocId The searchLocId to set.
	 */
	public void setSearchLocId(String searchLocId) {
		this.searchLocId = searchLocId;
	}
	public List getLstCity() {
		return lstCity;
	}
	public void setLstCity(List lstCity) {
		this.lstCity = lstCity;
	}
	public String getSourceCity() {
		return sourceCity;
	}
	public void setSourceCity(String sourceCity) {
		this.sourceCity = sourceCity;
	}
	public String getSourceZip4() {
		return sourceZip4;
	}
	public void setSourceZip4(String sourceZip4) {
		this.sourceZip4 = sourceZip4;
	}
	public String getSourceZip5() {
		return sourceZip5;
	}
	public void setSourceZip5(String sourceZip5) {
		this.sourceZip5 = sourceZip5;
	}
	public String getSourceState() {
		return sourceState;
	}
	public void setSourceState(String sourceState) {
		this.sourceState = sourceState;
	}
	public String getCurrGroupName() {
		return currGroupName;
}
	public void setCurrGroupName(String currGroupName) {
		this.currGroupName = currGroupName;
	}
	public String getEnrollGroupName() {
		return enrollGroupName;
	}
	public void setEnrollGroupName(String enrollGroupName) {
		this.enrollGroupName = enrollGroupName;
	}
	public String getEditOverride() {
		return editOverride;
}
	public void setEditOverride(String editOverride) {
		this.editOverride = editOverride;
	}
	public String getDenialDate() {
		return denialDate;
	}
	public void setDenialDate(String denialDate) {
		this.denialDate = denialDate;
	}
	public String getDenialDateFrmt() {
		return denialDateFrmt;
	}
	public void setDenialDateFrmt(String denialDateFrmt) {
		this.denialDateFrmt = denialDateFrmt;
	}
	public String getDenialReasonCd() {
		return denialReasonCd;
	}
	public void setDenialReasonCd(String denialReasonCd) {
		this.denialReasonCd = denialReasonCd;
	}
	public List<ListBoxItem> getApplDenialReasons() {
		return applDenialReasons;
	}
	public void setApplDenialReasons(List<ListBoxItem> applDenialReasons) {
		this.applDenialReasons = applDenialReasons;
	}
	public String getBtnClicked() {
		return btnClicked;
	}
	public void setBtnClicked(String btnClicked) {
		this.btnClicked = btnClicked;
	}
	public String getFrmtDate() {
		DateUtil du = new DateUtil();
		frmtDate = du.getTodaysDate();
		frmtDate = DateFormatter.reFormat(frmtDate, DateFormatter.YYYYMMDD,
				DateFormatter.MM_DD_YYYY);
		return frmtDate;
	}
	/**
	 * @return the rejectButton
	 */
	public boolean isRejectButton() {
		return rejectButton;
	}
	/**
	 * @param rejectButton the rejectButton to set
	 */
	public void setRejectButton(boolean rejectButton) {
		this.rejectButton = rejectButton;
	}
	/**
	 * @return the reasonPDP
	 */
	public String getReasonPDP() {
		return reasonPDP;
	}
	/**
	 * @param reasonPDP the reasonPDP to set
	 */
	public void setReasonPDP(String reasonPDP) {
		this.reasonPDP = reasonPDP;
	}
	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}
	/**
	 * @param date the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}
	/**
	 * @return the reasonList
	 */
	public List getReasonList() {
		return reasonList;
	}
	/**
	 * @param reasonList the reasonList to set
	 */
	public void setReasonList(List reasonList) {
		this.reasonList = reasonList;
	}
	/**
	 * @param frmtDate the frmtDate to set
	 */
	public void setFrmtDate(String frmtDate) {
		this.frmtDate = frmtDate;
	}
	/**
	 * @return the preSetNoteList
	 */
	public List getPreSetNoteList() {
		return preSetNoteList;
	}
	/**
	 * @param preSetNoteList the preSetNoteList to set
	 */
	public void setPreSetNoteList(List preSetNoteList) {
		this.preSetNoteList = preSetNoteList;
	}
	/**
	 * @return the preSet
	 */
	public String getPreSet() {
		return preSet;
	}
	/**
	 * @param preSet the preSet to set
	 */
	public void setPreSet(String preSet) {
		this.preSet = preSet;
	}
	/**
	 * @return the radioCheck
	 */
	public String getRadioCheck() {
		return radioCheck;
	}
	/**
	 * @param radioCheck the radioCheck to set
	 */
	public void setRadioCheck(String radioCheck) {
		this.radioCheck = radioCheck;
	}
	/**
	 * @return the ind
	 */
	public String getInd() {
		return ind;
	}
	/**
	 * @param ind the ind to set
	 */
	public void setInd(String ind) {
		this.ind = ind;
	}
	/**
	 * @return the preSetDisplayState
	 */
	public String getPreSetDisplayState() {
		return preSetDisplayState;
	}
	/**
	 * @param preSetDisplayState the preSetDisplayState to set
	 */
	public void setPreSetDisplayState(String preSetDisplayState) {
		this.preSetDisplayState = preSetDisplayState;
	}
	/**
	 * @return the preSetKeyValue
	 */
	public String getPreSetKeyValue() {
		return preSetKeyValue;
	}
	/**
	 * @param preSetKeyValue the preSetKeyValue to set
	 */
	public void setPreSetKeyValue(String preSetKeyValue) {
		this.preSetKeyValue = preSetKeyValue;
	}
	/**
	 * @return the preSetNoteM
	 */
	public String getPreSetNoteM() {
		return preSetNoteM;
	}
	/**
	 * @param preSetNoteM the preSetNoteM to set
	 */
	public void setPreSetNoteM(String preSetNoteM) {
		this.preSetNoteM = preSetNoteM;
	}
	/**
	 * @return the preSetNoteDescr
	 */
	public String getPreSetNoteDescr() {
		return preSetNoteDescr;
	}
	/**
	 * @param preSetNoteDescr the preSetNoteDescr to set
	 */
	public void setPreSetNoteDescr(String preSetNoteDescr) {
		this.preSetNoteDescr = preSetNoteDescr;
	}
	/**
	 * @return the preSetKey
	 */
	public String getPreSetKey() {
		return preSetKey;
	}
	/**
	 * @param preSetKey the preSetKey to set
	 */
	public void setPreSetKey(String preSetKey) {
		this.preSetKey = preSetKey;
	}
	/**
	 * @return the maxId
	 */
	public String getMaxId() {
		return maxId;
	}
	/**
	 * @param maxId the maxId to set
	 */
	public void setMaxId(String maxId) {
		this.maxId = maxId;
	}
	/**
	 * @return the oevUpdtdate
	 */
	public String getOevUpdtdate() {
		return oevUpdtdate;
	}
	/**
	 * @param oevUpdtdate the oevUpdtdate to set
	 */
	public void setOevUpdtdate(String oevUpdtdate) {
		this.oevUpdtdate = oevUpdtdate;
	}
	/**
	 * @return the oevDateNext
	 */
	public boolean isOevDateNext() {
		return oevDateNext;
	}
	/**
	 * @param oevDateNext the oevDateNext to set
	 */
	public void setOevDateNext(boolean oevDateNext) {
		this.oevDateNext = oevDateNext;
	}
	/**
	 * @return the oevInfo
	 */
	public EmMbrOevInfoVO getOevInfo() {
		return oevInfo;
	}
	/**
	 * @param oevInfo the oevInfo to set
	 */
	public void setOevInfo(EmMbrOevInfoVO oevInfo) {
		this.oevInfo = oevInfo;
	}
	/**
	 * @return the oevRetInfo
	 */
	public EmMbrOevInfoVO getOevRetInfo() {
		return oevRetInfo;
	}
	/**
	 * @param oevRetInfo the oevRetInfo to set
	 */
	public void setOevRetInfo(EmMbrOevInfoVO oevRetInfo) {
		this.oevRetInfo = oevRetInfo;
	}
	/**
	 * @return the oevInfoChanged
	 */
	public boolean isOevInfoChanged() {
		return oevInfoChanged;
	}
	/**
	 * @param oevInfoChanged the oevInfoChanged to set
	 */
	public void setOevInfoChanged(boolean oevInfoChanged) {
		this.oevInfoChanged = oevInfoChanged;
	}
	/**
	 * @return the oevReturnInfoChanged
	 */
	public boolean isOevReturnInfoChanged() {
		return oevReturnInfoChanged;
	}
	/**
	 * @param oevReturnInfoChanged the oevReturnInfoChanged to set
	 */
	public void setOevReturnInfoChanged(boolean oevReturnInfoChanged) {
		this.oevReturnInfoChanged = oevReturnInfoChanged;
	}
	/**
	 * @return the oevDateCheck
	 */
	public boolean isOevDateCheck() {
		return oevDateCheck;
	}
	/**
	 * @param oevDateCheck the oevDateCheck to set
	 */
	public void setOevDateCheck(boolean oevDateCheck) {
		this.oevDateCheck = oevDateCheck;
	}
	/**
	 * @return the oevCheck
	 */
	public boolean isOevCheck() {
		return oevCheck;
	}
	/**
	 * @param oevCheck the oevCheck to set
	 */
	public void setOevCheck(boolean oevCheck) {
		this.oevCheck = oevCheck;
	}
	/**
	 * @return the oevTimerCheck
	 */
	public String getOevTimerCheck() {
		return oevTimerCheck;
	}
	/**
	 * @param oevTimerCheck the oevTimerCheck to set
	 */
	public void setOevTimerCheck(String oevTimerCheck) {
		this.oevTimerCheck = oevTimerCheck;
	}
	/**
	 * @return the oev2TimerCheck
	 */
	public boolean isOev2TimerCheck() {
		return oev2TimerCheck;
	}
	/**
	 * @param oev2TimerCheck the oev2TimerCheck to set
	 */
	public void setOev2TimerCheck(boolean oev2TimerCheck) {
		this.oev2TimerCheck = oev2TimerCheck;
	}
	/**
	 * @return the oevButton
	 */
	public String getOevButton() {
		return oevButton;
	}
	/**
	 * @param oevButton the oevButton to set
	 */
	public void setOevButton(String oevButton) {
		this.oevButton = oevButton;
	}
	/**
	 * @return the oevAgentCheck
	 */
	public boolean isOevAgentCheck() {
		return oevAgentCheck;
	}
	/**
	 * @param oevAgentCheck the oevAgentCheck to set
	 */
	public void setOevAgentCheck(boolean oevAgentCheck) {
		this.oevAgentCheck = oevAgentCheck;
	}
	/**
	 * @return the oevCallStatusDrop
	 */
	public List getOevCallStatusDrop() {
		return oevCallStatusDrop;
	}
	/**
	 * @param oevCallStatusDrop the oevCallStatusDrop to set
	 */
	public void setOevCallStatusDrop(List oevCallStatusDrop) {
		this.oevCallStatusDrop = oevCallStatusDrop;
	}
	/**
	 * @return the oevCallSubReasonDrop
	 */
	public List getOevCallSubReasonDrop() {
		return oevCallSubReasonDrop;
	}
	/**
	 * @param oevCallSubReasonDrop the oevCallSubReasonDrop to set
	 */
	public void setOevCallSubReasonDrop(List oevCallSubReasonDrop) {
		this.oevCallSubReasonDrop = oevCallSubReasonDrop;
	}
	/**
	 * @return the oevCallAttempts
	 */
	public List getOevCallAttempts() {
		return oevCallAttempts;
	}
	/**
	 * @param oevCallAttempts the oevCallAttempts to set
	 */
	public void setOevCallAttempts(List oevCallAttempts) {
		this.oevCallAttempts = oevCallAttempts;
	}
	/**
	 * @return the oevCallStatus
	 */
	public List getOevCallStatus() {
		return oevCallStatus;
	}
	/**
	 * @param oevCallStatus the oevCallStatus to set
	 */
	public void setOevCallStatus(List oevCallStatus) {
		this.oevCallStatus = oevCallStatus;
	}
	/**
	 * @return the oevCallStatusSaved
	 */
	public List getOevCallStatusSaved() {
		return oevCallStatusSaved;
	}
	/**
	 * @param oevCallStatusSaved the oevCallStatusSaved to set
	 */
	public void setOevCallStatusSaved(List oevCallStatusSaved) {
		this.oevCallStatusSaved = oevCallStatusSaved;
	}
	/**
	 * @return the oevRetStatus
	 */
	public List getOevRetStatus() {
		return oevRetStatus;
	}
	/**
	 * @param oevRetStatus the oevRetStatus to set
	 */
	public void setOevRetStatus(List oevRetStatus) {
		this.oevRetStatus = oevRetStatus;
	}
	/**
	 * @return the oevRetStatusSaved
	 */
	public List getOevRetStatusSaved() {
		return oevRetStatusSaved;
	}
	/**
	 * @param oevRetStatusSaved the oevRetStatusSaved to set
	 */
	public void setOevRetStatusSaved(List oevRetStatusSaved) {
		this.oevRetStatusSaved = oevRetStatusSaved;
	}
	/**
	 * @return the returnCalls
	 */
	public List getReturnCalls() {
		return returnCalls;
	}
	/**
	 * @param returnCalls the returnCalls to set
	 */
	public void setReturnCalls(List returnCalls) {
		this.returnCalls = returnCalls;
	}
	/**
	 * @return the premium
	 */
	public String getPremium() {
		return premium;
	}
	/**
	 * @param premium the premium to set
	 */
	public void setPremium(String premium) {
		this.premium = premium;
	}
	/**
	 * @return the primCoPay
	 */
	public String getPrimCoPay() {
		return primCoPay;
	}
	/**
	 * @param primCoPay the primCoPay to set
	 */
	public void setPrimCoPay(String primCoPay) {
		this.primCoPay = primCoPay;
	}
	/**
	 * @return the spclCoPay
	 */
	public String getSpclCoPay() {
		return spclCoPay;
	}
	/**
	 * @param spclCoPay the spclCoPay to set
	 */
	public void setSpclCoPay(String spclCoPay) {
		this.spclCoPay = spclCoPay;
	}
	/**
	 * @return the tier1
	 */
	public String getTier1() {
		return tier1;
	}
	/**
	 * @param tier1 the tier1 to set
	 */
	public void setTier1(String tier1) {
		this.tier1 = tier1;
	}
	/**
	 * @return the brandTier
	 */
	public String getBrandTier() {
		return brandTier;
	}
	/**
	 * @param brandTier the brandTier to set
	 */
	public void setBrandTier(String brandTier) {
		this.brandTier = brandTier;
	}
	/**
	 * @return the fedralConrtStmt
	 */
	public String getFedralConrtStmt() {
		return fedralConrtStmt;
	}
	/**
	 * @param fedralConrtStmt the fedralConrtStmt to set
	 */
	public void setFedralConrtStmt(String fedralConrtStmt) {
		this.fedralConrtStmt = fedralConrtStmt;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the approvalCode
	 */
	public String getApprovalCode() {
		return approvalCode;
	}
	/**
	 * @param approvalCode the approvalCode to set
	 */
	public void setApprovalCode(String approvalCode) {
		this.approvalCode = approvalCode;
	}
	/**
	 * @return the oevplanName
	 */
	public String getOevplanName() {
		return oevplanName;
	}
	/**
	 * @param oevplanName the oevplanName to set
	 */
	public void setOevplanName(String oevplanName) {
		this.oevplanName = oevplanName;
	}
	/**
	 * @param oevCallStatusSaved
	 */
	public void setDisplaySavedOev(List oevCallStatusSaved) {
		this.oevCallStatusSaved = oevCallStatusSaved;
		if ((this.oevCallStatusSaved != null)
				&& (this.oevCallStatusSaved.isEmpty() == false)) {
			this.oevInfo = (EmMbrOevInfoVO) this.oevCallStatusSaved
					.get(oevCallStatusSaved.size() - 1);
			// System.out.println("in applform oev info"+ oevInfo.getDate());
		} else {
			this.oevInfo = new EmMbrOevInfoVO();
		}
	}

	/**
	 * @param oevRetStatusSaved
	 */
	public void setDisplaySavedRetOev(List oevRetStatusSaved) {
		this.oevRetStatusSaved = oevRetStatusSaved;
		if ((this.oevRetStatusSaved != null)
				&& (this.oevRetStatusSaved.isEmpty() == false)) {
			this.oevRetInfo = (EmMbrOevInfoVO) this.oevRetStatusSaved
					.get(oevRetStatusSaved.size() - 1);
		} else {
			this.oevRetInfo = new EmMbrOevInfoVO();
		}
	}
	/**
	 * @return the sepInd
	 */
	public String[] getSepInd() {
		return sepInd;
	}
	/**
	 * @param sepInd the sepInd to set
	 */
	public void setSepInd(String[] sepInd) {
		this.sepInd = sepInd;
	}
	/**
	 * @return the sepQueNo
	 */
	public String[] getSepQueNo() {
		return sepQueNo;
	}
	/**
	 * @param sepQueNo the sepQueNo to set
	 */
	public void setSepQueNo(String[] sepQueNo) {
		this.sepQueNo = sepQueNo;
	}
	public String getSearchAgencyId() {
		return searchAgencyId;
	}
	public void setSearchAgencyId(String searchAgencyId) {
		this.searchAgencyId = searchAgencyId;
	}
	public String getSearchAgencyName() {
		return searchAgencyName;
	}
	public void setSearchAgencyName(String searchAgencyName) {
		this.searchAgencyName = searchAgencyName;
	}
	public String getAgencyName() {
		return agencyName;
	}
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}
	public List getLstAgencies() {
		return lstAgencies;
	}
	public void setLstAgencies(List lstAgencies) {
		this.lstAgencies = lstAgencies;
	}
	/**
	 * @return the achBillPayMethod
	 */
	public String getAchBillPayMethod() {
		return achBillPayMethod;
	}
	/**
	 * @param achBillPayMethod the achBillPayMethod to set
	 */
	public void setAchBillPayMethod(String achBillPayMethod) {
		this.achBillPayMethod = achBillPayMethod;
	}
	/**
	 * @return the achBillingName
	 */
	public String getAchBillingName() {
		return achBillingName;
	}
	/**
	 * @param achBillingName the achBillingName to set
	 */
	public void setAchBillingName(String achBillingName) {
		this.achBillingName = achBillingName;
	}
	/**
	 * @return the achDraftDay
	 */
	public String getAchDraftDay() {
		return achDraftDay;
	}
	/**
	 * @param achDraftDay the achDraftDay to set
	 */
	public void setAchDraftDay(String achDraftDay) {
		this.achDraftDay = achDraftDay;
	}
	/**
	 * @return the achDraftOverrideAmt
	 */
	public String getAchDraftOverrideAmt() {
		return achDraftOverrideAmt;
	}
	/**
	 * @param achDraftOverrideAmt the achDraftOverrideAmt to set
	 */
	public void setAchDraftOverrideAmt(String achDraftOverrideAmt) {
		this.achDraftOverrideAmt = achDraftOverrideAmt;
	}
	/**
	 * @return the achNameOnAct
	 */
	public String getAchNameOnAct() {
		return achNameOnAct;
	}
	/**
	 * @param achNameOnAct the achNameOnAct to set
	 */
	public void setAchNameOnAct(String achNameOnAct) {
		this.achNameOnAct = achNameOnAct;
	}
	/**
	 * @return the achBankName
	 */
	public String getAchBankName() {
		return achBankName;
	}
	/**
	 * @param achBankName the achBankName to set
	 */
	public void setAchBankName(String achBankName) {
		this.achBankName = achBankName;
	}
	/**
	 * @return the achAccountType
	 */
	public String getAchAccountType() {
		return achAccountType;
	}
	/**
	 * @param achAccountType the achAccountType to set
	 */
	public void setAchAccountType(String achAccountType) {
		this.achAccountType = achAccountType;
	}
	/**
	 * @return the achAbaRoutingNbr
	 */
	public String getAchAbaRoutingNbr() {
		return achAbaRoutingNbr;
	}
	/**
	 * @param achAbaRoutingNbr the achAbaRoutingNbr to set
	 */
	public void setAchAbaRoutingNbr(String achAbaRoutingNbr) {
		this.achAbaRoutingNbr = achAbaRoutingNbr;
	}
	/**
	 * @return the achbankAcctNbr
	 */
	public String getAchbankAcctNbr() {
		return achbankAcctNbr;
	}
	/**
	 * @param achbankAcctNbr the achbankAcctNbr to set
	 */
	public void setAchbankAcctNbr(String achbankAcctNbr) {
		this.achbankAcctNbr = achbankAcctNbr;
	}
	/**
	 * @return the achLstActType
	 */
	public List getAchLstActType() {
		return achLstActType;
	}
	/**
	 * @param achLstActType the achLstActType to set
	 */
	public void setAchLstActType(List achLstActType) {
		this.achLstActType = achLstActType;
	}
	/**
	 * @return the achLstBillPayMethod
	 */
	public List getAchLstBillPayMethod() {
		return achLstBillPayMethod;
	}
	/**
	 * @param achLstBillPayMethod the achLstBillPayMethod to set
	 */
	public void setAchLstBillPayMethod(List achLstBillPayMethod) {
		this.achLstBillPayMethod = achLstBillPayMethod;
	}
	public String getSearchGroupId() {
		return searchGroupId;
	}

	public void setSearchGroupId(String searchGroupId) {
		this.searchGroupId = searchGroupId;
	}
	public String getSearchProdId() {
		return searchProdId;
	}

	public void setSearchProdId(String searchProdId) {
		this.searchProdId = searchProdId;
	}
	/** @author Surya
	* UseCaseName 024_Cambia_LEP - Start 1
	*/
    List outInitAttests;
	List inInitAttests;
	List outIncAttests;
	List inIncAttests;
	List inLateAttests;	
    public List getInInitAttests() {
		return inInitAttests;
	}
	public void setInInitAttests(List inInitAttests) {
		this.inInitAttests = inInitAttests;
	}
	public List getOutIncAttests() {
		return outIncAttests;
	}
	public void setOutIncAttests(List outIncAttests) {
		this.outIncAttests = outIncAttests;
	}
	public List getInIncAttests() {
		return inIncAttests;
	}
	public void setInIncAttests(List inIncAttests) {
		this.inIncAttests = inIncAttests;
	}
	public List getInLateAttests() {
		return inLateAttests;
	}
	public void setInLateAttests(List inLateAttests) {
		this.inLateAttests = inLateAttests;
	}
	
    
    public List getOutInitAttests() {
		return outInitAttests;
	}
	public void setOutInitAttests(List outInitAttests) {
		this.outInitAttests = outInitAttests;
	}
	/** @author Surya
	* UseCaseName 024_Cambia_LEP - End 1
	*/
	/** @author Surya
	* UseCaseName 024_Cambia_LEP - Start 2
	*/
	private int applicationId;
	public int getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}
	public int getSelectedLepInfoRow() {
		return selectedLepInfoRow;
	}
	public void setSelectedLepInfoRow(int selectedLepInfoRow) {
		this.selectedLepInfoRow = selectedLepInfoRow;
	}
	private int selectedLepInfoRow;
	private List listLepInfos;
	private EmLepSummaryVO displayApplLepInfo = new EmLepSummaryVO();
	public void setListAppLepInfosDisplay(List listLepInfos) {
		this.listLepInfos = listLepInfos;
		if ((this.listLepInfos != null) && (this.listLepInfos.isEmpty() == false)) {
			this.displayApplLepInfo= (EmLepSummaryVO) this.listLepInfos.get(selectedLepInfoRow);
		}
		else {
			this.displayApplLepInfo= new EmLepSummaryVO();
		}
	}
	List lepNunCmoStstus;
    public List getListLepInfos() {
		return listLepInfos;
	}
	public void setListLepInfos(List listLepInfos) {
		this.listLepInfos = listLepInfos;
	}
	public EmLepSummaryVO getDisplayApplLepInfo() {
		return displayApplLepInfo;
	}
	public void setDisplayApplLepInfo(EmLepSummaryVO displayApplLepInfo) {
		this.displayApplLepInfo = displayApplLepInfo;
	}
	public List getLepNunCmoStstus() {
		return lepNunCmoStstus;
	}
	public void setLepNunCmoStstus(List lepNunCmoStstus) {
		this.lepNunCmoStstus = lepNunCmoStstus;
	}
	public String getSelectedLepApplSubTab() {
		return selectedLepApplSubTab;
	}
	public void setSelectedLepApplSubTab(String selectedLepApplSubTab) {
		this.selectedLepApplSubTab = selectedLepApplSubTab;
	}
	private String selectedLepApplSubTab;
	private String[] outInitAttestDate;
	private String[] outInitAttestStatus;
	public String[] getOutInitAttestStatus() {
		return outInitAttestStatus;
	}
	public void setOutInitAttestStatus(String[] outInitAttestStatus) {
		this.outInitAttestStatus = outInitAttestStatus;
	}
	public String[] getOutInitAttestUserID() {
		return outInitAttestUserID;
	}
	public void setOutInitAttestUserID(String[] outInitAttestUserID) {
		this.outInitAttestUserID = outInitAttestUserID;
	}
	public String[] getOutInitAttestChange() {
		return outInitAttestChange;
	}
	public void setOutInitAttestChange(String[] outInitAttestChange) {
		this.outInitAttestChange = outInitAttestChange;
	}
	public String[] getOutInitAttestCreateTime() {
		return outInitAttestCreateTime;
	}
	public void setOutInitAttestCreateTime(String[] outInitAttestCreateTime) {
		this.outInitAttestCreateTime = outInitAttestCreateTime;
	}
	private String[] outInitAttestUserID;
	private String[] outInitAttestChange;
	private String[] outInitAttestCreateTime;
	public String[] getOutInitAttestDate() {
		return outInitAttestDate;
	}
	public void setOutInitAttestDate(String[] outInitAttestDate) {
		this.outInitAttestDate = outInitAttestDate;
	}
	
	
	
	private String[] inInitAttestAttempt;
	public String[] getInInitAttestAttempt() {
		return inInitAttestAttempt;
	}
	public void setInInitAttestAttempt(String[] inInitAttestAttempt) {
		this.inInitAttestAttempt = inInitAttestAttempt;
	}
	public String[] getInInitAttestDate() {
		return inInitAttestDate;
	}
	public void setInInitAttestDate(String[] inInitAttestDate) {
		this.inInitAttestDate = inInitAttestDate;
	}
	public String[] getInInitAttestStatus() {
		return inInitAttestStatus;
	}
	public void setInInitAttestStatus(String[] inInitAttestStatus) {
		this.inInitAttestStatus = inInitAttestStatus;
	}
	public String[] getInInitAttestUserID() {
		return inInitAttestUserID;
	}
	public void setInInitAttestUserID(String[] inInitAttestUserID) {
		this.inInitAttestUserID = inInitAttestUserID;
	}
	public String[] getInInitAttestChange() {
		return inInitAttestChange;
	}
	public void setInInitAttestChange(String[] inInitAttestChange) {
		this.inInitAttestChange = inInitAttestChange;
	}
	public String[] getInInitAttestCreateTime() {
		return inInitAttestCreateTime;
	}
	public void setInInitAttestCreateTime(String[] inInitAttestCreateTime) {
		this.inInitAttestCreateTime = inInitAttestCreateTime;
	}
	private String[] inInitAttestDate;
	private String[] inInitAttestStatus;
	private String[] inInitAttestUserID;
	private String[] inInitAttestChange;
	private String[] inInitAttestCreateTime;
	
	
	private String[] outIncAttestAttempt;
	public String[] getOutIncAttestAttempt() {
		return outIncAttestAttempt;
	}
	public void setOutIncAttestAttempt(String[] outIncAttestAttempt) {
		this.outIncAttestAttempt = outIncAttestAttempt;
	}
	public String[] getOutIncAttestDate() {
		return outIncAttestDate;
	}
	public void setOutIncAttestDate(String[] outIncAttestDate) {
		this.outIncAttestDate = outIncAttestDate;
	}
	public String[] getOutIncAttestStatus() {
		return outIncAttestStatus;
	}
	public void setOutIncAttestStatus(String[] outIncAttestStatus) {
		this.outIncAttestStatus = outIncAttestStatus;
	}
	public String[] getOutIncAttestUserID() {
		return outIncAttestUserID;
	}
	public void setOutIncAttestUserID(String[] outIncAttestUserID) {
		this.outIncAttestUserID = outIncAttestUserID;
	}
	public String[] getOutIncAttestChange() {
		return outIncAttestChange;
	}
	public void setOutIncAttestChange(String[] outIncAttestChange) {
		this.outIncAttestChange = outIncAttestChange;
	}
	public String[] getOutIncAttestCreateTime() {
		return outIncAttestCreateTime;
	}
	public void setOutIncAttestCreateTime(String[] outIncAttestCreateTime) {
		this.outIncAttestCreateTime = outIncAttestCreateTime;
	}
	private String[] outIncAttestDate;
	private String[] outIncAttestStatus;
	private String[] outIncAttestUserID;
	private String[] outIncAttestChange;
	private String[] outIncAttestCreateTime;
	
	
	private String[] inIncAttestAttempt;
	public String[] getInIncAttestAttempt() {
		return inIncAttestAttempt;
	}
	public void setInIncAttestAttempt(String[] inIncAttestAttempt) {
		this.inIncAttestAttempt = inIncAttestAttempt;
	}
	public String[] getInIncAttestDate() {
		return inIncAttestDate;
	}
	public void setInIncAttestDate(String[] inIncAttestDate) {
		this.inIncAttestDate = inIncAttestDate;
	}
	public String[] getInIncAttestStatus() {
		return inIncAttestStatus;
	}
	public void setInIncAttestStatus(String[] inIncAttestStatus) {
		this.inIncAttestStatus = inIncAttestStatus;
	}
	public String[] getInIncAttestUserID() {
		return inIncAttestUserID;
	}
	public void setInIncAttestUserID(String[] inIncAttestUserID) {
		this.inIncAttestUserID = inIncAttestUserID;
	}
	public String[] getInIncAttestChange() {
		return inIncAttestChange;
	}
	public void setInIncAttestChange(String[] inIncAttestChange) {
		this.inIncAttestChange = inIncAttestChange;
	}
	public String[] getInIncAttestCreateTime() {
		return inIncAttestCreateTime;
	}
	public void setInIncAttestCreateTime(String[] inIncAttestCreateTime) {
		this.inIncAttestCreateTime = inIncAttestCreateTime;
	}
	private String[] inIncAttestDate;
	private String[] inIncAttestStatus;
	private String[] inIncAttestUserID;
	private String[] inIncAttestChange;
	private String[] inIncAttestCreateTime;
	
	private String[] inLateoInitAttestDate;
	public String[] getInLateoInitAttestDate() {
		return inLateoInitAttestDate;
	}
	public void setInLateoInitAttestDate(String[] inLateoInitAttestDate) {
		this.inLateoInitAttestDate = inLateoInitAttestDate;
	}
	public String[] getInLateAttestStatus() {
		return inLateAttestStatus;
	}
	public void setInLateAttestStatus(String[] inLateAttestStatus) {
		this.inLateAttestStatus = inLateAttestStatus;
	}
	public String[] getInLateAttestUserID() {
		return inLateAttestUserID;
	}
	public void setInLateAttestUserID(String[] inLateAttestUserID) {
		this.inLateAttestUserID = inLateAttestUserID;
	}
	public String[] getInLateAttestChange() {
		return inLateAttestChange;
	}
	public void setInLateAttestChange(String[] inLateAttestChange) {
		this.inLateAttestChange = inLateAttestChange;
	}
	public String[] getInLateAttestCreateTime() {
		return inLateAttestCreateTime;
	}
	public void setInLateAttestCreateTime(String[] inLateAttestCreateTime) {
		this.inLateAttestCreateTime = inLateAttestCreateTime;
	}
	private String[] inLateAttestStatus;
	private String[] inLateAttestUserID;
	private String[] inLateAttestChange;
	private String[] inLateAttestCreateTime;
	
	
	
	public int getNbrUnCMonths() {
		return nbrUnCMonths;
	}
	public void setNbrUnCMonths(int nbrUnCMonths) {
		this.nbrUnCMonths = nbrUnCMonths;
	}
	public String getAppIncAttRcDt() {
		return appIncAttRcDt;
	}
	public void setAppIncAttRcDt(String appIncAttRcDt) {
		this.appIncAttRcDt = appIncAttRcDt;
	}
	public String getAppIncAttLetExpDt() {
		return appIncAttLetExpDt;
	}
	public void setAppIncAttLetExpDt(String appIncAttLetExpDt) {
		this.appIncAttLetExpDt = appIncAttLetExpDt;
	}
	public String getCreateUserId() {
		return createUserId;
	}
	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}
	public String getLastUpdtTime() {
		return lastUpdtTime;
	}
	public void setLastUpdtTime(String lastUpdtTime) {
		this.lastUpdtTime = lastUpdtTime;
	}
	public String getLastUpdtUserId() {
		return lastUpdtUserId;
	}
	public void setLastUpdtUserId(String lastUpdtUserId) {
		this.lastUpdtUserId = lastUpdtUserId;
	}
	public String getBrkInCoverage() {
		return brkInCoverage;
	}
	public void setBrkInCoverage(String brkInCoverage) {
		this.brkInCoverage = brkInCoverage;
	}
	public String getCredRXCoverage() {
		return credRXCoverage;
	}
	public void setCredRXCoverage(String credRXCoverage) {
		this.credRXCoverage = credRXCoverage;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getComptRespRecDate() {
		return comptRespRecDate;
	}
	public void setComptRespRecDate(String comptRespRecDate) {
		this.comptRespRecDate = comptRespRecDate;
	}
	public String getAttestLetMailDate() {
		return attestLetMailDate;
	}
	public void setAttestLetMailDate(String attestLetMailDate) {
		this.attestLetMailDate = attestLetMailDate;
	}
	public String getAttestLetExpDate() {
		return attestLetExpDate;
	}
	public void setAttestLetExpDate(String attestLetExpDate) {
		this.attestLetExpDate = attestLetExpDate;
	}
	public String getDmsID() {
		return dmsID;
	}
	public void setDmsID(String dmsID) {
		this.dmsID = dmsID;
	}
	public List getBrkInCoverageType() {
		return brkInCoverageType;
	}
	public void setBrkInCoverageType(List brkInCoverageType) {
		this.brkInCoverageType = brkInCoverageType;
	}
	public String getUncovMnthStrtDt() {
		return uncovMnthStrtDt;
	}
	public void setUncovMnthStrtDt(String uncovMnthStrtDt) {
		this.uncovMnthStrtDt = uncovMnthStrtDt;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public List getLepInfos() {
		return lepInfos;
	}
	public void setLepInfos(List lepInfos) {
		this.lepInfos = lepInfos;
	}
	private int nbrUnCMonths;
	private String appIncAttRcDt;
	private String appIncAttLetExpDt;
	private String createUserId;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	private String brkInCoverage;
	private String credRXCoverage;
	private String fromDate;
	private String toDate;
	private String comptRespRecDate;
	private String attestLetMailDate;
	private String attestLetExpDate;
	private String dmsID;
	private List brkInCoverageType;
	private String uncovMnthStrtDt;
	private String memberId;
	private List lepInfos;
	private String statusCd;
	public String getStatusCd() {
		return statusCd;
	}
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	public String getLoginUser() {
		return loginUser;
	}
	public void setLoginUser(String loginUser) {
		this.loginUser = loginUser;
	}
	private String loginUser;
	private String uncovMthStDt;
	public String getUncovMthStDt() {
		return uncovMthStDt;
	}

	public void setUncovMthStDt(String uncovMthStDt) {
		this.uncovMthStDt = uncovMthStDt;
	}
	private String letterName;
	public String getLetterName() {
		return letterName;
	}

	public void setLetterName(String letterName) {
		this.letterName = letterName;
	}
	private String letterUploadedTime;
	
	
	//Begin:IFOX-00412749
	private String pdf_archival;
	
	public String getPdf_archival() {
		return pdf_archival;
	}
	public void setPdf_archival(String pdf_archival) {
		this.pdf_archival = pdf_archival;
	}
	
	//End:IFOX-00412749
	
	public String getLetterUploadedTime() {
		return letterUploadedTime;
	}

	public void setLetterUploadedTime(String letterUploadedTime) {
		this.letterUploadedTime = letterUploadedTime;
		
	}
	private String letterAvailabilityInDB;
	public String getLetterAvailabilityInDB() {
		return letterAvailabilityInDB;
	}

	public void setLetterAvailabilityInDB(String letterAvailabilityInDB) {
		this.letterAvailabilityInDB = letterAvailabilityInDB;
	}
	private List validStatus;
	public List getValidStatus() {
		return validStatus;
	}

	public void setValidStatus(List validStatus) {
		this.validStatus = validStatus;
	}
	 /** @author Surya
		* UseCaseName 024_Cambia_LEP - End 2
		*/
	public String getAchBillFrequency() {
		return achBillFrequency;
	}
	public void setAchBillFrequency(String achBillFrequency) {
		this.achBillFrequency = achBillFrequency;
	}
	public List getAchLstBillFrequency() {
		return achLstBillFrequency;
	}
	public void setAchLstBillFrequency(List achLstBillFrequency) {
		this.achLstBillFrequency = achLstBillFrequency;
	}
	public String getLepCalcFlag() {
		return lepCalcFlag;
	}
	public void setLepCalcFlag(String lepCalcFlag) {
		this.lepCalcFlag = lepCalcFlag;
	}
	public String getPrtdCnt() {
		return prtdCnt;
	}
	public void setPrtdCnt(String prtdCnt) {
		this.prtdCnt = prtdCnt;
	}
	public String getRdsCnt() {
		return rdsCnt;
	}
	public void setRdsCnt(String rdsCnt) {
		this.rdsCnt = rdsCnt;
	}
	public String getTrigger_Type() {
		return trigger_Type;
	}
	public void setTrigger_Type(String trigger_Type) {
		this.trigger_Type = trigger_Type;
	}
	public String getLiCoPayCd() {
		return liCoPayCd;
	}
	public void setLiCoPayCd(String liCoPayCd) {
		this.liCoPayCd = liCoPayCd;
	}
	public String getLisPctCd() {
		return lisPctCd;
	}
	public void setLisPctCd(String lisPctCd) {
		this.lisPctCd = lisPctCd;
	}
	public List getValidLiPercents() {
		return validLiPercents;
	}
	public void setValidLiPercents(List validLiPercents) {
		this.validLiPercents = validLiPercents;
	}
	public List getValidLiCopays() {
		return validLiCopays;
	}
	public void setValidLiCopays(List validLiCopays) {
		this.validLiCopays = validLiCopays;
	}
	public String getLisEffStartDate() {
		return lisEffStartDate;
	}
	public void setLisEffStartDate(String lisEffStartDate) {
		this.lisEffStartDate = lisEffStartDate;
	}
	public String getLisEffEndDate() {
		return lisEffEndDate;
	}
	public void setLisEffEndDate(String lisEffEndDate) {
		this.lisEffEndDate = lisEffEndDate;
	}

	  // BEQ Short term solution --Start
	public String getEligOverrideInd() {
		return eligOverrideInd;
	}
	public void setEligOverrideInd(String eligOverrideInd) {
		this.eligOverrideInd = eligOverrideInd;
	}
	  // BEQ Short term solution --End
	/**
	 * @return the agencySrchPageNbr
	 */
	public int getAgencySrchPageNbr() {
		return agencySrchPageNbr;
	}
	/**
	 * @param agencySrchPageNbr the agencySrchPageNbr to set
	 */
	public void setAgencySrchPageNbr(int agencySrchPageNbr) {
		this.agencySrchPageNbr = agencySrchPageNbr;
	}
	/**
	 * @return the agencySrchPageType
	 */
	public String getAgencySrchPageType() {
		return agencySrchPageType;
	}
	/**
	 * @param agencySrchPageType the agencySrchPageType to set
	 */
	public void setAgencySrchPageType(String agencySrchPageType) {
		this.agencySrchPageType = agencySrchPageType;
	}
	/**
	 * @return the agencySrchMove
	 */
	public String getAgencySrchMove() {
		return agencySrchMove;
	}
	/**
	 * @param agencySrchMove the agencySrchMove to set
	 */
	public void setAgencySrchMove(String agencySrchMove) {
		this.agencySrchMove = agencySrchMove;
	}
	// IFOX-00381706 - COB Fix CR Summacare - Start
	public String getIsInCmpltCOB() {
		return isInCmpltCOB;
	}
	public void setIsInCmpltCOB(String isInCmpltCOB) {
		this.isInCmpltCOB = isInCmpltCOB;
	}
	// IFOX-00381706 - COB Fix CR Summacare - End

	
	//Added new form property to hold indicator for HIC or MBI : start
		private String isHicOrMbi;
		
		
		/**
		 * @return the isHicOrMbi
		 */
		public String getIsHicOrMbi() {
			return isHicOrMbi;
		}
		/**
		 * @param isHicOrMbi the isHicOrMbi to set
		 */
		public void setIsHicOrMbi(String isHicOrMbi) {
			this.isHicOrMbi = isHicOrMbi;
		}
		//Added new form property to hold indicator for HIC or MBI : end

	public String getSourceCounty() {
		return sourceCounty;
	}
	public void setSourceCounty(String sourceCounty) {
		this.sourceCounty = sourceCounty;
	}

	//LEP Merge -Start
	private List ptnlUnCovMnthsReportList;
	
	public List getPtnlUnCovMnthsReportList() {
		return ptnlUnCovMnthsReportList;
	}

	public void setPtnlUnCovMnthsReportList(List ptnlUnCovMnthsReportList) {
		this.ptnlUnCovMnthsReportList = ptnlUnCovMnthsReportList;
	}

	public void setPtnUnCvMntsAppLepInfosDisplay(List ptnlUnCovMnthsReportList) {
		this.ptnlUnCovMnthsReportList = ptnlUnCovMnthsReportList;
		if ((this.ptnlUnCovMnthsReportList != null) && (this.ptnlUnCovMnthsReportList.isEmpty() == false)) {
			this.displayPtnUnCovLepInfo = (LepPtnlUncovMthsVO) this.ptnlUnCovMnthsReportList.get(selectedLepInfoRow);
		} else {
			this.displayPtnUnCovLepInfo = new LepPtnlUncovMthsVO();
		}
	}
	
	private String totalPlepMonths;
	
	public String getTotalPlepMonths() {
		return totalPlepMonths;
	}

	public void setTotalPlepMonths(String totalPlepMonths) {
		this.totalPlepMonths = totalPlepMonths;
	}
	
	private int topDisplayLepInfoRow;
	

	public int getTopDisplayLepInfoRow() {
		return topDisplayLepInfoRow;
	}

	public void setTopDisplayLepInfoRow(int topDisplayLepInfoRow) {
		this.topDisplayLepInfoRow = topDisplayLepInfoRow;
	}
	
	private int topDisplayLepAttRow;
	public int getTopDisplayLepAttRow() {
		return topDisplayLepAttRow;
	}
	public void setTopDisplayLepAttRow(int topDisplayLepAttRow) {
		this.topDisplayLepAttRow = topDisplayLepAttRow;
	}
	
	private String potentialShowAll;
	public String getPotentialShowAll() {
		return potentialShowAll;
	}

	public void setPotentialShowAll(String potentialShowAll) {
		this.potentialShowAll = potentialShowAll;
	}
	
	private LepPtnlUncovMthsVO displayPtnUnCovLepInfo = new LepPtnlUncovMthsVO();
	
	public LepPtnlUncovMthsVO getDisplayPtnUnCovLepInfo() {
		return displayPtnUnCovLepInfo;
	}

	public void setDisplayPtnUnCovLepInfo(LepPtnlUncovMthsVO displayPtnUnCovLepInfo) {
		this.displayPtnUnCovLepInfo = displayPtnUnCovLepInfo;
	}
	
	private String showAllPtnl;
	
	public String getShowAllPtnl() {
		return showAllPtnl;
	}

	public void setShowAllPtnl(String showAllPtnl) {
		this.showAllPtnl = showAllPtnl;
	}
	
	private String move;
	   
    public String getMove() {
		return move;
	}
	public void setMove(String move) {
		this.move = move;
	}
	
	private List lepPtlUnCovMnthsList;
	
	public List getLepPtlUnCovMnthsList() {
		return lepPtlUnCovMnthsList;
	}
	public void setLepPtlUnCovMnthsList(List lepPtlUnCovMnthsList) {
		this.lepPtlUnCovMnthsList = lepPtlUnCovMnthsList;
	}
	
	private String txtUncovMthStDt;
	private String txtUncovMthEndDt;

	public String getTxtUncovMthStDt() {
		return txtUncovMthStDt;
	}

	public void setTxtUncovMthStDt(String txtUncovMthStDt) {
		this.txtUncovMthStDt = txtUncovMthStDt;
	}

	public String getTxtUncovMthEndDt() {
		return txtUncovMthEndDt;
	}

	public void setTxtUncovMthEndDt(String txtUncovMthEndDt) {
		this.txtUncovMthEndDt = txtUncovMthEndDt;
	}
	
	private List emApplLepAttestInfolist;
	
	public List getEmApplLepAttestInfolist() {
		return emApplLepAttestInfolist;
	}

	public void setEmApplLepAttestInfolist(List emApplLepAttestInfolist) {
		this.emApplLepAttestInfolist = emApplLepAttestInfolist;
	}
	
	private EmApplLepAttestInfoVO displayEmApplLepAttestInfo = new EmApplLepAttestInfoVO();
	
	public EmApplLepAttestInfoVO getDisplayEmApplLepAttestInfo() {
		return displayEmApplLepAttestInfo;
	}

	public void setDisplayEmApplLepAttestInfo(EmApplLepAttestInfoVO displayEmApplLepAttestInfo) {
		this.displayEmApplLepAttestInfo = displayEmApplLepAttestInfo;
	}

	
	public void setEmApplLepAttestInfolistDisplay(List emApplLepAttestInfolist) {
		this.emApplLepAttestInfolist = emApplLepAttestInfolist;
		if ((this.emApplLepAttestInfolist != null) && (this.emApplLepAttestInfolist.isEmpty() == false)) {
			this.displayEmApplLepAttestInfo = (EmApplLepAttestInfoVO) this.emApplLepAttestInfolist
					.get(selectedLepInfoRow);
		} else {
			this.displayEmApplLepAttestInfo = new EmApplLepAttestInfoVO();
		}
	}
	private String selectedLepApplAttnSubTab;
	
	public String getSelectedLepApplAttnSubTab() {
		return selectedLepApplAttnSubTab;
	}

	public void setSelectedLepApplAttnSubTab(String selectedLepApplAttnSubTab) {
		this.selectedLepApplAttnSubTab = selectedLepApplAttnSubTab;
	}

	private String appAttnShowAll;
	
	public String getAppAttnShowAll() {
		return appAttnShowAll;
	}

	public void setAppAttnShowAll(String appAttnShowAll) {
		this.appAttnShowAll = appAttnShowAll;
	}
	
	private int selectedLepCcfRow;
	public int getSelectedLepCcfRow() {
		return selectedLepCcfRow;
	}

	public void setSelectedLepCcfRow(int selectedLepCcfRow) {
		this.selectedLepCcfRow = selectedLepCcfRow;
	}
	private int topDisplayCcfRow;
	public int getTopDisplayCcfRow() {
		return topDisplayCcfRow;
	}

	public void setTopDisplayCcfRow(int topDisplayCcfRow) {
		this.topDisplayCcfRow = topDisplayCcfRow;
	}
	
	private String attestStatus;
	
	public String getAttestStatus() {
		return attestStatus;
	}

	public void setAttestStatus(String attestStatus) {
		this.attestStatus = attestStatus;
	}
	
	private String resp;
	
	public String getResp() {
		return resp;
	}
	public void setResp(String resp) {
		this.resp = resp;
	}
	
	private List respType;
	
	public List getRespType() {
		return respType;
	}
	public void setRespType(List respType) {
		this.respType = respType;
	}
	
	private int ccfUncovMnths;
	public int getCcfUncovMnths() {
		return ccfUncovMnths;
	}
	public void setCcfUncovMnths(int ccfUncovMnths) {
		this.ccfUncovMnths = ccfUncovMnths;
	}
	
  //LEP Changes-END	


	public String getBeqCheck() {
		return beqCheck;
	}

	public void setBeqCheck(String beqCheck) {
		this.beqCheck = beqCheck;
	}
	
	/**AAH BasePlus Migration IFOX-00426351 START*/
	private String lobValidation;
    private String enrollLineOfBusiness;
    private String allyAlignLTCQues;
    private String addlQ1;
    private String addlQ2;
    private String addlQ3;
    
    public String getEnrollLineOfBusiness() {
		return enrollLineOfBusiness;
	}
    
	public void setEnrollLineOfBusiness(String enrollLineOfBusiness) {
		this.enrollLineOfBusiness = enrollLineOfBusiness;
	}
	
	public String getLobValidation() {
		return lobValidation;
	}
	public void setLobValidation(String lobValidation) {
		this.lobValidation = lobValidation;
	}
	
	/**
	 * @return the allyAlignLTCQues
	 */
	public String getAllyAlignLTCQues() {
		return allyAlignLTCQues;
	}
	/**
	 * @param allyAlignLTCQues the allyAlignLTCQues to set
	 */
	public void setAllyAlignLTCQues(String allyAlignLTCQues) {
		this.allyAlignLTCQues = allyAlignLTCQues;
	}
	/**
	 * @return the addlQ1
	 */
	public String getAddlQ1() {
		return addlQ1;
	}
	/**
	 * @param addlQ1 the addlQ1 to set
	 */
	public void setAddlQ1(String addlQ1) {
		this.addlQ1 = addlQ1;
	}
	/**
	 * @return the addlQ2
	 */
	public String getAddlQ2() {
		return addlQ2;
	}
	/**
	 * @param addlQ2 the addlQ2 to set
	 */
	public void setAddlQ2(String addlQ2) {
		this.addlQ2 = addlQ2;
	}
	/**
	 * @return the addlQ3
	 */
	public String getAddlQ3() {
		return addlQ3;
	}
	/**
	 * @param addlQ3 the addlQ3 to set
	 */
	public void setAddlQ3(String addlQ3) {
		this.addlQ3 = addlQ3;
	}
	/**AAH BasePlus Migration IFOX-00426351 END*/ 
	
	   //Access health PCP CR- Start 
    private String searchNpiId;
    
    public String getSearchNpiId() {
		return searchNpiId;
	}
	public void setSearchNpiId(String searchNpiId) {
		this.searchNpiId = searchNpiId;
	}
    private String pcpNpiId;
    
    public String getPcpNpiId() {
		return pcpNpiId;
	}
	public void setPcpNpiId(String pcpNpiId) {
		this.pcpNpiId = pcpNpiId;
	}
	
	private String displayNPIField;
	
	public String getDisplayNPIField() {
		return displayNPIField;
	}
	public void setDisplayNPIField(String displayNPIField) {
		this.displayNPIField = displayNPIField;
	}
	//SSNRI-OrigApp
	private String isHicOrMbiEntered;	
    
    public String getIsHicOrMbiEntered() {
		return isHicOrMbiEntered;
	}
	public void setIsHicOrMbiEntered(String isHicOrMbiEntered) {
		this.isHicOrMbiEntered = isHicOrMbiEntered;
	}
	//SSNRI-OrigApp
	//Access health PCP CR- End
	public String getAltCorrespondenceInd() {
		return altCorrespondenceInd;
	}
	public void setAltCorrespondenceInd(String altCorrespondenceInd) {
		this.altCorrespondenceInd = altCorrespondenceInd;
	}
	
	//IFOX-00406767 -START
	/*public String getHealthPlanNews() {
		return healthPlanNews;
	}
	public void setHealthPlanNews(String healthPlanNews) {
		this.healthPlanNews = healthPlanNews;
	}*/
	//IFOX-00406767 -end
	public boolean isLisChanged() {
		return isLisChanged;
	}
	public void setLisChanged(boolean isLisChanged) {
		this.isLisChanged = isLisChanged;
	}
	/** Triple S BasePlus Migration START **/
	/* Fix for IFOX-00378075 -- START*/
	/**
	 * @return the paramcd
	 */
	public String getParamcd() {
		return paramcd;
	}
	/**
	 * @param paramcd the paramcd to set
	 */
	public void setParamcd(String paramcd) {
		this.paramcd = paramcd;
	}
	/* Fix for IFOX-00378075 -- END*/
	/*IFOX-00354933 START */
	public String getCompaignId() {
		return compaignId;
	}
	public void setCompaignId(String compaignId) {
		this.compaignId = compaignId;
	}
	public String getContractorNo() {
		return contractorNo;
	}
	public void setContractorNo(String contractorNo) {
		this.contractorNo = contractorNo;
	}
	/*IFOX-00354933 END */
	/** Triple S BasePlus Migration END **/
	
	/**
	 * @return the isSubscriberIdMandatory
	 */
	public String getIsSubscriberIdMandatory() {
		return isSubscriberIdMandatory;
	}
	/**
	 * @param isSubscriberIdMandatory the isSubscriberIdMandatory to set
	 */
	public void setIsSubscriberIdMandatory(String isSubscriberIdMandatory) {
		this.isSubscriberIdMandatory = isSubscriberIdMandatory;
	}
	//Fix for IFOX-00415856 START
	 private List lstAgencyTypes;
	/**
	 * @return Returns the lstAgencyTypes.
	 */
	public List getLstAgencyTypes() {
		return lstAgencyTypes;
	}
	/**
	 * @param lstAgencyTypes The lstAgencyTypes to set.
	 */
	public void setLstAgencyTypes(List lstAgencyTypes) {
		this.lstAgencyTypes = lstAgencyTypes;
	}
	
	/**
	 * @return the searchAgentId
	 */
	public String getSearchAgentId() {
		return searchAgentId;
	}
	/**
	 * @param searchAgentId the searchAgentId to set
	 */
	public void setSearchAgentId(String searchAgentId) {
		this.searchAgentId = searchAgentId;
	}
	/**
	 * @return the searchAgentName
	 */
	public String getSearchAgentName() {
		return searchAgentName;
	}
	/**
	 * @param searchAgentName the searchAgentName to set
	 */
	public void setSearchAgentName(String searchAgentName) {
		this.searchAgentName = searchAgentName;
	}
	/**
	 * @return the searchAgencyType
	 */
	public String getSearchAgencyType() {
		return searchAgencyType;
	}
	/**
	 * @param searchAgencyType the searchAgencyType to set
	 */
	public void setSearchAgencyType(String searchAgencyType) {
		this.searchAgencyType = searchAgencyType;
	}
	/**
	 * @return the searchAgentType
	 */
	public String getSearchAgentType() {
		return searchAgentType;
	}
	/**
	 * @param searchAgentType the searchAgentType to set
	 */
	public void setSearchAgentType(String searchAgentType) {
		this.searchAgentType = searchAgentType;
	}
	/**
	 * @return the agentId
	 */
	public String getAgentId() {
		return AgentId;
	}
	/**
	 * @param agentId the agentId to set
	 */
	public void setAgentId(String agentId) {
		AgentId = agentId;
	}
	/**
	 * @return the agentName
	 */
	public String getAgentName() {
		return AgentName;
	}
	/**
	 * @param agentName the agentName to set
	 */
	public void setAgentName(String agentName) {
		AgentName = agentName;
	}
	/**
	 * @return the agencyType
	 */
	public String getAgencyType() {
		return AgencyType;
	}
	/**
	 * @param agencyType the agencyType to set
	 */
	public void setAgencyType(String agencyType) {
		AgencyType = agencyType;
	}
	/**
	 * @return the agentType
	 */
	public String getAgentType() {
		return AgentType;
	}
	/**
	 * @param agentType the agentType to set
	 */
	public void setAgentType(String agentType) {
		AgentType = agentType;
	}
	//Fix for IFOX-00415856 END
	
	/** Triple S BasePlus Migration END **/
	//00427630-TSA| M360+ Supress LEP process Platino Members : start
		private String suppLepPlatino;

		public String getSuppLepPlatino() {
			System.out.println("get suppLepPlatino="+suppLepPlatino);
			return suppLepPlatino;
		}
		public void setSuppLepPlatino(String suppLepPlatino) {
			System.out.println("set suppLepPlatino="+suppLepPlatino);
			this.suppLepPlatino = suppLepPlatino;
		}
		
	//00427630-TSA| M360+ Supress LEP process Platino Members : end
	
 /*  IFOX-00431133 -CMS Changes Start  */ 
	public String getDoYouWork() {
		return doYouWork;
	}
	public void setDoYouWork(String doYouWork) {
		this.doYouWork = doYouWork;
	}	
		
	public String getEmailOptIn() {
		return emailOptIn;
	}
	public void setEmailOptIn(String emailOptIn) {
		this.emailOptIn = emailOptIn;
	}
	 /*  IFOX-00431133 -CMS Changes End  */ 
	public String getHealthPlanNews() {
		return healthPlanNews;
	}
	public void setHealthPlanNews(String healthPlanNews) {
		this.healthPlanNews = healthPlanNews;
	}
	//IFOX - 431608 : CMS Changes 2020 - start
	private List <ListBoxItem> appDenialReasonsESRD;
	/**
	 * @return the appDenialReasonsESRD
	 */
	public List<ListBoxItem> getAppDenialReasonsESRD() {
		return appDenialReasonsESRD;
	}
	/**
	 * @param appDenialReasonsESRD the appDenialReasonsESRD to set
	 */
	public void setAppDenialReasonsESRD(List<ListBoxItem> appDenialReasonsESRD) {
		this.appDenialReasonsESRD = appDenialReasonsESRD;
	}
	//IFOX - 431608 : CMS Changes 2020 - end
	
	/* IFOX-431927 Data Masking CR :Start */
	private String maskSSN;
	
	/**
	 * @return the maskSSN
	 */
	public String getMaskSSN() {
		maskSSN = " ";
		if(mbrSsn !=null && !mbrSsn.equals("")){
			if(mbrSsn.length()>4)
				maskSSN = "*****"+mbrSsn.substring(mbrSsn.length()-4);
			else
				maskSSN = "*****"+mbrSsn;
		}
		return maskSSN;
	}
	/**
	 * @param maskSSN the maskSSN to set
	 */
	public void setMaskSSN(String maskSSN) {
		maskSSN = " ";
		if(mbrSsn!= null && !mbrSsn.equals("")){
			if(mbrSsn.length()>4)
				maskSSN = "*****"+mbrSsn.substring(mbrSsn.length()-4);
			else
				maskSSN = "*****"+mbrSsn;
		}
		this.maskSSN = maskSSN;
	}
	
	private String maskAcntNbr;
	private String maskRoutingNbr;
	/**
	 * @return the maskAcntNbr
	 */
	public String getMaskAcntNbr() {
		maskAcntNbr = " ";
		if(achbankAcctNbr !=null && !achbankAcctNbr.equals("")){
			if(achbankAcctNbr.length()>4)
				maskAcntNbr = "*****"+achbankAcctNbr.substring(achbankAcctNbr.length()-4);
			else
				maskAcntNbr =  "*****"+achbankAcctNbr;
		}
		return maskAcntNbr;
	}
	/**
	 * @param maskAcntNbr the maskAcntNbr to set
	 */
	public void setMaskAcntNbr(String maskAcntNbr) {
		maskAcntNbr = " ";
		if(achbankAcctNbr != null && !achbankAcctNbr.equals("")){
			if(achbankAcctNbr.length()>4)
				maskAcntNbr = "*****"+achbankAcctNbr.substring(achbankAcctNbr.length()-4);
			else
				maskAcntNbr =  "*****"+achbankAcctNbr;
		}
		this.maskAcntNbr = maskAcntNbr;
	}
	/**
	 * @return the maskRoutingNbr
	 */
	public String getMaskRoutingNbr() {
		maskRoutingNbr = " ";
		if(achAbaRoutingNbr != null && !achAbaRoutingNbr.equals("")){
			if(achAbaRoutingNbr.length()>4)
				maskRoutingNbr = "*****"+achAbaRoutingNbr.substring(achAbaRoutingNbr.length()-4);
			else
				maskRoutingNbr =  "*****"+achAbaRoutingNbr;
		}
		return maskRoutingNbr;
	}
	/**
	 * @param maskRoutingNbr the maskRoutingNbr to set
	 */
	public void setMaskRoutingNbr(String maskRoutingNbr) {
		maskRoutingNbr = " ";
		if(achAbaRoutingNbr !=null && !achAbaRoutingNbr.equals("")){
			if(achAbaRoutingNbr.length()>4)
				maskRoutingNbr = "*****"+achAbaRoutingNbr.substring(achAbaRoutingNbr.length()-4);
			else
				maskRoutingNbr =  "*****"+achAbaRoutingNbr;
		}
		this.maskRoutingNbr = maskRoutingNbr;
	}

	
	
	/* IFOX-431927 Data Masking CR :End */
		
		
}
