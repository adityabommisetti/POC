//IFOX-00412735 changes -start
/*
 *  $Id: SingleSignOnAction.java,v 1.1 2014/06/26 07:56:40 praveen Exp $
 
package com.ps.mss.web.actions;
import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.DynaActionForm;

import com.ps.mss.adapter.BusinessObjectsAdapter;
import com.ps.mss.adapter.BOAdmin;
import com.ps.io.ModuleLog;
import com.ps.mss.security.SessionManager;
import com.ps.mss.db.AppLogPersistence;
import com.ps.mss.db.DbConnWeb;
import com.ps.mss.db.Message;
import com.ps.mss.db.Module;
import com.ps.mss.framework.Constants;
import com.ps.mss.util.MssProperties;
import com.ps.util.StringUtil;

public class SingleSignOnAction extends Action{
	static ModuleLog log = new ModuleLog("SingleSignOnAction");
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		Connection conn = null;
		try {
			conn = DbConnWeb.getConnection();
			//Don't let customer do SSO, unless a session is already established.
			HttpSession session = SessionManager.getSession(log,request,conn);
			if (session == null) {
				request.setAttribute("Msg", "No session");
				return mapping.findForward("ssoError");
			}
			DynaActionForm genericForm = (DynaActionForm) form;
			String service = StringUtil.trimToNull((String)genericForm.get("service"));
			if (service == null) {
				request.setAttribute("Msg", "cannot determine the service");
				return mapping.findForward("ssoError");
			}
			
		    String user_id = (String) session.getAttribute("User_id");
		    String passwd = (String) session.getAttribute("User_pwd");
		    boolean result = false;
			if ("bor".equals(service)) {
	            String temp = (String)session.getAttribute(Constants.SESSION_SERVICE_BOR);
	            if ("FALSE".equalsIgnoreCase(temp)) {
	    			request.setAttribute("Msg", "You do not have a permission for Reporting Service");
	    			return mapping.findForward("ssoError");
	            }
				result = service_BOR(conn, user_id, passwd);
			} // end of BOR service
			//For future: check for other service here.
			else {
				request.setAttribute("Msg", "Invalid service " + service);
				return mapping.findForward("ssoError");
			}
			if (!result) {
				request.setAttribute("Msg", "Unexpected Error ");
				return mapping.findForward("ssoError");
			}
			return mapping.findForward(service); 
			
		} catch (Exception e) {
			log.println("service_BOR: " + e.getMessage());
			request.setAttribute("Msg", "Application Error");
			return mapping.findForward("ssoError");
		}
		finally {
	        try {
	            if (conn != null)
	                conn.close();
	        } catch(Exception e) {
	            log.println(e.toString());
	        }
		}
	}
	
	private boolean service_BOR(Connection conn, String user_id, String passwd)  {
		String BorUrl = MssProperties.getBorURL();
		StringBuffer errorMsg = new StringBuffer("");
		
		BOAdmin boInfo = BusinessObjectsAdapter.getBOInformations(conn);
		if (boInfo.getCmcUrl()==null || boInfo.getAdminId()==null || boInfo.getAdminPasswd() == null) {
			log.println("service_BOR: BO adminPasswd is null");
			return false;
		}
		//try to login using regular password
		boolean result = BusinessObjectsAdapter.login(boInfo.getCmcUrl(), user_id, passwd, errorMsg );
		//Changed on 6/18/09 : always generate log
		if (!result) {
			try {
				AppLogPersistence alp = new AppLogPersistence(log.getStream());
				alp.add(conn, user_id, Module.SINGLESIGNONACTION, Message.PASWORD_CONF_MISMATCH, 1);
				//force password change
				int returnCode = BusinessObjectsAdapter.changePassword(boInfo.getCmcUrl(), boInfo.getAdminId(), boInfo.getAdminPasswd(), user_id, passwd, errorMsg);
        		switch (returnCode){
    			case BusinessObjectsAdapter.SUCCESSFUL_PASSWORD_CHANGE:
    				alp.add(conn, user_id, Module.SINGLESIGNONACTION, Message.BO_PASSWORD_CHANGED, 2);
    				return true;
     			case BusinessObjectsAdapter.USERID_NOT_FOUND:
    				log.println("BusinessObjects cannot find this [" + user_id + "]");
     				alp.add(conn, user_id, Module.SINGLESIGNONACTION, Message.BO_PASSWD_FAILED, 3);
	        		return false;
				case BusinessObjectsAdapter.ADMINCANNOTLOGIN:
					//This is serious error. Administrator cannot login
					alp.add(conn, user_id, Module.SINGLESIGNONACTION, Message.BO_PASSWD_FAILED, 4);
					errorMsg.append("Administrator cannot login to Business Object");
	        		return false;
    			default:
    				log.println(errorMsg.toString());
    				alp.add(conn, user_id, Module.SINGLESIGNONACTION, Message.BO_PASSWD_FAILED, 5);
	        		return false;
        		}
        	}
			catch (Exception e) {
				log.println("service_BOR: " + e.getMessage());
				return false;
			}
		}
	    return true;
	}
	
}
*/
//IFOX-00412735 changes -end