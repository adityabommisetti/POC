package com.ps.mss.web.actions;

import java.io.PrintWriter;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EEMApplService;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.MBD;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.manager.EEMManager;
import com.ps.mss.model.EEMContext;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.util.StringUtil;

public class EligibilityAction extends Action {
	
	private static Logger logger = LoggerFactory.getLogger(EligibilityAction.class);

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		PrintWriter out = response.getWriter();
		Connection conn = null;
		Map<String, String> dataMap = null;
		MBD mbdData = null;
		try {
			logger.debug("Inside Eligibility Action.");
			
			// use the default DB for security check
			conn = DbConn.getConnection();
			SessionHelper sessionHelper = new SessionHelper(request);
			String errorMsg = sessionHelper.validateUser(conn);
			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			if (errorMsg != null) {
				request.setAttribute("Msg", "Login Has Timed Out");
				throw new Exception(errorMsg);
			}
			
			conn = DbConn.reGetConnection(conn, sessionHelper.getEEMDatabaseName());
			
			String memberAvailabilityInMBD = StringUtil.nonNullTrim(request.getParameter("memberAvailabilityInMBD"));
			System.out.println(" memberAvailabilityInMBD [" + memberAvailabilityInMBD + "] ");
			
			if("false".equalsIgnoreCase(memberAvailabilityInMBD)) {
				MBD mbd = new MBD();
				mbd.clear();
				
				String hicnbr = (String)	request.getParameter("hicnbr");
				String lastname = (String)	request.getParameter("lastname");
				String DOB = (String)request.getParameter("DOB");
				
				mbd.setHicNbr(StringUtil.nonNullTrim(hicnbr));
				mbd.setLastName(StringUtil.nonNullTrim(lastname));
				mbd.setBirthDate(StringUtil.nonNullTrim(DOB));
				
				request.getSession().setAttribute("mbdData", mbd);
			}
			
			String hicnbr = (String)	request.getParameter("hicnbr");//Shellapplication
			String hicMbiFlag = isHicOrMbi(hicnbr);
			mbdData = (MBD) request.getSession().getAttribute("mbdData");

			//IFOX-00397573 start
			if(mbdData.getHicNbr() != null) {
				mbdData.setHicNbr(mbdData.getHicNbr().toUpperCase());
			}
			if(mbdData.getLastName() != null) {
				mbdData.setLastName(mbdData.getLastName().toUpperCase());
			}
			//IFOX-00397573 end
			
			String reqDate = (String) request.getParameter("reqDate");
			String applDate = (String) request.getParameter("applDate");
			String applCat = (String) request.getParameter("applCat");
			logger.debug("reqDate:" + reqDate + ", applDate:" + applDate+", applCat:"+applCat);
			
			EEMContext context = EEMManager.getContext(sessionHelper.getSession());
			EEMApplService applService = context.getService();
			
			dataMap = applService.createApplAndAddToWorklist(conn, sessionHelper.getMfId(), sessionHelper.getUserId(), 
					mbdData, eemDb, reqDate, applDate, applCat,hicMbiFlag);
			if(dataMap == null) {
				dataMap = new HashMap<String, String>();
				dataMap.put("error", "Failed to process.");
			}
		} catch(ApplicationException e) {
			dataMap = new HashMap<String, String>();
			dataMap.put("error", "Failed to process." + "\n" + e.getMessage());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("ApplicationException in EligibilityAction: " + e);
//			logger.error("ApplicationException in EligibilityAction: " + e);
		} catch(Exception e) {
			dataMap = new HashMap<String, String>();
			dataMap.put("error", "Failed to process." + "\n" + e.getMessage());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception in EligibilityAction: " + e);
//			logger.error("Exception in EligibilityAction: " + e);
		} finally {
			if(dataMap == null) {
				dataMap = new HashMap<String, String>();
				dataMap.put("error", "Failed to process.");
			}
			String jsonStr = prepareResponse(dataMap);
			response.setContentType("application/json");
		    out.println(jsonStr);
			out.close();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return null;
	}

	/**
	 * This method prepares the json response with the specified map fields.
	 * 
	 * @param dataMap
	 * @return jsonString
	 */
	private String prepareResponse(Map<String, String> dataMap) {
		logger.info(LoggerConstants.methodStartLevel());
		String res = "{}";
		if(dataMap != null) {
			StringBuilder sb = new StringBuilder();
			sb.append("{");
			Set<String> keySet = dataMap.keySet();
			boolean isFirstElement = true;
			for(String key : keySet) {
				if(isFirstElement) {
					isFirstElement = false;
				} else {
					sb.append(",");
				}
				sb.append("\"");
				sb.append(key);
				sb.append("\":\"");
				sb.append(dataMap.get(key));
				sb.append("\"");
			}
			sb.append("}");
			res = sb.toString();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return res;
	}
	// IFOX-00423084 - BasePlus CMS Nov 2019 Changes - Start
	/*private String isHicOrMbi(String medId) {
		logger.info(LoggerConstants.methodStartLevel());
		String flag = "mbi";
		if(medId.length() == 11){
			if(!Character.isDigit(medId.charAt(0)))
				flag = "hic";
			else if(!Character.isLetter(medId.charAt(1)))
				flag = "hic";
			else if(!Character.isLetterOrDigit(medId.charAt(2)))
				flag = "hic";
			else if(!Character.isDigit(medId.charAt(3)))
				flag = "hic";
			else if(!Character.isLetter(medId.charAt(4)))
				flag = "hic";
			else if(!Character.isLetterOrDigit(medId.charAt(5)))
				flag = "hic";
			else if(!Character.isDigit(medId.charAt(6)))
				flag = "hic";
			else if(!Character.isLetter(medId.charAt(7)))
				flag = "hic";
			else if(!Character.isLetter(medId.charAt(8)))
				flag = "hic";
			else if(!Character.isDigit(medId.charAt(9)))
				flag = "hic";
			else if(!Character.isDigit(medId.charAt(10)))
				flag = "hic";
				
		}
		else 
			flag = "hic";
		logger.info(LoggerConstants.methodEndLevel());
		return flag;
	}*/
	
	private String isHicOrMbi(String medId) {
		logger.info(LoggerConstants.methodStartLevel());
		String flag = "mbi";
		if(medId.length() == 11){
			if(!Character.isDigit(medId.charAt(0)))
				flag = "hic";
			else if(!(Character.isLetter(medId.charAt(1)) && !lookUpForExceptions(medId.charAt(1))))
				flag = "hic";
			else if(!(Character.isLetterOrDigit(medId.charAt(2)) && !lookUpForExceptions(medId.charAt(2))))
				flag = "hic";
			else if(!Character.isDigit(medId.charAt(3)))
				flag = "hic";
			else if(!(Character.isLetter(medId.charAt(4)) && !lookUpForExceptions(medId.charAt(4))))
				flag = "hic";
			else if(!(Character.isLetterOrDigit(medId.charAt(5)) && !lookUpForExceptions(medId.charAt(5))))
				flag = "hic";
			else if(!Character.isDigit(medId.charAt(6)))
				flag = "hic";
			else if(!(Character.isLetter(medId.charAt(7)) && !lookUpForExceptions(medId.charAt(7))))
				flag = "hic";
			else if(!(Character.isLetter(medId.charAt(8)) && !lookUpForExceptions(medId.charAt(8))))
				flag = "hic";
			else if(!Character.isDigit(medId.charAt(9)))
				flag = "hic";
			else if(!Character.isDigit(medId.charAt(10)))
				flag = "hic";
				
		}
		else 
			flag = "hic";
		logger.info(LoggerConstants.methodEndLevel());
		return flag;
	}

	
	private boolean lookUpForExceptions(char ch) {
		char[] exclusions = {'S', 'L', 'O', 'I', 'B', 'Z'};
		
		for(char c:exclusions){
			if(ch == c) {
				//System.out.println("Exclusion Char is Present: " + c);
				return true;
			}
				
		}
		return false;
		
	}
	// IFOX-00423084 - BasePlus CMS Nov 2019 Changes - End 

}
