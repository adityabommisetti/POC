/*
 * $Id: EEMEnrollPcpSearchForm.java,v 1.1 2014/06/26 07:55:42 praveen Exp $
 */
package com.ps.mss.web.forms;

import java.util.List;

public class EEMEnrollPcpSearchForm extends EEMForm {

	private String customerId;
	private String memberId;
	private String effDate;
	private String acceptNewPatientInd;
	private String pcpNbr;
	private String locationId;
	private String doctorName;
	private String doctorAddress;
	private String doctorCity;
	private String doctorState;
	private String doctorZip;
	
	public String getDoctorAddress() {
		return doctorAddress;
	}
	public void setDoctorAddress(String doctorAddress) {
		this.doctorAddress = doctorAddress;
	}
	public String getDoctorCity() {
		return doctorCity;
	}
	public void setDoctorCity(String doctorCity) {
		this.doctorCity = doctorCity;
	}
	public String getDoctorState() {
		return doctorState;
	}
	public void setDoctorState(String doctorState) {
		this.doctorState = doctorState;
	}
	public String getDoctorZip() {
		return doctorZip;
	}
	public void setDoctorZip(String doctorZip) {
		this.doctorZip = doctorZip;
	}
	private List searchResults;

	/**AAH BasePlus Migration IFOX-00426351 START*/ 
	private String lineOfBusiness;	

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}
	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}
	/**AAH BasePlus Migration IFOX-00426351 END*/ 
	
	public String getEffDate() {
		return effDate;
	}
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getPcpNbr() {
		return pcpNbr;
	}
	public void setPcpNbr(String pcpNbr) {
		this.pcpNbr = pcpNbr;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public List getSearchResults() {
		return searchResults;
	}
	public void setSearchResults(List searchResults) {
		this.searchResults = searchResults;
	}
	
	public String getAcceptNewPatientInd() {
		return acceptNewPatientInd;
	}
	public void setAcceptNewPatientInd(String acceptNewPatientInd) {
		this.acceptNewPatientInd = acceptNewPatientInd;
	}

	/*Access health PCP CR- Start*/
	private String pcpNpi;
	
	public String getPcpNpi() {
		return pcpNpi;
	}
	public void setPcpNpi(String pcpNpi) {
		this.pcpNpi = pcpNpi;
	}
	/*Access health PCP CR- END*/

}