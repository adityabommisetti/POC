package com.ps.mss.web.helper;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.EEMSecRolesVO;

import com.ps.mss.web.actions.EEMSecurityAction;
import com.ps.mss.web.forms.EEMSecurityRolesForm;
/**
 * This class is used for form level changes
 * 
 * @author Pramod 
 *
 *@version 1.0, 15th Oct 2013
 */
public class EEMSecRolesHelper {
	/**
	 * To trace the code
	 */
	private static Logger logger = LoggerFactory.getLogger(EEMSecurityAction.class);
	/**
	 * To save the form
	 * @param sessionHelper to forward the session attributes
	 * @param form to store the values of the form
	 */
	public static void saveEEMForm(SessionHelper sessionHelper, EEMSecurityRolesForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		sessionHelper.setAttribute("SaveEEMSecRolesForm",form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	/**
	 * to get the form
	 * @param sessionHelper to forward the session attributes
	 * @return the saved EEMSecurityRolesForm
	 */
	public static EEMSecurityRolesForm getEEMForm(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());

		return (EEMSecurityRolesForm)sessionHelper.getAttribute("SaveEEMSecRolesForm");
	}
	
	

	/**
	 * To set the form to VO
	 * @param eemSecurityRolesForm form from the UI side
	 * @param filterVO to save the values of form to VO 
	 * @param sessionHelper to forward the session attributes
	 * @throws ApplicationException
	 */
	public static void setFormToVO(EEMSecurityRolesForm eemSecurityRolesForm,EEMSecRolesVO filterVO, SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try{	
		
			BeanUtils.copyProperties(filterVO, eemSecurityRolesForm);
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Error in setting form to VO"+e.getMessage());
//			logger.info("Error in setting form to VO"+e.getMessage());
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	/**
	 * To set the VO to form
	 * @param filterVO to save the values of  VO to form 
	 * @param eemSecurityRolesForm form going to be used in UI side
	 * @param sessionHelper forward the session attributes
	 * @throws ApplicationException
	 */
	public static void setVOToForm(EEMSecRolesVO filterVO,EEMSecurityRolesForm eemSecurityRolesForm, SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try{	
		BeanUtils.copyProperties(eemSecurityRolesForm, filterVO);	
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Error in setting VO to form"+e.getMessage());
//			logger.info("Error in setting VO to form"+e.getMessage());
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

}
