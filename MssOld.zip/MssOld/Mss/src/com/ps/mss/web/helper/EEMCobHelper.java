 /*
  * $Id: EEMTimersHelper.java,v 1.1 2014/06/26 07:55:09 praveen Exp $ 
  */

package com.ps.mss.web.helper;

import java.util.List;
import org.apache.commons.beanutils.BeanUtils;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.model.EEMCobFlowVO;
import com.ps.mss.dao.model.EMTimersVO;
import com.ps.mss.db.EEMCodeCache;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.web.forms.EEMCobFlowForm;
import com.ps.mss.web.forms.EEMTimersForm;
import com.ps.util.StringUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class EEMCobHelper {
	
	private static Logger logger = LoggerFactory.getLogger(EEMTimersHelper.class);


	public static void saveEEMForm(SessionHelper sessionHelper, EEMCobFlowForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		//logger.info("Save EEMTimersForm");
			sessionHelper.setAttribute("SaveCobFlowForm",form);
			logger.info(LoggerConstants.methodEndLevel());
	}
	public static EEMCobFlowForm getEEMForm(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		//	logger.info("Get EEMTimersForm");
    return (EEMCobFlowForm)sessionHelper.getAttribute("SaveCobFlowForm");
	}
	
  public static void setCobFormList(EEMCobFlowForm eemCobForm,SessionHelper sessionHelper) throws ApplicationException {
	  logger.info(LoggerConstants.methodStartLevel());
	  // logger.info("Setting RFITimersList to  EEMTimersForm");
	EEMCodeCache objCache = EEMCodeCache.getInstance();
	/*eemTimersForm.setCustomerId(sessionHelper.getMfId());
	eemTimersForm.setArrSearchTypes(objCache.getArrSourceTypes());
	eemTimersForm.setTriggerTypes(objCache.getTriggerTypes());
		// Set Search list
	eemTimersForm.setTimersList((List)sessionHelper.getSession().getAttribute(EEMConstants. SESSION_TIMERS_SEARCH));*/
		
	logger.info(LoggerConstants.methodEndLevel());
		
	}
public static void setFormToVO(EEMCobFlowForm eemCobForm,EEMCobFlowVO filterVO, SessionHelper sessionHelper) throws ApplicationException {
	logger.info(LoggerConstants.methodStartLevel());
	try{	
		//logger.info("Set EEMTimersForm to EMTimersVO");
		BeanUtils.copyProperties(filterVO, eemCobForm);

	} catch (Exception e) {
		throw new ApplicationException(e);
	}
	logger.info(LoggerConstants.methodEndLevel());
}

public static void setVOToForm(EEMCobFlowVO filterVO,EEMCobFlowForm eemCobForm, SessionHelper sessionHelper) throws ApplicationException {
	logger.info(LoggerConstants.methodStartLevel());
	try{	
		//logger.info("Set EMTimersVO to EEMTimersForm");
	/*	if (!StringUtil.nonNullTrim(filterVO.getMessage()).equals(""))
		{
			////System.out.println("in if of helper"+filterVO.getMessage());
			eemTimersForm.setMessage(filterVO.getMessage());*/
		BeanUtils.copyProperties(eemCobForm, filterVO);
		
		
	} catch (Exception e) {
		throw new ApplicationException(e);
	}
	logger.info(LoggerConstants.methodEndLevel());
}


}
