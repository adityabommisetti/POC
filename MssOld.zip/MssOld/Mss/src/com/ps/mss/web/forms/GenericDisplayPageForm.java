/*
 * $Id: GenericDisplayPageForm.java,v 1.1 2014/06/26 07:55:49 praveen Exp $
 */
package com.ps.mss.web.forms;

import java.util.List;

/**
 * 
 * @author indrapradja.adriana
 *
 * Used for display. Will be accessed by .jsp
 */
public class GenericDisplayPageForm {
	private int count;
	private String title;
	private List listObject;
	private Object detail;
	
	/**
	 * @return Returns the count.
	 */
	public int getCount() {
		return count;
	}
	/**
	 * @param count The count to set.
	 */
	public void setCount(int count) {
		this.count = count;
	}
	/**
	 * @return Returns the title or header.
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title The title to set or header
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return Returns the listObject.
	 */
	public List getListObject() {
		return listObject;
	}
	/**
	 * @param listObject The listObject to set.
	 */
	public void setListObject(List listObject) {
		this.listObject = listObject;
	}
	/**
	 * @return Returns the detail.
	 */
	public Object getDetail() {
		return detail;
	}
	/**
	 * @param detail The detail to set.
	 */
	public void setDetail(Object detail) {
		this.detail = detail;
	}
}
