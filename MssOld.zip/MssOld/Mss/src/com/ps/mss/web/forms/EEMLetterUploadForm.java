package com.ps.mss.web.forms;

import org.apache.struts.upload.FormFile;
import java.util.List;

public class EEMLetterUploadForm extends EEMSubMenuForm {

	private String customerId;
	private String memberId;
	private String userId;
	private String fileName;
	private FormFile file;
	private String recordType;
	private String fileBatchId;
	private List memberLetters;

	private String printRequestDate;
	private String origMailDate;
	private String lastMailDate;
	private String printDate;
	private String reprintDate;
	private String responseDueDate;
	private String responseDate;

	private String uploadedFilePath;
	
	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the memberId
	 */
	public String getMemberId() {
		return memberId;
	}

	/**
	 * @param memberId the memberId to set
	 */
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the file
	 */
	public FormFile getFile() {
		return file;
	}

	/**
	 * @param file the file to set
	 */
	public void setFile(FormFile file) {
		this.file = file;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return the memberLetters
	 */
	public List getMemberLetters() {
		return memberLetters;
	}

	/**
	 * @param memberLetters the memberLetters to set
	 */
	public void setMemberLetters(List memberLetters) {
		this.memberLetters = memberLetters;
	}

	/**
	 * @return the recordType
	 */
	public String getRecordType() {
		return recordType;
	}

	/**
	 * @param recordType the recordType to set
	 */
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	/**
	 * @return the fileBatchId
	 */
	public String getFileBatchId() {
		return fileBatchId;
	}

	/**
	 * @param fileBatchId the fileBatchId to set
	 */
	public void setFileBatchId(String fileBatchId) {
		this.fileBatchId = fileBatchId;
	}


	/**
	 * @return the printRequestDate
	 */
	public String getPrintRequestDate() {
		return printRequestDate;
	}

	/**
	 * @param printRequestDate the printRequestDate to set
	 */
	public void setPrintRequestDate(String printRequestDate) {
		this.printRequestDate = printRequestDate;
	}

	/**
	 * @return the origMailDate
	 */
	public String getOrigMailDate() {
		return origMailDate;
	}

	/**
	 * @param origMailDate the origMailDate to set
	 */
	public void setOrigMailDate(String origMailDate) {
		this.origMailDate = origMailDate;
	}

	/**
	 * @return the lastMailDate
	 */
	public String getLastMailDate() {
		return lastMailDate;
	}

	/**
	 * @param lastMailDate the lastMailDate to set
	 */
	public void setLastMailDate(String lastMailDate) {
		this.lastMailDate = lastMailDate;
	}

	/**
	 * @return the printDate
	 */
	public String getPrintDate() {
		return printDate;
	}

	/**
	 * @param printDate the printDate to set
	 */
	public void setPrintDate(String printDate) {
		this.printDate = printDate;
	}

	/**
	 * @return the reprintDate
	 */
	public String getReprintDate() {
		return reprintDate;
	}

	/**
	 * @param reprintDate the reprintDate to set
	 */
	public void setReprintDate(String reprintDate) {
		this.reprintDate = reprintDate;
	}

	/**
	 * @return the responseDueDate
	 */
	public String getResponseDueDate() {
		return responseDueDate;
	}

	/**
	 * @param responseDueDate the responseDueDate to set
	 */
	public void setResponseDueDate(String responseDueDate) {
		this.responseDueDate = responseDueDate;
	}

	/**
	 * @return the responseDate
	 */
	public String getResponseDate() {
		return responseDate;
	}

	/**
	 * @param responseDate the responseDate to set
	 */
	public void setResponseDate(String responseDate) {
		this.responseDate = responseDate;
	}

	/**
	 * @return the uploadedFilePath
	 */
	public String getUploadedFilePath() {
		return uploadedFilePath;
	}

	/**
	 * @param uploadedFilePath the uploadedFilePath to set
	 */
	public void setUploadedFilePath(String uploadedFilePath) {
		this.uploadedFilePath = uploadedFilePath;
	}
	//IFOX-00430896 - Ltter Upload Changes for Sentara -start
	private String ftpFilePath;
	private String upldProfInd;

	/**
	 * @return the ftpFilePath
	 */
	public String getFtpFilePath() {
		return ftpFilePath;
	}

	/**
	 * @param ftpFilePath the ftpFilePath to set
	 */
	public void setFtpFilePath(String ftpFilePath) {
		this.ftpFilePath = ftpFilePath;
	}

	/**
	 * @return the upldProfInd
	 */
	public String getUpldProfInd() {
		return upldProfInd;
	}

	/**
	 * @param upldProfInd the upldProfInd to set
	 */
	public void setUpldProfInd(String upldProfInd) {
		this.upldProfInd = upldProfInd;
	}
	
	private String ltrupload;

	/**
	 * @return the ltrupload
	 */
	public String getLtrupload() {
		return ltrupload;
	}

	/**
	 * @param ltrupload the ltrupload to set
	 */
	public void setLtrupload(String ltrupload) {
		this.ltrupload = ltrupload;
	}
	
	
	//IFOX-00430896 - Ltter Upload Changes for Sentara -end

}