/*
 * $Id: EEMMbrDshBrdForm.java,v 1.1 2014/06/26 07:55:46 praveen Exp $
 */
package com.ps.mss.web.forms;

import java.util.List;

/**
 * @author Raghu Gorur
 *
 */
public class EEMMbrDshBrdForm extends EEMForm {
	
	private String customerId;
	private String category;
	private String dateRange;
	private String supplId;
	private String user;
	
	private List lstDashBoard;
	private List lstWorkload;
	private List lstDshBrdDrill;
	
	private String selectedSubMenuTab;
	
	/**
	 * @return Returns the customerId.
	 */
	public String getCustomerId() {
		return customerId;
	}
	/**
	 * @param customerId The customerId to set.
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	/**
	 * @return Returns the dateRange.
	 */
	public String getDateRange() {
		return dateRange;
	}
	/**
	 * @param dateRange The dateRange to set.
	 */
	public void setDateRange(String dateRange) {
		this.dateRange = dateRange;
	}
	/**
	 * @return Returns the lstDashBoard.
	 */
	public List getLstDashBoard() {
		return lstDashBoard;
	}
	/**
	 * @param lstDashBoard The lstDashBoard to set.
	 */
	public void setLstDashBoard(List lstDashBoard) {
		this.lstDashBoard = lstDashBoard;
	}
	/**
	 * @return Returns the lstDshBrdDrill.
	 */
	public List getLstDshBrdDrill() {
		return lstDshBrdDrill;
	}
	/**
	 * @param lstDshBrdDrill The lstDshBrdDrill to set.
	 */
	public void setLstDshBrdDrill(List lstDshBrdDrill) {
		this.lstDshBrdDrill = lstDshBrdDrill;
	}
	/**
	 * @return Returns the supplId.
	 */
	public String getSupplId() {
		return supplId;
	}
	/**
	 * @param supplId The supplId to set.
	 */
	public void setSupplId(String supplId) {
		this.supplId = supplId;
	}
	/**
	 * @return Returns the lstWorkload.
	 */
	public List getLstWorkload() {
		return lstWorkload;
	}
	/**
	 * @param lstWorkload The lstWorkload to set.
	 */
	public void setLstWorkload(List lstWorkload) {
		this.lstWorkload = lstWorkload;
	}
	/**
	 * @return Returns the selectedSubMenuTab.
	 */
	public String getSelectedSubMenuTab() {
		return selectedSubMenuTab;
	}
	/**
	 * @param selectedSubMenuTab The selectedSubMenuTab to set.
	 */
	public void setSelectedSubMenuTab(String selectedSubMenuTab) {
		this.selectedSubMenuTab = selectedSubMenuTab;
	}
	/**
	 * @return Returns the user.
	 */
	public String getUser() {
		return user;
	}
	/**
	 * @param user The user to set.
	 */
	public void setUser(String user) {
		this.user = user;
	}
	/**
	 * @return Returns the category.
	 */
	public String getCategory() {
		return category;
	}
	/**
	 * @param category The category to set.
	 */
	public void setCategory(String category) {
		this.category = category;
	}
}
