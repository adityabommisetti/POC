package com.ps.mss.web.forms;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import com.ps.mss.model.DiscrepancyDashBoardVO;
import com.ps.mss.model.DiscrepancySummaryVOList;

/**
 * Form bean for a Struts application.
 * @version 	1.0
 * @author
 */
public class DiscrepancyDashBoardForm extends BaseForm {

	private DiscrepancyDashBoardVO [] discrepancyDashBoardVO = null;
	private DiscrepancySummaryVOList discrepancySummaryVOList= null ;
	
	/**
	 * @return Returns the discrepancySummaryVOList.
	 */
	public DiscrepancySummaryVOList getDiscrepancySummaryVOList() {
		return discrepancySummaryVOList;
	}
	/**
	 * @param discrepancySummaryVOList The discrepancySummaryVOList to set.
	 */
	public void setDiscrepancySummaryVOList(
			DiscrepancySummaryVOList discrepancySummaryVOList) {
		this.discrepancySummaryVOList = discrepancySummaryVOList;
	}
	/**
	 * @return Returns the discrepancyDashBoardVO.
	 */
	public DiscrepancyDashBoardVO[] getDiscrepancyDashBoardVO() {
		return discrepancyDashBoardVO;
	}
	/**
	 * @param discrepancyDashBoardVO The discrepancyDashBoardVO to set.
	 */
	public void setDiscrepancyDashBoardVO(
			DiscrepancyDashBoardVO[] discrepancyDashBoardVO) {
		this.discrepancyDashBoardVO = discrepancyDashBoardVO;
	}
	
    public void reset(ActionMapping mapping, HttpServletRequest request) {

        // Reset field values here.

    }

    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {

        ActionErrors errors = new ActionErrors();
        // Validate the fields in your form, adding
        // adding each error to this.errors as found, e.g.

        // if ((field == null) || (field.length() == 0)) {
        //   errors.add("field", new org.apache.struts.action.ActionError("error.field.required"));
        // }
        return errors;

    }
	
}
