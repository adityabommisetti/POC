/*
 * $Id: SearchProfileAction.java,v 1.1 2014/06/26 07:56:47 praveen Exp $
 */

package com.ps.mss.web.actions;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.Action;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.framework.Constants;
import com.ps.mss.manager.MasterManager;
import com.ps.mss.manager.ProfileManager;
import com.ps.mss.manager.WorkQueueManager;
import com.ps.mss.model.FilterVO;
import com.ps.mss.model.ProfileSearchDetailVO;
import com.ps.mss.model.ProfileSearchVO;
import com.ps.mss.model.ProfileSearchVOList;
import com.ps.mss.web.forms.SearchProfileForm;
import com.ps.mss.web.helper.DispatchActionHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.util.NameValuePair;
import com.ps.util.StringUtil;

/**
 * @author palat.pradeep
 */
public class SearchProfileAction extends Action {

	private static Logger logger=LoggerFactory.getLogger(SearchProfileAction.class);


	public SearchProfileAction(){
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("Called in constructor of SearchProfileAction");
//		logger.info("Called in constructor of SearchProfileAction");
		logger.info(LoggerConstants.methodEndLevel());
	}

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		String target = "error";
		SessionHelper sessionHelper = new SessionHelper(request);
		logger.info("In Execute of SearchProfileAction ");
		try{	
			//Recon Work Queue changes : start
			SearchProfileForm searchForm = (SearchProfileForm) form;
			//Recon Work Queue changes : end
			if (  Constants.PROFILE_SHOW_PARM_DETAILS.equals(request.getParameter("method"))){
			SearchProfileForm searchProfileForm = (SearchProfileForm) form;			
			searchProfileForm.init(request);
			target = "showParmDetail";
			
		}else {
			
			SearchProfileForm searchProfileForm = (SearchProfileForm) form;			
			searchProfileForm.init(request);
			target = getProfileSearchResult(request, searchProfileForm);
			NameValuePair[] planIdArr = searchProfileForm.getPlanNameList();
			
			if(planIdArr != null && planIdArr.length == 1) {
				searchProfileForm.setPlanName(planIdArr[0].getName());
			}
			
		}
		}catch ( Exception ex){
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			logger.debug("Exception in execute "  + ex);
//			logger.error("Exception in execute "  + ex);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(target);
	}

	/**
	 * This method fetches the Profile Search Result  
	 * @param request
	 * @param searchProfileForm
	 * @return
	 * @throws Exception
	 */
	private String getProfileSearchResult(HttpServletRequest request, SearchProfileForm searchProfileForm) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		List uiContext = null;
		FilterVO filterVO = null;			
		String target = "error";
		SessionHelper sessionHelper = new SessionHelper(request);
		
		Map profileMap = null ;
		String actionType = searchProfileForm.getActionType();			
		logger.debug("actionType " + actionType);
		String pdFetchList = searchProfileForm.getPdFetchList();
		String move = null;
		String print = request.getParameter("print");
		
		if (!"summaryPage".equals(actionType) && ! "search".equals(actionType)) {
			profileMap = (Map)sessionHelper.getAttribute(Constants.SESSION_PROFILE_DETAIL_MAP);
		}
		
		if(StringUtil.trimToNull(searchProfileForm.getMenuName())==null && request.getParameter("menuName")!=null){
			searchProfileForm.setMenuName(request.getParameter("menuName"));
        }
		
		int selectedRowNo = 0;
		if(profileMap!=null){
			Integer temp = ((Integer)profileMap.get(Constants.PAGE_SELECTED_LINE));
			if(temp != null)
				selectedRowNo = temp.intValue() ; 
		}
		
		Map planMap = sessionHelper.getPlanForParts();

		// Fetch the Date range for search
		Map profileDateRangeMap = null;
		
		profileDateRangeMap = (Map)sessionHelper.getAttribute(Constants.SESSION_PROFILE_DATE_RANGE);
		if ( profileDateRangeMap == null){
			profileDateRangeMap = ProfileManager.getProfileDateRange ( planMap, sessionHelper.getActiveDataBaseName());
			sessionHelper.setAttribute(Constants.SESSION_PROFILE_DATE_RANGE, profileDateRangeMap);
		}
		
		//Fetch the list of Plan, PBP and Segment Ids
		Map planPbpSegMap = null;
		planPbpSegMap = (Map)sessionHelper.getAttribute(Constants.SESSION_PROFILE_PLAN_PBP_SGMT);
		if ( planPbpSegMap == null){
			planPbpSegMap = ProfileManager.getPlanPbpSegMap ( planMap, sessionHelper.getActiveDataBaseName());
			sessionHelper.setAttribute(Constants.SESSION_PROFILE_PLAN_PBP_SGMT, planPbpSegMap);
		}
		
		filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_PROFILE_DETAIL_FILTERVO);
		uiContext = (List)sessionHelper.getAttribute(Constants.SESSION_PROFILE_DETAIL_STATUS);
		target = "successForPrint";		
		
		Map detailProfileMap = null;
		Map detailPBPProfileMap = null;
		if( print != null){
			
			String uiContextRange = StringUtil.nonNullTrim(request.getParameter("uiContextRange"));
			Integer maxRecordCount = MasterManager.getMaxRecordCount();
			move = "current";
			request.setAttribute("uiContextRange",uiContextRange);
			//In the case of all we have to fetch records( records count is  according to sysparm table ) for selected line.
			if(Constants.CONSTANTS_ALL.equals(uiContextRange)){ 
				move = "first";
				if(profileMap!= null){
					if ( Constants.PARTC.equals(filterVO.getPartName())) { //when part C has selectd line
						detailProfileMap =  profileMap != null ?(Map)profileMap.get(Constants.PARTC_PROFILE_DETAIL_MAP) : null ;
						request.setAttribute("showProfileList",Constants.PARTC);
					} else { // when part D has selected line
						detailProfileMap =  profileMap != null ?(Map)profileMap.get(Constants.PARTD_PROFILE_DETAIL_MAP) : null ;
						request.setAttribute("showPDProfilePlnList",Constants.PARTD);
						
						detailPBPProfileMap =  profileMap != null ?(Map)profileMap.get(Constants.PARTD_PBP_PROFILE_DETAIL_MAP) : null ;
						request.setAttribute("showPDProfilePBPList",Constants.PARTD);

					}
					
					if(detailProfileMap != null){
						detailProfileMap.put(Constants.SESSION_MAX_RECORD_COUNT,maxRecordCount);
						detailProfileMap.put(Constants.UI_CONTEXT_RANGE,Constants.CONSTANTS_ALL);
					}
					
					if(detailPBPProfileMap != null){
						detailPBPProfileMap.put(Constants.SESSION_MAX_RECORD_COUNT,maxRecordCount);
						detailPBPProfileMap.put(Constants.UI_CONTEXT_RANGE,Constants.CONSTANTS_ALL);
					}					
				}
			}
			
			String searchCriteriaHeader = ProfileManager.getSearchCriteriaHeader(filterVO, Constants.PROFILE_SEARCH, searchProfileForm.getMenuName(), sessionHelper.getActiveDataBaseName());
   			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCriteriaHeader);			
			
		}
		//Recon Work Queue changes : start
		else if(actionType!= null && 
				(actionType.equals("autoAssign")||actionType.equals("updateAutoAssign") )){
			System.out.println("In auto Assign");
			filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_PROFILE_DETAIL_FILTERVO);
			filterVO = setFilterVO(searchProfileForm, filterVO);
			searchProfileForm.setUpdateMessage("");
			if(actionType.equals("updateAutoAssign")){
				int count=ProfileManager.updateAutoAssignTask(planMap,sessionHelper.getActiveDataBaseName(),
						searchProfileForm.getAutoAssignDisc(),searchProfileForm.getAutoAssignedTo(),sessionHelper.getUserId(),filterVO);
			    if(count > 0)
			    	searchProfileForm.setUpdateMessage("Auto Assignment successful to selected user" );
			    else 
			    	searchProfileForm.setUpdateMessage("An Unexpected Database Response has occured");
			    
			}
			List usrList = WorkQueueManager.getUsersList(sessionHelper.getMfId(),sessionHelper.getActiveDataBaseName(),sessionHelper.getPlanForParts());
			searchProfileForm.setAssignedToList(usrList);
			Map autoAsgnUserMap = ProfileManager.getAutoAssignMap(usrList, sessionHelper.getActiveDataBaseName());
			searchProfileForm.setUserAsgnMap(autoAsgnUserMap);
			sessionHelper.setAttribute("autoAsgnMap", autoAsgnUserMap);
			sessionHelper.setAttribute("usersList", usrList);
			filterVO = setFilterVO(searchProfileForm, filterVO);
			sessionHelper.setAttribute(Constants.SESSION_PROFILE_DETAIL_FILTERVO, filterVO);
			uiContext = (List) sessionHelper.getAttribute(Constants.SESSION_PROFILE_DETAIL_STATUS);
			
			target = "autoAssignPage";
			DispatchActionHelper.setTabAndFormName(request, Constants.PROFILE_MENU, "SearchProfileForm");
		}
		
		//Recon Work Queue changes : end
		else{
			filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_PROFILE_DETAIL_FILTERVO);
			filterVO = setFilterVO(searchProfileForm, filterVO);
			sessionHelper.setAttribute(Constants.SESSION_PROFILE_DETAIL_FILTERVO, filterVO);
			uiContext = (List) sessionHelper.getAttribute(Constants.SESSION_PROFILE_DETAIL_STATUS);
			target = "searchProfile";
			DispatchActionHelper.setTabAndFormName(request, Constants.PROFILE_MENU, "SearchProfileForm");
		}
		
		if(StringUtil.trimToNull(filterVO.getPlanName())!= null ) { //This condition is true when use click first time on profile detail tab
			
			logger.debug(" Part C " + planMap.get(Constants.PartC_Plan));
			logger.debug(" Part D " + planMap.get(Constants.PartD_Plan));
			
			filterVO.setSearchType(sessionHelper.evaluteSearchType(filterVO));
			
			String discInd = null;
			if(filterVO!=null){
				discInd = filterVO.getDiscrepancyIndicator();  

				if(request.getParameter("print") != null && Constants.CONSTANTS_ALL.equals(StringUtil.nonNullTrim(request.getParameter("uiContextRange")))){					
					 filterVO.setDiscrepancyIndicator(filterVO.getPartName());
				}
				
			}
			
			ProfileSearchDetailVO profileSearchDetailVO = ProfileManager.getProfileSearchDetailVO(filterVO,profileMap,move, sessionHelper.getActiveDataBaseName(),planMap, pdFetchList,searchProfileForm.getMenuName(), profileDateRangeMap);
			if(detailProfileMap != null){
				detailProfileMap.put(Constants.SESSION_MAX_RECORD_COUNT,new Integer(10));
				detailProfileMap.remove(Constants.UI_CONTEXT_RANGE);
			}
			
			if(detailPBPProfileMap != null){
				detailPBPProfileMap.put(Constants.SESSION_MAX_RECORD_COUNT,new Integer(10));
				detailPBPProfileMap.remove(Constants.UI_CONTEXT_RANGE);
			}			
			filterVO.setDiscrepancyIndicator(discInd);
			
			if(profileSearchDetailVO != null){
				searchProfileForm.setProfileSearchDetailVO(profileSearchDetailVO);
				if(print == null)
					setDetailMap(profileMap,profileSearchDetailVO,sessionHelper,searchProfileForm.getMenuName(),filterVO.getDiscrepancyIndicator(), pdFetchList);
			}								
		}	
		
		setUiContext(uiContext,searchProfileForm);
		setForm(searchProfileForm ,  filterVO);			
		
		searchProfileForm.init(request);
		searchProfileForm.setPaymentMonthMap(profileDateRangeMap);
		searchProfileForm.setPlanPbpSegMap(planPbpSegMap);
		logger.info(LoggerConstants.methodEndLevel());
		return target;
	}
	
	/**
	 * This method sets the values in the filterVO to the SearchProfileForm 
	 * @param searchProfileForm
	 * @param filterVO
	 * @return
	 */
	private FilterVO setFilterVO ( SearchProfileForm searchProfileForm, FilterVO filterVO){
		logger.info(LoggerConstants.methodStartLevel());
		String actionType = searchProfileForm.getActionType();
			
			String parmCode = "";
			
			if ( filterVO == null){
                filterVO = new FilterVO();
                filterVO.setDiscrepancyIndicator(Constants.PARTC);
                logger.info(LoggerConstants.methodEndLevel());
                return filterVO;
			}
			
			if ("search".equals(actionType) || "summaryPage".equals(actionType)) {
				filterVO.setPlanName(searchProfileForm.getPlanName());
				filterVO.setStartDate(searchProfileForm.getFromDate());
				filterVO.setEndDate(searchProfileForm.getToDate());
				filterVO.setPartName(searchProfileForm.getPartName());
				
				if ( ! StringUtil.isNullOrEmpty(searchProfileForm.getParameterCodeAdv())){
					parmCode =  searchProfileForm.getParameterCodeAdv() + "%";
					
				}else if ( ! StringUtil.isNullOrEmpty(searchProfileForm.getParameterCode())){
					parmCode =  searchProfileForm.getParameterCode() + "%";
				}
				 
				filterVO.setParameterCode(parmCode);
				filterVO.setPbpId(searchProfileForm.getPbpId());
				filterVO.setSegmentId(searchProfileForm.getSegmentId());
				filterVO.setSearchType(searchProfileForm.getSearchType());
				String indicator = StringUtil.trimToNull(searchProfileForm.getPartName());
				filterVO.setDiscrepancyIndicator(indicator); 				
			}
			logger.info(LoggerConstants.methodEndLevel());
			return filterVO;
	}
	
	/**
	 * This method sets the values from the filterVO to the Form
	 * @param discrpDetailForm
	 * @param filterVO
	 */
	private void setForm(SearchProfileForm searchProfileForm, FilterVO filterVO) {		
		logger.info(LoggerConstants.methodStartLevel());
		searchProfileForm.setPlanName(StringUtil.nonNullTrim(filterVO.getPlanName()));
		searchProfileForm.setPartName(filterVO.getDiscrepancyIndicator());
		searchProfileForm.setFromDate(filterVO.getStartDate());
		searchProfileForm.setToDate(filterVO.getEndDate());
		
		String parmCode = filterVO.getParameterCode();
		if ( !StringUtil.isNullOrEmpty(parmCode)){
			if ( parmCode.endsWith("%")){
				parmCode = parmCode.substring(0, parmCode.length()-1);
			}
		}else{
			parmCode = Constants.PROFILE_PARM_ADVANCED_SEARCH;
		}
		
		searchProfileForm.setParameterCodeAdv(parmCode);
		searchProfileForm.setPbpId(filterVO.getPbpId());
		searchProfileForm.setSegmentId(filterVO.getSegmentId());
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	
	/**
	 * This method sets the UIContext for SearchProfile detail
	 * @param uiContext
	 * @param baseForm
	 */
	private void setUiContext(List uiContext, SearchProfileForm searchProfileForm) {
		logger.info(LoggerConstants.methodStartLevel());
		if(uiContext != null) {
			String contextString = null;
			Iterator it = uiContext.iterator();
			while(it.hasNext()) {
				contextString = (String) it.next();
				if(Constants.PROFILE_PARTC_PLNLIST.equals(contextString)) {
					searchProfileForm.setShowProfileList(contextString);
				} else if(Constants.PROFILE_PARTD_PLNLIST.equals(contextString)) {
					searchProfileForm.setShowPDProfilePlnList(contextString);
				} else if(Constants.PROFILE_PARTD_PBPLIST.equals(contextString)) {
					searchProfileForm.setShowPDProfilePBPList(contextString);
				}
			}
		} else { // This is for default context because in defult detail  must be open
			searchProfileForm.setShowProfileList(Constants.PROFILE_PARTC_PLNLIST); // Show only the Part C on load
			searchProfileForm.setShowPDProfilePlnList(Constants.PROFILE_PARTD_PLNLIST);
			searchProfileForm.setShowPDProfilePBPList(Constants.PROFILE_PARTD_PBPLIST);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}	
	
	/***
	 * This set detailMap which contain total number of page ,records , first and last record of profileList 
	 * @param profileMap
	 * @param profileSearchDetailVO
	 * @param sessionHelper
	 * @param menuName
	 * @param partName
	 * @param pdFetchList
	 */
	
	private void setDetailMap(Map profileMap, ProfileSearchDetailVO profileSearchDetailVO, SessionHelper sessionHelper, String menuName, String partName, String pdFetchList) {
		logger.info(LoggerConstants.methodStartLevel());
		if(profileSearchDetailVO != null) {
			if(profileMap == null )
				profileMap = new HashMap ();
			if(Constants.PARTC.equals(partName)) {
				profileMap.put(Constants.PARTC_PROFILE_DETAIL_MAP,createMap(profileSearchDetailVO.getPartCProfileSearchVOList()));
				
			} else if(Constants.PARTD.equals(partName)) {
				if ( Constants.PROFILE_PARTD_FETCH_BOTHLIST.equals(pdFetchList) || Constants.PROFILE_PARTD_FETCH_PLNLIST.equals(pdFetchList)){
					profileMap.put(Constants.PARTD_PROFILE_DETAIL_MAP,createMap(profileSearchDetailVO.getPartDProfileSearchVOList()));
				}
				
				if ( Constants.PROFILE_PARTD_FETCH_BOTHLIST.equals(pdFetchList) || Constants.PROFILE_PARTD_FETCH_PBPLIST.equals(pdFetchList)){
					profileMap.put(Constants.PARTD_PBP_PROFILE_DETAIL_MAP,createPbpMap(profileSearchDetailVO.getPartDPBPProfileSearchVOList()));
				}
			}
			
			profileMap.put(Constants.PAGE_SELECTED_LINE , new Integer("0"));
			
			profileMap.remove(Constants.SESSION_MAX_RECORD_COUNT);
			sessionHelper.setAttribute(Constants.SESSION_PROFILE_DETAIL_MAP,profileMap);	
		}
		logger.info(LoggerConstants.methodEndLevel());
	}	
	
	/**
	 * 
	 * @param profileSearchVOList
	 * @return
	 */
	private Map createMap(ProfileSearchVOList profileSearchVOList){
		logger.info(LoggerConstants.methodStartLevel());
		Map profileMap = null;
		if ( profileSearchVOList != null) {
			profileMap = new HashMap ();
				ProfileSearchVO [] profileSearchVOArr = profileSearchVOList.getProfileSearchVOList();
				if ( profileSearchVOArr != null ){
					profileMap.put(Constants.FIRST_DETAIL_VO, profileSearchVOArr[0]);
					profileMap.put(Constants.LAST_DETAIL_VO, profileSearchVOArr[profileSearchVOArr.length-1]);
					profileMap.put(Constants.CURRENT_PAGE, profileSearchVOList.getCurrentPage());
					profileMap.put(Constants.PAGE_NUMBER , new Integer(profileSearchVOList.getPageNumber()));
				}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return profileMap;
	}
	
	
	/**
	 * 
	 * @param profileSearchVOList
	 * @return
	 */
	private Map createPbpMap(ProfileSearchVOList profileSearchVOList){
		logger.info(LoggerConstants.methodStartLevel());
		Map profileMap = null;
		if ( profileSearchVOList != null) {
			profileMap = new HashMap ();
				ProfileSearchVO [] profileSearchVOArr = profileSearchVOList.getProfileSearchVOList();
				if ( profileSearchVOArr != null ){
					profileMap.put(Constants.FIRST_PBP_DETAIL_VO, profileSearchVOArr[0]);
					profileMap.put(Constants.LAST_PBP_DETAIL_VO, profileSearchVOArr[profileSearchVOArr.length-1]);
					profileMap.put(Constants.CURRENT_PBP_DISCRP_PAGE, profileSearchVOList.getCurrentPage());
					profileMap.put(Constants.PBP_PAGE_NUMBER , new Integer(profileSearchVOList.getPageNumber()));
				}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return profileMap;
	}		
	
	private void showProfileParmDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("Details called");	
		//logger.info("Details called");	
		logger.info(LoggerConstants.methodEndLevel());
	}
}
