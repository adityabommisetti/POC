package com.ps.mss.web.forms;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import com.ps.mss.dao.model.DiscViewReconVO;
import com.ps.mss.dao.model.McaidAnomSummDetailDataVO;
import com.ps.mss.model.DiscrepancyDashBoardVO;
import com.ps.mss.model.DiscrepancySummaryVOList;
import com.ps.mss.model.McaidReconAnomVO;

/**
 * Form bean for a Struts application.
 * @version 	1.0
 * @author
 */
public class McaidReconDiscForm extends McaidReconBaseForm {
	
	private String pbpId;
	private String year;
	private String month;
	private String quarter;
	
	private String cmsPaid;
	private String planExpected;
	private String diffrence;	
	
	private String count ="0";
	private String open ="0" ;
	private String inProgress ="0";
	private String forceClosed ="0";
	private String resolved ="0";	
	
		
	private List mcaidDiscDsbPBPLst;

	//-------------- Summary-------------------	
	
		private String summSrchPbp;
		private String summSrchYear;
		private String summSrchQtr;
		private String summSrchMonth;
		private String summSrchStatus;
		private String summSrchGoPbp;
		private String summSrchGoStatus;
		private String summSrchType;
		private String summSrchMedicaidId;
		private String summSrchFromEffDate;
		private String summSrchToEffDate;
		private String summSrchFromUpdtDate;
		private String summSrchToUpdtDate;
		private String summSrchUpdtUserId;
		private String summSrchDiscrpCd; 
		
		//State and plan value addition: start
		private String summSrchStateValue;
		private String summSrchPlanValue;
		//State and plan value addition: end
		
		private List summSrchPbpLst;
		private List summSrchStatusLst;
		private List summSrchTypeLst;
		
		// Details Status List
		private List summDetailStatusLst;
		private Map summDetailStatusChngLst;
		// Details Status List
		
		private String summPageLabel1;
		private String summPageLabel2;
		private int summSrchListRowSelect;
		
		//--Summary Page section-1- Anomaly List
		private List summAnomListLst;
		private List summAnomTotalLst;
		/**
		 * @return the summAnomTotalLst
		 */
		public List getSummAnomTotalLst() {
			return summAnomTotalLst;
		}


		/**
		 * @param summAnomTotalLst the summAnomTotalLst to set
		 */
		public void setSummAnomTotalLst(List summAnomTotalLst) {
			this.summAnomTotalLst = summAnomTotalLst;
		}
		private int summAnomLstPageNbr;
		private String summAnomLstPageType;
		
		//--Summary Page section-2	
		private McaidAnomSummDetailDataVO anomSummDetailDataVo = new McaidAnomSummDetailDataVO();
	
	private String medicaidId;
	private String discrepancy;
	private String effDate;
	private String discStatuc;
	private String state;
	private String planId;
	private String userId;
	private String lastUpdtTime;
	private String firstName;
	private String lastName;
	private String suppIdEffDate;
	private String recentSuppId;
	private String viewPymtPageLabel;
	private String applyDate;
	private String adjCode;
	private String adjDesc;
	private List mcaidViewPymntDetailLst;
	private String changeStatus;
	private String changeComment;
	
	private String popupMsg = "";
	private String summCmsPaid;
	private String summPlanExpected;
	private String summDataDiffrence;
	
	private DiscrepancyDashBoardVO [] discrepancyDashBoardVO = null;
	private DiscrepancySummaryVOList discrepancySummaryVOList= null ;
	
	private String strPlanId;
	private String strCreateTime;
	
	private String discrepancyCategory;
	private List descrepancyCategoryList;
	private List discrpDetailsLst;
	private List discrpDetailsTotalLst;
	
	//Added to export more than 10000 records : start
	
		private String countOfRecords;
		
		
		public String getCountOfRecords() {
			return countOfRecords;
		}


		public void setCountOfRecords(String countOfRecords) {
			this.countOfRecords = countOfRecords;
		}
		private String extractQuery;
		
		public String getExtractQuery() {
			return extractQuery;
		}


		public void setExtractQuery(String extractQuery) {
			this.extractQuery = extractQuery;
		}

		//Added to export more than 10000 records : end
		
		//IFOX-00407694-FCLO/WRTO Changes: start
		
		private String [] select;
		private String wrtoInd;
		
		
	
		/**
		 * @return the wrtoInd
		 */
		public String getWrtoInd() {
			return wrtoInd;
		}


		/**
		 * @param wrtoInd the wrtoInd to set
		 */
		public void setWrtoInd(String wrtoInd) {
			this.wrtoInd = wrtoInd;
		}
		private String fcloStartDate;
		
		public String getFcloStartDate(){
			return fcloStartDate;
		}
		
		/**
		 * @return the select
		 */
		public String[] getSelect() {
			return select;
		}


		/**
		 * @param select the select to set
		 */
		public void setSelect(String[] select) {
			this.select = select;
		}


		public void setFcloStartDate(String fcloStartDate){
			this.fcloStartDate = fcloStartDate;
		}
		
		
		private String fcloEndDate;
		
		public String getFcloEndDate(){
			return fcloEndDate;
		}
		
		public void setFcloEndDate(String fcloEndDate){
			this.fcloEndDate = fcloEndDate;
		}
		
		private String reopenDates;
		
		public String getReopenDates(){
			return reopenDates;
		}
		public void setReopenDates(String reopenDates){
			this.reopenDates = reopenDates;
		}
		
		private String defaultValue;
		
		public String getDefaultValue(){
			return defaultValue;
		}
		
		public void setDefaultValue(String defaultValue){
			this.defaultValue = defaultValue;
		}
		
		private String changedComment;
		
		public String getChangedComment(){
			return changedComment;
		}
		public void setChangedComment(String changedComment){
			this.changedComment = changedComment;
		}
		
		
		

		private List discrpFcloLst;
		public List getDiscrpFcloLst() {
			return discrpFcloLst;
		}

		public void setDiscrpFcloLst(List discrpFcloLst) {
			this.discrpFcloLst = discrpFcloLst;
		}
		//IFOX-00407694-FCLO/WRTO Changes: end
	/**
	 * @return Returns the discrepancySummaryVOList.
	 */
	public DiscrepancySummaryVOList getDiscrepancySummaryVOList() {
		return discrepancySummaryVOList;
	}
	/**
	 * @param discrepancySummaryVOList The discrepancySummaryVOList to set.
	 */
	public void setDiscrepancySummaryVOList(
			DiscrepancySummaryVOList discrepancySummaryVOList) {
		this.discrepancySummaryVOList = discrepancySummaryVOList;
	}
	/**
	 * @return Returns the discrepancyDashBoardVO.
	 */
	public DiscrepancyDashBoardVO[] getDiscrepancyDashBoardVO() {
		return discrepancyDashBoardVO;
	}
	/**
	 * @param discrepancyDashBoardVO The discrepancyDashBoardVO to set.
	 */
	public void setDiscrepancyDashBoardVO(
			DiscrepancyDashBoardVO[] discrepancyDashBoardVO) {
		this.discrepancyDashBoardVO = discrepancyDashBoardVO;
	}
	
    public void reset(ActionMapping mapping, HttpServletRequest request) {

        // Reset field values here.

    }

    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {

        ActionErrors errors = new ActionErrors();
        // Validate the fields in your form, adding
        // adding each error to this.errors as found, e.g.

        // if ((field == null) || (field.length() == 0)) {
        //   errors.add("field", new org.apache.struts.action.ActionError("error.field.required"));
        // }
        return errors;

    }
	/**
	 * @return the pbpId
	 */
	public String getPbpId() {
		return pbpId;
	}
	/**
	 * @param pbpId the pbpId to set
	 */
	public void setPbpId(String pbpId) {
		this.pbpId = pbpId;
	}
	/**
	 * @return the year
	 */
	public String getYear() {
		return year;
	}
	/**
	 * @param year the year to set
	 */
	public void setYear(String year) {
		this.year = year;
	}
	/**
	 * @return the month
	 */
	public String getMonth() {
		return month;
	}
	/**
	 * @param month the month to set
	 */
	public void setMonth(String month) {
		this.month = month;
	}
	/**
	 * @return the quarter
	 */
	public String getQuarter() {
		return quarter;
	}
	/**
	 * @param quarter the quarter to set
	 */
	public void setQuarter(String quarter) {
		this.quarter = quarter;
	}
	/**
	 * @return the cmsPaid
	 */
	public String getCmsPaid() {
		return cmsPaid;
	}
	/**
	 * @param cmsPaid the cmsPaid to set
	 */
	public void setCmsPaid(String cmsPaid) {
		this.cmsPaid = cmsPaid;
	}
	/**
	 * @return the planExpected
	 */
	public String getPlanExpected() {
		return planExpected;
	}
	/**
	 * @param planExpected the planExpected to set
	 */
	public void setPlanExpected(String planExpected) {
		this.planExpected = planExpected;
	}
	/**
	 * @return the diffrence
	 */
	public String getDiffrence() {
		return diffrence;
	}
	/**
	 * @param diffrence the diffrence to set
	 */
	public void setDiffrence(String diffrence) {
		this.diffrence = diffrence;
	}
	/**
	 * @return the mcaidDiscDsbPBPLst
	 */
	public List getMcaidDiscDsbPBPLst() {
		return mcaidDiscDsbPBPLst;
	}
	/**
	 * @param mcaidDiscDsbPBPLst the mcaidDiscDsbPBPLst to set
	 */
	public void setMcaidDiscDsbPBPLst(List mcaidDiscDsbPBPLst) {
		this.mcaidDiscDsbPBPLst = mcaidDiscDsbPBPLst;
	}
	/**
	 * @return the count
	 */
	public String getCount() {
		return count;
	}
	/**
	 * @param count the count to set
	 */
	public void setCount(String count) {
		this.count = count;
	}
	/**
	 * @return the open
	 */
	public String getOpen() {
		return open;
	}
	/**
	 * @param open the open to set
	 */
	public void setOpen(String open) {
		this.open = open;
	}
	/**
	 * @return the inProgress
	 */
	public String getInProgress() {
		return inProgress;
	}
	/**
	 * @param inProgress the inProgress to set
	 */
	public void setInProgress(String inProgress) {
		this.inProgress = inProgress;
	}
	/**
	 * @return the forceClosed
	 */
	public String getForceClosed() {
		return forceClosed;
	}
	/**
	 * @param forceClosed the forceClosed to set
	 */
	public void setForceClosed(String forceClosed) {
		this.forceClosed = forceClosed;
	}
	/**
	 * @return the resolved
	 */
	public String getResolved() {
		return resolved;
	}
	/**
	 * @param resolved the resolved to set
	 */
	public void setResolved(String resolved) {
		this.resolved = resolved;
	}
	
	/**
	 * @return the medicaidId
	 */
	public String getMedicaidId() {
		return medicaidId;
	}
	/**
	 * @param medicaidId the medicaidId to set
	 */
	public void setMedicaidId(String medicaidId) {
		this.medicaidId = medicaidId;
	}
	/**
	 * @return the discrepancy
	 */
	public String getDiscrepancy() {
		return discrepancy;
	}
	/**
	 * @param discrepancy the discrepancy to set
	 */
	public void setDiscrepancy(String discrepancy) {
		this.discrepancy = discrepancy;
	}
	/**
	 * @return the effDate
	 */
	public String getEffDate() {
		return effDate;
	}
	/**
	 * @param effDate the effDate to set
	 */
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	/**
	 * @return the discStatuc
	 */
	public String getDiscStatuc() {
		return discStatuc;
	}
	/**
	 * @param discStatuc the discStatuc to set
	 */
	public void setDiscStatuc(String discStatuc) {
		this.discStatuc = discStatuc;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the planId
	 */
	public String getPlanId() {
		return planId;
	}
	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the lastUpdtTime
	 */
	public String getLastUpdtTime() {
		return lastUpdtTime;
	}
	/**
	 * @param lastUpdtTime the lastUpdtTime to set
	 */
	public void setLastUpdtTime(String lastUpdtTime) {
		this.lastUpdtTime = lastUpdtTime;
	}
	
	/**
	 * @return the viewPymtPageLabel
	 */
	public String getViewPymtPageLabel() {
		return viewPymtPageLabel;
	}
	/**
	 * @param viewPymtPageLabel the viewPymtPageLabel to set
	 */
	public void setViewPymtPageLabel(String viewPymtPageLabel) {
		this.viewPymtPageLabel = viewPymtPageLabel;
	}
	/**
	 * @return the applyDate
	 */
	public String getApplyDate() {
		return applyDate;
	}
	/**
	 * @param applyDate the applyDate to set
	 */
	public void setApplyDate(String applyDate) {
		this.applyDate = applyDate;
	}
	/**
	 * @return the adjCode
	 */
	public String getAdjCode() {
		return adjCode;
	}
	/**
	 * @param adjCode the adjCode to set
	 */
	public void setAdjCode(String adjCode) {
		this.adjCode = adjCode;
	}
	/**
	 * @return the mcaidViewPymntDetailLst
	 */
	public List getMcaidViewPymntDetailLst() {
		return mcaidViewPymntDetailLst;
	}
	/**
	 * @param mcaidViewPymntDetailLst the mcaidViewPymntDetailLst to set
	 */
	public void setMcaidViewPymntDetailLst(List mcaidViewPymntDetailLst) {
		this.mcaidViewPymntDetailLst = mcaidViewPymntDetailLst;
	}
	public String getSummSrchPbp() {
		return summSrchPbp;
	}
	public void setSummSrchPbp(String summSrchPbp) {
		this.summSrchPbp = summSrchPbp;
	}
	public String getSummSrchYear() {
		return summSrchYear;
	}
	public void setSummSrchYear(String summSrchYear) {
		this.summSrchYear = summSrchYear;
	}
	public String getSummSrchQtr() {
		return summSrchQtr;
	}
	public void setSummSrchQtr(String summSrchQtr) {
		this.summSrchQtr = summSrchQtr;
	}
	public String getSummSrchMonth() {
		return summSrchMonth;
	}
	public void setSummSrchMonth(String summSrchMonth) {
		this.summSrchMonth = summSrchMonth;
	}
	public String getSummSrchStatus() {
		return summSrchStatus;
	}
	public void setSummSrchStatus(String summSrchStatus) {
		this.summSrchStatus = summSrchStatus;
	}
	public String getSummPageLabel1() {
		return summPageLabel1;
	}
	public void setSummPageLabel1(String summPageLabel1) {
		this.summPageLabel1 = summPageLabel1;
	}
	public String getSummPageLabel2() {
		return summPageLabel2;
	}
	public void setSummPageLabel2(String summPageLabel2) {
		this.summPageLabel2 = summPageLabel2;
	}
	public int getSummSrchListRowSelect() {
		return summSrchListRowSelect;
	}
	public void setSummSrchListRowSelect(int summSrchListRowSelect) {
		this.summSrchListRowSelect = summSrchListRowSelect;
	}
	public List getSummAnomListLst() {
		return summAnomListLst;
	}
	public void setSummAnomListLst(List summAnomListLst) {
		this.summAnomListLst = summAnomListLst;
	}
	public int getSummAnomLstPageNbr() {
		return summAnomLstPageNbr;
	}
	public void setSummAnomLstPageNbr(int summAnomLstPageNbr) {
		this.summAnomLstPageNbr = summAnomLstPageNbr;
	}
	public String getSummAnomLstPageType() {
		return summAnomLstPageType;
	}
	public void setSummAnomLstPageType(String summAnomLstPageType) {
		this.summAnomLstPageType = summAnomLstPageType;
	}
	public McaidAnomSummDetailDataVO getAnomSummDetailDataVo() {
		return anomSummDetailDataVo;
	}
	public void setAnomSummDetailDataVo(
			McaidAnomSummDetailDataVO anomSummDetailDataVo) {
		this.anomSummDetailDataVo = anomSummDetailDataVo;
	}
	/**
	 * @return the adjDesc
	 */
	public String getAdjDesc() {
		return adjDesc;
	}
	/**
	 * @param adjDesc the adjDesc to set
	 */
	public void setAdjDesc(String adjDesc) {
		this.adjDesc = adjDesc;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the suppIdEffDate
	 */
	public String getSuppIdEffDate() {
		return suppIdEffDate;
	}
	/**
	 * @param suppIdEffDate the suppIdEffDate to set
	 */
	public void setSuppIdEffDate(String suppIdEffDate) {
		this.suppIdEffDate = suppIdEffDate;
	}
	/**
	 * @return the recentSuppId
	 */
	public String getRecentSuppId() {
		return recentSuppId;
	}
	/**
	 * @param recentSuppId the recentSuppId to set
	 */
	public void setRecentSuppId(String recentSuppId) {
		this.recentSuppId = recentSuppId;
	}
	/**
	 * @return the summCmsPaid
	 */
	public String getSummCmsPaid() {
		return summCmsPaid;
	}
	/**
	 * @param summCmsPaid the summCmsPaid to set
	 */
	public void setSummCmsPaid(String summCmsPaid) {
		this.summCmsPaid = summCmsPaid;
	}
	/**
	 * @return the summPlanExpected
	 */
	public String getSummPlanExpected() {
		return summPlanExpected;
	}
	/**
	 * @param summPlanExpected the summPlanExpected to set
	 */
	public void setSummPlanExpected(String summPlanExpected) {
		this.summPlanExpected = summPlanExpected;
	}
	/**
	 * @return the summDataDiffrence
	 */
	public String getSummDataDiffrence() {
		return summDataDiffrence;
	}
	/**
	 * @param summDataDiffrence the summDataDiffrence to set
	 */
	public void setSummDataDiffrence(String summDataDiffrence) {
		this.summDataDiffrence = summDataDiffrence;
	}

/* View Reconciliation - Start*/    
	DiscViewReconVO discviewPVO = new DiscViewReconVO();
	DiscViewReconVO discviewSVO = new DiscViewReconVO();
	
	/**
	 * @return the discviewPVO
	 */
	public DiscViewReconVO getDiscviewPVO() {
		return discviewPVO;
	}
	/**
	 * @param discviewPVO the discviewPVO to set
	 */
	public void setDiscviewPVO(DiscViewReconVO discviewPVO) {
		this.discviewPVO = discviewPVO;
	}
	/**
	 * @return the discviewSVO
	 */
	public DiscViewReconVO getDiscviewSVO() {
		return discviewSVO;
	}
	/**
	 * @param discviewSVO the discviewSVO to set
	 */
	public void setDiscviewSVO(DiscViewReconVO discviewSVO) {
		this.discviewSVO = discviewSVO;
	} 
	/* View Reconciliation - End*/
	/**
	 * @return the changeStatus
	 */
	public String getChangeStatus() {
		return changeStatus;
	}
	/**
	 * @param changeStatus the changeStatus to set
	 */
	public void setChangeStatus(String changeStatus) {
		this.changeStatus = changeStatus;
	}
	/**
	 * @return the changeComment
	 */
	public String getChangeComment() {
		return changeComment;
	}
	/**
	 * @param changeComment the changeComment to set
	 */
	public void setChangeComment(String changeComment) {
		this.changeComment = changeComment;
	}
	/**
	 * @return the popupMsg
	 */
	public String getPopupMsg() {
		return popupMsg;
	}
	/**
	 * @param popupMsg the popupMsg to set
	 */
	public void setPopupMsg(String popupMsg) {
		this.popupMsg = popupMsg;
	}
	/**
	 * @return the summSrchType
	 */
	public String getSummSrchType() {
		return summSrchType;
	}
	/**
	 * @param summSrchType the summSrchType to set
	 */
	public void setSummSrchType(String summSrchType) {
		this.summSrchType = summSrchType;
	}
	/**
	 * @return the summSrchMedicaidId
	 */
	public String getSummSrchMedicaidId() {
		return summSrchMedicaidId;
	}
	/**
	 * @param summSrchMedicaidId the summSrchMedicaidId to set
	 */
	public void setSummSrchMedicaidId(String summSrchMedicaidId) {
		this.summSrchMedicaidId = summSrchMedicaidId;
	}
	/**
	 * @return the summSrchFromEffDate
	 */
	public String getSummSrchFromEffDate() {
		return summSrchFromEffDate;
	}
	/**
	 * @param summSrchFromEffDate the summSrchFromEffDate to set
	 */
	public void setSummSrchFromEffDate(String summSrchFromEffDate) {
		this.summSrchFromEffDate = summSrchFromEffDate;
	}
	/**
	 * @return the summSrchToEffDate
	 */
	public String getSummSrchToEffDate() {
		return summSrchToEffDate;
	}
	/**
	 * @param summSrchToEffDate the summSrchToEffDate to set
	 */
	public void setSummSrchToEffDate(String summSrchToEffDate) {
		this.summSrchToEffDate = summSrchToEffDate;
	}
	/**
	 * @return the summSrchFromUpdtDate
	 */
	public String getSummSrchFromUpdtDate() {
		return summSrchFromUpdtDate;
	}
	/**
	 * @param summSrchFromUpdtDate the summSrchFromUpdtDate to set
	 */
	public void setSummSrchFromUpdtDate(String summSrchFromUpdtDate) {
		this.summSrchFromUpdtDate = summSrchFromUpdtDate;
	}
	/**
	 * @return the summSrchToUpdtDate
	 */
	public String getSummSrchToUpdtDate() {
		return summSrchToUpdtDate;
	}
	/**
	 * @param summSrchToUpdtDate the summSrchToUpdtDate to set
	 */
	public void setSummSrchToUpdtDate(String summSrchToUpdtDate) {
		this.summSrchToUpdtDate = summSrchToUpdtDate;
	}
	/**
	 * @return the summSrchUpdtUserId
	 */
	public String getSummSrchUpdtUserId() {
		return summSrchUpdtUserId;
	}
	/**
	 * @param summSrchUpdtUserId the summSrchUpdtUserId to set
	 */
	public void setSummSrchUpdtUserId(String summSrchUpdtUserId) {
		this.summSrchUpdtUserId = summSrchUpdtUserId;
	}
	//State and plan value addition: start
	/**
	 * @return the summSrchStateValue
	 */
	public String getSummSrchStateValue() {
		return summSrchStateValue;
	}
	/**
	 * @param summSrchStateValue the summSrchStateValue to set
	 */
	public void setSummSrchStateValue(String summSrchStateValue) {
		this.summSrchStateValue = summSrchStateValue;
	}
	/**
	 * @return the summSrchPlanValue
	 */
	public String getSummSrchPlanValue() {
		return summSrchPlanValue;
	}
	/**
	 * @param summSrchPlanValue the summSrchPlanValue to set
	 */
	public void setSummSrchPlanValue(String summSrchPlanValue) {
		this.summSrchPlanValue = summSrchPlanValue;
	}
	//State and plan value addition: end
	/**
	 * @return the summSrchPbpLst
	 */
	public List getSummSrchPbpLst() {
		return summSrchPbpLst;
	}
	/**
	 * @param summSrchPbpLst the summSrchPbpLst to set
	 */
	public void setSummSrchPbpLst(List summSrchPbpLst) {
		this.summSrchPbpLst = summSrchPbpLst;
	}
	/**
	 * @return the summSrchStatusLst
	 */
	public List getSummSrchStatusLst() {
		return summSrchStatusLst;
	}
	/**
	 * @param summSrchStatusLst the summSrchStatusLst to set
	 */
	public void setSummSrchStatusLst(List summSrchStatusLst) {
		this.summSrchStatusLst = summSrchStatusLst;
	}
	/**
	 * @return the summSrchTypeLst
	 */
	public List getSummSrchTypeLst() {
		return summSrchTypeLst;
	}
	/**
	 * @param summSrchTypeLst the summSrchTypeLst to set
	 */
	public void setSummSrchTypeLst(List summSrchTypeLst) {
		this.summSrchTypeLst = summSrchTypeLst;
	}
	/**
	 * @return the summSrchGoPbp
	 */
	public String getSummSrchGoPbp() {
		return summSrchGoPbp;
	}
	/**
	 * @param summSrchGoPbp the summSrchGoPbp to set
	 */
	public void setSummSrchGoPbp(String summSrchGoPbp) {
		this.summSrchGoPbp = summSrchGoPbp;
	}
	/**
	 * @return the summSrchGoStatus
	 */
	public String getSummSrchGoStatus() {
		return summSrchGoStatus;
	}
	/**
	 * @param summSrchGoStatus the summSrchGoStatus to set
	 */
	public void setSummSrchGoStatus(String summSrchGoStatus) {
		this.summSrchGoStatus = summSrchGoStatus;
	}
	public String getStrPlanId() {
		return strPlanId;
	}
	public void setStrPlanId(String strPlanId) {
		this.strPlanId = strPlanId;
	}
	public String getStrCreateTime() {
		return strCreateTime;
	}
	public void setStrCreateTime(String strCreateTime) {
		this.strCreateTime = strCreateTime;
	}
	
	// Details Status List
	public List getSummDetailStatusLst() {
		return summDetailStatusLst;
	}
	public void setSummDetailStatusLst(List summDetailStatusLst) {
		this.summDetailStatusLst = summDetailStatusLst;
	}
	public Map getSummDetailStatusChngLst() {
		return summDetailStatusChngLst;
	}
	public void setSummDetailStatusChngLst(Map summDetailStatusChngLst) {
		this.summDetailStatusChngLst = summDetailStatusChngLst;
	}
	// Details Status List
	
	public List getDescrepancyCategoryList() {
		return descrepancyCategoryList;
	}
	public String getDiscrepancyCategory() {
		return discrepancyCategory;
	}
	public void setDiscrepancyCategory(String discrepancyCategory) {
		this.discrepancyCategory = discrepancyCategory;
	}
	public void setDescrepancyCategoryList(List descrepancyCategoryList) {
		this.descrepancyCategoryList = descrepancyCategoryList;
	}
	/**
	 * @return the discrpDetailsLst
	 */
	public List getDiscrpDetailsLst() {
		//System.out.println(" in getter ---"+discrpDetailsLst.size());
		return discrpDetailsLst;
	}
	/**
	 * @param discrpDetailsLst the discrpDetailsLst to set
	 */
	public void setDiscrpDetailsLst(List discrpDetailsLst) {
		//System.out.println(" list set size---"+discrpDetailsLst);
		this.discrpDetailsLst = discrpDetailsLst;
	}
	/**
	 * @return the summSrchDiscrpCd
	 */
	public String getSummSrchDiscrpCd() {
		return summSrchDiscrpCd;
	}
	/**
	 * @param summSrchDiscrpCd the summSrchDiscrpCd to set
	 */
	public void setSummSrchDiscrpCd(String summSrchDiscrpCd) {
		this.summSrchDiscrpCd = summSrchDiscrpCd;
	}
	/**
	 * @return the discrpDetailsTotalLst
	 */
	public List getDiscrpDetailsTotalLst() {
		return discrpDetailsTotalLst;
	}
	/**
	 * @param discrpDetailsTotalLst the discrpDetailsTotalLst to set
	 */
	public void setDiscrpDetailsTotalLst(List discrpDetailsTotalLst) {
		this.discrpDetailsTotalLst = discrpDetailsTotalLst;
	}
	
	//IFOX-00408441- Additional Disc Details: start
			private String rate;
			private String region;
			private String birthDate;
			private String gender;
			private String phCohort;
			private String bhCohort;
			private String geoCode;
			
			public String getRate(){
				return rate;
			}
			public void setRate(String rate){
				this.rate = rate;
			}
			
			public String getRegion(){
				return region;
			}
			public void setRegion(String region){
				this.region = region;
			}
			
			public String getBirthDate(){
				return birthDate;
			}
			public void setBirthDate(String birthDate){
				this.birthDate = birthDate;
			}
			
			public String getGender(){
				return gender;
			}
			public void setGender(String gender){
				this.gender = gender;
			}
			
			public String getBhCohort(){
				return bhCohort;
			}
			public void setBhCohort(String bhCohort){
				this.bhCohort = bhCohort;
			}
			
			public String getPhCohort(){
				return phCohort;
			}
			public void setPhCohort(String phCohort){
				this.phCohort = phCohort;
			}
			
			public String getGeoCode(){
				return geoCode;
			}
			public void setGeoCode(String geoCode){
				this.geoCode = geoCode;
			}
		//IFOX-00408441- Additional Disc Details: end

	//IFOX-00410283- Duplicate fix: start
	
	private String stateRate;
	private String stateRegion;
	private String statePhCohort;
	private String stateBhCohort;

	public String getStateRate(){
		return stateRate;
	}
	public void setStateRate(String stateRate){
		this.stateRate = stateRate;
	}
			
	public String getStateRegion(){
		return stateRegion;
	}
	public void setStateRegion(String stateRegion){
		this.stateRegion = stateRegion;
	}
			
	public String getStateBhCohort(){
		return stateBhCohort;
	}
	public void setStateBhCohort(String stateBhCohort){
		this.stateBhCohort = stateBhCohort;
	}
			
	public String getStatePhCohort(){
		return statePhCohort;
	}
	public void setStatePhCohort(String statePhCohort){
		this.statePhCohort = statePhCohort;
	}
	//IFOX-00410283- Duplicate fix: end
	
	//IFOX-00408437 / 00408436 / 00408435:Region Search Addition: start
	private String summSrchRegion;

	public String getSummSrchRegion() {
		return summSrchRegion;
	}
	public void setSummSrchRegion(String summSrchRegion) {
		this.summSrchRegion = summSrchRegion;
	}
	//IFOX-00408437 / 00408436 / 00408435: Region Search Addition: end

}//class
