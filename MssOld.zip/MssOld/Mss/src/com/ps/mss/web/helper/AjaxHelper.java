/*
 * $Id: AjaxHelper.java,v 1.1 2014/06/26 07:55:09 praveen Exp $
 */
package com.ps.mss.web.helper;

import java.sql.Connection;
import javax.servlet.http.HttpServletRequest;

import org.directwebremoting.WebContextFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.FilterVO;
import com.ps.mss.model.RapsFilter;


/**
 * @author rakesh
 *
 */
public class AjaxHelper {
	private static Logger logger=LoggerFactory.getLogger(AjaxHelper.class);
	/**
	 * @return <code>SessionHelper</code> 
	 * @throws ApplicationException
	 */
	public static SessionHelper getSessionHelper() throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		HttpServletRequest request =(HttpServletRequest) WebContextFactory.get().getHttpServletRequest();
		logger.info(LoggerConstants.methodEndLevel());
		return new SessionHelper(request, false);
	}
	
	/**
	 * <code>setAttribute</code> set attributes in sesssion scope.
	 * @param attrName
	 * @param attrValue
	 * @throws ApplicationException
	 */
	public static void setAttribute(String attrName, Object attrValue) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		
		if(attrValue != null)
			sessionHelper.setAttribute(attrName,attrValue);
		else 
			sessionHelper.removeAttribute(attrName);
		logger.info(LoggerConstants.methodEndLevel());
	}

	/**
	 * <code>getAttribute</code> return the values from session scope.
	 * @param attrName
	 * @return
	 * @throws ApplicationException
	 */
	public static Object getAttribute(String attrName) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		logger.info(LoggerConstants.methodEndLevel());
		return sessionHelper.getAttribute(attrName);
	}
	
	/**
	 * Function <code>getActiveDataBaseName</code> get database name from session scope. 
	 * this database name is set during login process.
	 * 
	 * @return databaseName 
	 * @throws ApplicationException
	 */
	public static String getActiveDataBaseName() throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = getSessionHelper();
		logger.info(LoggerConstants.methodEndLevel());
		return sessionHelper.getActiveDataBaseName();
	}

	public static String getRapsDataBaseName() throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = getSessionHelper();
		logger.info(LoggerConstants.methodEndLevel());
		return sessionHelper.getRapsDatabaseName();
	}

	/**
	 * <code>updateFilterVo</code> update filterVO from session filterVO base on searchType.
	 * @param sessionFilterVO
	 * @param filterVO
	 * @param searchType
	 */
	public static void updateFilterVo(FilterVO sessionFilterVO, FilterVO filterVO, String searchType) {
		logger.info(LoggerConstants.methodStartLevel());
		if(sessionFilterVO != null && filterVO != null){
			String yearId = filterVO.getStartDate();
			filterVO.setHicNumber(sessionFilterVO.getHicNumber());
			filterVO.setDateType(sessionFilterVO.getDateType());
			filterVO.setStartDate(sessionFilterVO.getStartDate());
			filterVO.setEndDate(sessionFilterVO.getEndDate());
			filterVO.setMemberId(sessionFilterVO.getMemberId());
			filterVO.setHicNumberList(sessionFilterVO.getHicNumberList());
			
			if("month".equals(searchType)){
				if(!isContain(sessionFilterVO.getStartDate(),yearId)){
					filterVO.setStartDate("01/"+yearId);
				} 
				if(!isContain(sessionFilterVO.getEndDate(),yearId)){
					filterVO.setEndDate("12/"+yearId);
				}
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	/**
	 * <code>updateFilterVo</code> update filterVO from session filterVO base on searchType.
	 * @param sessionFilterVO
	 * @param filterVO
	 * @param searchType
	 */
	public static void updateFilterVo(RapsFilter sessionFilterVO, RapsFilter filterVO, String searchType) {
		logger.info(LoggerConstants.methodStartLevel());
		if(sessionFilterVO != null && filterVO != null){
			String yearId = filterVO.getFromDate();
			filterVO.setHicNbr(sessionFilterVO.getHicNbr());
			filterVO.setMbi(sessionFilterVO.getMbi());/*SSNRI Changes*/ 
			filterVO.setDateType(sessionFilterVO.getDateType());
			filterVO.setFromDate(sessionFilterVO.getFromDate());
			filterVO.setToDate(sessionFilterVO.getToDate());
			
			if("month".equals(searchType)){
				if(!isContain(sessionFilterVO.getFromDate(),yearId)){
					filterVO.setFromDate("01/"+yearId);
				} 
				if(!isContain(sessionFilterVO.getToDate(),yearId)){
					filterVO.setToDate("12/"+yearId);
				}
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
	}	
	/**
	 * @param fromDate
	 * @param yearId
	 * @return
	 */
	private static boolean isContain(String fromDate ,String yearId ) {
		logger.info(LoggerConstants.methodStartLevel());
		boolean flag = false;
		if(fromDate != null) {
			int  index = fromDate.lastIndexOf(yearId);
			if(index != -1) {
				flag =  true;
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return flag;
	}

	/**
	 * Function <code>validateUser</code> is responsable to validate user session.
	 * <p>Internally it used validateUser method  of <code>SessionHelper</code></p>
	 * @param request
	 * @return Error Messange (if validation failed)
	 * @throws ApplicationException
	 */
	public static void validateUser() throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		HttpServletRequest request =(HttpServletRequest) WebContextFactory.get().getHttpServletRequest();
		SessionHelper sessionHelper = new SessionHelper(request, false);
		String errorMsg = sessionHelper.validateUser();
		
		if(errorMsg != null)
			throw new ApplicationException(errorMsg);
		logger.info(LoggerConstants.methodEndLevel());
		return; // validation success
	}
	
	public static void validateUser(SessionHelper sessionHelper, Connection conn) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String errorMsg = sessionHelper.validateUser(conn);
		
		if(errorMsg != null)
			throw new ApplicationException(errorMsg);
		logger.info(LoggerConstants.methodEndLevel());
		return; // validation success
	}
	

}
