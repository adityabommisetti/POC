/*
 * $Id: ChartAction.java,v 1.2 2014/09/24 17:41:53 jacob Exp $
 */
package com.ps.mss.web.actions;

import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.model.HpeSearchVO;
import com.ps.mss.db.DbConn;
import com.ps.mss.framework.ChartConstants;
import com.ps.mss.framework.HPEConstants;
import com.ps.mss.manager.ChartManager;
import com.ps.mss.model.HPEContext;
import com.ps.mss.model.Pagination;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.forms.ChartEncounterForm;
import com.ps.mss.web.helper.ChartHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.text.DateFormatter;
import com.ps.util.StringUtil;

/**
 * @author nenne.robert
 */
public class ChartAction extends Action {

	private static Logger logger=LoggerFactory.getLogger(ChartAction.class);
	private static Logger replogger=LoggerFactory.getLogger("reportsLogger");

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		long startTime = System.currentTimeMillis();
		Connection conn = null;		
		HpeSearchVO searchVO = null;		
		String forward = ChartConstants.CHART_ERROR;		
		String previousMethod = null,previousENMethod = null;
		String requestStatus = "0";
		String valueChanged = "N";
		Pagination pagi = null;
		String oldPosition = null;
		String backCRFlag = "false";
		String oldStateVal = null,strStat = "false";
		String clmType = null;
		StringBuffer msg= new StringBuffer("");

		try {
			//get the session
			SessionHelper sessionHelper = new SessionHelper(request);			
			
			// get a connection
			conn = DbConn.getConnection();			

			// use the default DB for security check
			String errorMsg = sessionHelper.validateUser(conn);
			if (errorMsg != null) {
				request.setAttribute("Msg", "Login Has Timed Out");
				throw new Exception(errorMsg);
			}

			// re-get the connection in case the environment is different (QA, etc.)
			conn = DbConn.reGetConnection(conn, (String) sessionHelper.getAttribute(SessionManager.HPEDB));

			//get the context
			HPEContext context = ChartManager.getContext(sessionHelper.getSession());	

			// get the form
			ChartEncounterForm chartEncounterForm = (ChartEncounterForm) form;

			
			// get the method/menu
			String method = chartEncounterForm.getMethod();			
			String menu = chartEncounterForm.getMenu();
			
			//Editable Fileds CHS -- IFOX-00395627
			if(StringUtils.isNotEmpty(method) &&  method.startsWith("editableClaimCodesSection")){
			//	int pos = method.indexOf("?");
				method=method;				
			}
			
			//Editable Fileds CHS -- IFOX-00395627
			
			int enumMethod = 0;
			if(!StringUtil.isNullOrEmpty(method)) {
				enumMethod = ChartConstants.getEnumMethod(method);
			}
			
			if (enumMethod == ChartConstants.ENUM_METHOD_SWITCHMENU) {
				previousENMethod = (String) sessionHelper.getAttribute(HPEConstants.ENUM_SUMM_METHOD);
				sessionHelper.setAttribute(HPEConstants.PREV_SUMM_METHOD,previousENMethod);
				
				previousENMethod = (String) sessionHelper.getAttribute(HPEConstants.ENUM_DASH_METHOD);
				sessionHelper.setAttribute(HPEConstants.PREV_DASH_METHOD,previousENMethod);			
				
				if (ChartConstants.MENU_DASHBOARD.equals(menu)) {	
					method = (String) sessionHelper.getAttribute(ChartConstants.PREV_CR_DASH_METHOD);				
					if (method != null){
						if(!StringUtil.isNullOrEmpty(method)) {
							enumMethod = ChartConstants.getEnumMethod(method);
						}
						
						previousMethod = (String) sessionHelper.getAttribute(ChartConstants.ENUM_CR_SUMM_METHOD);						
						sessionHelper.setAttribute(ChartConstants.PREV_CR_SUMM_METHOD,previousMethod);
						
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ERROR_VO);
						if (searchVO != null) {
							if (searchVO.getIconFlag().equals("N")) {						
								if (searchVO.getEncType().equals("I")) {
									searchVO.setListExpanded(chartEncounterForm.isInstListExpanded());
									searchVO.setErrorsExpanded(chartEncounterForm.isInstErrorsExpanded());
									searchVO.setSubscriberExpanded(chartEncounterForm.isInstSubscriberExpanded());
									searchVO.setProviderExpanded(chartEncounterForm.isInstProviderExpanded());
									searchVO.setClaimExpanded(chartEncounterForm.isInstClaimExpanded());
									searchVO.setClaimCodesExpanded(chartEncounterForm.isInstClaimCodesExpanded());
									searchVO.setClaimNotesExpanded(chartEncounterForm.isInstClaimNotesExpanded());
									searchVO.setClaimProvExpanded(chartEncounterForm.isInstClaimProvExpanded());
									searchVO.setClaimProvDetailExpanded(chartEncounterForm.isInstClaimProvDetailExpanded());
									searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isInstClaimOtherSubsProvExpanded());
									searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
									searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isInstClaimOtherSubsExpanded());
									searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isInstClaimOtherSubsDetailExpanded());
									searchVO.setClaimLineExpanded(chartEncounterForm.isInstClaimLineExpanded());
									searchVO.setClaimLineDetailExpanded(chartEncounterForm.isInstClaimLineDetailExpanded());
									searchVO.setClaimLineProvExpanded(chartEncounterForm.isInstClaimLineProvExpanded());
									searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isInstClaimLineProvDetailExpanded());
									searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isInstClaimLineAdjudExpanded());
									searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isInstClaimLineAdjudDetailExpanded());								
									
								} else if (searchVO.getEncType().equals("P")){
									searchVO.setListExpanded(chartEncounterForm.isProfListExpanded());
									searchVO.setErrorsExpanded(chartEncounterForm.isProfErrorsExpanded());
									searchVO.setSubscriberExpanded(chartEncounterForm.isProfSubscriberExpanded());
									searchVO.setProviderExpanded(chartEncounterForm.isProfProviderExpanded());
									searchVO.setClaimExpanded(chartEncounterForm.isProfClaimExpanded());
									searchVO.setClaimCodesExpanded(chartEncounterForm.isProfClaimCodesExpanded());								
									searchVO.setClaimProvExpanded(chartEncounterForm.isProfClaimProvExpanded());
									searchVO.setClaimProvDetailExpanded(chartEncounterForm.isProfClaimProvDetailExpanded());
									searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isProfClaimOtherSubsProvExpanded());
									searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
									searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isProfClaimOtherSubsExpanded());
									searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isProfClaimOtherSubsDetailExpanded());
									searchVO.setClaimLineExpanded(chartEncounterForm.isProfClaimLineExpanded());
									searchVO.setClaimLineDetailExpanded(chartEncounterForm.isProfClaimLineDetailExpanded());
									searchVO.setClaimLineProvExpanded(chartEncounterForm.isProfClaimLineProvExpanded());
									searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isProfClaimLineProvDetailExpanded());
									searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isProfClaimLineAdjudExpanded());
									searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isProfClaimLineAdjudDetailExpanded());								
								}														
							} 
							//searchVO.setIconFlag("Y");	
							sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ERROR_VO,searchVO);
						}						
						requestStatus = "1";
					}	
					long endTime = System.currentTimeMillis();
					replogger.debug("EDPS|Chart Dashboard|"+"|"+(endTime - startTime)+" ms|");
					
				}
				if (ChartConstants.MENU_SUMMARY.equals(menu)) {
					method = (String) sessionHelper.getAttribute(ChartConstants.PREV_CR_SUMM_METHOD);					
					if (method != null){
						if(!StringUtil.isNullOrEmpty(method)) {
							enumMethod = ChartConstants.getEnumMethod(method);
						}
						
						previousMethod = (String) sessionHelper.getAttribute(ChartConstants.ENUM_CR_DASH_METHOD);						
						sessionHelper.setAttribute(ChartConstants.PREV_CR_DASH_METHOD,previousMethod);
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);	
						if(searchVO == null){
							strStat = "true";
							searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_BACK_VO);
						}
						if (searchVO != null) {
							if (searchVO.getIconFlag().equals("N")) {						
								if (searchVO.getEncType().equals("I")) {
									searchVO.setListExpanded(chartEncounterForm.isInstListExpanded());
									searchVO.setErrorsExpanded(chartEncounterForm.isInstErrorsExpanded());
									searchVO.setSubscriberExpanded(chartEncounterForm.isInstSubscriberExpanded());
									searchVO.setProviderExpanded(chartEncounterForm.isInstProviderExpanded());
									searchVO.setClaimExpanded(chartEncounterForm.isInstClaimExpanded());
									searchVO.setClaimCodesExpanded(chartEncounterForm.isInstClaimCodesExpanded());
									searchVO.setClaimNotesExpanded(chartEncounterForm.isInstClaimNotesExpanded());
									searchVO.setClaimProvExpanded(chartEncounterForm.isInstClaimProvExpanded());
									searchVO.setClaimProvDetailExpanded(chartEncounterForm.isInstClaimProvDetailExpanded());
									searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isInstClaimOtherSubsProvExpanded());
									searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
									searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isInstClaimOtherSubsExpanded());
									searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isInstClaimOtherSubsDetailExpanded());
									searchVO.setClaimLineExpanded(chartEncounterForm.isInstClaimLineExpanded());
									searchVO.setClaimLineDetailExpanded(chartEncounterForm.isInstClaimLineDetailExpanded());
									searchVO.setClaimLineProvExpanded(chartEncounterForm.isInstClaimLineProvExpanded());
									searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isInstClaimLineProvDetailExpanded());
									searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isInstClaimLineAdjudExpanded());
									searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isInstClaimLineAdjudDetailExpanded());								
									
								} else if (searchVO.getEncType().equals("P")){
									searchVO.setListExpanded(chartEncounterForm.isProfListExpanded());
									searchVO.setErrorsExpanded(chartEncounterForm.isProfErrorsExpanded());
									searchVO.setSubscriberExpanded(chartEncounterForm.isProfSubscriberExpanded());
									searchVO.setProviderExpanded(chartEncounterForm.isProfProviderExpanded());
									searchVO.setClaimExpanded(chartEncounterForm.isProfClaimExpanded());
									searchVO.setClaimCodesExpanded(chartEncounterForm.isProfClaimCodesExpanded());								
									searchVO.setClaimProvExpanded(chartEncounterForm.isProfClaimProvExpanded());
									searchVO.setClaimProvDetailExpanded(chartEncounterForm.isProfClaimProvDetailExpanded());
									searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isProfClaimOtherSubsProvExpanded());
									searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
									searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isProfClaimOtherSubsExpanded());
									searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isProfClaimOtherSubsDetailExpanded());
									searchVO.setClaimLineExpanded(chartEncounterForm.isProfClaimLineExpanded());
									searchVO.setClaimLineDetailExpanded(chartEncounterForm.isProfClaimLineDetailExpanded());
									searchVO.setClaimLineProvExpanded(chartEncounterForm.isProfClaimLineProvExpanded());
									searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isProfClaimLineProvDetailExpanded());
									searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isProfClaimLineAdjudExpanded());
									searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isProfClaimLineAdjudDetailExpanded());								
								}														
							} 
							//searchVO.setIconFlag("Y");
							if(strStat.equalsIgnoreCase("false"))
								sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO,searchVO);
							else if(strStat.equalsIgnoreCase("true"))
								sessionHelper.setAttribute(ChartConstants.SEARCH_CR_BACK_VO,searchVO);
						}						
						requestStatus = "1";
					}
				}				
			}
			
			switch (enumMethod) {
				/*case ChartConstants.ENUM_METHOD_INITIALIZE:
					ChartEncounterDao dao = new ChartEncounterDao();
					HPEEncounterDao enDao = new HPEEncounterDao();
					List lst = enDao.getEDPSSubmitterList(conn, sessionHelper.getMfId());
					context.setOptionsSubmitters(lst);
					// These belong in application rather than session
					EncProvtypeVOs encProvtypes = dao.selectProviders(conn);
					context.setEncChartProvtypes(encProvtypes);
					
					//Set State List
					CodeCache cc = CodeCache.getInstance();
					context.setStateList(cc.getStateArr());
					ENCCodeCache encCC = ENCCodeCache.getInstance();
					context.setLstPlaceOfService(encCC.getLstPlaceOfService());
					context.setLstEntityType(encCC.getLstEntityType());
					
					context.setSelectedMenu(ChartConstants.MENU_DASHBOARD);
					context.setSelectedOption(ChartConstants.OPTION_DASHTREE);					
					
					//Set Group Status List
					List groupList = encCC.getLstENCGroupStatus();
					context.setOptionsGroupStatus(groupList);
					
					List errorList = encCC.getLstENCErrorSource();
					context.setOptionsErrorSource(errorList);
					List errorGroup = encCC.getLstENCErrorGroup();
					context.setOptionsErrorGroup(errorGroup);
					List encTypeList = encCC.getLstENCEncType();
					context.setOptionsEncType(encTypeList);
					Pagination pg = context.getClaimDetailPagination();
					pg.setPageNumber(0);
					pg.setCurrentPage("current");
					
					// Delete all the HpeSearchVO objects from session
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_DASH_VO);
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_REJECT_VO);
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_VO);
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_ERROR_VO);
					sessionHelper.removeAttribute(ChartConstants.DEFAULT_CR_SEARCH_VO);
					sessionHelper.removeAttribute(ChartConstants.PREV_CR_DASH_METHOD);
					sessionHelper.removeAttribute(ChartConstants.PREV_CR_SUMM_METHOD);
					sessionHelper.removeAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
					sessionHelper.removeAttribute(ChartConstants.ENUM_CR_SUMM_METHOD);
					
					NameValuePair nvp = (NameValuePair)lst.get(0);
					chartEncounterForm.setSearchSummarySubmitterId(nvp.getName());
					
					//Create VO to store the default screen data	
					searchVO = new HpeSearchVO();
					searchVO.setSubmitterId(chartEncounterForm.getSearchSummarySubmitterId());						
					searchVO.setDateInd(chartEncounterForm.getSearchSummaryDateInd());						
					searchVO.setFromDate(chartEncounterForm.getSearchSummaryFromDate());
					searchVO.setToDate(chartEncounterForm.getSearchSummaryToDate());						
					
					sessionHelper.setAttribute(ChartConstants.DEFAULT_CR_SEARCH_VO,searchVO);
					
					ChartHelper.buildStatusSummary(conn, sessionHelper, context, chartEncounterForm, request);
					forward = ChartConstants.CHART_DASHBOARD;					
					break;*/
				case ChartConstants.ENUM_METHOD_SWITCHMENU:					
					if (ChartConstants.MENU_DASHBOARD.equals(menu)) {						
						previousMethod = (String) sessionHelper.getAttribute(ChartConstants.ENUM_CR_SUMM_METHOD);						
						sessionHelper.setAttribute(ChartConstants.PREV_CR_SUMM_METHOD,previousMethod);	
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ERROR_VO);
						if (searchVO != null) {
							if (searchVO.getIconFlag().equals("N")) {						
								if (searchVO.getEncType().equals("I")) {
									searchVO.setListExpanded(chartEncounterForm.isInstListExpanded());
									searchVO.setErrorsExpanded(chartEncounterForm.isInstErrorsExpanded());
									searchVO.setSubscriberExpanded(chartEncounterForm.isInstSubscriberExpanded());
									searchVO.setProviderExpanded(chartEncounterForm.isInstProviderExpanded());
									searchVO.setClaimExpanded(chartEncounterForm.isInstClaimExpanded());
									searchVO.setClaimCodesExpanded(chartEncounterForm.isInstClaimCodesExpanded());
									searchVO.setClaimNotesExpanded(chartEncounterForm.isInstClaimNotesExpanded());
									searchVO.setClaimProvExpanded(chartEncounterForm.isInstClaimProvExpanded());
									searchVO.setClaimProvDetailExpanded(chartEncounterForm.isInstClaimProvDetailExpanded());
									searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isInstClaimOtherSubsProvExpanded());
									searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
									searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isInstClaimOtherSubsExpanded());
									searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isInstClaimOtherSubsDetailExpanded());
									searchVO.setClaimLineExpanded(chartEncounterForm.isInstClaimLineExpanded());
									searchVO.setClaimLineDetailExpanded(chartEncounterForm.isInstClaimLineDetailExpanded());
									searchVO.setClaimLineProvExpanded(chartEncounterForm.isInstClaimLineProvExpanded());
									searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isInstClaimLineProvDetailExpanded());
									searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isInstClaimLineAdjudExpanded());
									searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isInstClaimLineAdjudDetailExpanded());								
									
								} else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")){
									searchVO.setListExpanded(chartEncounterForm.isProfListExpanded());
									searchVO.setErrorsExpanded(chartEncounterForm.isProfErrorsExpanded());
									searchVO.setSubscriberExpanded(chartEncounterForm.isProfSubscriberExpanded());
									searchVO.setProviderExpanded(chartEncounterForm.isProfProviderExpanded());
									searchVO.setClaimExpanded(chartEncounterForm.isProfClaimExpanded());
									searchVO.setClaimCodesExpanded(chartEncounterForm.isProfClaimCodesExpanded());								
									searchVO.setClaimProvExpanded(chartEncounterForm.isProfClaimProvExpanded());
									searchVO.setClaimProvDetailExpanded(chartEncounterForm.isProfClaimProvDetailExpanded());
									searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isProfClaimOtherSubsProvExpanded());
									searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
									searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isProfClaimOtherSubsExpanded());
									searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isProfClaimOtherSubsDetailExpanded());
									searchVO.setClaimLineExpanded(chartEncounterForm.isProfClaimLineExpanded());
									searchVO.setClaimLineDetailExpanded(chartEncounterForm.isProfClaimLineDetailExpanded());
									searchVO.setClaimLineProvExpanded(chartEncounterForm.isProfClaimLineProvExpanded());
									searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isProfClaimLineProvDetailExpanded());
									searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isProfClaimLineAdjudExpanded());
									searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isProfClaimLineAdjudDetailExpanded());								
								}														
							}
							//searchVO.setIconFlag("Y");	
							sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ERROR_VO,searchVO);
						}					
					
						context.setSelectedMenu(ChartConstants.MENU_DASHBOARD);
						context.setSelectedOption(ChartConstants.OPTION_DASHTREE);						
						ChartHelper.buildStatusSummary(conn, sessionHelper, context, chartEncounterForm, request);
						forward = ChartConstants.CHART_DASHTREE;						
					}
					if (ChartConstants.MENU_SUMMARY.equals(menu)) {
						previousMethod = (String) sessionHelper.getAttribute(ChartConstants.ENUM_CR_DASH_METHOD);						
						sessionHelper.setAttribute(ChartConstants.PREV_CR_DASH_METHOD,previousMethod);
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);
						
						if(searchVO == null){
							strStat="true";
							searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_BACK_VO);							
						}
						if (searchVO != null) {
							if (searchVO.getIconFlag().equals("N")) {						
								if (searchVO.getEncType().equals("I")) {
									searchVO.setListExpanded(chartEncounterForm.isInstListExpanded());
									searchVO.setErrorsExpanded(chartEncounterForm.isInstErrorsExpanded());
									searchVO.setSubscriberExpanded(chartEncounterForm.isInstSubscriberExpanded());
									searchVO.setProviderExpanded(chartEncounterForm.isInstProviderExpanded());
									searchVO.setClaimExpanded(chartEncounterForm.isInstClaimExpanded());
									searchVO.setClaimCodesExpanded(chartEncounterForm.isInstClaimCodesExpanded());
									searchVO.setClaimNotesExpanded(chartEncounterForm.isInstClaimNotesExpanded());
									searchVO.setClaimProvExpanded(chartEncounterForm.isInstClaimProvExpanded());
									searchVO.setClaimProvDetailExpanded(chartEncounterForm.isInstClaimProvDetailExpanded());
									searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isInstClaimOtherSubsProvExpanded());
									searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
									searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isInstClaimOtherSubsExpanded());
									searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isInstClaimOtherSubsDetailExpanded());
									searchVO.setClaimLineExpanded(chartEncounterForm.isInstClaimLineExpanded());
									searchVO.setClaimLineDetailExpanded(chartEncounterForm.isInstClaimLineDetailExpanded());
									searchVO.setClaimLineProvExpanded(chartEncounterForm.isInstClaimLineProvExpanded());
									searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isInstClaimLineProvDetailExpanded());
									searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isInstClaimLineAdjudExpanded());
									searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isInstClaimLineAdjudDetailExpanded());								
									
								} else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")){
									searchVO.setListExpanded(chartEncounterForm.isProfListExpanded());
									searchVO.setErrorsExpanded(chartEncounterForm.isProfErrorsExpanded());
									searchVO.setSubscriberExpanded(chartEncounterForm.isProfSubscriberExpanded());
									searchVO.setProviderExpanded(chartEncounterForm.isProfProviderExpanded());
									searchVO.setClaimExpanded(chartEncounterForm.isProfClaimExpanded());
									searchVO.setClaimCodesExpanded(chartEncounterForm.isProfClaimCodesExpanded());								
									searchVO.setClaimProvExpanded(chartEncounterForm.isProfClaimProvExpanded());
									searchVO.setClaimProvDetailExpanded(chartEncounterForm.isProfClaimProvDetailExpanded());
									searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isProfClaimOtherSubsProvExpanded());
									searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
									searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isProfClaimOtherSubsExpanded());
									searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isProfClaimOtherSubsDetailExpanded());
									searchVO.setClaimLineExpanded(chartEncounterForm.isProfClaimLineExpanded());
									searchVO.setClaimLineDetailExpanded(chartEncounterForm.isProfClaimLineDetailExpanded());
									searchVO.setClaimLineProvExpanded(chartEncounterForm.isProfClaimLineProvExpanded());
									searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isProfClaimLineProvDetailExpanded());
									searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isProfClaimLineAdjudExpanded());
									searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isProfClaimLineAdjudDetailExpanded());								
								}														
							} 
							//searchVO.setIconFlag("Y");	
							if(strStat.equalsIgnoreCase("false"))
								sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO,searchVO);
							else if(strStat.equalsIgnoreCase("true"))
								sessionHelper.setAttribute(ChartConstants.SEARCH_CR_BACK_VO,searchVO);
						}						
						context.setSelectedMenu(ChartConstants.MENU_SUMMARY);
						context.setSelectedOption(ChartConstants.OPTION_SUMMTREE);						
						ChartHelper.buildErrorStatusSummary(conn, sessionHelper, context, chartEncounterForm, request);	
						forward = ChartConstants.CHART_SUMMTREE;						
					}
					break;
				case ChartConstants.ENUM_METHOD_DASHTREEOPTION:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_DASH_METHOD,method);				
					context.setSelectedMenu(ChartConstants.MENU_DASHBOARD);
					context.setSelectedOption(ChartConstants.OPTION_DASHTREE);	
					if ("0".equals(requestStatus)) {
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);	
						
						if(searchVO == null){
							strStat = "true";
							searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_BACK_VO);	
						}
						if (searchVO != null){
							if (searchVO.getIconFlag().equals("N")) {						
								if (searchVO.getEncType().equals("I")) {
									searchVO.setListExpanded(chartEncounterForm.isInstListExpanded());
									searchVO.setErrorsExpanded(chartEncounterForm.isInstErrorsExpanded());
									searchVO.setSubscriberExpanded(chartEncounterForm.isInstSubscriberExpanded());
									searchVO.setProviderExpanded(chartEncounterForm.isInstProviderExpanded());
									searchVO.setClaimExpanded(chartEncounterForm.isInstClaimExpanded());
									searchVO.setClaimCodesExpanded(chartEncounterForm.isInstClaimCodesExpanded());
									searchVO.setClaimNotesExpanded(chartEncounterForm.isInstClaimNotesExpanded());
									searchVO.setClaimProvExpanded(chartEncounterForm.isInstClaimProvExpanded());
									searchVO.setClaimProvDetailExpanded(chartEncounterForm.isInstClaimProvDetailExpanded());
									searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isInstClaimOtherSubsProvExpanded());
									searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
									searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isInstClaimOtherSubsExpanded());
									searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isInstClaimOtherSubsDetailExpanded());
									searchVO.setClaimLineExpanded(chartEncounterForm.isInstClaimLineExpanded());
									searchVO.setClaimLineDetailExpanded(chartEncounterForm.isInstClaimLineDetailExpanded());
									searchVO.setClaimLineProvExpanded(chartEncounterForm.isInstClaimLineProvExpanded());
									searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isInstClaimLineProvDetailExpanded());
									searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isInstClaimLineAdjudExpanded());
									searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isInstClaimLineAdjudDetailExpanded());								
									
								} else if (searchVO.getEncType().equals("P")){
									searchVO.setListExpanded(chartEncounterForm.isProfListExpanded());
									searchVO.setErrorsExpanded(chartEncounterForm.isProfErrorsExpanded());
									searchVO.setSubscriberExpanded(chartEncounterForm.isProfSubscriberExpanded());
									searchVO.setProviderExpanded(chartEncounterForm.isProfProviderExpanded());
									searchVO.setClaimExpanded(chartEncounterForm.isProfClaimExpanded());
									searchVO.setClaimCodesExpanded(chartEncounterForm.isProfClaimCodesExpanded());								
									searchVO.setClaimProvExpanded(chartEncounterForm.isProfClaimProvExpanded());
									searchVO.setClaimProvDetailExpanded(chartEncounterForm.isProfClaimProvDetailExpanded());
									searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isProfClaimOtherSubsProvExpanded());
									searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
									searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isProfClaimOtherSubsExpanded());
									searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isProfClaimOtherSubsDetailExpanded());
									searchVO.setClaimLineExpanded(chartEncounterForm.isProfClaimLineExpanded());
									searchVO.setClaimLineDetailExpanded(chartEncounterForm.isProfClaimLineDetailExpanded());
									searchVO.setClaimLineProvExpanded(chartEncounterForm.isProfClaimLineProvExpanded());
									searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isProfClaimLineProvDetailExpanded());
									searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isProfClaimLineAdjudExpanded());
									searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isProfClaimLineAdjudDetailExpanded());								
								}
								//searchVO.setIconFlag("Y");								
							} 
							
							if(strStat.equalsIgnoreCase("false")){
								sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO,searchVO);
								searchVO.setIconFlag("Y");	
							}
							else if(strStat.equalsIgnoreCase("true")){
								searchVO.setIconFlag("N");	
								sessionHelper.setAttribute(ChartConstants.SEARCH_CR_BACK_VO,searchVO);
							}
						}
					}
					ChartHelper.buildStatusSummary(conn, sessionHelper, context, chartEncounterForm, request);
					forward = ChartConstants.CHART_DASHTREE;
					break;
				case ChartConstants.ENUM_METHOD_DASHDETAILOPTION:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_DASH_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_DASHBOARD);
					context.setSelectedOption(ChartConstants.OPTION_DASHINSTDETAIL);
					requestStatus = "0";
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);
					if (searchVO != null) {
						searchVO.setIconFlag("N");
						sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO,searchVO);
					}
					forward = ChartHelper.selectClaims(conn, sessionHelper, context, chartEncounterForm, request,requestStatus);					
					break;
				case ChartConstants.ENUM_METHOD_DASHTREESEARCH:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_DASH_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_DASHBOARD);
					context.setSelectedOption(ChartConstants.OPTION_DASHTREE);

					if ("0".equals(requestStatus)) {
						//Delete the default VO and recreate the new one to store the search criterias
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_DASH_VO);
						if (searchVO != null){
							sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_DASH_VO);	
						}
						
						searchVO = new HpeSearchVO();
						searchVO.setSubmitterId(chartEncounterForm.getSearchCRSummarySubmitterId());	
						searchVO.setClmType(chartEncounterForm.getSearchCRSummaryType());
						searchVO.setDateInd(chartEncounterForm.getSearchCRSummaryDateInd());						
						searchVO.setFromDate(chartEncounterForm.getSearchCRSummaryFromDate());
						searchVO.setToDate(chartEncounterForm.getSearchCRSummaryToDate());
						searchVO.setPrevMenu(chartEncounterForm.getPrevMenu());
						searchVO.setPrevMethod(chartEncounterForm.getPrevMethod());
						
						sessionHelper.setAttribute(ChartConstants.SEARCH_CR_DASH_VO,searchVO);
					}
										
					ChartHelper.buildStatusSummary(conn, sessionHelper, context, chartEncounterForm, request);
					forward = ChartConstants.CHART_DASHTREE;
					break;
				case ChartConstants.ENUM_METHOD_DASHINSTMONTH:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_DASH_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_DASHBOARD);
					context.setSelectedOption(ChartConstants.OPTION_DASHINSTDETAIL);
					
					if ("0".equals(requestStatus)) {					
						chartEncounterForm.setSearchCRDetailSubmitterId(chartEncounterForm.getSearchCRSummarySubmitterId());
						chartEncounterForm.setSearchCRDetailClmType(chartEncounterForm.getSearchCRSummaryType());
						chartEncounterForm.setSearchCRDetailEncType(chartEncounterForm.getSearchCRSummaryEncType());
						chartEncounterForm.setSearchCRDetailDateInd(chartEncounterForm.getSearchCRSummaryDateInd());
						chartEncounterForm.setSelectedCRDateYrmo(chartEncounterForm.getSelectedCRDateYrmo());
						chartEncounterForm.setSearchCRDetailFromDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRSummaryFromDate(), DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_START));
						chartEncounterForm.setSearchCRDetailToDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRSummaryToDate(), DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_END));
						chartEncounterForm.setSearchCRDetailGroupStatus(chartEncounterForm.getSearchCRSummaryGroupStatus());
						chartEncounterForm.setPrevMenu(chartEncounterForm.getPrevMenu());
						chartEncounterForm.setPrevMethod(chartEncounterForm.getPrevMethod());
						
						/* Create the VO to store the data of the user selected row of the EDPS dashboard 
						 * It will be used, when user wants to view the previuos screen data
						 */
						searchVO = new HpeSearchVO();					
						searchVO.setSubmitterId(chartEncounterForm.getSearchCRSummarySubmitterId());
						searchVO.setClmType(chartEncounterForm.getSearchCRSummaryType());
						searchVO.setEncType(chartEncounterForm.getSearchCRSummaryEncType());
						searchVO.setDateInd(chartEncounterForm.getSearchCRSummaryDateInd());
						searchVO.setSelectedDate(chartEncounterForm.getSelectedCRDateYrmo());
						searchVO.setFromDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRSummaryFromDate(), DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_START));
						searchVO.setToDate(DateFormatter.reFormat(chartEncounterForm.getSearchCRSummaryToDate(), DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_END));
						searchVO.setGroupStatus(chartEncounterForm.getSearchCRSummaryGroupStatus());
						searchVO.setPrevMenu(chartEncounterForm.getPrevMenu());
						searchVO.setPrevMethod(chartEncounterForm.getPrevMethod());
						
						sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO,searchVO);
					}	
					requestStatus = "0";
					forward = ChartHelper.selectClaims(conn, sessionHelper, context, chartEncounterForm, request,requestStatus);
					break;
				case ChartConstants.ENUM_METHOD_DASHDETAILSEARCH:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_DASH_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_DASHBOARD);
					context.setSelectedOption(ChartConstants.OPTION_DASHINSTDETAIL);
					
					if ("0".equals(requestStatus)) {
						//Delete the default VO and recreate the new one to store the search criterias
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);
						if (searchVO != null){
							sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);	
						}
						
						chartEncounterForm.setSubscriberDisplayState(ChartConstants.HPE_SCREEN_VIEW);
						chartEncounterForm.setClaimDisplayState(ChartConstants.HPE_SCREEN_VIEW);
						chartEncounterForm.setProviderDisplayState(ChartConstants.HPE_SCREEN_VIEW);
						chartEncounterForm.setClmProviderDisplayState(ChartConstants.HPE_SCREEN_VIEW);
						
						searchVO = new HpeSearchVO();
						
						//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : Start
						searchVO.setMaoflag(chartEncounterForm.getMaoflag());
						
						//System.out.println("In ChartAction maoflag::::::::::::::"+searchVO.getMaoflag());
						//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : End
						
						//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - Start
						searchVO.setPayerSecId(chartEncounterForm.getSearchPayerSecId());
						searchVO.setSubsGrpOrPolNbr(chartEncounterForm.getSearchSubsGrpOrPolNbr());
						//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - End
						searchVO.setSubmitterId(chartEncounterForm.getSearchCRDetailSubmitterId());
						searchVO.setClmType(chartEncounterForm.getSearchCRDetailClmType());
						searchVO.setEncType(chartEncounterForm.getSearchCRDetailEncType());
						searchVO.setDateInd(chartEncounterForm.getSearchCRDetailDateInd());					
						searchVO.setFromDate(chartEncounterForm.getSearchCRDetailFromDate());
						searchVO.setToDate(chartEncounterForm.getSearchCRDetailToDate());
						searchVO.setGroupStatus(chartEncounterForm.getSearchCRDetailGroupStatus());	
						searchVO.setErrorCode(chartEncounterForm.getSearchCRDetailErrorCode());	
						searchVO.setErrorGroup(chartEncounterForm.getSearchCRDetailErrorGroup());	
						searchVO.setErrorSource(chartEncounterForm.getSearchCRDetailErrorSource());
						searchVO.setClaimRefNbr(chartEncounterForm.getSearchCRDetailClaimRefNbr());
						searchVO.setHicNbr(chartEncounterForm.getSearchCRDetailHicNbr());
						searchVO.setPrevMenu(chartEncounterForm.getPrevMenu());
						searchVO.setPrevMethod(chartEncounterForm.getPrevMethod());
						
						//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
						searchVO.setVanTanNumber(chartEncounterForm.getSearchVanTanNumber());
						//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
						
						if (chartEncounterForm.getSearchCRDetailEncType().equals("I")) {
							searchVO.setListExpanded(chartEncounterForm.isInstListExpanded());
							searchVO.setErrorsExpanded(chartEncounterForm.isInstErrorsExpanded());
							searchVO.setSubscriberExpanded(chartEncounterForm.isInstSubscriberExpanded());
							searchVO.setProviderExpanded(chartEncounterForm.isInstProviderExpanded());
							searchVO.setClaimExpanded(chartEncounterForm.isInstClaimExpanded());
							searchVO.setClaimCodesExpanded(chartEncounterForm.isInstClaimCodesExpanded());
							searchVO.setClaimNotesExpanded(chartEncounterForm.isInstClaimNotesExpanded());
							searchVO.setClaimProvExpanded(chartEncounterForm.isInstClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(chartEncounterForm.isInstClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isInstClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isInstClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isInstClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(chartEncounterForm.isInstClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(chartEncounterForm.isInstClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(chartEncounterForm.isInstClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isInstClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isInstClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isInstClaimLineAdjudDetailExpanded());					
						} else if (chartEncounterForm.getSearchCRDetailEncType().equals("P")) {
							searchVO.setListExpanded(chartEncounterForm.isProfListExpanded());
							searchVO.setErrorsExpanded(chartEncounterForm.isProfErrorsExpanded());
							searchVO.setSubscriberExpanded(chartEncounterForm.isProfSubscriberExpanded());
							searchVO.setProviderExpanded(chartEncounterForm.isProfProviderExpanded());
							searchVO.setClaimExpanded(chartEncounterForm.isProfClaimExpanded());
							searchVO.setClaimCodesExpanded(chartEncounterForm.isProfClaimCodesExpanded());								
							searchVO.setClaimProvExpanded(chartEncounterForm.isProfClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(chartEncounterForm.isProfClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isProfClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isProfClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isProfClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(chartEncounterForm.isProfClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(chartEncounterForm.isProfClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(chartEncounterForm.isProfClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isProfClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isProfClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isProfClaimLineAdjudDetailExpanded());					
						}						
												
						sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO,searchVO);
					}
					requestStatus = "0";
					forward = ChartHelper.selectClaims(conn, sessionHelper, context, chartEncounterForm, request,requestStatus);
					String uid = sessionHelper.getUserId();
					logger.error("User Id: " + uid);   //checking
					break;
				case ChartConstants.ENUM_METHOD_SUMMDETAILSEARCH:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_SUMM_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_SUMMARY);
					context.setSelectedOption(ChartConstants.OPTION_SUMMINSTDETAIL);
					
					if ("0".equals(requestStatus)) {
						//Delete the default VO and recreate the new one to store the search criterias
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ERROR_VO);
						if (searchVO != null){
							sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_ERROR_VO);	
						}
						
						searchVO = new HpeSearchVO();
						
						//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : Start
						searchVO.setMaoflag(chartEncounterForm.getMaoflag());
						//System.out.println("In ChartAction request status 0 maoflag::::::::::::::"+searchVO.getMaoflag());
						//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : End
						//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - Start
						searchVO.setPayerSecId(chartEncounterForm.getSearchPayerSecId());
						searchVO.setSubsGrpOrPolNbr(chartEncounterForm.getSearchSubsGrpOrPolNbr());
						//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - End
						searchVO.setSubmitterId(chartEncounterForm.getSearchCRDetailSubmitterId());
						searchVO.setClmType(chartEncounterForm.getSearchCRDetailClmType());
						searchVO.setEncType(chartEncounterForm.getSearchCRDetailEncType());
						searchVO.setDateInd(chartEncounterForm.getSearchCRDetailDateInd());					
						searchVO.setFromDate(chartEncounterForm.getSearchCRDetailFromDate());
						searchVO.setToDate(chartEncounterForm.getSearchCRDetailToDate());
						searchVO.setGroupStatus(chartEncounterForm.getSearchCRDetailGroupStatus());	
						searchVO.setErrorCode(chartEncounterForm.getSearchCRDetailErrorCode());	
						searchVO.setErrorGroup(chartEncounterForm.getSearchCRDetailErrorGroup());	
						searchVO.setErrorSource(chartEncounterForm.getSearchCRDetailErrorSource());
						searchVO.setClaimRefNbr(chartEncounterForm.getSearchCRDetailClaimRefNbr());
						searchVO.setHicNbr(chartEncounterForm.getSearchCRDetailHicNbr());
						
						//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
						searchVO.setVanTanNumber(chartEncounterForm.getSearchVanTanNumber());
						//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
						
						if (chartEncounterForm.getSearchCRDetailEncType().equals("I")) {
							searchVO.setListExpanded(chartEncounterForm.isInstListExpanded());
							searchVO.setErrorsExpanded(chartEncounterForm.isInstErrorsExpanded());
							searchVO.setSubscriberExpanded(chartEncounterForm.isInstSubscriberExpanded());
							searchVO.setProviderExpanded(chartEncounterForm.isInstProviderExpanded());
							searchVO.setClaimExpanded(chartEncounterForm.isInstClaimExpanded());
							searchVO.setClaimCodesExpanded(chartEncounterForm.isInstClaimCodesExpanded());
							searchVO.setClaimNotesExpanded(chartEncounterForm.isInstClaimNotesExpanded());
							searchVO.setClaimProvExpanded(chartEncounterForm.isInstClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(chartEncounterForm.isInstClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isInstClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isInstClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isInstClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(chartEncounterForm.isInstClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(chartEncounterForm.isInstClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(chartEncounterForm.isInstClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isInstClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isInstClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isInstClaimLineAdjudDetailExpanded());					
						} else if (chartEncounterForm.getSearchCRDetailEncType().equals("P")) {
							searchVO.setListExpanded(chartEncounterForm.isProfListExpanded());
							searchVO.setErrorsExpanded(chartEncounterForm.isProfErrorsExpanded());
							searchVO.setSubscriberExpanded(chartEncounterForm.isProfSubscriberExpanded());
							searchVO.setProviderExpanded(chartEncounterForm.isProfProviderExpanded());
							searchVO.setClaimExpanded(chartEncounterForm.isProfClaimExpanded());
							searchVO.setClaimCodesExpanded(chartEncounterForm.isProfClaimCodesExpanded());								
							searchVO.setClaimProvExpanded(chartEncounterForm.isProfClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(chartEncounterForm.isProfClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isProfClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isProfClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isProfClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(chartEncounterForm.isProfClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(chartEncounterForm.isProfClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(chartEncounterForm.isProfClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isProfClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isProfClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isProfClaimLineAdjudDetailExpanded());					
						}						
						sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ERROR_VO,searchVO);
					}
					requestStatus = "1";
					forward = ChartHelper.selectClaims(conn, sessionHelper, context, chartEncounterForm, request,requestStatus);
					break;
				case ChartConstants.ENUM_METHOD_DASH_DETAIL_PAGE_FIRST:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_DASH_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_DASHBOARD);
					context.setSelectedOption(ChartConstants.OPTION_DASHINSTDETAIL);	
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);
					pagi = new Pagination();					
					if ("0".equals(requestStatus)) {
						valueChanged = "Y";		
						searchVO.setClaimDetailPagination(context.getCrClaimDetailPagination());
						searchVO.setMove("first");
						searchVO.setOldState("false");
					}
					requestStatus = "0";
					forward = ChartHelper.pageClaims(conn, sessionHelper, context, chartEncounterForm, request, "first",requestStatus);
					if ("Y".equals(valueChanged)) {						
						searchVO.setOldState("true");
						//Create replica of pagination object
						pagi.setCurrentPage(context.getCrClaimDetailPagination().getCurrentPage());
						pagi.setPageNumber(context.getCrClaimDetailPagination().getPageNumber());
						pagi.setFirstDetail(context.getCrClaimDetailPagination().getFirstDetail());
						pagi.setLastDetail(context.getCrClaimDetailPagination().getLastDetail());
						pagi.setPageHistory(context.getCrClaimDetailPagination().getPageHistory());
						pagi.setMaxRecordCount(context.getCrClaimDetailPagination().getMaxRecordCount());
						//End
						searchVO.setClaimDetailPagination(pagi);
						searchVO.setSelectedClaimType("");
						searchVO.setSelectedClaimRefNbr("");
						searchVO.setSelectedClaimRevNbr("");
						searchVO.setSelectedClaimSeqNbr("");
					}
					searchVO.setIconFlag("N");
					sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO,searchVO);
					break;
				case ChartConstants.ENUM_METHOD_DASH_DETAIL_PAGE_PREV:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_DASH_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_DASHBOARD);
					context.setSelectedOption(ChartConstants.OPTION_DASHINSTDETAIL);
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);
					pagi = new Pagination();
					if ("0".equals(requestStatus)) {
						valueChanged = "Y";	
						searchVO.setClaimDetailPagination(context.getCrClaimDetailPagination());
						searchVO.setMove("previous");
						searchVO.setOldState("false");
					}										
					requestStatus = "0";
					forward = ChartHelper.pageClaims(conn, sessionHelper, context, chartEncounterForm, request, "previous",requestStatus);
					if ("Y".equals(valueChanged)) {											
						searchVO.setOldState("true");	
						//Create replica of pagination object
						pagi.setCurrentPage(context.getCrClaimDetailPagination().getCurrentPage());
						pagi.setPageNumber(context.getCrClaimDetailPagination().getPageNumber());
						pagi.setFirstDetail(context.getCrClaimDetailPagination().getFirstDetail());
						pagi.setLastDetail(context.getCrClaimDetailPagination().getLastDetail());
						pagi.setPageHistory(context.getCrClaimDetailPagination().getPageHistory());
						pagi.setMaxRecordCount(context.getCrClaimDetailPagination().getMaxRecordCount());
						//End
						searchVO.setClaimDetailPagination(pagi);
						searchVO.setSelectedClaimType("");
						searchVO.setSelectedClaimRefNbr("");
						searchVO.setSelectedClaimRevNbr("");
						searchVO.setSelectedClaimSeqNbr("");
					} 
					searchVO.setIconFlag("N");
					sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO,searchVO);
					break;
				case ChartConstants.ENUM_METHOD_DASH_DETAIL_PAGE_NEXT:					
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_DASH_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_DASHBOARD);
					context.setSelectedOption(ChartConstants.OPTION_DASHINSTDETAIL);
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);
					pagi = new Pagination();					
					if ("0".equals(requestStatus)) {
						valueChanged = "Y";	
						searchVO.setClaimDetailPagination(context.getCrClaimDetailPagination());
						searchVO.setMove("next");	
						searchVO.setOldState("false");
					}					
					requestStatus = "0";					
					forward = ChartHelper.pageClaims(conn, sessionHelper, context, chartEncounterForm, request, "next",requestStatus);					
					if ("Y".equals(valueChanged)) {						
						searchVO.setOldState("true");
						// Create replica of pagination object
						pagi.setCurrentPage(context.getCrClaimDetailPagination().getCurrentPage());
						pagi.setPageNumber(context.getCrClaimDetailPagination().getPageNumber());
						pagi.setFirstDetail(context.getCrClaimDetailPagination().getFirstDetail());
						pagi.setLastDetail(context.getCrClaimDetailPagination().getLastDetail());
						pagi.setPageHistory(context.getCrClaimDetailPagination().getPageHistory());
						pagi.setMaxRecordCount(context.getCrClaimDetailPagination().getMaxRecordCount());
						//End						
						searchVO.setClaimDetailPagination(pagi);
						searchVO.setSelectedClaimType("");
						searchVO.setSelectedClaimRefNbr("");
						searchVO.setSelectedClaimRevNbr("");
						searchVO.setSelectedClaimSeqNbr("");
					}
					searchVO.setIconFlag("N");
					sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO,searchVO);					
					break;					
				case ChartConstants.ENUM_METHOD_SUMM_DETAIL_PAGE_FIRST:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_SUMM_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_SUMMARY);
					context.setSelectedOption(ChartConstants.OPTION_SUMMINSTDETAIL);
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ERROR_VO);
					pagi = new Pagination();
					if ("0".equals(requestStatus)) {
						valueChanged = "Y";	
						searchVO.setClaimDetailPagination(context.getCrClaimDetailPagination());
						searchVO.setMove("first");
						searchVO.setOldState("false");
					}					
					requestStatus = "1";
					forward = ChartHelper.pageClaims(conn, sessionHelper, context, chartEncounterForm, request, "first",requestStatus);
					if ("Y".equals(valueChanged)) {						
						searchVO.setOldState("true");
						//Create replica of pagination object
						pagi.setCurrentPage(context.getCrClaimDetailPagination().getCurrentPage());
						pagi.setPageNumber(context.getCrClaimDetailPagination().getPageNumber());
						pagi.setFirstDetail(context.getCrClaimDetailPagination().getFirstDetail());
						pagi.setLastDetail(context.getCrClaimDetailPagination().getLastDetail());
						pagi.setPageHistory(context.getCrClaimDetailPagination().getPageHistory());
						pagi.setMaxRecordCount(context.getCrClaimDetailPagination().getMaxRecordCount());
						//End
						searchVO.setClaimDetailPagination(pagi);
						searchVO.setSelectedClaimType("");
						searchVO.setSelectedClaimRefNbr("");
						searchVO.setSelectedClaimRevNbr("");
						searchVO.setSelectedClaimSeqNbr("");
					}
					searchVO.setIconFlag("N");
					sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ERROR_VO,searchVO);
					break;
				case ChartConstants.ENUM_METHOD_SUMM_DETAIL_PAGE_PREV:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_SUMM_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_SUMMARY);
					context.setSelectedOption(ChartConstants.OPTION_SUMMINSTDETAIL);
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ERROR_VO);
					pagi = new Pagination();
					if ("0".equals(requestStatus)) {
						valueChanged = "Y";	
						searchVO.setClaimDetailPagination(context.getCrClaimDetailPagination());
						searchVO.setMove("previous");
						searchVO.setOldState("false");
					}					
					requestStatus = "1";
					forward = ChartHelper.pageClaims(conn, sessionHelper, context, chartEncounterForm, request, "previous",requestStatus);
					if ("Y".equals(valueChanged)) {						
						searchVO.setOldState("true");
						//Create replica of pagination object
						pagi.setCurrentPage(context.getCrClaimDetailPagination().getCurrentPage());
						pagi.setPageNumber(context.getCrClaimDetailPagination().getPageNumber());
						pagi.setFirstDetail(context.getCrClaimDetailPagination().getFirstDetail());
						pagi.setLastDetail(context.getCrClaimDetailPagination().getLastDetail());
						pagi.setPageHistory(context.getCrClaimDetailPagination().getPageHistory());
						pagi.setMaxRecordCount(context.getCrClaimDetailPagination().getMaxRecordCount());
						//End
						searchVO.setClaimDetailPagination(pagi);
						searchVO.setSelectedClaimType("");
						searchVO.setSelectedClaimRefNbr("");
						searchVO.setSelectedClaimRevNbr("");
						searchVO.setSelectedClaimSeqNbr("");
					}
					searchVO.setIconFlag("N");
					sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ERROR_VO,searchVO);
					break;
				case ChartConstants.ENUM_METHOD_SUMM_DETAIL_PAGE_NEXT:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_SUMM_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_SUMMARY);
					context.setSelectedOption(ChartConstants.OPTION_SUMMINSTDETAIL);
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ERROR_VO);
					pagi = new Pagination();
					if ("0".equals(requestStatus)) {
						valueChanged = "Y";	
						searchVO.setClaimDetailPagination(context.getCrClaimDetailPagination());
						searchVO.setMove("next");
						searchVO.setOldState("false");
					}					
					requestStatus = "1";
					forward = ChartHelper.pageClaims(conn, sessionHelper, context, chartEncounterForm, request, "next",requestStatus);
					if ("Y".equals(valueChanged)) {						
						searchVO.setOldState("true");
						//Create replica of pagination object
						pagi.setCurrentPage(context.getCrClaimDetailPagination().getCurrentPage());
						pagi.setPageNumber(context.getCrClaimDetailPagination().getPageNumber());
						pagi.setFirstDetail(context.getCrClaimDetailPagination().getFirstDetail());
						pagi.setLastDetail(context.getCrClaimDetailPagination().getLastDetail());
						pagi.setPageHistory(context.getCrClaimDetailPagination().getPageHistory());
						pagi.setMaxRecordCount(context.getCrClaimDetailPagination().getMaxRecordCount());
						//End
						searchVO.setClaimDetailPagination(pagi);
						searchVO.setSelectedClaimType("");
						searchVO.setSelectedClaimRefNbr("");
						searchVO.setSelectedClaimRevNbr("");
						searchVO.setSelectedClaimSeqNbr("");
					}
					searchVO.setIconFlag("N");
					sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ERROR_VO,searchVO);
					break;
				case ChartConstants.ENUM_METHOD_DASHDETAILSELECT:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_DASH_METHOD,ChartConstants.METHOD_DASHDETAILOPTION);
					context.setSelectedMenu(ChartConstants.MENU_DASHBOARD);
					context.setSelectedOption(ChartConstants.OPTION_DASHINSTDETAIL);
					context.getEncounterVO().setInstClaim(null);
					context.getEncounterVO().setProfClaim(null);
					if ("0".equals(requestStatus)) {
						//Delete the default VO and recreate the new one to store the search criterias
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);
						if (searchVO != null){
							pagi = searchVO.getClaimDetailPagination();
							oldPosition = searchVO.getMove();
							oldStateVal = searchVO.getOldState();
							sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);	
						}
						
						searchVO = new HpeSearchVO();					
						searchVO.setSubmitterId(chartEncounterForm.getSearchCRDetailSubmitterId());
						searchVO.setClmType(chartEncounterForm.getSearchCRDetailClmType());
						searchVO.setEncType(chartEncounterForm.getSearchCRDetailEncType());
						searchVO.setDateInd(chartEncounterForm.getSearchCRDetailDateInd());					
						searchVO.setFromDate(chartEncounterForm.getSearchCRDetailFromDate());
						searchVO.setToDate(chartEncounterForm.getSearchCRDetailToDate());
						searchVO.setGroupStatus(chartEncounterForm.getSearchCRDetailGroupStatus());	
						searchVO.setErrorCode(chartEncounterForm.getSearchCRDetailErrorCode());	
						searchVO.setErrorGroup(chartEncounterForm.getSearchCRDetailErrorGroup());	
						searchVO.setErrorSource(chartEncounterForm.getSearchCRDetailErrorSource());
						searchVO.setClaimRefNbr(chartEncounterForm.getSearchCRDetailClaimRefNbr());
						searchVO.setHicNbr(chartEncounterForm.getSearchCRDetailHicNbr());					
						searchVO.setSelectedClaimType(chartEncounterForm.getSelectedClaimType());
						searchVO.setSelectedClaimRefNbr(chartEncounterForm.getSelectedClaimRefNbr());
						searchVO.setSelectedClaimRevNbr(chartEncounterForm.getSelectedClaimRevNbr());
						searchVO.setSelectedClaimSeqNbr(chartEncounterForm.getSelectedClaimSeqNbr());	
						searchVO.setPrevMenu(chartEncounterForm.getPrevMenu());
						searchVO.setPrevMethod(chartEncounterForm.getPrevMethod());
						
						//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
						searchVO.setVanTanNumber(chartEncounterForm.getSearchVanTanNumber());
						//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
						
						if (pagi != null) {
							searchVO.setClaimDetailPagination(pagi);	
							searchVO.setMove(oldPosition);
							searchVO.setOldState(oldStateVal);
						}
						if (chartEncounterForm.getSearchCRDetailEncType().equals("I")) {
							searchVO.setListExpanded(chartEncounterForm.isInstListExpanded());
							searchVO.setErrorsExpanded(chartEncounterForm.isInstErrorsExpanded());
							searchVO.setSubscriberExpanded(chartEncounterForm.isInstSubscriberExpanded());
							searchVO.setProviderExpanded(chartEncounterForm.isInstProviderExpanded());
							searchVO.setClaimExpanded(chartEncounterForm.isInstClaimExpanded());
							searchVO.setClaimCodesExpanded(chartEncounterForm.isInstClaimCodesExpanded());
							searchVO.setClaimNotesExpanded(chartEncounterForm.isInstClaimNotesExpanded());
							searchVO.setClaimProvExpanded(chartEncounterForm.isInstClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(chartEncounterForm.isInstClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isInstClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isInstClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isInstClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(chartEncounterForm.isInstClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(chartEncounterForm.isInstClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(chartEncounterForm.isInstClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isInstClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isInstClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isInstClaimLineAdjudDetailExpanded());					
						} else if (chartEncounterForm.getSearchCRDetailEncType().equals("P")) {
							searchVO.setListExpanded(chartEncounterForm.isProfListExpanded());
							searchVO.setErrorsExpanded(chartEncounterForm.isProfErrorsExpanded());
							searchVO.setSubscriberExpanded(chartEncounterForm.isProfSubscriberExpanded());
							searchVO.setProviderExpanded(chartEncounterForm.isProfProviderExpanded());
							searchVO.setClaimExpanded(chartEncounterForm.isProfClaimExpanded());
							searchVO.setClaimCodesExpanded(chartEncounterForm.isProfClaimCodesExpanded());								
							searchVO.setClaimProvExpanded(chartEncounterForm.isProfClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(chartEncounterForm.isProfClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isProfClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isProfClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isProfClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(chartEncounterForm.isProfClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(chartEncounterForm.isProfClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(chartEncounterForm.isProfClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isProfClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isProfClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isProfClaimLineAdjudDetailExpanded());					
						}						
												
						sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO,searchVO);
					}
					requestStatus = "0";
					forward = ChartHelper.selectClaim(conn, sessionHelper, context, chartEncounterForm, request,requestStatus);
					break;
				case ChartConstants.ENUM_METHOD_SUMMDETAILSELECT:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_SUMM_METHOD,ChartConstants.METHOD_SUMMDETAILOPTION);
					context.setSelectedMenu(ChartConstants.MENU_SUMMARY);
					context.setSelectedOption(ChartConstants.OPTION_SUMMINSTDETAIL);
					context.getEncounterVO().setInstClaim(null);
					context.getEncounterVO().setProfClaim(null);
					if ("0".equals(requestStatus)) {
						//Delete the default VO and recreate the new one to store the search criterias
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ERROR_VO);
						if (searchVO != null){
							pagi = searchVO.getClaimDetailPagination();
							oldPosition = searchVO.getMove();
							oldStateVal = searchVO.getOldState();
							sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_ERROR_VO);	
						}
						
						searchVO = new HpeSearchVO();					
						searchVO.setSubmitterId(chartEncounterForm.getSearchCRDetailSubmitterId());
						searchVO.setClmType(chartEncounterForm.getSearchCRDetailClmType());
						searchVO.setEncType(chartEncounterForm.getSearchCRDetailEncType());
						searchVO.setDateInd(chartEncounterForm.getSearchCRDetailDateInd());					
						searchVO.setFromDate(chartEncounterForm.getSearchCRDetailFromDate());
						searchVO.setToDate(chartEncounterForm.getSearchCRDetailToDate());
						searchVO.setGroupStatus(chartEncounterForm.getSearchCRDetailGroupStatus());	
						searchVO.setErrorCode(chartEncounterForm.getSearchCRDetailErrorCode());	
						searchVO.setErrorGroup(chartEncounterForm.getSearchCRDetailErrorGroup());	
						searchVO.setErrorSource(chartEncounterForm.getSearchCRDetailErrorSource());
						searchVO.setClaimRefNbr(chartEncounterForm.getSearchCRDetailClaimRefNbr());
						searchVO.setHicNbr(chartEncounterForm.getSearchCRDetailHicNbr());					
						searchVO.setSelectedClaimType(chartEncounterForm.getSelectedClaimType());
						searchVO.setSelectedClaimRefNbr(chartEncounterForm.getSelectedClaimRefNbr());
						searchVO.setSelectedClaimRevNbr(chartEncounterForm.getSelectedClaimRevNbr());
						searchVO.setSelectedClaimSeqNbr(chartEncounterForm.getSelectedClaimSeqNbr());
						
						//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
						searchVO.setVanTanNumber(chartEncounterForm.getSearchVanTanNumber());
						//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
						
						if (pagi != null) {
							searchVO.setClaimDetailPagination(pagi);	
							searchVO.setMove(oldPosition);
							searchVO.setOldState(oldStateVal);
						}
						if (chartEncounterForm.getSearchCRDetailEncType().equals("I")) {
							searchVO.setListExpanded(chartEncounterForm.isInstListExpanded());
							searchVO.setErrorsExpanded(chartEncounterForm.isInstErrorsExpanded());
							searchVO.setSubscriberExpanded(chartEncounterForm.isInstSubscriberExpanded());
							searchVO.setProviderExpanded(chartEncounterForm.isInstProviderExpanded());
							searchVO.setClaimExpanded(chartEncounterForm.isInstClaimExpanded());
							searchVO.setClaimCodesExpanded(chartEncounterForm.isInstClaimCodesExpanded());
							searchVO.setClaimNotesExpanded(chartEncounterForm.isInstClaimNotesExpanded());
							searchVO.setClaimProvExpanded(chartEncounterForm.isInstClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(chartEncounterForm.isInstClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isInstClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isInstClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isInstClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(chartEncounterForm.isInstClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(chartEncounterForm.isInstClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(chartEncounterForm.isInstClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isInstClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isInstClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isInstClaimLineAdjudDetailExpanded());					
						} else if (chartEncounterForm.getSearchCRDetailEncType().equals("P")) {
							searchVO.setListExpanded(chartEncounterForm.isProfListExpanded());
							searchVO.setErrorsExpanded(chartEncounterForm.isProfErrorsExpanded());
							searchVO.setSubscriberExpanded(chartEncounterForm.isProfSubscriberExpanded());
							searchVO.setProviderExpanded(chartEncounterForm.isProfProviderExpanded());
							searchVO.setClaimExpanded(chartEncounterForm.isProfClaimExpanded());
							searchVO.setClaimCodesExpanded(chartEncounterForm.isProfClaimCodesExpanded());								
							searchVO.setClaimProvExpanded(chartEncounterForm.isProfClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(chartEncounterForm.isProfClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isProfClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isProfClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isProfClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(chartEncounterForm.isProfClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(chartEncounterForm.isProfClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(chartEncounterForm.isProfClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isProfClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isProfClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isProfClaimLineAdjudDetailExpanded());					
						}				
												
						sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ERROR_VO,searchVO);
					}					
					requestStatus = "1";
					forward = ChartHelper.selectClaim(conn, sessionHelper, context, chartEncounterForm, request,requestStatus);
					break;
				case ChartConstants.ENUM_METHOD_DASHDETAILSAVE:
					//context.setSelectedMenu(ChartConstants.MENU_DASHBOARD);
					//context.setSelectedOption(ChartConstants.OPTION_DASHINSTDETAIL);							
					forward = ChartHelper.updateFormData(conn, sessionHelper, context, chartEncounterForm, request);				
					break;
				/*case ChartConstants.ENUM_METHOD_DASHDETAILCLMSAVE:
					//context.setSelectedMenu(ChartConstants.MENU_DASHBOARD);
					//context.setSelectedOption(ChartConstants.OPTION_DASHINSTDETAIL);							
					forward = ChartHelper.updateClaim(conn, sessionHelper, context, chartEncounterForm, request);				
					break;*/					
				case ChartConstants.ENUM_METHOD_DASHPROFMONTH:
					context.setSelectedMenu(ChartConstants.MENU_DASHBOARD);
					context.setSelectedOption(ChartConstants.OPTION_DASHPROFDETAIL);
					forward = ChartConstants.CHART_PROFDETAIL;
					break;
				case ChartConstants.ENUM_METHOD_SUMMTREEOPTION:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_SUMM_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_SUMMARY);
					context.setSelectedOption(ChartConstants.OPTION_SUMMTREE);
					if ("0".equals(requestStatus)) {
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ERROR_VO);					
						if (searchVO != null){
							if (searchVO.getIconFlag().equals("N")) {						
								if (searchVO.getEncType().equals("I")) {
									searchVO.setListExpanded(chartEncounterForm.isInstListExpanded());
									searchVO.setErrorsExpanded(chartEncounterForm.isInstErrorsExpanded());
									searchVO.setSubscriberExpanded(chartEncounterForm.isInstSubscriberExpanded());
									searchVO.setProviderExpanded(chartEncounterForm.isInstProviderExpanded());
									searchVO.setClaimExpanded(chartEncounterForm.isInstClaimExpanded());
									searchVO.setClaimCodesExpanded(chartEncounterForm.isInstClaimCodesExpanded());
									searchVO.setClaimNotesExpanded(chartEncounterForm.isInstClaimNotesExpanded());
									searchVO.setClaimProvExpanded(chartEncounterForm.isInstClaimProvExpanded());
									searchVO.setClaimProvDetailExpanded(chartEncounterForm.isInstClaimProvDetailExpanded());
									searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isInstClaimOtherSubsProvExpanded());
									searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
									searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isInstClaimOtherSubsExpanded());
									searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isInstClaimOtherSubsDetailExpanded());
									searchVO.setClaimLineExpanded(chartEncounterForm.isInstClaimLineExpanded());
									searchVO.setClaimLineDetailExpanded(chartEncounterForm.isInstClaimLineDetailExpanded());
									searchVO.setClaimLineProvExpanded(chartEncounterForm.isInstClaimLineProvExpanded());
									searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isInstClaimLineProvDetailExpanded());
									searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isInstClaimLineAdjudExpanded());
									searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isInstClaimLineAdjudDetailExpanded());								
									
								} else if (searchVO.getEncType().equals("P")){
									searchVO.setListExpanded(chartEncounterForm.isProfListExpanded());
									searchVO.setErrorsExpanded(chartEncounterForm.isProfErrorsExpanded());
									searchVO.setSubscriberExpanded(chartEncounterForm.isProfSubscriberExpanded());
									searchVO.setProviderExpanded(chartEncounterForm.isProfProviderExpanded());
									searchVO.setClaimExpanded(chartEncounterForm.isProfClaimExpanded());
									searchVO.setClaimCodesExpanded(chartEncounterForm.isProfClaimCodesExpanded());								;
									searchVO.setClaimProvExpanded(chartEncounterForm.isProfClaimProvExpanded());
									searchVO.setClaimProvDetailExpanded(chartEncounterForm.isProfClaimProvDetailExpanded());
									searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isProfClaimOtherSubsProvExpanded());
									searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
									searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isProfClaimOtherSubsExpanded());
									searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isProfClaimOtherSubsDetailExpanded());
									searchVO.setClaimLineExpanded(chartEncounterForm.isProfClaimLineExpanded());
									searchVO.setClaimLineDetailExpanded(chartEncounterForm.isProfClaimLineDetailExpanded());
									searchVO.setClaimLineProvExpanded(chartEncounterForm.isProfClaimLineProvExpanded());
									searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isProfClaimLineProvDetailExpanded());
									searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isProfClaimLineAdjudExpanded());
									searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isProfClaimLineAdjudDetailExpanded());								
								}
								searchVO.setIconFlag("Y");								
							} 
							sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ERROR_VO,searchVO);
						}
					}
					ChartHelper.buildErrorStatusSummary(conn, sessionHelper, context, chartEncounterForm, request);					
					forward = ChartConstants.CHART_SUMMTREE;					
					break;	
				case ChartConstants.ENUM_METHOD_SUMMTREESEARCH:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_SUMM_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_SUMMARY);
					context.setSelectedOption(ChartConstants.OPTION_SUMMTREE);	
					
					if ("0".equals(requestStatus)) {
						//Delete the default VO and recreate the new one to store the search criterias
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_REJECT_VO);
						if (searchVO != null){
							sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_REJECT_VO);	
						}
						
						searchVO = new HpeSearchVO();
						searchVO.setSubmitterId(chartEncounterForm.getSearchCRSummarySubmitterId());	
						searchVO.setClmType(chartEncounterForm.getSearchCRSummaryType());
						searchVO.setDateInd(chartEncounterForm.getSearchCRSummaryDateInd());						
						searchVO.setFromDate(chartEncounterForm.getSearchCRSummaryFromDate());
						searchVO.setToDate(chartEncounterForm.getSearchCRSummaryToDate());						
						
						sessionHelper.setAttribute(ChartConstants.SEARCH_CR_REJECT_VO,searchVO);	
					}
					ChartHelper.buildErrorStatusSummary(conn, sessionHelper, context, chartEncounterForm, request);					
					forward = ChartConstants.CHART_SUMMTREE;
					break;
				case ChartConstants.ENUM_METHOD_SUMMINSTMONTH:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_SUMM_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_SUMMARY);
					context.setSelectedOption(ChartConstants.OPTION_CRSUMMINSTREJECTCODES);
					
					if ("0".equals(requestStatus)) {
						chartEncounterForm.setSearchCRSummarySubmitterId(chartEncounterForm.getSearchCRSummarySubmitterId());
						chartEncounterForm.setSearchCRSummaryType(chartEncounterForm.getSearchCRSummaryType());
						chartEncounterForm.setSearchCRSummaryEncType(chartEncounterForm.getSearchCRSummaryEncType());
						chartEncounterForm.setSearchCRSummaryDateInd(chartEncounterForm.getSearchCRSummaryDateInd());					
						chartEncounterForm.setSearchCRSummaryFromDate(chartEncounterForm.getSearchCRSummaryFromDate());
						chartEncounterForm.setSearchCRSummaryToDate(chartEncounterForm.getSearchCRSummaryToDate());					
						chartEncounterForm.setSelectedCRDateYrmo(chartEncounterForm.getSelectedCRDateYrmo());
						chartEncounterForm.setSearchCRSummaryErrorSource(chartEncounterForm.getSearchCRSummaryErrorSource());
						chartEncounterForm.setSearchCRSummaryErrorCode(chartEncounterForm.getSearchCRSummaryErrorCode());					
						
						/* Create the VO to store the data of the user selected row of the Reject Analysis dashboard 
						 * It will be used, when user wants to view the previuos screen data
						 */
						searchVO = new HpeSearchVO();					
						searchVO.setSubmitterId(chartEncounterForm.getSearchCRSummarySubmitterId());
						searchVO.setClmType(chartEncounterForm.getSearchCRSummaryType());
						searchVO.setEncType(chartEncounterForm.getSearchCRSummaryEncType());
						searchVO.setDateInd(chartEncounterForm.getSearchCRSummaryDateInd());
						searchVO.setSelectedDate(chartEncounterForm.getSelectedCRDateYrmo());
						searchVO.setFromDate(chartEncounterForm.getSearchCRSummaryFromDate());
						searchVO.setToDate(chartEncounterForm.getSearchCRSummaryToDate());
						searchVO.setErrorSource(chartEncounterForm.getSearchCRSummaryErrorSource());
						searchVO.setErrorCode(chartEncounterForm.getSearchCRSummaryErrorCode());
						
						sessionHelper.setAttribute(ChartConstants.SEARCH_CR_VO,searchVO);	
					}
					
					forward = ChartHelper.getErrorDetails(conn, sessionHelper, context, chartEncounterForm, request);
					break;
				case ChartConstants.ENUM_METHOD_SUMMREJECTCODESOPTION:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_SUMM_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_SUMMARY);
					context.setSelectedOption(ChartConstants.OPTION_CRSUMMINSTREJECTCODES);	
					
					if ("0".equals(requestStatus)) {
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ERROR_VO);						
						
						if (searchVO != null){
							if (searchVO.getIconFlag().equals("N")) {						
								if (searchVO.getEncType().equals("I")) {
									searchVO.setListExpanded(chartEncounterForm.isInstListExpanded());
									searchVO.setErrorsExpanded(chartEncounterForm.isInstErrorsExpanded());
									searchVO.setSubscriberExpanded(chartEncounterForm.isInstSubscriberExpanded());
									searchVO.setProviderExpanded(chartEncounterForm.isInstProviderExpanded());
									searchVO.setClaimExpanded(chartEncounterForm.isInstClaimExpanded());
									searchVO.setClaimCodesExpanded(chartEncounterForm.isInstClaimCodesExpanded());
									searchVO.setClaimNotesExpanded(chartEncounterForm.isInstClaimNotesExpanded());
									searchVO.setClaimProvExpanded(chartEncounterForm.isInstClaimProvExpanded());
									searchVO.setClaimProvDetailExpanded(chartEncounterForm.isInstClaimProvDetailExpanded());
									searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isInstClaimOtherSubsProvExpanded());
									searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
									searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isInstClaimOtherSubsExpanded());
									searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isInstClaimOtherSubsDetailExpanded());
									searchVO.setClaimLineExpanded(chartEncounterForm.isInstClaimLineExpanded());
									searchVO.setClaimLineDetailExpanded(chartEncounterForm.isInstClaimLineDetailExpanded());
									searchVO.setClaimLineProvExpanded(chartEncounterForm.isInstClaimLineProvExpanded());
									searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isInstClaimLineProvDetailExpanded());
									searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isInstClaimLineAdjudExpanded());
									searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isInstClaimLineAdjudDetailExpanded());								
									
								} else if (searchVO.getEncType().equals("P")){
									searchVO.setListExpanded(chartEncounterForm.isProfListExpanded());
									searchVO.setErrorsExpanded(chartEncounterForm.isProfErrorsExpanded());
									searchVO.setSubscriberExpanded(chartEncounterForm.isProfSubscriberExpanded());
									searchVO.setProviderExpanded(chartEncounterForm.isProfProviderExpanded());
									searchVO.setClaimExpanded(chartEncounterForm.isProfClaimExpanded());
									searchVO.setClaimCodesExpanded(chartEncounterForm.isProfClaimCodesExpanded());								
									searchVO.setClaimProvExpanded(chartEncounterForm.isProfClaimProvExpanded());
									searchVO.setClaimProvDetailExpanded(chartEncounterForm.isProfClaimProvDetailExpanded());
									searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isProfClaimOtherSubsProvExpanded());
									searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
									searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isProfClaimOtherSubsExpanded());
									searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isProfClaimOtherSubsDetailExpanded());
									searchVO.setClaimLineExpanded(chartEncounterForm.isProfClaimLineExpanded());
									searchVO.setClaimLineDetailExpanded(chartEncounterForm.isProfClaimLineDetailExpanded());
									searchVO.setClaimLineProvExpanded(chartEncounterForm.isProfClaimLineProvExpanded());
									searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isProfClaimLineProvDetailExpanded());
									searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isProfClaimLineAdjudExpanded());
									searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isProfClaimLineAdjudDetailExpanded());								
								}
								searchVO.setIconFlag("Y");								
							}							
							sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ERROR_VO,searchVO);							
						}
					}
					
					chartEncounterForm.setSelectedCRDateYrmo("");
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_VO);		
						
					if (searchVO != null) {	
						forward = ChartHelper.getErrorDetails(conn, sessionHelper, context, chartEncounterForm, request);
					} else {
						chartEncounterForm.setSearchCRSummarySubmitterId("");
						chartEncounterForm.setSearchCRSummaryEncType("I");
						chartEncounterForm.setSearchCRSummaryType("CR");
						chartEncounterForm.setSearchCRSummaryDateInd("0");					
						chartEncounterForm.setSearchCRSummaryFromDate("");
						chartEncounterForm.setSearchCRSummaryToDate("");	
						chartEncounterForm.setSearchCRSummaryErrorSource("");
						chartEncounterForm.setSearchCRSummaryErrorCode("");
						
						forward = ChartConstants.CHART_SUMMINSTREJECTCODES;	
					}					
					break;
				case ChartConstants.ENUM_METHOD_ERRORSEARCH:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_SUMM_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_SUMMARY);
					context.setSelectedOption(ChartConstants.OPTION_CRSUMMINSTREJECTCODES);	
					
					if ("0".equals(requestStatus)) {
						//Delete and recreate the VO to store the search criteria of error dashboard page					
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_VO);
						if (searchVO != null){
							sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_VO);	
						}
						
						searchVO = new HpeSearchVO();					
						searchVO.setSubmitterId(chartEncounterForm.getSearchCRSummarySubmitterId());
						searchVO.setClmType(chartEncounterForm.getSearchCRSummaryType());
						searchVO.setEncType(chartEncounterForm.getSearchCRSummaryEncType());
						searchVO.setDateInd(chartEncounterForm.getSearchCRSummaryDateInd());					
						searchVO.setFromDate(chartEncounterForm.getSearchCRSummaryFromDate());
						searchVO.setToDate(chartEncounterForm.getSearchCRSummaryToDate());
						searchVO.setErrorSource(chartEncounterForm.getSearchCRSummaryErrorSource());
						searchVO.setErrorGroup(chartEncounterForm.getSearchCRSummaryErrorGroup());
						searchVO.setErrorCode(chartEncounterForm.getSearchCRSummaryErrorCode());
						sessionHelper.setAttribute(ChartConstants.SEARCH_CR_VO,searchVO);
					}
					
					forward = ChartHelper.getErrorDetails(conn, sessionHelper, context, chartEncounterForm, request);														
					break;			
				case ChartConstants.ENUM_METHOD_SUMMINSTSYNMONTH:
				case ChartConstants.ENUM_METHOD_SUMMINSTCCRMONTH:
				case ChartConstants.ENUM_METHOD_SUMMINSTREJMONTH:
				case ChartConstants.ENUM_METHOD_SUMMINSTTOTMONTH:
					context.setSelectedMenu(ChartConstants.MENU_SUMMARY);
					context.setSelectedOption(ChartConstants.OPTION_CRSUMMINSTREJECTCODES);

					//	List lst = new ArrayList();
					//	HPETestVO objVO = new HPETestVO();
					//
					//	switch (enumMethod) {
					//		case ChartConstants.ENUM_METHOD_SUMMINSTSYNMONTH:
					//			objVO.setCol("Syntax");
					//			break;
					//		case ChartConstants.ENUM_METHOD_SUMMINSTCCRMONTH:
					//			objVO.setCol("CCR");
					//			break;
					//		case ChartConstants.ENUM_METHOD_SUMMINSTREJMONTH:
					//			objVO.setCol("Rejected");
					//			break;
					//		case ChartConstants.ENUM_METHOD_SUMMINSTTOTMONTH:
					//			objVO.setCol("Syntax");
					//			break;
					//	}
					//
					//	lst.add(objVO);
					//	formHPE.setTestList(lst);

					forward = ChartConstants.CHART_SUMMINSTREJECTCODES;
					break;
				case ChartConstants.ENUM_METHOD_SUMMPROFSYNMONTH:
				case ChartConstants.ENUM_METHOD_SUMMPROFCCRMONTH:
				case ChartConstants.ENUM_METHOD_SUMMPROFREJMONTH:
				case ChartConstants.ENUM_METHOD_SUMMPROFTOTMONTH:
					context.setSelectedMenu(ChartConstants.MENU_SUMMARY);
					context.setSelectedOption(ChartConstants.OPTION_CRSUMMPROFREJECTCODES);

					//	List lst = new ArrayList();
					//	HPETestVO objVO = new HPETestVO();
					//
					//	switch (enumMethod) {
					//		case ChartConstants.ENUM_METHOD_SUMMPROFSYNMONTH:
					//			objVO.setCol("Syntax");
					//			break;
					//		case ChartConstants.ENUM_METHOD_SUMMPROFCCRMONTH:
					//			objVO.setCol("CCR");
					//			break;
					//		case ChartConstants.ENUM_METHOD_SUMMPROFREJMONTH:
					//			objVO.setCol("Rejected");
					//			break;
					//		case ChartConstants.ENUM_METHOD_SUMMPROFTOTMONTH:
					//			objVO.setCol("Syntax");
					//			break;
					//	}
					//
					//	lst.add(objVO);
					//	formHPE.setTestList(lst);

					forward = ChartConstants.CHART_SUMMPROFREJECTCODES;
					break;	
				case ChartConstants.ENUM_METHOD_SUMMDETAILOPTION:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_SUMM_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_SUMMARY);
					context.setSelectedOption(ChartConstants.OPTION_SUMMINSTDETAIL);
					sessionHelper.setAttribute(ChartConstants.HPE_BACK,"false");
					
					if ("0".equals(requestStatus)) {
						chartEncounterForm.setSearchCRDetailSubmitterId(chartEncounterForm.getSearchCRSummarySubmitterId());
						chartEncounterForm.setSearchCRDetailClmType(chartEncounterForm.getSearchCRSummaryType());
						chartEncounterForm.setSearchCRDetailEncType(chartEncounterForm.getSearchCRSummaryEncType());
						chartEncounterForm.setSearchCRDetailDateInd(chartEncounterForm.getSearchCRSummaryDateInd());
						chartEncounterForm.setSearchCRDetailFromDate(DateFormatter.reFormat(chartEncounterForm.getSelectedCRDateYrmo(), DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_START));
						chartEncounterForm.setSearchCRDetailToDate(DateFormatter.reFormat(chartEncounterForm.getSelectedCRDateYrmo(), DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_END));					
						chartEncounterForm.setFormattedErrorSource(chartEncounterForm.getFormattedErrorSource());
						chartEncounterForm.setRejectCode(chartEncounterForm.getRejectCode());
						
						/* Create the VO to store the data of the user selected row of the Error dashboard 
						 * It will be used, when user wants to view the previuos screen data
						 */
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ERROR_VO);
						if (searchVO != null){
							sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_ERROR_VO);
						}
						
						searchVO = new HpeSearchVO();					
						searchVO.setSubmitterId(chartEncounterForm.getSearchCRSummarySubmitterId());
						searchVO.setClmType(chartEncounterForm.getSearchCRSummaryType());
						searchVO.setEncType(chartEncounterForm.getSearchCRSummaryEncType());
						searchVO.setDateInd(chartEncounterForm.getSearchCRSummaryDateInd());
						searchVO.setSelectedDate(chartEncounterForm.getSelectedCRDateYrmo());
						searchVO.setFromDate(chartEncounterForm.getSearchCRSummaryFromDate());
						searchVO.setToDate(chartEncounterForm.getSearchCRSummaryToDate());
						searchVO.setErrorSource(chartEncounterForm.getSearchCRSummaryErrorSource());
						searchVO.setErrorCode(chartEncounterForm.getSearchCRSummaryErrorCode());
						searchVO.setFormattedErrorSource(chartEncounterForm.getFormattedErrorSource());
						searchVO.setRejectCode(chartEncounterForm.getRejectCode());
						searchVO.setErrorGroup(chartEncounterForm.getSelectedCRErrorGroup());
						sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ERROR_VO,searchVO);
					}
					
					forward = ChartHelper.selectErrorSpecificClaims(conn, sessionHelper, context, chartEncounterForm, request);					
					break;
				case ChartConstants.ENUM_METHOD_SUMMENCOUNTEROPTION:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_SUMM_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_SUMMARY);
					context.setSelectedOption(ChartConstants.OPTION_SUMMINSTDETAIL);
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ERROR_VO);
					sessionHelper.setAttribute(ChartConstants.HPE_BACK,"false");
					
					if (searchVO != null) {
						searchVO.setIconFlag("N");
						sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ERROR_VO,searchVO);
					}
					forward = ChartHelper.selectErrorSpecificClaims(conn, sessionHelper, context, chartEncounterForm, request);	
					break;
				case ChartConstants.ENUM_METHOD_CHARTDETAILOPTION:					
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_DASH_METHOD,method);
					sessionHelper.setAttribute(ChartConstants.HPE_BACK,"TRUE");
					context.setSelectedMenu(ChartConstants.MENU_DASHBOARD);
					context.setSelectedOption(ChartConstants.OPTION_DASHINSTDETAIL);
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);
					if (searchVO != null){
						sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);
					}
					
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_BACK_VO);
					if (searchVO != null) {
						chartEncounterForm.setClaimRefNbr(searchVO.getClaimRefNbr());
						chartEncounterForm.setClmType(searchVO.getClmType());
						chartEncounterForm.setClaimType(searchVO.getEncType());
						chartEncounterForm.setSubmitterId(searchVO.getSubmitterId());
						chartEncounterForm.setPrevMenu(searchVO.getPrevMenu());
						chartEncounterForm.setPrevMethod(searchVO.getPrevMethod());	
						chartEncounterForm.setDateInd(searchVO.getDateInd());
						if (searchVO.getEncType().equals("I")) {
							chartEncounterForm.setInstListExpanded(searchVO.isListExpanded());
							chartEncounterForm.setInstErrorsExpanded(searchVO.isErrorsExpanded());
							chartEncounterForm.setInstSubscriberExpanded(searchVO.isSubscriberExpanded());
							chartEncounterForm.setInstProviderExpanded(searchVO.isProviderExpanded());
							chartEncounterForm.setInstClaimExpanded(searchVO.isClaimExpanded());
							chartEncounterForm.setInstClaimCodesExpanded(searchVO.isClaimCodesExpanded());
							chartEncounterForm.setInstClaimNotesExpanded(searchVO.isClaimNotesExpanded());
							chartEncounterForm.setInstClaimProvExpanded(searchVO.isClaimProvExpanded());
							chartEncounterForm.setInstClaimProvDetailExpanded(searchVO.isClaimProvDetailExpanded());
							chartEncounterForm.setInstClaimOtherSubsProvExpanded(searchVO.isClaimOtherSubsProvExpanded());
							chartEncounterForm.setInstClaimOtherSubsProvDetailExpanded(searchVO.isClaimOtherSubsProvDetailExpanded());
							chartEncounterForm.setInstClaimOtherSubsExpanded(searchVO.isClaimOtherSubsExpanded());
							chartEncounterForm.setInstClaimOtherSubsDetailExpanded(searchVO.isClaimOtherSubsDetailExpanded());
							chartEncounterForm.setInstClaimLineExpanded(searchVO.isClaimLineExpanded());
							chartEncounterForm.setInstClaimLineDetailExpanded(searchVO.isClaimLineDetailExpanded());
							chartEncounterForm.setInstClaimLineProvExpanded(searchVO.isClaimLineProvExpanded());
							chartEncounterForm.setInstClaimLineProvDetailExpanded(searchVO.isClaimLineProvDetailExpanded());
							chartEncounterForm.setInstClaimLineAdjudExpanded(searchVO.isClaimLineAdjudExpanded());
							chartEncounterForm.setInstClaimLineAdjudDetailExpanded(searchVO.isClaimLineAdjudDetailExpanded());					
						}else if (searchVO.getEncType().equals("P")) {
							chartEncounterForm.setProfListExpanded(searchVO.isListExpanded());
							chartEncounterForm.setProfErrorsExpanded(searchVO.isErrorsExpanded());
							chartEncounterForm.setProfSubscriberExpanded(searchVO.isSubscriberExpanded());
							chartEncounterForm.setProfProviderExpanded(searchVO.isProviderExpanded());
							chartEncounterForm.setProfClaimExpanded(searchVO.isClaimExpanded());
							chartEncounterForm.setProfClaimCodesExpanded(searchVO.isClaimCodesExpanded());					
							chartEncounterForm.setProfClaimProvExpanded(searchVO.isClaimProvExpanded());
							chartEncounterForm.setProfClaimProvDetailExpanded(searchVO.isClaimProvDetailExpanded());
							chartEncounterForm.setProfClaimOtherSubsProvExpanded(searchVO.isClaimOtherSubsProvExpanded());
							chartEncounterForm.setProfClaimOtherSubsProvDetailExpanded(searchVO.isClaimOtherSubsProvDetailExpanded());
							chartEncounterForm.setProfClaimOtherSubsExpanded(searchVO.isClaimOtherSubsExpanded());
							chartEncounterForm.setProfClaimOtherSubsDetailExpanded(searchVO.isClaimOtherSubsDetailExpanded());
							chartEncounterForm.setProfClaimLineExpanded(searchVO.isClaimLineExpanded());
							chartEncounterForm.setProfClaimLineDetailExpanded(searchVO.isClaimLineDetailExpanded());
							chartEncounterForm.setProfClaimLineProvExpanded(searchVO.isClaimLineProvExpanded());
							chartEncounterForm.setProfClaimLineProvDetailExpanded(searchVO.isClaimLineProvDetailExpanded());
							chartEncounterForm.setProfClaimLineAdjudExpanded(searchVO.isClaimLineAdjudExpanded());
							chartEncounterForm.setProfClaimLineAdjudDetailExpanded(searchVO.isClaimLineAdjudDetailExpanded());					
						}
					}else {
						searchVO = new HpeSearchVO();
						searchVO.setClaimRefNbr(chartEncounterForm.getClaimRefNbr());
						searchVO.setEncType(chartEncounterForm.getClaimType());
						searchVO.setSubmitterId(chartEncounterForm.getSubmitterId());
						searchVO.setPrevMenu(chartEncounterForm.getPrevMenu());
						searchVO.setPrevMethod(chartEncounterForm.getPrevMethod());						
						searchVO.setDateInd(chartEncounterForm.getDateInd());
						searchVO.setClmType(chartEncounterForm.getClmType());
						
						if (searchVO.getEncType().equals("I")) {
							searchVO.setListExpanded(chartEncounterForm.isInstListExpanded());
							searchVO.setErrorsExpanded(chartEncounterForm.isInstErrorsExpanded());
							searchVO.setSubscriberExpanded(chartEncounterForm.isInstSubscriberExpanded());
							searchVO.setProviderExpanded(chartEncounterForm.isInstProviderExpanded());
							searchVO.setClaimExpanded(chartEncounterForm.isInstClaimExpanded());
							searchVO.setClaimCodesExpanded(chartEncounterForm.isInstClaimCodesExpanded());
							searchVO.setClaimNotesExpanded(chartEncounterForm.isInstClaimNotesExpanded());
							searchVO.setClaimProvExpanded(chartEncounterForm.isInstClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(chartEncounterForm.isInstClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isInstClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isInstClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isInstClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(chartEncounterForm.isInstClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(chartEncounterForm.isInstClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(chartEncounterForm.isInstClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isInstClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isInstClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isInstClaimLineAdjudDetailExpanded());								
						} else if (searchVO.getEncType().equals("P")){
							searchVO.setListExpanded(chartEncounterForm.isProfListExpanded());
							searchVO.setErrorsExpanded(chartEncounterForm.isProfErrorsExpanded());
							searchVO.setSubscriberExpanded(chartEncounterForm.isProfSubscriberExpanded());
							searchVO.setProviderExpanded(chartEncounterForm.isProfProviderExpanded());
							searchVO.setClaimExpanded(chartEncounterForm.isProfClaimExpanded());
							searchVO.setClaimCodesExpanded(chartEncounterForm.isProfClaimCodesExpanded());								
							searchVO.setClaimProvExpanded(chartEncounterForm.isProfClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(chartEncounterForm.isProfClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isProfClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isProfClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isProfClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(chartEncounterForm.isProfClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(chartEncounterForm.isProfClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(chartEncounterForm.isProfClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isProfClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isProfClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isProfClaimLineAdjudDetailExpanded());								
						}
					}
					searchVO.setIconFlag("N");
					sessionHelper.setAttribute(ChartConstants.SEARCH_CR_BACK_VO,searchVO);	
										
					chartEncounterForm.setClaimRefNbr(chartEncounterForm.getClaimRefNbr());
					chartEncounterForm.setClaimType(chartEncounterForm.getClaimType());
					chartEncounterForm.setClmType(chartEncounterForm.getClmType());
					chartEncounterForm.setSubmitterId(chartEncounterForm.getSubmitterId());
					chartEncounterForm.setPrevMenu(chartEncounterForm.getPrevMenu());
					chartEncounterForm.setPrevMethod(chartEncounterForm.getPrevMethod());
					sessionHelper.setAttribute(HPEConstants.PREV_DASH_METHOD,chartEncounterForm.getPrevMethod());
					
					forward = ChartHelper.displayCRClaims(conn, sessionHelper, context, chartEncounterForm, request);
					break;
				case ChartConstants.ENUM_METHOD_SUMMPROFREJECTCODES:
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_SUMM_METHOD,method);
					context.setSelectedMenu(ChartConstants.MENU_SUMMARY);
					context.setSelectedOption(ChartConstants.OPTION_SUMMPROFDETAIL);
					forward = ChartConstants.CHART_PROFDETAIL;
					break;
				case ChartConstants.ENUM_METHOD_LOGDETAIL:
					forward = ChartHelper.getClaimChangeLogDetails(conn, sessionHelper, context, chartEncounterForm, request);	
					break;
				case ChartConstants.ENUM_METHOD_LOGHISTORY:
					forward = ChartHelper.getClaimChangeLogHistory(conn, sessionHelper, context, chartEncounterForm, request);	
					break;
				case ChartConstants.ENUM_SWITCH_MENU_EN:					
					menu = chartEncounterForm.getMenu();				
					method = "switchMenu";					
				    
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ERROR_VO);					
					if (searchVO != null){													
						if (searchVO.getEncType().equals("I")) {
							searchVO.setListExpanded(chartEncounterForm.isInstListExpanded());
							searchVO.setErrorsExpanded(chartEncounterForm.isInstErrorsExpanded());
							searchVO.setSubscriberExpanded(chartEncounterForm.isInstSubscriberExpanded());
							searchVO.setProviderExpanded(chartEncounterForm.isInstProviderExpanded());
							searchVO.setClaimExpanded(chartEncounterForm.isInstClaimExpanded());
							searchVO.setClaimCodesExpanded(chartEncounterForm.isInstClaimCodesExpanded());
							searchVO.setClaimNotesExpanded(chartEncounterForm.isInstClaimNotesExpanded());
							searchVO.setClaimProvExpanded(chartEncounterForm.isInstClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(chartEncounterForm.isInstClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isInstClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isInstClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isInstClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(chartEncounterForm.isInstClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(chartEncounterForm.isInstClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(chartEncounterForm.isInstClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isInstClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isInstClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isInstClaimLineAdjudDetailExpanded());								
						} else if (searchVO.getEncType().equals("P")){
							searchVO.setListExpanded(chartEncounterForm.isProfListExpanded());
							searchVO.setErrorsExpanded(chartEncounterForm.isProfErrorsExpanded());
							searchVO.setSubscriberExpanded(chartEncounterForm.isProfSubscriberExpanded());
							searchVO.setProviderExpanded(chartEncounterForm.isProfProviderExpanded());
							searchVO.setClaimExpanded(chartEncounterForm.isProfClaimExpanded());
							searchVO.setClaimCodesExpanded(chartEncounterForm.isProfClaimCodesExpanded());								
							searchVO.setClaimProvExpanded(chartEncounterForm.isProfClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(chartEncounterForm.isProfClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isProfClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isProfClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isProfClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(chartEncounterForm.isProfClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(chartEncounterForm.isProfClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(chartEncounterForm.isProfClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isProfClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isProfClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isProfClaimLineAdjudDetailExpanded());								
						}
						//searchVO.setIconFlag("N");						
					}
					sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ERROR_VO,searchVO);	
												
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);						
					
					if(searchVO == null){
						strStat = "true";
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_CR_BACK_VO);	
					}
					if (searchVO != null){													
						if (searchVO.getEncType().equals("I")) {
							searchVO.setListExpanded(chartEncounterForm.isInstListExpanded());
							searchVO.setErrorsExpanded(chartEncounterForm.isInstErrorsExpanded());
							searchVO.setSubscriberExpanded(chartEncounterForm.isInstSubscriberExpanded());
							searchVO.setProviderExpanded(chartEncounterForm.isInstProviderExpanded());
							searchVO.setClaimExpanded(chartEncounterForm.isInstClaimExpanded());
							searchVO.setClaimCodesExpanded(chartEncounterForm.isInstClaimCodesExpanded());
							searchVO.setClaimNotesExpanded(chartEncounterForm.isInstClaimNotesExpanded());
							searchVO.setClaimProvExpanded(chartEncounterForm.isInstClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(chartEncounterForm.isInstClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isInstClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isInstClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isInstClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(chartEncounterForm.isInstClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(chartEncounterForm.isInstClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(chartEncounterForm.isInstClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isInstClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isInstClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isInstClaimLineAdjudDetailExpanded());								
						} else if (searchVO.getEncType().equals("P")){
							searchVO.setListExpanded(chartEncounterForm.isProfListExpanded());
							searchVO.setErrorsExpanded(chartEncounterForm.isProfErrorsExpanded());
							searchVO.setSubscriberExpanded(chartEncounterForm.isProfSubscriberExpanded());
							searchVO.setProviderExpanded(chartEncounterForm.isProfProviderExpanded());
							searchVO.setClaimExpanded(chartEncounterForm.isProfClaimExpanded());
							searchVO.setClaimCodesExpanded(chartEncounterForm.isProfClaimCodesExpanded());								
							searchVO.setClaimProvExpanded(chartEncounterForm.isProfClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(chartEncounterForm.isProfClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isProfClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(chartEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isProfClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(chartEncounterForm.isProfClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(chartEncounterForm.isProfClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(chartEncounterForm.isProfClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(chartEncounterForm.isProfClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(chartEncounterForm.isProfClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isProfClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(chartEncounterForm.isProfClaimLineAdjudDetailExpanded());								
						}
						searchVO.setIconFlag("Y");						
					} 
					if(strStat.equalsIgnoreCase("false"))
						sessionHelper.setAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO,searchVO);
					else if(strStat.equalsIgnoreCase("true"))
						sessionHelper.setAttribute(ChartConstants.SEARCH_CR_BACK_VO,searchVO);
					
				    String strUrl = "/hpeAction.do?menu="+menu+"&method="+method;
				    response.sendRedirect(strUrl);
				    logger.info(LoggerConstants.methodEndLevel());
				    return null;
				    
				    
				 // File Tracking Project Start 
				  //Traverse CR from file tracking to chart management
				case HPEConstants.ENUM_FILETREE_MOVE_CR:
					menu = chartEncounterForm.getMenu();
					
					sessionHelper.setAttribute(ChartConstants.ENUM_CR_DASH_METHOD, method);
					context.setSelectedMenu(ChartConstants.MENU_DASHBOARD);
					context.setSelectedOption(ChartConstants.OPTION_DASHINSTDETAIL);				
					
					if (backCRFlag.equalsIgnoreCase("false")) {
						if ("0".equals(requestStatus)) {
							// Delete the default VO and recreate the new one to
							// store the search criterias
							searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_FILE_TRACK_VO);
							if (searchVO != null) {
								
								chartEncounterForm.setFileTrackingFlag(true);
								chartEncounterForm.setOrigFileId(searchVO.getSelectedOrigFileId());
								chartEncounterForm.setSearchCRDetailEncType(searchVO.getEncType());
								chartEncounterForm.setSelClaimType("CR");
								chartEncounterForm.setSearchCRDetailGroupStatus(searchVO.getGroupStatus());
								chartEncounterForm.setSearchCRDetailSubmitterId(searchVO.getSubmitterId());
								
								//sessionHelper.removeAttribute(HPEConstants.SEARCH_FILE_TRACK_VO);
							}

							chartEncounterForm.setSubscriberDisplayState(HPEConstants.HPE_SCREEN_VIEW);
							chartEncounterForm.setClaimDisplayState(HPEConstants.HPE_SCREEN_VIEW);
							chartEncounterForm.setProviderDisplayState(HPEConstants.HPE_SCREEN_VIEW);
							chartEncounterForm.setClmProviderDisplayState(HPEConstants.HPE_SCREEN_VIEW);
							
							

							searchVO = new HpeSearchVO();
							searchVO.setSubmitterId(chartEncounterForm.getSearchCRDetailSubmitterId());
							searchVO.setClmType(chartEncounterForm.getSearchCRDetailClmType());
							searchVO.setEncType(chartEncounterForm.getSearchCRDetailEncType());
							searchVO.setDateInd(chartEncounterForm.getSearchCRDetailDateInd());
							searchVO.setFromDate(chartEncounterForm.getSearchCRDetailFromDate());
							searchVO.setToDate(chartEncounterForm.getSearchCRDetailToDate());
							searchVO.setGroupStatus(chartEncounterForm.getSearchCRDetailGroupStatus());
							searchVO.setErrorCode(chartEncounterForm.getSearchCRDetailErrorCode());
							searchVO.setErrorGroup(chartEncounterForm.getSearchCRDetailErrorGroup());
							searchVO.setErrorSource(chartEncounterForm.getSearchCRDetailErrorSource());
							searchVO.setClaimRefNbr(chartEncounterForm.getSearchCRDetailClaimRefNbr());
							searchVO.setHicNbr(chartEncounterForm.getSearchCRDetailHicNbr());
							if (chartEncounterForm.getSearchCRDetailEncType().equals("I")) {
								searchVO.setListExpanded(chartEncounterForm.isInstListExpanded());
								searchVO.setErrorsExpanded(chartEncounterForm.isInstErrorsExpanded());
								searchVO.setSubscriberExpanded(chartEncounterForm.isInstSubscriberExpanded());
								searchVO.setProviderExpanded(chartEncounterForm.isInstProviderExpanded());
								searchVO.setClaimExpanded(chartEncounterForm.isInstClaimExpanded());
								searchVO.setClaimCodesExpanded(chartEncounterForm.isInstClaimCodesExpanded());
								searchVO.setClaimNotesExpanded(chartEncounterForm.isInstClaimNotesExpanded());
								searchVO.setClaimProvExpanded(chartEncounterForm.isInstClaimProvExpanded());
								searchVO.setClaimProvDetailExpanded(chartEncounterForm.isInstClaimProvDetailExpanded());
								searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isInstClaimOtherSubsProvExpanded());
								searchVO.setClaimOtherSubsProvDetailExpanded(
										chartEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
								searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isInstClaimOtherSubsExpanded());
								searchVO.setClaimOtherSubsDetailExpanded(
										chartEncounterForm.isInstClaimOtherSubsDetailExpanded());
								searchVO.setClaimLineExpanded(chartEncounterForm.isInstClaimLineExpanded());
								searchVO.setClaimLineDetailExpanded(chartEncounterForm.isInstClaimLineDetailExpanded());
								searchVO.setClaimLineProvExpanded(chartEncounterForm.isInstClaimLineProvExpanded());
								searchVO.setClaimLineProvDetailExpanded(
										chartEncounterForm.isInstClaimLineProvDetailExpanded());
								searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isInstClaimLineAdjudExpanded());
								searchVO.setClaimLineAdjudDetailExpanded(
										chartEncounterForm.isInstClaimLineAdjudDetailExpanded());
							} else if (chartEncounterForm.getSearchCRDetailEncType().equals("P")) {
								searchVO.setListExpanded(chartEncounterForm.isProfListExpanded());
								searchVO.setErrorsExpanded(chartEncounterForm.isProfErrorsExpanded());
								searchVO.setSubscriberExpanded(chartEncounterForm.isProfSubscriberExpanded());
								searchVO.setProviderExpanded(chartEncounterForm.isProfProviderExpanded());
								searchVO.setClaimExpanded(chartEncounterForm.isProfClaimExpanded());
								searchVO.setClaimCodesExpanded(chartEncounterForm.isProfClaimCodesExpanded());
								searchVO.setClaimProvExpanded(chartEncounterForm.isProfClaimProvExpanded());
								searchVO.setClaimProvDetailExpanded(chartEncounterForm.isProfClaimProvDetailExpanded());
								searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isProfClaimOtherSubsProvExpanded());
								searchVO.setClaimOtherSubsProvDetailExpanded(
										chartEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
								searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isProfClaimOtherSubsExpanded());
								searchVO.setClaimOtherSubsDetailExpanded(
										chartEncounterForm.isProfClaimOtherSubsDetailExpanded());
								searchVO.setClaimLineExpanded(chartEncounterForm.isProfClaimLineExpanded());
								searchVO.setClaimLineDetailExpanded(chartEncounterForm.isProfClaimLineDetailExpanded());
								searchVO.setClaimLineProvExpanded(chartEncounterForm.isProfClaimLineProvExpanded());
								searchVO.setClaimLineProvDetailExpanded(
										chartEncounterForm.isProfClaimLineProvDetailExpanded());
								searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isProfClaimLineAdjudExpanded());
								searchVO.setClaimLineAdjudDetailExpanded(
										chartEncounterForm.isProfClaimLineAdjudDetailExpanded());
							}
							sessionHelper.setAttribute(HPEConstants.SEARCH_FILE_TRACK_VO, searchVO);
						}
					} else {
						sessionHelper.removeAttribute(ChartConstants.HPE_BACK);
						sessionHelper.removeAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
						sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_BACK_VO);
						sessionHelper.removeAttribute(ChartConstants.PREV_CR_DASH_METHOD);
					}
					requestStatus = "2";
					forward = ChartHelper.selectClaims(conn, sessionHelper, context, chartEncounterForm, request,
							requestStatus);
					break;
				// File Tracking project End	
					
					//Editable Fileds CHS -- IFOX-00395627
					
				case ChartConstants.ENUM_METHOD_EDITABLE_CLAIM_CODE_SECTION:	
					logger.debug("in ENUM_METHOD_EDITABLE_CLAIM_CODE_SECTION::::");
					 String heir = (String)request.getParameter("heir");
					 String mfId =  (String)request.getParameter("mfId");
				//	 clmType = (String)request.getParameter("clmType");
					 clmType = context.getChartEncounterVO().getSearchDetailEncType();
					
					 String clmNbr = (String)request.getParameter("clmNbr");
					 String clmRvNbr = (String)request.getParameter("clmRvNbr");
					 String clmSqNbr= (String)request.getParameter("clmSqNbr");
					 String cndSqNbr= (String)request.getParameter("cndSqNbr");	
					 String encType= (String)request.getParameter("encType");
					// String encType = chartEncounterForm.getSelectedClaimType();
					 String delFlag = (String)request.getParameter("delFlag");
					 
					 if(StringUtils.isNotEmpty(mfId)){
						 chartEncounterForm.setEditableMfid(mfId);
					 }
					 if(StringUtils.isNotEmpty(encType)){
						 chartEncounterForm.setEditableEncType(encType);
					 }
					 if(StringUtils.isNotEmpty(clmType)){
						 chartEncounterForm.setSelectedClaimType(clmType);
					 }
					 if(StringUtils.isNotEmpty(clmNbr)){
						 chartEncounterForm.setSelectedClaimRefNbr(clmNbr);
					 }
					 
					 if(StringUtils.isNotEmpty(clmRvNbr)){
						 chartEncounterForm.setSelectedClaimRevNbr(clmRvNbr);
					 }
					 if(StringUtils.isNotEmpty(clmSqNbr)){
						 chartEncounterForm.setSelectedClaimSeqNbr(clmSqNbr);
					 }
					 if(StringUtils.isNotEmpty(cndSqNbr)){
						 chartEncounterForm.setEditableCndSeqNbr(cndSqNbr);
					 }
					 		 
					 
					 if(StringUtils.isNotEmpty(heir)){
						 
						 chartEncounterForm.setHier(heir);
						 
						 if(ChartConstants.EDITABLE_COND_CODE_CNSTNT.equals(heir) || ChartConstants.EDITABLE_TREATMENT_CODE_CNSTNT.equals(heir)){
							 chartEncounterForm.setEditableCode((String)request.getParameter("code")); 
						 }
						 
						 if(ChartConstants.EDITABLE_DIAG_CODE_CNSTNT.equals(heir) || ChartConstants.EDITABLE_EXT_INJ_CODE_CNSTNT.equals(heir)){
							 chartEncounterForm.setEditableCode((String)request.getParameter("code")); 
							 chartEncounterForm.setEditableType((String)request.getParameter("type"));
							 chartEncounterForm.setEditablePOA((String)request.getParameter("poa"));
						 }
						 
						 if(ChartConstants.EDITABLE_PROCEDURE_CODE_CNSTNT.equals(heir)){
							 chartEncounterForm.setEditableCode((String)request.getParameter("code")); 
							 chartEncounterForm.setEditableType((String)request.getParameter("type"));
							 chartEncounterForm.setEditableDate((String)request.getParameter("date"));
						 }
						 if(ChartConstants.EDITABLE_OCCURSPAN_CODE_CNSTNT.equals(heir)){
							 chartEncounterForm.setEditableCode((String)request.getParameter("code"));
							 chartEncounterForm.setEditableFromDt((String)request.getParameter("from"));
							 chartEncounterForm.setEditableThruDt((String)request.getParameter("thru"));
						 }
						 if(ChartConstants.EDITABLE_VALUE_CODE_CNSTNT.equals(heir)){
							 chartEncounterForm.setEditableCode((String)request.getParameter("code"));
							 String amntVal = (String)request.getParameter("amnt");
							 amntVal=amntVal.replaceAll("\\$", "");
							 double amntValue= Double.parseDouble(amntVal);
							 chartEncounterForm.setEditableAmount(amntValue);
							 
						 }
						 if(ChartConstants.EDITABLE_OCCURENCE_CODE_CNSTNT.equals(heir)){
							 chartEncounterForm.setEditableCode((String)request.getParameter("code"));
							 chartEncounterForm.setEditableDate((String)request.getParameter("date"));
						 }
						 //IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
						 if(HPEConstants.EDITABLE_CLMLINE_ADJUD_ADJUST.equals(heir)){
							 chartEncounterForm.setEditableAdjGroupCode((String)request.getParameter("code"));
							 chartEncounterForm.setEditableAdjReasonCode((String)request.getParameter("reason"));
							 chartEncounterForm.setEditableAdjAmount(Double.parseDouble(request.getParameter("amount").replace("$", "")));
							 chartEncounterForm.setEditableAdjQuantity(Integer.parseInt(request.getParameter("quantity")));
							 chartEncounterForm.setEditableAdjudSeqNbr(Integer.parseInt(request.getParameter("adjudseqnbr").trim()));
							 chartEncounterForm.setEditableAdjustSeqNbr(Integer.parseInt(request.getParameter("adjustseqnbr").trim()));
							 chartEncounterForm.setClmliSeqNbr((String)request.getParameter("clmliseqnbr").trim());
						 }
						//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
						
					 }
						
						 
						 forward = ChartHelper.EditableUpdateCodes(conn, sessionHelper, context, request, chartEncounterForm, delFlag); 
						 
					
					PrintWriter out = response.getWriter();	
					 msg.append(forward);
					 out.println(msg.toString());
	                 out.flush();
	                 out.close();
			        logger.debug("Retrieved the Remarks from Xref table -"+forward);
									
					break;
					
				case ChartConstants.ENUM_METHOD_EDITABLE_ADD_CODE_SECTION:
					sessionHelper.setAttribute(ChartConstants.ENUM_DASH_METHOD, method);
					context.setSelectedMenu(ChartConstants.MENU_DASHBOARD);
					context.setSelectedOption(ChartConstants.OPTION_DASHINSTDETAIL);

					if (backCRFlag.equalsIgnoreCase("false")) {
						if ("0".equals(requestStatus)) {
							// Delete the default VO and recreate the new one to
							// store the search criterias
							searchVO = (HpeSearchVO) sessionHelper.getAttribute(ChartConstants.SEARCH_ENCOUNTER_VO);
							if (searchVO != null) {
								sessionHelper.removeAttribute(ChartConstants.SEARCH_ENCOUNTER_VO);
							}

							chartEncounterForm.setSubscriberDisplayState(ChartConstants.HPE_SCREEN_VIEW);
							chartEncounterForm.setClaimDisplayState(ChartConstants.HPE_SCREEN_VIEW);
							chartEncounterForm.setProviderDisplayState(ChartConstants.HPE_SCREEN_VIEW);
							chartEncounterForm.setClmProviderDisplayState(ChartConstants.HPE_SCREEN_VIEW);

							searchVO = new HpeSearchVO();
							searchVO.setSubmitterId(chartEncounterForm.getSearchDetailSubmitterId());
							searchVO.setClmType(chartEncounterForm.getSearchDetailClmType());
							searchVO.setEncType(chartEncounterForm.getSearchDetailEncType());
							searchVO.setDateInd(chartEncounterForm.getSearchDetailDateInd());
							searchVO.setFromDate(chartEncounterForm.getSearchDetailFromDate());
							searchVO.setToDate(chartEncounterForm.getSearchDetailToDate());
							searchVO.setGroupStatus(chartEncounterForm.getSearchDetailGroupStatus());
							searchVO.setErrorCode(chartEncounterForm.getSearchDetailErrorCode());
							searchVO.setErrorGroup(chartEncounterForm.getSearchDetailErrorGroup());
							searchVO.setErrorSource(chartEncounterForm.getSearchDetailErrorSource());
							searchVO.setClaimRefNbr(chartEncounterForm.getSearchDetailClaimRefNbr());
							searchVO.setHicNbr(chartEncounterForm.getSearchDetailHicNbr());
							if (chartEncounterForm.getSearchDetailEncType().equals("I")) {
								searchVO.setListExpanded(chartEncounterForm.isInstListExpanded());
								searchVO.setErrorsExpanded(chartEncounterForm.isInstErrorsExpanded());
								searchVO.setSubscriberExpanded(chartEncounterForm.isInstSubscriberExpanded());
								searchVO.setProviderExpanded(chartEncounterForm.isInstProviderExpanded());
								searchVO.setClaimExpanded(chartEncounterForm.isInstClaimExpanded());
								searchVO.setClaimCodesExpanded(chartEncounterForm.isInstClaimCodesExpanded());
								searchVO.setClaimNotesExpanded(chartEncounterForm.isInstClaimNotesExpanded());
								searchVO.setClaimProvExpanded(chartEncounterForm.isInstClaimProvExpanded());
								searchVO.setClaimProvDetailExpanded(chartEncounterForm.isInstClaimProvDetailExpanded());
								searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isInstClaimOtherSubsProvExpanded());
								searchVO.setClaimOtherSubsProvDetailExpanded(
										chartEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
								searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isInstClaimOtherSubsExpanded());
								searchVO.setClaimOtherSubsDetailExpanded(
										chartEncounterForm.isInstClaimOtherSubsDetailExpanded());
								searchVO.setClaimLineExpanded(chartEncounterForm.isInstClaimLineExpanded());
								searchVO.setClaimLineDetailExpanded(chartEncounterForm.isInstClaimLineDetailExpanded());
								searchVO.setClaimLineProvExpanded(chartEncounterForm.isInstClaimLineProvExpanded());
								searchVO.setClaimLineProvDetailExpanded(
										chartEncounterForm.isInstClaimLineProvDetailExpanded());
								searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isInstClaimLineAdjudExpanded());
								searchVO.setClaimLineAdjudDetailExpanded(
										chartEncounterForm.isInstClaimLineAdjudDetailExpanded());
							} else if (chartEncounterForm.getSearchDetailEncType().equals("P") || chartEncounterForm.getSearchDetailEncType().equals("E")) {
								searchVO.setListExpanded(chartEncounterForm.isProfListExpanded());
								searchVO.setErrorsExpanded(chartEncounterForm.isProfErrorsExpanded());
								searchVO.setSubscriberExpanded(chartEncounterForm.isProfSubscriberExpanded());
								searchVO.setProviderExpanded(chartEncounterForm.isProfProviderExpanded());
								searchVO.setClaimExpanded(chartEncounterForm.isProfClaimExpanded());
								searchVO.setClaimCodesExpanded(chartEncounterForm.isProfClaimCodesExpanded());
								searchVO.setClaimProvExpanded(chartEncounterForm.isProfClaimProvExpanded());
								searchVO.setClaimProvDetailExpanded(chartEncounterForm.isProfClaimProvDetailExpanded());
								searchVO.setClaimOtherSubsProvExpanded(chartEncounterForm.isProfClaimOtherSubsProvExpanded());
								searchVO.setClaimOtherSubsProvDetailExpanded(
										chartEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
								searchVO.setClaimOtherSubsExpanded(chartEncounterForm.isProfClaimOtherSubsExpanded());
								searchVO.setClaimOtherSubsDetailExpanded(
										chartEncounterForm.isProfClaimOtherSubsDetailExpanded());
								searchVO.setClaimLineExpanded(chartEncounterForm.isProfClaimLineExpanded());
								searchVO.setClaimLineDetailExpanded(chartEncounterForm.isProfClaimLineDetailExpanded());
								searchVO.setClaimLineProvExpanded(chartEncounterForm.isProfClaimLineProvExpanded());
								searchVO.setClaimLineProvDetailExpanded(
										chartEncounterForm.isProfClaimLineProvDetailExpanded());
								searchVO.setClaimLineAdjudExpanded(chartEncounterForm.isProfClaimLineAdjudExpanded());
								searchVO.setClaimLineAdjudDetailExpanded(
										chartEncounterForm.isProfClaimLineAdjudDetailExpanded());
							}
							sessionHelper.setAttribute(HPEConstants.SEARCH_ENCOUNTER_VO, searchVO);
						}
					} else {
						sessionHelper.removeAttribute(ChartConstants.HPE_BACK);
						sessionHelper.removeAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
						sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_BACK_VO);
						sessionHelper.removeAttribute(ChartConstants.PREV_CR_DASH_METHOD);
					}
					requestStatus = "0";
					
					chartEncounterForm.setSelectedClaimRefNbr(chartEncounterForm.getFirstClaimRefNbr());
					chartEncounterForm.setEditableMfid(sessionHelper.getMfId());
					chartEncounterForm.setSelectedClaimRevNbr(chartEncounterForm.getFirstClaimRevNbr());
					chartEncounterForm.setSelectedClaimSeqNbr(chartEncounterForm.getFirstClaimSeqNbr());
					chartEncounterForm.setEditableEncType(searchVO.getClmType());
					chartEncounterForm.setSelectedClaimType(chartEncounterForm.getFirstClaimType());
					
					
					 forward = ChartHelper.EditableUpdateCodes(conn, sessionHelper, context, request, chartEncounterForm, "ADD");
					
					forward = ChartHelper.selectClaims(conn, sessionHelper, context, chartEncounterForm, request,
							requestStatus);
					break;	   
				    
				    
				    
				    
				    
				    
				default:
					forward = ChartConstants.CHART_ERROR;
					break;
			}
			
		}
		catch(Exception e) {
		//logger.error(e.getMessage());
		logger.error(LoggerConstants.exceptionMessage(e.toString()));
		}
		finally {
			try {
				if (conn != null)
					conn.close();
			}
			catch(Exception e) {
			logger.error(e.getMessage());
			}
		}	
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(forward);
	}
}

