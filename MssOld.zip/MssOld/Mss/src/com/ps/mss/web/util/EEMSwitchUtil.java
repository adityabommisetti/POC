package com.ps.mss.web.util;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import java.sql.Connection;
import java.util.List;

/*import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
*/
import com.ps.mss.businesslogic.EEMSupvsrService;
/*LEP CR Changes Start.*/
import com.ps.mss.dao.EEMEnrollDao;
import com.ps.mss.dao.model.EmMbrEnrollmentVO;
/*LEP CR Changes End.*/
import com.ps.mss.web.forms.EEMBillDraftForm;
import com.ps.mss.db.EEMProfileSettings;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.manager.EEMBillingManager;
import com.ps.mss.manager.EEMEnrollManager;
import com.ps.mss.manager.EEMLetterManager;
import com.ps.mss.manager.EEMLetterReviewManager;
import com.ps.mss.model.EEMContext;
import com.ps.mss.model.EEMEnrollVO;
import com.ps.mss.model.EEMLetterReqVO;
import com.ps.mss.model.EEMSupvsrVO;
import com.ps.mss.model.EMLetterReqDisplayVO;
import com.ps.mss.model.Pagination;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.actions.EEMAction;
/*import com.ps.mss.web.Process.EEMWorkFlowProcess;*/
import com.ps.mss.web.actions.EEMSecurityAction;
import com.ps.mss.web.forms.EEMApplForm;
import com.ps.mss.web.forms.EEMBillInvoiceForm;
import com.ps.mss.web.forms.EEMBillMembPaymentsForm;
import com.ps.mss.web.forms.EEMBillPaymentsForm;
import com.ps.mss.web.forms.EEMCobFlowForm;
import com.ps.mss.web.forms.EEMDshBrdForm;
import com.ps.mss.web.forms.EEMEnrollForm;
import com.ps.mss.web.forms.EEMForm;
import com.ps.mss.web.forms.EEMGroupForm;
import com.ps.mss.web.forms.EEMLetterReqForm;
import com.ps.mss.web.forms.EEMLetterReviewAttachmentForm;
import com.ps.mss.web.forms.EEMLetterReviewDetailForm;
import com.ps.mss.web.forms.EEMLetterReviewQCForm;
import com.ps.mss.web.forms.EEMMbrDshBrdForm;
import com.ps.mss.web.forms.EEMMedicaidForm;
import com.ps.mss.web.forms.EEMSecurityRolesForm;
import com.ps.mss.web.forms.EEMSupvsrForm;
import com.ps.mss.web.forms.EEMTimersForm;
import com.ps.mss.web.forms.EEMWorkFlowForm;
import com.ps.mss.web.helper.EEMApplHelper;
import com.ps.mss.web.helper.EEMBillingHelper;
import com.ps.mss.web.helper.EEMCobHelper;
import com.ps.mss.web.helper.EEMDshBrdHelper;
import com.ps.mss.web.helper.EEMEnrollHelper;
import com.ps.mss.web.helper.EEMGroupHelper;
import com.ps.mss.web.helper.EEMLetterHelper;
import com.ps.mss.web.helper.EEMLetterReviewHelper;
import com.ps.mss.web.helper.EEMMbrDshBrdHelper;
import com.ps.mss.web.helper.EEMSecRolesHelper;
import com.ps.mss.web.helper.EEMSupvsrHelper;
import com.ps.mss.web.helper.EEMTimersHelper;
import com.ps.mss.web.helper.EEMWorkFlowHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.web.process.EEMWorkFlowProcess;
import com.ps.util.StringUtil;


public class EEMSwitchUtil {
	/*static Logger logger = LoggerFactory.getLogger(EEMSwitchUtil.class);*/
	public static ActionForward switchMenu(ActionMapping mapping,Connection conn,EEMContext context, ActionForm form,EEMForm eemForm, SessionHelper sessionHelper, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String menu = eemForm.getMenu();
		
		// TSA : Spanish Language Change :start
		HttpSession session =request.getSession(false);
		
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
				String corrLabel = EEMProfileSettings.getCalendarProfileText(eemDb, sessionHelper.getMfId(), "DCORRLANG");
				session.setAttribute("CORRLANG", corrLabel);
				sessionHelper.setAttribute("CORRLANG", corrLabel);
				// TSA : Spanish Language Change :end
				//M360 lookup from Recon : IFOX-00428244-start
				String medicaidID = StringUtil.nonNullTrim(request.getParameter("medId"));
				//M360 lookup from Recon : IFOX-00428244-end
				
				//IFOX - 430896 LTr QC CR : start
				String indValue = EEMProfileSettings.getCalendarProfileText(eemDb, sessionHelper.getMfId(),
						"LTRQCIND");
				sessionHelper.setAttribute("QCPROFIND",StringUtil.nonNullTrim(indValue));
				//IFOX - 430896 LTr QC CR : end
				//IFOX-00430896 - Ltter Upload Changes for Sentara -start
				String uploadProf = EEMProfileSettings.getCalendarProfileText(eemDb, sessionHelper.getMfId(),
						"LTRUPLD");
				sessionHelper.setAttribute("LTRUPLD",StringUtil.nonNullTrim(uploadProf));
				//IFOX-00430896 - Ltter Upload Changes for Sentara -end
				if(eemForm instanceof EEMEnrollForm) {
			EEMEnrollHelper.saveEEMForm(sessionHelper,(EEMEnrollForm)eemForm);
		}
		else
		if(eemForm instanceof EEMApplForm) {
		
			
			EEMApplHelper.saveEEMForm(sessionHelper,(EEMApplForm)eemForm);
			/**
			 * Cambia_OevProcess-Start
			 */
			((EEMApplForm) eemForm).getOevTimerCheck();
				/**
				 * Cambia_OevProcess-End
				 */
		 
		}
		else
		if(eemForm instanceof EEMLetterReqForm) {
			EEMLetterHelper.saveEEMForm(sessionHelper,(EEMLetterReqForm)eemForm);
		}
		else
		if(eemForm instanceof EEMSupvsrForm) {
			EEMSupvsrHelper.saveEEMForm(sessionHelper,(EEMSupvsrForm)eemForm);
		}
		else
		if(eemForm instanceof EEMLetterReviewDetailForm) {
			EEMLetterReviewHelper.saveEEMDetailForm(sessionHelper,(EEMLetterReviewDetailForm)eemForm);
		}
		else
		if(eemForm instanceof EEMGroupForm) {
			EEMGroupHelper.saveEEMForm(sessionHelper,(EEMGroupForm)eemForm);
		}
		else
		if(eemForm instanceof EEMBillInvoiceForm) {
			EEMBillingHelper.saveEEMFormInv(sessionHelper,(EEMBillInvoiceForm)eemForm);
		}
		else
		if(eemForm instanceof EEMBillPaymentsForm) {
			EEMBillingHelper.saveEEMFormPay(sessionHelper,(EEMBillPaymentsForm)eemForm);
		}
		else
		if(eemForm instanceof EEMDshBrdForm) {
			EEMDshBrdHelper.saveEEMForm(sessionHelper,(EEMDshBrdForm)eemForm);
		}
		else
		if(eemForm instanceof EEMMbrDshBrdForm) {
			EEMMbrDshBrdHelper.saveEEMForm(sessionHelper,(EEMMbrDshBrdForm)eemForm);
		}
		
       else if (eemForm instanceof EEMTimersForm) {
			

			EEMTimersHelper.saveEEMForm(sessionHelper,(EEMTimersForm) eemForm);
		}
	/**
	 * Cambia_Security_Roles - Start
	 */
	 if (eemForm instanceof EEMSecurityRolesForm) {

		EEMSecRolesHelper.saveEEMForm(sessionHelper,
				(EEMSecurityRolesForm) eemForm);
	}
	/**
	 * Cambia_Security_Roles - Start
	 */
		
	
		    /**
			* 045_WORKFLOW - Start
			*/
			else if (eemForm instanceof EEMWorkFlowForm) {
				EEMWorkFlowHelper.saveEEMWorkFlowForm(sessionHelper, (EEMWorkFlowForm) eemForm);
			}
			/**
			 * 045_WORKFLOW  - End
			 */
			else if (eemForm instanceof EEMCobFlowForm) {
				

				EEMCobHelper.saveEEMForm(sessionHelper, (EEMCobFlowForm)eemForm);
			}
		if (EEMConstants.MENU_APPL.equals(menu))
			return eemApplMenu(conn, sessionHelper, context, mapping, form, request);
		if (EEMConstants.MENU_ENROLLMENT.equals(menu))
			return eemEnrollmentMenu(conn, sessionHelper, context, mapping, form, request);
		if (EEMConstants.MENU_DASHBOARD.equals(menu))
			return eemDashBoard(conn, sessionHelper, context, mapping, form, request);
		if (EEMConstants.MENU_MBR_DASHBOARD.equals(menu))
			return eemMbrDashBoard(conn, sessionHelper, context, mapping, form, request);
		if (EEMConstants.MENU_APPROVALS.equals(menu))
			return eemSupvsrApproval(conn, sessionHelper, context, mapping, form, request);
		if (EEMConstants.MENU_GROUP.equals(menu))
			return eemGroupSelect(conn, sessionHelper, context, mapping, form, request);
		if (EEMConstants.MENU_LETTER.equals(menu))
			return eemLetterReqMenu(conn, sessionHelper, context, mapping, form, request);
		if (EEMConstants.MENU_LETTER_REVIEW.equals(menu))
			return eemLetterReviewMenu(conn, sessionHelper, context, mapping, form, request);
		if (EEMConstants.MENU_BILLING.equals(menu))
			return eemBillingMenu(conn, sessionHelper, context, mapping, form, request);
		/**
		 * Cambia_Timers - Start
		 */
		if (EEMConstants.MENU_TIMERS.equals(menu))
			return eemTimersMenu(conn, sessionHelper, context, mapping, form, request);
		/**
		 * Cambia_Timers - End
		 */
		/**
		 * Cambia_SUC_Security_Roles - Start 
		 */
		if (EEMConstants.MENU_SECROLES.equals(menu))
			return EEMSecurityAction.eemSecRolesMenu(conn, sessionHelper, context, mapping, form, request);
		
		/**
		 * Cambia_SUC_Security_Roles - End
		 */
	
	
		/**
		 * 045_WORKFLOW - Start
		 */
		if (EEMConstants.MENU_WF.equals(menu)) {
			return new EEMWorkFlowProcess().switchMenu(conn, sessionHelper, context, mapping, form, request);
		}
		//M360 lookup from Recon : IFOX-00428244-start
		if (EEMConstants.MENU_MBR.equals(menu)) {
			return lookUpM360(medicaidID,conn, sessionHelper, context, mapping, form, request);
		}
		//M360 lookup from Recon : IFOX-00428244-end
		if (EEMConstants.MENU_COB.equals(menu)) {
			//return new EEMWorkFlowProcess().switchMenu(conn, sessionHelper, context, mapping, form, request);

			context.setSelectedMenu(EEMConstants.MENU_COB);	
			//return mapping.findForward(EEMConstants.EEM_COB_WF);
			return eemCobFlowMenu(conn, sessionHelper, context, mapping, eemForm, request);
		}
		if (EEMConstants.MENU_MEDICAID.equals(menu)) {
			//return new EEMWorkFlowProcess().switchMenu(conn, sessionHelper, context, mapping, form, request);

			context.setSelectedMenu(EEMConstants.MENU_MEDICAID);
			/*EEMMedicaidForm mform = (EEMMedicaidForm)eemForm;
			mform.setSelectedMemberTab(EEMConstants.EEM_MBR_TAB_DEMOGRAPHIC);*/
			return mapping.findForward(EEMConstants.EEM_MEDICAID);
			//return eemCobFlowMenu(conn, sessionHelper, context, mapping, eemForm, request);
		}
		/**
		 * 045_WORKFLOW - end
		 */
		return mapping.findForward("eemError");
		
	
	}
	//M360 lookup from Recon : IFOX-00428244-start
private static ActionForward lookUpM360(String medicaidID, Connection conn, SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
	context.setSelectedMenu(EEMConstants.MENU_ENROLLMENT);
	if (!(form instanceof EEMEnrollForm)) {
		
		EEMEnrollForm eemEnrollForm = EEMEnrollHelper.getEEMForm(sessionHelper);
		if (eemEnrollForm == null) {
			eemEnrollForm = new EEMEnrollForm();
			eemEnrollForm.setSelectedMemberTab("");
			eemEnrollForm.setTabPageMove("");
		}
		
		EEMEnrollVO enrollVO = context.getEnrollVO();
		/*LEP CR Changes Start.*/
		EEMEnrollDao dao = new EEMEnrollDao();
		/*LEP CR Changes End.*/
		enrollVO.setMessage("");
		EEMEnrollHelper.setEnrollFormList(eemEnrollForm, sessionHelper.getSession());
		EEMEnrollHelper.copyVOToForm(enrollVO,eemEnrollForm);
		EEMEnrollHelper.setDisplayItems(enrollVO,eemEnrollForm);
		EEMEnrollManager.setAgentsLookUp(conn, sessionHelper, eemEnrollForm);
		request.setAttribute(EEMConstants.EEM_ENROLL_FORM, eemEnrollForm);
		eemEnrollForm.setOevCallAttempts((List) sessionHelper.getSession().getAttribute(EEMConstants.SESSION_OEV_SEARCH1));
		eemEnrollForm.setOevCallStatus((List) sessionHelper.getSession().getAttribute(EEMConstants.SESSION_OEV_SEARCH2));
		eemEnrollForm.setOevCallStatusSaved((List) sessionHelper.getSession().getAttribute(EEMConstants.SESSION_OEV_SEARCH3));
		eemEnrollForm.setOevRetStatus((List) sessionHelper.getSession().getAttribute(EEMConstants.SESSION_OEV_SEARCH4));
		eemEnrollForm.setOevRetStatusSaved((List) sessionHelper.getSession().getAttribute(EEMConstants.SESSION_OEV_SEARCH5));
		eemEnrollForm.setReturnCalls((List) sessionHelper.getSession().getAttribute(EEMConstants.SESSION_OEV_SEARCH6));
		/*LEP CR Changes Start.*/
		if(eemEnrollForm.getListEnrollments() != null && eemEnrollForm.getListEnrollments().size() > 0){
			eemEnrollForm.setLepMaximusInfo(dao.getLepMaximusDetails(conn, sessionHelper.getMfId(), ((EmMbrEnrollmentVO)eemEnrollForm.getListEnrollments().get(0)).getMemberId()));
		}
		/*LEP CR Changes End.*/
		eemEnrollForm.setSearchHicNo(medicaidID);
		new EEMAction().eemEnrollSearch(conn, sessionHelper, context, mapping, eemEnrollForm, request);
	}		
	
	return mapping.findForward(EEMConstants.EEM_ENROLLMENT);
	}
//M360 lookup from Recon : IFOX-00428244-end
private static ActionForward eemApplMenu(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		
	EEMApplForm eemApplForm = null;
	context.setSelectedMenu(EEMConstants.MENU_APPL);
	if (!(form instanceof EEMApplForm)) {
		
		eemApplForm = EEMApplHelper.getEEMForm(sessionHelper);
		if (eemApplForm == null) {
			eemApplForm = new EEMApplForm();
			eemApplForm.setVisible("N");
			eemApplForm.setApplType("");
		}
		
		request.setAttribute(EEMConstants.EEM_APPL_FORM, eemApplForm);
	} else {
		eemApplForm = (EEMApplForm)form;
	}
	EEMApplHelper.setCommentList(eemApplForm);
	EEMApplHelper.setApplFormList(eemApplForm, sessionHelper);
	EEMApplHelper.loadLookUps(conn,eemApplForm,sessionHelper);	
	/**
	 * Cambia_OevProcess-Start
	 */
	eemApplForm.setOevCallAttempts((List) sessionHelper.getSession().getAttribute(EEMConstants.SESSION_OEV_SEARCH1));
	eemApplForm.setOevCallStatus((List) sessionHelper.getSession().getAttribute(EEMConstants.SESSION_OEV_SEARCH2));
	eemApplForm.setOevCallStatusSaved((List) sessionHelper.getSession().getAttribute(EEMConstants.SESSION_OEV_SEARCH3));
	eemApplForm.setOevRetStatus((List) sessionHelper.getSession().getAttribute(EEMConstants.SESSION_OEV_SEARCH4));
	eemApplForm.setOevRetStatusSaved((List) sessionHelper.getSession().getAttribute(EEMConstants.SESSION_OEV_SEARCH5));
	eemApplForm.setReturnCalls((List) sessionHelper.getSession().getAttribute(EEMConstants.SESSION_OEV_SEARCH6));
	/**
	 * Cambia_OEVProcess-End
	 */
	return mapping.findForward(EEMApplHelper.getPage(eemApplForm));
	
	}
private static ActionForward eemEnrollmentMenu(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
	
	context.setSelectedMenu(EEMConstants.MENU_ENROLLMENT);
	if (!(form instanceof EEMEnrollForm)) {
		
		EEMEnrollForm eemEnrollForm = EEMEnrollHelper.getEEMForm(sessionHelper);
		if (eemEnrollForm == null) {
			eemEnrollForm = new EEMEnrollForm();
			eemEnrollForm.setSelectedMemberTab("");
			eemEnrollForm.setTabPageMove("");
		}
		
		EEMEnrollVO enrollVO = context.getEnrollVO();
		/*LEP CR Changes Start.*/
		EEMEnrollDao dao = new EEMEnrollDao();
		/*LEP CR Changes End.*/
		enrollVO.setMessage("");
		EEMEnrollHelper.setEnrollFormList(eemEnrollForm, sessionHelper.getSession());
		EEMEnrollHelper.copyVOToForm(enrollVO,eemEnrollForm);
		EEMEnrollHelper.setDisplayItems(enrollVO,eemEnrollForm);
		EEMEnrollManager.setAgentsLookUp(conn, sessionHelper, eemEnrollForm);
		request.setAttribute(EEMConstants.EEM_ENROLL_FORM, eemEnrollForm);
		eemEnrollForm.setOevCallAttempts((List) sessionHelper.getSession().getAttribute(EEMConstants.SESSION_OEV_SEARCH1));
		eemEnrollForm.setOevCallStatus((List) sessionHelper.getSession().getAttribute(EEMConstants.SESSION_OEV_SEARCH2));
		eemEnrollForm.setOevCallStatusSaved((List) sessionHelper.getSession().getAttribute(EEMConstants.SESSION_OEV_SEARCH3));
		eemEnrollForm.setOevRetStatus((List) sessionHelper.getSession().getAttribute(EEMConstants.SESSION_OEV_SEARCH4));
		eemEnrollForm.setOevRetStatusSaved((List) sessionHelper.getSession().getAttribute(EEMConstants.SESSION_OEV_SEARCH5));
		eemEnrollForm.setReturnCalls((List) sessionHelper.getSession().getAttribute(EEMConstants.SESSION_OEV_SEARCH6));
		/*LEP CR Changes Start.*/
		if(eemEnrollForm.getListEnrollments() != null && eemEnrollForm.getListEnrollments().size() > 0){
			eemEnrollForm.setLepMaximusInfo(dao.getLepMaximusDetails(conn, sessionHelper.getMfId(), ((EmMbrEnrollmentVO)eemEnrollForm.getListEnrollments().get(0)).getMemberId()));
		}
		/*LEP CR Changes End.*/
	}		
	return mapping.findForward(EEMConstants.EEM_ENROLLMENT);
		
		
	

	
}
private static ActionForward eemDashBoard(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
	
	context.setSelectedMenu(EEMConstants.MENU_DASHBOARD);

	EEMDshBrdForm eemDshBrdForm = null;
	if (!(form instanceof EEMDshBrdForm)) {
		
		eemDshBrdForm = EEMDshBrdHelper.getEEMForm(sessionHelper);
		if (eemDshBrdForm == null) {
			eemDshBrdForm = new EEMDshBrdForm();
		}
		request.setAttribute(EEMConstants.EEM_DSHBRD_FORM, eemDshBrdForm);
		
	} else {
		eemDshBrdForm = (EEMDshBrdForm)form;
	}
	EEMDshBrdHelper.setDshBrdFormList(eemDshBrdForm, sessionHelper);
	
	// Get the Search list
	if (sessionHelper.isEEMSupervisor()) { 
		String selectedTab = StringUtil.nonNullTrim(context.getApplDshBrdTab());
		if (selectedTab.equals("")) {
			selectedTab = EEMConstants.EEM_APPLDSHBRD_TAB_MAIN;
			context.setApplDshBrdTab(selectedTab);
		}
		if (selectedTab.equals(EEMConstants.EEM_APPLDSHBRD_TAB_MAIN)) {
			EEMDshBrdHelper.getDashBoardList(eemDshBrdForm, sessionHelper);
		} else if (selectedTab.equals(EEMConstants.EEM_APPLDSHBRD_TAB_WORKLOAD)) {
			EEMDshBrdHelper.getWorkLoadList(eemDshBrdForm, sessionHelper);
		} else if (selectedTab.equals(EEMConstants.EEM_APPLDSHBRD_TAB_ASSIGNMENT)) {
			eemDshBrdForm.setLstDshBrdDrill(EEMDshBrdHelper.getDrillDown(sessionHelper));
		}
	} else {
		context.setApplDshBrdTab(EEMConstants.EEM_APPLDSHBRD_TAB_ASSIGNMENT);
		eemDshBrdForm.setSelectedSubMenuTab(EEMConstants.EEM_APPLDSHBRD_TAB_ASSIGNMENT);
		EEMDshBrdHelper.getDrillDownList(eemDshBrdForm, sessionHelper);
	}
	
	return mapping.findForward(EEMConstants.EEM_DASHBOARD);
}
private static ActionForward eemMbrDashBoard(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
	
	context.setSelectedMenu(EEMConstants.MENU_DASHBOARD);

	EEMDshBrdForm eemDshBrdForm = null;
	if (!(form instanceof EEMDshBrdForm)) {
		
		eemDshBrdForm = EEMDshBrdHelper.getEEMForm(sessionHelper);
		if (eemDshBrdForm == null) {
			eemDshBrdForm = new EEMDshBrdForm();
		}
		request.setAttribute(EEMConstants.EEM_DSHBRD_FORM, eemDshBrdForm);
		
	} else {
		eemDshBrdForm = (EEMDshBrdForm)form;
	}
	EEMDshBrdHelper.setDshBrdFormList(eemDshBrdForm, sessionHelper);
	
	// Get the Search list
	if (sessionHelper.isEEMSupervisor()) { 
		String selectedTab = StringUtil.nonNullTrim(context.getApplDshBrdTab());
		if (selectedTab.equals("")) {
			selectedTab = EEMConstants.EEM_APPLDSHBRD_TAB_MAIN;
			context.setApplDshBrdTab(selectedTab);
		}
		if (selectedTab.equals(EEMConstants.EEM_APPLDSHBRD_TAB_MAIN)) {
			EEMDshBrdHelper.getDashBoardList(eemDshBrdForm, sessionHelper);
		} else if (selectedTab.equals(EEMConstants.EEM_APPLDSHBRD_TAB_WORKLOAD)) {
			EEMDshBrdHelper.getWorkLoadList(eemDshBrdForm, sessionHelper);
		} else if (selectedTab.equals(EEMConstants.EEM_APPLDSHBRD_TAB_ASSIGNMENT)) {
			eemDshBrdForm.setLstDshBrdDrill(EEMDshBrdHelper.getDrillDown(sessionHelper));
		}
	} else {
		context.setApplDshBrdTab(EEMConstants.EEM_APPLDSHBRD_TAB_ASSIGNMENT);
		eemDshBrdForm.setSelectedSubMenuTab(EEMConstants.EEM_APPLDSHBRD_TAB_ASSIGNMENT);
		EEMDshBrdHelper.getDrillDownList(eemDshBrdForm, sessionHelper);
	}
	
	return mapping.findForward(EEMConstants.EEM_DASHBOARD);
	
	
}
private static ActionForward eemSupvsrApproval(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
	
	context.setSelectedMenu(EEMConstants.MENU_APPROVALS);

	EEMSupvsrForm eemSupvsrForm = null;
	if (!(form instanceof EEMSupvsrForm)) {
		
		eemSupvsrForm = EEMSupvsrHelper.getEEMForm(sessionHelper);
		if (eemSupvsrForm == null) {
			eemSupvsrForm = new EEMSupvsrForm();
			// Default search to Ready Approval status
			eemSupvsrForm.setCustomerId(sessionHelper.getMfId());
			eemSupvsrForm.setSearchApplStatus(EEMConstants.APPL_STATUS_READYAPPR);
			eemSupvsrSearch(conn, sessionHelper, context, mapping, eemSupvsrForm, request);
		}

		request.setAttribute(EEMConstants.EEM_SUPVSR_FORM, eemSupvsrForm);
		
	} else {
		eemSupvsrForm = (EEMSupvsrForm)form;
	}
	EEMSupvsrHelper.setSupvsrFormList(eemSupvsrForm, sessionHelper);

	return mapping.findForward(EEMConstants.EEM_APPROVALS);

}
private static ActionForward eemSupvsrSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {

	EEMSupvsrForm eemSupvsrForm = (EEMSupvsrForm) form;
	EEMSupvsrVO filterVO = context.getSupvsrFilter();
	EEMSupvsrHelper.setFormToVO(eemSupvsrForm, filterVO, sessionHelper);
	
	Pagination pagination = context.getSupvsrPagination();
	if (pagination == null) {
		pagination = new Pagination();
		pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
		context.setSupvsrPagination(pagination);
	}
	
	// Get the form fields
	EEMSupvsrService service = context.getSupvsrService();
	List lstSearch = service.getSearchList(conn, filterVO, pagination, "first");
	if (lstSearch.size() > 0) {
		filterVO.setLstSearch(lstSearch);
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_SUPVSR_SEARCH, lstSearch);
	} else {
		filterVO.setLstSearch(null);
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_SUPVSR_SEARCH, null);
	}
	
	EEMSupvsrHelper.setVOToForm(filterVO, eemSupvsrForm, sessionHelper);
	
	return mapping.findForward(EEMConstants.EEM_APPROVALS);
}

private static ActionForward eemGroupSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
	
	context.setSelectedMenu(EEMConstants.MENU_GROUP);
	String selectedTab = context.getOptGrpSvc();
	if (selectedTab == null) {
		selectedTab = EEMConstants.OPTION_GROUPSEM;
		context.setOptGrpSvc(EEMConstants.OPTION_GROUPSEM);
	}
	EEMGroupForm eemGroupForm = null;
	if (!(form instanceof EEMGroupForm)) {
		eemGroupForm = EEMGroupHelper.getEEMForm(sessionHelper);
		if (eemGroupForm == null) {
			eemGroupForm = new EEMGroupForm();
		}
		EEMGroupHelper.setFormLists(eemGroupForm);
		request.setAttribute(EEMConstants.EEM_GROUP_FORM, eemGroupForm);
	} else {
		eemGroupForm = (EEMGroupForm)form;
	}
			
	eemGroupForm.setMenu(EEMConstants.MENU_GROUP);
	
	if (EEMConstants.OPTION_GROUPSEM.equals(selectedTab)) {
		EEMGroupHelper.setGroupSearchLists(eemGroupForm, context);
		return mapping.findForward(EEMConstants.EEM_GROUP);
	}

	if (EEMConstants.OPTION_PRODUCTSEM.equals(selectedTab))
		return mapping.findForward(EEMConstants.EEM_PRODUCTS);
	
	if (EEMConstants.OPTION_SVCAREASEM.equals(selectedTab))
		return mapping.findForward(EEMConstants.EEM_SVCAREAS);
	
	if (EEMConstants.OPTION_GRPPRODSVCEM.equals(selectedTab))
		return mapping.findForward(EEMConstants.EEM_SVCAREAS);

	return mapping.findForward("eemError");
}
private static ActionForward eemLetterReqMenu(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
	
	context.setSelectedMenu(EEMConstants.MENU_LETTER);
	if (!(form instanceof EEMLetterReqForm)) {
		EEMLetterReqForm eemLetterForm = EEMLetterHelper.getEEMForm(sessionHelper);
		if (eemLetterForm == null) {
			eemLetterForm = new EEMLetterReqForm();
			EEMLetterHelper.clearForm(eemLetterForm);
		}
		
		EEMLetterReqVO letterReqVO = context.getLetterReqVO();
					
		List searchResults = letterReqVO.getSearchResults();
		eemLetterForm.setListSearchResults(searchResults);
		eemLetterForm.setLstLetterName(context.getLstLetterNames());

		
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(eemLetterForm.getEditState())) {
			if (searchResults != null) {
				if (searchResults.size() > 0) {
					EEMLetterManager mgr = new EEMLetterManager();
					mgr.letterReqSelect(conn,sessionHelper,context,eemLetterForm);

					//EMLetterReqSearchResultVO searchVO = (EMLetterReqSearchResultVO) searchResults.get(eemLetterForm.getSelectedSearchRow());
					//EMLetterReqDisplayVO dispVO = new EMLetterReqDisplayVO();
					//EEMLetterHelper.copySearchToDisplay(searchVO,dispVO);
					//eemLetterForm.setDisplayLetterReq(dispVO);
				}
			}
		} else {
			EMLetterReqDisplayVO dispVO = eemLetterForm.getDisplayLetterReq();
			dispVO.setLstVarData(EEMLetterHelper.getVarDataList(dispVO));
		}
		
		EEMLetterHelper.setFormLists(eemLetterForm);
		request.setAttribute(EEMConstants.EEM_LETTER_FORM, eemLetterForm);
	}
	
	return mapping.findForward(EEMConstants.EEM_LETTER_REQ);
}
private static ActionForward eemLetterReviewMenu(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
	
	
	context.setSelectedMenu(EEMConstants.MENU_LETTER_REVIEW);
	String selectedTab = StringUtil.nonNullTrim(context.getLetterReviewTab());
	if (selectedTab.equals("")) {
		selectedTab = EEMConstants.EEM_LTR_TAB_DETAILS;
		context.setLetterReviewTab(selectedTab);
		//EEMLetterReviewDetailForm eemLetterForm = new EEMLetterReviewDetailForm();
		//EEMLetterReviewHelper.clearForm(eemLetterForm);
		//EEMLetterReviewHelper.setFormLists(eemLetterForm);
		//request.setAttribute(EEMConstants.EEM_LETTER_REVIEW_DETAILS_FORM, eemLetterForm);
		//return mapping.findForward(EEMConstants.EEM_LETTER_REVIEW);
	}

	if (selectedTab.equals(EEMConstants.EEM_LTR_TAB_GENERATION)) {
		context.setLetterReviewTab(EEMConstants.EEM_LTR_TAB_GENERATION);
		return mapping.findForward(EEMConstants.EEM_LETTER_REVIEW_GENERATE);		
	}
	
	if (selectedTab.equals(EEMConstants.EEM_LTR_TAB_DETAILS)) {
		EEMLetterReviewDetailForm eemLetterForm = null;
		if (!(form instanceof EEMLetterReviewDetailForm)) {
			eemLetterForm = EEMLetterReviewHelper.getEEMDetailForm(sessionHelper);
			if (eemLetterForm == null) {
				eemLetterForm = new EEMLetterReviewDetailForm();
				EEMLetterReviewHelper.clearForm(eemLetterForm);
			}
			request.setAttribute(EEMConstants.EEM_LETTER_REVIEW_DETAILS_FORM, eemLetterForm);			
		}
		EEMLetterReviewHelper.setFormLists(eemLetterForm);			
		EEMLetterReviewManager mgr = new EEMLetterReviewManager();
		mgr.letterReviewSelect(conn,sessionHelper,context,eemLetterForm,false);
		context.setLetterReviewTab(EEMConstants.EEM_LTR_TAB_DETAILS);
		return mapping.findForward(EEMConstants.EEM_LETTER_REVIEW);
	}
		/*  Begin: Added for Letter Review QC */
		if (selectedTab.equals(EEMConstants.LTR_REVIEW_QC)) {
			context.setLetterReviewTab(EEMConstants.LTR_REVIEW_QC);
			return mapping.findForward(EEMConstants.EEM_LTR_QC);		
		}
		/*  End: Added for Letter Review QC */
		if (selectedTab.equals(EEMConstants.LTR_REVIEW_UPLOAD)) {
			
			context.setLetterReviewTab(EEMConstants.LTR_REVIEW_UPLOAD);
			return mapping.findForward(EEMConstants.EEM_LTR_REVIEW_UPLOAD);		
		}
		//IFOX-00426356: Attachment CR:start
		if (selectedTab.equals(EEMConstants.LTR_ATTACHMENT)) {
			EEMLetterReviewAttachmentForm eemLetterForm = null;
			if (!(form instanceof EEMLetterReviewAttachmentForm)) {
				eemLetterForm = EEMLetterReviewHelper.getEEMAttachForm(sessionHelper);
				if (eemLetterForm == null) {
					eemLetterForm = new EEMLetterReviewAttachmentForm();
					//EEMLetterReviewHelper.clearForm(eemLetterForm);
				}
				request.setAttribute(EEMConstants.EEM_LETTER_REVIEW_ATTACHMENT_FORM, eemLetterForm);			
			}
			EEMLetterReviewHelper.setFormLists(eemLetterForm);	
			context.setLetterReviewTab(EEMConstants.LTR_ATTACHMENT);
			return mapping.findForward(EEMConstants.EEM_LTR_ATTACHMENT);		
		}
		//IFOX-00426356: Attachment end
	
	return mapping.findForward("eemError");


}
private static ActionForward eemBillingMenu(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
	
	EEMBillingManager mgr = new EEMBillingManager();
	
	context.setSelectedMenu(EEMConstants.MENU_BILLING);
	String selectedTab = StringUtil.nonNullTrim(context.getBillingTab());
	if (selectedTab.equals("")) {
		selectedTab = EEMConstants.EEM_BILL_TAB_INVOICE;
		context.setBillingTab(selectedTab);
	}

	if (selectedTab.equals(EEMConstants.EEM_BILL_TAB_PAYMENTS)) {
		context.setBillingTab(EEMConstants.EEM_BILL_TAB_PAYMENTS);
		EEMBillPaymentsForm eemBillPaymentsForm = EEMBillingHelper.getEEMFormPay(sessionHelper);
		if (eemBillPaymentsForm == null) {
			eemBillPaymentsForm = new EEMBillPaymentsForm();
			EEMBillingHelper.clearPaymentsForm(eemBillPaymentsForm);
		}
		request.setAttribute(EEMConstants.EEM_BILLING_PAYMENTS_FORM, eemBillPaymentsForm);
		eemBillPaymentsForm.setSelectedSubMenuTab(selectedTab);
		
		EEMBillingHelper.setPaymentsFormLists(eemBillPaymentsForm);
		if (eemBillPaymentsForm.isNewPaymentScreen()) {
			if (eemBillPaymentsForm.getNewHeaderDisplayState().equals(EEMConstants.EEM_MBR_SCREEN_EDIT)) {
				mgr.newBillPaymentHeader(conn,sessionHelper,context, eemBillPaymentsForm, eemBillPaymentsForm.getDisplayPaymentsHeader());
				return mapping.findForward(EEMConstants.EEM_BILLING_PAYMENTS_NEW);
			} else {
				return eemBillPaymentAddDetails(conn, sessionHelper, context, mapping, eemBillPaymentsForm, request);
			}
		} else {
			mgr.billPaymentsDetailSelect(conn, sessionHelper, context, eemBillPaymentsForm);
			return mapping.findForward(EEMConstants.EEM_BILLING_PAYMENTS);
		}
	}
	
	if (selectedTab.equals(EEMConstants.EEM_BILL_TAB_DRAFT)) {
		context.setBillingTab(EEMConstants.EEM_BILL_TAB_DRAFT);
		EEMBillDraftForm eemBillDraftForm = EEMBillingHelper.getEEMFormDraft(sessionHelper);
		if (eemBillDraftForm == null) {
			eemBillDraftForm = new EEMBillDraftForm();
			EEMBillingHelper.clearDraftForm(eemBillDraftForm);
		}
		request.setAttribute(EEMConstants.EEM_BILLING_DRAFT_FORM, eemBillDraftForm);
		eemBillDraftForm.setSelectedSubMenuTab(selectedTab);
		
		EEMBillingHelper.setDraftFormLists(eemBillDraftForm);
		//mgr.billInvoiceDetailSelect(conn, sessionHelper, context, eemBillDraftForm);
		
		return mapping.findForward(EEMConstants.EEM_BILLING_DRAFT);		
	}

	if (selectedTab.equals(EEMConstants.EEM_BILL_TAB_INVOICE)) {
		context.setBillingTab(EEMConstants.EEM_BILL_TAB_INVOICE);
		EEMBillInvoiceForm eemBillInvoiceForm = EEMBillingHelper.getEEMFormInv(sessionHelper);
		if (eemBillInvoiceForm == null) {
			eemBillInvoiceForm = new EEMBillInvoiceForm();
			EEMBillingHelper.clearInvoiceForm(eemBillInvoiceForm);
		}
		request.setAttribute(EEMConstants.EEM_BILLING_INVOICE_FORM, eemBillInvoiceForm);
		eemBillInvoiceForm.setSelectedSubMenuTab(selectedTab);
		
		EEMBillingHelper.setInvoiceFormLists(eemBillInvoiceForm);
		mgr.billInvoiceDetailSelect(conn, sessionHelper, context, eemBillInvoiceForm);
		
		return mapping.findForward(EEMConstants.EEM_BILLING_INVOICE);		
	}
	
	if (selectedTab.equals(EEMConstants.EEM_BILL_TAB_MEMBER_PAYMENTS)) {
		context.setBillingTab(EEMConstants.EEM_BILL_TAB_MEMBER_PAYMENTS);
		EEMBillMembPaymentsForm eemBillMembPaymentsForm = EEMBillingHelper.getEEMFormMembPay(sessionHelper);
		if (eemBillMembPaymentsForm == null) {
			eemBillMembPaymentsForm = new EEMBillMembPaymentsForm();
			EEMBillingHelper.clearMembPaymentsForm(eemBillMembPaymentsForm);
		}
		request.setAttribute(EEMConstants.EEM_BILLING_MEMB_PAYMENTS_FORM, eemBillMembPaymentsForm);
		eemBillMembPaymentsForm.setSelectedSubMenuTab(selectedTab);
		
		EEMBillingHelper.setMembPaymentsFormLists(eemBillMembPaymentsForm);
		mgr.billMembPaymentsDetailSelect(conn, sessionHelper, context, eemBillMembPaymentsForm);
		
		return mapping.findForward(EEMConstants.EEM_BILLING_MEMBER_PAYMENTS);
	}
	
	return mapping.findForward("eemError");

}
private static ActionForward eemTimersMenu(Connection conn,
		SessionHelper sessionHelper, EEMContext context,
		ActionMapping mapping, ActionForm form, HttpServletRequest request)
		throws Exception {
/*logger.info("Timer Menu : Begin : ");  */
EEMTimersForm eemTimersForm = null;
context.setSelectedMenu(EEMConstants.MENU_TIMERS);
if (!(form instanceof EEMTimersForm)) {

	eemTimersForm = EEMTimersHelper.getEEMForm(sessionHelper);
	if (eemTimersForm == null) {
		eemTimersForm = new EEMTimersForm();
		
	eemTimersForm.setSearchType("");
	}

	request.setAttribute(EEMConstants.EEM_TIMERS_FORM, eemTimersForm);
} else {
	eemTimersForm = (EEMTimersForm) form;
}
EEMTimersHelper.setTimersFormList(eemTimersForm, sessionHelper);
/*logger.info("Timer Menu : End: ");  */
return mapping.findForward(EEMConstants.EEM_TIMERS_APP);

}

private static ActionForward eemCobFlowMenu(Connection conn,
		SessionHelper sessionHelper, EEMContext context,
		ActionMapping mapping, ActionForm form, HttpServletRequest request)
		throws Exception {
	
	EEMCobFlowForm eemCobFlowForm = null;
	context.setSelectedMenu(EEMConstants.MENU_COB);
	if (!(form instanceof EEMCobFlowForm)) {
	
		eemCobFlowForm = EEMCobHelper.getEEMForm(sessionHelper);
		if (eemCobFlowForm == null) {
			eemCobFlowForm = new EEMCobFlowForm();
			
			//eemCobFlowForm.setSearchType("");
		}
	
		request.setAttribute(EEMConstants.EEM_COB_FORM, eemCobFlowForm);
	} else {
		eemCobFlowForm = (EEMCobFlowForm) form;
	}
	//EEMCobHelper.setCobFormList(eemCobFlowForm, sessionHelper);
	/*logger.info("Timer Menu : End: ");  */
	return mapping.findForward(EEMConstants.EEM_COB_WF);

}

private static ActionForward eemBillPaymentAddDetails(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
	
	EEMBillingManager mgr = new EEMBillingManager();
	mgr.addBillPaymentDetails(conn,sessionHelper,context,(EEMBillPaymentsForm)form);
	return mapping.findForward(EEMConstants.EEM_BILLING_PAYMENTS_NEW);
}

}
