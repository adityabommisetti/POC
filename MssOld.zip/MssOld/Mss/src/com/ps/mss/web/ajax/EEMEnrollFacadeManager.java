/*
 * $Id: EEMEnrollFacadeManager.java,v 1.1 2014/06/26 07:56:56 praveen Exp $
 */
package com.ps.mss.web.ajax;

import java.sql.Connection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EEMEnrollService;
import com.ps.mss.dao.model.EmCorrMbrVO;
import com.ps.mss.dao.model.EmCorrVarDataVO;
import com.ps.mss.db.DbConn;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.manager.EEMManager;
import com.ps.mss.model.EEMContext;
import com.ps.mss.model.EEMEnrollVO;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.helper.AjaxHelper;
import com.ps.mss.web.helper.SessionHelper;

/**
 * @author Raghu Gorur
 *  
 */
public class EEMEnrollFacadeManager {
	private static Logger logger=LoggerFactory.getLogger(EEMEnrollFacadeManager.class);
	ModuleLog log = new ModuleLog("EEMEnrollFacadeManager");

	public EmCorrVarDataVO [] getLetterVarData(int rowNbr) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EmCorrVarDataVO [] arrData = null;
		Connection conn = null;
		try {
			// use the default DB for security check
			conn = DbConn.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);

			EEMContext context = EEMManager.getContext(sessionHelper.getSession());
			EEMEnrollVO enrollVO = context.getEnrollVO();

			List lst = enrollVO.getLetters();
			EmCorrMbrVO letterVO = (EmCorrMbrVO)lst.get(rowNbr);

			EEMEnrollService service = new EEMEnrollService();
			List lstData = service.getLetterVarData(conn,letterVO);
			enrollVO.setLetterData(lstData);
		
	        int cnt = lstData.size();
	        arrData = new EmCorrVarDataVO[cnt];
	        arrData = (EmCorrVarDataVO [])lstData.toArray(arrData);

		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				throw new ApplicationException(e);
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return arrData;
	
	}
	
}
