/*
 * $Id: EEMLetterReqForm.java,v 1.1 2014/06/26 07:55:45 praveen Exp $
 */
package com.ps.mss.web.forms;

import java.util.List;

import com.ps.mss.model.EMLetterReqDisplayVO;
import com.ps.util.ListBoxItem;

public class EEMLetterReqForm extends EEMForm {

	private String searchType;
	private String searchId;
	private String searchCreateDate;
	private String searchStatus;

	private boolean searchExpanded;
	private int selectedSearchRow;
	private List listSearchResults;
		
	private EMLetterReqDisplayVO displayLetterReq = new EMLetterReqDisplayVO();
	
	private ListBoxItem [] arrSearchTypes;
	private List lstSearchStatus;
	
	private String editState;
	
	private List lstLetterName;
	/** Triple S BasePlus Migration START **/
	// Added for TSA changes for Member Id Label Change :Start
	private String mbrLabel;

	// Added for TSA changes for Member Id Label Change :End
	public String getMbrLabel() {
		return mbrLabel;
	}
	public void setMbrLabel(String mbrLabel) {
		this.mbrLabel = mbrLabel;
	}
	/** Triple S BasePlus Migration END **/
	public EMLetterReqDisplayVO getDisplayLetterReq() {
		return displayLetterReq;
	}
	public void setDisplayLetterReq(EMLetterReqDisplayVO displayLetterReq) {
		this.displayLetterReq = displayLetterReq;
	}
	public String getSearchCreateDate() {
		return searchCreateDate;
	}
	public void setSearchCreateDate(String searchCreateDate) {
		this.searchCreateDate = searchCreateDate;
	}
	public String getSearchId() {
		return searchId;
	}
	public void setSearchId(String searchId) {
		this.searchId = searchId;
	}
	public String getSearchStatus() {
		return searchStatus;
	}
	public void setSearchStatus(String searchStatus) {
		this.searchStatus = searchStatus;
	}
	public String getSearchType() {
		return searchType;
	}
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	public boolean isSearchExpanded() {
		return searchExpanded;
	}
	public void setSearchExpanded(boolean searchExpanded) {
		this.searchExpanded = searchExpanded;
	}
	public int getSelectedSearchRow() {
		return selectedSearchRow;
	}
	public void setSelectedSearchRow(int selectedSearchRow) {
		this.selectedSearchRow = selectedSearchRow;
	}	
	public List getListSearchResults() {
		return listSearchResults;
	}
	public void setListSearchResults(List listSearchResults) {
		this.listSearchResults = listSearchResults;
	}
	
	
	
	public String getEditState() {
		return editState;
	}
	public void setEditState(String editState) {
		this.editState = editState;
	}
	
	/**
	 * @return Returns the lstLetterName.
	 */
	public List getLstLetterName() {
		return lstLetterName;
	}
	/**
	 * @param lstLetterName The lstLetterName to set.
	 */
	public void setLstLetterName(List lstLetterName) {
		this.lstLetterName = lstLetterName;
	}
	/**
	 * @return Returns the planDesignation.
	 */
	public List getLstSearchStatus() {
		return lstSearchStatus;
	}
	public void setLstSearchStatus(List lstSearchStatus) {
		this.lstSearchStatus = lstSearchStatus;
	}
	public ListBoxItem[] getArrSearchTypes() {
		return arrSearchTypes;
	}
	public void setArrSearchTypes(ListBoxItem[] arrSearchTypes) {
		this.arrSearchTypes = arrSearchTypes;
	}
}
