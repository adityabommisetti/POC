/*
 * $Id: RapsFacadeManager.java,v 1.1 2014/06/26 07:57:01 praveen Exp $
 */
package com.ps.mss.web.ajax;

import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.RapsConstants;
import com.ps.mss.manager.ContextManager;
import com.ps.mss.manager.RapsManager;
import com.ps.mss.model.RapsContext;
import com.ps.mss.model.RapsErrorsInfo;
import com.ps.mss.model.RapsErrorsItem;
import com.ps.mss.model.RapsErrorsHistoryItem;
import com.ps.mss.model.RapsErrorsPage;
import com.ps.mss.model.RapsFilter;
import com.ps.mss.model.RapsDetailPage;
import com.ps.mss.model.RapsDetailItem;
import com.ps.mss.model.BasePagingItem;
import com.ps.mss.model.BasePaginationPage;
import com.ps.mss.model.Pagination;
import com.ps.mss.model.RapsClaimsDetailPage;
import com.ps.mss.model.RapsClaimDetailItem;
import com.ps.mss.web.helper.AjaxHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.db.DbConnWeb;

/**
 * @author Adriana.Indrapradja
 */
public class RapsFacadeManager {
	//static ModuleLog log = new ModuleLog("RapsFacadeManager");
	private static Logger logger=LoggerFactory.getLogger(RapsFacadeManager.class);


    
    /**
 	 * TAB	 : 	RAPS Summary
	 * SUBTAB:	RASP Details
	 * Called whenever a customer select "<<" "<" or ">" on RAPS Details page. 
	 * This will end up querying db to populate the following:
	 * 		+ RAPS List - the 10 items on the list
	 *  	+ RAPS Details portion 
	 *  	+ RAPS History portion 
     * @param move
     * @return
     * @throws ApplicationException
     */
    public RapsDetailPage getRapsDetailPage(String move) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	Connection conn = null; boolean anyError = true; String errMessage = null;
    	RapsDetailPage detailPage = null;
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	AjaxHelper.validateUser(sessionHelper,conn);
    	   	
			// now get the connection to the RAPS Db
			String dbId = sessionHelper.getRapsDatabaseName();
			conn = DbConnWeb.reGetConnection(conn,dbId);
			RapsContext rc = (RapsContext) ContextManager.getContext(sessionHelper.getSession(), RapsConstants.RAPS_CONTEXT);
			rc.setReuseList(false); //always get fresh page.
			Pagination pagination = rc.getRapsDetailsPagination();
			
			if("previous".equals(move)){
				RapsDetailItem detailItem = new RapsDetailItem();
				setPrevDetailFromHistory(detailItem, pagination);
				pagination.setFirstDetail(detailItem);
			}
			
			RapsFilter filter = rc.getRapsDetailFilter();
			Map planMap = sessionHelper.getPlanForParts();
			detailPage = RapsManager.getRapsDetailPage(conn, rc, filter, move, planMap);
	 
			if (detailPage != null) {
				int count = 0;
				RapsDetailItem firstItem = null, lastItem = null;
				RapsDetailItem[] detailArr = detailPage.getRapsDetails();
				if (detailArr != null) {
					count = detailArr.length;
					firstItem = detailArr[0];
					if (count > 0)
						lastItem = detailArr[count - 1];
					rc.setLastRapsDetail(detailPage.getDetailInfo()); //save the last fetched raps detail.
				} 
				setPagination(pagination, detailPage, count, firstItem, lastItem, move);
			}
			anyError = false;
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
    		logger.debug(errMessage);
//    		logger.error(errMessage);
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return detailPage; 

    }//detailPage.
    
    /**
 	 * TAB	 : 	RAPS Summary
	 * SUBTAB:	RASP Details
	 * Called whenever a customer select a row on RAPS Details page. 
	 * This will end up querying db to populate the following:
	 *  	+ RAPS Details portion 
	 *  	+ RAPS History portion 
     * @param seqNum : additional field for db query. May need additional fields....
     * @param rowId : the selected row on the page
     * @param menuName : "detail"
     * @return
     * @throws ApplicationException
     * 
     */
    public RapsDetailPage getRapsDetail(int rowId, RapsDetailItem rapsDetailItem) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
    	Connection conn = null; boolean anyError = true; String errMessage = null;
    	RapsDetailPage detailPage = null;
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	AjaxHelper.validateUser(sessionHelper,conn);
    	   	
			// now get the connection to the RAPS Db
			String dbId = sessionHelper.getRapsDatabaseName();
			conn = DbConnWeb.reGetConnection(conn,dbId);
        
			RapsContext rc = (RapsContext) ContextManager.getContext(sessionHelper.getSession(), RapsConstants.RAPS_CONTEXT);
	
	    	Pagination pagination = rc.getRapsDetailsPagination();
	    	pagination.setSelectedLine(rowId);
			detailPage = RapsManager.getRapsDetail(conn, rc, rapsDetailItem);
			rc.setLastRapsDetail(detailPage.getDetailInfo()); //save the last fetched raps detail.
			anyError = false;
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			errMessage = e.getMessage();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				errMessage = e.getMessage();
			}
		}
		if (anyError) {
    		logger.debug(errMessage);
//    		logger.error(errMessage);
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return detailPage;
	}
    
    /**
 	 * TAB	 : 	Claims Summary
	 * SUBTAB:	Claims Details
	 * Called whenever a customer select "<<" "<" or ">" on RAPS Details page. 
	 * This will end up querying db to populate the following:
	 * 		+ Claims List - the 10 items on the list
	 *  	+ Claims Details portion 
	 *  	+ Claims History portion 
     * @param move
     * @return
     * @throws ApplicationException
     */
    public RapsClaimsDetailPage getRapsClaimDetailPage(String move) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	Connection conn = null; boolean anyError = true; String errMessage = null;
    	RapsClaimsDetailPage detailPage = null;
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	AjaxHelper.validateUser(sessionHelper,conn);
    	   	
			// now get the connection to the RAPS Db
			String dbId = sessionHelper.getRapsDatabaseName();
			conn = DbConnWeb.reGetConnection(conn,dbId);
			RapsContext rc = (RapsContext) ContextManager.getContext(sessionHelper.getSession(), RapsConstants.RAPS_CONTEXT);
			rc.setReuseList(false); //always get fresh page.
			Pagination pagination = rc.getClaimsDetailsPagination();
			
			if("previous".equals(move)){
				RapsClaimDetailItem detailItem = new RapsClaimDetailItem();
				setPrevDetailFromHistory(detailItem, pagination);
				pagination.setFirstDetail(detailItem);
			}
			
			RapsFilter filter = rc.getClaimsDetailFilter();
			Map planMap = sessionHelper.getPlanForParts();
			//String custName = (String) sessionHelper.getAttribute(Constants.SESSION_CUSTOMER_NAME);
			detailPage = RapsManager.getClaimsDetailPage(conn, rc, filter, move, planMap);
	 
			if (detailPage != null) {
				int count = 0;
				RapsClaimDetailItem firstItem = null, lastItem = null;
				RapsClaimDetailItem[] detailArr = detailPage.getClaimsList();
				if (detailArr != null) {
					count = detailArr.length;
					firstItem = detailArr[0];
					if (count > 0)
						lastItem = detailArr[count - 1];
					rc.setLastClaimDetail(detailPage.getDetailInfo());
				} 
				setPagination(pagination, detailPage, count, firstItem, lastItem, move);
			}
			anyError = false;
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			errMessage = e.getMessage();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				errMessage = e.getMessage();
			}
		}
		if (anyError) {
    		logger.debug(errMessage);
//    		logger.error(errMessage);
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return detailPage;  
    }
 
    /**
 	 * TAB	 : 	Claims Summary
	 * SUBTAB:	Claims Details
	 * Called whenever a customer select a row on Claims Details page. 
	 * This will end up querying db to populate the following:
	 *  	+ Claims Details portion
	 *  	+ Claims History portion 
     * @param seqNum : additional field for db query. May need additional fields....
     * @param rowId : the selected row on the page
     * @param menuName : "detail"
     * @return RapsClaimsDetailPage
     * @throws ApplicationException
     * 
     */
     public RapsClaimsDetailPage getRapsClaimDetail(int rowId, RapsClaimDetailItem rapsDetailItem) throws ApplicationException{
    	 logger.info(LoggerConstants.methodStartLevel());
    	 Connection conn = null; boolean anyError = true; String errMessage = null;
     	RapsClaimsDetailPage detailPage = null;
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	AjaxHelper.validateUser(sessionHelper,conn);
    	   	
			// now get the connection to the RAPS Db
			String dbId = sessionHelper.getRapsDatabaseName();
			conn = DbConnWeb.reGetConnection(conn,dbId);
			RapsContext rc = (RapsContext) ContextManager.getContext(sessionHelper.getSession(), RapsConstants.RAPS_CONTEXT);
	
	    	Pagination pagination = rc.getClaimsDetailsPagination();
	    	pagination.setSelectedLine(rowId); 
	 		detailPage = RapsManager.getRapsClaimDetail(conn, rc, rapsDetailItem, false);
			rc.setLastClaimDetail(detailPage.getDetailInfo());
	 		anyError = false;
	 	} catch(Exception e) {
	 		errMessage = e.getMessage();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
		 		errMessage = e.getMessage();				
			}
		}
		if (anyError) {
    		logger.error(errMessage);
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return detailPage;
     }
    
    /**
     * 
     * @param pagingItem object to be populated by item stored in history
     * @param pagination
     */
	private void setPrevDetailFromHistory(BasePagingItem pagingItem, Pagination pagination) {
		logger.info(LoggerConstants.methodStartLevel());
		String pageHist = (String) pagination.getPageHistory();
		if(pageHist != null){
			String historyStr;
			
			if(pageHist.indexOf(",") == -1)
				historyStr = pageHist;
			else {
				String [] pageHistArr = pageHist.split("[,]");				
				//	getting Last page 
				historyStr = pageHistArr[pageHistArr.length-1];
			}
			pagingItem.setFieldsBasedOnHistory(historyStr);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	/**
	 * 
	 * @param pagination
	 * @param detailPage
	 * @param arrSize
	 * @param firstItem
	 * @param lastItem
	 * @param move
	 */
    private void setPagination(Pagination pagination, BasePaginationPage detailPage, int arrSize, Object firstItem, Object lastItem, String move) {
    	logger.info(LoggerConstants.methodStartLevel());
    	if(arrSize > 0 ){
            //**************** START BLOCK FOR CALCULATING PAGE HIST ***************************
			// ADD : When user click on NEXT button (adding prev. page First VO
			// REMOVE : When user click on PREV button (remove top entry from List (it. current loading page)
			//
			
        	String pageHist = (String) pagination.getPageHistory();
            String newPageHist = (pageHist != null) ? pageHist : "";
            
            // updating Page Hist 
            if("previous".equals(move)){
            	if(newPageHist.indexOf(",") != -1) {
                	String []pageHistArr = pageHist.split("[,]"); // spliting the list, remove last entry (CURRENT PAGE)
                	newPageHist = pageHistArr[0];
                	for(int i=1; i < pageHistArr.length-1; i++ )
                		newPageHist += "," + pageHistArr[i];
            	} else 
            		newPageHist = "";
            	
    		} else if ("next".equals(move)) {  // adding current page Paging Key Set into PDE PAGE HIST
    			BasePagingItem detailItem = (BasePagingItem) pagination.getFirstDetail();
    			if(! "".equals(newPageHist))
    				newPageHist += ",";
   				newPageHist += detailItem.getHistory();
        	}
    		
    		if(("previous".equals(move) && "".equals(newPageHist)) || "first".equals(move))
    			pagination.setPageHistory(null);
    		else
    			pagination.setPageHistory(newPageHist);
    		
            //**************** START BLOCK FOR CALCULATING PAGE HIST ***************************
    		pagination.setFirstDetail(firstItem);
    		pagination.setLastDetail(lastItem);
    		pagination.setCurrentPage(detailPage.getCurrentPage());
    		pagination.setPageNumber(detailPage.getPageNumber());
    		pagination.setSelectedLine(detailPage.getSelectedLine());
        }
		pagination.setMaxRecordCount(10);
		pagination.setAllPage(false);        
		logger.info(LoggerConstants.methodEndLevel());
	} 
    
    /**
 	 * TAB	 : 	RAPS Summary
	 * SUBTAB:	RAPS Errors
	 * Called whenever a customer selects "<<" "<" or ">" on RAPS Errors page. 
	 * This will end up querying db to populate the following:
	 * 		+ RAPS Errors List - the 10 items on the list
	 *  	+ RAPS Error Details portion 
	 *  	+ RAPS Errors History portion 
     * @param move
     * @return RapsErrorsPage
     * @throws ApplicationException
     */
    public RapsErrorsPage getRapsErrorsPage(String move) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	Connection conn = null; boolean anyError = true; String errMessage = null;
    	RapsErrorsPage errorsPage = null;
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	AjaxHelper.validateUser(sessionHelper,conn);
    	   	
			// now get the connection to the RAPS Db
			String dbId = sessionHelper.getRapsDatabaseName();
			conn = DbConnWeb.reGetConnection(conn,dbId);
			RapsContext rc = (RapsContext) ContextManager.getContext(sessionHelper.getSession(), RapsConstants.RAPS_CONTEXT);
			rc.setReuseList(false); //always get fresh page.
			Pagination pagination = rc.getRapsErrorsPagination();
			
			if("previous".equals(move)){
				RapsErrorsItem errorsItem = new RapsErrorsItem();
				setPrevDetailFromHistory(errorsItem, pagination);
				pagination.setFirstDetail(errorsItem);
			}
			
			RapsFilter filter = rc.getRapsErrorsFilter();
			Map planMap = sessionHelper.getPlanForParts();
			errorsPage = RapsManager.getRapsErrorsPage(conn, rc, filter, move, planMap);
	 
			if (errorsPage != null) {
				int count = 0;
				RapsErrorsItem firstItem = null, lastItem = null;
				RapsErrorsItem[] errorsArr = errorsPage.getRapsErrors();
				if (errorsArr != null) {
					count = errorsArr.length;
					firstItem = errorsArr[0];
					if (count > 0)
						lastItem = errorsArr[count - 1];
					rc.setLastRapsErrors(errorsPage.getErrorsInfo()); //save the last fetched raps errors detail.
				} 
				setPagination(pagination, errorsPage, count, firstItem, lastItem, move);
			}
			anyError = false;
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
		if (anyError) {
    		logger.debug(errMessage);
//    		logger.error(errMessage);
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return errorsPage; 

    }//errorsPage.
    
    /**
 	 * TAB	 : 	RAPS Summary
	 * SUBTAB:	RASP Errors
	 * Called whenever a customer selects a row on RAPS Errors page. 
	 * This will end up querying db to populate the following:
	 *  	+ RAPS Errors Details portion 
	 *  	+ RAPS Errors History portion 
     * @param rowId : the selected row on the page
     * @param RapsErrorsItem
     * @return RapsErrorsPage
     * @throws ApplicationException
     * 
     */
    public RapsErrorsPage getRapsErrorsDetail(int rowId, RapsErrorsItem rapsErrorsItem) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
    	Connection conn = null; boolean anyError = true; String errMessage = null;
    	RapsErrorsPage errorsPage = null;
    	try {
			// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	AjaxHelper.validateUser(sessionHelper,conn);
    	   	
			// now get the connection to the RAPS Db
			String dbId = sessionHelper.getRapsDatabaseName();
			conn = DbConnWeb.reGetConnection(conn,dbId);
        
			RapsContext rc = (RapsContext) ContextManager.getContext(sessionHelper.getSession(), RapsConstants.RAPS_CONTEXT);
	
	    	Pagination pagination = rc.getRapsErrorsPagination();
	    	pagination.setSelectedLine(rowId);
			errorsPage = RapsManager.getRapsErrorsDetail(conn, rc, rapsErrorsItem);
			rc.setLastRapsErrors(errorsPage.getErrorsInfo()); //save the last fetched raps errorsdetail.
			anyError = false;
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			errMessage = e.getMessage();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				errMessage = e.getMessage();
			}
		}
		if (anyError) {
    		logger.debug(errMessage);
//    		logger.error(errMessage);
			throw new ApplicationException(errMessage);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return errorsPage;
	}
    
    /**
 	 * TAB	 : 	RAPS Summary
	 * SUBTAB:	RASP Errors
	 * Called whenever a customer click on the update button on RAPS Errors page. 
     * @param rowId : the selected row on the page
     * @param RapsErrorsItem
     * @param newStatus
     * @param newComment
     * @return RapsErrorsHistoryItem
     * @throws ApplicationException
     * 
     */
    public RapsErrorsHistoryItem[] updateRapsErrorStatusComment(int rowId, RapsErrorsItem rapsErrorsItem, String newStatus, String newComment, boolean changeStatus) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	Connection conn = null; 
    	String errMessage = null;
    	RapsErrorsHistoryItem[] errHistItem = null;
   	
    	try {
    		// use the default DB for security check
    		conn = DbConnWeb.getConnection();
    		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
    	   	AjaxHelper.validateUser(sessionHelper,conn);
    	   	String userId = sessionHelper.getUserId();
    	   	
			// now get the connection to the RAPS Db
			String dbId = sessionHelper.getRapsDatabaseName();
			conn = DbConnWeb.reGetConnection(conn,dbId);
        
			RapsContext rc = (RapsContext) ContextManager.getContext(sessionHelper.getSession(), RapsConstants.RAPS_CONTEXT);
    	   	
    	   	RapsErrorsInfo rapsErrorsInfo = rc.getLastRapsErrors();
    	   	
    	   	errHistItem = RapsManager.updateRapsErrorsStatusComment(conn, rapsErrorsItem, userId, newStatus, newComment, changeStatus);
    	   	if (errHistItem != null) {
    	   		rapsErrorsInfo.setCurrentWorkStatus(rapsErrorsItem.getErrorWorkStatusCode());
    	   		rapsErrorsInfo.setComment(errHistItem[errHistItem.length-1].getComment());
    			return errHistItem;
    	   	}
			
    	} catch(Exception e) {
    		logger.error(LoggerConstants.exceptionMessage(e.toString()));
    		errMessage = e.getMessage();
    	} finally {
    		try {
    			if (conn != null)
    				conn.close();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			errMessage = e.getMessage();
    		}
    	}
    	logger.info(LoggerConstants.methodEndLevel());
		return null; 
    }
}