package com.ps.mss.web.actions;

import java.sql.Connection;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EEMSecRolesService;
import com.ps.mss.db.DbConn;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.manager.EEMManager;
import com.ps.mss.model.EEMContext;
import com.ps.mss.model.EEMSecRolesVO;
import com.ps.mss.model.UserRoles;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.forms.EEMForm;
import com.ps.mss.web.forms.EEMSecurityRolesForm;
import com.ps.mss.web.helper.EEMSecRolesHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.web.util.EEMSwitchUtil;
/**
 * This class is used in order to perform Action
 * 
 * @author Pramod 
 *
 *@version 1.0, 15th Oct 2013
 */
public class EEMSecurityAction extends Action {
	private static Logger logger = LoggerFactory.getLogger(EEMSecurityAction.class);
	
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		try {
			EEMForm eemForm = (EEMForm) form;
			String method = eemForm.getMethod();
			////System.out.println("In action method >>"+method);
			// use the default DB for security check
			conn = DbConn.getConnection();
			SessionHelper sessionHelper = new SessionHelper(request);
			String errorMsg = sessionHelper.validateUser(conn);
			if (errorMsg != null) {
				request.setAttribute("Msg", "Login Has Timed Out");
				throw new Exception(errorMsg);
			}
			
			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			EEMContext context = EEMManager.getContext(sessionHelper.getSession());
			String selectedMenu = context.getSelectedMenu();
			eemForm.setMessage(null);// Reset the Exception/Error messages
			if("updateRole".equals(method)){
				logger.info(LoggerConstants.methodEndLevel());
				return updateRole(conn, sessionHelper, context, mapping, form, request);
			}
			else 
				if ("switchMenu".equals(method)) {
					logger.info(LoggerConstants.methodEndLevel());
					return EEMSwitchUtil.switchMenu( mapping, conn, context,  form, eemForm,  sessionHelper,  request,  response);
				}
		}catch(Exception e){
			
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward("eemError");
		
	}
	/**
	 * This method is used to update the role 
	 * @param conn to connect to the DataBase
	 * @param sessionHelper to handle the form
	 * @param context to get the services and VO objects
	 * @param mapping to map to the forward jsp
	 * @param form to save the attributes
	 * @param request to forward the request
	 * @return ActionForward
	 * @throws ApplicationException
	 */
	public static ActionForward updateRole(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMSecurityRolesForm eemSecRolesForm = null;
		EEMSecRolesVO filterVO = context.getSecurityRolesVO();
		context.setSelectedMenu(EEMConstants.MENU_SECROLES);
		if (!(form instanceof EEMSecurityRolesForm)) {

			eemSecRolesForm = EEMSecRolesHelper.getEEMForm(sessionHelper);
			if (eemSecRolesForm == null) {
				eemSecRolesForm = new EEMSecurityRolesForm();
			}
			request.setAttribute(EEMConstants.EEM_SECURITY_ROLES_FORM, eemSecRolesForm);
		} else {
			eemSecRolesForm = (EEMSecurityRolesForm) form;
		}
		eemSecRolesForm.setCustomerID(sessionHelper.getMfId());
		EEMSecRolesHelper.setFormToVO(eemSecRolesForm, filterVO, sessionHelper);
		EEMSecRolesService service = context.getSecRolesService();
		String userid = sessionHelper.getUserId();
		String customerId = sessionHelper.getMfId();
		boolean userUpdate = service.getUserUpdate(conn, filterVO,userid,customerId);
		filterVO.setUserUpdate(userUpdate);
		EEMSecRolesHelper.setVOToForm(filterVO, eemSecRolesForm, sessionHelper);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_SECURITY_ROLES_APP);
	}
	/**
	 * This method is used to get the user details
	 * @param conn to connect to the DataBase
	 * @param sessionHelper to handle the form
	 * @param context to get the services and VO objects
	 * @param mapping to map to the forward jsp
	 * @param form to save the attributes
	 * @param request to forward the request
	 * @return ActionForward
	 * @throws ApplicationException
	 */
	public static ActionForward eemSecRolesMenu(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("Entered in Sec Roles");
//		logger.info("Entered in Sec Roles");
		EEMSecurityRolesForm eemSecRolesForm = null;
		EEMSecRolesVO filterVO = context.getSecurityRolesVO();
		context.setSelectedMenu(EEMConstants.MENU_SECROLES);
		if (!(form instanceof EEMSecurityRolesForm)) {

			eemSecRolesForm = EEMSecRolesHelper.getEEMForm(sessionHelper);
			if (eemSecRolesForm == null) {
				eemSecRolesForm = new EEMSecurityRolesForm();
			}

			request.setAttribute(EEMConstants.EEM_SECURITY_ROLES_FORM, eemSecRolesForm);
		} else {
			eemSecRolesForm = (EEMSecurityRolesForm) form;
		}
		eemSecRolesForm.setCustomerID(sessionHelper.getMfId());
		EEMSecRolesHelper.setFormToVO(eemSecRolesForm, filterVO, sessionHelper);
		EEMSecRolesService service = context.getSecRolesService();
		String userid = sessionHelper.getUserId();
		String customerId = sessionHelper.getMfId();
		Map<String,String> userDetails = service.getUserDetails(conn, filterVO,userid,customerId);
		if (userDetails.size() > 0) {
			filterVO.setUserDetails(userDetails);
			sessionHelper.getSession().setAttribute(
					EEMConstants.EEM_SEC_USERS_LIST, userDetails);
	} else {
			filterVO.setUserDetails(null);
			sessionHelper.getSession().setAttribute(
				EEMConstants.EEM_SEC_USERS_LIST, null);
	}
		List<UserRoles> lstSearch = service.getRolesList(conn, filterVO,customerId,userid);
		if (lstSearch.size() > 0) {
				filterVO.setUserRole(lstSearch);
				sessionHelper.getSession().setAttribute(
						EEMConstants.EEM_SEC_ROLES_LIST, lstSearch);
		} else {
				filterVO.setUserRole(null);
				sessionHelper.getSession().setAttribute(
					EEMConstants.EEM_SEC_ROLES_LIST, null);
		}
		
//		logger.info("In Action...........");
		logger.debug("In Action...........");
		EEMSecRolesHelper.setVOToForm(filterVO, eemSecRolesForm, sessionHelper);
//		logger.info("Exiting from Sec Roles");
		logger.debug("Exiting from Sec Roles");
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_SECURITY_ROLES_APP);
	}
}
