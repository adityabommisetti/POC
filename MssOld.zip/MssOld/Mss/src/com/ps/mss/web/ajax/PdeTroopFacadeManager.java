/*
 * Created on Apr 17, 2008
 * $Id: PdeTroopFacadeManager.java,v 1.1 2014/06/26 07:56:57 praveen Exp $
 *
 */
package com.ps.mss.web.ajax;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.PdeTroopService;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.manager.PdeTroopManager;
import com.ps.mss.model.FilterVO;
import com.ps.mss.model.Pagination;
import com.ps.mss.model.PdeContext;
import com.ps.mss.model.PdeDashboardVO;
import com.ps.mss.model.PdeDetailVO;
import com.ps.mss.model.PdeErrDetailItem;
import com.ps.mss.model.PdeEventDetailVO;
import com.ps.mss.model.PdeEventDetailVoList;
import com.ps.mss.model.TroopDashBoardVOList;
import com.ps.mss.model.TroopDetailVO;
import com.ps.mss.model.TroopDetailVOList;
import com.ps.mss.web.helper.AjaxHelper;
import com.ps.mss.web.helper.SessionHelper;

/**
 * @author deepak
 *
 */	
public class PdeTroopFacadeManager {
	private static Logger logger=LoggerFactory.getLogger(PdeTroopFacadeManager.class);
	/**
	 * This method check that whether export request valid or not base on total no of records(Base of search criteria).
	 * @author hemant 
	 * @return "TRUE" or Max valid Number of records to show
	 * @throws ApplicationException
	 */
	public String isExportPdeDetailRequestValid()throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		AjaxHelper.validateUser();
		FilterVO filterVO = null;
		Map detailMap = null;
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_PDE_EVENT_DETAIL_FILTERVO);
			detailMap = (Map)sessionHelper.getAttribute(Constants.SESSION_PDE_EVENT_DETAIL_MAP);
		logger.info(LoggerConstants.methodEndLevel());
		return PdeTroopManager.isExportPdeDetailRequestValid(AjaxHelper.getActiveDataBaseName(),filterVO,detailMap);	
	}
	
	/**
	 * This method check that whether export request valid or not base on total no of records(Base of search criteria).
	 * @author hemant 
	 * @return "TRUE" or Max valid Number of records to show
	 * @throws ApplicationException
	 */
	public String isExportTroopDetailRequestValid()throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		AjaxHelper.validateUser();
		FilterVO filterVO = null;
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_TROOP_DETAIL_FILTERVO);
		
		Map planMap = getPlanForParts();
		logger.info(LoggerConstants.methodEndLevel());
		return PdeTroopManager.isExportTroopDetailRequestValid(AjaxHelper.getActiveDataBaseName(),filterVO, planMap);	
	}
	/**
     *  This function is call by UI to get  values for trooopDashBoard.
     * @param searchType : On the  basis of this value we decide search criteria. 
     * @param filterVO : this Vo contain all the criteria to be use in searching.
     * @return
     * @throws ApplicationException
     */
    public TroopDashBoardVOList getTroopDashBoard (String searchType, FilterVO filterVO) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	AjaxHelper.validateUser();
        Map planMap = getPlanForParts();
        FilterVO sessionFilterVO = null;
        sessionFilterVO = (FilterVO) AjaxHelper.getAttribute(Constants.SESSION_TROOP_DASHBOARD_FILTERVO);
        AjaxHelper.updateFilterVo(sessionFilterVO,filterVO,searchType);
        logger.info(LoggerConstants.methodEndLevel());
        return PdeTroopManager.getTroopDashBoard(filterVO, planMap, searchType, null, AjaxHelper.getActiveDataBaseName());
    }
    
    /**
     * This find plans Map for partC/partD
     * @param request
     * @return
     * @throws ApplicationException
     */
    private Map getPlanForParts() throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
        Map planMap = sessionHelper.getPlanForParts();
        logger.info(LoggerConstants.methodEndLevel());
        return planMap;
    }
    
    
    /**
     * The <code>getTroopDetail</code> returns list of all Troop Detail based on search criteria
     * @param move
     * @return
     * @throws ApplicationException
     */
    public TroopDetailVOList getTroopDetail(String move ) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	AjaxHelper.validateUser();
        SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
        FilterVO filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_TROOP_DETAIL_FILTERVO);
        Map troopDeailMap = (Map) sessionHelper.getAttribute(Constants.SESSION_TROOP_DETAIL_MAP);
        //create key using PAGE_HIST value and set into discrpVoMap
        if("previous".equals(move)){
        	TroopDetailVO troopDetailVO = getPrevTroopDetailVO(troopDeailMap);
        	troopDeailMap.put(Constants.FIRST_DETAIL_VO, troopDetailVO);
		}
		
        Map planMap = getPlanForParts();
        String custName = (String) sessionHelper.getAttribute(Constants.SESSION_CUSTOMER_NAME);        
        TroopDetailVOList troopDetailVOList =  PdeTroopManager.getTroopDetail(filterVO, troopDeailMap, move, AjaxHelper.getActiveDataBaseName(), planMap, filterVO.getSearchType(), custName);
        setDetailMap(troopDeailMap, troopDetailVOList, sessionHelper, move);
        logger.info(LoggerConstants.methodEndLevel());
        return troopDetailVOList;
    }
    
    /**
     * This set detailMap which contain total number of page ,records , first and last record of discrpancyList 
     * @param troopMap
     * @param discrepancyDetailVOList
     * @param sessionHelper
     * @param string
     */
    private void setDetailMap(Map troopMap, TroopDetailVOList troopDetailVOList, SessionHelper sessionHelper, String move) {
    	logger.info(LoggerConstants.methodStartLevel());
    	if(troopDetailVOList != null) {
            if(troopMap == null )
                troopMap = new HashMap ();
            TroopDetailVO[] troopDetailVOs = troopDetailVOList.getTroopDetailVO();
            if(troopDetailVOs != null ){
	            /**************** START BLOCK FOR CALCULATING PAGE HIST ***************************
				 ADD : When user click on NEXT button (adding prev. page First VO
				 REMOVE : When user click on PREV button (remove top entry from List (it. current loading page)
				***********************************************************************************/
				
            	String pdePageHist = (String) troopMap.get(Constants.PAGE_HIST);
                String newPageHist = (pdePageHist != null) ? pdePageHist : "";
                
                // updating Troop Page Hist 
                if("previous".equals(move)){
                	if(newPageHist.indexOf(",") != -1) {
	                	String []pageHistArr = pdePageHist.split("[,]"); // spliting the list, remove last entry (CURRENT PAGE)
	                	newPageHist = pageHistArr[0];
	                	
	                	for(int i=1; i < pageHistArr.length-1; i++ ){
	                		newPageHist += "," + pageHistArr[i];
	                	}
                	} else 
                		newPageHist = "";
                	
        		} else if ("next".equals(move)) {  // adding current page Paging Key Set into Troop PAGE HIST
        			TroopDetailVO detailVO = (TroopDetailVO) troopMap.get(Constants.FIRST_DETAIL_VO);
        			if(! "".equals(newPageHist))
        				newPageHist += ",";
        			
       				newPageHist += detailVO.getPagingKeySet();
            	}
        		
        		if(("previous".equals(move) && "".equals(newPageHist)) || "first".equals(move))
        			troopMap.remove(Constants.PAGE_HIST);
        		else
        			troopMap.put(Constants.PAGE_HIST, newPageHist);
				/**************** END BLOCK FOR CALCULATING PAGE HIST ***************************/
				
				

        		troopMap.put(Constants.FIRST_DETAIL_VO,troopDetailVOs[0]);
                troopMap.put(Constants.LAST_DETAIL_VO,troopDetailVOs[troopDetailVOs.length-1]);
                troopMap.put(Constants.CURRENT_PAGE,troopDetailVOList.getCurrentPage());
                troopMap.put(Constants.PAGE_NUMBER , new Integer(troopDetailVOList.getPageNumber()));
                troopMap.put(Constants.PAGE_SELECTED_LINE , new Integer(troopDetailVOList.getSelectedLine()));
            }
            troopMap.remove(Constants.SESSION_MAX_RECORD_COUNT);
            troopMap.remove(Constants.CONSTANTS_ALL);
            
            sessionHelper.setAttribute(Constants.SESSION_TROOP_DETAIL_MAP,troopMap);	
        }
    	logger.info(LoggerConstants.methodEndLevel());
    }
    
    public PdeDetailVO getPdeDetail(String seqNum, int rowId, String menuName) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
    	AjaxHelper.validateUser();
        Map detailMap = null;
        
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		FilterVO filterVO = null;
        if(Constants.TROOP_DETAIL_MENU.equals(menuName)) {
			detailMap = (Map)sessionHelper.getAttribute(Constants.SESSION_TROOP_DETAIL_MAP);
			filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_TROOP_DETAIL_FILTERVO);
        } else if (Constants.PDE_ERR_DETAIL.equals(menuName)){ 
			PdeContext rc = (PdeContext) sessionHelper.getAttribute(Constants.SESSION_PDE_CONTEXT);
			filterVO = (FilterVO) rc.getErrDetailFilter();
	    	Pagination pagination = rc.getErrDetailPagination();
	    	pagination.setSelectedLine(rowId); 
        } else { 
			detailMap = (Map)sessionHelper.getAttribute(Constants.SESSION_PDE_EVENT_DETAIL_MAP);
			filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_PDE_EVENT_DETAIL_FILTERVO);
        }
		if(detailMap != null)
			detailMap.put(Constants.PAGE_SELECTED_LINE , new Integer(rowId));
		
		String custName = (String) sessionHelper.getAttribute(Constants.SESSION_CUSTOMER_NAME);
		logger.info(LoggerConstants.methodEndLevel());
		return PdeTroopManager.getPdeDetail(seqNum, custName, filterVO, AjaxHelper.getActiveDataBaseName());
    }
    
    public PdeDashboardVO[] getPdeDashBoard (String searchType, FilterVO filterVO, String menuName) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	AjaxHelper.validateUser();
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		Map planMap = sessionHelper.getPlanForParts();
		FilterVO sessionFilterVO = null;
		sessionFilterVO = (FilterVO) AjaxHelper.getAttribute(Constants.SESSION_PDE_DASHBOARD_FILTERVO);
		AjaxHelper.updateFilterVo(sessionFilterVO, filterVO, searchType);
		logger.info(LoggerConstants.methodEndLevel());
		return PdeTroopManager.getPdeDashBoard(filterVO, planMap, searchType, null, AjaxHelper.getActiveDataBaseName());
	}
    
    /**
     * @param move
     * @return
     * @throws ApplicationException
     */
    public PdeEventDetailVoList getPdeEventDetailList(String move) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	AjaxHelper.validateUser();
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		Map pdeEventVOMap = (Map)sessionHelper.getAttribute(Constants.SESSION_PDE_EVENT_DETAIL_MAP);
		
		if("previous".equals(move)){
			PdeEventDetailVO pdeDetailVO = getPrevPdeEventDetailVO(pdeEventVOMap);
			pdeEventVOMap.put(Constants.FIRST_DETAIL_VO, pdeDetailVO);
		}
		
		FilterVO filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_PDE_EVENT_DETAIL_FILTERVO);
		Map planMap = sessionHelper.getPlanForParts();
		String custName = (String) sessionHelper.getAttribute(Constants.SESSION_CUSTOMER_NAME);
		PdeEventDetailVoList pdeEventDetailVoList = PdeTroopManager.getPdeEventDetail(filterVO, pdeEventVOMap, "plan", move, planMap, custName, sessionHelper.getActiveDataBaseName());
		setPdeEvntMap(pdeEventVOMap, pdeEventDetailVoList, sessionHelper, move);
		logger.info(LoggerConstants.methodEndLevel());
		return pdeEventDetailVoList;
	}
    
    /**
	 * @param pdeEventVOMap
     * @return
	 */
	private PdeEventDetailVO getPrevPdeEventDetailVO(Map pdeEventVOMap) {
		logger.info(LoggerConstants.methodStartLevel());
		PdeEventDetailVO pdeDetailVO = null;
		String pageHist = (String) pdeEventVOMap.get(Constants.PDE_PAGE_HIST);
		if(pageHist != null){
			pdeDetailVO = new PdeEventDetailVO();
			String pdeStr;
			
			if(pageHist.indexOf(",") == -1){
				pdeStr = pageHist;
			} else {
				String [] pageHistArr = pageHist.split("[,]");
				
				//	getting Last page PDE Event Detail VO
				pdeStr = pageHistArr[pageHistArr.length-1];
			}
			String [] pdeDetailArr = pdeStr.split("[|]");
			
			pdeDetailVO.setServiceDate(pdeDetailArr[0]); // Service Date         
			pdeDetailVO.setPdeStatus(pdeDetailArr[1]);	// PDE Status
			pdeDetailVO.setHicNumber(pdeDetailArr[2]);	// Hic Number
			pdeDetailVO.setPdeSeqNumber(pdeDetailArr[3]);// Pde Sequence Number			
		}
		logger.info(LoggerConstants.methodEndLevel());
		return pdeDetailVO;
	}
	
	/**
	 * This method generally called to get First Record Keys of Last Page.
	 * which is used by Query Helper to produce prev. records set.
	 * This method also updates pageHist attribute
	 * @param pdeEventVOMap
     * @return
	 */
	private TroopDetailVO getPrevTroopDetailVO(Map pdeEventVOMap) {
		logger.info(LoggerConstants.methodStartLevel());
		TroopDetailVO troopDetailVO = null;
		String pageHist = (String) pdeEventVOMap.get(Constants.PAGE_HIST);
		if(pageHist != null){
			String troopStr;
			
			if(pageHist.indexOf(",") == -1){
				troopStr = pageHist;
			} else {
				String [] pageHistArr = pageHist.split("[,]");
				
				//	getting Last page PDE Event Detail VO
				troopStr = pageHistArr[pageHistArr.length-1];
			}
			String [] troopDetailArr = troopStr.split("[|]");
			
			troopDetailVO = new TroopDetailVO();
			troopDetailVO.setSeqNbr(troopDetailArr[0]); // Sequence Number
			troopDetailVO.setPlanName(troopDetailArr[1]);	// plan Name
			troopDetailVO.setPbpId(troopDetailArr[2]);	// pbp Id
			troopDetailVO.setHicNbr(troopDetailArr[3]);	// Hic Number
			troopDetailVO.setPymtEffDate(troopDetailArr[4]);// Payment Effective Date
			troopDetailVO.setLastUpdatTime(troopDetailArr[5]);// last Update Time
		
		}
		logger.info(LoggerConstants.methodEndLevel());
		return troopDetailVO;
	}

	/**
	 * This set detailMap which contain total number of page ,records , first and last record of discrpancyList 
	 * @param discrpMap
	 * @param discrepancyDetailVOList
	 * @param sessionHelper
	 * @param partName
	 * @param string
	 */
    private void setPdeEvntMap(Map pdeMap, PdeEventDetailVoList pdeDetailVOList, SessionHelper sessionHelper, String move) {
    	logger.info(LoggerConstants.methodStartLevel());
    	if(pdeDetailVOList != null) {
            if(pdeMap == null )
                pdeMap = new HashMap();
            PdeEventDetailVO[] pdeEventDetailVOs = (PdeEventDetailVO[])pdeDetailVOList.getPdeEventDetailVOs();
            if(pdeEventDetailVOs != null ){
	            /**************** START BLOCK FOR CALCULATING PAGE HIST ***************************
				 ADD : When user click on NEXT button (adding prev. page First VO
				 REMOVE : When user click on PREV button (remove top entry from List (it. current loading page)
				***********************************************************************************/
				
            	String pdePageHist = (String) pdeMap.get(Constants.PDE_PAGE_HIST);
                String newPageHist = (pdePageHist != null) ? pdePageHist : "";
                
                // updating PDE Page Hist 
                if("previous".equals(move)){
                	if(newPageHist.indexOf(",") != -1) {
	                	String []pageHistArr = pdePageHist.split("[,]"); // spliting the list, remove last entry (CURRENT PAGE)
	                	newPageHist = pageHistArr[0];
	                	
	                	for(int i=1; i < pageHistArr.length-1; i++ ){
	                		newPageHist += "," + pageHistArr[i];
	                	}
                	} else 
                		newPageHist = "";
                	
        		} else if ("next".equals(move)) {  // adding current page Paging Key Set into PDE PAGE HIST
        			PdeEventDetailVO detailVO = (PdeEventDetailVO) pdeMap.get(Constants.FIRST_DETAIL_VO);
        			if(! "".equals(newPageHist))
        				newPageHist += ",";
        			
       				newPageHist += detailVO.getPagingKeySet();
            	}
        		
        		if(("previous".equals(move) && "".equals(newPageHist)) || "first".equals(move))
        			pdeMap.remove(Constants.PDE_PAGE_HIST);
        		else
        			pdeMap.put(Constants.PDE_PAGE_HIST, newPageHist);
                /**************** START BLOCK FOR CALCULATING PAGE HIST ***************************/
                
        		
                pdeMap.put(Constants.FIRST_DETAIL_VO,pdeEventDetailVOs[0]);
                pdeMap.put(Constants.LAST_DETAIL_VO,pdeEventDetailVOs[pdeEventDetailVOs.length-1]);
                pdeMap.put(Constants.CURRENT_PAGE,pdeDetailVOList.getCurrentPage());
                pdeMap.put(Constants.PAGE_NUMBER , new Integer(pdeDetailVOList.getPageNumber()));
                pdeMap.put(Constants.PAGE_SELECTED_LINE , new Integer(pdeDetailVOList.getSelectedLine()));
            }
            pdeMap.remove(Constants.SESSION_MAX_RECORD_COUNT);
            pdeMap.remove(Constants.CONSTANTS_ALL);
            
            sessionHelper.setAttribute(Constants.SESSION_PDE_EVENT_DETAIL_MAP, pdeMap);	
        }
    	logger.info(LoggerConstants.methodEndLevel());
    } 
    /**
     * @param move
     * @return
     * @throws ApplicationException
     */
    public PdeEventDetailVoList getPdeErrDetailList(String move) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	AjaxHelper.validateUser();
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		PdeContext rc = (PdeContext) sessionHelper.getAttribute(Constants.SESSION_PDE_CONTEXT);
		Pagination pagination = rc.getErrDetailPagination();
		if("previous".equals(move)){
			PdeErrDetailItem detailItem = new PdeErrDetailItem();
			AjaxUtil.setPrevDetailFromHistory(detailItem, pagination);
			pagination.setFirstDetail(detailItem);
		}
				
		FilterVO filterVO = rc.getErrDetailFilter();
		Map planMap = sessionHelper.getPlanForParts();
		String custName = (String) sessionHelper.getAttribute(Constants.SESSION_CUSTOMER_NAME);
        PdeTroopService pdeTroopService = new PdeTroopService(sessionHelper.getActiveDataBaseName());
        Map results = pdeTroopService.getPdeErrDetail(filterVO, pagination, move, planMap, custName, false);
        PdeEventDetailVoList pdeEventDetailVoList =  (PdeEventDetailVoList)results.get("data");
        if (pdeEventDetailVoList != null ) {
        	PdeErrDetailItem[] detailArr = (PdeErrDetailItem[])pdeEventDetailVoList.getPdeEventDetailVOs();
			int count = 0;
			PdeErrDetailItem firstItem = null, lastItem = null;
			if (detailArr != null) {
				count = detailArr.length;
				firstItem = detailArr[0];
				if (count > 0)
					lastItem = detailArr[count - 1];
			} 
			AjaxUtil.setPagination(pagination, pdeEventDetailVoList, count, firstItem, lastItem, move);
        }	
        logger.info(LoggerConstants.methodEndLevel());
		return pdeEventDetailVoList;
	}
    

}
