/*
 * $Id: EEMGroupHelper.java,v 1.1 2014/06/26 07:55:02 praveen Exp $
 */
package com.ps.mss.web.helper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.db.EEMCodeCache;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.EEMContext;
import com.ps.mss.web.forms.EEMGroupForm;

public class EEMGroupHelper {
	private static Logger logger=LoggerFactory.getLogger(EEMGroupHelper.class);
	public static void saveEEMForm(SessionHelper sessionHelper, EEMGroupForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		sessionHelper.setAttribute("SaveEEMGroupForm",form);
		logger.info(LoggerConstants.methodEndLevel());
		}
	public static EEMGroupForm getEEMForm(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (EEMGroupForm)sessionHelper.getAttribute("SaveEEMGroupForm");
	}
	
	public static void clearForm(EEMGroupForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		form.setSearchItemSelected(0);
		form.setSearchResults(null);
		clearGroup(form);
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void clearGroup(EEMGroupForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		form.setGroupId("");
		form.setGrpStartDate("");
		form.setGrpEndDate("");
		form.setSupplGrpId("");
		form.setCreateTime("");
		form.setCreateUserId("");
		form.setLastUpdtTime("");
		form.setLastUpdtUserId("");	
		
		form.setPrevGrpName("");
		form.setGrpName("");
		form.setGrpNameStartDate("");
		form.setGrpNameEndDate("");
		form.setGrpNameLastUpdtTime("");
		form.setGrpNameLastUpdtUserId("");
		
		form.setGrpAddrItemSelected(0);
		form.setLstGrpAddresses(null);
		
		form.setAddrType("");
		form.setAddrAttention("");
		form.setAddrLine1("");
		form.setAddrLine2("");
		form.setAddrLine3("");
		form.setAddrCity("");
		form.setAddrState("");
		form.setAddrZip("");
		form.setAddrCountry("");
		form.setOfficePhone("");
		form.setFaxNbr("");
		form.setAddrCreateTime("");
		form.setAddrCreateUserId("");
		form.setAddrLastUpdtTime("");
		form.setAddrLastUpdtUserId("");	
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void setFormLists(EEMGroupForm eemGroupForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMCodeCache objCache = EEMCodeCache.getInstance();
		eemGroupForm.setLstGrpAddrTypes(objCache.getLstGrpAddrTypes());
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void setGroupSearchLists(EEMGroupForm eemGroupForm, EEMContext context) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		eemGroupForm.setSearchResults(context.getGroupSearchResult());
		eemGroupForm.setLstGrpAddresses(context.getGroupSearchAddrResult());
		logger.info(LoggerConstants.methodEndLevel());
	}
	
}
