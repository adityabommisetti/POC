/*
 * $Id: EEMBillMembPaymentsForm.java,v 1.1 2014/06/26 07:55:47 praveen Exp $
 */
package com.ps.mss.web.forms;

import java.util.List;

import com.ps.mss.dao.model.EmBBBPaymentsDetailVO;

public class EEMBillMembPaymentsForm extends EEMSubMenuForm {

	private String searchPaySource;
	private String searchInvoiceId;
	private String searchCheckNbr;
	private String searchLastName;
	private String searchHicNbr;
	private List lstPaySource;
	
	private String searchSupplId;
	
	public String getSearchSupplId() {
		return searchSupplId;
	}
	public void setSearchSupplId(String searchSupplId) {
		this.searchSupplId = searchSupplId;
	}

	private boolean detailListExpanded;
	private int selectedDetailRow;
	private String detailDisplayState;
	private List listDetail;
	private EmBBBPaymentsDetailVO displayPaymentsDetail = new EmBBBPaymentsDetailVO();
	
	public String getSearchPaySource() {
		return searchPaySource;
	}
	public void setSearchPaySource(String searchPaySource) {
		this.searchPaySource = searchPaySource;
	}
	public List getLstPaySource() {
		return lstPaySource;
	}
	public void setLstPaySource(List lstPaySource) {
		this.lstPaySource = lstPaySource;
	}
	public String getDetailDisplayState() {
		return detailDisplayState;
	}
	public void setDetailDisplayState(String detailDisplayState) {
		this.detailDisplayState = detailDisplayState;
	}
	public boolean isDetailListExpanded() {
		return detailListExpanded;
	}
	public void setDetailListExpanded(boolean detailListExpanded) {
		this.detailListExpanded = detailListExpanded;
	}
	public EmBBBPaymentsDetailVO getDisplayPaymentsDetail() {
		return displayPaymentsDetail;
	}
	public void setDisplayPaymentsDetail(
			EmBBBPaymentsDetailVO displayPaymentsDetail) {
		this.displayPaymentsDetail = displayPaymentsDetail;
	}
	public List getListDetail() {
		return listDetail;
	}
	public void setListDetail(List listDetail) {
		this.listDetail = listDetail;
	}
	public int getSelectedDetailRow() {
		return selectedDetailRow;
	}
	public void setSelectedDetailRow(int selectedDetailRow) {
		this.selectedDetailRow = selectedDetailRow;
	}
	public String getSearchCheckNbr() {
		return searchCheckNbr;
	}
	public void setSearchCheckNbr(String searchCheckNbr) {
		this.searchCheckNbr = searchCheckNbr;
	}
	public String getSearchInvoiceId() {
		return searchInvoiceId;
	}
	public void setSearchInvoiceId(String searchInvoiceId) {
		this.searchInvoiceId = searchInvoiceId;
	}
	public String getSearchHicNbr() {
		return searchHicNbr;
	}
	public void setSearchHicNbr(String searchHicNbr) {
		this.searchHicNbr = searchHicNbr;
	}
	public String getSearchLastName() {
		return searchLastName;
	}
	public void setSearchLastName(String searchLastName) {
		this.searchLastName = searchLastName;
	}
}
