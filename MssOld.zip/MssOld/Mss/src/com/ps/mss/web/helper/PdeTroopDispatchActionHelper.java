/*
 * Created on Apr 16, 2008
 * $Id: PdeTroopDispatchActionHelper.java,v 1.1 2014/06/26 07:55:04 praveen Exp $
 *
 */
package com.ps.mss.web.helper;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.CodeCacheService;
import com.ps.mss.businesslogic.PdeTroopService;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.helper.ServiceHelper;
import com.ps.mss.manager.PaymentManager;
import com.ps.mss.manager.PdeTroopManager;
import com.ps.mss.model.FilterVO;
import com.ps.mss.model.GenericDashboard;
import com.ps.mss.model.Pagination;
import com.ps.mss.model.PdeContext;
import com.ps.mss.model.PdeErrDetailItem;
import com.ps.mss.model.PdeEventDetailVO;
import com.ps.mss.model.PdeEventDetailVoList;
import com.ps.mss.model.TroopDetailVO;
import com.ps.mss.model.TroopDetailVOList;
import com.ps.mss.web.forms.PdeTroopForm;
import com.ps.util.DateUtil;
import com.ps.util.NameValuePair;
import com.ps.util.StringUtil;

/**
 * @author deepak
 *
 */
public class PdeTroopDispatchActionHelper {
	private static Logger logger=LoggerFactory.getLogger(PdeTroopDispatchActionHelper.class);
    /**
     * Fucntion fatch data for troop dashboard on the basis of search criteria,
     * @param request
     * @param PdeTroopForm
     * @throws ApplicationException
     */
    public void getTroopDashboard(HttpServletRequest request, PdeTroopForm pdeTroopForm) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	SessionHelper sessionHelper = new SessionHelper(request);
        FilterVO filterVO = null ;
        filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_TROOP_DASHBOARD_FILTERVO);
        filterVO = setFilterVO(pdeTroopForm,filterVO);
        filterVO.setSearchCrit("all");
        if(request.getParameter("print") !=  null) {
   			String searchCreiteriaHeader = PaymentManager.getSearchCreiteriaHeader(filterVO, Constants.TROOP_DASHBOARD, null, sessionHelper.getActiveDataBaseName());
   			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCreiteriaHeader);
   		}
        sessionHelper.setAttribute(Constants.SESSION_TROOP_DASHBOARD_FILTERVO,filterVO);
        setPdeTroopForm(pdeTroopForm,filterVO);
        Map planMap = sessionHelper.getPlanForParts();
        List troopDashBoardStatus = (List)sessionHelper.getAttribute(Constants.SESSION_TROOP_DESH_STATUS);
        pdeTroopForm.setTroopDashBoardVOList(PdeTroopManager.getTroopDashBoard(filterVO, planMap, "plan", troopDashBoardStatus, sessionHelper.getActiveDataBaseName()));
        pdeTroopForm.setDetailPage(false);
        logger.info(LoggerConstants.methodEndLevel());
    }
    
    /**
     * Function set PdeTroopForm from the filterVO for current search
     * @param PdeTroopForm
     * @param filterVO
     */
    private void setPdeTroopForm(PdeTroopForm baseForm, FilterVO filterVO) {
    	logger.info(LoggerConstants.methodStartLevel());
    	baseForm.setPlanName(filterVO.getPlanName());
        baseForm.setFromDate(filterVO.getStartDate());
        baseForm.setToDate(filterVO.getEndDate());
        baseForm.setSearchType(filterVO.getSearchType());
        baseForm.setHicNbr(filterVO.getHicNumber());
        baseForm.setPdeStatus(filterVO.getPdeStatus());
        baseForm.setPbpId(filterVO.getPbpId());
        baseForm.setErrorCode(filterVO.getDiscrpCd());
        logger.info(LoggerConstants.methodEndLevel());
     }

    /**
	 * Fucntion set search criteria into filterVO from baseForm.
	 * @param baseForm
	 * @param filterVO
	 * @return
	 */
	private FilterVO setFilterVO(PdeTroopForm baseForm,FilterVO filterVO) {
		logger.info(LoggerConstants.methodStartLevel());
		String action = baseForm.getActionType();	
		if( filterVO == null )
			filterVO = new FilterVO() ;
		
		// Filter criteria changed only when action execute from go button.
		if("search".equals(action) ) {
			filterVO.setPlanName(StringUtil.trimToNull(baseForm.getPlanName()));
			filterVO.setStartDate(StringUtil.trimToNull(baseForm.getFromDate()));
			filterVO.setEndDate(StringUtil.trimToNull(baseForm.getToDate()));
			filterVO.setHicNumber(StringUtil.trimToNull(baseForm.getHicNbr()));
			filterVO.setSearchType(StringUtil.trimToNull(baseForm.getSearchType()));
			filterVO.setPdeStatus(StringUtil.trimToNull(baseForm.getPdeStatus()));
			filterVO.setPbpId(StringUtil.trimToNull(baseForm.getPbpId()));
			//I can't believe it. So many fields in FilterVO, none for error code. So just reuse DiscrpCd
			filterVO.setDiscrpCd(StringUtil.trimToNull(baseForm.getErrorCode()));
			filterVO.setPageHeaderMsg("");
			filterVO.setTotalTroop("");
		}
		logger.info(LoggerConstants.methodEndLevel());
		return filterVO;
	}

    /**
     * This method fatch troop 
     * @param request
     * @param pdeTroopForm
     * @throws ApplicationException
     */
    public void getTroopDetail(HttpServletRequest request, PdeTroopForm pdeTroopForm) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	SessionHelper sessionHelper = new SessionHelper(request);
        String move = null;
        Map troopMap = null ;  
        // getting Troop Detail map, if user is not comming thru "GO" button on Troop detail page.
        if(! "search".equals(pdeTroopForm.getActionType()))
           	troopMap =  (Map)sessionHelper.getAttribute(Constants.SESSION_TROOP_DETAIL_MAP);
        
        FilterVO filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_TROOP_DETAIL_FILTERVO);
        filterVO = setFilterVO(pdeTroopForm ,filterVO);
        filterVO.setSearchType(sessionHelper.evaluteSearchType(filterVO));
        sessionHelper.setAttribute(Constants.SESSION_TROOP_DETAIL_FILTERVO,filterVO);
        setPdeTroopForm(pdeTroopForm, filterVO);
        Map planMap = sessionHelper.getPlanForParts();
        List uiContext = (List)sessionHelper.getAttribute(Constants.SESSION_TROOP_DETAIL_STATUS);
        if(request.getParameter("print") !=  null) {
        	String uiContextRange = StringUtil.nonNullTrim(request.getParameter("uiContextRange"));
			request.setAttribute("uiContextRange",uiContextRange);
			if(Constants.CONSTANTS_ALL.equals(uiContextRange)){
				 if(troopMap!=null){
				 	CodeCacheService codeCache=new CodeCacheService();
					Integer maxRecordCount=codeCache.getMaxRecordCount();
					troopMap.put(Constants.SESSION_MAX_RECORD_COUNT,maxRecordCount);
					troopMap.put(Constants.UI_CONTEXT_RANGE,Constants.CONSTANTS_ALL);
					move = "first";
				 }
			}
			
   			String searchCreiteriaHeader = PaymentManager.getSearchCreiteriaHeader(filterVO, Constants.TROOP_DETAIL, null, sessionHelper.getActiveDataBaseName());
   			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCreiteriaHeader);
   		}
        String custName = (String) sessionHelper.getAttribute(Constants.SESSION_CUSTOMER_NAME);
        TroopDetailVOList troopDetailVOList = PdeTroopManager.getTroopDetail(filterVO,troopMap, move, sessionHelper.getActiveDataBaseName(), planMap,filterVO.getSearchType(), custName);
           
        // reseting Detail Map only if request is not for PRINT.
        if(request.getParameter("print") ==  null)
        	setDetailMap(troopMap,troopDetailVOList,sessionHelper);
        
        if(troopMap != null){
        	troopMap.put(Constants.SESSION_MAX_RECORD_COUNT,new Integer(10));
        	troopMap.remove(Constants.UI_CONTEXT_RANGE);
        }
        pdeTroopForm.setTroopDetailVOList(troopDetailVOList);
        setUiContext(uiContext,pdeTroopForm);
        pdeTroopForm.setDetailPage(true);
        sessionHelper.setAttribute(Constants.SESSION_DISPLAY_TROOP_DETAIL,"true");//this attribute is set to show troopDetail tab once user has visite this.
        logger.info(LoggerConstants.methodEndLevel());
     }
   
	/**
	 * <code>setUiContext</code> set ui context into base form for requested page.
	 * @param uiContext
	 * @param baseForm
	 */
	private void setUiContext(List uiContext, PdeTroopForm pdeTroopForm) {
		logger.info(LoggerConstants.methodStartLevel());
		if(uiContext != null) {
			String contextString = null;
			Iterator it = uiContext.iterator();
			while(it.hasNext()) {
				contextString = (String) it.next();
				if(Constants.TROOP_LIST.equals(contextString)) 
				    pdeTroopForm.setShowTroopList(contextString);
				else if(Constants.PDE_DETAIL.equals(contextString)) 
				    pdeTroopForm.setShowPdeDetail(contextString);
				else if(Constants.PDE_EVENT_DETAIL.equals(contextString))
					pdeTroopForm.setShowPdeEventList(contextString);
			}
		} else { // This is for default context because in defult detail  must be open
		    pdeTroopForm.setShowTroopList(Constants.TROOP_LIST);
		    pdeTroopForm.setShowPdeEventList(Constants.PDE_EVENT_DETAIL);
		    pdeTroopForm.setShowPdeDetail(Constants.PDE_DETAIL);		    
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	/**
	 * @param request
	 * @param pdeTroopForm
	 * @throws ApplicationException
	 */
	public void getPdeDashboard(HttpServletRequest request, PdeTroopForm baseForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = new SessionHelper(request);
        FilterVO filterVO = null ;
        filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_PDE_DASHBOARD_FILTERVO);
        filterVO = setFilterVO(baseForm, filterVO);
        if(request.getParameter("print") !=  null) {
   			String searchCreiteriaHeader = PaymentManager.getSearchCreiteriaHeader(filterVO, Constants.PDE_DASHBOARD, null, sessionHelper.getActiveDataBaseName());
   			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCreiteriaHeader);
   		}
        sessionHelper.setAttribute(Constants.SESSION_PDE_DASHBOARD_FILTERVO,filterVO);
        setPdeTroopForm(baseForm, filterVO);
//        Map planMap = sessionHelper.getPlanForParts();
        List pdeDashBoardStatus = (List) sessionHelper.getAttribute(Constants.SESSION_PDE_DESH_STATUS);
        Map planMap = sessionHelper.getPlanForParts();
	    baseForm.setPdeDashBoardVOs(PdeTroopManager.getPdeDashBoard(filterVO, planMap, "plan", pdeDashBoardStatus, sessionHelper.getActiveDataBaseName()));
	    logger.info(LoggerConstants.methodEndLevel());
	  }
	
	/**
     * @param request
     * @param pdeTroopForm
	 * @throws ApplicationException
     */
    public void getPdeEventDetail(HttpServletRequest request, PdeTroopForm pdeTroopForm) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	SessionHelper sessionHelper = new SessionHelper(request);
        String move = null;
        FilterVO filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_PDE_EVENT_DETAIL_FILTERVO);

        Map pdeEventMap = null;
        // getting PDE Event detail map, if user is not comming thru "GO" button on PDE Event detail page.
        if(! "search".equals(pdeTroopForm.getActionType()))
        	pdeEventMap = (Map)sessionHelper.getAttribute(Constants.SESSION_PDE_EVENT_DETAIL_MAP); 
        		
        filterVO = setFilterVO(pdeTroopForm, filterVO);
        
        String uiContextRange = null;
        if(request.getParameter("print") !=  null) {
        	move = "current";
        	uiContextRange = StringUtil.nonNullTrim(request.getParameter("uiContextRange"));
			request.setAttribute("uiContextRange", uiContextRange);
			if(Constants.CONSTANTS_ALL.equals(uiContextRange)){
				 if(pdeEventMap!=null){
				 	CodeCacheService codeCache=new CodeCacheService();
					Integer maxRecordCount=codeCache.getMaxRecordCount();
					pdeEventMap.put(Constants.SESSION_MAX_RECORD_COUNT, maxRecordCount);
					pdeEventMap.put(Constants.UI_CONTEXT_RANGE,Constants.CONSTANTS_ALL);
					move = "first";
				 }
			}
			
   			String searchCreiteriaHeader = PaymentManager.getSearchCreiteriaHeader(filterVO, Constants.PDE_EVENT_DETAIL, null, sessionHelper.getActiveDataBaseName());
   			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCreiteriaHeader);
   		}
        
        sessionHelper.setAttribute(Constants.SESSION_PDE_EVENT_DETAIL_FILTERVO, filterVO);
        Map planMap = sessionHelper.getPlanForParts();
        
        List uiContext = (List)sessionHelper.getAttribute(Constants.SESSION_PDE_EVENT_DETAIL_STATUS);
        String custName = (String) sessionHelper.getAttribute(Constants.SESSION_CUSTOMER_NAME);
        
        PdeEventDetailVoList pdeEventDetailVoList = PdeTroopManager.getPdeEventDetail(filterVO, pdeEventMap, "plan", move, planMap, custName, sessionHelper.getActiveDataBaseName());
        
        pdeTroopForm.setPdeEventDetailVoList(pdeEventDetailVoList);
        
		if(request.getParameter("print") ==  null) {
			setPdeEvntMap(pdeEventMap, pdeEventDetailVoList, sessionHelper);
		}
		
		// resetting MAX record count to 10, which may modified by print request with ALL
		if(pdeEventMap != null) {
			pdeEventMap.put(Constants.SESSION_MAX_RECORD_COUNT, new Integer(10));
			pdeEventMap.remove(Constants.UI_CONTEXT_RANGE);
		}
        setUiContext(uiContext,pdeTroopForm);
        setPdeTroopForm(pdeTroopForm, filterVO);
        
        //Checking & correcting Service Date formate
        checkPdeServiceDateFormat(pdeTroopForm);
        sessionHelper.setAttribute(Constants.SESSION_DISPLAY_PDE_EVENT_DETAIL,"true"); //this attribute is set to show Pde Event Detail tab once user has visite this.        
        logger.info(LoggerConstants.methodEndLevel());
    }

	/**
	 * @param request
	 * @param pdeTroopForm
	 * @throws ApplicationException
	 */
	public void getPdeErrDashboard(HttpServletRequest request, PdeContext context, PdeTroopForm baseForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = new SessionHelper(request);
        FilterVO filterVO = null ;
        filterVO = context.getErrDashBoardFilter();
        filterVO = setFilterVO(baseForm, filterVO);
        context.setErrDashBoardFilter(filterVO);
		boolean getPlanPbp = true;
        if(request.getParameter("print") !=  null) {
        	getPlanPbp = false; //no need to build plan pbp map
        	String searchCriteriaHeader = ServiceHelper.getSearchCreiteriaHeader(filterVO, Constants.PDE_ERR_DASHBOARD, Constants.PDE_ERR_DASHBOARD );
   			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCriteriaHeader);
   		}
        setPdeTroopForm(baseForm, filterVO);
		PdeTroopService pdeTroopService = new PdeTroopService(sessionHelper.getActiveDataBaseName());		
		
		Map returnObjects = pdeTroopService.getPdeErrDashBoard(filterVO, sessionHelper.getPlanForParts(), context, getPlanPbp);
		GenericDashboard[] items= (GenericDashboard[])returnObjects.get("items");
	    baseForm.setPdeDashBoardVOs(items);
		String planPbp = buildPlanPBPArray((TreeMap) returnObjects.get("tree"));
		baseForm.setPbpList(getPbpList(StringUtil.trimToNull(filterVO.getPlanName()), (TreeMap)returnObjects.get("tree"), true));
		request.setAttribute("tree", planPbp);
		request.setAttribute("error", returnObjects.get("error"));
		logger.info(LoggerConstants.methodEndLevel());
	} 
	
	/**
	 * @param request
	 * @param pdeTroopForm
	 * @throws ApplicationException
	 */
	public void pdeErrCodes(HttpServletRequest request, PdeContext context, PdeTroopForm baseForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = new SessionHelper(request);
        FilterVO filterVO = null ;
        filterVO = context.getErrCodesFilter();
        filterVO = setFilterVO(baseForm, filterVO);
        boolean getPlanPbp = true;
        if(request.getParameter("print") !=  null) {
        	getPlanPbp = false; //no need to build plan pbp map
        	String searchCriteriaHeader = ServiceHelper.getSearchCreiteriaHeader(filterVO, Constants.PDE_ERR_CODES, Constants.PDE_ERR_CODES );
   			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCriteriaHeader);
   		}
        setPdeTroopForm(baseForm, filterVO);
		PdeTroopService pdeTroopService = new PdeTroopService(sessionHelper.getActiveDataBaseName());		
		
        PdeEventDetailVoList pdeEventDetailVoList =  new PdeEventDetailVoList();
		String tableTitle = ServiceHelper.createHeaderTitle(filterVO, null, null, sessionHelper.getPlanForParts(), "Service Date");
        pdeEventDetailVoList.setSummaryHeaderTitle(tableTitle);
		
        Map planMap = sessionHelper.getPlanForParts();
        Map returnObjects = pdeTroopService.getPdeErrCodes(filterVO, planMap);
        
        GenericDashboard[] items =  (GenericDashboard[])returnObjects.get("items");
	    baseForm.setPdeDashBoardVOs(items);
	    
        String planPbp = buildPlanPBPArray((TreeMap) returnObjects.get("tree"));
		baseForm.setPbpList(getPbpList(StringUtil.trimToNull(filterVO.getPlanName()), (TreeMap)returnObjects.get("tree"), true));
		
		request.setAttribute("tree", planPbp);
		request.setAttribute("error", returnObjects.get("error"));
		
		baseForm.setPdeEventDetailVoList(pdeEventDetailVoList);
        sessionHelper.setAttribute(Constants.SESSION_DISPLAY_PDE_ERR_CODES,"true"); //this attribute is set to show Pde Event Detail tab once user has visite this.
        logger.info(LoggerConstants.methodEndLevel());
	}  
	
    public void getPdeErrDetail(HttpServletRequest request, PdeContext context, PdeTroopForm pdeTroopForm) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	SessionHelper sessionHelper = new SessionHelper(request);
        String move = null;
        Pagination pagination = null;
        if ("search".equals(pdeTroopForm.getActionType())) //new search, reset pagination information
        	pagination = new Pagination();
        else {//reuse old pagination info
        	pagination = context.getErrDetailPagination();
        	if (pagination == null)
        		pagination = new Pagination();
        }
        context.setErrDetailPagination(pagination);
        FilterVO filterVO = context.getErrDetailFilter();
        filterVO = setFilterVO(pdeTroopForm, filterVO);
        
        String uiContextRange = null;
        if(request.getParameter("print") !=  null) {
        	move = "current";
        	uiContextRange = StringUtil.nonNullTrim(request.getParameter("uiContextRange"));
			request.setAttribute("uiContextRange", uiContextRange);
			if(Constants.CONSTANTS_ALL.equals(uiContextRange)){
				CodeCacheService codeCache=new CodeCacheService();
				Integer maxRecordCount=codeCache.getMaxRecordCount();
				pagination.setMaxRecordCount(maxRecordCount.intValue());
				pagination.setAllPage(true);
				move = "first";
			}
			
        	String searchCriteriaHeader = ServiceHelper.getSearchCreiteriaHeader(filterVO, Constants.PDE_ERR_DETAIL, Constants.PDE_ERR_DETAIL );
   			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCriteriaHeader);
   		}
        
        Map planMap = sessionHelper.getPlanForParts();
        
        List uiContext = context.getErrDetailExpandableItems();
        String custName = (String) sessionHelper.getAttribute(Constants.SESSION_CUSTOMER_NAME);
        
        PdeTroopService pdeTroopService = new PdeTroopService(sessionHelper.getActiveDataBaseName());
        Map results = pdeTroopService.getPdeErrDetail(filterVO, pagination, move, planMap, custName, true);
        PdeEventDetailVoList pdeEventDetailVoList =  (PdeEventDetailVoList)results.get("data");
       
        pdeTroopForm.setPdeEventDetailVoList(pdeEventDetailVoList);
        
		if(request.getParameter("print") ==  null) {
			setErrDetailPagination(pagination, pdeEventDetailVoList, sessionHelper);
		}
		
		// resetting MAX record count to 10, which may modified by print request with ALL
		pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
		pagination.setAllPage(false);

		setUiContext(uiContext,pdeTroopForm);
        setPdeTroopForm(pdeTroopForm, filterVO);
        
        //Checking & correcting Service Date formate
        checkPdeServiceDateFormat(pdeTroopForm);
        sessionHelper.setAttribute(Constants.SESSION_DISPLAY_PDE_ERR_DETAIL,"true"); //this attribute is set to show Pde Event Detail tab once user has visite this.
		String planPbp = buildPlanPBPArray((TreeMap) results.get("tree"));
		pdeTroopForm.setPbpList(getPbpList(StringUtil.trimToNull(filterVO.getPlanName()), (TreeMap)results.get("tree"), true));
		request.setAttribute("tree", planPbp);
		request.setAttribute("error", results.get("error"));
		logger.info(LoggerConstants.methodEndLevel());
    }
	/**
	 * Checking & correcting Service Date formate
	 * @param pdeTroopForm
	 */
	private void checkPdeServiceDateFormat(PdeTroopForm pdeTroopForm) {
		logger.info(LoggerConstants.methodStartLevel());
		String startDate = pdeTroopForm.getFromDate();
		String endDate = pdeTroopForm.getToDate(); 
		
		if(startDate != null && startDate.length() == 7 ){
			startDate = DateUtil.getFirstOrLastDayOfMonth(startDate, true);
			pdeTroopForm.setFromDate(startDate);
		}
		
		if(endDate != null && endDate.length() == 7 ){
			endDate = DateUtil.getFirstOrLastDayOfMonth(endDate, false);
			pdeTroopForm.setToDate(endDate);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	/**
	 * This set detailMap which contain total number of page ,records , first and last record of Pde Event Detail List 
	 * @param pdeMap
	 * @param pdeDetailVOList
	 * @param sessionHelper
	 */
    private void setPdeEvntMap(Map pdeMap, PdeEventDetailVoList pdeDetailVOList, SessionHelper sessionHelper) {
    	logger.info(LoggerConstants.methodStartLevel());
    	if(pdeDetailVOList != null) {
            if(pdeMap == null )
                pdeMap = new HashMap();
            PdeEventDetailVO[] pdeEventDetailVOs = (PdeEventDetailVO[])pdeDetailVOList.getPdeEventDetailVOs();
            if(pdeEventDetailVOs != null ){
                pdeMap.put(Constants.FIRST_DETAIL_VO,pdeEventDetailVOs[0]);
                pdeMap.put(Constants.LAST_DETAIL_VO,pdeEventDetailVOs[pdeEventDetailVOs.length-1]);
                pdeMap.put(Constants.CURRENT_PAGE,pdeDetailVOList.getCurrentPage());
                pdeMap.put(Constants.PAGE_NUMBER , new Integer(pdeDetailVOList.getPageNumber()));
                
            }
            pdeMap.remove(Constants.SESSION_MAX_RECORD_COUNT);
            pdeMap.remove(Constants.CONSTANTS_ALL);
            sessionHelper.setAttribute(Constants.SESSION_PDE_EVENT_DETAIL_MAP, pdeMap);	
        }
    	logger.info(LoggerConstants.methodEndLevel());
    }
    private void setErrDetailPagination(Pagination pagination, PdeEventDetailVoList pdeDetailVOList, SessionHelper sessionHelper) {
    	logger.info(LoggerConstants.methodStartLevel());
    	PdeErrDetailItem[] items = (PdeErrDetailItem[])pdeDetailVOList.getPdeEventDetailVOs();
        if(items != null ){
        	pagination.setFirstDetail(items[0]);
        	pagination.setLastDetail(items[items.length-1]);
        	pagination.setCurrentPage(pdeDetailVOList.getCurrentPage());
        	pagination.setPageNumber(pdeDetailVOList.getPageNumber());               
        }
        logger.info(LoggerConstants.methodEndLevel());
    }    
   
    /**
	 * This set detailMap which contain total number of page ,records , first and last record of discrpancyList 
	 * @param discrpMap
	 * @param discrepancyDetailVOList
	 * @param sessionHelper
	 * @param partName
	 * @param string
	 */
    private void setDetailMap(Map troopMap, TroopDetailVOList troopDetailVOList, SessionHelper sessionHelper) {
    	logger.info(LoggerConstants.methodStartLevel());
    	if(troopDetailVOList != null) {
            if(troopMap == null )
                troopMap = new HashMap ();
            TroopDetailVO[] troopDetailVOs = troopDetailVOList.getTroopDetailVO();
            if(troopDetailVOs != null ){
            	troopMap.put(Constants.FIRST_DETAIL_VO,troopDetailVOs[0]);
            	troopMap.put(Constants.LAST_DETAIL_VO,troopDetailVOs[troopDetailVOs.length-1]);
            	troopMap.put(Constants.CURRENT_PAGE,troopDetailVOList.getCurrentPage());
            	troopMap.put(Constants.PAGE_NUMBER , new Integer(troopDetailVOList.getPageNumber()));
            	
            	/*// adding first record into Troop PAGE HIST, which is furture used for pagination
            	String pdePageHist = (String) troopMap.get(Constants.PAGE_HIST);
            	if(pdePageHist == null) {
            		pdePageHist = troopDetailVOs[0].getPagingKeySet(); 
            		troopMap.put(Constants.PAGE_HIST, pdePageHist);
            	}*/
            }
            //troopMap.put(Constants.TROOP_DETAIL_MAP,createMap(troopDetailVOList));
            troopMap.remove(Constants.SESSION_MAX_RECORD_COUNT);
            troopMap.remove(Constants.CONSTANTS_ALL);
            
            sessionHelper.setAttribute(Constants.SESSION_TROOP_DETAIL_MAP,troopMap);	
        }
    	logger.info(LoggerConstants.methodEndLevel());
    }
    /**
     * 
     * @param tree
     * @return
     */
    private String buildPlanPBPArray(TreeMap tree) {
    	logger.info(LoggerConstants.methodStartLevel());
    	/*	 Create the Plan/PBP/Segment array with the following structure
    	planPBPSegment =  ['H9998',[['001'],['002']]],
    					  ['T9998',[['003'],['014']]]
    					 
    	*/	
    	if (tree == null) return "[]";
    	StringBuffer result = new StringBuffer("");
    	Set set = tree.entrySet();
    	Iterator it = set.iterator();
    	int i = 0;
    	while (it.hasNext()) {
    	       Map.Entry entry =  ( Map.Entry ) it.next () ; 
    	       if (i >0) result.append(",");
    	       result.append("['").append(entry.getKey()).append("',");
    	       TreeMap children = (TreeMap) entry.getValue();
    	       int j = 0;
    	       Set pbps = children.entrySet();
    	       if (pbps.size() == 0) 
    	       		result.append("[['']]");
    	       else {
    	       		result.append("[");
	    	       Iterator childIt = pbps.iterator();
	    	       while (childIt.hasNext()) {
	    	       		Map.Entry pbp = (Map.Entry) childIt.next();
	    	       		if (j>0) result.append(",");
	    	       		result.append("['").append(pbp.getKey()).append("']");
	    	       		j++;
	    	       }
	    	      result.append("]");
    	       }
	    	   result.append("]");
	    	   i++;
    	}
    	logger.info(LoggerConstants.methodEndLevel());
    	return result.toString();
    }
	public NameValuePair[] getPbpList(String planName, TreeMap tree, boolean supportAll) {
		logger.info(LoggerConstants.methodStartLevel());
		NameValuePair[] pbpList = null;
		int count = 0;
		if (supportAll)
			count++;
		Map pbpMap = null;
		if (planName == null || tree == null) {
			logger.info(LoggerConstants.methodEndLevel());
			return buildEmptyList();
		}
		else {
			pbpMap = (Map) tree.get(planName);
			if (pbpMap == null) {//the plan has no PBP for the selected year
				logger.info(LoggerConstants.methodEndLevel());
				return buildEmptyList();
			}
			count += pbpMap.size();
			Set entryset = pbpMap.entrySet();
			Iterator it = entryset.iterator();

			pbpList = new NameValuePair[count];
			int i=0;
			if (i == 0 && supportAll) {
				pbpList[0] = new NameValuePair();
				pbpList[0].setValue("All"); pbpList[0].setName("ALL");
				i++;
			}
			while (it.hasNext()) {
				java.util.Map.Entry entry = (Map.Entry) it.next();
				pbpList[i] = new NameValuePair();
				pbpList[i].setName((String)entry.getKey());
				pbpList[i].setValue((String)entry.getValue());
				i++;
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return pbpList;
	}
	private NameValuePair[] buildEmptyList() {
		logger.info(LoggerConstants.methodStartLevel());
		NameValuePair[] pbpList = new NameValuePair[1];
		pbpList[0] = new NameValuePair();
		pbpList[0].setValue("All"); pbpList[0].setName("ALL");
		logger.info(LoggerConstants.methodEndLevel());
		return pbpList;
	}
}
