/*
/* * $Id: EEMAction.java,v 1.24 2016/06/16 19:37:37 dinesh Exp $
 */
package com.ps.mss.web.actions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EEMApplService;
import com.ps.mss.businesslogic.EEMOevService;
import com.ps.mss.businesslogic.EEMSupvsrService;
import com.ps.mss.dao.DaoFactory;
import com.ps.mss.dao.EEMApplDao;
import com.ps.mss.dao.EEMBillDao;
import com.ps.mss.dao.EEMEnrollDao;
import com.ps.mss.dao.model.EEMApplCommentsVO;
import com.ps.mss.dao.model.EEMLetterReviewQcVO;
import com.ps.mss.dao.model.EmBBBPaymentsHeaderVO;
import com.ps.mss.dao.model.EmCorrMbrVO;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.EEMCodeCache;
import com.ps.mss.db.EEMPersistence;
import com.ps.mss.db.EEMProfileSettings;
import com.ps.mss.db.MBD;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.manager.EEMApplManager;
import com.ps.mss.manager.EEMBillingManager;
import com.ps.mss.manager.EEMEnrollManager;
import com.ps.mss.manager.EEMGroupManager;
import com.ps.mss.manager.EEMLetterManager;
import com.ps.mss.manager.EEMLetterReviewManager;
import com.ps.mss.manager.EEMManager;
import com.ps.mss.model.EEMApplicationVO;
import com.ps.mss.model.EEMContext;
import com.ps.mss.model.EEMEnrollVO;
import com.ps.mss.model.EEMLetterReqVO;
import com.ps.mss.model.EEMLetterReviewAttachmentVO;
import com.ps.mss.model.EEMLetterReviewVO;
import com.ps.mss.model.EEMOriginalApplicationVO;
import com.ps.mss.model.EEMSupvsrVO;
import com.ps.mss.model.EMBillPaymentsVO;
import com.ps.mss.model.EMLetterReqDisplayVO;
import com.ps.mss.model.Pagination;
import com.ps.mss.security.SessionManager;
import com.ps.mss.util.MssProperties;
import com.ps.mss.web.forms.EEMApplForm;
import com.ps.mss.web.forms.EEMBillDraftForm;
import com.ps.mss.web.forms.EEMBillInvoiceForm;
import com.ps.mss.web.forms.EEMBillMembPaymentsForm;
import com.ps.mss.web.forms.EEMBillPaymentsForm;
import com.ps.mss.web.forms.EEMDshBrdForm;
import com.ps.mss.web.forms.EEMEnrollForm;
import com.ps.mss.web.forms.EEMForm;
import com.ps.mss.web.forms.EEMGroupForm;
import com.ps.mss.web.forms.EEMLetterReqForm;
import com.ps.mss.web.forms.EEMLetterReviewAttachmentForm;
import com.ps.mss.web.forms.EEMLetterReviewDetailForm;
import com.ps.mss.web.forms.EEMLetterReviewGenerateForm;
import com.ps.mss.web.forms.EEMLetterReviewQCForm;
import com.ps.mss.web.forms.EEMLetterUploadForm;
import com.ps.mss.web.forms.EEMMbrDshBrdForm;
import com.ps.mss.web.forms.EEMSubMenuForm;
import com.ps.mss.web.forms.EEMSupvsrForm;
import com.ps.mss.web.helper.EEMApplHelper;
import com.ps.mss.web.helper.EEMBillingHelper;
import com.ps.mss.web.helper.EEMDshBrdHelper;
import com.ps.mss.web.helper.EEMEnrollHelper;
import com.ps.mss.web.helper.EEMGroupHelper;
import com.ps.mss.web.helper.EEMHelper;
import com.ps.mss.web.helper.EEMLetterHelper;
import com.ps.mss.web.helper.EEMLetterReviewHelper;
import com.ps.mss.web.helper.EEMMbrDshBrdHelper;
import com.ps.mss.web.helper.EEMSupvsrHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.web.util.EEMSwitchUtil;
import com.ps.text.DateFormatter;
import com.ps.util.DateMath;
import com.ps.util.DateUtil;
import com.ps.util.StringUtil;
/**
 * @author nenne.robert
 */
public class EEMAction extends Action {
	
	private static Logger logger=LoggerFactory.getLogger(EEMAction.class);
	private static Logger replogger=LoggerFactory.getLogger("reportsLogger");

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		try {
			EEMForm eemForm = (EEMForm) form;
			String method = eemForm.getMethod();
			
			// use the default DB for security check
			conn = DbConn.getConnection();
			SessionHelper sessionHelper = new SessionHelper(request);
			String errorMsg = sessionHelper.validateUser(conn);
			if (errorMsg != null) {
				request.setAttribute("Msg", "Login Has Timed Out");
				throw new Exception(errorMsg);
			}
			
			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			logger.error(" EEMDB in action=="+eemDb);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			EEMContext context = EEMManager.getContext(sessionHelper.getSession());
			String selectedMenu = context.getSelectedMenu();
			eemForm.setMessage(null);// Reset the Exception/Error messages
			if("updateRole".equals(method)){
				logger.info(LoggerConstants.methodEndLevel());
				return EEMSecurityAction.updateRole(conn, sessionHelper, context, mapping, form, request);
			}
			if ("initialize".equals(method)) {
				logger.info(LoggerConstants.methodEndLevel());
				return initializeEEM(conn, sessionHelper, context, mapping, form, request);
			} 
			else 
			if ("switchMenu".equals(method)) {
				logger.info(LoggerConstants.methodEndLevel());
				return EEMSwitchUtil.switchMenu( mapping, conn, context,  form, eemForm,  sessionHelper,  request,  response);
				/*String menu = eemForm.getMenu();

				if(eemForm instanceof EEMEnrollForm) {
					EEMEnrollHelper.saveEEMForm(sessionHelper,(EEMEnrollForm)eemForm);
				}
				else
				if(eemForm instanceof EEMApplForm) {
					EEMApplHelper.saveEEMForm(sessionHelper,(EEMApplForm)eemForm);
				}
				else
				if(eemForm instanceof EEMLetterReqForm) {
					EEMLetterHelper.saveEEMForm(sessionHelper,(EEMLetterReqForm)eemForm);
				}
				else
				if(eemForm instanceof EEMSupvsrForm) {
					EEMSupvsrHelper.saveEEMForm(sessionHelper,(EEMSupvsrForm)eemForm);
				}
				else
				if(eemForm instanceof EEMLetterReviewDetailForm) {
					EEMLetterReviewHelper.saveEEMDetailForm(sessionHelper,(EEMLetterReviewDetailForm)eemForm);
				}
				else
				if(eemForm instanceof EEMGroupForm) {
					EEMGroupHelper.saveEEMForm(sessionHelper,(EEMGroupForm)eemForm);
				}
				else
				if(eemForm instanceof EEMBillInvoiceForm) {
					EEMBillingHelper.saveEEMFormInv(sessionHelper,(EEMBillInvoiceForm)eemForm);
				}
					else
				if(eemForm instanceof EEMBillDraftForm) {
						EEMBillingHelper.saveEEMFormDraft(sessionHelper,(EEMBillDraftForm)eemForm);
					}
				else
				if(eemForm instanceof EEMBillPaymentsForm) {
					EEMBillingHelper.saveEEMFormPay(sessionHelper,(EEMBillPaymentsForm)eemForm);
				}
				else
				if(eemForm instanceof EEMDshBrdForm) {
					EEMDshBrdHelper.saveEEMForm(sessionHelper,(EEMDshBrdForm)eemForm);
				}
				else
				if(eemForm instanceof EEMMbrDshBrdForm) {
					EEMMbrDshBrdHelper.saveEEMForm(sessionHelper,(EEMMbrDshBrdForm)eemForm);
				}
					
				if (EEMConstants.MENU_APPL.equals(menu))
					return eemApplMenu(conn, sessionHelper, context, mapping, form, request);
				if (EEMConstants.MENU_ENROLLMENT.equals(menu))
					return eemEnrollmentMenu(conn, sessionHelper, context, mapping, form, request);
				if (EEMConstants.MENU_DASHBOARD.equals(menu))
					return eemDashBoard(conn, sessionHelper, context, mapping, form, request);
				if (EEMConstants.MENU_MBR_DASHBOARD.equals(menu))
					return eemMbrDashBoard(conn, sessionHelper, context, mapping, form, request);
				if (EEMConstants.MENU_APPROVALS.equals(menu))
					return eemSupvsrApproval(conn, sessionHelper, context, mapping, form, request);
				if (EEMConstants.MENU_GROUP.equals(menu))
					return eemGroupSelect(conn, sessionHelper, context, mapping, form, request);
				if (EEMConstants.MENU_LETTER.equals(menu))
					return eemLetterReqMenu(conn, sessionHelper, context, mapping, form, request);
				if (EEMConstants.MENU_LETTER_REVIEW.equals(menu))
					return eemLetterReviewMenu(conn, sessionHelper, context, mapping, form, request);
				if (EEMConstants.MENU_BILLING.equals(menu))
					return eemBillingMenu(conn, sessionHelper, context, mapping, form, request);
				
			*/}
			else 
			if (EEMConstants.MENU_DASHBOARD.equals(selectedMenu)) {
				if ("gotoApplSearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemDshBrdToAppl(conn, sessionHelper, context, mapping, form, request);
				}
				if ("applDshBrdSelectTab".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemDshBrdTabSelect(conn, sessionHelper, context, mapping, form, request);
				}
				if ("drillDown".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemDshBrdDrill(conn, sessionHelper, context, mapping, form, request);
				}
			}
			else 
			if (EEMConstants.MENU_MBR_DASHBOARD.equals(selectedMenu)) {
				if ("gotoMbrSearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemDshBrdToMbr(conn, sessionHelper, context, mapping, form, request);
				}
				if ("mbrDshBrdSelectTab".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemMbrDshBrdTabSelect(conn, sessionHelper, context, mapping, form, request);
				}
				if ("drillDown".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemMbrDshBrdDrill(conn, sessionHelper, context, mapping, form, request);
				}
			}
			else 
			if (EEMConstants.MENU_GROUP.equals(selectedMenu)) {

				if(eemForm instanceof EEMGroupForm) {
					EEMGroupHelper.setFormLists((EEMGroupForm)eemForm);
				}

				String selectedTab = context.getOptGrpSvc();
				if (EEMConstants.OPTION_GROUPSEM.equals(selectedTab)) {
					if (EEMConstants.METHOD_SEARCH.equals(method)) {
						logger.info(LoggerConstants.methodEndLevel());
						return eemGroupsSearch(conn, sessionHelper, context, mapping, form, request);
					}					
					if (EEMConstants.METHOD_GROUP_GET.equals(method)) {
						logger.info(LoggerConstants.methodEndLevel());
						return eemGroupsGet(conn, sessionHelper, context, mapping, form, request);
					}
					if (EEMConstants.METHOD_GROUP_NEW.equals(method)) {
						logger.info(LoggerConstants.methodEndLevel());
						return eemGroupsNew(conn, sessionHelper, context, mapping, form, request);
					}
					if (EEMConstants.METHOD_GROUP_SAVE.equals(method)) {
						logger.info(LoggerConstants.methodEndLevel());
						return eemGroupsSave(conn, sessionHelper, context, mapping, form, request);
					}
					if (EEMConstants.METHOD_GROUP_ADDR_GET.equals(method)) {
						logger.info(LoggerConstants.methodEndLevel());
						return eemGroupAddrGet(conn, sessionHelper, context, mapping, form, request);
					}
				}
				if (EEMConstants.OPTION_GROUPSEM.equals(method)) {
					logger.info(LoggerConstants.methodEndLevel());
					return eemGroupsEM(conn, sessionHelper, context, mapping, form, request);				
				}
				if (EEMConstants.OPTION_PRODUCTSEM.equals(method)) {
					logger.info(LoggerConstants.methodEndLevel());
					return eemProductsEM(conn, sessionHelper, context, mapping, form, request);				
				}
				if (EEMConstants.OPTION_SVCAREASEM.equals(method)) {
					logger.info(LoggerConstants.methodEndLevel());
					return eemSvcAreasEM(conn, sessionHelper, context, mapping, form, request);				
				}															
			}else if (EEMConstants.MENU_MEDICAID.equals(selectedMenu)) {
				EEMEnrollVO enrollVO = context.getEnrollVO();
				enrollVO.setMessage("");

				if(eemForm instanceof EEMEnrollForm) {
					//EEMEnrollHelper.setEnrollFormList((EEMEnrollForm)eemForm, sessionHelper.getSession());
					//EEMEnrollManager.setAgentsLookUp(conn, sessionHelper, (EEMEnrollForm)eemForm);
				}	
				if ("enrollSearchSelect".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollSearchSelect(conn, sessionHelper, context, mapping, form, request);
				}
				if ("enrollShowAll".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollShowAll(conn, sessionHelper, context, mapping, form, request);
				}
				if ("enrollSearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollSearch(conn, sessionHelper, context, mapping, form, request);
				}
				if ("enrollSearchPageNext".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollSearchPage(conn, sessionHelper, context, mapping, form, request, "next");
				}
				if ("enrollSearchPagePrev".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollSearchPage(conn, sessionHelper, context, mapping, form, request, "previous");
				}
				if ("enrollSearchPageFirst".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollSearchPage(conn, sessionHelper, context, mapping, form, request, "first");
				}
				if ("enrollTabPage".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollTabPage(conn, sessionHelper, context, mapping, form, request);
				}
			}
			
			else if (EEMConstants.MENU_ENROLLMENT.equals(selectedMenu)) {
			
				EEMEnrollVO enrollVO = context.getEnrollVO();
				enrollVO.setMessage("");

				if(eemForm instanceof EEMEnrollForm) {
					EEMEnrollHelper.setEnrollFormList((EEMEnrollForm)eemForm, sessionHelper.getSession());
					EEMEnrollManager.setAgentsLookUp(conn, sessionHelper, (EEMEnrollForm)eemForm);
				}
				
				/**
				 * Cambia_OEVProcess-Start
				 */
				if ("mbrOevScript".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemMbrOevScript(conn, sessionHelper, context, mapping, (EEMEnrollForm) eemForm, request);
				}
				/**
				 * Cambia_OEVProcess-End
				 */
				if ("enrollSearchSelect".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollSearchSelect(conn, sessionHelper, context, mapping, form, request);
				}
				if ("enrollUpdate".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollUpdate(conn, sessionHelper, context, mapping, form, request);
				}
				if ("enrollDelete".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollDelete(conn, sessionHelper, context, mapping, form, request);
				}
				/**
				 * 024_Cambia_SUC_LEP - Start 1
				 */
				
				if ("enrollCreCovLetter".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLEPCreLetter(conn, sessionHelper, context,
							mapping, form, request);
				}
				if ("enrollLepAdjLetter".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLEPAdjLetter(conn, sessionHelper, context,
							mapping, form, request);
				}
				/**
				 * 024_Cambia_SUC_LEP - End 1
				 */
				if ("enrollShowAll".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollShowAll(conn, sessionHelper, context, mapping, form, request);
				}
				//New LEP changes - Start
				if ("enrollPotentialShowAll".equals(method))
					return eemEnrollPotentialShowAll(conn, sessionHelper, context, mapping, form, request);
				if ("enrollCcfShowAll".equals(method))
					return eemEnrollCcfShowAll(conn, sessionHelper, context, mapping, form, request);
				//New LEP changes - end
				if ("enrollSearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollSearch(conn, sessionHelper, context, mapping, form, request);
				}
				if ("cityZipSearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplCitySearch(conn, sessionHelper, context, mapping, form, request);
				}
				if ("enrollSearchPageNext".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollSearchPage(conn, sessionHelper, context, mapping, form, request, "next");
				}
				if ("enrollSearchPagePrev".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollSearchPage(conn, sessionHelper, context, mapping, form, request, "previous");
				}
				if ("enrollSearchPageFirst".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollSearchPage(conn, sessionHelper, context, mapping, form, request, "first");
				}
				if ("enrollLetterSelect".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollLetterSelect(conn, sessionHelper, context, mapping, form, request);
				}

				if ("enrollTabPage".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollTabPage(conn, sessionHelper, context, mapping, form, request);
				}

				if ("enrollClearSearch".equals(method))
					return eemEnrollClearSearch(conn, sessionHelper, context, mapping, form, request);
				/**
				 * Start -- for 020_UI Mock_ups-- to view letter from DB
				 */
				if ("displayDocFromDB".equals(method)) {
					logger.info(LoggerConstants.methodEndLevel());
					return displayDocumentFromDB(conn, sessionHelper,
							context, mapping, form, request, response);
				}
				/**
				 * End -- for 020_UI Mock_ups-- to view letter from DB
				 */
				/**
				 * Start -- 014_Highmark_SUC_Letters_v1-- to Reprint Selected Letter 
				 */
				if ("rePrintSelectedLetter".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollReprintLetter(conn, 
                       sessionHelper,context, mapping, form, request, response);
				}
				/**
				 * End -- 014_Highmark_SUC_Letters_v1-- to Reprint Selected Letter 
				 */
				
				if ("enrollAgencySearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollAgencySearch(conn, sessionHelper, context, mapping, form, request);
				}
				if ("enrollAgencySearchNew".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEnrollAgencySearchNew(conn, sessionHelper, context, mapping, form, request);
				}
			} else if (EEMConstants.MENU_APPL.equals(selectedMenu)) {
				
				if(eemForm instanceof EEMApplForm) {
					EEMApplHelper.setApplFormList((EEMApplForm)eemForm, sessionHelper);
				}

				if ("applNewMemberMA".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplNewMemberMA(conn, sessionHelper, context, mapping, form, request);
				}
				if ("applNewMemberPD".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplNewMemberPD(conn, sessionHelper, context, mapping, form, request);
				}
				if ("contractChgMA".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemContractChgMA(conn, sessionHelper, context, mapping, form, request);
				}
				if ("contractChgPD".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemContractChgPD(conn, sessionHelper, context, mapping, form, request);
				}
				if ("applSearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplSearch(conn, sessionHelper, context, mapping, form, request);
				}
				//IFOX-00395242 - viewPdf-- start
				if ("viewPdf".equals(method)) {
					logger.info(LoggerConstants.methodEndLevel());
					return viewPdf(conn, sessionHelper,
							context, mapping, form, request, response);
				}
				//IFOX-00395242 - viewPdf-- end
				//original application start
				if ("originalAppl".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplOriginal(conn, sessionHelper, context, mapping,
							form, request);
				}
				if("currentAppl".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplRowSearch(conn, sessionHelper, context,
							mapping, form, request);
				}
				//original application end
				
				
				if ("eligCheck".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemEligCheck(conn, sessionHelper, context, mapping, form, request);	
				}
				if ("applUpdate".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplUpdate(conn, sessionHelper, context, mapping, form, request);
				}
				/*if ("applCommentsUpdate".equals(method))
					return eemApplCommentsUpdate(conn, sessionHelper, context, mapping, form, request);*/
				if ("cityZipSearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplCitySearch(conn, sessionHelper, context, mapping, form, request);
				}
				if ("prodSearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplProdSearch(conn, sessionHelper, context, mapping, form, request);
				}
				if ("pcpSearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplPcpSearch(conn, sessionHelper, context, mapping, form, request);
				}
				if ("validate".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplValidate(conn, sessionHelper, context, mapping, form, request);
				}
				if ("rowSearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplRowSearch(conn, sessionHelper, context, mapping, form, request);
				}
				if ("applSearchPageNext".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplSearchPage(conn, sessionHelper, context, mapping, form, request, "next");
				}
				if ("applSearchPageFirst".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplSearchPage(conn, sessionHelper, context, mapping, form, request, "first");
				}
				if ("applSearchPagePrev".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplSearchPage(conn, sessionHelper, context, mapping, form, request, "previous");
				}
				if ("memberCheck".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplMemberCheck(conn, sessionHelper, context, mapping, form, request);
				}
				if ("applCancel".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemAppl(conn, sessionHelper, context, mapping, form, request);
				}
				/**
				 * Cambia_Application Cancellation- Start 
				 */
				if ("reject".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplCancellation(conn, sessionHelper, context, mapping,
							form, request);
				}
				/**
				 * Cambia_Application Cancellation- End
				 */
				
				/**
				 * Cambia_PRE-SET Notes-Start
				 */
				if("preSetUpdate".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					 return eemEnrollAddNote(conn, sessionHelper, context, mapping,
					 form, request);
					 }
				/**
				 * Cambia_PRE-SET Notes-End
				 */
				// 024_LEP Start
				if ("lepInformation".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplLep(conn, sessionHelper, context, mapping, form, request);
				}
				if ("appLEPUpdate".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemappLEPUpdate(conn, sessionHelper, context, mapping, form, request);
				}
				// 024_LEP End
				
				//New LEP CR Start
				if ("appLEPShowAll".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemappLEPShowAll(conn, sessionHelper, context, mapping, form, request);
				}
				// NEw LEP CR End
				
				// 024_LEP End
				//new LEP changes -- start
				if ("appLepUnCovPtnlMnthUpdate".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemAppLepUnCovPtnlMnthUpdate(conn, sessionHelper, context, mapping, form, request);
				}
				if ("appLepUnCovPtnlMnthDelete".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemAppLepUnCovPtnlMnthDelete(conn, sessionHelper, context, mapping, form, request);
				}
				if ("appLepAttnInfoDelete".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemAppLepAttnDelete(conn, sessionHelper, context, mapping, form, request);
				}
				//new LEP changes End.
				
				/**
				 * Cambia_OEVProcess-start
				 */
				if("oevUpdate".equals(method)){{
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplOev(conn, sessionHelper,context, mapping, form, request);
				}
				}
				if ("oevScript".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemOevScript(conn, sessionHelper, context, mapping, eemForm, request);
				}
				/**
				 * Cambia_OEVProcess-End
				 */
				
				if ("agencySearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplAgencySearch(conn, sessionHelper, context, mapping, form, request);
				}
				if ("agencySearchNew".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplAgencySearchNew(conn, sessionHelper, context, mapping, form, request);
				}
				if ("displayDocFromDB".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return displayDocumentFromDB(conn, sessionHelper, context, mapping, eemForm, request, response);
				}
				
			} else if (EEMConstants.MENU_APPROVALS.equals(selectedMenu)) {
				
				if(eemForm instanceof EEMSupvsrForm) {
					EEMSupvsrHelper.setSupvsrFormList((EEMSupvsrForm)eemForm, sessionHelper);
				}
				
				if ("supvsrSearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemSupvsrSearch(conn, sessionHelper, context, mapping, form, request);
				}
				if ("supvsrPageNext".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemSupvsrSearchPage(conn, sessionHelper, context, mapping, form, request, "next");
				}
				if ("supvsrPageFirst".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemSupvsrSearchPage(conn, sessionHelper, context, mapping, form, request, "first");
				}
				if ("supvsrPagePrev".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemSupvsrSearchPage(conn, sessionHelper, context, mapping, form, request, "previous");
				}
				if ("gotoApplication".equals(method)) {
					logger.info(LoggerConstants.methodEndLevel());
					return eemSupvsrGotoAppl(conn, sessionHelper, context, mapping, form, request);
				}
				if ("supvsrUpdate".equals(method)) {
					logger.info(LoggerConstants.methodEndLevel());
					return eemSupvsrUpdate(conn, sessionHelper, context, mapping, form, request);
				}
				if ("supvsrCancel".equals(method)) {
					logger.info(LoggerConstants.methodEndLevel());
					return eemSupvsrCancel(conn, sessionHelper, context, mapping, form, request);
				}
				
			} else if (EEMConstants.MENU_LETTER.equals(selectedMenu)) {

				if(eemForm instanceof EEMLetterReqForm) {
					EEMLetterHelper.setFormLists((EEMLetterReqForm)eemForm);
				}

				if ("lookup".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReqLookup(conn, sessionHelper, context, mapping, eemForm, request);
				}
				if ("selectletter".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReqSelectLetter(conn, sessionHelper, context, mapping, eemForm, request);
				}
				if ("createletter".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReqCreateLetter(conn, sessionHelper, context, mapping, eemForm, request);
				}
				if ("infoChange".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReqInfoChange(conn, sessionHelper, context, mapping, eemForm, request);
				}
				if ("search".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReqSearch(conn, sessionHelper, context, mapping, eemForm, request);
				}
				if ("newRequest".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReqNewRequest(conn, sessionHelper, context, mapping, eemForm, request);
				}
				if ("letterReqSearchPageNext".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReqSearchPage(conn, sessionHelper, context, mapping, form, request, "next");
				}
				if ("letterReqSearchPagePrev".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReqSearchPage(conn, sessionHelper, context, mapping, form, request, "previous");
				}
				if ("letterReqSearchPageFirst".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReqSearchPage(conn, sessionHelper, context, mapping, form, request, "first");
				}
				if ("letterReqSelect".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReqSelect(conn, sessionHelper, context, mapping, form, request);
				}

				if ("clearSearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReqClearSearch(conn, sessionHelper, context, mapping, eemForm, request);
				}
				
			} else if (EEMConstants.MENU_LETTER_REVIEW.equals(selectedMenu)) {

				if(eemForm instanceof EEMLetterReviewDetailForm) {
					/** Triple S BasePlus Migration START **/
					//Added for TSA changes for Member Id Label Change :Start	
					((EEMLetterReviewDetailForm) eemForm).setMbrLabel(EEMProfileSettings
							.getCalendarProfileText(eemDb, sessionHelper.getMfId(),
									"MBRIDLIT"));
					//Added for TSA changes for Member Id Label Change :End
					/** Triple S BasePlus Migration END **/
					EEMLetterReviewHelper.setFormLists((EEMLetterReviewDetailForm)eemForm);
				}
				//Begin: Added for Letter Review upload
				if ("displayLetterUploadPopUp".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return displayLetterUploadPopUp(conn, sessionHelper, context, mapping, form, request);
				}

				if ("uploadLetters".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return uploadLetters(conn, sessionHelper, context, mapping, form, request);
				}
				
				if ("uploadLetterReviewLetters".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return uploadLetterReviewLetters(conn, sessionHelper, context, mapping, form, request);
				}
				
				//End: Added for Letter Review upload

				 /*	 Begin: Added for Letter Review QC */
				if(eemForm instanceof EEMLetterReviewQCForm){
					EEMLetterReviewHelper.setFormLists((EEMLetterReviewQCForm)eemForm,sessionHelper);
				}
				/*	 End: Added for Letter Review QC */
				
				if ("letterReviewSearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReviewSearch(conn, sessionHelper, context, mapping, form, request);
				}
				if ("letterReviewSearchPageNext".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReviewSearchPage(conn, sessionHelper, context, mapping, form, request, "next");
				}
				if ("letterReviewSearchPagePrev".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReviewSearchPage(conn, sessionHelper, context, mapping, form, request, "previous");
				}
				if ("letterReviewSearchPageFirst".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReviewSearchPage(conn, sessionHelper, context, mapping, form, request, "first");
				}
				if ("letterReviewSelect".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReviewSelect(conn, sessionHelper, context, mapping, form, request);
				}

				if ("letterCorrMbrUpdate".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterCorrMbrUpdate(conn, sessionHelper, context, mapping, form, request);
				}

				if ("letterReviewSelectTab".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReviewTabSelect(conn, sessionHelper, context, mapping, form, request);
				}
				
				if ("letterReviewGenerate".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReviewGenerate(conn, sessionHelper, context, mapping, form, request);
				}

				if ("clearSearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReviewClearSearch(conn, sessionHelper, context, mapping, eemForm, request);
				}
				
				if ("displayDocFromDB".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return displayDocumentFromDB(conn, sessionHelper, context, mapping, eemForm, request, response);
				}
				//Begin: Added for Letter Review LetterQC
				if ("letterReviewQCbatchId".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReviewQCbatchId(conn, sessionHelper, context, mapping, form, request);
				}
				if ("letterReviewQCDescription".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReviewQCDescription(conn, sessionHelper, context, mapping, form, request);
				}
				if ("letterReviewQCSearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReviewQCSearch(conn, sessionHelper, context, mapping, form, request);
				}
				if ("clearQcSearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReviewQcClearSearch(conn, sessionHelper, context, mapping, eemForm, request);
				}
				if ("changeLetterStatus".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterReviewQcletterStatus(conn, sessionHelper, context, mapping, eemForm, request);
				}
				//End: Added for Letter Review LetterQC
				//IFOX-00426356: Attachment CR:start
				if(eemForm instanceof EEMLetterReviewAttachmentForm) {
					EEMLetterReviewHelper.setFormLists((EEMLetterReviewAttachmentForm)eemForm);
				}
				if ("letterAttachmentSearch".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterAttachmentSearch(conn, sessionHelper, context, mapping, form, request);
				}
				if ("letterAttachSelect".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterAttachSelect(conn, sessionHelper, context, mapping, form, request);
					
				}
				if ("uploadLetterAttachment".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return uploadLetterAttachment(conn, sessionHelper, context, mapping, form, request);
				}
				if ("letterAttachSearchPageNext".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterAttachSearchPage(conn, sessionHelper, context, mapping, form, request, "next");
				}
				if ("letterAttachSearchPagePrev".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterAttachSearchPage(conn, sessionHelper, context, mapping, form, request, "previous");
				}
				if ("letterAttachSearchPageFirst".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemLetterAttachSearchPage(conn, sessionHelper, context, mapping, form, request, "first");
				}
				//IFOX-00426356: Attachment CR:end
			} else if (EEMConstants.MENU_BILLING.equals(selectedMenu)) {

				if(eemForm instanceof EEMBillInvoiceForm) {
					EEMBillingHelper.setInvoiceFormLists((EEMBillInvoiceForm)eemForm);
				}
				else
				if(eemForm instanceof EEMBillPaymentsForm) {
					EEMBillingHelper.setPaymentsFormLists((EEMBillPaymentsForm)eemForm);
				}
				else
				if(eemForm instanceof EEMBillMembPaymentsForm) {
					EEMBillingHelper.setMembPaymentsFormLists((EEMBillMembPaymentsForm)eemForm);
				}
				else
				if(eemForm instanceof EEMBillDraftForm) {
					EEMBillingHelper.setDraftFormLists((EEMBillDraftForm)eemForm);
				}					
				
				
				String selectedTab = ((EEMSubMenuForm)eemForm).getSelectedSubMenuTab();

				if ("billingSelectTab".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemBillingTabSelect(conn, sessionHelper, context, mapping, form, request);
				}

				if (selectedTab.equals(EEMConstants.EEM_BILL_TAB_INVOICE)) {
					if ("billInvoiceSearch".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillInvoiceSearch(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billInvoiceSelect".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillInvoiceSelect(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billInvoiceSearchPageNext".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillInvoiceSearchPage(conn, sessionHelper, context, mapping, form, request, "next");
					}
					if ("billInvoiceSearchPageFirst".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillInvoiceSearchPage(conn, sessionHelper, context, mapping, form, request, "first");
					}
					if ("billInvoiceSearchPagePrev".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillInvoiceSearchPage(conn, sessionHelper, context, mapping, form, request, "previous");
					}
					if ("billInvoiceDetailSelect".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillInvoiceDetailSelect(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billInvoiceDetailPageNext".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillInvoiceDetailPage(conn, sessionHelper, context, mapping, form, request, "next");
					}
					if ("billInvoiceDetailPageFirst".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillInvoiceDetailPage(conn, sessionHelper, context, mapping, form, request, "first");
					}
					if ("billInvoiceDetailPagePrev".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillInvoiceDetailPage(conn, sessionHelper, context, mapping, form, request, "previous");
					}
					if ("billInvoiceCommentSave".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillInvoiceCommentSave(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billInvoiceDetailsUpdate".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillInvoiceDetailsUpdate(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billMbrGrpSearch".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillMbrGrpSearch(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billInvoiceTransfer".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillInvoiceTransfer(conn, eemDb, sessionHelper, context, mapping, form, request);
					}
				}
				
				if (selectedTab.equals(EEMConstants.EEM_BILL_TAB_DRAFT)) {
					if ("billDraftSearch".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillDraftSearch(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billDraftSelect".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillDraftSelect(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billDraftSearchPageNext".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillDraftSearchPage(conn, sessionHelper, context, mapping, form, request, "next");
					}
					if ("billDraftSearchPageFirst".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillDraftSearchPage(conn, sessionHelper, context, mapping, form, request, "first");
					}
					if ("billDraftSearchPagePrev".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillDraftSearchPage(conn, sessionHelper, context, mapping, form, request, "previous");
					}
					if ("billDraftDetailSelect".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillDraftDetailSelect(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billDraftDetailPageNext".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillDraftDetailPage(conn, sessionHelper, context, mapping, form, request, "next");
					}
					if ("billDraftDetailPageFirst".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillDraftDetailPage(conn, sessionHelper, context, mapping, form, request, "first");
					}
					if ("billDraftDetailPagePrev".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillDraftDetailPage(conn, sessionHelper, context, mapping, form, request, "previous");
					}
					if ("billDraftCommentSave".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillDraftCommentSave(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billDraftDetailsUpdate".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillDraftDetailsUpdate(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billDraftDetailsInsert".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillDraftDetailsInsert(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billDraftDetailsInsertForMember".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillDraftDetailsInsertForMember(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billDraftGetMemberDetails".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillDraftGetMemberDetails(conn, sessionHelper, context, mapping, form, request);
					}
				}				
				
				if (selectedTab.equals(EEMConstants.EEM_BILL_TAB_PAYMENTS)) {
					
					//TSA -CR-00383227-Begin
					if ("billPaymentsDetailPageSearch".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return billPaymentsSubSearch(conn, sessionHelper, context, mapping, form, request);
					}
					//TSA -CR-00383227-End
					
					if ("billPaymentsSearch".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillPaymentsSearch(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billPaymentsSelect".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillPaymentsSelect(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billPaymentsSearchPageNext".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillPaymentsSearchPage(conn, sessionHelper, context, mapping, form, request, "next");
					}
					if ("billPaymentsSearchPageFirst".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillPaymentsSearchPage(conn, sessionHelper, context, mapping, form, request, "first");
					}
					if ("billPaymentsSearchPagePrev".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillPaymentsSearchPage(conn, sessionHelper, context, mapping, form, request, "previous");
					}
					if ("billPaymentsDetailSelect".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillPaymentsDetailSelect(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billPaymentsDetailPageNext".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillPaymentsDetailPage(conn, sessionHelper, context, mapping, form, request, "next");
					}
					if ("billPaymentsDetailPageFirst".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillPaymentsDetailPage(conn, sessionHelper, context, mapping, form, request, "first");
					}
					if ("billPaymentsDetailPagePrev".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillPaymentsDetailPage(conn, sessionHelper, context, mapping, form, request, "previous");
					}
					if ("billPaymentHeaderDetailsUpdate".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillPaymentHeaderDetailsUpdate(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billPaymentDetailsUpdate".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillPaymentDetailsUpdate(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billPaymentNew".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillPaymentNew(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billPaymentAddDetails".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillPaymentAddDetails(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billPaymentCancel".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillPaymentCancel(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billPaymentNewUpdate".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillPaymentNewUpdate(conn, sessionHelper, context, mapping, form, request);
					}
				}
				if (selectedTab.equals(EEMConstants.EEM_BILL_TAB_MEMBER_PAYMENTS)) {
					if ("billMembPaymentsSearch".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillMembPaymentsSearch(conn, sessionHelper, context, mapping, form, request);
					}
					if ("billMembPaymentsPageNext".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillMembPaymentsSearchPage(conn, sessionHelper, context, mapping, form, request, "next");
					}
					if ("billMembPaymentsPageFirst".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillMembPaymentsSearchPage(conn, sessionHelper, context, mapping, form, request, "first");
					}
					if ("billMembPaymentsPagePrev".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillMembPaymentsSearchPage(conn, sessionHelper, context, mapping, form, request, "previous");
					}
					if ("billMembPaymentUpdate".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemBillMembPaymentUpdate(conn, sessionHelper, context, mapping, form, request);
					}
				}
			} else if (EEMConstants.MENU_DASHBOARD.equals(selectedMenu)) {
				if ("drill".equals(method)) {
					context.setSelectedMenu(EEMConstants.MENU_APPL);
					logger.info(LoggerConstants.methodEndLevel());
					return eemApplNewMemberMA(conn, sessionHelper, context, mapping, form, request);
				}
			}
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward("eemError");

		} catch(Exception e) {
			//logger.error("Exception : " + e.getMessage());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace(log.getStream());
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
				//e.printStackTrace(log.getStream());
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				//logger.error("Exception : " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward("eemError");
	}
	
	//original application start

	private ActionForward eemApplOriginal(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		//System.out.println("original application");
		// Get the form
		EEMApplForm eemFormAppl = (EEMApplForm) form;
		EEMOriginalApplicationVO formVO = new EEMOriginalApplicationVO();
		EEMApplicationVO filterVO = new EEMApplicationVO();
		EEMApplHelper.setFormToVO(eemFormAppl, filterVO, sessionHelper);
		EEMApplService service = context.getService();

		filterVO.setCustomerId(sessionHelper.getMfId());
		filterVO.setApplId(eemFormAppl.getApplId());
		filterVO.setCustomerNbr(sessionHelper.getCustomerNumber());
		formVO.setCustomerId(sessionHelper.getMfId());
		formVO.setApplId(eemFormAppl.getApplId());
		formVO.setCustomerNbr(sessionHelper.getCustomerNumber());
		//System.out.println("original application service");
		formVO = service.getApplOriginal(conn, filterVO);
		//System.out.println("original application seting button");
		eemFormAppl.setOriginalButton(1);
		//System.out.println("original application helper");
		EEMApplHelper.setOrigVOToForm(formVO, eemFormAppl, sessionHelper);
		//orignal application start
		//eemFormAppl.setNtlProviderId("");
		//eemFormAppl.setNetworkCode("");
		//eemFormAppl.setPracticeName("");
		//original application end
		eemFormAppl.setUpdateRec("Y");
		List lstSearch = (List) sessionHelper
				.getAttribute(EEMConstants.SESSION_APPL_SEARCH);
		if(lstSearch!=null){
		if(lstSearch.size()>0){
			for (int i = 0; i < lstSearch.size(); i++) {
			EEMApplicationVO objVO = (EEMApplicationVO) lstSearch.get(i);
			if (objVO.getApplId().equals(eemFormAppl.getApplId())) {
				objVO.setRowSelected("Y");
			} else {
				objVO.setRowSelected("N");
			}
		}
		eemFormAppl.setLstSearch(lstSearch);
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_APPL_SEARCH, lstSearch);
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_APPL_ERRORS, eemFormAppl.getLstErrors());
		// Set Application Status
		EEMApplHelper.setApplicationStatus(eemFormAppl, sessionHelper);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_APPL_SEARCH, null);
		eemFormAppl.setApplType("");
		context.setOptAppl(null);
		eemFormAppl.setApplType("");
		eemFormAppl.setVisible("Y");
		EEMApplHelper.setApplFormList(eemFormAppl, sessionHelper);
		EEMApplHelper.postPhoneOrder(eemFormAppl);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMApplHelper.getPage(eemFormAppl));
		}
		}
		EEMApplHelper.postPhoneOrder(eemFormAppl);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMApplHelper.getPage(eemFormAppl));
		
		
	}
//original application end
	private ActionForward initializeEEM(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		context.setOptAppl(null);
		context.setEnrollVO(null);
		/** Triple S BasePlus Migration START **/
		HttpSession session =request.getSession(false);
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		String achInd = EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),"ACHIND");
		session.setAttribute("ACHIND", achInd);
		
		/** Getting BYPASSDATE filed from profile for Bypass the START and END Date validation **/
		String byPassCOBDate = EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),"BYPASSDATE");
		session.setAttribute("BYPASSCOBDATE", StringUtil.nonNullTrim(byPassCOBDate));
		/** Getting BYPASSRXVD validation filed from profile for bypass the RX field validation**/
		
		/* Fix for IFOX-00378075 -- START*/
		EEMApplDao eemApplDao = new EEMApplDao();
		String medicaidparamCode = eemApplDao.getMedicaidProfileValue(conn,sessionHelper.getMfId());
		sessionHelper.setAttribute("MEDIINDVALUE", medicaidparamCode);
		/* Fix for IFOX-00378075 -- END*/
		
		//Added for TSA changes for Member Id Label Change :Start
		String memberLabel = EEMProfileSettings.getCalendarProfileText(eemDb, sessionHelper.getMfId(), "MBRIDLIT");
		session.setAttribute("MBRIDLIT", memberLabel);
		//Added for TSA changes for Member Id Label Change :End
		
		// Added for TSA changes for Suppressing 75 TXN :Start
		String suppTxn = EEMProfileSettings.getCalendarProfileText(eemDb, sessionHelper.getMfId(), "SUPPTXN");
		session.setAttribute("SUPPTXN", suppTxn);
		// Added for TSA changes for Suppressing 75 TXN :End
		
		// Added for TSA changes, to enable Question Snippet for MA- Contract Chg Form :Start
		String enableQuest = EEMProfileSettings.getCalendarProfileText(eemDb, sessionHelper.getMfId(), "ENBQUEST");
		session.setAttribute("ENBQUEST", enableQuest);
		session.setAttribute("ENBQUESTVAL", enableQuest);
		// Added for TSA changes, to enable Question Snippet for MA- Contract Chg Form :End
		
		// Added for TSA changes, to Trigger 73 TXN: Start
		String trigger73 = EEMProfileSettings.getCalendarProfileText(eemDb, sessionHelper.getMfId(), "TC73TRIG");
		session.setAttribute("TC73TRIG", trigger73);
		// Added for TSA changes, to Trigger 73 TXN: End

		// TSA : Spanish Language Change :start
		String corrLabel = EEMProfileSettings.getCalendarProfileText(eemDb, sessionHelper.getMfId(), "DCORRLANG");
		session.setAttribute("CORRLANG", corrLabel);
		sessionHelper.setAttribute("CORRLANG", corrLabel);
		// TSA : Spanish Language Change :end
		
		// TSA : COB Type Change :start
		String cobType = EEMProfileSettings.getCalendarProfileText(eemDb, sessionHelper.getMfId(), "COBPRIM");
		session.setAttribute("COBPRIM", cobType);
		sessionHelper.setAttribute("COBPRIM", cobType);
		// TSA : COB Type Change :end
		
		// TSA :Address Date Validation Change :start
		String addrValid = EEMProfileSettings.getCalendarProfileText(eemDb, sessionHelper.getMfId(), "ADRVAL");
		session.setAttribute("ADRVAL", addrValid);
		sessionHelper.setAttribute("ADRVAL", addrValid);
		// TSA : Address Date Validation :end
		
		// TSA :COB Date Validation Change : START
		String cobValid = EEMProfileSettings.getCalendarProfileText(eemDb, sessionHelper.getMfId(), "COBVAL");
		logger.debug("COBVAL :"+cobValid);				
		session.setAttribute("COBVAL", cobValid);
		sessionHelper.setAttribute("COBVAL", cobValid);
		// TSA :COB Date Validation Change
		//IFOX-00354933-START
		
		// Triple-S Specific Fields Retrieval Issue Fix - Start
		String campIndInd = EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(), "CAMPIDIND");
		//System.out.println("CAMPIDIND :" + campIndInd);
		session.setAttribute("CAMPIDIND", campIndInd);
		sessionHelper.setAttribute("CAMPIDIND", campIndInd);
		
		String contractNoInd = EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(), "CONTRNOIND");
		//System.out.println("CONTRNOIND :" + contractNoInd);
		session.setAttribute("CONTRNOIND", contractNoInd);
		sessionHelper.setAttribute("CONTRNOIND", contractNoInd);
		//IFOX-00354933-END
		// Triple-S Specific Fields Retrieval Issue Fix - Start
		//Raj, confirmed Draft Day and Bank Name fields should be enable for all baseplus customers.
		/*//Draft day changes on Billing START
		String draftDayInd = EEMProfileSettings.getCalendarProfileText(eemDb, sessionHelper.getMfId(), EEMConstants.EEM_APPL_DRFT_DAY_IND);
		session.setAttribute(EEMConstants.EEM_APPL_DRFT_DAY_IND, draftDayInd);
		sessionHelper.setAttribute(EEMConstants.EEM_APPL_DRFT_DAY_IND, draftDayInd);
		//Draft day changes on Billing END 
		//Bank Name changes on Billing START
		String bankNameInd = EEMProfileSettings.getCalendarProfileText(eemDb, sessionHelper.getMfId(), EEMConstants.EEM_APPL_BANK_NAME_IND);
		session.setAttribute(EEMConstants.EEM_APPL_BANK_NAME_IND, bankNameInd);
		sessionHelper.setAttribute(EEMConstants.EEM_APPL_BANK_NAME_IND, bankNameInd);
		//Bank Name changes on Billing END 
*/		//Enable Appl CMA Emergency Section START
		String applCMAEmergInd = EEMProfileSettings.getCalendarProfileText(eemDb, sessionHelper.getMfId(), EEMConstants.EEM_APPL_CMA_EMERG_IND);
		session.setAttribute(EEMConstants.EEM_APPL_CMA_EMERG_IND, applCMAEmergInd);
		sessionHelper.setAttribute(EEMConstants.EEM_APPL_CMA_EMERG_IND, applCMAEmergInd);
		//Enable Appl CMA Emergency Section END
		
		/**AAH BasePlus Migration IFOX-00426351 START*/
		/** IFOX-00425298 Enable Question Section for CMA Appl. AAH START*/
		String enableApplQuestForCMAInd = EEMProfileSettings
				.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),
						EEMProfileSettings.ENABLE_CMA_QUESTIONS);
		logger.debug(" Value of ENBCMAQUES ::: "+enableApplQuestForCMAInd);
		session.setAttribute(EEMProfileSettings.ENABLE_CMA_QUESTIONS, enableApplQuestForCMAInd);
		/** IFOX-00425298 Enable Question Section for CMA Appl. AAH START*/
		/**AAH BasePlus Migration IFOX-00426351 END*/
		
		/* AAH CR-Start -426569 */
		String autoPopApplDate = EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),EEMProfileSettings.AUTO_POPULTATE_APPLDT);
		session.setAttribute(EEMProfileSettings.AUTO_POPULTATE_APPLDT, autoPopApplDate);
		String validateSignAgent = EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),EEMProfileSettings.VALIDATE_SIGN_AGENT);
		session.setAttribute(EEMProfileSettings.VALIDATE_SIGN_AGENT, validateSignAgent);
		/* AAH CR-end -426569 */
		
		//00414932 :Start
			String suppIdProfile = EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(), EEMProfileSettings.SUPPLID);
			String suppFix = EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(), EEMProfileSettings.SUPPFIX);
			session.setAttribute(EEMProfileSettings.SUPPFIX, suppFix);
			session.setAttribute(EEMProfileSettings.SUPPLID, suppIdProfile);
		//00414932 :End	
	

		/**  Triple S BasePlus Migration END **/
		sessionHelper.removeAttribute("SaveEEMApplForm");
		
		sessionHelper.removeAttribute("SaveEEMBillInvoiceForm");
		
		sessionHelper.removeAttribute("SaveEEMBillDraftForm");
		
		sessionHelper.removeAttribute("SaveEEMBillPaymentForm");
		sessionHelper.removeAttribute("SaveEEMBillMembPaymentForm");
		
		sessionHelper.removeAttribute("SaveEEMEnrollForm");
		
		sessionHelper.removeAttribute("SaveEEMLetterReqForm");
		sessionHelper.removeAttribute("SaveEEMLetterReviewDetailForm");
		
		sessionHelper.removeAttribute(EEMConstants.SESSION_APPL_SEARCH);
		sessionHelper.removeAttribute(EEMConstants.SESSION_APPL_ERRORS);
		
		if (EEMHelper.hasAppService(sessionHelper)) {
			logger.info(LoggerConstants.methodEndLevel());
			return eemApplMenu(conn, sessionHelper, context, mapping, form, request);
		}
		if (EEMHelper.hasMbrService(sessionHelper)) {
			logger.info(LoggerConstants.methodEndLevel());
			return eemEnrollmentMenu(conn, sessionHelper, context, mapping, form, request);
		}
		
		if (EEMHelper.hasBilService(sessionHelper)) {
			logger.info(LoggerConstants.methodEndLevel());
			return eemBillingMenu(conn, sessionHelper, context, mapping, form, request);
		}
		
		if (EEMHelper.hasLtrService(sessionHelper)) {
			logger.info(LoggerConstants.methodEndLevel());
			return eemLetterReqMenu(conn, sessionHelper, context, mapping, form, request);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward("eemEmpty");
	}
	
	private ActionForward eemEligibility(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		context.setSelectedMenu(EEMConstants.MENU_ELIGIBILITY);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_ELIGIBILITY);
	}

	private ActionForward eemAppl(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		context.setSelectedMenu(EEMConstants.MENU_APPL);
		context.setOptAppl(null);
		// Check for the submitted form instance
		if (!(form instanceof EEMApplForm)) {
			EEMApplForm eemApplForm = new EEMApplForm();
			eemApplForm.setVisible("N");
			request.setAttribute(EEMConstants.EEM_APPL_FORM, eemApplForm);
		}
		
		EEMApplForm eemApplForm = (EEMApplForm)request.getAttribute(EEMConstants.EEM_APPL_FORM);
		eemApplForm.setApplType("");
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		
		try {
			eemApplForm.setIsSubscriberIdRequired(EEMProfileSettings
					.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),
							"SUBSCID"));
			/** Triple S BasePlus Migration START **/
			// TSA Changes :Start
						eemApplForm.setIsSubscriberIdMandatory(EEMProfileSettings
								.getCalendarProfileText(eemDb, sessionHelper.getMfId(),
										"SUBSCID"));
			//TSA Changes :End
			/** Triple S BasePlus Migration END **/
						
		} catch (Exception e) {
		
		}
		
		EEMApplHelper.setApplFormList(eemApplForm, sessionHelper);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_APPL);
	}

	public ActionForward eemApplMenu(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplForm eemApplForm = null;
		context.setSelectedMenu(EEMConstants.MENU_APPL);
		if (!(form instanceof EEMApplForm)) {
			
			eemApplForm = EEMApplHelper.getEEMForm(sessionHelper);
			if (eemApplForm == null) {
				eemApplForm = new EEMApplForm();
				eemApplForm.setVisible("N");
				eemApplForm.setApplType("");
			}

			request.setAttribute(EEMConstants.EEM_APPL_FORM, eemApplForm);
		} else {
			eemApplForm = (EEMApplForm)form;
		}
		EEMApplHelper.setCommentList(eemApplForm);
		EEMApplHelper.setApplFormList(eemApplForm, sessionHelper);
		EEMApplHelper.loadLookUps(conn,eemApplForm,sessionHelper);	
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMApplHelper.getPage(eemApplForm));
	}

	private ActionForward eemApplCancel(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplForm eemApplForm = null;
		context.setSelectedMenu(EEMConstants.MENU_APPL);
		if (!(form instanceof EEMApplForm)) {
			
			eemApplForm = EEMApplHelper.getEEMForm(sessionHelper);
			if (eemApplForm == null) {
				eemApplForm = new EEMApplForm();
				eemApplForm.setVisible("N");
				eemApplForm.setApplType("");
			}
			request.setAttribute(EEMConstants.EEM_APPL_FORM, eemApplForm);
		} else {
			eemApplForm = (EEMApplForm)form;
		}
		EEMApplHelper.setApplFormList(eemApplForm, sessionHelper);
		EEMApplHelper.loadLookUps(conn,eemApplForm,sessionHelper);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMApplHelper.getPage(eemApplForm));
	}

	private ActionForward eemEnrollmentMenu(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		context.setSelectedMenu(EEMConstants.MENU_ENROLLMENT);
		if (!(form instanceof EEMEnrollForm)) {
			
			EEMEnrollForm eemEnrollForm = EEMEnrollHelper.getEEMForm(sessionHelper);
			if (eemEnrollForm == null) {
				eemEnrollForm = new EEMEnrollForm();
				eemEnrollForm.setSelectedMemberTab("");
				eemEnrollForm.setTabPageMove("");
			}
			EEMEnrollVO enrollVO = context.getEnrollVO();
			enrollVO.setMessage("");
			EEMEnrollHelper.setEnrollFormList(eemEnrollForm, sessionHelper.getSession());
			EEMEnrollHelper.copyVOToForm(enrollVO,eemEnrollForm);
			EEMEnrollHelper.setDisplayItems(enrollVO,eemEnrollForm);
			EEMEnrollManager.setAgentsLookUp(conn, sessionHelper, eemEnrollForm);
			request.setAttribute(EEMConstants.EEM_ENROLL_FORM, eemEnrollForm);
		}	
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_ENROLLMENT);
	}

	private ActionForward eemEnrollClearSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollVO enrollVO = context.getEnrollVO();
		EEMEnrollHelper.clearContextDisplay(enrollVO);
		
		enrollVO.setMessage("");
		enrollVO.setMfId("");
		enrollVO.setSearchMemberId("");
		enrollVO.setSearchHicNo("");
		enrollVO.setSearchSSN("");
		enrollVO.setSearchSupplementalId("");
		enrollVO.setSearchLastName("");
		//IFOX-00424860 - New member search fields :start
		enrollVO.setSearchFirstName("");
		enrollVO.setSearchDob("");
		//IFOX-00424860 - New member search fields :end
		enrollVO.setSearchEffectiveMonth("");
		enrollVO.setSearchShowAll("");
				
		EEMEnrollForm eemEnrollForm = (EEMEnrollForm)form;
		eemEnrollForm.setMessage("");
		eemEnrollForm.setSearchMemberId("");
		eemEnrollForm.setSearchHicNo("");
		eemEnrollForm.setSearchSSN("");
		eemEnrollForm.setSearchSupplementalId("");
		eemEnrollForm.setSearchLastName("");
		//IFOX-00424860 - New member search fields :start
		eemEnrollForm.setSearchFirstName("");
		eemEnrollForm.setSearchDob("");
		//IFOX-00424860 - New member search fields :end
		eemEnrollForm.setSearchEffectiveMonth("");
		eemEnrollForm.setSearchShowAll("");
		eemEnrollForm.setSearchExpanded(false);
		
		EEMEnrollHelper.clearFormDisplay(eemEnrollForm);
		EEMEnrollHelper.setEnrollFormList(eemEnrollForm, sessionHelper.getSession());
		//EEMEnrollHelper.copyVOToForm(enrollVO,eemEnrollForm);
		//EEMEnrollHelper.setDisplayItems(enrollVO,eemEnrollForm);
		
		eemEnrollForm.setFocusField("eemEnrollForm.searchMemberId");
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_ENROLLMENT);
	}

	public ActionForward eemEnrollSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		long startTime = System.currentTimeMillis();
		EEMEnrollManager mgr = new EEMEnrollManager();
		// SSNRI 2017 -Determining whether the searched hic number is MBI or HiCN :start
		String medicaidID = ((EEMEnrollForm)form).getSearchHicNo();
		String flag = "";
		if(!StringUtil.nonNullTrim(medicaidID).equals(""))
			 flag = isHicOrMbi(medicaidID);
		
		mgr.memberSearch(conn,sessionHelper,context,(EEMEnrollForm)form,flag);
		// SSNRI 2017 -Determining whether the searched hic number is MBI or HiCN :end 
		/**
		 * Cambia_OEVProcess-Start
		 */
		EEMEnrollForm eemForm = (EEMEnrollForm)form;
		if(eemForm.getOevCallAttempts()==null){
			//System.out.println(" in action Oev list is null");
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH1, null);
		}
		else{
		//	System.out.println(" oevCal size"+filterVO.getOevCallAttempts());
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH1, eemForm.getOevCallAttempts());
		}
		if(eemForm.getOevCallStatus()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH2, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH2, eemForm.getOevCallStatus());
		}
		if(eemForm.getOevCallStatusSaved()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH3, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH3,eemForm.getOevCallStatusSaved());
		}
		if(eemForm.getOevRetStatus()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH4, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH4,eemForm.getOevRetStatus());
		}
		if(eemForm.getOevRetStatusSaved()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH5, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH5,eemForm.getOevRetStatusSaved());
		}
		if(eemForm.getOevRetStatus()==null){
			//System.out.println(" in action Oev list is null");
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH6, null);
		}
		else{
			//System.out.println(" oevCal size"+filterVO.getOevRetStatus());
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH6, eemForm.getReturnCalls());
		}
		/**
		 * Cambia_OEVProcess-End
		 */
		logger.info(LoggerConstants.methodEndLevel());
		long endTime = System.currentTimeMillis();
		replogger.debug("M360|Member Search|"+sessionHelper.getMfId()+"|"+(endTime - startTime)+" ms|");
		return mapping.findForward(EEMConstants.EEM_ENROLLMENT);
	}

	private ActionForward eemEnrollSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request, String move) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollManager mgr = new EEMEnrollManager();
		// SSNRI 2017 -Determining whether the searched hic number is MBI or HiCN :start
				String medicaidID = ((EEMEnrollForm)form).getSearchHicNo();
				String flag = "";
				if(!StringUtil.nonNullTrim(medicaidID).equals(""))
					 flag = isHicOrMbi(medicaidID);
				
				// SSNRI 2017 -Determining whether the searched hic number is MBI or HiCN :end 
		mgr.memberSearchPage(conn,sessionHelper,context,(EEMEnrollForm)form,move,flag);
		/**
		 * Cambia_OEVProcess-Start
		 */
		EEMEnrollForm eemForm = (EEMEnrollForm)form;
		if(eemForm.getOevCallAttempts()==null){
			//System.out.println(" in action Oev list is null");
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH1, null);
		}
		else{
		//	System.out.println(" oevCal size"+filterVO.getOevCallAttempts());
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH1, eemForm.getOevCallAttempts());
		}
		if(eemForm.getOevCallStatus()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH2, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH2, eemForm.getOevCallStatus());
		}
		if(eemForm.getOevCallStatusSaved()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH3, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH3,eemForm.getOevCallStatusSaved());
		}
		if(eemForm.getOevRetStatus()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH4, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH4,eemForm.getOevRetStatus());
		}
		if(eemForm.getOevRetStatusSaved()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH5, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH5,eemForm.getOevRetStatusSaved());
		}
		if(eemForm.getOevRetStatus()==null){
			//System.out.println(" in action Oev list is null");
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH6, null);
		}
		else{
			//System.out.println(" oevCal size"+filterVO.getOevRetStatus());
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH6, eemForm.getReturnCalls());
		}
		/**
		 * Cambia_OEVProcess-End
		 */
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_ENROLLMENT);
	}

	private ActionForward eemEnrollSearchSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollManager mgr = new EEMEnrollManager();
		mgr.memberSelect(conn,sessionHelper,context,(EEMEnrollForm)form);
		/**
		 * Cambia_OEVProcess-Start
		 */
		EEMEnrollForm eemForm = (EEMEnrollForm)form;
		if(eemForm.getOevCallAttempts()==null){
			//System.out.println(" in action Oev list is null");
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH1, null);
		}
		else{
		//	System.out.println(" oevCal size"+filterVO.getOevCallAttempts());
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH1, eemForm.getOevCallAttempts());
		}
		if(eemForm.getOevCallStatus()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH2, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH2, eemForm.getOevCallStatus());
		}
		if(eemForm.getOevCallStatusSaved()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH3, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH3,eemForm.getOevCallStatusSaved());
		}
		if(eemForm.getOevRetStatus()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH4, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH4,eemForm.getOevRetStatus());
		}
		if(eemForm.getOevRetStatusSaved()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH5, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH5,eemForm.getOevRetStatusSaved());
		}
		if(eemForm.getOevRetStatus()==null){
			//System.out.println(" in action Oev list is null");
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH6, null);
		}
		else{
			//System.out.println(" oevCal size"+filterVO.getOevRetStatus());
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH6, eemForm.getReturnCalls());
		}
		/**
		 * Cambia_OEVProcess-End
		 */
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_ENROLLMENT);
	}

	private ActionForward eemEnrollUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		long startTime = System.currentTimeMillis();
		
		EEMEnrollManager mgr = new EEMEnrollManager();
		mgr.memberUpdate(conn,sessionHelper,context,(EEMEnrollForm)form);
		/**
		 * Cambia_OEVProcess-Start
		 */
		EEMEnrollForm eemForm = (EEMEnrollForm)form;
		if(eemForm.getOevCallAttempts()==null){
			//System.out.println(" in action Oev list is null");
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH1, null);
		}
		else{
		//	System.out.println(" oevCal size"+filterVO.getOevCallAttempts());
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH1, eemForm.getOevCallAttempts());
		}
		if(eemForm.getOevCallStatus()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH2, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH2, eemForm.getOevCallStatus());
		}
		if(eemForm.getOevCallStatusSaved()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH3, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH3,eemForm.getOevCallStatusSaved());
		}
		if(eemForm.getOevRetStatus()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH4, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH4,eemForm.getOevRetStatus());
		}
		if(eemForm.getOevRetStatusSaved()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH5, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH5,eemForm.getOevRetStatusSaved());
		}
		if(eemForm.getOevRetStatus()==null){
			//System.out.println(" in action Oev list is null");
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH6, null);
		}
		else{
			//System.out.println(" oevCal size"+filterVO.getOevRetStatus());
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH6, eemForm.getReturnCalls());
		}
		/**
		 * Cambia_OEVProcess-End
		 */
		EEMEnrollManager.setAgentsLookUp(conn, sessionHelper, (EEMEnrollForm)form);
		long endTime = System.currentTimeMillis();
		System.out.println("Time: " + (endTime - startTime) + "milliseconds");
		replogger.debug("M360|Member Update|"+sessionHelper.getMfId()+"|"+(endTime - startTime)+" ms|");
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_ENROLLMENT);
	}

	private ActionForward eemEnrollDelete(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollManager mgr = new EEMEnrollManager();
		mgr.memberDelete(conn,sessionHelper,context,(EEMEnrollForm)form);
		/**
		 * Cambia_OEVProcess-Start
		 */
		EEMEnrollForm eemForm = (EEMEnrollForm)form;
		if(eemForm.getOevCallAttempts()==null){
			//System.out.println(" in action Oev list is null");
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH1, null);
		}
		else{
		//	System.out.println(" oevCal size"+filterVO.getOevCallAttempts());
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH1, eemForm.getOevCallAttempts());
		}
		if(eemForm.getOevCallStatus()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH2, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH2, eemForm.getOevCallStatus());
		}
		if(eemForm.getOevCallStatusSaved()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH3, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH3,eemForm.getOevCallStatusSaved());
		}
		if(eemForm.getOevRetStatus()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH4, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH4,eemForm.getOevRetStatus());
		}
		if(eemForm.getOevRetStatusSaved()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH5, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH5,eemForm.getOevRetStatusSaved());
		}
		if(eemForm.getOevRetStatus()==null){
			//System.out.println(" in action Oev list is null");
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH6, null);
		}
		else{
			//System.out.println(" oevCal size"+filterVO.getOevRetStatus());
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH6, eemForm.getReturnCalls());
		}
		/**
		 * Cambia_OEVProcess-End
		 */
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_ENROLLMENT);
	}

	private ActionForward eemEnrollLetterSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollManager mgr = new EEMEnrollManager();
		mgr.memberLetterSelect(conn,sessionHelper,context,(EEMEnrollForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_ENROLLMENT);
	}

	private ActionForward eemEnrollTabPage(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollForm eemEnrollForm = (EEMEnrollForm)form;
		
		String selectedTab = eemEnrollForm.getSelectedMemberTab();
		String move = eemEnrollForm.getTabPageMove();
		
		EEMEnrollManager mgr = new EEMEnrollManager();
		if ("enrollment".equals(selectedTab))
			mgr.memberEnrollmentTabPage(conn,sessionHelper,context,eemEnrollForm,move);
		else
		if ("dsinfo".equals(selectedTab))
			mgr.memberDsInfoTabPage(conn,sessionHelper,context,eemEnrollForm,move);
		else
		if ("trrlogs".equals(selectedTab))
			mgr.memberTrrTabPage(conn,sessionHelper,context,eemEnrollForm,move);
		else
		if ("comments".equals(selectedTab))
			mgr.memberCommentTabPage(conn,sessionHelper,context,eemEnrollForm,move);
		else
		if ("pcpinfo".equals(selectedTab))
			mgr.memberPcpTabPage(conn,sessionHelper,context,eemEnrollForm,move);
		else
		if ("letters".equals(selectedTab))
			mgr.memberLetterTabPage(conn,sessionHelper,context,eemEnrollForm,move);
		else
		if ("address".equals(selectedTab))
			mgr.memberAddressTabPage(conn,sessionHelper,context,eemEnrollForm,move);
		else
		if ("lepinfo".equals(selectedTab))
			mgr.memberLepInfoTabPage(conn,sessionHelper,context,eemEnrollForm,move);
		else
		if ("lisinfo".equals(selectedTab))
			mgr.memberLisInfoTabPage(conn,sessionHelper,context,eemEnrollForm,move);
		else
		if ("agent".equals(selectedTab))
			mgr.memberAgentsTabPage(conn,sessionHelper,context,eemEnrollForm,move);
		else
		if ("cob".equals(selectedTab))
			mgr.memberCobTabPage(conn,sessionHelper,context,eemEnrollForm,move);
		else
		if ("billing".equals(selectedTab))
			mgr.memberBillingTabPage(conn,sessionHelper,context,eemEnrollForm,move);
		/**
		 * 033_Highmark_SUC_OOASCCprocess - Start
		 */
		else if ("ooa".equals(selectedTab))

			mgr.memberOoaTabPage(conn, sessionHelper, context,
					eemEnrollForm, move);
		/**
		 * 033_Highmark_SUC_OOASCCprocess - End
		 */
		/**
		 * 020_Highmark_SUC_UI_v1.03 (Accretion) - Start
		 */
		else if ("accret".equals(selectedTab))

			mgr.memberAccretionTabPage(conn, sessionHelper, context,
					eemEnrollForm, move);
		
		/**
		 * 020_Highmark_SUC_UI_v1.03 (Accretion) - End
		 */
		
		/**
		 * cambia pos start
		 * 
		 */
		else if ("pos".equals(selectedTab))

			mgr.memberPosInfoTabPage(conn, sessionHelper, context,
					eemEnrollForm, move);
		
		/**
		 * 020_Highmark_SUC_UI_v1.03 (Accretion) - End
		 */
		/**
		 * cambia pos end
		 * 
		 */
		/** Triple S BasePlus Migration START **/
		//ASES CR For TripleS -Start
		else if ("ases".equals(selectedTab))
				mgr.memberAsesTabPage(conn,sessionHelper,context,eemEnrollForm,move);
		//ASES CR For TripleS -End
		/** Triple S BasePlus Migration END **/	
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_ENROLLMENT);
	}

	private ActionForward eemEnrollShowAll(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollManager mgr = new EEMEnrollManager();
		mgr.memberReSelect(conn,sessionHelper,context,(EEMEnrollForm)form);
		/**
		 * Cambia_OEVProcess-Start
		 */
		EEMEnrollForm eemForm = (EEMEnrollForm)form;
		if(eemForm.getOevCallAttempts()==null){
			//System.out.println(" in action Oev list is null");
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH1, null);
		}
		else{
		//	System.out.println(" oevCal size"+filterVO.getOevCallAttempts());
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH1, eemForm.getOevCallAttempts());
		}
		if(eemForm.getOevCallStatus()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH2, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH2, eemForm.getOevCallStatus());
		}
		if(eemForm.getOevCallStatusSaved()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH3, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH3,eemForm.getOevCallStatusSaved());
		}
		if(eemForm.getOevRetStatus()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH4, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH4,eemForm.getOevRetStatus());
		}
		if(eemForm.getOevRetStatusSaved()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH5, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH5,eemForm.getOevRetStatusSaved());
		}
		if(eemForm.getOevRetStatus()==null){
			//System.out.println(" in action Oev list is null");
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH6, null);
		}
		else{
			//System.out.println(" oevCal size"+filterVO.getOevRetStatus());
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH6, eemForm.getReturnCalls());
		}
		/**
		 * Cambia_OEVProcess-End
		 */
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_ENROLLMENT);
	}
		//New LEP changes - Start
		private ActionForward eemEnrollPotentialShowAll(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
			logger.info(LoggerConstants.methodStartLevel());
			
			EEMEnrollManager mgr = new EEMEnrollManager();
			mgr.enrollPotentialShowAll(conn,sessionHelper,context,(EEMEnrollForm)form);
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.EEM_ENROLLMENT);
		}

			private ActionForward eemEnrollCcfShowAll(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
				logger.info(LoggerConstants.methodStartLevel());
				
				EEMEnrollManager mgr = new EEMEnrollManager();
				mgr.EnrollCcfShowAll(conn,sessionHelper,context,(EEMEnrollForm)form);
				logger.info(LoggerConstants.methodEndLevel());
				return mapping.findForward(EEMConstants.EEM_ENROLLMENT);
			}
		//New LEP changes - End
	/*private ActionForward eemSupvsrApproval(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		
		context.setSelectedMenu(EEMConstants.MENU_APPROVALS);

		EEMSupvsrForm eemSupvsrForm = null;
		if (!(form instanceof EEMSupvsrForm)) {
			
			eemSupvsrForm = EEMSupvsrHelper.getEEMForm(sessionHelper);
			if (eemSupvsrForm == null) {
				eemSupvsrForm = new EEMSupvsrForm();
				// Default search to Ready Approval status
				eemSupvsrForm.setCustomerId(sessionHelper.getMfId());
				eemSupvsrForm.setSearchApplStatus(EEMConstants.APPL_STATUS_READYAPPR);
				eemSupvsrSearch(conn, sessionHelper, context, mapping, eemSupvsrForm, request);
			}

			request.setAttribute(EEMConstants.EEM_SUPVSR_FORM, eemSupvsrForm);
			
		} else {
			eemSupvsrForm = (EEMSupvsrForm)form;
		}
		EEMSupvsrHelper.setSupvsrFormList(eemSupvsrForm, sessionHelper);

		return mapping.findForward(EEMConstants.EEM_APPROVALS);
	}

	private ActionForward eemGroupSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		
		context.setSelectedMenu(EEMConstants.MENU_GROUP);
		String selectedTab = context.getOptGrpSvc();
		if (selectedTab == null) {
			selectedTab = EEMConstants.OPTION_GROUPSEM;
			context.setOptGrpSvc(EEMConstants.OPTION_GROUPSEM);
		}
		EEMGroupForm eemGroupForm = null;
		if (!(form instanceof EEMGroupForm)) {
			eemGroupForm = EEMGroupHelper.getEEMForm(sessionHelper);
			if (eemGroupForm == null) {
				eemGroupForm = new EEMGroupForm();
			}
			EEMGroupHelper.setFormLists(eemGroupForm);
			request.setAttribute(EEMConstants.EEM_GROUP_FORM, eemGroupForm);
		} else {
			eemGroupForm = (EEMGroupForm)form;
		}
				
		eemGroupForm.setMenu(EEMConstants.MENU_GROUP);
		
		if (EEMConstants.OPTION_GROUPSEM.equals(selectedTab)) {
			EEMGroupHelper.setGroupSearchLists(eemGroupForm, context);
			return mapping.findForward(EEMConstants.EEM_GROUP);
		}

		if (EEMConstants.OPTION_PRODUCTSEM.equals(selectedTab))
			return mapping.findForward(EEMConstants.EEM_PRODUCTS);
		
		if (EEMConstants.OPTION_SVCAREASEM.equals(selectedTab))
			return mapping.findForward(EEMConstants.EEM_SVCAREAS);
		
		if (EEMConstants.OPTION_GRPPRODSVCEM.equals(selectedTab))
			return mapping.findForward(EEMConstants.EEM_SVCAREAS);

		return mapping.findForward("eemError");
	}*/
	
	private ActionForward eemLetterReqMenu(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		context.setSelectedMenu(EEMConstants.MENU_LETTER);
		if (!(form instanceof EEMLetterReqForm)) {
			EEMLetterReqForm eemLetterForm = EEMLetterHelper.getEEMForm(sessionHelper);
			if (eemLetterForm == null) {
				eemLetterForm = new EEMLetterReqForm();
				EEMLetterHelper.clearForm(eemLetterForm);
			}
			
			EEMLetterReqVO letterReqVO = context.getLetterReqVO();
						
			List searchResults = letterReqVO.getSearchResults();
			eemLetterForm.setListSearchResults(searchResults);
			eemLetterForm.setLstLetterName(context.getLstLetterNames());
			/** Triple S BasePlus Migration START **/
			//Added for TSA changes for Member Id Label Change :Start	
			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			String memberLabel = EEMProfileSettings
					.getCalendarProfileText(eemDb, sessionHelper.getMfId(),
							"MBRIDLIT");
			eemLetterForm.setMbrLabel(memberLabel);
			//Added for TSA changes for Member Id Label Change :End
			/** Triple S BasePlus Migration END **/
			
			if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(eemLetterForm.getEditState())) {
				if (searchResults != null) {
					if (searchResults.size() > 0) {
						EEMLetterManager mgr = new EEMLetterManager();
						mgr.letterReqSelect(conn,sessionHelper,context,eemLetterForm);

						//EMLetterReqSearchResultVO searchVO = (EMLetterReqSearchResultVO) searchResults.get(eemLetterForm.getSelectedSearchRow());
						//EMLetterReqDisplayVO dispVO = new EMLetterReqDisplayVO();
						//EEMLetterHelper.copySearchToDisplay(searchVO,dispVO);
						//eemLetterForm.setDisplayLetterReq(dispVO);
					}
				}
			} else {
				EMLetterReqDisplayVO dispVO = eemLetterForm.getDisplayLetterReq();
				dispVO.setLstVarData(EEMLetterHelper.getVarDataList(dispVO));
			}
			
			EEMLetterHelper.setFormLists(eemLetterForm);
			request.setAttribute(EEMConstants.EEM_LETTER_FORM, eemLetterForm);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LETTER_REQ);
	}

	private ActionForward eemLetterReqClearSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws SQLException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterReqVO letterReqVO = context.getLetterReqVO();
		// Copy the search criteria to the VO
		letterReqVO.setCustomerId("");
		letterReqVO.setSearchType("");
		letterReqVO.setSearchId("");
		letterReqVO.setSearchCreateDate("");
		letterReqVO.setSearchStatus("");

		letterReqVO.setSearchResults(null);
		
		EEMLetterReqForm eemLetterForm = (EEMLetterReqForm)form;
		eemLetterForm.setSearchType("");
		eemLetterForm.setSearchId("");
		eemLetterForm.setSearchCreateDate("");
		eemLetterForm.setSearchStatus("");

		eemLetterForm.setSelectedSearchRow(0);
		eemLetterForm.setListSearchResults(null);
		eemLetterForm.setSearchExpanded(false);
		eemLetterForm.setEditState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		
		EMLetterReqDisplayVO dispVO = new EMLetterReqDisplayVO();
		dispVO.setLetterName("");
		eemLetterForm.setDisplayLetterReq(dispVO);
		eemLetterForm.setLstLetterName(null);
		context.setLstLetterNames(null);		
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LETTER_REQ);
	}

	private ActionForward eemLetterReqSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws SQLException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		long startTime = System.currentTimeMillis();
		EEMLetterManager mgr = new EEMLetterManager();
		mgr.letterReqSearch(conn, sessionHelper, context, (EEMLetterReqForm)form);
		long endTime = System.currentTimeMillis();
		replogger.debug("Letters|Letter Request Search|"+sessionHelper.getMfId()+"|"+(endTime - startTime)+" ms|");
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LETTER_REQ);
	}
	private ActionForward eemLetterReqSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request, String move) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterManager mgr = new EEMLetterManager();
		mgr.letterReqSearchPage(conn,sessionHelper,context,(EEMLetterReqForm)form,move);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LETTER_REQ);
	}
	private ActionForward eemLetterReqSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterManager mgr = new EEMLetterManager();
		mgr.letterReqSelect(conn,sessionHelper,context,(EEMLetterReqForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LETTER_REQ);
	}
	public ActionForward eemLetterReqLookup(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterManager mgr = new EEMLetterManager();
		mgr.letterReqLookup(conn,sessionHelper,context,(EEMLetterReqForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LETTER_REQ);		
	}
	private ActionForward eemLetterReqInfoChange(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		context.setSelectedMenu(EEMConstants.MENU_LETTER);
		EEMLetterReqVO letterReqVO = context.getLetterReqVO();
		
		EEMLetterReqForm eemLetterForm = (EEMLetterReqForm)form;
		
		List searchResults = letterReqVO.getSearchResults();
		eemLetterForm.setListSearchResults(searchResults);

		eemLetterForm.setLstLetterName(null);
		context.setLstLetterNames(null);

		EMLetterReqDisplayVO dispVO = eemLetterForm.getDisplayLetterReq();
		dispVO.setLetterName("");
		dispVO.setPlanId("");
		dispVO.setPbpId("");
		dispVO.setEffDate("");
		dispVO.setPlanDesignation("");
		dispVO.setLstVarData(null);
		
		
		EEMLetterHelper.setFormLists(eemLetterForm);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LETTER_REQ);
	}
	public ActionForward eemLetterReqSelectLetter(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterManager mgr = new EEMLetterManager();
		mgr.letterReqSelectLetter(conn,sessionHelper,context,(EEMLetterReqForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LETTER_REQ);		
	}
	public ActionForward eemLetterReqCreateLetter(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterManager mgr = new EEMLetterManager();
		mgr.letterReqCreateLetter(conn,sessionHelper,context,(EEMLetterReqForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LETTER_REQ);		
	}
	public ActionForward eemLetterReqNewRequest(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterManager mgr = new EEMLetterManager();
		mgr.letterReqNewRequest(conn,sessionHelper,context,(EEMLetterReqForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LETTER_REQ);		
	}
	
	/*private ActionForward eemDashBoard(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		
		context.setSelectedMenu(EEMConstants.MENU_DASHBOARD);

		EEMDshBrdForm eemDshBrdForm = null;
		if (!(form instanceof EEMDshBrdForm)) {
			
			eemDshBrdForm = EEMDshBrdHelper.getEEMForm(sessionHelper);
			if (eemDshBrdForm == null) {
				eemDshBrdForm = new EEMDshBrdForm();
			}
			request.setAttribute(EEMConstants.EEM_DSHBRD_FORM, eemDshBrdForm);
			
		} else {
			eemDshBrdForm = (EEMDshBrdForm)form;
		}
		EEMDshBrdHelper.setDshBrdFormList(eemDshBrdForm, sessionHelper);
		
		// Get the Search list
		if (sessionHelper.isEEMSupervisor()) { 
			String selectedTab = StringUtil.nonNullTrim(context.getApplDshBrdTab());
			if (selectedTab.equals("")) {
				selectedTab = EEMConstants.EEM_APPLDSHBRD_TAB_MAIN;
				context.setApplDshBrdTab(selectedTab);
			}
			if (selectedTab.equals(EEMConstants.EEM_APPLDSHBRD_TAB_MAIN)) {
				EEMDshBrdHelper.getDashBoardList(eemDshBrdForm, sessionHelper);
			} else if (selectedTab.equals(EEMConstants.EEM_APPLDSHBRD_TAB_WORKLOAD)) {
				EEMDshBrdHelper.getWorkLoadList(eemDshBrdForm, sessionHelper);
			} else if (selectedTab.equals(EEMConstants.EEM_APPLDSHBRD_TAB_ASSIGNMENT)) {
				eemDshBrdForm.setLstDshBrdDrill(EEMDshBrdHelper.getDrillDown(sessionHelper));
			}
		} else {
			context.setApplDshBrdTab(EEMConstants.EEM_APPLDSHBRD_TAB_ASSIGNMENT);
			eemDshBrdForm.setSelectedSubMenuTab(EEMConstants.EEM_APPLDSHBRD_TAB_ASSIGNMENT);
			EEMDshBrdHelper.getDrillDownList(eemDshBrdForm, sessionHelper);
		}
		
		return mapping.findForward(EEMConstants.EEM_DASHBOARD);
	}
	*/
	private ActionForward eemDshBrdTabSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		context.setSelectedMenu(EEMConstants.MENU_DASHBOARD);
		
		EEMDshBrdForm eemDshBrdForm = (EEMDshBrdForm)form;
		String selectedTab = StringUtil.nonNullTrim(eemDshBrdForm.getSelectedSubMenuTab());
		context.setApplDshBrdTab(selectedTab);
		
		if (selectedTab.equals(EEMConstants.EEM_APPLDSHBRD_TAB_MAIN)) {
			EEMDshBrdHelper.getDashBoardList(eemDshBrdForm, sessionHelper);
		} else if (selectedTab.equals(EEMConstants.EEM_APPLDSHBRD_TAB_WORKLOAD)) {
			EEMDshBrdHelper.getWorkLoadList(eemDshBrdForm, sessionHelper);
		} else if (selectedTab.equals(EEMConstants.EEM_APPLDSHBRD_TAB_ASSIGNMENT)) {
			eemDshBrdForm.setLstDshBrdDrill(EEMDshBrdHelper.getDrillDown(sessionHelper));
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_DASHBOARD);
	}
	
	private ActionForward eemDshBrdToAppl(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMDshBrdForm eemDshBrdForm = (EEMDshBrdForm)form;
		EEMDshBrdHelper.saveEEMForm(sessionHelper, eemDshBrdForm);

		EEMApplForm eemApplForm = new EEMApplForm();
		eemApplForm.setSearchApplId(eemDshBrdForm.getApplId());
		EEMApplHelper.setApplFormList(eemApplForm, sessionHelper);
		
		request.setAttribute(EEMConstants.EEM_APPL_FORM, eemApplForm);
		context.setSelectedMenu(EEMConstants.MENU_APPL);
		logger.info(LoggerConstants.methodEndLevel());
		return eemApplSearch(conn, sessionHelper, context, mapping, (EEMForm)eemApplForm, request);
	}
	
	private ActionForward eemDshBrdDrill(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMDshBrdForm eemDshBrdForm = (EEMDshBrdForm)form;

		EEMDshBrdHelper.getDrillDownList(eemDshBrdForm, sessionHelper);
		eemDshBrdForm.setSelectedSubMenuTab(EEMConstants.EEM_APPLDSHBRD_TAB_ASSIGNMENT);
		context.setApplDshBrdTab(EEMConstants.EEM_APPLDSHBRD_TAB_ASSIGNMENT);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_DASHBOARD);
	}
	
	/*private ActionForward eemMbrDashBoard(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		
		context.setSelectedMenu(EEMConstants.MENU_MBR_DASHBOARD);

		EEMMbrDshBrdForm eemDshBrdForm = null;
		if (!(form instanceof EEMMbrDshBrdForm)) {
			
			eemDshBrdForm = EEMMbrDshBrdHelper.getEEMForm(sessionHelper);
			if (eemDshBrdForm == null) {
				eemDshBrdForm = new EEMMbrDshBrdForm();
			}
			request.setAttribute(EEMConstants.EEM_MBR_DSHBRD_FORM, eemDshBrdForm);
			
		} else {
			eemDshBrdForm = (EEMMbrDshBrdForm)form;
		}
		
		EEMMbrDshBrdHelper.setDshBrdFormList(eemDshBrdForm, sessionHelper);
		
		// Get the Search list
		if (sessionHelper.isEEMSupervisor()) { 
			String selectedTab = StringUtil.nonNullTrim(context.getMbrDshBrdTab());
			if (selectedTab.equals("")) {
				selectedTab = EEMConstants.EEM_MBRDSHBRD_TAB_MAIN;
				context.setMbrDshBrdTab(selectedTab);
			}
			if (selectedTab.equals(EEMConstants.EEM_MBRDSHBRD_TAB_MAIN)) {
				EEMMbrDshBrdHelper.getDashBoardList(eemDshBrdForm, sessionHelper);
			} else if (selectedTab.equals(EEMConstants.EEM_MBRDSHBRD_TAB_WORKLOAD)) {
				EEMMbrDshBrdHelper.getWorkloadList(eemDshBrdForm, sessionHelper);
			} else if (selectedTab.equals(EEMConstants.EEM_MBRDSHBRD_TAB_ASSIGNMENT)) {
				eemDshBrdForm.setLstDshBrdDrill(EEMMbrDshBrdHelper.getDrillDown(sessionHelper));
			}
		} else {
			context.setMbrDshBrdTab(EEMConstants.EEM_MBRDSHBRD_TAB_ASSIGNMENT);
			eemDshBrdForm.setSelectedSubMenuTab(EEMConstants.EEM_MBRDSHBRD_TAB_ASSIGNMENT);
			EEMMbrDshBrdHelper.getDrillDownList(eemDshBrdForm,sessionHelper);
		}		
		
		return mapping.findForward(EEMConstants.EEM_MBR_DASHBOARD);
	}*/

	private ActionForward eemMbrDshBrdTabSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		context.setSelectedMenu(EEMConstants.MENU_MBR_DASHBOARD);
		
		EEMMbrDshBrdForm eemDshBrdForm = (EEMMbrDshBrdForm)form;
		String selectedTab = StringUtil.nonNullTrim(eemDshBrdForm.getSelectedSubMenuTab());
		context.setMbrDshBrdTab(selectedTab);
		
		if (selectedTab.equals(EEMConstants.EEM_MBRDSHBRD_TAB_MAIN)) {
			EEMMbrDshBrdHelper.getDashBoardList(eemDshBrdForm, sessionHelper);
		} else if (selectedTab.equals(EEMConstants.EEM_MBRDSHBRD_TAB_WORKLOAD)) {
			EEMMbrDshBrdHelper.getWorkloadList(eemDshBrdForm, sessionHelper);
		} else if (selectedTab.equals(EEMConstants.EEM_MBRDSHBRD_TAB_ASSIGNMENT)) {
			eemDshBrdForm.setLstDshBrdDrill(EEMMbrDshBrdHelper.getDrillDown(sessionHelper));
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_MBR_DASHBOARD);
	}

	private ActionForward eemMbrDshBrdDrill(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMMbrDshBrdForm eemDshBrdForm = (EEMMbrDshBrdForm)form;

		EEMMbrDshBrdHelper.getDrillDownList(eemDshBrdForm, sessionHelper);
		context.setMbrDshBrdTab(EEMConstants.EEM_MBRDSHBRD_TAB_ASSIGNMENT);
		eemDshBrdForm.setSelectedSubMenuTab(EEMConstants.EEM_MBRDSHBRD_TAB_ASSIGNMENT);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_MBR_DASHBOARD);
	}

	private ActionForward eemApplNewMemberMA(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplHelper.loadFormDetails(conn, EEMConstants.OPTION_APPLNEWMBR_MA, (EEMApplForm)form, sessionHelper);
		// IFOX-00377758 -- Added the below method call
		EEMApplHelper.resetMbrPersonalInfo((EEMApplForm)form);
		/** Triple S BasePlus Migration START **/
			//Begin: Added for IFOX-00398201
			EEMApplForm eemApplForm = (EEMApplForm)form;
			if(StringUtil.nonNullTrim(eemApplForm.getCustomerId()).trim().equalsIgnoreCase("HCF0281")){
				eemApplForm.setLanguage("SPA"); //TSA Baseplus
			}
				else
				eemApplForm.setLanguage(eemApplForm.getLanguage() == null || eemApplForm.getLanguage().trim().equals("") ? "ENG" : eemApplForm.getLanguage());
				//End: Added for IFOX-00398201
		/** Triple S BasePlus Migration END **/
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.EEM_APPLNEWMBR_MA);
	}
	
	private ActionForward eemApplNewMemberPD(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplHelper.loadFormDetails(conn, EEMConstants.OPTION_APPLNEWMBR_PD, (EEMApplForm)form, sessionHelper);
		// IFOX-00377758 -- Added the below method call
		EEMApplHelper.resetMbrPersonalInfo((EEMApplForm)form);
		/** Triple S BasePlus Migration START **/
			//Begin: Added for IFOX-00398201
			EEMApplForm eemApplForm = (EEMApplForm)form;
			if(StringUtil.nonNullTrim(eemApplForm.getCustomerId()).trim().equalsIgnoreCase("HCF0281"))
				eemApplForm.setLanguage("SPA"); //TSA Baseplus
			else
				eemApplForm.setLanguage(eemApplForm.getLanguage() == null || eemApplForm.getLanguage().trim().equals("") ? "ENG" : eemApplForm.getLanguage());
				//End: Added for IFOX-00398201
		/** Triple S BasePlus Migration END **/
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.EEM_APPLNEWMBR_PD);
	}
	
	private ActionForward eemContractChgMA(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplHelper.loadFormDetails(conn, EEMConstants.OPTION_CNTRCHG_MA, (EEMApplForm)form, sessionHelper);
		/** Triple S BasePlus Migration START **/
			//Begin: Added for IFOX-00398201
			EEMApplForm eemApplForm = (EEMApplForm)form;
			if(StringUtil.nonNullTrim(eemApplForm.getCustomerId()).trim().equalsIgnoreCase("HCF0281"))
				eemApplForm.setLanguage("SPA"); //TSA Baseplus
			else
				eemApplForm.setLanguage(eemApplForm.getLanguage() == null || eemApplForm.getLanguage().trim().equals("") ? "ENG" : eemApplForm.getLanguage());
				//End: Added for IFOX-00398201
		/** Triple S BasePlus Migration END **/
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.EEM_CNTRCHG_MA);
	}
	
	private ActionForward eemContractChgPD(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplHelper.loadFormDetails(conn, EEMConstants.OPTION_CNTRCHG_PD, (EEMApplForm)form, sessionHelper);
		/** Triple S BasePlus Migration START **/
			//Begin: Added for IFOX-00398201
			EEMApplForm eemApplForm = (EEMApplForm)form;
			if(StringUtil.nonNullTrim(eemApplForm.getCustomerId()).trim().equalsIgnoreCase("HCF0281"))
				eemApplForm.setLanguage("SPA"); //TSA Baseplus
			else
				eemApplForm.setLanguage(eemApplForm.getLanguage() == null || eemApplForm.getLanguage().trim().equals("") ? "ENG" : eemApplForm.getLanguage());
				//End: Added for IFOX-00398201
		/** Triple S BasePlus Migration END **/
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.EEM_CNTRCHG_PD);
	}


	private ActionForward eemGroupsEM(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		context.setOptGrpSvc(EEMConstants.OPTION_GROUPSEM);
		if (!(form instanceof EEMGroupForm)) {
			EEMGroupForm eemGroupForm = new EEMGroupForm();
			eemGroupForm.setLstGrpAddresses(new ArrayList());
			EEMGroupHelper.setFormLists(eemGroupForm);
			request.setAttribute(EEMConstants.EEM_GROUP_FORM, eemGroupForm);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_GROUPS);
	}
	
	private ActionForward eemGroupsSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws SQLException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMGroupManager mgr = new EEMGroupManager();
		
		Pagination pagination = context.getGroupPagination();
		if (pagination == null) {
			pagination = new Pagination();
			pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
			context.setGroupPagination(pagination);
		}
		
		mgr.groupSearch(conn, sessionHelper, context, (EEMGroupForm)form, pagination, "first");
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_GROUPS);
	}

	private ActionForward eemGroupsGet(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws SQLException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMGroupManager mgr = new EEMGroupManager();
		mgr.getGroupDetail(conn, sessionHelper, context, (EEMGroupForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_GROUPS);
	}

	private ActionForward eemGroupAddrGet(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws SQLException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMGroupManager mgr = new EEMGroupManager();
		mgr.getGroupAddrDetail(conn, sessionHelper, context, (EEMGroupForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_GROUPS);
	}
	
	private ActionForward eemGroupsNew(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws SQLException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMGroupHelper.clearForm((EEMGroupForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_GROUPS);
	}
	
	private ActionForward eemGroupsSave(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws SQLException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMGroupManager mgr = new EEMGroupManager();
		mgr.groupSave(conn, sessionHelper, (EEMGroupForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_GROUPS);
	}

	private ActionForward eemProductsEM(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		context.setOptGrpSvc(EEMConstants.OPTION_PRODUCTSEM);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_PRODUCTS);
	}	

	private ActionForward eemSvcAreasEM(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		context.setOptGrpSvc(EEMConstants.OPTION_SVCAREASEM);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_SVCAREAS);
	}		
	
	private ActionForward eemSupvsrGotoAppl(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMSupvsrForm eemSupvsrForm = (EEMSupvsrForm) form;
		EEMApplForm applForm = new EEMApplForm();
		EEMApplicationVO filterVO = context.getApplicationFilter();
		EEMApplService service = context.getService();
		String returnStr = EEMConstants.EEM_APPROVALS;
		
		// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - Start
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - End
		
		// Set the form fields
		String customerId = StringUtil.nonNullTrim(eemSupvsrForm.getCustomerId());
		String applId = StringUtil.nonNullTrim(eemSupvsrForm.getApplId());
		
		if (!customerId.equals("") && !applId.equals("")) {
			// Save the Supervisor form
			EEMSupvsrHelper.saveEEMForm(sessionHelper, eemSupvsrForm);
			
			// Get Application details
			filterVO.setCustomerId(customerId);
			filterVO.setApplId(applId);
			
			// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - Start
			EEMApplicationVO selectedApp = service.getApplDetails(conn,eemDb, filterVO);
			// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - End

			// Set it to Appl form
			EEMApplHelper.setVOToForm(selectedApp, applForm, sessionHelper);
			/**
			 * Cambia_OEVprocess-start
			 */
			applForm.setDisplaySavedOev(selectedApp.getOevCallStatusSaved());
			if(!(selectedApp.getOevCallStatusSaved()==null)){
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_APPL_SEARCH, null);
			}
			applForm.setDisplaySavedRetOev(selectedApp.getOevRetStatusSaved());
			/**
			 * Cambia_OEVprocess-End
			 */
			
			// Set other details for Appl Form
			context.setSelectedMenu(EEMConstants.MENU_APPL);
			EEMApplHelper.loadLookUps(conn, applForm, sessionHelper);
			EEMApplHelper.setApplicationStatus(applForm, sessionHelper);
			applForm.setUpdateRec("Y");
			
			// Remove Search List
			applForm.setLstSearch(null);
			sessionHelper.getSession().setAttribute(EEMConstants.SESSION_APPL_SEARCH, null);
			
			// Save it to request
			request.setAttribute(EEMConstants.EEM_APPL_FORM, applForm);
			EEMApplHelper.saveEEMForm(sessionHelper, applForm);
			
			returnStr = EEMApplHelper.getPage(applForm);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(returnStr);
	}
	
	private ActionForward eemSupvsrUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMSupvsrForm eemSupvsrForm = (EEMSupvsrForm) form;
		EEMSupvsrVO filterVO = context.getSupvsrFilter();
		EEMSupvsrService service = context.getSupvsrService();
		
		EEMSupvsrHelper.setFormToVO(eemSupvsrForm, filterVO, sessionHelper);
		
		service.setApprovalStatus(conn, filterVO);
		
		EEMSupvsrHelper.setVOToForm(filterVO, eemSupvsrForm, sessionHelper);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_APPROVALS);
	}

	private ActionForward eemSupvsrCancel(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMSupvsrForm eemSupvsrForm = (EEMSupvsrForm) form;
		
		EEMSupvsrHelper.cancelSearch(eemSupvsrForm, sessionHelper);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_APPROVALS);
	}
	
	private ActionForward eemSupvsrSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMSupvsrForm eemSupvsrForm = (EEMSupvsrForm) form;
		EEMSupvsrVO filterVO = context.getSupvsrFilter();
		EEMSupvsrHelper.setFormToVO(eemSupvsrForm, filterVO, sessionHelper);
		
		Pagination pagination = context.getSupvsrPagination();
		if (pagination == null) {
			pagination = new Pagination();
			pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
			context.setSupvsrPagination(pagination);
		}
		
		// Get the form fields
		EEMSupvsrService service = context.getSupvsrService();
		List lstSearch = service.getSearchList(conn, filterVO, pagination, "first");
		if (lstSearch.size() > 0) {
			filterVO.setLstSearch(lstSearch);
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_SUPVSR_SEARCH, lstSearch);
		} else {
			filterVO.setLstSearch(null);
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_SUPVSR_SEARCH, null);
		}
		
		EEMSupvsrHelper.setVOToForm(filterVO, eemSupvsrForm, sessionHelper);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_APPROVALS);
	}


	private ActionForward eemSupvsrSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request, String move) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMSupvsrForm eemSupvsrForm = (EEMSupvsrForm) form;
		EEMSupvsrVO filterVO = context.getSupvsrFilter();
		EEMSupvsrHelper.setFormToVO(eemSupvsrForm, filterVO, sessionHelper);
		
		Pagination pagination = context.getSupvsrPagination();
		if (pagination == null) {
			pagination = new Pagination();
			pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
			context.setSupvsrPagination(pagination);
		}
		
		
		EEMSupvsrService service = context.getSupvsrService();
		List lstSearch = service.getSearchList(conn, filterVO, pagination, move);		
		if (lstSearch.size() > 0) {
			filterVO.setLstSearch(lstSearch);
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_SUPVSR_SEARCH, lstSearch);
		} else {
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_SUPVSR_SEARCH, null);
		}
		
		EEMSupvsrHelper.setVOToForm(filterVO, eemSupvsrForm, sessionHelper);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_APPROVALS);
	}
	
	private ActionForward eemDshBrdToMbr(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMMbrDshBrdForm eemDshBrdForm = (EEMMbrDshBrdForm)form;
		EEMMbrDshBrdHelper.saveEEMForm(sessionHelper, eemDshBrdForm);

		EEMEnrollForm eemEnrollForm = new EEMEnrollForm();
		eemEnrollForm.setSearchSupplementalId(eemDshBrdForm.getSupplId());
		EEMEnrollHelper.setEnrollFormList(eemEnrollForm, sessionHelper.getSession());
		
		request.setAttribute(EEMConstants.EEM_ENROLL_FORM, eemEnrollForm);
		context.setSelectedMenu(EEMConstants.MENU_ENROLLMENT);
		logger.info(LoggerConstants.methodEndLevel());
		return eemEnrollSearch(conn, sessionHelper, context, mapping, (EEMForm)eemEnrollForm, request);
	}
	
	public ActionForward eemApplSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		long startTime = System.currentTimeMillis();
		EEMApplForm eemFormAppl = (EEMApplForm) form;
		EEMApplicationVO filterVO = context.getApplicationFilter();
		EEMApplHelper.setFormToVO(eemFormAppl, filterVO, sessionHelper);
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		//Added for SSNRI changes,Calling method to determine if Medicare ID search field is HIC/MBI : start
		if(!StringUtil.nonNullTrim(filterVO.getSearchHicNo()).equals("")){
			String flag = isHicOrMbi(filterVO.getSearchHicNo());
			filterVO.setIsHicOrMbi(flag);
			if(filterVO.getIsHicOrMbi().equals("mbi"))
				filterVO.setMbiNbr(filterVO.getSearchHicNo());
		}
		//Added for SSNRI changes,Calling method to determine if Medicare ID search field is HIC/MBI : start

		try {
			eemFormAppl.setIsSubscriberIdRequired(EEMProfileSettings
					.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),
							"SUBSCID"));
			
			/** Triple S BasePlus Migration START **/
			// TSA Changes :Start

						eemFormAppl.setIsSubscriberIdMandatory(EEMProfileSettings
								.getCalendarProfileText(eemDb, sessionHelper.getMfId(),
										"SUBSCID"));
			// TSA Changes :End
			/** Triple S BasePlus Migration END **/
						
			/*Access health PCP CR- Start */
			String npiInd = (String) sessionHelper.getAttribute("NPIIND");
			if(null == npiInd || npiInd.trim().equals(""))
			{
				npiInd = EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(), "NPIIND");
				sessionHelper.setAttribute("NPIIND", npiInd);
			}
			/*Access health PCP CR- End */
			
		} catch (Exception e) {
		
		}
	
		Pagination pagination = context.getApplPagination();
		if (pagination == null) {
			pagination = new Pagination();
			pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
			context.setApplPagination(pagination);
		}
		
		// Get the form fields
		EEMApplService service = context.getService();
		
		List lstSearch = service.getSearchList(conn, filterVO, pagination, "first");		
		if (lstSearch.size() > 0) {
			EEMApplicationVO objVO = (EEMApplicationVO) lstSearch.get(0);
			filterVO.setCustomerId(objVO.getCustomerId());
			filterVO.setApplId(objVO.getApplId());

			// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - Start
			EEMApplicationVO selctedApp = service.getApplDetails(conn, eemDb, filterVO);
			// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - End
			
			//original application start
			boolean check=service.checkOrigApplRecords(conn,filterVO);
			
			if(check==true){
			filterVO.setOrig(1);
			selctedApp.setOrig(1);
			filterVO.setOriginalButton(0);
			selctedApp.setOriginalButton(0);
			
			}
		//original application end
			/**
			 * Cambia_PRE-SET Notes-start
			 */
			// Performance Changes -Start
			//getPresetList(conn, service, filterVO,sessionHelper);
			// Performance Changes -End
			/**
			 * Cambia_PRE-SET Notes-End
			 */
			EEMApplHelper.setVOToForm(selctedApp, eemFormAppl, sessionHelper);
			EEMApplHelper.setSearchVOToForm(filterVO,eemFormAppl);
			/**
			 * Cambia_PRE-SET Notes-start
			 */
			// Performance Changes -Start
	        //eemFormAppl.setPreSetNoteList(filterVO.getPreSetNoteList());
			// Performance Changes -End
	        /**
			 * Cambia_PRE-SET Notes-End
			 */
			
			
			/**
			 * Cambia_OEVProcess-start
			 */
			eemFormAppl.setDisplaySavedOev(selctedApp.getOevCallStatusSaved());
			eemFormAppl.setDisplaySavedRetOev(selctedApp.getOevRetStatusSaved());
			
			/**
			 * Cambia_OEVProcess-End
			 */
			if (lstSearch.size() > 1) {
				eemFormAppl.setLstSearch(lstSearch);
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_APPL_SEARCH, lstSearch);
			} else {
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_APPL_SEARCH, null);
			}
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_APPL_ERRORS,
					eemFormAppl.getLstErrors());
			/**
			 * Cambia_OEVProcess-Start
			 */
			if(selctedApp.getOevCallAttempts()==null){
				//System.out.println(" in action Oev list is null");
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_OEV_SEARCH1, null);
			}
			else{
				//System.out.println(" oevCal size"+filterVO.getOevCallAttempts());
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH1, selctedApp.getOevCallAttempts());
			}
			if(selctedApp.getOevCallStatus()==null){
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_OEV_SEARCH2, null);
			}
			else{
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH2, selctedApp.getOevCallStatus());
			}
			if(selctedApp.getOevCallStatusSaved()==null){
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_OEV_SEARCH3, null);
			}
			else{
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH3,selctedApp.getOevCallStatusSaved());
			}
			if(selctedApp.getOevRetStatus()==null){
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_OEV_SEARCH4, null);
			}
			else{
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH4,selctedApp.getOevRetStatus());
			}
			if(selctedApp.getOevRetStatusSaved()==null){
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_OEV_SEARCH5, null);
			}
			else{
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH5,selctedApp.getOevRetStatusSaved());
			}
			if(selctedApp.getOevRetStatus()==null){
				//System.out.println(" in action Oev list is null");
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_OEV_SEARCH6, null);
			}
			else{
				//System.out.println(" oevCal size"+filterVO.getOevRetStatus());
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH6, selctedApp.getReturnCalls());
			}
			/**
			 * Cambia_OEVProcess-End
			 */
			// Set Application Status
			EEMApplHelper.setApplicationStatus(eemFormAppl, sessionHelper);
			eemFormAppl.setUpdateRec("Y");
		} else {
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_APPL_SEARCH, null);
			context.setOptAppl(null);
			eemFormAppl.setApplType("");
			eemFormAppl.setVisible("Y");
			EEMApplHelper.setApplFormList(eemFormAppl, sessionHelper);
			return mapping.findForward(EEMConstants.EEM_APPL);			
			//return eemAppl(conn, sessionHelper, context, mapping, form, request);
		}
		logger.info(LoggerConstants.methodEndLevel());
		long endTime = System.currentTimeMillis();
		replogger.debug("M360|Application Search|"+sessionHelper.getMfId()+"|"+(endTime - startTime)+" ms|");
		return mapping.findForward(EEMApplHelper.getPage(eemFormAppl));
	}
	private ActionForward eemApplSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request, String move) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplForm eemFormAppl = (EEMApplForm) form;
		Pagination pagination = context.getApplPagination();
		if (pagination == null) {
			pagination = new Pagination();
			pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
			context.setApplPagination(pagination);
		}
		EEMApplicationVO filterVO = context.getApplicationFilter();
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		
		try {
			eemFormAppl.setIsSubscriberIdRequired(EEMProfileSettings
					.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),
							"SUBSCID"));
			/** Triple S BasePlus Migration START **/
			// TSA Changes :Start

						eemFormAppl.setIsSubscriberIdMandatory(EEMProfileSettings
								.getCalendarProfileText(eemDb, sessionHelper.getMfId(),
										"SUBSCID"));
			// TSA Changes :End
			/** Triple S BasePlus Migration END **/
						
		} catch (Exception e) {
		
		}
		//Added for SSNRI changes,Calling method to determine if Medicare ID search field is HIC/MBI : start
			if(!StringUtil.nonNullTrim(filterVO.getSearchHicNo()).equals("")){
					String flag = isHicOrMbi(filterVO.getSearchHicNo());
					filterVO.setIsHicOrMbi(flag);
					if(filterVO.getIsHicOrMbi().equals("mbi"))
						filterVO.setMbiNbr(filterVO.getMbrHicNbr());
			}
			//Added for SSNRI changes,Calling method to determine if Medicare ID search field is HIC/MBI : start
		
		EEMApplService service = context.getService();
		List lstSearch = service.getSearchList(conn, filterVO, pagination, move);		

		if (lstSearch.size() > 0) {
			EEMApplicationVO objVO = (EEMApplicationVO) lstSearch.get(0);
			filterVO.setCustomerId(objVO.getCustomerId());
			filterVO.setApplId(objVO.getApplId());

			// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - Start
			filterVO = service.getApplDetails(conn,eemDb, filterVO);
			// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - End
			
			EEMApplHelper.setVOToForm(filterVO, eemFormAppl, sessionHelper);
			/**
			 * Cambia_OEV-Start
			 */
			eemFormAppl.setDisplaySavedOev(filterVO.getOevCallStatusSaved());
			eemFormAppl.setDisplaySavedRetOev(filterVO.getOevRetStatusSaved());
			/**
			 * Cambia_OEV-End
			 */
			eemFormAppl.setLstSearch(lstSearch);
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_APPL_SEARCH, lstSearch);
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_APPL_ERRORS,
					eemFormAppl.getLstErrors());
			
			// Set Application Status
			EEMApplHelper.setApplicationStatus(eemFormAppl, sessionHelper);
			eemFormAppl.setUpdateRec("Y");
		} else {
			sessionHelper.getSession().setAttribute(EEMConstants.SESSION_APPL_SEARCH, null);
			eemFormAppl.setApplType("");
			context.setOptAppl(null);
			eemFormAppl.setApplType("");
			eemFormAppl.setVisible("Y");
			EEMApplHelper.setApplFormList(eemFormAppl, sessionHelper);
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.EEM_APPL);			
			
			//return eemAppl(conn, sessionHelper, context, mapping, form, request);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMApplHelper.getPage(eemFormAppl));
	}
	
	private ActionForward eemApplValidate(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		// Get the form
		EEMApplForm eemFormAppl = (EEMApplForm) form;
		EEMApplService service = context.getService();
		
		EEMApplHelper.setCommentList(eemFormAppl);
		EEMApplHelper.setAttestationList(eemFormAppl);
//Added for SSNRI changes, calling method to determine if Medicare ID search field is HIC/MBI : start
		if(!StringUtil.nonNullTrim(eemFormAppl.getMbrHicNbr()).equals("")){
			String flag = isHicOrMbi(eemFormAppl.getMbrHicNbr());
			eemFormAppl.setIsHicOrMbi(flag);
			if(eemFormAppl.getIsHicOrMbi().equals("mbi"))
				eemFormAppl.setMbiNbr(eemFormAppl.getMbrHicNbr());
		}
		//Added for SSNRI changes, Calling method to determine if Medicare ID search field is HIC/MBI : end
		// Validate form
		EEMApplicationVO filterVO = EEMApplHelper.validateForm(conn, sessionHelper, context, eemFormAppl);
		filterVO = service.getOevDetails(conn, filterVO);
		if(filterVO.getOevCallAttempts()==null){
			//System.out.println(" in action Oev list is null");
			sessionHelper.getSession().setAttribute
			(
					EEMConstants.SESSION_OEV_SEARCH1, null);
		}
		else{
		//	System.out.println(" oevCal size"+filterVO.getOevCallAttempts());
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH1, filterVO.getOevCallAttempts());
		}
		if(filterVO.getOevCallStatus()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH2, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH2, filterVO.getOevCallStatus());
		}
		if(filterVO.getOevCallStatusSaved()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH3, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH3,filterVO.getOevCallStatusSaved());
		}
		if(filterVO.getOevRetStatus()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH4, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH4,filterVO.getOevRetStatus());
		}
		if(filterVO.getOevRetStatusSaved()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH5, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH5,filterVO.getOevRetStatusSaved());
		}
		if(filterVO.getOevRetStatus()==null){
			//System.out.println(" in action Oev list is null");
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH6, null);
		}
		else{
			//System.out.println(" oevCal size"+filterVO.getOevRetStatus());
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH6, filterVO.getReturnCalls());
		}
		/**
		 * Cambia_BEQ-Start
		 */
		if(filterVO.getApplStatus().equals(EEMConstants.APPL_STATUS_READYAPPR)&&
				StringUtil.nonNullTrim(filterVO.getEligibilitySrcTable()).equals(EEMConstants.EM_TABLE_BEQ)){
			filterVO.setApplStatus(EEMConstants.APPL_STATUS_BEQAPPR);
		}
		else if(filterVO.getApplStatus().equals(EEMConstants.APPL_STATUS_BEQAPPR)&&
				StringUtil.nonNullTrim(filterVO.getEligibilitySrcTable()).equals(EEMConstants.EM_TABLE_MBD)){
			filterVO.setApplStatus(EEMConstants.APPL_STATUS_READYAPPR);
		}
		/**
		 * Cambia_BEQ-End
		 */
		
		// Set Form variables
		//eemFormAppl.setLstErrors(filterVO.getLstErrors());
		EEMApplHelper.setVOToForm(filterVO, eemFormAppl, sessionHelper);
		logger.debug(" values in validate --"+eemFormAppl.getMbrBirthDt()+" "+filterVO.getMbrBirthDt());
		logger.debug(" values2 --"+eemFormAppl.getMbrGender()+" "+filterVO.getMbrGender());
		if (StringUtil.nonNullTrim(filterVO.getMessage()).equals("")) {
			eemFormAppl.setMessage("Validating Application Done.");
		} else {
			eemFormAppl.setMessage(filterVO.getMessage());	
		}
		EEMApplHelper.loadLookUps(conn, eemFormAppl, sessionHelper);
		eemFormAppl.setIsChanged("Y");
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMApplHelper.getPage(eemFormAppl));
	}

	private ActionForward eemApplRowSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		// Get the form
		EEMApplForm eemFormAppl = (EEMApplForm) form;

		// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - Start
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - End

		EEMApplicationVO filterVO = new EEMApplicationVO();
		EEMApplService service = context.getService();

		filterVO.setCustomerId(sessionHelper.getMfId());
		filterVO.setApplId(eemFormAppl.getApplId());
		filterVO.setCustomerNbr(sessionHelper.getCustomerNumber());
		// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - Start
		filterVO = service.getApplDetails(conn,eemDb, filterVO);
		// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - End
		
		//original application start
	boolean check=service.checkOrigApplRecords(conn,filterVO);
		
		if(check==true){
		filterVO.setOrig(1);}
		
		//original application end
		/**
		 * Cambia_Preset Notes-Start
		 */
		// Performance Changes -Start
		//getPresetList(conn, service, filterVO,sessionHelper);
		// Performance Changes -End
		EEMApplHelper.setVOToForm(filterVO, eemFormAppl, sessionHelper);

		// Performance Changes -Start
		//eemFormAppl.setPreSetNoteList(filterVO.getPreSetNoteList());
		// Performance Changes -End
		/**
		 * Cambia_Preset Notes-End
		 */
		/**
		 *Cambia_OEV-Start
		 */
		eemFormAppl.setDisplaySavedOev(filterVO.getOevCallStatusSaved());
		eemFormAppl.setDisplaySavedRetOev(filterVO.getOevRetStatusSaved());
		/**
		 * Cambia_OEV-End
		 */
		eemFormAppl.setUpdateRec("Y");
		//String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		
		try {
			eemFormAppl.setIsSubscriberIdRequired(EEMProfileSettings
					.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),
							"SUBSCID"));
			/** Triple S BasePlus Migration START **/		
			//TSA Changes :Start
			eemFormAppl.setIsSubscriberIdMandatory(EEMProfileSettings
					.getCalendarProfileText(eemDb, sessionHelper.getMfId(),
							"SUBSCID"));
			//TSA Changes :End
			/** Triple S BasePlus Migration END **/
			
		} catch (Exception e) {
		
		}
		
		
		
		List lstSearch = (List) sessionHelper.getAttribute(EEMConstants.SESSION_APPL_SEARCH);
		//original application start
		if(lstSearch!=null ){
			if(lstSearch.size()>0){	
		//original application end
				for (int i = 0; i < lstSearch.size(); i++) {
			EEMApplicationVO objVO = (EEMApplicationVO) lstSearch.get(i);
			if (objVO.getApplId().equals(eemFormAppl.getApplId())) {
				objVO.setRowSelected("Y");
			} else {
				objVO.setRowSelected("N");
			}
		}
//original application start
		eemFormAppl.setLstSearch(lstSearch);
		/**
		 * Cambia_OEV-Start
		 */
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_APPL_SEARCH, lstSearch);
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_APPL_ERRORS, eemFormAppl.getLstErrors());
					}else{
					sessionHelper.getSession().setAttribute(
							EEMConstants.SESSION_APPL_SEARCH, null);
					eemFormAppl.setApplType("");
					context.setOptAppl(null);
					eemFormAppl.setApplType("");
					eemFormAppl.setVisible("Y");
					EEMApplHelper.setApplFormList(eemFormAppl, sessionHelper);

					return mapping.findForward(EEMApplHelper.getPage(eemFormAppl));
					}
					}
		if(filterVO.getOevCallAttempts()==null){
			//System.out.println(" in action Oev list is null");
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH1, null);
		}
		else{
			//System.out.println(" oevCal size"+filterVO.getOevCallAttempts());
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH1, filterVO.getOevCallAttempts());
		}
		if(filterVO.getOevCallStatus()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH2, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH2, filterVO.getOevCallStatus());
		}
		if(filterVO.getOevCallStatusSaved()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH3, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH3,filterVO.getOevCallStatusSaved());
		}
		if(filterVO.getOevRetStatus()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH4, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH4,filterVO.getOevRetStatus());
		}
		if(filterVO.getOevRetStatusSaved()==null){
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH5, null);
		}
		else{
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH5,filterVO.getOevRetStatusSaved());
		}
		if(filterVO.getOevRetStatus()==null){
			//System.out.println(" in action Oev list is null");
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_OEV_SEARCH6, null);
		}
		else{
			//System.out.println(" oevCal size"+filterVO.getOevRetStatus());
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_OEV_SEARCH6, filterVO.getReturnCalls());
		}
		/**
		 * Cambia_OEV-End
		 */
		// Set Application Status
		EEMApplHelper.setApplicationStatus(eemFormAppl, sessionHelper);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMApplHelper.getPage(eemFormAppl));
	}

	private ActionForward eemApplMemberCheck(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		// Get the form
		EEMApplForm eemFormAppl = (EEMApplForm) form;
		EEMApplicationVO filterVO = new EEMApplicationVO();
		EEMApplService service = context.getService();
		
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		
		try {
			eemFormAppl.setIsSubscriberIdRequired(EEMProfileSettings
					.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),
							"SUBSCID"));
			/** Triple S BasePlus Migration START **/
			//TSA Changes :Start
			eemFormAppl.setIsSubscriberIdMandatory(EEMProfileSettings
					.getCalendarProfileText(eemDb, sessionHelper.getMfId(),
							"SUBSCID"));
			//TSA Changes :End
			/** Triple S BasePlus Migration END **/
		} catch (Exception e) {
			//e.printStackTrace();
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//logger.error("Exception : " + e.getMessage());
		
		}
		
		
		// Get the member details
		EEMApplHelper.setFormToVO(eemFormAppl, filterVO, sessionHelper);
		//Added for SSNRI changes,Calling method to determine if Medicare ID search field is HIC/MBI : START
		if(!StringUtil.nonNullTrim(filterVO.getMbrHicNbr()).equals("")){
			String flag = isHicOrMbi(filterVO.getMbrHicNbr());
			filterVO.setIsHicOrMbi(flag);
			if(filterVO.getIsHicOrMbi().equals("mbi"))
				filterVO.setMbiNbr(filterVO.getMbrHicNbr());
		}
		//Added for SSNRI changes,Calling method to determine if Medicare ID search field is HIC/MBI : END
		service.getMemberDetails(conn, eemDb, filterVO, false);
		
		// Set the details to Form
		EEMApplHelper.setVOToForm(filterVO, eemFormAppl, sessionHelper);
		EEMApplHelper.loadLookUps(conn, eemFormAppl, sessionHelper);
		EEMApplHelper.setAttestationList(eemFormAppl);
		
		// Set search list if present
		List lstSearch = (List) sessionHelper.getSession().getAttribute(
				EEMConstants.SESSION_APPL_SEARCH);
		if (lstSearch != null) {
			for (int i = 0; i < lstSearch.size(); i++) {
				EEMApplicationVO objVO = (EEMApplicationVO) lstSearch.get(i);
				if (objVO.getApplId().equals(eemFormAppl.getApplId())) {
					objVO.setRowSelected("Y");
				} else {
					objVO.setRowSelected("N");
				}
			}
		}
		eemFormAppl.setLstSearch(lstSearch);
		sessionHelper.getSession().setAttribute(EEMConstants.SESSION_APPL_SEARCH, lstSearch);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMApplHelper.getPage(eemFormAppl));
	}

	private ActionForward eemApplUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		long startTime = System.currentTimeMillis();
		// Get the form
		EEMApplForm eemFormAppl = (EEMApplForm) form;
		/*if(eemFormAppl.getBtnClicked() != null && eemFormAppl.getBtnClicked().equalsIgnoreCase("Cancel")){
			return eemApplCancellation(conn, sessionHelper, context, mapping,
						form, request);
		}
		else{*/
		EEMApplService service = context.getService();
		
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		
		EEMApplHelper.setCommentList(eemFormAppl);
		EEMApplHelper.setAttestationList(eemFormAppl);
		boolean incomplete = EEMApplHelper.isIncomplete(eemFormAppl); 
		
		EEMApplicationVO filterVO = new EEMApplicationVO();
		EEMApplHelper.setFormToVO(eemFormAppl, filterVO, sessionHelper);
		
		//Added for SSNRI changes,Calling method to determine if Medicare ID search field is HIC/MBI : start
				if(!StringUtil.nonNullTrim(filterVO.getMbrHicNbr()).equals("")){
					String flag = isHicOrMbi(filterVO.getMbrHicNbr());
					filterVO.setIsHicOrMbi(flag);
					if(filterVO.getIsHicOrMbi().equals("mbi"))
						filterVO.setMbiNbr(filterVO.getMbrHicNbr());
				}
				//Added for SSNRI changes,Calling method to determine if Medicare ID search field is HIC/MBI : start
		if(eemFormAppl.getBtnClicked() != null && eemFormAppl.getBtnClicked().equalsIgnoreCase("Cancel")){
			//to insert comments entered before canceling application--start--
			EEMApplHelper.setVOToForm(filterVO, eemFormAppl, sessionHelper);
			EEMApplCommentsVO origCommentVO  = new EEMApplCommentsVO();
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
		    service.setCommentDetails(eemDao, conn,eemDb,filterVO,origCommentVO);
		  //to insert comments entered before canceling application--end--
		    logger.info(LoggerConstants.methodEndLevel());
			return eemApplCancellation(conn, sessionHelper, context, mapping,
						form, request);
		}
		else{
		
		// Check for Lock Ind
		if (EEMApplHelper.checkLockInd(conn, eemFormAppl, sessionHelper, context)) {
			// Application is Incomplete or Canceled or Denied
			if (!incomplete) {
				// Member check and population
				String applType = eemFormAppl.getApplType();
				if (service.getMemberDetails(conn, eemDb, filterVO, true)) {
					filterVO.setMessage("");// blanking "Member check done." message
				}
				EEMApplHelper.setVOToForm(filterVO, eemFormAppl, sessionHelper);
				// IFOX-00382607: Retro Application CR - Start			
				//eemFormAppl.setApplType(applType);
				// IFOX-00382607: Retro Application CR - End
				// Validate Form
				filterVO = EEMApplHelper.validateForm(conn, sessionHelper, context, eemFormAppl);
			}
			
			// No exceptions
			if (StringUtil.nonNullTrim(filterVO.getMessage()).equals("")) {
				
				//Begin: Added for IFOX-00364414
				try {
					filterVO.setBeqCheck(StringUtil.nonNullTrim( EEMProfileSettings.getCalendarProfileItem (
							(String) new com.ps.mss.web.helper.SessionHelper(request).getAttribute(SessionManager.EEMDB),
							filterVO.getCustomerId(), EEMProfileSettings.BEQCHECK)));
					//CR-IFOX-00408061. START Functionality Not Approved
					/*filterVO.setDentalApplFlag(EEMProfileSettings.getCalendarProfileItem(eemDb,
							filterVO.getCustomerId(),EEMProfileSettings.DENTALAPP));*/
					//CR-IFOX-00408061. END
				} catch (Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug(" EEMAction : eemApplUpdate : " + e.getMessage());
//					logger.error(" EEMAction : eemApplUpdate : " + e.getMessage());
				}
				//End: Added for IFOX-00364414
				
				// Update the details
				if (!service.setApplDetails(conn, eemDb, filterVO)) {
					// Reset back to form when update fails
					eemFormAppl.setMessage(filterVO.getMessage());
					
					//DUPAPPL-start
					if(eemFormAppl.getMessage().equalsIgnoreCase("No Override Duplicate Application found. \n") 
							|| eemFormAppl.getMessage().equalsIgnoreCase("Exsisting Duplicate Application Found. \n") ){
						eemFormAppl.setAppDuplicateCheck("N");	
					}
					//End
					
					EEMApplHelper.setFormToVO(eemFormAppl, filterVO, sessionHelper);
				}
				
				
				filterVO = service.getOevDetails(conn, filterVO);
				if(filterVO.getOevCallAttempts()==null){
					//System.out.println(" in action Oev list is null");
					sessionHelper.getSession().setAttribute(
							EEMConstants.SESSION_OEV_SEARCH1, null);
				}
				else{
				//	System.out.println(" oevCal size"+filterVO.getOevCallAttempts());
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_OEV_SEARCH1, filterVO.getOevCallAttempts());
				}
				if(filterVO.getOevCallStatus()==null){
					sessionHelper.getSession().setAttribute(
							EEMConstants.SESSION_OEV_SEARCH2, null);
				}
				else{
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_OEV_SEARCH2, filterVO.getOevCallStatus());
				}
				if(filterVO.getOevCallStatusSaved()==null){
					sessionHelper.getSession().setAttribute(
							EEMConstants.SESSION_OEV_SEARCH3, null);
				}
				else{
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_OEV_SEARCH3,filterVO.getOevCallStatusSaved());
				}
				if(filterVO.getOevRetStatus()==null){
					sessionHelper.getSession().setAttribute(
							EEMConstants.SESSION_OEV_SEARCH4, null);
				}
				else{
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_OEV_SEARCH4,filterVO.getOevRetStatus());
				}
				if(filterVO.getOevRetStatusSaved()==null){
					sessionHelper.getSession().setAttribute(
							EEMConstants.SESSION_OEV_SEARCH5, null);
				}
				else{
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_OEV_SEARCH5,filterVO.getOevRetStatusSaved());
				}
				if(filterVO.getOevRetStatus()==null){
					//System.out.println(" in action Oev list is null");
					sessionHelper.getSession().setAttribute(
							EEMConstants.SESSION_OEV_SEARCH6, null);
				}
				else{
					//System.out.println(" oevCal size"+filterVO.getOevRetStatus());
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_OEV_SEARCH6, filterVO.getReturnCalls());
				}
			} 
			
		} else {
			filterVO.setMessage(eemFormAppl.getMessage());
			service.getErrorDetails(new EEMApplDao(), conn, filterVO);
		}
		
		EEMApplHelper.setVOToForm(filterVO, eemFormAppl, sessionHelper);
		EEMApplHelper.loadLookUps(conn, eemFormAppl, sessionHelper);
		EEMApplHelper.setAttestationList(eemFormAppl);
		//00427630-OPEN : TSA Supress LEP process Platino Members - start
		EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
		boolean lepTrgSkip = eemDao.getLepPlatinoFlag(conn, filterVO);
		if(lepTrgSkip)
			eemFormAppl.setSuppLepPlatino("true");
		else
			eemFormAppl.setSuppLepPlatino("false");
			
		//00427630-OPEN : TSA Supress LEP process Platino Members - end
		// Set Application Status
		EEMApplHelper.setApplicationStatus(eemFormAppl, sessionHelper);
		long endTime = System.currentTimeMillis();
		replogger.debug("M360|Application Update|"+sessionHelper.getMfId()+"|"+(endTime - startTime)+" ms|");
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMApplHelper.getPage(eemFormAppl));
	}
	}
	private ActionForward eemApplCitySearch(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplForm eemFormAppl = (EEMApplForm) form;
		
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		
		try {
			eemFormAppl.setIsSubscriberIdRequired(EEMProfileSettings
					.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),
							"SUBSCID"));
			/** Triple S BasePlus Migration START **/
			//TSA Changes :Start
			eemFormAppl.setIsSubscriberIdMandatory(EEMProfileSettings
					.getCalendarProfileText(eemDb, sessionHelper.getMfId(),
							"SUBSCID"));
			//TSA Changes :End
			/** Triple S BasePlus Migration END **/
		} catch (Exception e) {
		
		}
		
		String zip5 = StringUtil.nonNullTrim(request.getParameter("zip5"));
		//if (!zip5.equals("")) {	// Removing the condition for BasePlus
			eemFormAppl.setSearchZip5(zip5);
			eemFormAppl.setSearchZip4(StringUtil.nonNullTrim(request.getParameter("zip4")));
			eemFormAppl.setSourceCity(StringUtil.nonNullTrim(request.getParameter("sourceCity")));
			eemFormAppl.setSourceState(StringUtil.nonNullTrim(request.getParameter("sourceState")));
			eemFormAppl.setSourceZip5(StringUtil.nonNullTrim(request.getParameter("sourceZip5")));
			eemFormAppl.setSourceZip4(StringUtil.nonNullTrim(request.getParameter("sourceZip4")));
		//}
		EEMApplService service = context.getService();
		eemFormAppl.setLstCity(service.getCityNames(conn, eemFormAppl.getSearchZip5(), eemFormAppl.getSearchZip4()));
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_CITY_ZIP_SEARCH);
	}
	
	private ActionForward eemBillMbrGrpSearch(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillInvoiceForm eemForm = (EEMBillInvoiceForm) form;
		if (!StringUtil.nonNullTrim(request.getParameter("id")).equals(""))
			eemForm.setSearchTransGrp(StringUtil.nonNullTrim(request.getParameter("id")));
		if (!StringUtil.nonNullTrim(request.getParameter("mbrgrp")).equals(""))
			eemForm.setSelectedMbrGrpInd(StringUtil.nonNullTrim(request.getParameter("mbrgrp")));
		
		EEMBillDao billDao = new EEMBillDao();
		try {
			if (!StringUtil.nonNullTrim(eemForm.getSearchTransGrp()).equals("") ||
					!StringUtil.nonNullTrim(eemForm.getSearchTransName()).equals("") ||
					!StringUtil.nonNullTrim(eemForm.getSearchTransLastName()).equals("") ) {
				eemForm.setLstMbrGrp(billDao.getBillMbrGrpList(conn, sessionHelper.getMfId(), eemForm.getSearchTransGrp(), 
										eemForm.getSearchTransName(), eemForm.getSearchTransLastName(), eemForm.getSelectedMbrGrpInd()));
			}
			////Added for BilMbrGrp Search JSP Issue : Start
			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			String mbrLabel = EEMProfileSettings
			.getCalendarProfileText(eemDb, sessionHelper.getMfId(),
					"MBRIDLIT");
			eemForm.setMbrLabel(mbrLabel);
			////Added for BilMbrGrp Search JSP Issue : End
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILL_MBRGRP_SEARCH);
	}
	
	private ActionForward eemApplProdSearch(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplForm eemFormAppl = (EEMApplForm) form;
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		
		try {
			eemFormAppl.setIsSubscriberIdRequired(EEMProfileSettings
					.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),
							"SUBSCID"));
			/** Triple S BasePlus Migration START **/	
			//TSA Changes :Start
			eemFormAppl.setIsSubscriberIdMandatory(EEMProfileSettings
					.getCalendarProfileText(eemDb, sessionHelper.getMfId(),
							"SUBSCID"));
			//TSA Changes :End
			/** Triple S BasePlus Migration END **/
			
		} catch (Exception e) {
		
		}
		
		String covDt = request.getParameter("covDt");
		String prodName=request.getParameter("prod");
		
		if(!StringUtil.nonNullTrim(prodName).equals("")){
			prodName=prodName.replace("^","+");
		}
	if (!StringUtil.nonNullTrim(covDt).equals("")) {
			eemFormAppl.setReqDtCov(covDt);
			eemFormAppl.setSearchGroup(request.getParameter("group"));
			eemFormAppl.setSearchProd(prodName);
			eemFormAppl.setSearchGroupId(request.getParameter("groupId"));
			eemFormAppl.setSearchProdId(request.getParameter("prodId"));
			eemFormAppl.setSearchZip5(request.getParameter("zip5"));
			eemFormAppl.setSearchZip4(request.getParameter("zip4"));
			eemFormAppl.setSearchPlan(request.getParameter("plan"));
			eemFormAppl.setSearchPbp(request.getParameter("pbp"));
			eemFormAppl.setSearchSegment(request.getParameter("segment"));
			eemFormAppl.setApplType(request.getParameter("applType"));
		}
		
		EEMApplService service = context.getService();
		EEMApplicationVO filterVO = new EEMApplicationVO();
		EEMApplHelper.setFormToVO(eemFormAppl, filterVO, sessionHelper);
		filterVO.setEnrollGroupName(filterVO.getSearchGroup());
		filterVO.setEnrollProdName(filterVO.getSearchProd());
		filterVO.setPerZip5(filterVO.getSearchZip5());
		filterVO.setPerZip4(filterVO.getSearchZip4());
		filterVO.setEnrollPlan(filterVO.getSearchPlan());
		filterVO.setEnrollPbp(filterVO.getSearchPbp());
		filterVO.setEnrollSegment(filterVO.getSearchSegment());
		filterVO.setOutOfArea("");
		EEMApplicationVO objVO = service.getProducts(conn, filterVO);
		EEMApplHelper.setVOToForm(filterVO, eemFormAppl, sessionHelper);
		if (objVO != null) {
			eemFormAppl.setProducts(objVO.getProducts());
			eemFormAppl.setMessage(objVO.getMessage());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_PROD_SEARCH);
	}		

	private ActionForward eemApplPcpSearch(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplForm eemFormAppl = (EEMApplForm) form;
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		
     try {
    	 	//Access health PCP CR- Start
			String npiInd = (String) sessionHelper.getAttribute("NPIIND");
			if(null == npiInd || npiInd.trim().equals(""))
			{
				npiInd = EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(), "NPIIND");
				sessionHelper.setAttribute("NPIIND", npiInd);
			}
			//Access health PCP CR- End
			
		} catch (Exception e) {
		
		}
		String covDt = request.getParameter("covDt");
		if (!StringUtil.nonNullTrim(covDt).equals("")) {
			eemFormAppl.setReqDtCov(covDt);
			eemFormAppl.setSearchDocName(request.getParameter("docName"));
			eemFormAppl.setSearchCurrPatnt(request.getParameter("currPatient"));
		}
		
		EEMApplService service = context.getService();
		EEMApplicationVO filterVO = new EEMApplicationVO();
		EEMApplHelper.setFormToVO(eemFormAppl, filterVO, sessionHelper);
		
		filterVO.setPcpOfficeCd(filterVO.getSearchOffCd());
		filterVO.setPcpName(filterVO.getSearchDocName());
		filterVO.setPcpCurrPatnt(filterVO.getSearchCurrPatnt());
		filterVO.setPcpLocationId(filterVO.getSearchLocId());
		//Access health PCP CR- Start 
		filterVO.setPcpNpiId(filterVO.getSearchNpiId());
		//Access health PCP CR- End
		filterVO.setLstPcpNames(service.getPcpNames(conn, filterVO));
		
		EEMApplHelper.setVOToForm(filterVO, eemFormAppl, sessionHelper);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_PCP_SEARCH);
	}
	
	private ActionForward eemEligCheck(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplForm eemApplForm = (EEMApplForm) form;
		String eemDb = (String) sessionHelper.getAttribute(SessionManager.EEMDB);
		/** Triple S BasePlus Migration START **/
		// CMS FEB 2016 Release - Start
		String beqCheck = "";
		// CMS FEB 2016 Release - End
		/** Triple S BasePlus Migration END **/
		try {
			/** Triple S BasePlus Migration START **/
			// CMS FEB 2016 Release - Start
			beqCheck = EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),
					EEMProfileSettings.BEQCHECK);
			// CMS FEB 2016 Release - End
			/** Triple S BasePlus Migration END **/
			
			eemApplForm.setIsSubscriberIdRequired(
					EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(), "SUBSCID"));
			/** Triple S BasePlus Migration START **/
			//TSA Changes :Start
			eemApplForm.setIsSubscriberIdMandatory(EEMProfileSettings
					.getCalendarProfileText(eemDb, sessionHelper.getMfId(),
							"SUBSCID"));
			//TSA Changes :End
			/** Triple S BasePlus Migration END **/
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//logger.error(e.getMessage());
		}
		// Added for SSNRI changes,Calling method to determine if Medicare ID is HIC/MBI : START
		if (!StringUtil.nonNullTrim(eemApplForm.getMbrHicNbr()).equals("")) {
			String isHicOrMbi = isHicOrMbi(eemApplForm.getMbrHicNbr());
			eemApplForm.setIsHicOrMbi(isHicOrMbi);
			if (eemApplForm.getIsHicOrMbi().equals("mbi"))
				eemApplForm.setMbiNbr(eemApplForm.getMbrHicNbr());
		}
		// Added for SSNRI changes,Calling method to determine if Medicare ID isHIC/MBI : END
		// SSNRI 2017 :Start
		MBD mbd = context.getService().verifyEligibility(conn, eemApplForm.getMbrHicNbr(), eemApplForm.getMbrLastName(),
				eemApplForm.getMbrBirthDt(), eemApplForm.getCustomerNbr(), eemDb, beqCheck, eemApplForm.getIsHicOrMbi());
		// SSNRI 2017 :End
		if (mbd != null) {
			EEMApplHelper.formatMBD(mbd, eemApplForm);
		} else {
			eemApplForm.setMbd(new MBD());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_ELIG_CHECK);
	}

	/*private ActionForward eemLetterReviewMenu(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		
		
		context.setSelectedMenu(EEMConstants.MENU_LETTER_REVIEW);
		String selectedTab = StringUtil.nonNullTrim(context.getLetterReviewTab());
		if (selectedTab.equals("")) {
			selectedTab = EEMConstants.EEM_LTR_TAB_DETAILS;
			context.setLetterReviewTab(selectedTab);
			//EEMLetterReviewDetailForm eemLetterForm = new EEMLetterReviewDetailForm();
			//EEMLetterReviewHelper.clearForm(eemLetterForm);
			//EEMLetterReviewHelper.setFormLists(eemLetterForm);
			//request.setAttribute(EEMConstants.EEM_LETTER_REVIEW_DETAILS_FORM, eemLetterForm);
			//return mapping.findForward(EEMConstants.EEM_LETTER_REVIEW);
		}

		if (selectedTab.equals(EEMConstants.EEM_LTR_TAB_GENERATION)) {
			context.setLetterReviewTab(EEMConstants.EEM_LTR_TAB_GENERATION);
			return mapping.findForward(EEMConstants.EEM_LETTER_REVIEW_GENERATE);		
		}
		
		if (selectedTab.equals(EEMConstants.EEM_LTR_TAB_DETAILS)) {
			EEMLetterReviewDetailForm eemLetterForm = null;
			if (!(form instanceof EEMLetterReviewDetailForm)) {
				eemLetterForm = EEMLetterReviewHelper.getEEMDetailForm(sessionHelper);
				if (eemLetterForm == null) {
					eemLetterForm = new EEMLetterReviewDetailForm();
					EEMLetterReviewHelper.clearForm(eemLetterForm);
				}
				request.setAttribute(EEMConstants.EEM_LETTER_REVIEW_DETAILS_FORM, eemLetterForm);			
			}
			EEMLetterReviewHelper.setFormLists(eemLetterForm);			
			EEMLetterReviewManager mgr = new EEMLetterReviewManager();
			mgr.letterReviewSelect(conn,sessionHelper,context,eemLetterForm,false);
			return mapping.findForward(EEMConstants.EEM_LETTER_REVIEW);
		}
		
		return mapping.findForward("eemError");

	}*/

	private ActionForward eemLetterReviewTabSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		context.setSelectedMenu(EEMConstants.MENU_LETTER_REVIEW);
		
		EEMSubMenuForm eemLetterForm = (EEMSubMenuForm)form;
		context.setLetterReviewTab(eemLetterForm.getSelectedSubMenuTab());
		
		if (form instanceof EEMLetterReviewDetailForm) {
			EEMLetterReviewHelper.saveEEMDetailForm(sessionHelper,(EEMLetterReviewDetailForm)eemLetterForm);
		}
		
		if (EEMConstants.EEM_LTR_TAB_GENERATION.equals(eemLetterForm.getSelectedSubMenuTab())) {
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.EEM_LETTER_REVIEW_GENERATE);
		}
		//Begin: Added for Letter Review Upload
		if (EEMConstants.LTR_REVIEW_UPLOAD.equals(eemLetterForm.getSelectedSubMenuTab())) {
			logger.info(LoggerConstants.methodEndLevel());
			return eemLetterReviewUpload(conn, sessionHelper, context, mapping, eemLetterForm, request);
		}
		//End: Added for Letter Review Upload
		//Begin: Added for LetterQC
		if (EEMConstants.LTR_REVIEW_QC.equals(eemLetterForm.getSelectedSubMenuTab())) {
			EEMLetterReviewQCForm ltrQCform = new EEMLetterReviewQCForm();
			ltrQCform.setLstBatchId(null);
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.EEM_LTR_QC);
		}
		//End: Added for LetterQC
		
		//IFOX-00426356: Attachment CR Start
		if (EEMConstants.LTR_ATTACHMENT.equals(eemLetterForm.getSelectedSubMenuTab())) {
			logger.info(LoggerConstants.methodEndLevel());
			EEMLetterReviewAttachmentForm eemLetterAttachForm = null;
			if (!(form instanceof EEMLetterReviewAttachmentForm)) {
				eemLetterAttachForm = EEMLetterReviewHelper.getEEMAttachForm(sessionHelper);
				if (eemLetterAttachForm == null) {
					eemLetterAttachForm = new EEMLetterReviewAttachmentForm();
					//EEMLetterReviewHelper.clearForm(eemLetterAttachForm);eemLetterAttachForm
				}
				request.setAttribute(EEMConstants.EEM_LETTER_REVIEW_ATTACHMENT_FORM, eemLetterAttachForm);			
			}
			EEMLetterReviewHelper.setFormLists(eemLetterAttachForm);
			return mapping.findForward(EEMConstants.EEM_LTR_ATTACHMENT);
		}
		
		//IFOX-00426356: Attachment CR End
		EEMLetterReviewDetailForm eemLetterDetailForm = null;
		if (!(form instanceof EEMLetterReviewDetailForm)) {
			eemLetterDetailForm = EEMLetterReviewHelper.getEEMDetailForm(sessionHelper);
			if (eemLetterDetailForm == null) {
				eemLetterDetailForm = new EEMLetterReviewDetailForm();
				EEMLetterReviewHelper.clearForm(eemLetterDetailForm);
			}
			request.setAttribute(EEMConstants.EEM_LETTER_REVIEW_DETAILS_FORM, eemLetterDetailForm);			
		}
		/** Triple S BasePlus Migration START **/
		// Added for TSA changes for Member Id Label Change :Start
		String eemDb = (String) sessionHelper.getAttribute(SessionManager.EEMDB);
		String mbrLabel = EEMProfileSettings.getCalendarProfileText(eemDb, sessionHelper.getMfId(), "MBRIDLIT");
		eemLetterDetailForm.setMbrLabel(mbrLabel);
		// Added for TSA changes for Member Id Label Change :End
		/** Triple S BasePlus Migration END **/
		EEMLetterReviewHelper.setFormLists(eemLetterDetailForm);	
		EEMLetterReviewManager mgr = new EEMLetterReviewManager();
		mgr.letterReviewSelect(conn,sessionHelper,context,eemLetterDetailForm,false);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LETTER_REVIEW);
	}

	private ActionForward eemLetterCorrMbrUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterReviewManager mgr = new EEMLetterReviewManager();
		mgr.letterCorrMbrUpdate(conn,sessionHelper,context,(EEMLetterReviewDetailForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LETTER_REVIEW);
	}

	private ActionForward eemLetterReviewGenerate(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterReviewGenerateForm eemLetterForm = (EEMLetterReviewGenerateForm)form;
		EEMLetterReviewManager mgr = new EEMLetterReviewManager();
		mgr.letterGenerateRequest(conn,sessionHelper,context,(EEMLetterReviewGenerateForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LETTER_REVIEW_GENERATE);
	}

	private ActionForward eemLetterReviewSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterReviewManager mgr = new EEMLetterReviewManager();
		mgr.letterReviewSearch(conn,sessionHelper,context,(EEMLetterReviewDetailForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LETTER_REVIEW);
	}
	private ActionForward eemLetterReviewSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request, String move) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterReviewManager mgr = new EEMLetterReviewManager();
		mgr.letterReviewSearchPage(conn,sessionHelper,context,(EEMLetterReviewDetailForm)form,move);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LETTER_REVIEW);
	}
	private ActionForward eemLetterReviewSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterReviewManager mgr = new EEMLetterReviewManager();
		mgr.letterReviewSelect(conn,sessionHelper,context,(EEMLetterReviewDetailForm)form,true);
		/** Triple S BasePlus Migration START **/
		// Added for TSA changes for Member Id Label Change :Start
		EEMLetterReviewDetailForm letterForm = (EEMLetterReviewDetailForm) form;
		String eemDb = (String) sessionHelper.getAttribute(SessionManager.EEMDB);
		String mbrLabel = EEMProfileSettings.getCalendarProfileText(eemDb, sessionHelper.getMfId(), "MBRIDLIT");
		letterForm.setMbrLabel(mbrLabel);
		// Added for TSA changes for Member Id Label Change :End
		/** Triple S BasePlus Migration END **/
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LETTER_REVIEW);
	}

	private ActionForward eemLetterReviewClearSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws SQLException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterReviewVO letterReviewVO = context.getLetterReviewVO();
		letterReviewVO.setListSearchResults(null);
		
		EEMLetterReviewDetailForm eemLetterDetailForm = (EEMLetterReviewDetailForm)form;
		EEMLetterReviewHelper.clearForm(eemLetterDetailForm);
		EEMLetterReviewHelper.setFormLists(eemLetterDetailForm);
		eemLetterDetailForm.setDisplayCorrMbr(new EmCorrMbrVO());
		EEMLetterReviewManager mgr = new EEMLetterReviewManager();
		mgr.letterReviewSelect(conn,sessionHelper,context,eemLetterDetailForm,false);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LETTER_REVIEW);
	}

	private ActionForward eemBillingMenu(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		String achDraftTabEnable = EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(), EEMProfileSettings.ACHDRAFTTB);
		context.setAchDraftTab(achDraftTabEnable);
		context.setSelectedMenu(EEMConstants.MENU_BILLING);
		String selectedTab = StringUtil.nonNullTrim(context.getBillingTab());
		if (selectedTab.equals("")) {
			selectedTab = EEMConstants.EEM_BILL_TAB_INVOICE;
			//selectedTab = EEMConstants.EEM_BILL_TAB_DRAFT;
			context.setBillingTab(selectedTab);
		}

		if (selectedTab.equals(EEMConstants.EEM_BILL_TAB_PAYMENTS)) {
			context.setBillingTab(EEMConstants.EEM_BILL_TAB_PAYMENTS);
			EEMBillPaymentsForm eemBillPaymentsForm = EEMBillingHelper.getEEMFormPay(sessionHelper);
			if (eemBillPaymentsForm == null) {
				eemBillPaymentsForm = new EEMBillPaymentsForm();
				EEMBillingHelper.clearPaymentsForm(eemBillPaymentsForm);
			}
			request.setAttribute(EEMConstants.EEM_BILLING_PAYMENTS_FORM, eemBillPaymentsForm);
			eemBillPaymentsForm.setSelectedSubMenuTab(selectedTab);
			
			EEMBillingHelper.setPaymentsFormLists(eemBillPaymentsForm);
			if (eemBillPaymentsForm.isNewPaymentScreen()) {
				if (eemBillPaymentsForm.getNewHeaderDisplayState().equals(EEMConstants.EEM_MBR_SCREEN_EDIT)) {
					mgr.newBillPaymentHeader(conn,sessionHelper,context, eemBillPaymentsForm, eemBillPaymentsForm.getDisplayPaymentsHeader());
					logger.info(LoggerConstants.methodEndLevel());
					return mapping.findForward(EEMConstants.EEM_BILLING_PAYMENTS_NEW);
				} else {
					logger.info(LoggerConstants.methodEndLevel());
					return eemBillPaymentAddDetails(conn, sessionHelper, context, mapping, eemBillPaymentsForm, request);
				}
			} else {
				mgr.billPaymentsDetailSelect(conn, sessionHelper, context, eemBillPaymentsForm);
				logger.info(LoggerConstants.methodEndLevel());
				return mapping.findForward(EEMConstants.EEM_BILLING_PAYMENTS);
			}
		}

		if (selectedTab.equals(EEMConstants.EEM_BILL_TAB_DRAFT)) {
			context.setBillingTab(EEMConstants.EEM_BILL_TAB_DRAFT);
			EEMBillDraftForm eemBillDraftForm = EEMBillingHelper.getEEMFormDraft(sessionHelper);
			if (eemBillDraftForm == null) {
				eemBillDraftForm = new EEMBillDraftForm();
				EEMBillingHelper.clearDraftForm(eemBillDraftForm);
			}
			request.setAttribute(EEMConstants.EEM_BILLING_DRAFT_FORM, eemBillDraftForm);
			eemBillDraftForm.setSelectedSubMenuTab(selectedTab);
			
			EEMBillingHelper.setDraftFormLists(eemBillDraftForm);
			//mgr.billInvoiceDetailSelect(conn, sessionHelper, context, eemBillDraftForm);
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.EEM_BILLING_DRAFT);		
		}
		
		if (selectedTab.equals(EEMConstants.EEM_BILL_TAB_INVOICE)) {
			context.setBillingTab(EEMConstants.EEM_BILL_TAB_INVOICE);
			EEMBillInvoiceForm eemBillInvoiceForm = EEMBillingHelper.getEEMFormInv(sessionHelper);
			if (eemBillInvoiceForm == null) {
				eemBillInvoiceForm = new EEMBillInvoiceForm();
				EEMBillingHelper.clearInvoiceForm(eemBillInvoiceForm);
			}
			request.setAttribute(EEMConstants.EEM_BILLING_INVOICE_FORM, eemBillInvoiceForm);
			eemBillInvoiceForm.setSelectedSubMenuTab(selectedTab);
			
			EEMBillingHelper.setInvoiceFormLists(eemBillInvoiceForm);
			mgr.billInvoiceDetailSelect(conn, sessionHelper, context, eemBillInvoiceForm);
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.EEM_BILLING_INVOICE);		
		}
		
		if (selectedTab.equals(EEMConstants.EEM_BILL_TAB_MEMBER_PAYMENTS)) {
			context.setBillingTab(EEMConstants.EEM_BILL_TAB_MEMBER_PAYMENTS);
			EEMBillMembPaymentsForm eemBillMembPaymentsForm = EEMBillingHelper.getEEMFormMembPay(sessionHelper);
			if (eemBillMembPaymentsForm == null) {
				eemBillMembPaymentsForm = new EEMBillMembPaymentsForm();
				EEMBillingHelper.clearMembPaymentsForm(eemBillMembPaymentsForm);
			}
			request.setAttribute(EEMConstants.EEM_BILLING_MEMB_PAYMENTS_FORM, eemBillMembPaymentsForm);
			eemBillMembPaymentsForm.setSelectedSubMenuTab(selectedTab);
			
			EEMBillingHelper.setMembPaymentsFormLists(eemBillMembPaymentsForm);
			mgr.billMembPaymentsDetailSelect(conn, sessionHelper, context, eemBillMembPaymentsForm);
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.EEM_BILLING_MEMBER_PAYMENTS);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward("eemError");

	}

	private ActionForward eemBillingTabSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		context.setSelectedMenu(EEMConstants.MENU_BILLING);
		
		EEMSubMenuForm eemBillingForm = (EEMSubMenuForm)form;
		String selectedTab = eemBillingForm.getSelectedSubMenuTab();
		context.setBillingTab(selectedTab);
		
		if(form instanceof EEMBillDraftForm){
			EEMBillingHelper.saveEEMFormDraft(sessionHelper, (EEMBillDraftForm)form);
		}else if (form instanceof EEMBillPaymentsForm) {
			EEMBillingHelper.saveEEMFormPay(sessionHelper, (EEMBillPaymentsForm)form);
		} else if (form instanceof EEMBillMembPaymentsForm) {
			EEMBillingHelper.saveEEMFormMembPay(sessionHelper, (EEMBillMembPaymentsForm)form);
		} else if (form instanceof EEMBillInvoiceForm) {
			EEMBillingHelper.saveEEMFormInv(sessionHelper, (EEMBillInvoiceForm)form);
		}

		if (selectedTab.equals(EEMConstants.EEM_BILL_TAB_PAYMENTS)) {
			EEMBillPaymentsForm eemBillPaymentsForm = null;
			if (!(form instanceof EEMBillPaymentsForm)) {
				eemBillPaymentsForm = EEMBillingHelper.getEEMFormPay(sessionHelper);
				if (eemBillPaymentsForm == null) {
					eemBillPaymentsForm = new EEMBillPaymentsForm();
					EEMBillingHelper.clearPaymentsForm(eemBillPaymentsForm);
				}
				request.setAttribute(EEMConstants.EEM_BILLING_PAYMENTS_FORM, eemBillPaymentsForm);			
			}
			logger.info(LoggerConstants.methodEndLevel());
			return eemBillingMenu(conn, sessionHelper, context, mapping, eemBillPaymentsForm, request);
		}
		if (selectedTab.equals(EEMConstants.EEM_BILL_TAB_MEMBER_PAYMENTS)) {
			EEMBillMembPaymentsForm eemBillMembPaymentsForm = null;
			if (!(form instanceof EEMBillMembPaymentsForm)) {
				eemBillMembPaymentsForm = EEMBillingHelper.getEEMFormMembPay(sessionHelper);
				if (eemBillMembPaymentsForm == null) {
					eemBillMembPaymentsForm = new EEMBillMembPaymentsForm();
					EEMBillingHelper.clearMembPaymentsForm(eemBillMembPaymentsForm);
				}
				request.setAttribute(EEMConstants.EEM_BILLING_MEMB_PAYMENTS_FORM, eemBillMembPaymentsForm);			
			}
			logger.info(LoggerConstants.methodEndLevel());
			return eemBillingMenu(conn, sessionHelper, context, mapping, eemBillMembPaymentsForm, request);
		}

		if (selectedTab.equals(EEMConstants.EEM_BILL_TAB_INVOICE)) {
			EEMBillInvoiceForm eemBillInvoiceForm = null;
			if (!(form instanceof EEMBillInvoiceForm)) {
				eemBillInvoiceForm = EEMBillingHelper.getEEMFormInv(sessionHelper);
				if (eemBillInvoiceForm == null) {
					eemBillInvoiceForm = new EEMBillInvoiceForm();
					EEMBillingHelper.clearInvoiceForm(eemBillInvoiceForm);
				}
				request.setAttribute(EEMConstants.EEM_BILLING_INVOICE_FORM, eemBillInvoiceForm);			
			}
			logger.info(LoggerConstants.methodEndLevel());
			return eemBillingMenu(conn, sessionHelper, context, mapping, eemBillInvoiceForm, request);		
		}
		
		if (selectedTab.equals(EEMConstants.EEM_BILL_TAB_DRAFT)) {
			EEMBillDraftForm eemBillDraftForm = null;
			if (!(form instanceof EEMBillDraftForm)) {
				eemBillDraftForm = EEMBillingHelper.getEEMFormDraft(sessionHelper);
				if (eemBillDraftForm == null) {
					eemBillDraftForm = new EEMBillDraftForm();
					EEMBillingHelper.clearDraftForm(eemBillDraftForm);
				}
				request.setAttribute(EEMConstants.EEM_BILLING_DRAFT_FORM, eemBillDraftForm);			
			}
			logger.info(LoggerConstants.methodEndLevel());
			return eemBillingMenu(conn, sessionHelper, context, mapping, eemBillDraftForm, request);		
		}

		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward("eemError");
		
	}

	private ActionForward eemBillInvoiceTransfer(Connection conn, String eemDb, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		if (mgr.billInvoiceTransfer(conn,eemDb, sessionHelper,context,(EEMBillInvoiceForm)form)) {
			((EEMBillInvoiceForm)form).setTransExpanded(false);
			logger.info(LoggerConstants.methodEndLevel());
			return eemBillInvoiceSearchPage(conn, sessionHelper, context, mapping, form, request, "");
		}
		
		mgr.billInvoiceDetailSelect(conn,sessionHelper,context,(EEMBillInvoiceForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_INVOICE);
	}
	
	private ActionForward eemBillInvoiceSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		long startTime = System.currentTimeMillis();
		EEMBillingManager mgr = new EEMBillingManager();
		// SSNRI 2017 -Determining whether the searched hic number is MBI or HIC: start
				String medicaidID = ((EEMBillInvoiceForm) form).getSearchHicNbr();
				String flag = "";
				if (!StringUtil.nonNullTrim(medicaidID).equals(""))
					flag = isHicOrMbi(medicaidID);
		/*mgr.billInvoiceSearch(conn,sessionHelper,context,(EEMBillInvoiceForm)form);*/
			
				mgr.billInvoiceSearch(conn,sessionHelper,context,(EEMBillInvoiceForm)form, flag);
				
		// SSNRI 2017 -Determining whether the searched hic number is MBI or HIC :end
				long endTime = System.currentTimeMillis();
			replogger.debug("Billing|Invoice Search|"+sessionHelper.getMfId()+"|"+(endTime - startTime)+" ms|");
				logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_INVOICE);
	}
	
	
	private ActionForward eemBillDraftSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		// SSNRI 2017 -Determining whether the searched hic number is MBI or HIC: start
		String medicaidID = ((EEMBillDraftForm) form).getSearchHicNbr();
		String flag = "";
		if (!StringUtil.nonNullTrim(medicaidID).equals(""))
			flag = isHicOrMbi(medicaidID);
		
		mgr.billDraftSearch(conn,sessionHelper,context,(EEMBillDraftForm)form, flag);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_DRAFT);
	}
	
	private ActionForward billPaymentsSubSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.billPaymentsSubSearchPage(conn,sessionHelper,context,(EEMBillPaymentsForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_PAYMENTS);
	}
	
	private ActionForward eemBillPaymentsSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		long startTime = System.currentTimeMillis();
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.billPaymentsSearch(conn,sessionHelper,context,(EEMBillPaymentsForm)form);
		long endTime = System.currentTimeMillis();
		replogger.debug("Billing|Payment Search|"+sessionHelper.getMfId()+"|"+(endTime - startTime)+" ms|");
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_PAYMENTS);
	}
	private ActionForward eemBillMembPaymentsSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		
		// SSNRI 2017 -Determining whether the searched hic number is MBI or HIC: start
		String medicaidID = ((EEMBillMembPaymentsForm) form).getSearchHicNbr();
		String flag = "";
		if (!StringUtil.nonNullTrim(medicaidID).equals(""))
			flag = isHicOrMbi(medicaidID);
		/*mgr.billMembPaymentsSearch(conn,sessionHelper,context,(EEMBillMembPaymentsForm)form);*/
		mgr.billMembPaymentsSearch(conn,sessionHelper,context,(EEMBillMembPaymentsForm)form, flag);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_MEMBER_PAYMENTS);
	}
	
	private ActionForward eemBillInvoiceSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.billInvoiceSelect(conn,sessionHelper,context,(EEMBillInvoiceForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_INVOICE);
	}
	
	
	private ActionForward eemBillDraftSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.billDraftSelect(conn,sessionHelper,context,(EEMBillDraftForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_DRAFT);
	}
	
	
	private ActionForward eemBillPaymentsSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.billPaymentsSelect(conn,sessionHelper,context,(EEMBillPaymentsForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_PAYMENTS);
	}
	
	private ActionForward eemBillInvoiceSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request, String move) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		
		// SSNRI 2017 -Determining whether the searched hic number is MBI or HIC: start
		String medicaidID = ((EEMBillInvoiceForm) form).getSearchHicNbr();
		String flag = "";
		if (!StringUtil.nonNullTrim(medicaidID).equals(""))
			flag = isHicOrMbi(medicaidID);
		/*mgr.billInvoiceSearchPage(conn,sessionHelper,context,(EEMBillInvoiceForm)form, move);*/
		
		mgr.billInvoiceSearchPage(conn,sessionHelper,context,(EEMBillInvoiceForm)form, move,flag);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_INVOICE);
	}
		
	private ActionForward eemBillDraftSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request, String move) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.billDraftSearchPage(conn,sessionHelper,context,(EEMBillDraftForm)form, move, null);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_DRAFT);
	}	
	
	private ActionForward eemBillPaymentsSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request, String move) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.billPaymentsSearchPage(conn,sessionHelper,context,(EEMBillPaymentsForm)form, move);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_PAYMENTS);
	}
	private ActionForward eemBillMembPaymentsSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request, String move) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		// SSNRI 2017 -Determining whether the searched hic number is MBI or HIC: start
				String medicaidID = ((EEMBillMembPaymentsForm) form).getSearchHicNbr();
				String flag = "";
				if (!StringUtil.nonNullTrim(medicaidID).equals(""))
					flag = isHicOrMbi(medicaidID);
				/*mgr.billMembPaymentsSearchPage(conn,sessionHelper,context,(EEMBillMembPaymentsForm)form, move);*/
				mgr.billMembPaymentsSearchPage(conn,sessionHelper,context,(EEMBillMembPaymentsForm)form, move, flag);
				logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_MEMBER_PAYMENTS);
	}
	
	private ActionForward eemBillInvoiceDetailSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.billInvoiceDetailSelect(conn,sessionHelper,context,(EEMBillInvoiceForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_INVOICE);
	}
	

	private ActionForward eemBillDraftDetailSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.billDraftDetailSelect(conn,sessionHelper,context,(EEMBillDraftForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_DRAFT);
	}
	
	
	private ActionForward eemBillPaymentsDetailSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.billInvoiceDetailSelect(conn,sessionHelper,context,(EEMBillInvoiceForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_PAYMENTS);
	}
	
	private ActionForward eemBillInvoiceDetailPage(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request, String move) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.billInvoiceDetailPage(conn,sessionHelper,context,(EEMBillInvoiceForm)form, move);
		((EEMBillInvoiceForm)form).setTransExpanded(false);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_INVOICE);
	}
	
	private ActionForward eemBillDraftDetailPage(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request, String move) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.billInvoiceDetailPage(conn,sessionHelper,context,(EEMBillInvoiceForm)form, move);
		((EEMBillInvoiceForm)form).setTransExpanded(false);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_DRAFT);
	}
	
	
	private ActionForward eemBillPaymentsDetailPage(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request, String move) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.billPaymentsDetailPage(conn,sessionHelper,context,(EEMBillPaymentsForm)form, move);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_PAYMENTS);
	}
	
	private ActionForward eemBillInvoiceCommentSave(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.saveBillInvoiceComment(conn,sessionHelper,context,(EEMBillInvoiceForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_INVOICE);
	}
	
	private ActionForward eemBillDraftCommentSave(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.saveBillInvoiceComment(conn,sessionHelper,context,(EEMBillInvoiceForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_INVOICE);
	}	
	
	private ActionForward eemBillInvoiceDetailsUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.updateBillInvoiceDetails(conn,sessionHelper,context,(EEMBillInvoiceForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_INVOICE);
	}
	

	private ActionForward eemBillDraftDetailsUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.updateBillDraftDetails(conn,sessionHelper,context,(EEMBillDraftForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_DRAFT);
	}

	private ActionForward eemBillDraftDetailsInsert(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.insertBillDraftDetails(conn,sessionHelper,context,(EEMBillDraftForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_DRAFT);
	}	
	
	private ActionForward eemBillDraftDetailsInsertForMember(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.insertBillDraftDetailsForMember(conn,sessionHelper,context,(EEMBillDraftForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_DRAFT);
	}		

	private ActionForward eemBillDraftGetMemberDetails(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.eemBillDraftGetMemberDetails(conn,sessionHelper,context,(EEMBillDraftForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_DRAFT);
	}	
	
	
	private ActionForward eemBillPaymentHeaderDetailsUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.updateBillPaymentHeaderDetails(conn,sessionHelper,context,(EEMBillPaymentsForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_PAYMENTS);
	}
	private ActionForward eemBillPaymentDetailsUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.updateBillPaymentDetails(conn,sessionHelper,context,(EEMBillPaymentsForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_PAYMENTS);
	}
	private ActionForward eemBillMembPaymentUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.updateBillMembPayment(conn,sessionHelper,context,(EEMBillMembPaymentsForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_MEMBER_PAYMENTS);
	}
	private ActionForward eemBillPaymentNew(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.newBillPaymentHeader(conn,sessionHelper,context,(EEMBillPaymentsForm)form, null);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_PAYMENTS_NEW);
	}
	private ActionForward eemBillPaymentAddDetails(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		mgr.addBillPaymentDetails(conn,sessionHelper,context,(EEMBillPaymentsForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_PAYMENTS_NEW);
	}
	private ActionForward eemBillPaymentCancel(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		((EEMBillPaymentsForm)form).setNewPaymentScreen(false);
		mgr.billPaymentsDetailSelect(conn,sessionHelper,context,(EEMBillPaymentsForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_PAYMENTS);
	}
	private ActionForward eemBillPaymentNewUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillingManager mgr = new EEMBillingManager();
		EEMBillPaymentsForm payForm = (EEMBillPaymentsForm)form;
		if (mgr.updateBillPaymentNew(conn,sessionHelper,context, payForm)) {
			if (payForm.getNewHeaderDisplayState().equals(EEMConstants.EEM_MBR_SCREEN_VIEW)) {
				mgr.billPaymentsNewRefresh(conn,sessionHelper,context,payForm);
				payForm.setNewPaymentScreen(false);
			} else {
				EMBillPaymentsVO billPaymentsVO = context.getBillPaymentsVO();
				context.setBillPaymentsDetailPagination(null);
				EmBBBPaymentsHeaderVO headerVO = payForm.getDisplayPaymentsHeader();
				billPaymentsVO.setSearchPaySource(headerVO.getPaySourceType());
				billPaymentsVO.setSearchBatchDate(headerVO.getBatchDate());
				billPaymentsVO.setSearchBatchSeqNbr(""+headerVO.getBatchSeqNbr());
				
				mgr.billPaymentsSearchPage(conn,sessionHelper,context,payForm, "first");
				payForm.setNewPaymentScreen(false);
			}
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.EEM_BILLING_PAYMENTS);
		} else {
			if (payForm.getNewHeaderDisplayState().equals(EEMConstants.EEM_MBR_SCREEN_VIEW)) {
				EmBBBPaymentsHeaderVO headerVO = (EmBBBPaymentsHeaderVO) context.getBillPaymentsVO().getSearchResults().get(payForm.getSelectedSearchRow());
				EEMBillingHelper.setNewDetailTotalAmt(payForm, headerVO);
				payForm.setDisplayPaymentsHeader(headerVO);
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_BILLING_PAYMENTS_NEW);
	}
	/**
	 * Cambia_Application Cancellation- Start 
	 */
	/**
	 * This method is used for the cancellation of the application
	 * @param conn
	 * @param sessionHelper
	 * @param context
	 * @param mapping
	 * @param form
	 * @param request
	 * @return
	 * @throws ApplicationException
	 */
	private ActionForward eemApplCancellation(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB); //IFOX-00427552 		
		
				// Get the form
				EEMApplForm eemFormAppl = (EEMApplForm) form;
				EEMApplicationVO filterVO = new EEMApplicationVO();
				EEMApplHelper.setFormToVO(eemFormAppl, filterVO, sessionHelper);
				EEMApplService service = context.getService();
				
			
				if (filterVO.isRejectButton() == true) {
					String userId = sessionHelper.getUserId();
					String mfId = sessionHelper.getMfId();
					int c = 0;
					
					try {
						/*IFOX-00427552 - start*/
						c = service.applCancelLtrReg(conn, eemDb, userId, mfId, context,
								filterVO);
						/*IFOX-00427552 - end*/
					
						if (c != 0 ) {
							
							filterVO.setApplStatus(EEMConstants.APPL_STATUS_READY);
							filterVO.setCurrStatus(EEMConstants.APPL_STATUS_CANCELED);
							service.cancelTimers(filterVO, conn);
							filterVO.setRejectButton(false);
							filterVO.setIsChanged("N");
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						//e.printStackTrace();
					}

				}
				EEMApplHelper.setVOToForm(filterVO, eemFormAppl, sessionHelper);
				EEMApplHelper.loadLookUps(conn, eemFormAppl, sessionHelper);
				EEMApplHelper.setAttestationList(eemFormAppl);

				
				logger.info(LoggerConstants.methodEndLevel());
				return mapping.findForward(EEMApplHelper.getPage(eemFormAppl));
			
	}
	/**
	 * Cambia_Application Cancellation- End
	 */
	/**
	 * Cambia_PRE-SET Notes-Start
	 */
	
	/**
	 * To add the note
	 * @param conn contains Connection
	 * @param sessionHelper contains Session
	 * @param context contains EEMContext 
	 * @param mapping contains Action Mapping
	 * @param form contains Action form
	 * @param request contains HTTPServletRequest
	 * @return Action Forward
	 * @throws ApplicationException
	 * @throws SQLException
	 */
	private ActionForward eemEnrollAddNote(Connection conn,SessionHelper sessionHelper, EEMContext context,ActionMapping mapping, ActionForm form, HttpServletRequest request)
			throws ApplicationException, SQLException{
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("PreSetNote Update: Begin : ");  
		//logger.info("PreSetNote Update: Begin : ");  
		EEMApplForm eemFormAppl = (EEMApplForm) form;
		EEMApplService service = context.getService();
		EEMApplHelper.setCommentList(eemFormAppl);
		EEMApplHelper.setAttestationList(eemFormAppl);
	    EEMApplHelper.isIncomplete(eemFormAppl); 
		boolean rslt = false;
		String userId = sessionHelper.getUserId();
		EEMApplicationVO filterVO = new EEMApplicationVO();
		EEMApplHelper.setFormToVO(eemFormAppl, filterVO, sessionHelper);
		
		// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - Start
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - End
	
		filterVO.setCustomerId(sessionHelper.getMfId());
		// Performance Changes -Start
		//filterVO.setMaxId(sessionHelper.getAttribute("PresetMaxId").toString());
		// Performance Changes -End
		String presetnote = eemFormAppl.getPreSetNoteM(); 
		 String presetnoteDesc=eemFormAppl.getPreSetNoteDescr();
		  String indicator =eemFormAppl.getInd();
		  String radioCheck =eemFormAppl.getRadioCheck();
		  try{
		 if(indicator.equals("P"))//P indicates PreSetNote
			{
		
			 rslt = service.addPreSetNote(conn,filterVO,userId, presetnote, presetnoteDesc,radioCheck);

			
			if(rslt==true){
				// Performance Changes -Start
				//eemFormAppl.setMessage(filterVO.getMessage());
				// Performance Changes -End
				// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - Start
				filterVO = service.getApplDetails(conn, eemDb, filterVO);
				// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - End
				// Performance Changes -Start
				//filterVO.setMessage(eemFormAppl.getMessage());
				// Performance Changes -End
				getPresetList(conn, service, filterVO,sessionHelper);
			
			
			
			}	
			}
		 
		
		EEMApplHelper.setVOToForm(filterVO, eemFormAppl, sessionHelper);
		EEMApplHelper.setApplicationStatus(eemFormAppl, sessionHelper);
		
		
		eemFormAppl.setDisplaySavedOev(filterVO.getOevCallStatusSaved());
		eemFormAppl.setDisplaySavedRetOev(filterVO.getOevRetStatusSaved());
		// Performance Changes -Start
		//eemFormAppl.setPreSetNoteList(filterVO.getPreSetNoteList()) ;
		// Performance Changes -End
		
		  }catch(Exception e){
			// e.printStackTrace();
			  logger.error(LoggerConstants.exceptionMessage(e.toString()));
			  //logger.error(e.getMessage());
		  }
//		  logger.info("PreSetNote Update: End ");  
		logger.debug("PreSetNote Update: End ");  
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMApplHelper.getPage(eemFormAppl));
		
	}
	/**
	 * @param conn contains connection
	 * @param service cntains Service 
	 * @param filterVO conations VO of form
	 * @throws ApplicationException
	 */
	private void getPresetList(Connection conn, EEMApplService service,
			EEMApplicationVO filterVO, SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		// Performance Changes -Start
		/*filterVO.setMaxId(sessionHelper.getAttribute("PresetMaxId").toString());
	
		
		filterVO.setCustomerId(sessionHelper.getMfId());
		List lstSearch = service.getPreSetNoteList(conn,filterVO);*/
		
		
		EEMPersistence eemPer = new EEMPersistence();
		Map hmPreSetNotesTemp=eemPer.getPreSetNotes();
		EEMCodeCache codeCache = EEMCodeCache.getInstance();
		codeCache.setHmPreSetNotes(hmPreSetNotesTemp);
		
	/* if (lstSearch.size() > 0) {
		 filterVO.setPreSetNoteList(lstSearch);
			} else {
				filterVO.setPreSetNoteList(null);
				
			}*/
		logger.info(LoggerConstants.methodEndLevel());
	}
	// Performance Changes -End
	/**
	 * Cambia_PRE-SET Notes-End
	 */
	/**
	 * Cambia_OEVProcess-Start
	 */
	
	/**
	 * 
	 * @param conn contains Connection
	 * @param sessionHelper contains Session
	 * @param context Contains EEMContext
	 * @param mapping contains Action Mapping
	 * @param form contains Action form
	 * @param request contains HTTPServletRequest
	 * @return Action forward
	 * @throws ApplicationException
	 */
	private ActionForward eemMbrOevScript(Connection conn,	SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)
			throws ApplicationException, ParseException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollForm eemForm = (EEMEnrollForm) form;
		//String customerId = sessionHelper.getMfId();
		//Uat Iteration 2-start
		String plan = request.getParameter("plan");
		String planDesgn = request.getParameter("planDes");
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String gender = request.getParameter("gender");
		String grpId = request.getParameter("grpId");
		String planName = request.getParameter("planName");
		String pbpId = request.getParameter("pbpId");
		String effDate = request.getParameter("effDate");
		String electionType = request.getParameter("electionType");
		String applDate = request.getParameter("applicationDate");
		//eemForm.setDisplayDemographic(eemForm.setlist).setFirstName(firstName);
		eemForm.getDisplayDemographic().setFirstName(firstName);
		eemForm.getDisplayDemographic().setLastName(lastName);
		eemForm.getDisplayDemographic().setGenderCd(gender);
		eemForm.getDisplayEnrollment().setPlanId(plan);
		eemForm.getDisplayEnrollment().setPlanDesignation(planDesgn);
		eemForm.getDisplayEnrollment().setGrpId(grpId);
		eemForm.getDisplayEnrollment().setProductName(planName);
		eemForm.getDisplayEnrollment().setPbpId(pbpId);
		//eemForm.getDisplayEnrollment().setEffStartDate(DateMath.minusOneDay(StringUtil.nonNullTrim(effDate)));
		eemForm.getDisplayEnrollment().setElectionTypeCd(electionType);
		eemForm.getDisplayEnrollment().setApplicationDate(applDate);
		String cancellationDate = null;
		if(StringUtil.nonNullTrim(electionType).equalsIgnoreCase("A")){
			applDate = DateFormatter.reFormat(StringUtil.nonNullTrim(applDate),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
    		try {
				cancellationDate = DateMath.addDay(StringUtil.nonNullTrim(applDate), 7);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("Error in calculating Cancellation date for OEV for member:::::::"+e.getMessage());
//				logger.error("Error in calculating Cancellation date for OEV for member:::::::"+e.getMessage());
			}
    		Calendar localCalendar = Calendar.getInstance();
    		int year1 = Integer.parseInt(cancellationDate.substring(0, 4));
    		int year2 = localCalendar.get(Calendar.YEAR);
    		if(year1 > year2){
    			cancellationDate = DateFormatter.reFormat(StringUtil.nonNullTrim(cancellationDate),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
    			eemForm.getDisplayEnrollment().setEffStartDate(StringUtil.nonNullTrim(cancellationDate));
    		}
    		else{
    			cancellationDate = (String)((localCalendar.get(Calendar.YEAR))+"1231");
    			cancellationDate = DateFormatter.reFormat(StringUtil.nonNullTrim(cancellationDate),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
				eemForm.getDisplayEnrollment().setEffStartDate(StringUtil.nonNullTrim(cancellationDate));
    		}
    	}
		else if(StringUtil.nonNullTrim(electionType).equalsIgnoreCase("S")){
    		String calldt = new DateUtil().getTodaysDate();
			effDate = DateFormatter.reFormat(StringUtil.nonNullTrim(effDate),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
			try {
				 int compreValue = StringUtil.nonNullTrim(calldt).compareTo(StringUtil.nonNullTrim(effDate));
	    		 if(compreValue >= 0){
					 cancellationDate = DateMath.addDay(StringUtil.nonNullTrim(calldt), 7);
					 cancellationDate = DateFormatter.reFormat(StringUtil.nonNullTrim(cancellationDate),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
					
				 }
	    		 else{
				cancellationDate = DateMath.minusOneDay(StringUtil.nonNullTrim(effDate));
				cancellationDate = DateFormatter.reFormat(StringUtil.nonNullTrim(cancellationDate),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
			
	    		 }
	    		 }catch (ParseException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
	    			 logger.error(LoggerConstants.exceptionMessage(e.toString()));
	    			 logger.debug("Error in calculating Cancellation date for OEV for member:::::::"+e.getMessage());
//	    			 logger.error("Error in calculating Cancellation date for OEV for member:::::::"+e.getMessage());
		}
		}
		else{
			
			effDate = DateFormatter.reFormat(StringUtil.nonNullTrim(effDate),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
			try {
				cancellationDate = DateMath.minusOneDay(StringUtil.nonNullTrim(effDate));
				cancellationDate = DateFormatter.reFormat(StringUtil.nonNullTrim(cancellationDate),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
				eemForm.getDisplayEnrollment().setEffStartDate(StringUtil.nonNullTrim(cancellationDate));
				
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("Error in calculating Cancellation date for OEV for member:::::::"+e.getMessage());
//				logger.error("Error in calculating Cancellation date for OEV for member:::::::"+e.getMessage());
			}
		}
		
		//System.out.println("in mbr oev script action--"+plan+planDesgn+firstName+lastName+" "+eemForm.getDisplayDemographic().getFirstName());
		//Uat Iteration 2-end
		EEMEnrollManager mgr = new EEMEnrollManager();
		int script=mgr.memberOevScript(conn,sessionHelper, plan, planDesgn, context,eemForm);
		logger.debug(" Member OEV Script in action , script == "+script);
		//System.out.println("script=="+eemForm.getDisplayDemographic().getFirstName()+eemForm.getOperId()+eemForm.getFirstName()+eemForm.getGenderCd());
	if(script==1){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_1);
		}if(script==2){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_2);
		}if(script==3){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_3);
		}if(script==4){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_4);
		}if(script==5){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_5);
		}if(script==6){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_6);
		}if(script==7){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_7);
		}if(script==8){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_8);
		}if(script==9){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR__SCRIPT_9);
		}if(script==10){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_10);
		}if(script==11){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_11);
		}if(script==12){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_12);
		}if(script==13){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_13);
		}if(script==14){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_14);
		}if(script==15){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_15);
		}if(script==16){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_16);
		}if(script==17){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_17);
		}if(script==18){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_18);
		}if(script==19){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_19);
		}if(script==20){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_20);
		}if(script==21){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_21);
		}if(script==22){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_22);
		}if(script==23){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_23);
		}if(script==24){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_24);
		}	if(script==25){
		logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_25);
		}if(script==26){
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_DEMO);
		}
		if(script==27){
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_27);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.OEV_MBR_SCRIPT_0);
	
	}
	/**
	 * Oev Application Update
	
	 * @param conn contains Connection
	 * @param sessionHelper contains Session
	 * @param context Contains EEMContext
	 * @param mapping contains Action Mapping
	 * @param form contains Action form
	 * @param request contains HTTPServletRequest
	 * @return Action forwardt
	 * @throws ApplicationException
	 * @return eemFormAppl 
	 */

	private ActionForward eemApplOev(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("eemApplOev : Start");
//		logger.info("eemApplOev : Start");
				// Get the form
				EEMApplForm eemFormAppl = (EEMApplForm) form;
				////System.out.println("form values"+ eemFormAppl.getOevButton()+" "+eemFormAppl.isOevInfoChanged());
				EEMApplicationVO filterVO = new EEMApplicationVO();
				////System.out.println("test "+ eemFormAppl.getTest());
				EEMApplHelper.setFormToVO(eemFormAppl, filterVO, sessionHelper);
				EEMApplService service = context.getService();
				
				// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - Start
				String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);	
				// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - End
		
					String userId = sessionHelper.getUserId();
					String mfId = sessionHelper.getMfId();
					int c;
					try {
						filterVO = 	service.applOev(conn, userId, mfId, context,
								filterVO, eemDb);
					
				
						}
					catch (Exception e) {
						// TODO Auto-generated catch block
						logger.error(LoggerConstants.exceptionMessage(e.toString()));
						logger.debug("eemApplOev ErrorCode: "+e.getMessage());
//						logger.error("eemApplOev ErrorCode: "+e.getMessage());
					}

					//original application start
				boolean check=service.checkOrigApplRecords(conn,filterVO);
					
					if(check==true){
					filterVO.setOrig(1);
					}
				
					//original application end
					// Performance Changes -Start
					//getPresetList(conn, service, filterVO,sessionHelper);
					// Performance Changes -End
					filterVO.setUpdateRec("Y");
				EEMApplHelper.setVOToForm(filterVO, eemFormAppl, sessionHelper);
				// Performance Changes -Start
				//eemFormAppl.setPreSetNoteList(filterVO.getPreSetNoteList());
				// Performance Changes -End
				//eemFormAppl.setOtherPcpName(filterVO.getOtherPcpName());
				eemFormAppl.setDisplaySavedOev(filterVO.getOevCallStatusSaved());
				eemFormAppl.setDisplaySavedRetOev(filterVO.getOevRetStatusSaved());
			
				EEMApplHelper.loadLookUps(conn, eemFormAppl, sessionHelper);
				EEMApplHelper.setAttestationList(eemFormAppl);
				if(filterVO.getOevCallAttempts()==null){
					//System.out.println(" in action Oev list is null");
					sessionHelper.getSession().setAttribute(
							EEMConstants.SESSION_OEV_SEARCH1, null);
				}
				else{
					//System.out.println(" oevCal size"+filterVO.getOevCallAttempts());
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_OEV_SEARCH1, filterVO.getOevCallAttempts());
				}
				if(filterVO.getOevCallStatus()==null){
					sessionHelper.getSession().setAttribute(
							EEMConstants.SESSION_OEV_SEARCH2, null);
				}
				else{
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_OEV_SEARCH2, filterVO.getOevCallStatus());
				}
				if(filterVO.getOevCallStatusSaved()==null){
					sessionHelper.getSession().setAttribute(
							EEMConstants.SESSION_OEV_SEARCH3, null);
				}
				else{
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_OEV_SEARCH3,filterVO.getOevCallStatusSaved());
				}
				if(filterVO.getOevRetStatus()==null){
					sessionHelper.getSession().setAttribute(
							EEMConstants.SESSION_OEV_SEARCH4, null);
				}
				else{
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_OEV_SEARCH4,filterVO.getOevRetStatus());
				}
				if(filterVO.getOevRetStatusSaved()==null){
					sessionHelper.getSession().setAttribute(
							EEMConstants.SESSION_OEV_SEARCH5, null);
				}
				else{
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_OEV_SEARCH5,filterVO.getOevRetStatusSaved());
				}
				if(filterVO.getOevRetStatus()==null){
					//System.out.println(" in action Oev list is null");
					sessionHelper.getSession().setAttribute(
							EEMConstants.SESSION_OEV_SEARCH6, null);
				}
				else{
					//System.out.println(" oevCal size"+filterVO.getOevRetStatus());
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_OEV_SEARCH6, filterVO.getReturnCalls());
				}
				// Set Application Status
				EEMApplHelper.setApplicationStatus(eemFormAppl, sessionHelper);
				logger.debug("eemApplOev : End");
//				logger.info("eemApplOev : End");
				logger.info(LoggerConstants.methodEndLevel());
				return mapping.findForward(EEMApplHelper.getPage(eemFormAppl));
			
	}
	/**
	 * 
	 * @param conn contains Connection
	 * @param sessionHelper contains Session
	 * @param context Contains EEMContext
	 * @param mapping contains Action Mapping
	 * @param form contains Action form
	 * @param request contains HTTPServletRequest
	 * @return Action forward
	 * @throws ApplicationException
	 */
	private ActionForward eemOevScript(Connection conn,	SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplForm eemFormAppl = (EEMApplForm) form;
		//System.out.println("form vo"+eemFormAppl.getMbrLastName()+" "+eemFormAppl.getApplId()+" "+eemFormAppl.getMbrLastName()+" "+eemFormAppl.getSpclCoPay());
		String plan = request.getParameter("plan");
	
		String planDesgn = request.getParameter("planDesgn");
		
		String customerId = sessionHelper.getMfId();
		eemFormAppl.setCustomerId(customerId);
		eemFormAppl.setMbrLastName(request.getParameter("mbrLast"));
	    eemFormAppl.setMbrFirstName( request.getParameter("memberFirst"));
	    eemFormAppl.setApplDate(request.getParameter("applDate"));
	    eemFormAppl.setReqDtCov(request.getParameter("cancelDate"));
	    eemFormAppl.setSignDt(StringUtil.nonNullTrim(request.getParameter("signDt")));
	    eemFormAppl.setOperId(request.getParameter("userId"));
	    String reqDtCov = request.getParameter("cancelDate");
	 
	    eemFormAppl.setElectionDt(StringUtil.nonNullTrim(request.getParameter("electionDt")));
	    eemFormAppl.setElectionType(StringUtil.nonNullTrim(request.getParameter("electionType")));
	    EEMOevService service = new EEMOevService();
	    String cancelDt = service.calculateCancellationDate(eemFormAppl.getElectionType(),eemFormAppl.getApplDate(),reqDtCov,eemFormAppl.getElectionDt(),eemFormAppl.getSignDt());
	    if(StringUtil.nonNullTrim(cancelDt).equals("")){
	    	reqDtCov = DateFormatter.reFormat(StringUtil.nonNullTrim(reqDtCov),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
			
			try {
				cancelDt = DateMath.minusOneDay(StringUtil.nonNullTrim(reqDtCov));
				cancelDt = DateFormatter.reFormat(StringUtil.nonNullTrim(cancelDt),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
				eemFormAppl.setReqDtCov(cancelDt);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("Error in parsing OEV Cancellation Date:::::"+e.getMessage());
//				logger.error("Error in parsing OEV Cancellation Date:::::"+e.getMessage());
			}
	    	
	    }
	    else{
		    cancelDt = DateFormatter.reFormat(StringUtil.nonNullTrim(cancelDt),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
		    eemFormAppl.setReqDtCov(cancelDt);
	    }
	    String planName=request.getParameter("planName");
	    eemFormAppl.setEnrollProdName(request.getParameter("planName"));
	    eemFormAppl.setEnrollPbp(request.getParameter("pbpId"));
	
	     String gender = request.getParameter("gender");
	    if(gender.equalsIgnoreCase("M"))
	    	eemFormAppl.setMbrGender("he");
	    if(gender.equalsIgnoreCase("F"))
	    	eemFormAppl.setMbrGender("she");
	    eemFormAppl.setApplId(request.getParameter("applId"));
	    eemFormAppl.setEnrollGroup(request.getParameter("group"));
	    eemFormAppl.setEnrollPlan(plan);
	    eemFormAppl.setEnrollPlanDesgn(planDesgn);
	
		
		EEMApplicationVO filterVO = new EEMApplicationVO();
		EEMApplHelper.setFormToVO(eemFormAppl, filterVO, sessionHelper);
		//System.out.println("in action...."+planDesgn+plan);
		int script = service.oevScript(conn, plan, planDesgn, filterVO,planName,customerId);
		
		//System.out.println("script=="+script);
		


		EEMApplHelper.setVOToForm(filterVO, eemFormAppl, sessionHelper);
		logger.info(LoggerConstants.methodEndLevel());
		if(script==1)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_1);
		if(script==2)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_2);
		if(script==3)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_3);
		if(script==4)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_4);
		if(script==5)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_5);
		if(script==6)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_6);
		if(script==7)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_7);
		if(script==8)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_8);
		if(script==9)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_9);
		if(script==10)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_10);
		if(script==11)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_11);
		if(script==12)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_12);
		if(script==13)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_13);
		if(script==14)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_14);
		if(script==15)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_15);
		if(script==16)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_16);
		if(script==17)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_17);
		if(script==18)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_18);
		if(script==19)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_19);
		if(script==20)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_20);
		if(script==21)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_21);
		if(script==22)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_22);
		if(script==23)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_23);
		if(script==24)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_24);
		if(script==25)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_25);
		if(script==26)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_DEMO);
		if(script==27)
			return mapping.findForward(EEMConstants.OEV_SCRIPT_27);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.OEV_SCRIPT_0);
		

	}
	

	/**
	 * Cambia_OEVProcess-End
	 */
	//Begin: Added for Letter Review Upload

	private ActionForward eemLetterReviewUpload(Connection conn, SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception 
	{
		logger.info(LoggerConstants.methodStartLevel());
		String userId = new SessionHelper(request).getUserId();
		logger.debug(" EEMAction : eemLetterReviewUpload : CustomerId from Session [" + sessionHelper.getMfId() + "] ");
		//logger.info(" EEMAction : eemLetterReviewUpload : CustomerId from Session [" + sessionHelper.getMfId() + "] ");
		request.setAttribute("customerId", sessionHelper.getMfId());

		if( null == userId || userId.trim().equals(""))
			request.setAttribute("letterReviewUploadedUserId", "ADMIN");
		else
			request.setAttribute("letterReviewUploadedUserId", userId);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LTR_REVIEW_UPLOAD);
	}
	
	private ActionForward uploadLetterReviewLetters(Connection conn, SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception
	{
		logger.info(LoggerConstants.methodStartLevel());
		Map fieldsMap = new HashMap();
		EEMLetterReviewManager mgr = new EEMLetterReviewManager();
		EEMLetterUploadForm eemLetterUploadForm = (EEMLetterUploadForm) form;
		logger.debug("setting customer id"+sessionHelper.getMfId());
		eemLetterUploadForm.setCustomerId(sessionHelper.getMfId());
		eemLetterUploadForm.setUserId(sessionHelper.getUserId());
		
		//eemLetterUploadForm.setCustomerId(this.getCustomerIdFromResource());

		logger.debug(" EEMAction : uploadLetterReviewLetters : CustomerId [" + eemLetterUploadForm.getCustomerId() + "], MemberId [" +
				eemLetterUploadForm.getMemberId() + "], RecordType [" + eemLetterUploadForm.getRecordType() + "], UserId [" +
				eemLetterUploadForm.getUserId() + "] ");
//		logger.info(" EEMAction : uploadLetterReviewLetters : CustomerId [" + eemLetterUploadForm.getCustomerId() + "], MemberId [" +
//				eemLetterUploadForm.getMemberId() + "], RecordType [" + eemLetterUploadForm.getRecordType() + "], UserId [" +
//				eemLetterUploadForm.getUserId() + "] ");
		
		request.setAttribute("customerId", eemLetterUploadForm.getCustomerId());
		request.setAttribute("memberId", eemLetterUploadForm.getMemberId());;
		request.setAttribute("uploadedFilePath", eemLetterUploadForm.getUploadedFilePath());
		request.setAttribute("userId", eemLetterUploadForm.getUserId());
		
		FormFile file = eemLetterUploadForm.getFile();
	    String fileName = file.getFileName();
		//if(mgr.checkAvailabilityOfMember(conn, eemLetterUploadForm.getCustomerId(), eemLetterUploadForm.getMemberId()))
	    //IFOX-00408649 - start
				if((mgr.validateSourceAndPrimaryId(conn, eemLetterUploadForm.getCustomerId(), eemLetterUploadForm.getMemberId(), eemLetterUploadForm.getRecordType())) 
						&& (!isFilePresent(fileName,MssProperties.getLetterUploadDir())))
		//IFOX-00408649 - end
		{
					System.out.println("filename and directory" + fileName + MssProperties.getLetterUploadDir()+ "****" );
					System.out.println("isfile present" + isFilePresent(fileName,MssProperties.getLetterUploadDir()));
			String filePathInServer = this.uploadLettersToServer(form, request);
			//IFOX-00430896 - Ltter Upload Changes for Sentara -start
			String uploadProf = (String)sessionHelper.getAttribute("LTRUPLD");
			if(StringUtil.nonNull(uploadProf).equals("Y") && !(StringUtil.nonNullTrim(eemLetterUploadForm.getLtrupload()).equals("Y"))){
				String ftpPathInServer = this.ftpToServer(form, request, filePathInServer, sessionHelper.getMfId());
				logger.info(" EEMAction : uploadLetterstoFTPServer : ftpPathInServer [" + ftpPathInServer + "] ");
				if(null != ftpPathInServer && !ftpPathInServer.trim().equals("")) {
					eemLetterUploadForm.setFtpFilePath(ftpPathInServer);
					eemLetterUploadForm.setUpldProfInd(uploadProf);
					this.uploadLettersToDatabase(filePathInServer, conn, eemLetterUploadForm, request,sessionHelper.getUserId());
				}
			}
			else{
				if(null != filePathInServer && !filePathInServer.trim().equals("")) {
					this.uploadLettersToDatabase(filePathInServer, conn, form, request,eemLetterUploadForm.getUserId());
				}
			}
			//IFOX-00430896 - Ltter Upload Changes for Sentara -end
			fieldsMap.put("customerId", eemLetterUploadForm.getCustomerId());
			fieldsMap.put("memberId", eemLetterUploadForm.getMemberId());
			fieldsMap.put("recordType", eemLetterUploadForm.getRecordType());
			fieldsMap.put("fileBatchId", eemLetterUploadForm.getFileBatchId());
			fieldsMap.put("fileName", eemLetterUploadForm.getFileName());
	
			if(isLetterReviewFieldsEntered(eemLetterUploadForm)) {
				this.prepareLetterReviewMap(eemLetterUploadForm, fieldsMap);
				mgr.updateLetterReviewFields(conn, fieldsMap);
			}
			this.resetLetterReviewFields(eemLetterUploadForm);
			request.setAttribute("ackMessage", "Letter Uploaded Successfully");
		
		}else {
			request.setAttribute("errorMessage", " Invalid Source and Primary id OR Give Appropriate file name with Date and try again");
		}
				logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_LTR_REVIEW_UPLOAD);
	}
	
	private void prepareLetterReviewMap(EEMLetterUploadForm eemLetterUploadForm, Map fieldsMap)
	{
		logger.info(LoggerConstants.methodStartLevel());
		if(null != eemLetterUploadForm.getPrintRequestDate() && !eemLetterUploadForm.getPrintRequestDate().trim().equals(""))
			fieldsMap.put("printRequestDate", eemLetterUploadForm.getPrintRequestDate());
		
		if(null != eemLetterUploadForm.getOrigMailDate() && !eemLetterUploadForm.getOrigMailDate().trim().equals(""))
			fieldsMap.put("origMailDate", eemLetterUploadForm.getOrigMailDate());
		
		if(null != eemLetterUploadForm.getLastMailDate() && !eemLetterUploadForm.getLastMailDate().trim().equals(""))
			fieldsMap.put("lastMailDate", eemLetterUploadForm.getLastMailDate());
		
		if(null != eemLetterUploadForm.getPrintDate() && !eemLetterUploadForm.getPrintDate().trim().equals(""))
			fieldsMap.put("datePrinted", eemLetterUploadForm.getPrintDate());
		
		if(null != eemLetterUploadForm.getReprintDate() && !eemLetterUploadForm.getReprintDate().trim().equals(""))
			fieldsMap.put("reprintDate", eemLetterUploadForm.getReprintDate());
		
		if(null != eemLetterUploadForm.getResponseDueDate() && !eemLetterUploadForm.getResponseDueDate().trim().equals(""))
			fieldsMap.put("responseDueDate", eemLetterUploadForm.getResponseDueDate());
		
		if(null != eemLetterUploadForm.getResponseDate() && !eemLetterUploadForm.getResponseDate().trim().equals(""))
			fieldsMap.put("responseDate", eemLetterUploadForm.getResponseDate());
		logger.info(LoggerConstants.methodEndLevel());
	}

	private String getCustomerIdFromResource()
	{
		logger.info(LoggerConstants.methodStartLevel());
		String customerId = null;
		Properties prop = new Properties();

		try {
			prop.load(getClass().getClassLoader().getResourceAsStream("mss/resources/alfresco.properties"));
			customerId = prop.getProperty("customerId");

			if(null == customerId || customerId.trim().equals(""))
				customerId = "";

		} catch (Exception exception) {
			logger.error(LoggerConstants.exceptionMessage(exception.toString()));
			logger.debug(" EEMAction : getCustomerIdFromResource : " + exception.getMessage());
//			logger.error(" EEMAction : getCustomerIdFromResource : " + exception.getMessage());

		} finally {
			if(null != prop)
				prop.clear();
		}
//		logger.info(" EEMAction : getCustomerIdFromResource : CustomerId [" + customerId + "] ");
		logger.debug(" EEMAction : getCustomerIdFromResource : CustomerId [" + customerId + "] ");
		logger.info(LoggerConstants.methodEndLevel());
		return customerId;
	}
	
	private boolean isLetterReviewFieldsEntered(EEMLetterUploadForm eemLetterUploadForm)
	{
		logger.info(LoggerConstants.methodStartLevel());
		boolean flag = true;

		if( (null == eemLetterUploadForm.getPrintRequestDate() || eemLetterUploadForm.getPrintRequestDate().trim().equals("")) &&
			(null == eemLetterUploadForm.getOrigMailDate() || eemLetterUploadForm.getOrigMailDate().trim().equals("")) &&
			(null == eemLetterUploadForm.getLastMailDate() || eemLetterUploadForm.getLastMailDate().trim().equals("")) &&
			(null == eemLetterUploadForm.getPrintDate() || eemLetterUploadForm.getPrintDate().trim().equals("")) &&
			(null == eemLetterUploadForm.getReprintDate() || eemLetterUploadForm.getReprintDate().trim().equals("")) &&
			(null == eemLetterUploadForm.getResponseDueDate() || eemLetterUploadForm.getResponseDueDate().trim().equals("")) &&
			(null == eemLetterUploadForm.getResponseDate() || eemLetterUploadForm.getResponseDate().trim().equals("")) )
			flag = false;
		logger.info(LoggerConstants.methodEndLevel());
		return flag; 
	}
	
	private void resetLetterReviewFields(EEMLetterUploadForm eemLetterUploadForm) {
		logger.info(LoggerConstants.methodStartLevel());
		eemLetterUploadForm.setRecordType("");
		eemLetterUploadForm.setMemberId("");
		eemLetterUploadForm.setPrintRequestDate("");
		eemLetterUploadForm.setOrigMailDate("");
		eemLetterUploadForm.setLastMailDate("");
		eemLetterUploadForm.setPrintDate("");
		eemLetterUploadForm.setReprintDate("");
		eemLetterUploadForm.setResponseDueDate("");
		eemLetterUploadForm.setResponseDate("");
		//IFOX-00430896 - Ltter Upload Changes for Sentara -start
		eemLetterUploadForm.setLtrupload("");
		//IFOX-00430896 - Ltter Upload Changes for Sentara -end
		logger.info(LoggerConstants.methodEndLevel());
	}
	private String uploadLettersToServer(ActionForm form, HttpServletRequest request) throws ApplicationException, IOException
	{
		logger.info(LoggerConstants.methodStartLevel());
		String uploadedFilePathInServer =MssProperties.getLetterUploadDir();

//		logger.info(" EEMAction : uploadLettersToServer : Begin : "+uploadedFilePathInServer);
		logger.debug(" EEMAction : uploadLettersToServer : Begin : "+uploadedFilePathInServer);
		if(null==uploadedFilePathInServer || "".equalsIgnoreCase(uploadedFilePathInServer)){
			uploadedFilePathInServer=EEMConstants.LETTER_UPLOAD_DIR_DEFAULT;
		}

		try {
			
			EEMLetterUploadForm letterUploadForm = (EEMLetterUploadForm)form;
			FormFile file = letterUploadForm.getFile();
		    String fileName = file.getFileName();

		    logger.debug(" EEMAction : uploadLettersToServer : fileName [" + fileName + "] ");
//		    logger.info(" EEMAction : uploadLettersToServer : fileName [" + fileName + "] ");

		    if(!("").equals(fileName))
		    {
		    	letterUploadForm.setFileName(fileName);
		    	uploadedFilePathInServer = uploadedFilePathInServer + fileName;
		        File newFile = new File(uploadedFilePathInServer);
		        if(!newFile.exists()){
		          FileOutputStream fos = new FileOutputStream(newFile);
		          fos.write(file.getFileData());
		          fos.flush();
		          fos.close();
		        }  
		    }
		    /*
			DiskFileUpload diskFileUpload = new DiskFileUpload();
			diskFileUpload.setSizeMax(-1L);
			List list = diskFileUpload.parseRequest(request);
			Iterator iterator = list.iterator();

			while(iterator.hasNext())
			{
				FileItem fileItem = (FileItem)iterator.next();
				if(fileItem.getFieldName().equals("file")) {
					String fileNamePath = fileItem.getName();
					String fileName = fileNamePath.substring(fileNamePath.lastIndexOf("\\") + 1);
					uploadedFilePathInServer = uploadedFilePathInServer + "\\" + fileName;
					logger.info(" LtrFileUploadServlet : saveUploadedLettersToLocalDrive : File Saved At [" + uploadedFilePathInServer + "] ");
					File file = new File(uploadedFilePathInServer);
					fileItem.write(file);
					break;
				}
			}*/

		} catch (Exception exception) {
			logger.error(LoggerConstants.exceptionMessage(exception.toString()));
			logger.debug(" EEMAction : uploadLettersToServer : Exception : " + exception.getMessage());
//			logger.error(" EEMAction : uploadLettersToServer : Exception : " + exception.getMessage());
	   	}
//		logger.info(" EEMAction : uploadLettersToServer : End   : ");
		logger.debug(" EEMAction : uploadLettersToServer : End   : ");
		logger.info(LoggerConstants.methodEndLevel());
		return uploadedFilePathInServer;
	}
	
	//IFOX-00408649 - start
	private boolean isFilePresent(String file, String directory) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		System.out.println("In is file present method");
		System.out.println("file name in method inside  " + file+"****directory " + directory);
		directory = directory+file;
		System.out.println("Directory allocated *** " + directory);
		File tmpDir = new File(directory);
		System.out.println("File tmDir**** " +tmpDir);
		boolean exists = tmpDir.exists();
		System.out.println("exists or not *** " + exists);
		logger.info(LoggerConstants.methodEndLevel());
		return exists;
}
	//IFOX-00408649 - end
	
	private void uploadLettersToDatabase(String filePathInServer, Connection conn,
			ActionForm form, HttpServletRequest request,String userId) throws ApplicationException, IOException {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug(" EEMAction : uploadLettersToDatabase : Begin : ");
//		logger.info(" EEMAction : uploadLettersToDatabase : Begin : ");

		EEMEnrollDao eemEnrollDao = new EEMEnrollDao();
		String strDateTimeStamp = new DateUtil().getDB2DTS();
		
		String fileName = null;
		
		try {
			EEMLetterUploadForm letterUploadForm = (EEMLetterUploadForm)form;

			//eemEnrollDao.insertMbrLetters(conn, letterUploadForm.getUserId(),
			//		letterUploadForm.getCustomerId(), letterUploadForm.getMemberId(), letterUploadForm.getFileName(), " ");
			letterUploadForm.setUserId(userId);
			
			//Begin : Modified for IFOX-00401917
			//String fileName = letterUploadForm.getFileName().substring(0, letterUploadForm.getFileName().lastIndexOf(".pdf"));
			if( letterUploadForm.getFileName().lastIndexOf(".pdf") != -1 )
				fileName = letterUploadForm.getFileName().substring(0, letterUploadForm.getFileName().lastIndexOf(".pdf"));
			else
				fileName = letterUploadForm.getFileName().substring(0, letterUploadForm.getFileName().lastIndexOf(".PDF"));
			//End : Modified for IFOX-00401917
			//IFOX-00426356: Attachment CR:start
			String fileBatchId = eemEnrollDao.getMaxFileBatchId(conn, letterUploadForm.getCustomerId(), letterUploadForm.getMemberId(), fileName,"ONL");
			//IFOX-00426356: Attachment CR:send
			logger.debug(" EEMAction : uploadLettersToDatabase : Max FileBatchId from DB [ " + fileBatchId + "] ");
//			logger.info(" EEMAction : uploadLettersToDatabase : Max FileBatchId from DB [ " + fileBatchId + "] ");
			//IFOX-00426356: Attachment CR:start
			fileBatchId = this.getIncrementedFileBatchId(fileBatchId, "ONL");
			//IFOX-00426356: Attachment CR:end
			letterUploadForm.setFileName(fileName);
			letterUploadForm.setFileBatchId(fileBatchId);
			logger.debug(" EEMAction : uploadLettersToDatabase : FileBatchId After Increment [ " + fileBatchId + "] ");
//			logger.info(" EEMAction : uploadLettersToDatabase : FileBatchId After Increment [ " + fileBatchId + "] ");
			//IFOX-00430896 - Ltter Upload Changes for Sentara -start
			String status = "UPLOADED";
			String dmsId = "";
			if(StringUtil.nonNullTrim(letterUploadForm.getUpldProfInd()).equals("Y") &&
					!(StringUtil.nonNullTrim(letterUploadForm.getLtrupload()).equals("Y"))){
				status = "APPROVED";
				dmsId = letterUploadForm.getFtpFilePath();
			}
			eemEnrollDao.insertMemberAndApplicationLetters(conn, letterUploadForm.getCustomerId(), letterUploadForm.getMemberId(),
					letterUploadForm.getRecordType(), fileBatchId, fileName, letterUploadForm.getUserId(), 
					strDateTimeStamp, status, dmsId);
			//IFOX-00430896 - Ltter Upload Changes for Sentara -end
			eemEnrollDao.uploadLettersToDataBase(filePathInServer, conn, letterUploadForm.getCustomerId(), letterUploadForm.getMemberId(),
					fileName, letterUploadForm.getUserId(), fileBatchId, strDateTimeStamp);

		} catch (Exception exception) {
			logger.error(LoggerConstants.exceptionMessage(exception.toString()));
			logger.debug(" EEMAction : uploadLettersToDatabase : Exception : " + exception.getMessage());
//			logger.error(" EEMAction : uploadLettersToDatabase : Exception : " + exception.getMessage());
	   	}
		logger.debug(" EEMAction : uploadLettersToDatabase : End   : ");
//		logger.info(" EEMAction : uploadLettersToDatabase : End   : ");
		logger.info(LoggerConstants.methodEndLevel());
	}
	//IFOX-00426356: Attachment CR:start
	private String getIncrementedFileBatchId(String fileBatchId,String prefix) {
		logger.info(LoggerConstants.methodStartLevel());
		String updatedFileBatchId = prefix;
		//IFOX-00426356: Attachment CR:end
		String batchSequence = fileBatchId.substring(3, fileBatchId.length());
		int batchSequenceLength = batchSequence.length();
		String sequenceIncrement =  String.valueOf(Integer.parseInt(batchSequence)+1);
		
		for(int index = 0; index < (batchSequenceLength - sequenceIncrement.length()); index ++) {
			updatedFileBatchId = updatedFileBatchId + "0";
		}
		//System.out.println(updatedFileBatchId + String.valueOf(sequenceIncrement));
		logger.info(LoggerConstants.methodEndLevel());
		return updatedFileBatchId + String.valueOf(sequenceIncrement);
	}
	private ActionForward uploadLetters(Connection conn, SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException, IOException
	{
		logger.info(LoggerConstants.methodStartLevel());
		try {
			EEMLetterUploadForm letterUploadForm = (EEMLetterUploadForm)form;

			String filePathInServer = this.uploadLettersToServer(form, request);
			logger.info(" EEMAction : uploadLetters : filePathInServer [" + filePathInServer + "] ");
			String uploadProf = (String)sessionHelper.getAttribute("LTRUPLD");
			if(StringUtil.nonNull(uploadProf).equals("Y")){
				String ftpPathInServer = this.ftpToServer(form, request, filePathInServer, sessionHelper.getMfId());
				logger.info(" EEMAction : uploadLetterstoFTPServer : ftpPathInServer [" + ftpPathInServer + "] ");
				if(null != ftpPathInServer && !ftpPathInServer.trim().equals("")) {
					letterUploadForm.setFtpFilePath(ftpPathInServer);
					letterUploadForm.setUpldProfInd(uploadProf);
					this.uploadLettersToDatabase(filePathInServer, conn, letterUploadForm, request,sessionHelper.getUserId());
				}
			}
			else{
				if(null != filePathInServer && !filePathInServer.trim().equals("")) {
					this.uploadLettersToDatabase(filePathInServer, conn, form, request,sessionHelper.getUserId());
				}
			}
			
		} catch(Exception exception) {
			logger.error(LoggerConstants.exceptionMessage(exception.toString()));
			logger.debug(" EEMAction :  uploadLetters : " + exception.getMessage());
//			logger.error(" EEMAction :  uploadLetters : " + exception.getMessage());
		}
		request.setAttribute("UploadedStatus", "Y");
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward("letterUploadPopUp");
	}
	private ActionForward displayLetterUploadPopUp(Connection conn, SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException, IOException
	{
		logger.info(LoggerConstants.methodStartLevel());
		try {
			String userId = new SessionHelper(request).getUserId();
			String customerId = request.getParameter("customerId");
			String memberId = request.getParameter("memberId");
			String recordType = request.getParameter("recordType");
			String fileBatchId = request.getParameter("fileBatchId");
			String ltrDesDisp = (String)sessionHelper.getAttribute(EEMProfileSettings.LTR_DES_DISP);
			logger.debug(" EEMAction : displayLetterUploadPopUp : CustomerId [" + customerId + "], MemberId [" + memberId + "], RecordType [" +
					recordType + "], FileBatchId [" + fileBatchId + "], UserId [" + userId + "]");
//			logger.info(" EEMAction : displayLetterUploadPopUp : CustomerId [" + customerId + "], MemberId [" + memberId + "], RecordType [" +
//					recordType + "], FileBatchId [" + fileBatchId + "], UserId [" + userId + "]");
		
			EEMLetterUploadForm letterUploadForm = (EEMLetterUploadForm)form;
			letterUploadForm.setCustomerId(customerId);
			letterUploadForm.setMemberId(memberId);
			letterUploadForm.setUserId(userId);
			letterUploadForm.setRecordType(recordType);
			letterUploadForm.setFileBatchId(fileBatchId);
			letterUploadForm.setMemberLetters(new EEMEnrollDao().getMbrLetters(conn, customerId, memberId,ltrDesDisp));

		} catch(Exception exception) {
			logger.error(LoggerConstants.exceptionMessage(exception.toString()));
			logger.debug(" EEMAction :  displayLetterUploadPopUp : " + exception.getMessage());
//			logger.error(" EEMAction :  displayLetterUploadPopUp : " + exception.getMessage());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward("letterUploadPopUp");
	}

	//End: Added for Letter Review Upload

/*	 Begin: Added for Letter Review QC */
private ActionForward eemLetterReviewQCbatchId(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
	logger.info(LoggerConstants.methodStartLevel());
	EEMLetterReviewManager mgr = new EEMLetterReviewManager();
	
	/*mgr.letterReviewQCsearchbatchId(conn,context,(EEMLetterReviewQCForm)form); */
	
	/* SummaCare code start */ 
	mgr.letterReviewQCsearchbatchId(conn,context,(EEMLetterReviewQCForm)form, sessionHelper);
	/* SummaCare code end */ 
	logger.info(LoggerConstants.methodEndLevel());
	return mapping.findForward(EEMConstants.EEM_LTR_QC);
}
private ActionForward eemLetterReviewQCDescription(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
	logger.info(LoggerConstants.methodStartLevel());
	EEMLetterReviewManager mgr = new EEMLetterReviewManager();
	
	/*mgr.letterReviewQCsearchDescription(conn,context,(EEMLetterReviewQCForm)form);*/
	/*  CustomerId added for SummaCare  -Start */ 
		mgr.letterReviewQCsearchDescription(conn,context,(EEMLetterReviewQCForm)form, sessionHelper);
	/*  CustomerId added for SummaCare  -End */ 
		logger.info(LoggerConstants.methodEndLevel());
	return mapping.findForward(EEMConstants.EEM_LTR_QC);
}
private ActionForward eemLetterReviewQCSearch(Connection conn,SessionHelper sessionHelper, EEMContext context,ActionMapping mapping, ActionForm form, HttpServletRequest request) throws SQLException {
	logger.info(LoggerConstants.methodStartLevel());
	EEMLetterReviewManager mgr = new EEMLetterReviewManager();
	//IFOX - 430896 LTr QC CR : start
	//String ltrStatus = "EXTRACTED";
	String ltrStatus  = ((EEMLetterReviewQCForm)form).getChangedLetterStatus();
	//IFOX - 430896 LTr QC CR : end
	mgr.letterReviewQCSearch(conn,sessionHelper,context,(EEMLetterReviewQCForm)form,ltrStatus);
	logger.info(LoggerConstants.methodEndLevel());
	return mapping.findForward(EEMConstants.EEM_LTR_QC);
}
private ActionForward eemLetterReviewQcClearSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws SQLException, Exception {
	logger.info(LoggerConstants.methodStartLevel());
	EEMLetterReviewQcVO letterReviewQcVO = context.getLetterReviewQcVO();
	letterReviewQcVO.setListSearchResults(null);
	
	EEMLetterReviewQCForm eemLetterReviewQcForm = (EEMLetterReviewQCForm)form;
	EEMLetterReviewHelper.clearQcForm(eemLetterReviewQcForm);
	logger.info(LoggerConstants.methodEndLevel());
	return mapping.findForward(EEMConstants.EEM_LTR_QC);
}

private ActionForward eemLetterReviewQcletterStatus(Connection conn,SessionHelper sessionHelper, EEMContext context,ActionMapping mapping,  ActionForm form, HttpServletRequest request) {
	logger.info(LoggerConstants.methodStartLevel());
	 EEMLetterReviewQCForm eemLetterReviewQcForm = (EEMLetterReviewQCForm)form;
	 EEMLetterReviewManager mgr = new EEMLetterReviewManager();
	 String ltrStatus = eemLetterReviewQcForm.getChangedLetterStatus();
	 mgr.letterReviewQCSearch(conn,sessionHelper,context,(EEMLetterReviewQCForm)form,ltrStatus);
	 logger.info(LoggerConstants.methodEndLevel());
	return mapping.findForward(EEMConstants.EEM_LTR_QC);
}
/*End --- letterReviewQC*/	
/**
 * Start -- 014_Highmark_SUC_Letters_v1-- to Reprint Selected Letter 
 */
/**
 * 
 * @param conn contains Connection
 * @param sessionHelper contains Session
 * @param context Contains EEMContext
 * @param mapping contains Action Mapping
 * @param form contains Action form
 * @param request contains HTTPServletRequest
 * @param response contains HttpServletResponse
 * @return Action forward
 * @throws ApplicationException 
 */
private ActionForward eemEnrollReprintLetter(Connection conn,
		SessionHelper sessionHelper,EEMContext context, ActionMapping mapping,
		ActionForm form, HttpServletRequest request,
		HttpServletResponse response) throws ApplicationException {
	logger.info(LoggerConstants.methodStartLevel());
	EEMEnrollForm eemEnrollForm = (EEMEnrollForm) form;
	EEMEnrollManager mgr = new EEMEnrollManager();
	mgr.enrollReprintLetter(conn, sessionHelper,context,eemEnrollForm);
	logger.info(LoggerConstants.methodEndLevel());
	return mapping.findForward(EEMConstants.EEM_ENROLLMENT);
}
/**
 * End -- 014_Highmark_SUC_Letters_v1-- to Reprint Selected Letter 
 */
/**
 * 024_Cambia_SUC_LEP - Start 2
 * @throws SQLException 
 */
/**
 * 
 * @param conn contains Connection
 * @param sessionHelper contains Session
 * @param context contains EEMContext
 * @param mapping contains Action Mapping
 * @param form contains Action form
 * @param request contains HtpServletRequest
 * @return Action forward
 * @throws ApplicationException
 * @throws SQLException
 */
private ActionForward eemLEPCreLetter(Connection conn,
		SessionHelper sessionHelper, EEMContext context,
		ActionMapping mapping, ActionForm form, HttpServletRequest request)
		throws ApplicationException, SQLException {
	logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollManager mgr = new EEMEnrollManager();
		EEMEnrollManager.setAgentsLookUp(conn, sessionHelper,
						(EEMEnrollForm) form);
		mgr.mbrLEPCredLtrReq(conn, sessionHelper, context,
				(EEMEnrollForm) form);
		logger.info(LoggerConstants.methodEndLevel());
	return mapping.findForward(EEMConstants.EEM_ENROLLMENT);
}
/**
 * 
 * @param conn contains Connection
 * @param sessionHelper contains Session
 * @param context contains EEMContext
 * @param mapping contains ActionMapping
 * @param form contais Action form
 * @param request contains HTTPServletRequest
 * @return Actionforward
 * @throws ApplicationException
 * @throws SQLException
 */

private ActionForward eemLEPAdjLetter(Connection conn,
		SessionHelper sessionHelper, EEMContext context,
		ActionMapping mapping, ActionForm form, HttpServletRequest request)
		throws ApplicationException, SQLException {
	logger.info(LoggerConstants.methodStartLevel());
	EEMEnrollManager mgr = new EEMEnrollManager();
	EEMEnrollManager.setAgentsLookUp(conn, sessionHelper,
			(EEMEnrollForm) form);
	mgr.mgrLEPAdjLtrReq(conn, sessionHelper, context,
			(EEMEnrollForm) form);
	logger.info(LoggerConstants.methodEndLevel());
	return mapping.findForward(EEMConstants.EEM_ENROLLMENT);
}

/**
 * @author santokmr
 * This method will fetch the LEP details wrt Application side
 * upon clicking LEP Details button in Application Entry screen
 * @param conn holds Connection Object
 * @param sessionHelper holds sessionHelper
 * @param context holds EEMContext
 * @param mapping holds ActionMapping
 * @param form hold ActionForm
 * @param request holds HttpServletRequest
 * @throws ApplicationException when any exception occurs
 */
/*private ActionForward eemApplLep(Connection conn,
		SessionHelper sessionHelper, EEMContext context,
		ActionMapping mapping, ActionForm form, HttpServletRequest request)
		throws ApplicationException {

	EEMApplManager applManager = new EEMApplManager();
	EEMApplForm eemFormAppl = (EEMApplForm) form;
	int apId=0;
	boolean chkLepDataFlag=false;
	String custId = request.getParameter("customerId");
	apId = (Integer.parseInt(request.getParameter("applId")));
	String hic_Num = request.getParameter("hic_Nbr");
	String loginuserId = request.getParameter("operatorId");
	String applStatus = request.getParameter("applStatus");
	eemFormAppl.setCustomerId(custId);
	eemFormAppl.setApplicationId(apId);
	eemFormAppl.setMbrHicNbr(hic_Num);
	eemFormAppl.setLoginUser(loginuserId);
	EEMApplicationVO filterVO = new EEMApplicationVO();
	filterVO.setLoginUser(loginuserId);
	
	//Below method will check the availability of LEP Data 
	// Commented for High Mark -- To show MBD data when no LEP deatils are their for a paticular Application.
			chkLepDataFlag = applManager.checkApplLEPData(conn,custId,apId);
			if(chkLepDataFlag==true){
				applManager.applSelect(conn, sessionHelper, context,(EEMApplForm) form,filterVO);
				filterVO.setApplStatus(applStatus);
				EEMApplHelper.setVOToForm(filterVO,eemFormAppl,sessionHelper);
				return mapping.findForward("lepDetailsPage");
		   }else{
			   return mapping.findForward("NolepDetailsPage");
		   }   
		}*/

private ActionForward eemApplLep(Connection conn,
		SessionHelper sessionHelper, EEMContext context,
		ActionMapping mapping, ActionForm form, HttpServletRequest request)
		throws ApplicationException {
	logger.info(LoggerConstants.methodStartLevel());
	EEMApplManager applManager = new EEMApplManager();
	EEMApplForm eemFormAppl = (EEMApplForm) form;
	int apId=0;
	boolean chkLepDataFlag=false;
	String custId = request.getParameter("customerId");
	apId = (Integer.parseInt(request.getParameter("applId")));
	String hic_Num = request.getParameter("hic_Nbr");
	String loginuserId = request.getParameter("operatorId");
	String applStatus = request.getParameter("applStatus");
	String reqDtCov = request.getParameter("reqDtCov");
	
	
	eemFormAppl.setCustomerId(custId);
	eemFormAppl.setApplicationId(apId);
	eemFormAppl.setMbrHicNbr(hic_Num);
	eemFormAppl.setLoginUser(loginuserId);
	eemFormAppl.setReqDtCov(reqDtCov);
	EEMApplicationVO filterVO = new EEMApplicationVO();
	filterVO.setReqDtCov(reqDtCov);
	filterVO.setLoginUser(loginuserId);
	
	//Below method will check the availability of LEP Data 
	// Commented for High Mark -- To show MBD data when no LEP deatils are their for a paticular Application.
			/*chkLepDataFlag = applManager.checkApplLEPData(conn,custId,apId);
			if(chkLepDataFlag==true){*/
				applManager.applSelect(conn, sessionHelper, context,(EEMApplForm) form,filterVO);
				filterVO.setApplStatus(applStatus);
				//00427630-OPEN : TSA Supress LEP process Platino Members - start
				EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
				filterVO.setApplId(String.valueOf(apId));
				eemDao.getPlanDetails(conn, filterVO);
				boolean lepTrgSkip = eemDao.getLepPlatinoFlag(conn, filterVO);
				if(lepTrgSkip)
					filterVO.setSuppLepPlatino("true");
				else
					filterVO.setSuppLepPlatino("false");
					
				//00427630-OPEN : TSA Supress LEP process Platino Members - end
				EEMApplHelper.setVOToForm(filterVO,eemFormAppl,sessionHelper);
				logger.info(LoggerConstants.methodEndLevel());
				return mapping.findForward("lepDetailsPage");
		   /*}else{
			   return mapping.findForward("NolepDetailsPage");
		   } */  
		}





/**
 * Start -- for 020_UI Mock_ups-- to view letter from DB
/**
 * @author santokmr
 * This method will update the LEP Attestaion and Attestation Calls values 
 * wrt Application Side into Database based on the button clicked in the LEP Details popup window
 * @param conn holds Connection Object
 * @param sessionHelper holds sessionHelper
 * @param context holds EEMContext
 * @param mapping holds ActionMapping
 * @param form hold ActionForm
 * @param request holds HttpServletRequest
 * @throws ApplicationException when any exception occurs
 */

private ActionForward eemappLEPUpdate(Connection conn,
		SessionHelper sessionHelper, EEMContext context,
		ActionMapping mapping, ActionForm form, HttpServletRequest request)
		throws ApplicationException, SQLException {
	logger.info(LoggerConstants.methodStartLevel());
	try{

	
		
	EEMApplManager applManager = new EEMApplManager();
	EEMApplForm eemFormAppl = (EEMApplForm) form;
	EEMApplicationVO filterVO = new EEMApplicationVO();
	EEMApplHelper.setFormToVO(eemFormAppl,filterVO,sessionHelper);
	
	//System.out.println("In LEP Action");
	applManager.applLEPUpdate(conn, sessionHelper, context,(EEMApplForm) form,filterVO);
	applManager.applSelect(conn, sessionHelper, context,(EEMApplForm) form,filterVO);

	EEMApplHelper.setVOToForm(filterVO,eemFormAppl,sessionHelper);
	
	if(eemFormAppl.getOutInitAttests().size()!=filterVO.getOutInitAttests().size()){
	eemFormAppl.setOutInitAttests(filterVO.getOutInitAttests());
	eemFormAppl.setInInitAttests(filterVO.getInInitAttests());
	eemFormAppl.setOutIncAttests(filterVO.getOutIncAttests());
	eemFormAppl.setInIncAttests(filterVO.getInIncAttests());
	eemFormAppl.setInLateAttests(filterVO.getInLateAttests());
	}}catch(Exception e){
		logger.error(LoggerConstants.exceptionMessage(e.toString()));
		logger.debug("EEMAction updating LEP At values @ APPL Side::eemappLEPUpdate "+e.getMessage());
//		logger.info("EEMAction updating LEP At values @ APPL Side::eemappLEPUpdate "+e.getMessage());
		}
	logger.info(LoggerConstants.methodEndLevel());
	return mapping.findForward("lepDetailsPage");
}
/**
 * 024_Cambia_SUC_LEP - End 2
 */

//IFOX-00395242 - viewPdf-- start
private ActionForward viewPdf(Connection conn, SessionHelper sessionHelper, EEMContext context,
		ActionMapping mapping, ActionForm form, HttpServletRequest request, 
		HttpServletResponse response) throws ApplicationException, IOException {
	logger.info(LoggerConstants.methodStartLevel());
	logger.debug(" EEMAction : viewPdf : Begin : ");
//	logger.info(" EEMAction : viewPdf : Begin : ");
	ServletOutputStream outputStream = null;
	EmCorrMbrVO emCorrMbrVO = new EmCorrMbrVO();
	String responseMsg = "";
	try {
		//EEMApplForm eemFormAppl = (EEMApplForm) form;
		boolean pdfExists = false;
		
		String customerId = request.getParameter("customerId");
		String applId = request.getParameter("primaryId");
		logger.info(" EEMAction : viewPdf : CustomerId [" + customerId + "], MemberId [" + applId +"] ");

		emCorrMbrVO.setCustomerId(customerId);
		emCorrMbrVO.setPrimaryId(applId);

		outputStream = response.getOutputStream();
		emCorrMbrVO.setServletOutputStream(outputStream);
		EEMApplService service = context.getService();
		pdfExists = service.viewApplicationPdfs(conn, emCorrMbrVO);
		if(!pdfExists){
			responseMsg = service.loadPDF(conn, emCorrMbrVO);
			if(responseMsg.equalsIgnoreCase("SUCCESS"))
				pdfExists = service.viewApplicationPdfs(conn, emCorrMbrVO);
			
		}
		if(pdfExists)
			response.setContentType("application/pdf");
		else{
			response.setContentType("text/html");
			String htmlMsg = "<html><body onload='myFunction()'>"
					+"<script>"
					+ "function myFunction() {"
					+"alert('"+responseMsg+"')"
					+ "}"
					+"</script>"
					+ "</body></html>";
			outputStream.write(htmlMsg.getBytes());
		}
	} catch (Exception exception) {
		logger.error(LoggerConstants.exceptionMessage(exception.toString()));
		logger.debug(" EEMAction : viewPdf : Exception : " + exception.getMessage());
//		logger.error(" EEMAction : viewPdf : Exception : " + exception.getMessage());

 	} finally {
	    if( null != outputStream ) {
	    	try {
		    	outputStream.flush();
	        	outputStream.close();
			} catch (IOException ioe) {
				logger.error(LoggerConstants.exceptionMessage(ioe.toString()));
				logger.debug("IOException occured in viewPdf method of EEMAction "+ioe.getMessage() );
//				logger.error("IOException occured in viewPdf method of EEMAction "+ioe.getMessage() );
			}
	    }
 	}
	logger.debug(" EEMAction : viewPdf : End   : ");
//	logger.info(" EEMAction : viewPdf : End   : ");
	logger.info(LoggerConstants.methodEndLevel());
	return mapping.findForward(null);
}
//IFOX-00395242 - viewPdf-- end


/**
 * Start -- for 020_UI Mock_ups-- to view letter from DB
 */
private ActionForward displayDocumentFromDB(Connection conn, SessionHelper sessionHelper, EEMContext context,
		ActionMapping mapping, ActionForm form, HttpServletRequest request, 
		HttpServletResponse response) throws ApplicationException, IOException {
	logger.info(LoggerConstants.methodStartLevel());
	logger.debug(" EEMAction : displayDocumentFromDB : Begin : ");
//	logger.info(" EEMAction : displayDocumentFromDB : Begin : ");
	ServletOutputStream outputStream = null;
	EmCorrMbrVO emCorrMbrVO = new EmCorrMbrVO();
	String selectedMenu = context.getSelectedMenu();

	Connection archivalDBConnection = null; //Added for IFOX-00412749
	
	try {
		response.setContentType("application/pdf");

		String customerId = request.getParameter("customerId");
		String memberId = request.getParameter("primaryId");
		String letterName = request.getParameter("letterName");
		String letterCreationTime = request.getParameter("letterUploadedTime");
			String pdf_archival=request.getParameter("pdf_archival"); //Added for IFOX-00412749
		// eEnroll Sign PDF ; As Sign PDF is in image format , changed the resp content type
		// Ticket # TBD , Faye will create it. 405016
		if(EEMConstants.SIGN_PDF_LETTER_NAME.equalsIgnoreCase(letterName)) {
			response.setContentType("image/png");
		} else {
			response.setContentType("application/pdf");
		}
		
		logger.debug(" EEMAction : displayDocumentFromDB : CustomerId [" + customerId + "], MemberId [" + memberId +
				"], LetterName [" + letterName + "], LetterCreationTime [" + letterCreationTime + "] ");
//		logger.info(" EEMAction : displayDocumentFromDB : CustomerId [" + customerId + "], MemberId [" + memberId +
//				"], LetterName [" + letterName + "], LetterCreationTime [" + letterCreationTime + "] ");

		emCorrMbrVO.setCustomerId(customerId);
		emCorrMbrVO.setPrimaryId(memberId);
		emCorrMbrVO.setLetterName(letterName);
		emCorrMbrVO.setLetterUploadedTime(letterCreationTime);
		emCorrMbrVO.setPdf_archival(pdf_archival); //Added for IFOX-00412749

		outputStream = response.getOutputStream();
		emCorrMbrVO.setServletOutputStream(outputStream);
		EEMApplService service = context.getService();
		//Begin:IFOX-00412749
		if("Y".equalsIgnoreCase(emCorrMbrVO.getPdf_archival())) {
			archivalDBConnection = DbConn.getConnectionForArchivalDB();
			service.displayDocumentFromDB(archivalDBConnection,conn, emCorrMbrVO);
		} else {
			service.displayDocumentFromDB(null, conn, emCorrMbrVO);
		}
	} catch (Exception exception) {
		logger.error(LoggerConstants.exceptionMessage(exception.toString()));
		logger.debug(" EEMAction : displayDocumentFromDB : Exception : " + exception.getMessage());
//		logger.error(" EEMAction : displayDocumentFromDB : Exception : " + exception.getMessage());

   	} finally {
   		if(null != archivalDBConnection)
			try {
				archivalDBConnection.close();
			} catch (SQLException e) {}
	    if( null != outputStream ) {
	    	try {
		    	outputStream.flush();
	        	outputStream.close();
			} catch (IOException ioe) {
				logger.error(LoggerConstants.exceptionMessage(ioe.toString()));
				logger.debug("IOException occured in displayDocumentFromDB method of EEMAction "+ioe.getMessage() );
//				logger.error("IOException occured in displayDocumentFromDB method of EEMAction "+ioe.getMessage() );
			}
	    }
   	}
	//End:IFOX-00412749
	
//	logger.info(" EEMAction : displayDocumentFromDB : End   : ");
	logger.debug(" EEMAction : displayDocumentFromDB : End   : ");
	logger.info(LoggerConstants.methodEndLevel());
	return mapping.findForward(null);
}
/**
 * End -- for 020_UI Mock_ups-- to view letter from DB
 */
/**
 * Start --- save comments in Application Entry Tab
 */			
/*private ActionForward eemApplCommentsUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
	EEMApplForm eemFormAppl = (EEMApplForm) form;
	
	
	EEMApplService service = context.getService();
	EEMApplicationVO filterVO = new EEMApplicationVO();
	
	EEMApplHelper.setCommentList(eemFormAppl);
	EEMApplHelper.setFormToVO(eemFormAppl, filterVO, sessionHelper);
	
	try {
		if (!service.commentsUpdate(conn, filterVO)) {
			// Reset back to form when update fails
			eemFormAppl.setMessage(filterVO.getMessage());
			EEMApplHelper.setFormToVO(eemFormAppl, filterVO, sessionHelper);
			
		}
	} catch (SQLException e) {
		logger.error("eemApplCommentsUpdate ErrorCode: "+e.getMessage());
	}
		service.getOevDetails(conn, filterVO);
		EEMApplHelper.setVOToForm(filterVO, eemFormAppl, sessionHelper);
		EEMApplHelper.loadLookUps(conn, eemFormAppl, sessionHelper);
		EEMApplHelper.setAttestationList(eemFormAppl);
		EEMApplHelper.setApplicationStatus(eemFormAppl, sessionHelper);
		
	return mapping.findForward(EEMApplHelper.getPage(eemFormAppl));
}*/
/**
 * End --- save comments in Application Entry Tab
 */	
	private ActionForward eemApplAgencySearch(Connection conn, SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplForm eemFormAppl = (EEMApplForm) form;
		
		String reqDtCov = request.getParameter("reqDtCov");
		if (!StringUtil.nonNullTrim(reqDtCov).equals("")) {
			eemFormAppl.setReqDtCov(reqDtCov);
		}
		String lob = request.getParameter("enrollLineOfBusiness");
		if (!StringUtil.nonNullTrim(lob).equals("")) {
			eemFormAppl.setEnrollLineOfBusiness(lob);
		}
		//IHP issue for Agent
		if(null != eemFormAppl.getReqDtCov() && !eemFormAppl.getReqDtCov().trim().equals("") )
			sessionHelper.getSession().setAttribute("strReqDtCov", eemFormAppl.getReqDtCov());
		
		String strReqDtCov = (String) sessionHelper.getSession().getAttribute("strReqDtCov");
		if( (null == eemFormAppl.getReqDtCov() || eemFormAppl.getReqDtCov().trim().equals("")) &&
				null != strReqDtCov && !strReqDtCov.trim().equals("") )
			eemFormAppl.setReqDtCov(strReqDtCov.trim());
		//IHP issue for Agent
		
		EEMApplService service = context.getService();
		EEMApplicationVO filterVO = new EEMApplicationVO();
		EEMApplHelper.setFormToVO(eemFormAppl, filterVO, sessionHelper);
		
		filterVO.setCommAgencyId(filterVO.getSearchAgencyId());
		filterVO.setAgencyName(filterVO.getSearchAgencyName());
		
			 
		filterVO.setLstAgencies(service.getLstSrchAgencies(conn, filterVO));
				
					
		EEMApplHelper.setVOToForm(filterVO, eemFormAppl, sessionHelper);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_APPL_AGNCYSEARCH);
	}//eemApplAgentSearch()
	
	private ActionForward eemApplAgencySearchNew(Connection conn, SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplForm eemFormAppl = (EEMApplForm) form;
		
		String reqDtCov = request.getParameter("reqDtCov");
		if (!StringUtil.nonNullTrim(reqDtCov).equals("")) {
			eemFormAppl.setReqDtCov(reqDtCov);
		}
		/**AAH BasePlus Migration IFOX-00426351 Added LOB START*/
		String lob = request.getParameter("enrollLineOfBusiness");
		if (StringUtil.isNotNullNotEmptyNotWhiteSpace(lob)) {
			eemFormAppl.setEnrollLineOfBusiness(lob);
			sessionHelper.getSession().setAttribute("enrollLineOfBusiness", lob);
		}else {
			lob = (String) sessionHelper.getSession().getAttribute("enrollLineOfBusiness");
			if (StringUtil.isNotNullNotEmptyNotWhiteSpace(lob)) 
				eemFormAppl.setEnrollLineOfBusiness(lob);
		}
		/**AAH BasePlus Migration IFOX-00426351 Added LOB END*/
		//IHP issue for Agent
		if(null != eemFormAppl.getReqDtCov() && !eemFormAppl.getReqDtCov().trim().equals("") )
			sessionHelper.getSession().setAttribute("strReqDtCov", eemFormAppl.getReqDtCov());
		
		String strReqDtCov = (String) sessionHelper.getSession().getAttribute("strReqDtCov");
		if( (null == eemFormAppl.getReqDtCov() || eemFormAppl.getReqDtCov().trim().equals("")) &&
				null != strReqDtCov && !strReqDtCov.trim().equals("") )
			eemFormAppl.setReqDtCov(strReqDtCov.trim());
		//IHP issue for Agent
		
		EEMApplService service = context.getService();
		EEMApplicationVO filterVO = new EEMApplicationVO();
		EEMApplHelper.setFormToVO(eemFormAppl, filterVO, sessionHelper);
		
		filterVO.setCommAgencyId(filterVO.getSearchAgencyId());
		filterVO.setAgencyName(filterVO.getSearchAgencyName());
		
			 
		filterVO.setLstAgencies(service.getLstSrchAgenciesNew(conn, filterVO));
				
					
		EEMApplHelper.setVOToForm(filterVO, eemFormAppl, sessionHelper);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_APPL_AGNCYSEARCH_NEW);
	}//eemApplAgentSearch()	
	
	private ActionForward eemEnrollAgencySearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollManager mgr = new EEMEnrollManager();
		mgr.eemEnrollAgencySearch(conn, sessionHelper, context, (EEMEnrollForm)form);		
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_ENROLL_AGNCY_SEARCH);
	}
	
	private ActionForward eemEnrollAgencySearchNew(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollManager mgr = new EEMEnrollManager();
		mgr.eemEnrollAgencySearchNew(conn, sessionHelper, context, (EEMEnrollForm)form);		
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_ENROLL_AGNCY_SEARCH_NEW);
	}	
	
		//Added for SSNRI changes,Method to determine if the given medicareID value is Hic or Mbi : start
		// IFOX-00423084 - BasePlus CMS Nov 2019 Changes - Start
		/*private String isHicOrMbi(String medId) {
			logger.info(LoggerConstants.methodStartLevel());
			String flag = "mbi";
			if(medId.length() == 11){
				if(!Character.isDigit(medId.charAt(0)))
					flag = "hic";
				else if(!Character.isLetter(medId.charAt(1)))
					flag = "hic";
				else if(!Character.isLetterOrDigit(medId.charAt(2)))
					flag = "hic";
				else if(!Character.isDigit(medId.charAt(3)))
					flag = "hic";
				else if(!Character.isLetter(medId.charAt(4)))
					flag = "hic";
				else if(!Character.isLetterOrDigit(medId.charAt(5)))
					flag = "hic";
				else if(!Character.isDigit(medId.charAt(6)))
					flag = "hic";
				else if(!Character.isLetter(medId.charAt(7)))
					flag = "hic";
				else if(!Character.isLetter(medId.charAt(8)))
					flag = "hic";
				else if(!Character.isDigit(medId.charAt(9)))
					flag = "hic";
				else if(!Character.isDigit(medId.charAt(10)))
					flag = "hic";
					
			}
			else 
				flag = "hic";
			logger.info(LoggerConstants.methodEndLevel());
			return flag;
		}*/
		
		private String isHicOrMbi(String medId) {
			logger.info(LoggerConstants.methodStartLevel());
			String flag = "mbi";
			if(medId.length() == 11){
				if(!Character.isDigit(medId.charAt(0)))
					flag = "hic";
				else if(!(Character.isLetter(medId.charAt(1)) && !lookUpForExceptions(medId.charAt(1))))
					flag = "hic";
				else if(!(Character.isLetterOrDigit(medId.charAt(2)) && !lookUpForExceptions(medId.charAt(2))))
					flag = "hic";
				else if(!Character.isDigit(medId.charAt(3)))
					flag = "hic";
				else if(!(Character.isLetter(medId.charAt(4)) && !lookUpForExceptions(medId.charAt(4))))
					flag = "hic";
				else if(!(Character.isLetterOrDigit(medId.charAt(5)) && !lookUpForExceptions(medId.charAt(5))))
					flag = "hic";
				else if(!Character.isDigit(medId.charAt(6)))
					flag = "hic";
				else if(!(Character.isLetter(medId.charAt(7)) && !lookUpForExceptions(medId.charAt(7))))
					flag = "hic";
				else if(!(Character.isLetter(medId.charAt(8)) && !lookUpForExceptions(medId.charAt(8))))
					flag = "hic";
				else if(!Character.isDigit(medId.charAt(9)))
					flag = "hic";
				else if(!Character.isDigit(medId.charAt(10)))
					flag = "hic";
					
			}
			else 
				flag = "hic";
			logger.info(LoggerConstants.methodEndLevel());
			return flag;
		}
	
		
		private boolean lookUpForExceptions(char ch) {
			char[] exclusions = {'S', 'L', 'O', 'I', 'B', 'Z'};
			
			for(char c:exclusions){
				if(ch == c) {
					//System.out.println("Exclusion Char is Present: " + c);
					return true;
				}
					
			}
			return false;
			
		}
		// IFOX-00423084 - BasePlus CMS Nov 2019 Changes - End 
		//Added for SSNRI changes,Method to determine if the given medicareID value is Hic or Mbi : end
	//new LEP changes -- start

	private ActionForward eemAppLepUnCovPtnlMnthDelete(Connection conn,
				SessionHelper sessionHelper, EEMContext context,
				ActionMapping mapping, ActionForm form, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
			try{
					EEMApplManager applManager = new EEMApplManager();
					
					EEMApplForm eemFormAppl = (EEMApplForm) form;
					
					EEMApplicationVO filterVO = new EEMApplicationVO();
					EEMApplHelper.setFormToVO(eemFormAppl,filterVO,sessionHelper);
					
					applManager.applLepCovPtnlMnthsDelete(conn, sessionHelper, context,(EEMApplForm) form,filterVO);
					applManager.applSelect(conn, sessionHelper, context,(EEMApplForm) form,filterVO);
					
					
					EEMApplHelper.setVOToForm(filterVO,eemFormAppl,sessionHelper);
			}catch(Exception e){
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				//logger.error("Exception : " + e.getMessage());
			}
			logger.info(LoggerConstants.methodEndLevel());
			 return mapping.findForward("lepDetailsPage");
		}
		
	
	private ActionForward eemAppLepAttnDelete(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		try{
				EEMApplManager applManager = new EEMApplManager();
				EEMApplForm eemFormAppl = (EEMApplForm) form;
				EEMApplicationVO filterVO = new EEMApplicationVO();
				EEMApplHelper.setFormToVO(eemFormAppl,filterVO,sessionHelper);
			
				applManager.applAttnInfoDelete(conn, sessionHelper, context,(EEMApplForm) form,filterVO);
				applManager.applSelect(conn, sessionHelper, context,(EEMApplForm) form,filterVO);
				EEMApplHelper.setVOToForm(filterVO,eemFormAppl,sessionHelper);
			
		}catch(Exception e){
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
		}
		logger.info(LoggerConstants.methodEndLevel());
		 return mapping.findForward("lepDetailsPage");
	}
	//new LEP changes -- end
	
	// new LEP changes -- start
	private ActionForward eemAppLepUnCovPtnlMnthUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)
			throws ApplicationException, SQLException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			EEMApplManager applManager = new EEMApplManager();

			EEMApplForm eemFormAppl = (EEMApplForm) form;
			EEMApplicationVO filterVO = new EEMApplicationVO();

			EEMApplHelper.setFormToVO(eemFormAppl, filterVO, sessionHelper);

			// System.out.println("In LEP Action");
			applManager.applLEPCovPtnlMnthsUpdate(conn, sessionHelper, context, (EEMApplForm) form, filterVO);
			applManager.applSelect(conn, sessionHelper, context, (EEMApplForm) form, filterVO);

			EEMApplHelper.setVOToForm(filterVO, eemFormAppl, sessionHelper);

			if (eemFormAppl.getOutInitAttests().size() != filterVO.getOutInitAttests().size()) {
				eemFormAppl.setOutInitAttests(filterVO.getOutInitAttests());
				eemFormAppl.setInInitAttests(filterVO.getInInitAttests());
				eemFormAppl.setOutIncAttests(filterVO.getOutIncAttests());
				eemFormAppl.setInIncAttests(filterVO.getInIncAttests());
				eemFormAppl.setInLateAttests(filterVO.getInLateAttests());
			}

		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("EEMAction updating LEP At values @ APPL Side::eemappLEPUpdate " + e.getMessage());
//			logger.info("EEMAction updating LEP At values @ APPL Side::eemappLEPUpdate " + e.getMessage());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward("lepDetailsPage");
	}

//new LEP changes -- end
	
	// new LEP CR Start
		private ActionForward eemappLEPShowAll(Connection conn, SessionHelper sessionHelper, EEMContext context,
				ActionMapping mapping, ActionForm form, HttpServletRequest request)
				throws ApplicationException, SQLException {
			logger.info(LoggerConstants.methodStartLevel());
			try {

				EEMApplManager applManager = new EEMApplManager();
				EEMApplForm eemFormAppl = (EEMApplForm) form;
				EEMApplicationVO filterVO = new EEMApplicationVO();
				EEMApplHelper.setFormToVO(eemFormAppl, filterVO, sessionHelper);

				// System.out.println("In LEP Action");
				// applManager.applLEPUpdate(conn, sessionHelper,
				// context,(EEMApplForm) form,filterVO);
				applManager.applSelect(conn, sessionHelper, context, (EEMApplForm) form, filterVO);

				EEMApplHelper.setVOToForm(filterVO, eemFormAppl, sessionHelper);

				if (eemFormAppl.getOutInitAttests().size() != filterVO.getOutInitAttests().size()) {
					eemFormAppl.setOutInitAttests(filterVO.getOutInitAttests());
					eemFormAppl.setInInitAttests(filterVO.getInInitAttests());
					eemFormAppl.setOutIncAttests(filterVO.getOutIncAttests());
					eemFormAppl.setInIncAttests(filterVO.getInIncAttests());
					eemFormAppl.setInLateAttests(filterVO.getInLateAttests());
				}
			} catch (Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("EEMAction updating LEP At values @ APPL Side::eemappLEPUpdate " + e.getMessage());
//				logger.info("EEMAction updating LEP At values @ APPL Side::eemappLEPUpdate " + e.getMessage());
			}
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward("lepDetailsPage");
		}
		// new LEP CR End
		//IFOX-00426356: Attachment CR:start
		private ActionForward eemLetterAttachmentSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
			logger.info(LoggerConstants.methodStartLevel());
			EEMLetterReviewManager mgr = new EEMLetterReviewManager();
			mgr.letterAttachmentSearch(conn,sessionHelper,context,(EEMLetterReviewAttachmentForm)form);
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.EEM_LTR_ATTACHMENT);
		}
		private ActionForward eemLetterAttachSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
			logger.info(LoggerConstants.methodStartLevel());
			EEMLetterReviewManager mgr = new EEMLetterReviewManager();
			mgr.letterAttachmentSelect(conn,sessionHelper,context,(EEMLetterReviewAttachmentForm)form,true);
			
			return mapping.findForward(EEMConstants.EEM_LTR_ATTACHMENT);
		}
		private ActionForward uploadLetterAttachment(Connection conn, SessionHelper sessionHelper, EEMContext context,
				ActionMapping mapping, ActionForm form, HttpServletRequest request) 
		{
			logger.info(LoggerConstants.methodStartLevel());
			try {
				
				String filePathInServer = this.uploadAttachmentToServer(form, request);
				logger.info(" EEMAction : uploadLetters : filePathInServer [" + filePathInServer + "] ");
				if(null != filePathInServer && !filePathInServer.trim().equals("")) {
					this.uploadAttachmentToDatabase(filePathInServer, conn, form, request,sessionHelper.getUserId(),sessionHelper.getMfId());
				}
				eemLetterAttachmentSearch(conn, sessionHelper, context, mapping, form, request);
			} catch(Exception exception) {
				logger.error(LoggerConstants.exceptionMessage(exception.toString()));
				logger.debug(" EEMAction :  uploadLetters : " + exception.getMessage());
//				logger.error(" EEMAction :  uploadLetters : " + exception.getMessage());
			}
			request.setAttribute("UploadedStatus", "Y");
			request.setAttribute("ackMessage", "Document Uploaded Successfully");
			
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(EEMConstants.EEM_LTR_ATTACHMENT);
		}
		private String uploadAttachmentToServer(ActionForm form, HttpServletRequest request) throws ApplicationException, IOException
		{
			logger.info(LoggerConstants.methodStartLevel());
			String uploadedFilePathInServer =MssProperties.getLetterUploadDir();
			logger.debug(" EEMAction : uploadLettersToServer : Begin : "+uploadedFilePathInServer);
			if(null==uploadedFilePathInServer || "".equalsIgnoreCase(uploadedFilePathInServer)){
				uploadedFilePathInServer=EEMConstants.LETTER_UPLOAD_DIR_DEFAULT;
			}

			try {
			
				EEMLetterReviewAttachmentForm attachForm = (EEMLetterReviewAttachmentForm)form;
				FormFile file = attachForm.getFile();
			    String fileName = file.getFileName();

			    logger.debug(" EEMAction : uploadLettersToServer : fileName [" + fileName + "] ");

			    if(!("").equals(fileName))
			    {
			    	attachForm.setFileName(fileName);
			    	uploadedFilePathInServer = uploadedFilePathInServer + fileName;
			        File newFile = new File(uploadedFilePathInServer);
			        if(!newFile.exists()){
			          FileOutputStream fos = new FileOutputStream(newFile);
			          fos.write(file.getFileData());
			          fos.flush();
			          fos.close();
			        }  
			    }
			   
			} catch (Exception exception) {
				logger.error(LoggerConstants.exceptionMessage(exception.toString()));
				logger.debug(" EEMAction : uploadLettersToServer : Exception : " + exception.getMessage());

		   	}
			logger.debug(" EEMAction : uploadLettersToServer : End   : ");
			logger.info(LoggerConstants.methodEndLevel());
			return uploadedFilePathInServer;
		}
		private void uploadAttachmentToDatabase(String filePathInServer, Connection conn,
				ActionForm form, HttpServletRequest request,String userId, String custId) throws ApplicationException, IOException {
			logger.info(LoggerConstants.methodStartLevel());
			logger.debug(" EEMAction : uploadAttachmentToDatabase : Begin : ");

			EEMEnrollDao eemEnrollDao = new EEMEnrollDao();
			String strDateTimeStamp = new DateUtil().getDB2DTS();
			
			String fileName = null;
			
			try {
				EEMLetterReviewAttachmentForm attachForm = (EEMLetterReviewAttachmentForm)form;
				attachForm.setUserID(userId);
				attachForm.setCustomerId(custId);
				
				if( attachForm.getFileName().lastIndexOf(".pdf") != -1 )
					fileName = attachForm.getFileName().substring(0, attachForm.getFileName().lastIndexOf(".pdf"));
				else
					fileName = attachForm.getFileName().substring(0, attachForm.getFileName().lastIndexOf(".PDF"));
			
				String fileBatchId = eemEnrollDao.getMaxFileBatchId(conn, attachForm.getCustomerId(), attachForm.getSearchId(), fileName,"ATH");
				logger.debug(" EEMAction : uploadLettersToDatabase : Max FileBatchId from DB [ " + fileBatchId + "] ");

				fileBatchId = this.getIncrementedFileBatchId(fileBatchId,"ATH");
				attachForm.setFileName(fileName);
				attachForm.setFileBatchId(fileBatchId);
				String searchId = attachForm.getSearchId();
				
				logger.debug(" EEMAction : uploadLettersToDatabase : FileBatchId After Increment [ " + fileBatchId + "] ");
				if(StringUtil.nonNullTrim(attachForm.getSearchType()).equals("M")){
					searchId = eemEnrollDao.getmaxApplId(conn,attachForm.getCustomerId(),attachForm.getSearchId() );
	
				}
				//If Application, remove leading zeroes
				if(StringUtil.nonNullTrim(attachForm.getSearchType()).equals("A")){
					searchId = searchId.trim().replaceFirst("^0+(?!$)", "");
	
				}
				
				eemEnrollDao.uploadLettersToDataBase(filePathInServer, conn, attachForm.getCustomerId(),searchId ,
						fileName, attachForm.getUserID(), fileBatchId, strDateTimeStamp );

			} catch (Exception exception) {
				logger.error(LoggerConstants.exceptionMessage(exception.toString()));
				logger.debug(" EEMAction : uploadLettersToDatabase : Exception : " + exception.getMessage());
//				logger.error(" EEMAction : uploadLettersToDatabase : Exception : " + exception.getMessage());
		   	}
			logger.debug(" EEMAction : uploadLettersToDatabase : End   : ");
//			logger.info(" EEMAction : uploadLettersToDatabase : End   : ");
			logger.info(LoggerConstants.methodEndLevel());
		}
		private ActionForward eemLetterAttachSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request, String move) throws ApplicationException {
			logger.info(LoggerConstants.methodStartLevel());
			EEMLetterReviewManager mgr = new EEMLetterReviewManager();
			mgr.letterAttachmentSearchPage(conn,sessionHelper,context,(EEMLetterReviewAttachmentForm)form,move);
			logger.info(LoggerConstants.methodEndLevel());
			
			return mapping.findForward(EEMConstants.EEM_LTR_ATTACHMENT);
		}
		//IFOX-00426356: Attachment CR:end
		//IFOX-00430896 - Ltter Upload Changes for Sentara -start
	    private String ftpToServer (ActionForm form,HttpServletRequest request, String filePath, String custId){
	        
            FTPClient ftpClient = new FTPClient();
            boolean done = false;
            Properties prop = new Properties();
            String custDir = null;
            int returnCode = 0;
            String remoteFilePath = "";
            try {
        			
        		EEMLetterUploadForm letterUploadForm = (EEMLetterUploadForm)form;
        		FormFile file = letterUploadForm.getFile();
        		String fileName = file.getFileName();
        		
        		prop.load(getClass().getClassLoader().getResourceAsStream("mss/resources/LtrUploadDir.properties"));
        		custDir = prop.getProperty(custId);
            	String ftpServer = MssProperties.getUploadServer();
            	String userID = MssProperties.getUploadFtpUser();
            	String pwd = MssProperties.getUploadFtpPwd();
            	String ftpDir = MssProperties.getUploadFtpDir();
                ftpClient.connect(ftpServer, 21);
                returnCode = ftpClient.getReplyCode();
                
                if (!FTPReply.isPositiveCompletion(returnCode)) {
                    throw new IOException("Could not connect FTP server");
                }
                boolean loggedIn =  ftpClient.login(userID, pwd);
                if (!loggedIn) {
                    throw new IOException("Could not login");
                }
                ftpClient.enterLocalPassiveMode();
                ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
     
                File LocalFile = new File(filePath);
                String folder = new DateUtil().getFTPDTS();
                
                //ftpClient.changeWorkingDirectory("OutPutPDF");
                FTPFile[] files = ftpClient.listDirectories();
    			System.out.println("List of Directory on Ftp Server : ");
    			for (FTPFile dir : files) {
    				if (dir.getName().trim().equals(custDir)) {
    					logger.debug("Found Directory ");
    					ftpClient.changeWorkingDirectory(custDir.trim());
    		            ftpClient.makeDirectory(folder);
    		            ftpClient.changeWorkingDirectory(folder);
    		            
    		            InputStream inputStream = new FileInputStream(LocalFile);
    		                
    		            done = ftpClient.storeFile(fileName, inputStream);
    		            inputStream.close();
    		                
    		               if (done) {
    		                   logger.debug("The file is uploaded using FTP successfully.");
    		                   remoteFilePath = ftpDir.trim()+custDir.trim()+"/"+folder.trim()+"/"+fileName;
    		                   System.out.println("RemoteFilePath for FTP UploadLetters"+remoteFilePath);
    		                }
    					
    				} else {
    					logger.debug("Customer Directory not found");
    				}
    			}
               
                 
            } catch (IOException ex) {
                System.out.println("Error: " + ex.getMessage());
                logger.error(ex.getMessage());
                 
            } finally {
                 
                try {
                    if (ftpClient.isConnected()) {
                        ftpClient.logout();
                        ftpClient.disconnect();
                    }
                     
                } catch (IOException ex) {
                	logger.error(ex.getMessage());
                }
                prop.clear();
                 
            } 
            return remoteFilePath;
    }   
	    
	  //IFOX-00430896 - Ltter Upload Changes for Sentara -end

}//class
