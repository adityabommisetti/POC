package com.ps.mss.web.forms;

import java.util.List;

/**
 * @author Arun Kumar
 *
 */
public class EEMTrrDataForm extends EEMForm {

	private static final long serialVersionUID = 2911782414136925182L;

	private String customerId;
	private String memberId;
	private String effDate;
	private String trrReplyCd;
	private String variableDesc;
	private String variableId;
	private String VariableDataDesc;
	
	private List searchResults;

	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId
	 *            the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the memberId
	 */
	public String getMemberId() {
		return memberId;
	}

	/**
	 * @param memberId
	 *            the memberId to set
	 */
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	/**
	 * @return the effDate
	 */
	public String getEffDate() {
		return effDate;
	}

	/**
	 * @param effDate the effDate to set
	 */
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}

	
	/**
	 * @return the searchResults
	 */
	public List getSearchResults() {
		return searchResults;
	}

	/**
	 * @param searchResults
	 *            the searchResults to set
	 */
	public void setSearchResults(List searchResults) {
		this.searchResults = searchResults;
	}
	
	public String getTrrReplyCd() {
		return trrReplyCd;
	}

	public void setTrrReplyCd(String trrReplyCd) {
		this.trrReplyCd = trrReplyCd;
	}

	public String getVariableDesc() {
		return variableDesc;
	}

	public void setVariableDesc(String variableDesc) {
		this.variableDesc = variableDesc;
	}

	public String getVariableId() {
		return variableId;
	}

	public void setVariableId(String variableId) {
		this.variableId = variableId;
	}

	public String getVariableDataDesc() {
		return VariableDataDesc;
	}

	public void setVariableDataDesc(String variableDataDesc) {
		VariableDataDesc = variableDataDesc;
	}
   
}