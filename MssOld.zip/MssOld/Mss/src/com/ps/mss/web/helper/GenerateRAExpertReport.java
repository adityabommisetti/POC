/*
 * $Id: GenerateRAExpertReport.java,v 1.1 2014/06/26 07:55:03 praveen Exp $
 *
 */
package com.ps.mss.web.helper;

import java.awt.Color;
import java.sql.Connection;
import java.util.Iterator;
import java.util.List;
import org.slf4j.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.LoggerFactory;
import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;
import com.ps.mss.db.BeneficiaryPersistence;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.RAHccHistory;
import com.ps.mss.db.RAHccHistoryItem;
import com.ps.mss.db.RAHccProjection;
import com.ps.mss.db.RAHccProjectionItem;
import com.ps.mss.db.RAPSFinancialAuditPersistence;
import com.ps.mss.db.RAPaymentItem;
import com.ps.mss.db.RAPSFinancialAudit;
import com.ps.mss.db.RAYrToYrCompare;
import com.ps.mss.db.view.BeneInfo;
import com.ps.mss.pdf.RAExpertReportPDFUtil;
import com.ps.mss.security.SessionManager;
import com.ps.mss.util.MssProperties;
import com.ps.pdf.PdfFontUtil;
import com.ps.pdf.PdfTable;
import com.ps.pdf.PdfUtil;

public class GenerateRAExpertReport {
	//private static ModuleLog log = new ModuleLog("GenerateRAExpertReport");
	private static Logger logger=LoggerFactory.getLogger(GenerateRAExpertReport.class);

	RAExpertReportPDFUtil raExpertPDFUtil = new RAExpertReportPDFUtil();
	
	public static void createReport(HttpServletRequest request, HttpServletResponse response, String reportType) throws ServletException{
		logger.info(LoggerConstants.methodStartLevel());
	    String BaseUrl = MssProperties.getWebAppURL();
	    String XferUrl = MssProperties.getFtpAppURL();
	    	
	    Connection conn = null;       
	    String User_name = null; 
		String planId = request.getParameter("planId"); 
		String hicNumber = request.getParameter("hicNbr");
		String year = request.getParameter("paymentYear");
		int paymentYear = -1;
		if (null != year && !"".equals(year))
			paymentYear = Integer.parseInt(year);
		String thisYear = "";
		String prevYear = "";
		String prevs = "";
		if(paymentYear != -1) {
			thisYear = String.valueOf(paymentYear);
			prevYear = String.valueOf(paymentYear - 1);
			prevs = String.valueOf(paymentYear - 2);
		}
		//Financial Audit variable
		String diagCd = request.getParameter("diagCd");
		String partCCat = request.getParameter("partCCat");
		String partDCat = request.getParameter("partDCat");
		String hccPart = request.getParameter("hccPart");
		if (null != hccPart && hccPart.equalsIgnoreCase("undefined"))
			hccPart = "";
		
		try{
	        conn = DbConn.getConnection();

		    HttpSession session = SessionManager.getSession(request, conn);
		    if (session == null)
		    {
		        logger.debug("No Session");
//		        logger.error("No Session");
		        response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/RAExpertPDFLoadError.jsp"));
		        logger.info(LoggerConstants.methodEndLevel());
		        return;
		    }
		    String User_id = (String)session.getAttribute("User_id");
		    if (User_id == null)
		    {
		       logger.debug("No User_id");
//		       logger.error("No User_id");
		       response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/RAExpertPDFLoadError.jsp"));
		       logger.info(LoggerConstants.methodEndLevel());
		       return;
		    }
		    String MF_id = (String)session.getAttribute("MF_id");
		    if (MF_id == null)
		    {
//		    	logger.error("No MF_id");
		       logger.debug("No MF_id");
		       response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/RAExpertPDFLoadError.jsp"));
		       logger.info(LoggerConstants.methodEndLevel());
		       return;
		    }
		    
			String reconDb = (String) session.getAttribute("ReconDB");
			conn = DbConn.reGetConnection(conn,reconDb);		    
			
			BeneficiaryPersistence beneficiaryPersistence = new BeneficiaryPersistence();
			BeneInfo beneInfo = beneficiaryPersistence.getBeneInfo(conn, planId, hicNumber);

			if ( beneInfo.isClaimValid()){
		        User_name =  beneInfo.getLastName() + " " + beneInfo.getFirstName();
	        }else{
	        	User_name = "Hic Number is not valid.";
	        }

		    
		    /***********************  Start Report generation *********************************************/
					    
		    response.setContentType("application/pdf");		    
			
			PdfUtil pdfUtil = new PdfUtil("");
			pdfUtil.setLayout(PdfUtil.LANDSCAPE);
			pdfUtil.setLeftMargin(40);
			pdfUtil.setTopMargin(20);
			pdfUtil.enableSilentPrint(true);
			pdfUtil.createPDF(response.getOutputStream());
			
			//To print to a file:
/*			PdfUtil pdfUtil = new PdfUtil("c:/temp/mypdf.pdf");
			pdfUtil.setLayout(PdfUtil.LANDSCAPE);
			pdfUtil.setLeftMargin(40);
			pdfUtil.setTopMargin(20);
			pdfUtil.enableSilentPrint(false);
			pdfUtil.createPDF();
*/	
			int rowIndex = 0;
	
			// Member Detail Table
			PdfTable memberDetailTable = new PdfTable(4);
			memberDetailTable.setFont(RAExpertReportPDFUtil.normalTextFont);
			memberDetailTable.setBorder(0);
			float[] memberDetailColWidths = {10f,40f,15f,35f};
			memberDetailTable.setColumnWidths(memberDetailColWidths);
		
			rowIndex = memberDetailTable.addRow();
			memberDetailTable.setText(rowIndex, 1, "Plan ID :");
			memberDetailTable.setFont(rowIndex, 1, RAExpertReportPDFUtil.title1BoldFont);
			memberDetailTable.setText(rowIndex, 2, planId);
			memberDetailTable.setFont(rowIndex, 2, RAExpertReportPDFUtil.title1NormalFont);
	
			rowIndex = memberDetailTable.addRow();
			memberDetailTable.setText(rowIndex, 1, "Hic Nbr :");
			memberDetailTable.setFont(rowIndex, 1, RAExpertReportPDFUtil.title1BoldFont);
			memberDetailTable.setText(rowIndex, 2, hicNumber);
			memberDetailTable.setFont(rowIndex, 2, RAExpertReportPDFUtil.title1NormalFont);
	
			memberDetailTable.setText(rowIndex, 3, "Member Name : ");
			memberDetailTable.setFont(rowIndex, 3, RAExpertReportPDFUtil.title1BoldFont);
			memberDetailTable.setText(rowIndex, 4, User_name);
			memberDetailTable.setFont(rowIndex, 4, RAExpertReportPDFUtil.title1NormalFont);	
			
			// MAIN TABLE
			
			PdfTable pdfTable = new PdfTable(1);
			pdfTable.setWidthPercentage(100);
			pdfTable.setBorder(0);
			pdfTable.setAlignment(PdfTable.CENTER);
			pdfTable.setFont(RAExpertReportPDFUtil.pageHeadingFont);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "RA-Expert ");
						
			rowIndex = pdfTable.addRow();
			if ("YrToYr".equals(reportType)) 
				pdfTable.setText(rowIndex, 1, "Year to Year Risk-Payment");
			else if ("hccHist".equals(reportType))
				pdfTable.setText(rowIndex, 1, "HCC History Review");
			else if ("hccProj".equals(reportType))
				pdfTable.setText(rowIndex, 1, "HCC Projection Review");
			else if ("finAudit".equals(reportType))
				pdfTable.setText(rowIndex, 1, "RAPS Financial Audit");

			rowIndex = pdfTable.addRow();
			if ("hccProj".equals(reportType))
				pdfTable.setText(rowIndex, 1, "Data Collection Dates " + prevYear + " thru " + thisYear);
			else if (!"finAudit".equals(reportType))
				pdfTable.setText(rowIndex, 1, "Data Collection Dates 01/01/" + prevs + " thru 12/31/" + thisYear);
	
			rowIndex = pdfTable.addSpacerLine(12);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, memberDetailTable);

			if ("YrToYr".equals(reportType)) {
				List results = RAYrToYrCompare.getList(conn, planId, hicNumber, paymentYear);
				// Define the numbers table	
				PdfTable reconPayTable = new PdfTable(9);
				reconPayTable.setWidthPercentage(100);
				reconPayTable.setBorder(0);
				reconPayTable.setFont(RAExpertReportPDFUtil.normalTextFont);
				reconPayTable.setAlignment(PdfTable.CENTER);
				float[] reconPayTableWidths = {10f,10f,10f,10f,14f,14f,14f,9f,9f};
				reconPayTable.setColumnWidths(reconPayTableWidths);
	
				printTableHeaderYrToYr(reconPayTable, reconPayTableWidths);					
				printTableBodyYrToYr(reconPayTable, results);				
				rowIndex = pdfTable.addSpacerLine(12);	
				rowIndex = pdfTable.addRow();
				pdfTable.setTable(rowIndex, 1, reconPayTable);
			}
			else if  ("hccHist".equals(reportType)){
				List results = RAHccHistory.getList(conn, planId, hicNumber, paymentYear,null);
				// Define the numbers table	
				PdfTable reconPayTable = new PdfTable(9);
				reconPayTable.setWidthPercentage(100);
				reconPayTable.setBorder(0);
				reconPayTable.setFont(RAExpertReportPDFUtil.normalTextFont);
				reconPayTable.setAlignment(PdfTable.CENTER);
				float[] reconPayTableWidths = {7f,44f,7f,7f,7f,7f,7f,7f,7f};
				reconPayTable.setColumnWidths(reconPayTableWidths);
	
				printTableHeaderHccHist(reconPayTable, reconPayTableWidths, paymentYear);					
				printTableBodyHccHist(reconPayTable, results);				
				rowIndex = pdfTable.addSpacerLine(12);	
				rowIndex = pdfTable.addRow();
				pdfTable.setTable(rowIndex, 1, reconPayTable);
				rowIndex = pdfTable.addRow();
				pdfTable.setAlignment(PdfTable.LEFT);
				pdfTable.setText(rowIndex, 1, "Legend: X=HCC, I=HCC last reported on INTERIM MOR during the JAN-JUN period");
			}
			else if ("hccProj".equals(reportType)) {
				List results = RAHccProjection.getList(conn, planId, hicNumber, paymentYear,null);
				// Define the numbers table	
				PdfTable reconPayTable = new PdfTable(7);
				reconPayTable.setWidthPercentage(100);
				reconPayTable.setBorder(0);
				reconPayTable.setFont(RAExpertReportPDFUtil.normalTextFont);
				reconPayTable.setAlignment(PdfTable.CENTER);
				float[] reconPayTableWidths = {7f,44f,7f,7f,7f,7f,7f};
				reconPayTable.setColumnWidths(reconPayTableWidths);
	
				printTableHeaderHccProj(reconPayTable, reconPayTableWidths, paymentYear);					
				printTableBodyHccProj(reconPayTable, results);				
				rowIndex = pdfTable.addSpacerLine(12);	
				rowIndex = pdfTable.addRow();
				pdfTable.setTable(rowIndex, 1, reconPayTable);
				rowIndex = pdfTable.addRow();
				pdfTable.setAlignment(PdfTable.LEFT);
				pdfTable.setText(rowIndex, 1, "Legend: X=HCC, I=HCC last reported on INTERIM MOR during the JAN-JUN period");
			}
			else if ("finAudit".equals(reportType)) {
				/*
				RAPSFinancialAuditPersistence rapsFinancialAuditPersistence = new RAPSFinancialAuditPersistence();
				List results = rapsFinancialAuditPersistence.getRAPSFinancialAudit(conn, MF_id, planId, hicNumber, thisYear, diagCd, partCCat, partDCat, hccPart);
				// Define the numbers table	
				PdfTable reconPayTable = new PdfTable(19);
				reconPayTable.setWidthPercentage(100);
				reconPayTable.setBorder(0);
				reconPayTable.setFont(RAExpertReportPDFUtil.normalTextFont);
				reconPayTable.setAlignment(PdfTable.CENTER);
				float[] reconPayTableWidths = {7f,9f,4f,4f,5f,7f,7f,6f,4f,4f,4f,4f,6f,6f,6f,5f,5f,5f,9f};
				reconPayTable.setColumnWidths(reconPayTableWidths);
	
				printTableHeaderFinAudit(reconPayTable, reconPayTableWidths);
				rowIndex = pdfTable.addSpacerLine(12);	
				rowIndex = pdfTable.addRow();
				pdfTable.setTable(rowIndex, 1, reconPayTable);

				printTableBodyFinAudit(pdfTable, reconPayTableWidths, results);
				*/

				RAPSFinancialAuditPersistence rapsFinancialAuditPersistence = new RAPSFinancialAuditPersistence();
				List results = rapsFinancialAuditPersistence.getRAPSFinancialAudit(conn, MF_id, planId, hicNumber, thisYear, diagCd, partCCat, partDCat, hccPart,null);
				printTableFinAudit(pdfTable, results);
			}
	
			pdfUtil.addTable(pdfTable);
	
			pdfUtil.close();
	
		}catch(Exception ex){
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			logger.debug("GenerateRAExpertReport : createReport : Caught Exception" + ex);
//			logger.error("GenerateRAExpertReport : createReport : Caught Exception" + ex);
			throw new ServletException(ex);
		} finally {
			try {
				if (conn != null) conn.close();
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				//logger.error(e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	private static void printTableHeaderYrToYr ( PdfTable reconPayTable, float[] reconPayTableWidths) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		String boldTextFont = PdfFontUtil.defineFont("BOLD_TEXT_FONT", PdfFontUtil.COURIER, 9, PdfFontUtil.BOLD_FONT);
		
		try{		
			int rowIndex = reconPayTable.addRow();		// New Row
			for (int i =0; i< reconPayTableWidths.length; i++) { //draw line
				reconPayTable.drawLine(rowIndex, 1+i, .75f, Color.LIGHT_GRAY);
			}
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setFont(rowIndex, boldTextFont);			
			reconPayTable.setText(rowIndex, 1, "RAPS MOR");
			reconPayTable.setAlignment(rowIndex, 1, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 2, "RAPS RA");
			reconPayTable.setAlignment(rowIndex, 2, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 3, "RAPS/MOR");
			reconPayTable.setAlignment(rowIndex, 3, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 4, "Plan ");
			reconPayTable.setAlignment(rowIndex, 4, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 5, "RAPS Amount");
			reconPayTable.setAlignment(rowIndex, 5, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 6, "RAPS/MOR");
			reconPayTable.setAlignment(rowIndex, 6, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 7, "Plan RECON");
			reconPayTable.setAlignment(rowIndex, 7, PdfTable.CENTER);
			reconPayTable.setColSpan(rowIndex, 8, 2);
			reconPayTable.setText(rowIndex, 8, "**Months reported** ");
			reconPayTable.setAlignment(rowIndex, 8, PdfTable.CENTER);
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.drawLine(rowIndex, 8, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 9, .75f, Color.LIGHT_GRAY);
			rowIndex = reconPayTable.addRow();		// New Row

			reconPayTable.setFont(rowIndex, boldTextFont);
			reconPayTable.setText(rowIndex, 1, "Year");
			reconPayTable.setAlignment(rowIndex, 1, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 2, "Factor");
			reconPayTable.setAlignment(rowIndex, 2, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 3, "RA Factor");
			reconPayTable.setAlignment(rowIndex, 3, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 4, "RA Factor");
			reconPayTable.setAlignment(rowIndex, 4, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 5, " ");
			reconPayTable.setAlignment(rowIndex, 5, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 6, "Amount");
			reconPayTable.setAlignment(rowIndex, 6, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 7, "Payment");
			reconPayTable.setAlignment(rowIndex, 7, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 8, "Plan");
			reconPayTable.setAlignment(rowIndex, 8, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 9, "MMR");
			reconPayTable.setAlignment(rowIndex, 9, PdfTable.CENTER);	
			rowIndex = reconPayTable.addRow();		// New Row
			for (int i =0; i< reconPayTableWidths.length; i++) {
				reconPayTable.drawLine(rowIndex, 1+i, .75f, Color.LIGHT_GRAY);
			}
			
		}catch ( Exception ex){
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			logger.debug("GenerateRAExpertReport : printTableHeaderYrToYr : " + ex);
//			logger.error("GenerateRAExpertReport : printTableHeaderYrToYr : " + ex);
			throw ex;			
		}
		logger.info(LoggerConstants.methodEndLevel());
	}	
	
	private static void printTableBodyYrToYr ( PdfTable reconPayTable, List items) throws Exception{			
		logger.info(LoggerConstants.methodStartLevel());
		try{
			int rowIndex;
			if (items==null || items.size() == 0) {
				rowIndex = reconPayTable.addRow();		// New Row
				reconPayTable.setText(rowIndex, 1, " No record Found");
				reconPayTable.setAlignment(rowIndex, 1, PdfTable.LEFT);
				logger.info(LoggerConstants.methodEndLevel());
				return;
			}
			Iterator it = items.iterator();
			while (it.hasNext()) {
				RAPaymentItem item = (RAPaymentItem) it.next();
				rowIndex = reconPayTable.addRow();		// New Row
				reconPayTable.setText(rowIndex, 1, String.valueOf(item.getYear()));
				reconPayTable.setAlignment(rowIndex, 1, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 2, String.valueOf(item.getRaFactor()));
				reconPayTable.setAlignment(rowIndex, 2, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 3, String.valueOf(item.getMorRaFactor()));
				reconPayTable.setAlignment(rowIndex, 3, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 4, String.valueOf(item.getPlanRaFactor()));
				reconPayTable.setAlignment(rowIndex, 4, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 5, String.valueOf(item.getFormattedAmount()));
				reconPayTable.setAlignment(rowIndex, 5, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 6, String.valueOf(item.getFormattedMorAmount()));
				reconPayTable.setAlignment(rowIndex, 6, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 7, String.valueOf(item.getFormattedReconPayment()));
				reconPayTable.setAlignment(rowIndex, 7, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 8, String.valueOf(item.getPlanCount()));
				reconPayTable.setAlignment(rowIndex, 8, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 9, String.valueOf(item.getMmrCount()));
				reconPayTable.setAlignment(rowIndex, 9, PdfTable.CENTER);				
			}
			
		}catch ( Exception ex){
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			logger.debug("GenerateRAExpertReport : printTableBodyYrToYr : " + ex);
//			logger.error("GenerateRAExpertReport : printTableBodyYrToYr : " + ex);
			throw ex;			
		}	
		logger.info(LoggerConstants.methodEndLevel());
	}

	
	
	private static void printTableHeaderHccHist ( PdfTable reconPayTable, float[] reconPayTableWidths, int year) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		String boldTextFont = PdfFontUtil.defineFont("BOLD_TEXT_FONT", PdfFontUtil.COURIER, 9, PdfFontUtil.BOLD_FONT);
		
		try{		
			int rowIndex = reconPayTable.addRow();		// New Row
			for (int i =0; i< reconPayTableWidths.length; i++) { //draw line
				reconPayTable.drawLine(rowIndex, 1+i, .75f, Color.LIGHT_GRAY);
			}
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setFont(rowIndex, boldTextFont);			
			reconPayTable.setText(rowIndex, 1, "HCC");
			reconPayTable.setAlignment(rowIndex, 1, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 2, "Description");
			reconPayTable.setAlignment(rowIndex, 2, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 3, "Baseline");
			reconPayTable.setAlignment(rowIndex, 3, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 4, String.valueOf(year));
			reconPayTable.setColSpan(rowIndex, 4, 2);
			reconPayTable.setAlignment(rowIndex, 4, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 6, String.valueOf(year-1));
			reconPayTable.setColSpan(rowIndex, 6, 2);
			reconPayTable.setAlignment(rowIndex, 6, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 8, String.valueOf(year-2));
			reconPayTable.setColSpan(rowIndex, 8, 2);
			reconPayTable.setAlignment(rowIndex, 8, PdfTable.CENTER);
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.drawLine(rowIndex, 4, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 5, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 6, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 7, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 8, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 9, .75f, Color.LIGHT_GRAY);
			rowIndex = reconPayTable.addRow();		// New Row

			reconPayTable.setFont(rowIndex, boldTextFont);
			reconPayTable.setText(rowIndex, 4, "RAPS");
			reconPayTable.setAlignment(rowIndex, 4, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 5, "MOR");
			reconPayTable.setAlignment(rowIndex, 5, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 6, "RAPS");
			reconPayTable.setAlignment(rowIndex, 6, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 7, "MOR");
			reconPayTable.setAlignment(rowIndex, 7, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 8, "RAPS");
			reconPayTable.setAlignment(rowIndex, 8, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 9, "MOR");
			reconPayTable.setAlignment(rowIndex, 9, PdfTable.CENTER);	
			rowIndex = reconPayTable.addRow();		// New Row
			for (int i =0; i< reconPayTableWidths.length; i++) {
				reconPayTable.drawLine(rowIndex, 1+i, .75f, Color.LIGHT_GRAY);
			}
			
		}catch ( Exception ex){
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			logger.debug("GenerateRAExpertReport : printTableHeaderHccHist : " + ex);
//			logger.error("GenerateRAExpertReport : printTableHeaderHccHist : " + ex);
			throw ex;			
		}
		logger.info(LoggerConstants.methodEndLevel());
	}	

	private static void printTableBodyHccHist ( PdfTable reconPayTable, List items) throws Exception{			
		logger.info(LoggerConstants.methodStartLevel());
		try{
			int rowIndex;
			if (items==null || items.size() == 0) {
				rowIndex = reconPayTable.addRow();		// New Row
				reconPayTable.setText(rowIndex, 1, " No record Found");
				reconPayTable.setAlignment(rowIndex, 1, PdfTable.LEFT);
				logger.info(LoggerConstants.methodEndLevel());
				return;
			}
			Iterator it = items.iterator();
			while (it.hasNext()) {
				RAHccHistoryItem item = (RAHccHistoryItem) it.next();
				rowIndex = reconPayTable.addRow();		// New Row
				reconPayTable.setText(rowIndex, 1, String.valueOf(item.getHccCode()));
				reconPayTable.setAlignment(rowIndex, 1, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 2, String.valueOf(item.getDescription()));
				reconPayTable.setAlignment(rowIndex, 2, PdfTable.LEFT);
				reconPayTable.setText(rowIndex, 3, String.valueOf(item.getBaseLine()));
				reconPayTable.setAlignment(rowIndex, 3, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 4, String.valueOf(item.getCurrRaps()));
				reconPayTable.setAlignment(rowIndex, 4, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 5, String.valueOf(item.getCurrMOR()));
				reconPayTable.setAlignment(rowIndex, 5, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 6, String.valueOf(item.getCurMinOneRaps()));
				reconPayTable.setAlignment(rowIndex, 6, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 7, String.valueOf(item.getCurMinOneMOR()));
				reconPayTable.setAlignment(rowIndex, 7, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 8, String.valueOf(item.getCurMinTwoRaps()));
				reconPayTable.setAlignment(rowIndex, 8, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 9, String.valueOf(item.getCurMinTwoMOR()));
				reconPayTable.setAlignment(rowIndex, 9, PdfTable.CENTER);				
			}
			rowIndex = reconPayTable.addRow();		// New Row
			for (int i =0; i< 9; i++) 
				reconPayTable.drawLine(rowIndex, 1+i, .75f, Color.LIGHT_GRAY);
			
		}catch ( Exception ex){
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			logger.debug("GenerateRAExpertReport : printTableBodyHccHist : " + ex);
//			logger.error("GenerateRAExpertReport : printTableBodyHccHist : " + ex);
			throw ex;			
		}		
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	private static void printTableHeaderHccProj ( PdfTable reconPayTable, float[] reconPayTableWidths, int year) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		String boldTextFont = PdfFontUtil.defineFont("BOLD_TEXT_FONT", PdfFontUtil.COURIER, 9, PdfFontUtil.BOLD_FONT);
		
		try{		
			int rowIndex = reconPayTable.addRow();		// New Row
			for (int i =0; i< reconPayTableWidths.length; i++) { //draw line
				reconPayTable.drawLine(rowIndex, 1+i, .75f, Color.LIGHT_GRAY);
			}
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setFont(rowIndex, boldTextFont);
			reconPayTable.setText(rowIndex, 1, "HCC");
			reconPayTable.setAlignment(rowIndex, 1, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 2, "Description");
			reconPayTable.setAlignment(rowIndex, 2, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 3, "Baseline");
			reconPayTable.setAlignment(rowIndex, 3, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 4, String.valueOf(year));
			reconPayTable.setColSpan(rowIndex, 4, 2);
			reconPayTable.setAlignment(rowIndex, 4, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 6, String.valueOf(year-1));
			reconPayTable.setColSpan(rowIndex, 6, 2);
			reconPayTable.setAlignment(rowIndex, 6, PdfTable.CENTER);
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.drawLine(rowIndex, 4, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 5, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 6, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 7, .75f, Color.LIGHT_GRAY);
			rowIndex = reconPayTable.addRow();		// New Row

			reconPayTable.setFont(rowIndex, boldTextFont);
			reconPayTable.setText(rowIndex, 4, "RAPSLAG");
			reconPayTable.setAlignment(rowIndex, 4, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 5, "RAPS");
			reconPayTable.setAlignment(rowIndex, 5, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 6, "RAPS");
			reconPayTable.setAlignment(rowIndex, 6, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 7, "MOR");
			reconPayTable.setAlignment(rowIndex, 7, PdfTable.CENTER);	
			rowIndex = reconPayTable.addRow();		// New Row
			for (int i =0; i< reconPayTableWidths.length; i++) {
				reconPayTable.drawLine(rowIndex, 1+i, .75f, Color.LIGHT_GRAY);
			}
			
		}catch ( Exception ex){
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			logger.debug("GenerateRAExpertReport : printTableHeaderHccProj : " + ex);
//			logger.error("GenerateRAExpertReport : printTableHeaderHccProj : " + ex);
			throw ex;			
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	private static void printTableBodyHccProj ( PdfTable reconPayTable, List items) throws Exception{			
		logger.info(LoggerConstants.methodStartLevel());
		try{
			int rowIndex;
			if (items==null || items.size() == 0) {
				rowIndex = reconPayTable.addRow();		// New Row
				reconPayTable.setText(rowIndex, 1, "No Data Found");
				reconPayTable.setColSpan(rowIndex, 1, 7);
				reconPayTable.setAlignment(rowIndex, 1, PdfTable.CENTER);
				logger.info(LoggerConstants.methodEndLevel());
				return;
			}
			Iterator it = items.iterator();
			while (it.hasNext()) {
				RAHccProjectionItem item = (RAHccProjectionItem) it.next();
				rowIndex = reconPayTable.addRow();		// New Row
				reconPayTable.setText(rowIndex, 1, String.valueOf(item.getHccCode()));
				reconPayTable.setAlignment(rowIndex, 1, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 2, String.valueOf(item.getDescription()));
				reconPayTable.setAlignment(rowIndex, 2, PdfTable.LEFT);
				reconPayTable.setText(rowIndex, 3, String.valueOf(item.getBaseLine()));
				reconPayTable.setAlignment(rowIndex, 3, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 4, String.valueOf(item.getRapsLag()));
				reconPayTable.setAlignment(rowIndex, 4, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 5, String.valueOf(item.getProjRaps()));
				reconPayTable.setAlignment(rowIndex, 5, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 6, String.valueOf(item.getCurrRaps()));
				reconPayTable.setAlignment(rowIndex, 6, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 7, String.valueOf(item.getCurrMOR()));
				reconPayTable.setAlignment(rowIndex, 7, PdfTable.CENTER);
			}
			rowIndex = reconPayTable.addRow();		// New Row
			for (int i =0; i< 7; i++) 
				reconPayTable.drawLine(rowIndex, 1+i, .75f, Color.LIGHT_GRAY);
			
		}catch ( Exception ex){
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
//			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("GenerateRAExpertReport : printTableBodyHccProj : " + ex);
			throw ex;			
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	private static void printTableHeaderFinAudit( PdfTable reconPayTable, float[] reconPayTableWidths, boolean firstPage) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		String boldTextFont = PdfFontUtil.defineFont("BOLD_TEXT_FONT", PdfFontUtil.COURIER, 9, PdfFontUtil.BOLD_FONT);
		
		try{		
			int rowIndex;
			if (firstPage) {
				rowIndex = reconPayTable.addRow();		// New Row
				for (int i = 0; i < reconPayTableWidths.length; i++) { //draw line
					reconPayTable.drawLine(rowIndex, 1+i, .75f, Color.LIGHT_GRAY);
				}
			}
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setFont(rowIndex, boldTextFont);
			reconPayTable.setText(rowIndex, 9, "HCCs");
			reconPayTable.setColSpan(rowIndex, 9, 4);
			
			rowIndex = reconPayTable.addRow();		// New Row
			for (int i = 8; i < 12; i++) {
				reconPayTable.drawLine(rowIndex, 1+i, .75f, Color.LIGHT_GRAY);
			}
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setFont(rowIndex, boldTextFont);
			reconPayTable.setText(rowIndex, 6, "Service Date");
			reconPayTable.setColSpan(rowIndex, 6, 2);
			reconPayTable.setAlignment(rowIndex, 6, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 9, "Part C");
			reconPayTable.setColSpan(rowIndex, 9, 2);
			reconPayTable.setAlignment(rowIndex, 9, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 11, "Part D");
			reconPayTable.setColSpan(rowIndex, 11, 2);
			reconPayTable.setAlignment(rowIndex, 11, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 13, "File Sequence Numbers");
			reconPayTable.setColSpan(rowIndex, 13, 3);
			reconPayTable.setAlignment(rowIndex, 13, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 16, "Errors");
			reconPayTable.setColSpan(rowIndex, 16, 3);
			reconPayTable.setAlignment(rowIndex, 16, PdfTable.CENTER);
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.drawLine(rowIndex, 6, .75f, Color.LIGHT_GRAY);
			reconPayTable.drawLine(rowIndex, 7, .75f, Color.LIGHT_GRAY);
			for (int i = 8; i < 18; i++) {
				reconPayTable.drawLine(rowIndex, 1+i, .75f, Color.LIGHT_GRAY);
			}		
			
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setFont(rowIndex, boldTextFont);
			reconPayTable.setText(rowIndex, 1, "File Date");
			reconPayTable.setAlignment(rowIndex, 1, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 2, "File Id");
			reconPayTable.setAlignment(rowIndex, 2, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 3, "Prov Type");
			reconPayTable.setAlignment(rowIndex, 3, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 4, "ICD Type");
			reconPayTable.setAlignment(rowIndex, 4, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 5, "Diag Code");
			reconPayTable.setAlignment(rowIndex, 5, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 6, "From");
			reconPayTable.setAlignment(rowIndex, 6, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 7, "Thru");
			reconPayTable.setAlignment(rowIndex, 7, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 8, "Delete Ind");
			reconPayTable.setAlignment(rowIndex, 8, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 9, "Cat1");
			reconPayTable.setAlignment(rowIndex, 9, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 10, "Cat2");
			reconPayTable.setAlignment(rowIndex, 10, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 11, "Cat1");
			reconPayTable.setAlignment(rowIndex, 11, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 12, "Cat2");
			reconPayTable.setAlignment(rowIndex, 12, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 13, "BBB");
			reconPayTable.setAlignment(rowIndex, 13, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 14, "CCC");
			reconPayTable.setAlignment(rowIndex, 14, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 15, "Cluster");
			reconPayTable.setAlignment(rowIndex, 15, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 16, "Diag1");
			reconPayTable.setAlignment(rowIndex, 16, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 17, "Diag2");
			reconPayTable.setAlignment(rowIndex, 17, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 18, "HIC");
			reconPayTable.setAlignment(rowIndex, 18, PdfTable.CENTER);
			reconPayTable.setText(rowIndex, 19, "Corrected HIC");
			reconPayTable.setAlignment(rowIndex, 19, PdfTable.CENTER);
				
			rowIndex = reconPayTable.addRow();		// New Row
			for (int i =0; i< reconPayTableWidths.length; i++) {
				reconPayTable.drawLine(rowIndex, 1+i, .75f, Color.LIGHT_GRAY);
			}
			
		}catch ( Exception ex){
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			logger.debug("GenerateRAExpertReport : printTableHeaderHccHist : " + ex);
//			logger.error("GenerateRAExpertReport : printTableHeaderHccHist : " + ex);
			throw ex;			
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	private static void printTableFinAudit( PdfTable pdfTable, List items) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		try {
			boolean firstPage = true;
			float[] tableWidths = {7f,9f,4f,4f,5f,7f,7f,6f,4f,4f,4f,4f,6f,6f,6f,5f,5f,5f,9f};
			
			PdfTable finAuditTable = getNewFinAuditTable(tableWidths);
			printTableHeaderFinAudit(finAuditTable,tableWidths,firstPage);
			
			int rowIndex;
			if (items==null || items.size() == 0) {
				rowIndex = finAuditTable.addRow();		// New Row
				finAuditTable.setText(rowIndex, 1, "No Data Found");
				finAuditTable.setColSpan(rowIndex, 1, 19);
				finAuditTable.setAlignment(rowIndex, 1, PdfTable.CENTER);
	
				rowIndex = pdfTable.addRow();
				pdfTable.setTable(rowIndex, 1, finAuditTable);
				logger.info(LoggerConstants.methodEndLevel());
				return;
			}
	

			int cnt = 0;
			Iterator it = items.iterator();
			while (it.hasNext()) {
				RAPSFinancialAudit item = (RAPSFinancialAudit) it.next();
				rowIndex = finAuditTable.addRow();		// New Row
				finAuditTable.setText(rowIndex, 1, String.valueOf(item.getFileDate()));
				finAuditTable.setAlignment(rowIndex, 1, PdfTable.CENTER);
				finAuditTable.setText(rowIndex, 2, String.valueOf(item.getFileId()));
				finAuditTable.setAlignment(rowIndex, 2, PdfTable.CENTER);
				finAuditTable.setText(rowIndex, 3, String.valueOf(item.getProvType()));
				finAuditTable.setAlignment(rowIndex, 3, PdfTable.CENTER);
				finAuditTable.setText(rowIndex, 4, String.valueOf(item.getIcdType()));
				finAuditTable.setAlignment(rowIndex, 4, PdfTable.CENTER);
				finAuditTable.setText(rowIndex, 5, String.valueOf(item.getDiagCd()));
				finAuditTable.setAlignment(rowIndex, 5, PdfTable.CENTER);
				finAuditTable.setText(rowIndex, 6, String.valueOf(item.getServiceDateFrom()));
				finAuditTable.setAlignment(rowIndex, 6, PdfTable.CENTER);
				finAuditTable.setText(rowIndex, 7, String.valueOf(item.getServiceDateThru()));
				finAuditTable.setAlignment(rowIndex, 7, PdfTable.CENTER);
				finAuditTable.setText(rowIndex, 8, String.valueOf(item.getDeleteInd()));
				finAuditTable.setAlignment(rowIndex, 8, PdfTable.CENTER);
				finAuditTable.setText(rowIndex, 9, String.valueOf(item.getPartCACat1()));
				finAuditTable.setAlignment(rowIndex, 9, PdfTable.CENTER);
				finAuditTable.setText(rowIndex, 10, String.valueOf(item.getPartCACat2()));
				finAuditTable.setAlignment(rowIndex, 10, PdfTable.CENTER);
				finAuditTable.setText(rowIndex, 11, String.valueOf(item.getPartDCat1()));
				finAuditTable.setAlignment(rowIndex, 11, PdfTable.CENTER);
				finAuditTable.setText(rowIndex, 12, String.valueOf(item.getPartDCat2()));
				finAuditTable.setAlignment(rowIndex, 12, PdfTable.CENTER);
				finAuditTable.setText(rowIndex, 13, String.valueOf(item.getBbbSeq()));
				finAuditTable.setAlignment(rowIndex, 13, PdfTable.CENTER);
				finAuditTable.setText(rowIndex, 14, String.valueOf(item.getCccSeq()));
				finAuditTable.setAlignment(rowIndex, 14, PdfTable.CENTER);
				finAuditTable.setText(rowIndex, 15, String.valueOf(item.getClusterSeq()));
				finAuditTable.setAlignment(rowIndex, 15, PdfTable.CENTER);
				finAuditTable.setText(rowIndex, 16, String.valueOf(item.getDiagClusterErr1()));
				finAuditTable.setAlignment(rowIndex, 16, PdfTable.CENTER);
				finAuditTable.setText(rowIndex, 17, String.valueOf(item.getDiagClusterErr2()));
				finAuditTable.setAlignment(rowIndex, 17, PdfTable.CENTER);
				finAuditTable.setText(rowIndex, 18, String.valueOf(item.getHicErrCd()));
				finAuditTable.setAlignment(rowIndex, 18, PdfTable.CENTER);
				finAuditTable.setText(rowIndex, 19, String.valueOf(item.getCorrectedHic()));
				finAuditTable.setAlignment(rowIndex, 19, PdfTable.CENTER);
	
				cnt += 1;
				
				if ((firstPage && (cnt >= 30)) || (cnt >= 36)) {
					rowIndex = pdfTable.addRow();
					pdfTable.setTable(rowIndex, 1, finAuditTable);
					cnt = 0;
					firstPage = false;
					finAuditTable = getNewFinAuditTable(tableWidths);
					printTableHeaderFinAudit(finAuditTable,tableWidths,firstPage);				
				}
			}
	
			rowIndex = finAuditTable.addRow();		// New Row
			for (int i =0; i< 19; i++) 
				finAuditTable.drawLine(rowIndex, 1+i, .75f, Color.LIGHT_GRAY);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, finAuditTable);
			
		}catch ( Exception ex){
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			logger.debug("GenerateRAExpertReport : printTableBodyHccHist : " + ex);
//			logger.error("GenerateRAExpertReport : printTableBodyHccHist : " + ex);
			throw ex;			
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	private static PdfTable getNewFinAuditTable(float[] reconPayTableWidths) {
		logger.info(LoggerConstants.methodStartLevel());
		PdfTable tbl = new PdfTable(19);
		tbl.setWidthPercentage(100);
		tbl.setBorder(0);
		tbl.setFont(RAExpertReportPDFUtil.normalTextFont);
		tbl.setAlignment(PdfTable.CENTER);
		tbl.setColumnWidths(reconPayTableWidths);
		logger.info(LoggerConstants.methodEndLevel());
		return tbl;
	}
	
	private static void printTableBodyFinAudit ( PdfTable pdfTable, float[] reconPayTableWidths, List items) throws Exception{			
		logger.info(LoggerConstants.methodStartLevel());
		try{
			
			PdfTable reconPayTable = new PdfTable(19);
			reconPayTable.setWidthPercentage(100);
			reconPayTable.setBorder(0);
			reconPayTable.setFont(RAExpertReportPDFUtil.normalTextFont);
			reconPayTable.setAlignment(PdfTable.CENTER);
			reconPayTable.setColumnWidths(reconPayTableWidths);
			
			int rowIndex;
			if (items==null || items.size() == 0) {
				rowIndex = reconPayTable.addRow();		// New Row
				reconPayTable.setText(rowIndex, 1, "No Data Found");
				reconPayTable.setColSpan(rowIndex, 1, 19);
				reconPayTable.setAlignment(rowIndex, 1, PdfTable.CENTER);

				rowIndex = pdfTable.addRow();
				pdfTable.setTable(rowIndex, 1, reconPayTable);
				logger.info(LoggerConstants.methodEndLevel());
				return;
			}

			boolean firstPage = true;
			int cnt = 0;
			Iterator it = items.iterator();
			while (it.hasNext()) {
				RAPSFinancialAudit item = (RAPSFinancialAudit) it.next();
				rowIndex = reconPayTable.addRow();		// New Row
				reconPayTable.setText(rowIndex, 1, String.valueOf(item.getFileDate()));
				reconPayTable.setAlignment(rowIndex, 1, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 2, String.valueOf(item.getFileId()));
				reconPayTable.setAlignment(rowIndex, 2, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 3, String.valueOf(item.getProvType()));
				reconPayTable.setAlignment(rowIndex, 3, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 4, String.valueOf(item.getIcdType()));
				reconPayTable.setAlignment(rowIndex, 4, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 5, String.valueOf(item.getDiagCd()));
				reconPayTable.setAlignment(rowIndex, 5, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 6, String.valueOf(item.getServiceDateFrom()));
				reconPayTable.setAlignment(rowIndex, 6, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 7, String.valueOf(item.getServiceDateThru()));
				reconPayTable.setAlignment(rowIndex, 7, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 8, String.valueOf(item.getDeleteInd()));
				reconPayTable.setAlignment(rowIndex, 8, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 9, String.valueOf(item.getPartCACat1()));
				reconPayTable.setAlignment(rowIndex, 9, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 10, String.valueOf(item.getPartCACat2()));
				reconPayTable.setAlignment(rowIndex, 10, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 11, String.valueOf(item.getPartDCat1()));
				reconPayTable.setAlignment(rowIndex, 11, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 12, String.valueOf(item.getPartDCat2()));
				reconPayTable.setAlignment(rowIndex, 12, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 13, String.valueOf(item.getBbbSeq()));
				reconPayTable.setAlignment(rowIndex, 13, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 14, String.valueOf(item.getCccSeq()));
				reconPayTable.setAlignment(rowIndex, 14, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 15, String.valueOf(item.getClusterSeq()));
				reconPayTable.setAlignment(rowIndex, 15, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 16, String.valueOf(item.getDiagClusterErr1()));
				reconPayTable.setAlignment(rowIndex, 16, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 17, String.valueOf(item.getDiagClusterErr2()));
				reconPayTable.setAlignment(rowIndex, 17, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 18, String.valueOf(item.getHicErrCd()));
				reconPayTable.setAlignment(rowIndex, 18, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 19, String.valueOf(item.getCorrectedHic()));
				reconPayTable.setAlignment(rowIndex, 19, PdfTable.CENTER);

				cnt += 1;
				
				if ((firstPage && (cnt >= 30)) || (cnt >= 43)) {
					rowIndex = pdfTable.addRow();
					pdfTable.setTable(rowIndex, 1, reconPayTable);
					cnt = 0;
					firstPage = false;
					reconPayTable = new PdfTable(19);
					reconPayTable.setWidthPercentage(100);
					reconPayTable.setBorder(0);
					reconPayTable.setFont(RAExpertReportPDFUtil.normalTextFont);
					reconPayTable.setAlignment(PdfTable.CENTER);
					reconPayTable.setColumnWidths(reconPayTableWidths);
				}
			}
			rowIndex = reconPayTable.addRow();		// New Row
			for (int i =0; i< 19; i++) 
				reconPayTable.drawLine(rowIndex, 1+i, .75f, Color.LIGHT_GRAY);

			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, reconPayTable);
			
		}catch ( Exception ex){
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			logger.debug("GenerateRAExpertReport : printTableBodyHccHist : " + ex);
//			logger.error("GenerateRAExpertReport : printTableBodyHccHist : " + ex);
			throw ex;			
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	/*
	private static void printTableBodyFinAudit ( PdfTable reconPayTable, List items) throws Exception{			
		try{
			int rowIndex;
			if (items==null || items.size() == 0) {
				rowIndex = reconPayTable.addRow();		// New Row
				reconPayTable.setText(rowIndex, 1, "No Data Found");
				reconPayTable.setColSpan(rowIndex, 1, 19);
				reconPayTable.setAlignment(rowIndex, 1, PdfTable.CENTER);
				return;
			}
			Iterator it = items.iterator();
			while (it.hasNext()) {
				RAPSFinancialAudit item = (RAPSFinancialAudit) it.next();
				rowIndex = reconPayTable.addRow();		// New Row
				reconPayTable.setText(rowIndex, 1, String.valueOf(item.getFileDate()));
				reconPayTable.setAlignment(rowIndex, 1, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 2, String.valueOf(item.getFileId()));
				reconPayTable.setAlignment(rowIndex, 2, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 3, String.valueOf(item.getProvType()));
				reconPayTable.setAlignment(rowIndex, 3, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 4, String.valueOf(item.getIcdType()));
				reconPayTable.setAlignment(rowIndex, 4, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 5, String.valueOf(item.getDiagCd()));
				reconPayTable.setAlignment(rowIndex, 5, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 6, String.valueOf(item.getServiceDateFrom()));
				reconPayTable.setAlignment(rowIndex, 6, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 7, String.valueOf(item.getServiceDateThru()));
				reconPayTable.setAlignment(rowIndex, 7, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 8, String.valueOf(item.getDeleteInd()));
				reconPayTable.setAlignment(rowIndex, 8, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 9, String.valueOf(item.getPartCCat1()));
				reconPayTable.setAlignment(rowIndex, 9, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 10, String.valueOf(item.getPartCCat2()));
				reconPayTable.setAlignment(rowIndex, 10, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 11, String.valueOf(item.getPartDCat1()));
				reconPayTable.setAlignment(rowIndex, 11, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 12, String.valueOf(item.getPartDCat2()));
				reconPayTable.setAlignment(rowIndex, 12, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 13, String.valueOf(item.getBbbSeq()));
				reconPayTable.setAlignment(rowIndex, 13, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 14, String.valueOf(item.getCccSeq()));
				reconPayTable.setAlignment(rowIndex, 14, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 15, String.valueOf(item.getClusterSeq()));
				reconPayTable.setAlignment(rowIndex, 15, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 16, String.valueOf(item.getDiagClusterErr1()));
				reconPayTable.setAlignment(rowIndex, 16, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 17, String.valueOf(item.getDiagClusterErr2()));
				reconPayTable.setAlignment(rowIndex, 17, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 18, String.valueOf(item.getHicErrCd()));
				reconPayTable.setAlignment(rowIndex, 18, PdfTable.CENTER);
				reconPayTable.setText(rowIndex, 19, String.valueOf(item.getCorrectedHic()));
				reconPayTable.setAlignment(rowIndex, 19, PdfTable.CENTER);
			}
			rowIndex = reconPayTable.addRow();		// New Row
			for (int i =0; i< 19; i++) 
				reconPayTable.drawLine(rowIndex, 1+i, .75f, Color.LIGHT_GRAY);
			
		}catch ( Exception ex){
			logger.error("GenerateRAExpertReport : printTableBodyHccHist : " + ex);
			throw ex;			
		}
	}
	*/
}
