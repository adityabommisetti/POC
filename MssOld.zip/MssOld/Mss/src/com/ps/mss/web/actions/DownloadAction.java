/*
 * $Id: DownloadAction.java,v 1.1 2014/06/26 07:56:51 praveen Exp $
 * Created on Feb 26, 2008
 *
 */
package com.ps.mss.web.actions;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ps.io.FileNameUtil;
import com.ps.logger.LoggerConstants;
import com.ps.mss.util.MssProperties;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.util.StringUtil;
import com.ps.mss.framework.Constants;

/**
 * @author rakesh
 *
 */
public class DownloadAction extends Action {
	private static Logger logger=LoggerFactory.getLogger(DownloadAction.class);

	/* (non-Javadoc)
	 * @see org.apache.struts.action.Action#execute(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = new SessionHelper(request);
		String errorMsg = sessionHelper.validateUser();
		if (errorMsg != null) {
			request.setAttribute("Msg", "Login Has Timed Out");
			throw new Exception(errorMsg);
		}

		String fileName = request.getParameter("exportFileName");
		String tableName = request.getParameter("tableName");
		String exportType = request.getParameter("exportType");
		String parmFileName = request.getParameter("fileName");
		String csvFileName = (String)request.getAttribute("fileName");
		String csvFileFormat = (String)request.getAttribute("fileTrackingExportType");
		
		if(parmFileName == null)
			parmFileName = tableName;
		if(parmFileName == null){
			parmFileName = csvFileName;
		}
		if(fileName == null){
			fileName = parmFileName;
		}
		if(exportType == null || StringUtil.isNullOrEmpty(exportType)){
			exportType = csvFileFormat;
		}
		
		String mimeType = null;
		
		File file = new File(parmFileName);
		String checkedFileName = FileNameUtil.stripExt(MssProperties.getExportLocation() + File.separator + file.getName());
		logger.debug("checkedFileName is from :"+ checkedFileName);
		
		if (Constants.FILE_TYPE_PDF.equals(exportType)) {
			fileName +=  Constants.PDF_FILE_EXTENSION;
			checkedFileName += Constants.PDF_FILE_EXTENSION;
			mimeType = Constants.MIME_TYPE_PDF;
		} else if(Constants.FILE_TYPE_CSV.equals(exportType)){
			fileName += Constants.CSV_FILE_EXTENSION;
			checkedFileName += Constants.CSV_FILE_EXTENSION;
			mimeType = Constants.MIME_TYPE_CSV;
		} else if(Constants.FILE_TYPE_TXT.equals(exportType)) {
			fileName += Constants.TXT_FILE_EXTENSION;
			checkedFileName += Constants.TXT_FILE_EXTENSION;
			mimeType = Constants.MIME_TYPE_TXT;
		} else {
			fileName += Constants.XLS_FILE_EXTENSION;
			checkedFileName += Constants.XLS_FILE_EXTENSION;
			mimeType = Constants.MIME_TYPE_XLS;
		}
			
		if (!checkedFileName.equalsIgnoreCase(parmFileName)) {
			logger.debug("Warning DownloadAction Malformed Fille Request [" + parmFileName + "]");
			logger.info(LoggerConstants.methodEndLevel());
			return null;
		}
		
		logger.debug("Request [" + checkedFileName + "]");
		File checkedFile = new File(checkedFileName);
		
		response.setContentType(mimeType);
		response.setContentLength(new Long(checkedFile.length()).intValue());
		response.setHeader("Content-disposition", "attachment;filename=" + fileName);
		
		//DataInputStream in = null;
		BufferedInputStream bis = null;
		
		OutputStream out = null;
		try {
			//byte[] bbuf = new byte[4*1024];
			byte[] bbuf = new byte[1024];
			//in = new DataInputStream(new FileInputStream(checkedFile));
			bis = new BufferedInputStream(new FileInputStream(checkedFile));
			int length = 0;

			out = response.getOutputStream();
			//while ( (length = in.read(bbuf)) != -1)
			while ( (length = bis.read(bbuf)) != -1)
			{
				out.write(bbuf,0,length);
			}
			logger.debug("Writing to file is done ");
			out.flush();
			
			
		} finally {
			try {
				if (out != null)
					out.close();
			} catch(Exception e) {
			}
			try {
				//if (in != null)
					//in.close();
				if (bis != null)
					bis.close();
			} catch(Exception e) {
			}
		}

		checkedFile.delete();
		logger.info(LoggerConstants.methodEndLevel());
		return null;
	}
}
