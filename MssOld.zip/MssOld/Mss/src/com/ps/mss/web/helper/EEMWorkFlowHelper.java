package com.ps.mss.web.helper;
//import java.util.Properties;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.db.EEMWFCodeCache;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.EEMWorkFLowVO;
import com.ps.mss.web.forms.EEMWorkFlowForm;
import com.ps.util.ListBoxItem;
import com.ps.util.StringUtil;
/**
 * 
 * @author Praveen Are , new helper class for WorkFlow
 *
 */
public class EEMWorkFlowHelper{
	private static Logger logger = LoggerFactory.getLogger(EEMWorkFlowHelper.class);
//	private static Properties prop;
  /**
   * This method is used to clear all the list set in the EEMWorkFLowVO
   * @param enrollVO holds EEMWorkFLowVO object
   */
	public static void clearContextDisplay(EEMWorkFLowVO enrollVO) {
		/*enrollVO.setSearchResults(null);
		enrollVO.setDemographics(null);
		enrollVO.setEnrollments(null);
		enrollVO.setDsInfos(null);
		enrollVO.setLisInfos(null);
		enrollVO.setLepInfos(null);
		enrollVO.setAddresses(null);
		enrollVO.setLetters(null);
		enrollVO.setLetterData(null);
		enrollVO.setPcpInfos(null);
		enrollVO.setComments(null);
		enrollVO.setErrors(null);
		enrollVO.setTrrLogs(null);
		enrollVO.setListAgents(null);
		enrollVO.setListCobs(null);*/
		
	}//clearContextDisplay()
/**
 * This method is used to clear all the list set in EEMWorkFlowForm
 * @param form holds EEMWorkFlowForm value
 */
	public static void clearFormDisplay(EEMWorkFlowForm form) {
		/*form.setListSearchResults(null);
		form.setSelectedSearchRow(0);
		form.setListDemographicsWithDisplay(null);

		form.setListEnrollmentsWithDisplay(null);
		form.setSelectedEnrollmentRow(0);
		form.setTopDisplayEnrollmentRow(0);

		form.setListDsInfosWithDisplay(null);
		form.setSelectedDsInfoRow(0);
		form.setTopDisplayDsInfoRow(0);

		form.setListLisInfosWithDisplay(null);
		form.setSelectedLisInfoRow(0);
		form.setTopDisplayLisInfoRow(0);

		form.setListLepInfosWithDisplay(null);
		form.setSelectedLepInfoRow(0);
		form.setTopDisplayLepInfoRow(0);

		form.setListAddressesWithDisplay(null);
		form.setSelectedAddressRow(0);
		form.setTopDisplayAddressRow(0);*/		
		
	}//clearFormDisplay()
/**
 * This method is used to set the list values into EEMWorkFlowForm
 * @param eemWFForm holds EEMWorkFlowForm object
 * @param sessionHelper holds SessionHelper object
 * @throws ApplicationException when application failed to execute
 */
	public static void setEEMWorkFlowFormList(EEMWorkFlowForm eemWFForm, SessionHelper sessionHelper) 
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());

		EEMWFCodeCache objCache = EEMWFCodeCache.getInstance(sessionHelper.getMfId());
		String customerID = StringUtil.nonNullTrim(sessionHelper.getMfId());
		String loginUserId = StringUtil.nonNullTrim(sessionHelper.getUserId());
		String userLevel = null;
		eemWFForm.setWfStatus(objCache.getLstWFStatus());
		eemWFForm.setWfQPriority(objCache.getLstWFQPriority());

		eemWFForm.setAdminHistMonths(objCache.getLstAdminHistMonths());
		eemWFForm.setAdminHistWeeks(objCache.getLstAdminHistWeeks());
		eemWFForm.setAdminHistLvls(objCache.getLstAdminHistLvls());
		eemWFForm.setAdminHistQNames(objCache.getLstAdminHistQNames());
		eemWFForm.setAdminHistAdmins(objCache.getLstAdminHistAdmins());
		eemWFForm.setAdminHistRiskInds(objCache.getLstAdminHistRiskInds());
		eemWFForm.setAdminHIstRiskRngs(objCache.getLstAdminHistRiskRngs());
		eemWFForm.setAdminHistRiskCompls(objCache.getLstAdminHistRiskCompls());
		eemWFForm.setAdminHistSrchTypes(objCache.getLstAdminHistSrchTypes());
		/**
		 * 045_HighMark_Queue Characteristics Start
		 */
		eemWFForm.setArrYesNo(objCache.getArrYesNo());
		eemWFForm.setArrQuePriority(objCache.getArrQuePriority());
		eemWFForm.setArrCreationFreq(objCache.getArrCreationFreq());
		/**
		 * 045_HighMark_Queue Characteristics End
		 */
		//045_UserList start
		//DropDown Changes Starts
		userLevel = StringUtil.nonNullTrim(eemWFForm.getUserLevel());		
		//DropDown Changes ends
		eemWFForm.setListSupervisor(objCache.getLstSupervisor(customerID,loginUserId,userLevel));
		eemWFForm.setListUserLevel(objCache.getArrUserLevel());
		//045_UserList end
		eemWFForm.setWfSource(objCache.getLstWFSource());
		//045_AssignActivity start		
		String supervisorId = StringUtil.nonNullTrim(eemWFForm.getSupervisorId());	
		if(!supervisorId.equals("")){	
//				 eemWFForm.setListActivityUser(objCache.getLstUsersForSupervisor(eemWFForm.getSupervisorId(),customerID));
			 eemWFForm.setListActivityUser(objCache.getLstActivityUser(customerID,loginUserId,userLevel));
		}else{		
		 eemWFForm.setListActivityUser(objCache.getLstActivityUser(customerID,loginUserId,userLevel));
		}
		//045_AssignActivity end		
		
		logger.info(LoggerConstants.methodEndLevel());
	}//setEnrollFormList()	
  /**
   * This method used to copy EEMWorkFLowVO results to EEMWorkFlowForm
   * @param enrollVO holds  EEMWorkFLowVO object
   * @param form holds  EEMWorkFlowForm object
   */
	public static void copyVOToForm(EEMWorkFLowVO enrollVO, EEMWorkFlowForm form) {

		/*if (!StringUtil.nonNullTrim(enrollVO.getMessage()).equals(""))
			form.setMessage(enrollVO.getMessage());

		form.setListSearchResults(enrollVO.getSearchResults());
		form.setListDemographics(enrollVO.getDemographics());
		form.setListEnrollments(enrollVO.getEnrollments());
		form.setListDsInfos(enrollVO.getDsInfos());
		form.setListLisInfos(enrollVO.getLisInfos());
		form.setListLepInfos(enrollVO.getLepInfos());
		*/
		
	}
	/**
	 *  This method is used to copy results from form to VO
	 * @param eemWFForm holds EEMWorkFlowForm object
	 * @param wfFilterVO  holds EEMWorkFLowVO object
	 * @param sessionHelper holds SessionHelper object
	 * @throws ApplicationException when application failed to execute
	 */
	public static void setFormToVO(EEMWorkFlowForm eemWFForm,
			EEMWorkFLowVO wfFilterVO, SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try{	
			BeanUtils.copyProperties(wfFilterVO, eemWFForm);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	/**
	 * This method is used to copy results from VO to Form
	 * @param wfFilterVO  holds EEMWorkFLowVO object
	 * @param eemWFForm  holds EEMWorkFlowForm object
	 * @param sessionHelper  holds SessionHelper object
	 * @throws ApplicationException when application failed to execute
	 */
	public static void setVOToForm(EEMWorkFLowVO wfFilterVO,
			EEMWorkFlowForm eemWFForm, SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try{	
			BeanUtils.copyProperties(eemWFForm, wfFilterVO);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	
   /**
    * This method is used to set the form in session
    * @param sessionHelper holds SessionHelper object
    * @param form holds EEMWorkFlowForm object
    */
	public static void saveEEMWorkFlowForm(SessionHelper sessionHelper,
			EEMWorkFlowForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		sessionHelper.setAttribute("SaveEEMWorkFlowForm", form);
		logger.info(LoggerConstants.methodEndLevel());
	}
    /**
     * This method is used to get the the session form 
     * @param sessionHelper holds SessionHelper object
     * @return
     */
	public static EEMWorkFlowForm getEEMWorkFlowForm(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (EEMWorkFlowForm) sessionHelper.getAttribute("SaveEEMWorkFlowForm");
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void setAdminHistSrchYear(EEMWorkFlowForm eemWFForm)throws ApplicationException {		
		logger.info(LoggerConstants.methodStartLevel());
		List alYears = new ArrayList();
		ListBoxItem lbi = null;		
		Calendar cal = Calendar.getInstance();
		int year = cal.get(Calendar.YEAR);		  
		
		for(int i=0; i<5; i++){
			lbi = new ListBoxItem(new Integer(year-i).toString(), new Integer(year-i).toString());
			alYears.add(lbi);
			if((year-i) <= 2014){
				break;
			} 
		}
		eemWFForm.setAdminHistYears(alYears);	
		logger.info(LoggerConstants.methodEndLevel());
	}//setAdminHistSrchYear
	

	/*public static String getProperty(String sKey) throws ApplicationException {
		String sValue = null;
		try {
			if (prop == null) {
				prop = new Properties();
				prop.load(new FileInputStream("EEMProperties.properties"));
			}
			sValue = prop.getProperty(sKey);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}

		return sValue;
	}*/

}
