/*
 * Created on May 16, 2008
 *
 */
package com.ps.mss.web.taglib;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;

/**
 * @author deepak
 * This class is generate formatted out put for troopDeail.jsp
 */
public class DetailListAmtFormatorTag extends BodyTagSupport {
	private String width;
	private String align;
	private String valign;
	private String zero;
	private String id;
	private String appliedClass;
	private Integer index;
	private String nowrap;
	
	/* (non-Javadoc)
	 * @see javax.servlet.jsp.tagext.Tag#doStartTag()
	 */
	public int doEndTag() throws JspException {
		try {
			BodyContent body = getBodyContent();
			if(body != null) {
				String value = body.getString();
				String css = createCss();
				JspWriter out = pageContext.getOut();
				boolean styleAdded = false;
				if(value != null) {
					if("$0.00".equals(value) && zero == null)
						out.print("<td "+ css +" >&nbsp;</td>");
					else {
						String temp ="<td "+ css  ;
						if( value.startsWith("(") && appliedClass != null && !"".equals(appliedClass) && !"class=\"selectedRow\"".equals(appliedClass)) {
								temp += "class='red' ";
								styleAdded = true;
						} else if(! value.startsWith("(")) {
							value += "&nbsp;"; // adding white space with value +ive values
						}
						if(!styleAdded &&appliedClass != null && !"".equals(appliedClass)) {
							temp += appliedClass;
						}
							temp += ">" + value + "&nbsp;</td> ";
						out.print(temp);
					}
				} else if("true".equals(zero)){
					out.print("<td "+ css +" >$0.00;</td>");
				}
					
			}
		} catch (IOException e) {
				System.out.print("Error in CurrencyFromator Tag Hendler" + e);
		}
		return (EVAL_PAGE);
	}
	
	/**
	 * @return
	 */
	private String createCss() {
		StringBuffer css = new StringBuffer();
		if(width != null && !"".equals(width))
			css.append(" width ='").append(width).append("'");
		if(align != null && !"".equals(align))
			css.append(" align ='").append(align).append("'");
		if(valign != null && !"".equals(valign))
			css.append(" valign ='").append(valign).append("'");
		if(id != null && !"".equals(id)){
			if( index != null)
				css.append(" id ='").append(id).append(index.intValue()).append("'");
			else
				css.append(" id ='").append(id).append("'");
		}
			
		if(nowrap != null && !"".equals(nowrap)  )
			css.append(" nowrap ='").append(nowrap).append("'");
		
		return css.toString();
	}

	/**
	 * @return Returns the align.
	 */
	public String getAlign() {
		return align;
	}
	/**
	 * @param align The align to set.
	 */
	public void setAlign(String align) {
		this.align = align;
	}
	/**
	 * @return Returns the valign.
	 */
	public String getValign() {
		return valign;
	}
	/**
	 * @param valign The valign to set.
	 */
	public void setValign(String valign) {
		this.valign = valign;
	}
	/**
	 * @return Returns the width.
	 */
	public String getWidth() {
		return width;
	}
	/**
	 * @param width The width to set.
	 */
	public void setWidth(String width) {
		this.width = width;
	}
	/**
	 * @return Returns the zero.
	 */
	public String getZero() {
		return zero;
	}
	/**
	 * @param zero The zero to set.
	 */
	public void setZero(String zero) {
		this.zero = zero;
	}
	
	/**
	 * @return Returns the appliedClass.
	 */
	public String getAppliedClass() {
		return appliedClass;
	}
	/**
	 * @param appliedClass The appliedClass to set.
	 */
	public void setAppliedClass(String appliedClass) {
		this.appliedClass = appliedClass;
	}
	/**
	 * @return Returns the id.
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	public void setId(String id) {
		this.id = id;
	}
	
	/**
	 * @return Returns the index.
	 */
	public Integer getIndex() {
		return index;
	}
	/**
	 * @param index The index to set.
	 */
	public void setIndex(Integer index) {
		this.index = index;
	}
	/**
	 * @return Returns the nowrap.
	 */
	public String getNowrap() {
		return nowrap;
	}
	/**
	 * @param nowrap The nowrap to set.
	 */
	public void setNowrap(String nowrap) {
		this.nowrap = nowrap;
	}
}
