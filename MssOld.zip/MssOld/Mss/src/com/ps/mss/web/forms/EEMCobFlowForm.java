/**
 * $Id: EEMTimersForm.java,v 1.1 2014/06/26 07:55:49 praveen Exp $
 */
package com.ps.mss.web.forms;
import java.util.List;
import com.ps.util.ListBoxItem;

public class EEMCobFlowForm extends EEMForm{
	/**
	 * searchType : Holds the value Application or member
	 */
	private String searchStatus;
	/**
	 * searchId : Holds Applciation Id or member Id
	 */
	private String searchAssignedTo;
	/**
	 * customerId : Holds Customer Id
	 */
	private String searchMember;
	private String searchEnrollDt;
	private String customerId;
	
	
	public String getSearchMember() {
		return searchMember;
	}

	public void setSearchMember(String searchMember) {
		this.searchMember = searchMember;
	}

	public String getSearchEnrollDt() {
		return searchEnrollDt;
	}

	public void setSearchEnrollDt(String searchEnrollDt) {
		this.searchEnrollDt = searchEnrollDt;
	}

	public String getSearchStatus() {
		return searchStatus;
	}

	public void setSearchStatus(String searchStatus) {
		this.searchStatus = searchStatus;
	}

	public String getSearchAssignedTo() {
		return searchAssignedTo;
	}

	public void setSearchAssignedTo(String searchAssignedTo) {
		this.searchAssignedTo = searchAssignedTo;
	}

	private String memberID;
	private String subLastName;
	private String subFirstName ;
	private String plan;
	private String maintData ;
	private String mSPType ;
	private String validityInd ;
	private String deleteInd ;
	private String fileDate ;
	private String rxBIN ;
	private String rxPCN ;
	private String rxGRP ;
	private String insuresType ;
	private String insuresName ;
	private String insuresAddr1 ;
	private String insuresAddr2 ;
	private String insuresCity ;
	private String insuresState ;
	private String insuresZip ;
	private String policyNbr ;

	private String	employeeID ;
	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getMemberID() {
		return memberID;
	}

	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}

	public String getSubLastName() {
		return subLastName;
	}

	public void setSubLastName(String subLastName) {
		this.subLastName = subLastName;
	}

	public String getSubFirstName() {
		return subFirstName;
	}

	public void setSubFirstName(String subFirstName) {
		this.subFirstName = subFirstName;
	}

	public String getPlan() {
		return plan;
	}

	public void setPlan(String plan) {
		this.plan = plan;
	}

	public String getMaintData() {
		return maintData;
	}

	public void setMaintData(String maintData) {
		this.maintData = maintData;
	}

	public String getmSPType() {
		return mSPType;
	}

	public void setmSPType(String mSPType) {
		this.mSPType = mSPType;
	}

	public String getValidityInd() {
		return validityInd;
	}

	public void setValidityInd(String validityInd) {
		this.validityInd = validityInd;
	}

	public String getDeleteInd() {
		return deleteInd;
	}

	public void setDeleteInd(String deleteInd) {
		this.deleteInd = deleteInd;
	}

	public String getFileDate() {
		return fileDate;
	}

	public void setFileDate(String fileDate) {
		this.fileDate = fileDate;
	}

	public String getRxBIN() {
		return rxBIN;
	}

	public void setRxBIN(String rxBIN) {
		this.rxBIN = rxBIN;
	}

	public String getRxPCN() {
		return rxPCN;
	}

	public void setRxPCN(String rxPCN) {
		this.rxPCN = rxPCN;
	}

	public String getRxGRP() {
		return rxGRP;
	}

	public void setRxGRP(String rxGRP) {
		this.rxGRP = rxGRP;
	}

	public String getInsuresType() {
		return insuresType;
	}

	public void setInsuresType(String insuresType) {
		this.insuresType = insuresType;
	}

	public String getInsuresName() {
		return insuresName;
	}

	public void setInsuresName(String insuresName) {
		this.insuresName = insuresName;
	}

	public String getInsuresAddr1() {
		return insuresAddr1;
	}

	public void setInsuresAddr1(String insuresAddr1) {
		this.insuresAddr1 = insuresAddr1;
	}

	public String getInsuresAddr2() {
		return insuresAddr2;
	}

	public void setInsuresAddr2(String insuresAddr2) {
		this.insuresAddr2 = insuresAddr2;
	}

	public String getInsuresCity() {
		return insuresCity;
	}

	public void setInsuresCity(String insuresCity) {
		this.insuresCity = insuresCity;
	}

	public String getInsuresState() {
		return insuresState;
	}

	public void setInsuresState(String insuresState) {
		this.insuresState = insuresState;
	}

	public String getInsuresZip() {
		return insuresZip;
	}

	public void setInsuresZip(String insuresZip) {
		this.insuresZip = insuresZip;
	}

	public String getPolicyNbr() {
		return policyNbr;
	}

	public void setPolicyNbr(String policyNbr) {
		this.policyNbr = policyNbr;
	}

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}

	public String getEmployeeDataCd() {
		return employeeDataCd;
	}

	public void setEmployeeDataCd(String employeeDataCd) {
		this.employeeDataCd = employeeDataCd;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeAddr1() {
		return employeeAddr1;
	}

	public void setEmployeeAddr1(String employeeAddr1) {
		this.employeeAddr1 = employeeAddr1;
	}

	public String getEmployeeAdr2() {
		return employeeAdr2;
	}

	public void setEmployeeAdr2(String employeeAdr2) {
		this.employeeAdr2 = employeeAdr2;
	}

	public String getPrepaidDate() {
		return prepaidDate;
	}

	public void setPrepaidDate(String prepaidDate) {
		this.prepaidDate = prepaidDate;
	}

	public String getEmployeeCity() {
		return employeeCity;
	}

	public void setEmployeeCity(String employeeCity) {
		this.employeeCity = employeeCity;
	}

	public String getEmployeeState() {
		return employeeState;
	}

	public void setEmployeeState(String employeeState) {
		this.employeeState = employeeState;
	}

	public String getEmployeeZip() {
		return employeeZip;
	}

	public void setEmployeeZip(String employeeZip) {
		this.employeeZip = employeeZip;
	}

	public String getiNSGroupNbr() {
		return iNSGroupNbr;
	}

	public void setiNSGroupNbr(String iNSGroupNbr) {
		this.iNSGroupNbr = iNSGroupNbr;
	}

	public String getiNSGroup() {
		return iNSGroup;
	}

	public void setiNSGroup(String iNSGroup) {
		this.iNSGroup = iNSGroup;
	}

	public String getmSPEffDate() {
		return mSPEffDate;
	}

	public void setmSPEffDate(String mSPEffDate) {
		this.mSPEffDate = mSPEffDate;
	}

	public String getmSPTermDate() {
		return mSPTermDate;
	}

	public void setmSPTermDate(String mSPTermDate) {
		this.mSPTermDate = mSPTermDate;
	}

	public String getMemberProvEffDate() {
		return memberProvEffDate;
	}

	public void setMemberProvEffDate(String memberProvEffDate) {
		this.memberProvEffDate = memberProvEffDate;
	}

	public String getMemberProvTermDate() {
		return memberProvTermDate;
	}

	public void setMemberProvTermDate(String memberProvTermDate) {
		this.memberProvTermDate = memberProvTermDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusDate() {
		return statusDate;
	}

	public void setStatusDate(String statusDate) {
		this.statusDate = statusDate;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	public String getAddNotes() {
		return addNotes;
	}

	public void setAddNotes(String addNotes) {
		this.addNotes = addNotes;
	}

	private String employeeDataCd ;
	private String employeeName ;
	private String employeeAddr1 ;
	private String employeeAdr2 ;
	private String prepaidDate ;
	private String employeeCity ;
	private String employeeState ;
	private String employeeZip ;
	private String iNSGroupNbr ;
	private String iNSGroup ;
	
	private String mSPEffDate ;
	private String mSPTermDate ;
	private String memberProvEffDate; 
	private String memberProvTermDate ;
	private String status ;
	private String statusDate ;
	private String statusDescription; 
	private String addNotes ;
	private String createUserID;
	private String createTime;
	private String LastUpdtUserID;
	private String LastUpdtTime;
	private String empRxBin;
	private String empRxPcn;
	private String empRxGrp;
	private String insRxBin;
	private String insRxPcn;
	private String insRxGrp;


	public String getCreateUserID() {
		return createUserID;
	}

	public void setCreateUserID(String createUserID) {
		this.createUserID = createUserID;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getLastUpdtUserID() {
		return LastUpdtUserID;
	}

	public void setLastUpdtUserID(String lastUpdtUserID) {
		LastUpdtUserID = lastUpdtUserID;
	}

	public String getLastUpdtTime() {
		return LastUpdtTime;
	}

	public void setLastUpdtTime(String lastUpdtTime) {
		LastUpdtTime = lastUpdtTime;
	}

	public String getEmpRxBin() {
		return empRxBin;
	}

	public void setEmpRxBin(String empRxBin) {
		this.empRxBin = empRxBin;
	}

	public String getEmpRxPcn() {
		return empRxPcn;
	}

	public void setEmpRxPcn(String empRxPcn) {
		this.empRxPcn = empRxPcn;
	}

	public String getEmpRxGrp() {
		return empRxGrp;
	}

	public void setEmpRxGrp(String empRxGrp) {
		this.empRxGrp = empRxGrp;
	}

	public String getInsRxBin() {
		return insRxBin;
	}

	public void setInsRxBin(String insRxBin) {
		this.insRxBin = insRxBin;
	}

	public String getInsRxPcn() {
		return insRxPcn;
	}

	public void setInsRxPcn(String insRxPcn) {
		this.insRxPcn = insRxPcn;
	}

	public String getInsRxGrp() {
		return insRxGrp;
	}

	public void setInsRxGrp(String insRxGrp) {
		this.insRxGrp = insRxGrp;
	}
	
	private String method;


	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}
	

}
