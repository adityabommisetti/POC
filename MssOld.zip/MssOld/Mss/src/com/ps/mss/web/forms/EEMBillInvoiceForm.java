/*
 * $Id: EEMBillInvoiceForm.java,v 1.1 2014/06/26 07:55:49 praveen Exp $
 */
package com.ps.mss.web.forms;

import java.util.List;

import com.ps.mss.dao.model.EmBBBInvoiceDetailVO;
import com.ps.mss.dao.model.EmBBBInvoiceHeaderVO;
import com.ps.mss.dao.model.EmMbrCommentVO;
import com.ps.mss.model.EMMbrInvoiceSummaryVO;

public class EEMBillInvoiceForm extends EEMSubMenuForm {

	private String searchInvoiceNbr;
	private String searchInvoiceId;
	private String searchInvoiceStatus;
	private String searchInvoiceType;
	private String searchInvoiceGroup;
	private String searchLastName;
	private String searchHicNbr;
	private List lstInvoiceStatus;
	private List lstFunctionCode;
	private List lstRefReasonCode; //415889 Refund Extract
	private List lstInvoiceType;
	private List lstInvoiceGroup;
	private List lstRelatedInvoiceType;
	
	private boolean searchExpanded;
	private int selectedSearchRow;
	private String selectedMbrGrpInd;
	private List listSearchResults;
	private EmBBBInvoiceHeaderVO displayInvoiceHeader;
	
	private boolean detailListExpanded=true;
	private int selectedDetailRow;
	private String detailDisplayState;
	private List listDetail;
	private EMMbrInvoiceSummaryVO displayInvoiceSummary = new EMMbrInvoiceSummaryVO();
	private EmBBBInvoiceDetailVO displayInvoiceDetail = new EmBBBInvoiceDetailVO();
	
	private List listComments;
	private int topDisplayCommentRow;
	private int selectedCommentRow;
	private EmMbrCommentVO displayComment = new EmMbrCommentVO();
	private boolean commentChanged;
	private String commentDisplayState;
	private boolean commentsExpanded;
	
	private boolean transExpanded = false;
	private String transGrpId;
	private String transName;
	private String transAmt;
	private String transDetailAmt;
	private String searchTransGrp;
	private String searchTransName;
	private String searchTransLastName;
	private List lstMbrGrp;
	
	private String searchSupplId;
	
	public String getSearchSupplId() {
		return searchSupplId;
	}
	public void setSearchSupplId(String searchSupplId) {
		this.searchSupplId = searchSupplId;
	}

		//Added for BilMbrGrp Search JSP Issue : Start
		private String mbrLabel;
		
		public String getMbrLabel() {
			return mbrLabel;
		}
		public void setMbrLabel(String mbrLabel) {
			this.mbrLabel = mbrLabel;
		}
		//Added for BilMbrGrp Search JSP Issue : End
	
	// IFOX- 390543 Begin
		private String strInvoiceDetails;
		
		public String getStrInvoiceDetails() {
			return strInvoiceDetails;
		}
		public void setStrInvoiceDetails(String strInvoiceDetails) {
			this.strInvoiceDetails = strInvoiceDetails;
		}
		// End

		private String selectedInvoiceGroup = "";
		
	public String getSearchInvoiceId() {
		return searchInvoiceId;
	}
	public void setSearchInvoiceId(String searchInvoiceId) {
		this.searchInvoiceId = searchInvoiceId;
	}
	public String getSearchInvoiceNbr() {
		return searchInvoiceNbr;
	}
	public void setSearchInvoiceNbr(String searchInvoiceNbr) {
		this.searchInvoiceNbr = searchInvoiceNbr;
	}
	
	public boolean getSearchExpanded() {
		return searchExpanded;
	}
	public void setSearchExpanded(boolean searchExpanded) {
		this.searchExpanded = searchExpanded;
	}

	public List getListSearchResults() {
		return listSearchResults;
	}
	public void setListSearchResults(List listSearchResults) {
		this.listSearchResults = listSearchResults;
	}
	public int getSelectedSearchRow() {
		return selectedSearchRow;
	}
	public void setSelectedSearchRow(int selectedSearchRow) {
		this.selectedSearchRow = selectedSearchRow;
	}
	
	public EmBBBInvoiceHeaderVO getDisplayInvoiceHeader() {
		return displayInvoiceHeader;
	}
	public void setDisplayInvoiceHeader(EmBBBInvoiceHeaderVO displayInvoiceHeader) {
		this.displayInvoiceHeader = displayInvoiceHeader;
	}
	
	
	public EMMbrInvoiceSummaryVO getDisplayInvoiceSummary() {
		return displayInvoiceSummary;
	}
	public void setDisplayInvoiceSummary(EMMbrInvoiceSummaryVO displayInvoiceSummary) {
		this.displayInvoiceSummary = displayInvoiceSummary;
	}
	public EmBBBInvoiceDetailVO getDisplayInvoiceDetail() {
		return displayInvoiceDetail;
	}
	public void setDisplayInvoiceDetail(
			EmBBBInvoiceDetailVO displayInvoiceDetail) {
		this.displayInvoiceDetail = displayInvoiceDetail;
	}
	public List getListDetail() {
		return listDetail;
	}
	public void setListDetail(List listDetail) {
		this.listDetail = listDetail;
	}
	public int getSelectedDetailRow() {
		return selectedDetailRow;
	}
	public void setSelectedDetailRow(int selectedDetailRow) {
		this.selectedDetailRow = selectedDetailRow;
	}
	public boolean isDetailListExpanded() {
		return detailListExpanded;
	}
	public void setDetailListExpanded(boolean detailListExpanded) {
		this.detailListExpanded = detailListExpanded;
	}
	public List getLstInvoiceStatus() {
		return lstInvoiceStatus;
	}
	public void setLstInvoiceStatus(List lstInvoiceStatus) {
		this.lstInvoiceStatus = lstInvoiceStatus;
	}
	public String getSearchInvoiceStatus() {
		return searchInvoiceStatus;
	}
	public void setSearchInvoiceStatus(String searchInvoiceStatus) {
		this.searchInvoiceStatus = searchInvoiceStatus;
	}
	public String getCommentDisplayState() {
		return commentDisplayState;
	}
	public void setCommentDisplayState(String commentDisplayState) {
		this.commentDisplayState = commentDisplayState;
	}
	public List getListComments() {
		return listComments;
	}
	public void setListComments(List listComments) {
		this.listComments = listComments;
	}
	public void setListCommentsWithDisplay(List listComments) {
		this.listComments = listComments;
		if ((this.listComments != null) && (this.listComments.isEmpty() == false)) {
			this.displayComment = (EmMbrCommentVO) this.listComments.get(selectedCommentRow);
		}
		else {
			this.displayComment = new EmMbrCommentVO();
		}
	}
	public boolean isCommentChanged() {
		return commentChanged;
	}
	public void setCommentChanged(boolean commentChanged) {
		this.commentChanged = commentChanged;
	}
	public EmMbrCommentVO getDisplayComment() {
		return displayComment;
	}
	public void setDisplayComment(EmMbrCommentVO displayComment) {
		this.displayComment = displayComment;
	}
	public int getSelectedCommentRow() {
		return selectedCommentRow;
	}
	public void setSelectedCommentRow(int selectedCommentRow) {
		this.selectedCommentRow = selectedCommentRow;
	}
	public int getTopDisplayCommentRow() {
		return topDisplayCommentRow;
	}
	public void setTopDisplayCommentRow(int topDisplayCommentRow) {
		this.topDisplayCommentRow = topDisplayCommentRow;
	}
	public boolean isCommentsExpanded() {
		return commentsExpanded;
	}
	public void setCommentsExpanded(boolean commentsExpanded) {
		this.commentsExpanded = commentsExpanded;
	}
	public String getDetailDisplayState() {
		return detailDisplayState;
	}
	public void setDetailDisplayState(String detailDisplayState) {
		this.detailDisplayState = detailDisplayState;
	}
	public List getLstFunctionCode() {
		return lstFunctionCode;
	}
	public void setLstFunctionCode(List lstFunctionCode) {
		this.lstFunctionCode = lstFunctionCode;
	}
	public List getLstInvoiceType() {
		return lstInvoiceType;
	}
	public void setLstInvoiceType(List lstInvoiceType) {
		this.lstInvoiceType = lstInvoiceType;
	}
	public String getSearchInvoiceType() {
		return searchInvoiceType;
	}
	public void setSearchInvoiceType(String searchInvoiceType) {
		this.searchInvoiceType = searchInvoiceType;
	}
	public String getSearchLastName() {
		return searchLastName;
	}
	public void setSearchLastName(String searchLastName) {
		this.searchLastName = searchLastName;
	}
	public String getSearchHicNbr() {
		return searchHicNbr;
	}
	public void setSearchHicNbr(String searchHicNbr) {
		this.searchHicNbr = searchHicNbr;
	}
	public String getSearchInvoiceGroup() {
		return searchInvoiceGroup;
	}
	public void setSearchInvoiceGroup(String searchInvoiceGroup) {
		this.searchInvoiceGroup = searchInvoiceGroup;
	}
	public List getLstInvoiceGroup() {
		return lstInvoiceGroup;
	}
	public void setLstInvoiceGroup(List lstInvoiceGroup) {
		this.lstInvoiceGroup = lstInvoiceGroup;
	}
	public List getLstRelatedInvoiceType() {
		return lstRelatedInvoiceType;
	}
	public void setLstRelatedInvoiceType(List lstRelatedInvoiceType) {
		this.lstRelatedInvoiceType = lstRelatedInvoiceType;
	}
	/**
	 * @return Returns the transAmt.
	 */
	public String getTransAmt() {
		return transAmt;
	}
	/**
	 * @param transAmt The transAmt to set.
	 */
	public void setTransAmt(String transAmt) {
		this.transAmt = transAmt;
	}
	/**
	 * @return Returns the transGrpId.
	 */
	public String getTransGrpId() {
		return transGrpId;
	}
	/**
	 * @param transGrpId The transGrpId to set.
	 */
	public void setTransGrpId(String transGrpId) {
		this.transGrpId = transGrpId;
	}
	/**
	 * @return Returns the transName.
	 */
	public String getTransName() {
		return transName;
	}
	/**
	 * @param transName The transName to set.
	 */
	public void setTransName(String transName) {
		this.transName = transName;
	}
	/**
	 * @return Returns the transDetailAmt.
	 */
	public String getTransDetailAmt() {
		return transDetailAmt;
	}
	/**
	 * @param transDetailAmt The transDetailAmt to set.
	 */
	public void setTransDetailAmt(String transDetailAmt) {
		this.transDetailAmt = transDetailAmt;
	}
	/**
	 * @return Returns the transExpanded.
	 */
	public boolean isTransExpanded() {
		return transExpanded;
	}
	/**
	 * @param transExpanded The transExpanded to set.
	 */
	public void setTransExpanded(boolean transExpanded) {
		this.transExpanded = transExpanded;
	}
	/**
	 * @return Returns the searchTransGrp.
	 */
	public String getSearchTransGrp() {
		return searchTransGrp;
	}
	/**
	 * @param searchTransGrp The searchTransGrp to set.
	 */
	public void setSearchTransGrp(String searchTransGrp) {
		this.searchTransGrp = searchTransGrp;
	}
	/**
	 * @return Returns the searchTransName.
	 */
	public String getSearchTransName() {
		return searchTransName;
	}
	/**
	 * @param searchTransName The searchTransName to set.
	 */
	public void setSearchTransName(String searchTransName) {
		this.searchTransName = searchTransName;
	}
	/**
	 * @return Returns the lstMbrGrp.
	 */
	public List getLstMbrGrp() {
		return lstMbrGrp;
	}
	/**
	 * @param lstMbrGrp The lstMbrGrp to set.
	 */
	public void setLstMbrGrp(List lstMbrGrp) {
		this.lstMbrGrp = lstMbrGrp;
	}
	/**
	 * @return Returns the searchTransLastName.
	 */
	public String getSearchTransLastName() {
		return searchTransLastName;
	}
	/**
	 * @param searchTransLastName The searchTransLastName to set.
	 */
	public void setSearchTransLastName(String searchTransLastName) {
		this.searchTransLastName = searchTransLastName;
	}
	/**
	 * @return Returns the selectedMbrGrpInd.
	 */
	public String getSelectedMbrGrpInd() {
		return selectedMbrGrpInd;
	}
	/**
	 * @param selectedMbrGrpInd The selectedMbrGrpInd to set.
	 */
	public void setSelectedMbrGrpInd(String selectedMbrGrpInd) {
		this.selectedMbrGrpInd = selectedMbrGrpInd;
	}
	public String getSelectedInvoiceGroup() {
		return selectedInvoiceGroup;
	}
	public void setSelectedInvoiceGroup(String selectedInvoiceGroup) {
		this.selectedInvoiceGroup = selectedInvoiceGroup;
	}
	 //415889 Refund Extract start
	public List getLstRefReasonCode() {
		return lstRefReasonCode;
	}
	public void setLstRefReasonCode(List lstRefReasonCode) {
		this.lstRefReasonCode = lstRefReasonCode;
	}
	 //415889 Refund Extract end
	//IFOX- 421763 Billing User Role : start
	private String nsfAdjustVal;

	/**
	 * @return the nsfAdjustVal
	 */
	public String getNsfAdjustVal() {
		return nsfAdjustVal;
	}
	/**
	 * @param nsfAdjustVal the nsfAdjustVal to set
	 */
	public void setNsfAdjustVal(String nsfAdjustVal) {
		this.nsfAdjustVal = nsfAdjustVal;
	}
	//IFOX- 421763 Billing User Role :end
	
	
}
