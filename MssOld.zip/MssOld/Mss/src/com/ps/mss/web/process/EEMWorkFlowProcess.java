package com.ps.mss.web.process;

import java.io.IOException;
import java.sql.Connection;
//import java.sql.Timestamp;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.manager.EEMEnrollManager;
import com.ps.mss.manager.EEMWorkFlowManager;
import com.ps.mss.model.EEMContext;
import com.ps.mss.model.EEMEnrollVO;
import com.ps.mss.model.EEMWorkFLowVO;
import com.ps.mss.model.Pagination;
import com.ps.mss.web.forms.EEMApplForm;
import com.ps.mss.web.forms.EEMEnrollForm;
import com.ps.mss.web.forms.EEMWorkFlowForm;
import com.ps.mss.web.helper.EEMEnrollHelper;
import com.ps.mss.web.helper.EEMWorkFlowHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.dao.DaoFactory;
import com.ps.mss.dao.EEMAssignActivityDao;
import com.ps.mss.dao.EEMQueCharDAO;
import com.ps.mss.dao.EEMUserListDao;
import com.ps.mss.dao.EEMWorkFlowDao;
import com.ps.mss.dao.model.EEMAssignActivityVO;
import com.ps.mss.dao.model.EEMQueCharVO;
import com.ps.mss.dao.model.EEMUserListVO;
import com.ps.mss.dao.model.EMWFSupQueuesUserCountVO;
import com.ps.mss.dao.model.EMWFSupervisorUserVO;
import com.ps.mss.db.EEMWFCodeCache;
import com.ps.util.StringUtil;

import java.sql.SQLException;
/*******************************************************************************
 * Functionality Description : new Process class created for new tab WORK FLOW screen
 * External Objects called :EEMSwitchUtil,EEMWorkFlowAction 
 * Known Bugs : None * 
 * Modification Log 
 * Creation Date: Nov-2013        
 * Author: Prare
 
 ******************************************************************************/
public class EEMWorkFlowProcess {	
	/**
	 * Holds Properties object
	 */
	Properties props;
	/**
	 * logger holds logger object
	 */
	private static Logger logger = LoggerFactory.getLogger(EEMWorkFlowProcess.class);
	/**
	 * Constructor
	 */
	public EEMWorkFlowProcess(){
		try{
			props = new Properties();
			props.load(getClass().getClassLoader().getResourceAsStream("mss/resources/EEMWorkflow.properties"));
		}catch(Exception e){
			logger.error("EEMWorkFlowProcess:error"+e.getMessage());
			}
	}	
	
	/** //-executes when Clicked on WorkFlow menu.
	 * @param conn holds Connection Object
	 * @param sessionHelper holds SessionHelper object
	 * @param context holds EEMContext Object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds HttpServletRequest object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws IOException when IP related error comes
	 */
	public ActionForward switchMenu(Connection conn, SessionHelper sessionHelper, EEMContext context,
		ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException, IOException {
		
		/*java.util.Date date= new java.util.Date();
		logger.info("WF switchMenu() START TIME: "+new Timestamp(date.getTime()));*/
		logger.info("WF PROCESS START -Millis- TIMESTAMP:: "+System.currentTimeMillis());
		 
		logger.info("EEMWorkFlowProcess-switchMenu: Start");
		context.setSelectedMenu(EEMConstants.MENU_WF);	
		
		EEMWorkFlowForm eemWFForm = null;		
		if (!(form instanceof EEMWorkFlowForm)) {			
			eemWFForm = EEMWorkFlowHelper.getEEMWorkFlowForm(sessionHelper);
			if (eemWFForm == null) {
				eemWFForm = new EEMWorkFlowForm();				
			}
		}
		else{
			eemWFForm = (EEMWorkFlowForm) form;			
		}	
		
		EEMWorkFLowVO workFlowVO = context.getWorkFlowVO();
		workFlowVO.setUsrOptedAction(EEMConstants.EEM_WF_USER_OPT_WFMENU);
		EEMWorkFlowHelper.setVOToForm(workFlowVO, eemWFForm, sessionHelper);
		
		EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
		request.setAttribute(EEMConstants.EEM_WF_FORM, eemWFForm);
		clearAgrQsActsLists(workFlowVO, eemWFForm);
		userWorkFlowInit(conn, sessionHelper, context, mapping, eemWFForm, request);
		
		/*date= new java.util.Date();
		logger.info("WF switchMenu() END TIME: "+new Timestamp(date.getTime()));*/
		logger.info("WF PROCESS END -Millis- TIMESTAMP:: "+System.currentTimeMillis());
		
		return mapping.findForward(EEMConstants.EEM_GROUP_WF);
	}//switchMenu()
	
	
	/**
	 * executes when Clicked on any function in WorkFlow UI.
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */
	public ActionForward selectedMenu(Connection conn, SessionHelper sessionHelper, EEMContext context,
		ActionMapping mapping, ActionForm form, HttpServletRequest request)	
				throws ApplicationException, SQLException {
			
			
			logger.info("WF PROCESS START -Millis- TIMESTAMP:: "+System.currentTimeMillis());
			
			logger.info("EEMWorkFlowProcess-selectedMenu()");
			context.setSelectedMenu(EEMConstants.MENU_WF);
			EEMWorkFlowForm eemWFForm = (EEMWorkFlowForm) form;
			
			String method = eemWFForm.getMethod();
			EEMWorkFLowVO workFlowVO = context.getWorkFlowVO();
			request.setAttribute(EEMConstants.EEM_WF_FORM, eemWFForm);		
			
			//- executes when clicked on GetWork button.	
			if(method.equals(EEMConstants.EEM_WF_USER_OPT_GETWORK)){		
				logger.info("USER_WF : GET WORK");
				workFlowVO.setUsrOptedAction(EEMConstants.EEM_WF_USER_OPT_GETWORK);
				clearAgrQsActsLists(workFlowVO, eemWFForm);
				usergetWork(conn, sessionHelper, context, mapping, eemWFForm, request, "first");
				// added go button also to refresh the view
				logger.info("USER_WF : GO BUTTON CLICKED");
				clearAgrQsActsLists(workFlowVO, eemWFForm);
				workFlowVO.setUsrOptedAction(EEMConstants.EEM_WF_USER_OPT_GO);
				getSuprSelUsrData(conn, context, eemWFForm, workFlowVO);
			}
			//- executes when clicked on GO button.
			else if(method.equals(EEMConstants.EEM_WF_USER_OPT_GO)){
				logger.info("USER_WF : GO BUTTON CLICKED");
				clearAgrQsActsLists(workFlowVO, eemWFForm);
				workFlowVO.setUsrOptedAction(EEMConstants.EEM_WF_USER_OPT_GO);
				getSuprSelUsrData(conn, context, eemWFForm, workFlowVO);
			}
			//- executes when clicked on SubSet Activities button.
			else if(method.equals(EEMConstants.EEM_WF_USER_OPT_SUBSETACTIVITIES)){		
				logger.info("USER_WF : SUBSETACTIVITIES");
				workFlowVO.setUsrOptedAction(EEMConstants.EEM_WF_USER_OPT_SUBSETACTIVITIES);
				saveUserSearchInput(workFlowVO, eemWFForm);
				clearAgrQsActsLists(workFlowVO, eemWFForm);
				userSubsetAgreements(conn, sessionHelper, context, mapping, eemWFForm, request, "first");
			}
			
			//- executes when clicked on Get Priorities button.
			else if(method.equals(EEMConstants.EEM_WF_USER_OPT_GET_PRIORITIES)){
				logger.info("USER_WF : GET PRIORITIES BUTTON CLICKED");
				workFlowVO.setUsrOptedAction(EEMConstants.EEM_WF_USER_OPT_GET_PRIORITIES);
				getUserPrioritesData(conn, eemWFForm, workFlowVO);
			}			
			//- executes when clicked on Pagination-FIRST arrow button.
			else if(method.equals(EEMConstants.EEM_WF_USER_AGREEMENTS_PAGE_FIRST)){	
				logger.info("USER_WF : AGREEMENTS_PAGE_FIRST");
				clearAgrQsActsLists(workFlowVO, eemWFForm);
				if(workFlowVO.getUsrLoadedAgrmntsUsrOpt().equals(EEMConstants.EEM_WF_USER_OPT_WFMENU)){
					usrGWMenuAgrPagination(conn, context, eemWFForm, "first");
				}
				else if(workFlowVO.getUsrLoadedAgrmntsUsrOpt().equals(EEMConstants.EEM_WF_USER_OPT_GO)){
					usrGoOptAgrPagination(conn, context, eemWFForm, "first");
				}	
				else{//user opted SubSet Activities button.
					usrSsActAgrPagination(conn, context, eemWFForm, "first");
				}
			}
			//- executes when clicked on Pagination-NEXT arrow button.
			else if(method.equals(EEMConstants.EEM_WF_USER_AGREEMENTS_PAGE_NEXT)){	
				logger.info("USER_WF : AGREEMENTS_PAGE_NEXT");
				clearAgrQsActsLists(workFlowVO, eemWFForm);
				if(workFlowVO.getUsrLoadedAgrmntsUsrOpt().equals(EEMConstants.EEM_WF_USER_OPT_WFMENU)){
					usrGWMenuAgrPagination(conn, context, eemWFForm, "next");
				}
				else if(workFlowVO.getUsrLoadedAgrmntsUsrOpt().equals(EEMConstants.EEM_WF_USER_OPT_GO)){
					usrGoOptAgrPagination(conn, context, eemWFForm, "next");
				}
				else{					
					usrSsActAgrPagination(conn, context, eemWFForm, "next");
				}
			}
			//- executes when clicked on Pagination-PREVIOUS arrow button.
			else if(method.equals(EEMConstants.EEM_WF_USER_AGREEMENTS_PAGE_PREV)){
				logger.info("USER_WF : AGREEMENTS_PAGE_PREV");
				clearAgrQsActsLists(workFlowVO, eemWFForm);
				if(workFlowVO.getUsrLoadedAgrmntsUsrOpt().equals(EEMConstants.EEM_WF_USER_OPT_WFMENU)){
					usrGWMenuAgrPagination(conn, context, eemWFForm, "previous");
				}
				else if(workFlowVO.getUsrLoadedAgrmntsUsrOpt().equals(EEMConstants.EEM_WF_USER_OPT_GO)){
					usrGoOptAgrPagination(conn, context, eemWFForm, "previous");
				}
				else{					
					usrSsActAgrPagination(conn, context, eemWFForm, "previous");
				}
			}
			//- executes when clicked on Pagination-LAST arrow button.
			/* Fix for Pagination Last(>>) button CR # 00370553 - START */
			else if(method.equals(EEMConstants.EEM_WF_USER_AGREEMENTS_PAGE_LAST)){	
				logger.info("USER_WF : AGREEMENTS_PAGE_LAST");
				clearAgrQsActsLists(workFlowVO, eemWFForm);
				EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
				wfMgr.getTotalRecordsPagination(conn, context, eemWFForm);
//				 context.getWorkFlowVO().setUsrAgrmntLstPageNbr(maxPageNum);
//				 workFlowVO.setUsrAgrmntLstPageNbr(maxPageNum);
				if(workFlowVO.getUsrLoadedAgrmntsUsrOpt().equals(EEMConstants.EEM_WF_USER_OPT_WFMENU)){
					usrGWMenuAgrPagination(conn, context, eemWFForm, "next");
				}
				else if(workFlowVO.getUsrLoadedAgrmntsUsrOpt().equals(EEMConstants.EEM_WF_USER_OPT_GO)){
					usrGoOptAgrPagination(conn, context, eemWFForm, "next");
				}
				else{					
					usrSsActAgrPagination(conn, context, eemWFForm, "next");
				}
				
			}
			/* Fix for Pagination Last(>>) button CR # 00370553 - END */
			//- executes when clicked on an AGREEMENT row in the Agreements table.
			else if(method.equals(EEMConstants.EEM_WF_USER_GET_WORK_SRCH_QUE)){
				logger.info("USER_WF : GET_WORK_SRCH_QUE (CLICKED ON AGREEMENT)");
				clearActsLists(workFlowVO, eemWFForm);
				userGWQueueSearch(conn, sessionHelper, context, mapping, eemWFForm, workFlowVO, request, "first");
			}
			//- executes when clicked on a QUEUE row in the Queues table.
			else if(method.equals(EEMConstants.EEM_WF_USER_GET_WORK_SRCH_ACTIVITY)){
				logger.info("USER_WF : GET_WORK_SRCH_ACTIVITY (CLICKED ON QUEUE)");
				userGWActivitySearch(conn, sessionHelper, context, mapping, eemWFForm, workFlowVO, request, "first");
			}
			//- executes when clicked on an ACTIVITY in the Activities table(for Application Entry tab Navigation). 
			else if(method.equals(EEMConstants.EEM_WF_USER_GET_WORK_SRCH_APPL)){
				logger.info("USER_WF : REDIRECTING TO APPL ENTRY TAB");
				EEMWorkFlowHelper.saveEEMWorkFlowForm(sessionHelper,(EEMWorkFlowForm) eemWFForm);
				EEMWorkFlowProcessHelper pHelp = new EEMWorkFlowProcessHelper();
				//-Initializing EEM ApplForm-Start
				EEMApplForm eemApplForm = new EEMApplForm();
				pHelp.eemApplMenu(conn, sessionHelper, context, mapping, eemApplForm, request);	
				eemApplForm.setSearchHicNo("");
				eemApplForm.setSearchApplId(eemWFForm.getSrchAppOrMbrId());//-setting ApplicationId
				eemApplForm.setCustomerId(sessionHelper.getMfId());
				//-Initializing EEN ApplForm-end
				request.setAttribute(EEMConstants.EEM_APPL_FORM, eemApplForm);
				return pHelp.eemApplSearch(conn, sessionHelper, context, mapping, eemApplForm, request);
			}
			//- executes when clicked on an ACTIVITY in the Activities table(for Member tab Navigation). 
			else if(method.equals(EEMConstants.EEM_WF_USER_GET_WORK_SRCH_MEMBER)){
				logger.info("USER_WF : REDIRECTING TO MEMBER TAB");
				EEMWorkFlowHelper.saveEEMWorkFlowForm(sessionHelper,(EEMWorkFlowForm) eemWFForm);
				EEMWorkFlowProcessHelper pHelp = new EEMWorkFlowProcessHelper();				
				//-Initializing EEM ApplForm-Start
					context.setSelectedMenu(EEMConstants.MENU_ENROLLMENT);
					EEMEnrollForm eemEnrollForm = EEMEnrollHelper.getEEMForm(sessionHelper);						
					if (eemEnrollForm == null) {
						eemEnrollForm = new EEMEnrollForm();
						eemEnrollForm.setSelectedMemberTab(EEMConstants.EEM_MBR_TAB_DEMOGRAPHIC);
						eemEnrollForm.setTabPageMove("");
					}					
					EEMEnrollVO enrollVO = context.getEnrollVO();
					enrollVO.setMessage("");
					EEMEnrollHelper.setEnrollFormList(eemEnrollForm, sessionHelper.getSession());
					EEMEnrollHelper.copyVOToForm(enrollVO,eemEnrollForm);
					EEMEnrollHelper.setDisplayItems(enrollVO,eemEnrollForm);
					EEMEnrollManager.setAgentsLookUp(conn, sessionHelper, eemEnrollForm);
					request.setAttribute(EEMConstants.EEM_ENROLL_FORM, eemEnrollForm);
					eemEnrollForm.setSearchHicNo("");//setting HICNbr
					eemEnrollForm.setSearchMemberId(eemWFForm.getSrchAppOrMbrId());//setting MemberId
				//-Initializing EEN ApplForm-End
				pHelp.eemEnrollSearch( conn,  sessionHelper,  context,  mapping,  eemEnrollForm,  request);
				try{
	            	eemEnrollForm.setSelectedMemberTab(props.getProperty(eemWFForm.getScreenId().trim()));//screenId
				}catch(Exception e){
					logger.error("calling Member Menu from WorkFlow Menu"+e.getMessage());
					eemEnrollForm.setSelectedMemberTab(EEMConstants.EEM_MBR_TAB_DEMOGRAPHIC);
				}
	            EEMEnrollHelper.setEnrollFormList(eemEnrollForm, sessionHelper.getSession());
				return mapping.findForward(EEMConstants.EEM_ENROLLMENT);
			}
			else if(method.equals(EEMConstants.EEM_WF_GET_ADMIN_HISTORY)){
				logger.info("USER_WF : eem_wf_get_admin_history");
				//getAdminHistory(conn, eemWFForm, workFlowVO, "first");
				EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
				EEMWorkFlowHelper.setAdminHistSrchYear(eemWFForm);
				return mapping.findForward(EEMConstants.EEM_WF_ADMIN_HISTORY);
			}
			else if(method.equals(EEMConstants.EEM_WF_GET_ADMIN_HIST_DETAILS)){
				logger.info("USER_WF : eem_wf_get_admin_hist_details");
				getAdminHistoryDetails(conn, eemWFForm, workFlowVO, "first", true);
				EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
				EEMWorkFlowHelper.setAdminHistSrchYear(eemWFForm);
				return mapping.findForward(EEMConstants.EEM_WF_ADMIN_HISTORY);
			}
			else if(method.equals(EEMConstants.EEM_WF_GET_ADMIN_HIST_DETAIL_PAGE)){
				logger.info("USER_WF : eem_wf_get_admin_hist_detail_page");
				getAdminHistoryDetails(conn, eemWFForm, workFlowVO, eemWFForm.getAdminHistPageOpt(), false);
				EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
				EEMWorkFlowHelper.setAdminHistSrchYear(eemWFForm);
				return mapping.findForward(EEMConstants.EEM_WF_ADMIN_HISTORY);
			}
			//045_AssignActivity Start			
			else if(method.equals(EEMConstants.EEM_WF_NAV_WF)){				
				clearAgrQsActsLists(workFlowVO, eemWFForm);
				workFlowVO.setUsrOptedAction(EEMConstants.EEM_WF_USER_OPT_GO);
				eemWFForm.setSuprSelectedUName(StringUtil.nonNullTrim(eemWFForm.getNavUserId()));				
				workFlowVO.setSuprSelectedUName(eemWFForm.getSuprSelectedUName());
				getSuprSelUsrData(conn, context, eemWFForm, workFlowVO);
				//suprSelUsrAgreements(conn, sessionHelper, context, mapping, eemWFForm, request, "first");
			}
			//045_AssignActivity End
			
			/**
			 * 045_HighMark_Queue Characteristics Start
			 * 
			 */			
			else if("getQueCharInfo".equals(method)){	
				
				return eemWorkFlowGetQueChar(conn, sessionHelper, context, mapping,form, request);
			}else if ("queCharPageNext".equals(method)){
				
				return  eemQueCharPage(conn, sessionHelper, context,
						mapping, form, request, "next");
			}else if ("queCharPageFirst".equals(method)){
				
				return eemQueCharPage(conn, sessionHelper, context,
						mapping, form, request, "first");
			}else if ("queCharPagePrev".equals(method)){
				
				return eemQueCharPage(conn, sessionHelper, context,
						mapping, form, request, "previous");
			}else if ("queCharInfoUpdate".equals(method)){
				
				return eemQueCharUpdate(conn, sessionHelper, context, mapping,form, request);
			}			/**
			 * 045_HighMark_Queue Characteristics End
			 */
			/**
			 * 045_UserList Start
			 */
			else if("getUserListInfo".equals(method)){
				
				return eemWorkFlowGetUserList(conn, sessionHelper, context, mapping,form, request);
			}else if("userListSearch".equals(method)){
									
				return eemWorkFlowGetUserSearchList(conn, sessionHelper, context, mapping,form, request);
			}else if ("userListUpdate".equals(method)){
					
				return eemUserListUpdate(conn, sessionHelper, context, mapping,form, request);
			}else if ("userListPageNext".equals(method)){				
				return  eemUserListPage(conn, sessionHelper, context,
						mapping, form, request, "next");
			}else if ("userListPageFirst".equals(method)){				
				return eemUserListPage(conn, sessionHelper, context,
						mapping, form, request, "first");
			}else if ("userListPagePrev".equals(method)){				
				return eemUserListPage(conn, sessionHelper, context,
						mapping, form, request, "previous");
			}
			/**
			 * 045_UserList End
			 */
			/**
			 * 045_AssignActivity Start
			 */
			else if("getAssignActivityInfo".equals(method)){				
				return getAssignActivityList(conn, sessionHelper, context, mapping,form, request);
			}else if("activityListSearch".equals(method)){				
				return getAssignActivitySearchList(conn, sessionHelper, context, mapping,form, request);
			}else if ("activityListUpdate".equals(method)){				
				return eemAssignActivityUpdate(conn, sessionHelper, context, mapping,form, request);
			}else if ("assignActivityPageNext".equals(method)){				
				return  eemAssignActivityPage(conn, sessionHelper, context,
						mapping, form, request, "next");
			/* Fix for Pagination Last(>>) button CR # 00370553 - START */	
			}else if ("assignActivityPageLast".equals(method)){				
				return  eemAssignActivityPage(conn, sessionHelper, context,
						mapping, form, request, "last");
			/* Fix for Pagination Last(>>) button CR # 00370553 - END */	
			}else if ("assignActivityPageFirst".equals(method)){				
				return eemAssignActivityPage(conn, sessionHelper, context,
						mapping, form, request, "first");
			}else if ("assignActivityPagePrev".equals(method)){				
				return eemAssignActivityPage(conn, sessionHelper, context,
						mapping, form, request, "previous");
			}
			/**
			 * 045_AssignActivity End
			 */
			/**
			 * CloseAssignActivity Starts
			 */			
			else if("closeAssignActivityInfo".equals(method)){				
				return closeAssignActivityList(conn, sessionHelper, context, mapping,form, request);
			}
			else if("closeActivityListSearch".equals(method)){				
				return closeAssignActivitySearchList(conn, sessionHelper, context, mapping,form, request);
			}
			else if ("closeQueActivities".equals(method)){				
				return eemCloseQueActivities(conn, sessionHelper, context, mapping,form, request);
			}
			else if ("closeAssignActivityPageNext".equals(method)){				
				return  closeAssignActivityPage(conn, sessionHelper, context,
						mapping, form, request, "next");
			}else if ("closeAssignActivityPageFirst".equals(method)){				
				return closeAssignActivityPage(conn, sessionHelper, context,
						mapping, form, request, "first");
			}else if ("closeAssignActivityPagePrev".equals(method)){				
				return closeAssignActivityPage(conn, sessionHelper, context,
						mapping, form, request, "previous");
			}
			/**
			 * CloseAssignActivity Ends
			 */
			/**
			 * 045_AtRisk Changes start
			 */
            else if(method.equals(EEMConstants.EEM_WF_GET_AT_RISK)){            	
            	return getAtRiskSummary(conn, sessionHelper, context, mapping,form, request);
			}else if(method.equals(EEMConstants.EEM_WF_GET_AT_RISK_DTL)){				
				 return getAtRiskDetailsInfo(conn, sessionHelper, context, mapping, eemWFForm, workFlowVO, request, "first");
			}
			/**
			 * 045_AtRisk Changes End
			 */
			/* Highmark 045 Workflow Iteration-2 Supervisor and Admin change starts   */
			else if("getSupervisorInfo".equals(method)){	
				
				return eemWorkFlowSupervisor(conn, sessionHelper, context, mapping, eemWFForm, request);
			}else if("supervisorUserDetailDisplay".equals(method)){	
				
				return eemWorkFlowUserDetailDisplay(conn, sessionHelper, context, mapping,eemWFForm, request);
			}else if("supervisorUserUpdate".equals(method)){	
				
				return updateSupervisorUserInfo(conn, sessionHelper, context, mapping,eemWFForm, request);
			}else if("reassignSupervisorUser".equals(method)){	
				
				return reassignSupervisorUser(conn, sessionHelper, context, mapping,eemWFForm, request);
			}else if("updateQueueUsers".equals(method)){	
				
				return updateQueueSpecificUsers(conn, sessionHelper, context, mapping,eemWFForm, request);
			}else if("updateQueueTotals".equals(method)){	
				
				return updateQueueTotals(conn, sessionHelper, context, mapping,eemWFForm, request);
			}else if("getAdminSummaryInfo".equals(method)){	
				
				return eemAdminSummary(conn, sessionHelper, context, mapping,eemWFForm, request);
			}else if("displaySupervisorDetail".equals(method)){	
				
				return displaySupervisorDetail(conn, sessionHelper, context, mapping,eemWFForm, request);
			}else if("updateQueueSpecificAdminUsers".equals(method)){	
				
				return updateQueueSpecificAdminUsers(conn, sessionHelper, context, mapping,eemWFForm, request);
			}else if("updateAdminQueueTotals".equals(method)){	
				
				return updateAdminQueueTotals(conn, sessionHelper, context, mapping,eemWFForm, request);
			}else if("updateAdminSupervisorUserInfo".equals(method)){	
				
				return updateAdminSupervisorUserInfo(conn, sessionHelper, context, mapping,eemWFForm, request);
			}else if("addNewUser".equals(method)){	
				
				return addNewUser(conn, sessionHelper, context, mapping,eemWFForm, request);
			}else if("reassignAdminSupervisorUser".equals(method)){	
				
				return reassignAdminSupervisorUser(conn, sessionHelper, context, mapping,eemWFForm, request);
			}else if("updateAdminSummaryQueueTotals".equals(method)){	
				
				return updateAdminSummaryQueueTotals(conn, sessionHelper, context, mapping,eemWFForm, request);
			}else if("addUsersToWorkflow".equals(method)){	
				
				return addUsersToWorkflow(conn, sessionHelper, context, mapping,eemWFForm, request);
			}else if("adminSupervisorUserDetailDisplay".equals(method)){	
				
				return eemWorkFlowAdminUserDetailDisplay(conn, sessionHelper, context, mapping,eemWFForm, request);
			}else if("returnToUserWorkflow".equals(method)){	
				
				
			}			
			/* Highmark 045 Workflow Iteration-2 Supervisor and Admin change ends   */
			EEMWorkFlowHelper.setVOToForm(workFlowVO, eemWFForm, sessionHelper);
			EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
			logger.info("WF PROCESS END -Millis- TIMESTAMP:: "+System.currentTimeMillis());			
			return mapping.findForward(EEMConstants.EEM_GROUP_WF);
	}//selectedMenu()	
	
	/* Highmark 045 Workflow Iteration-2 Supervisor and Admin  change starts   */	
	/**
	 * This method is used to add new user
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */
	public ActionForward addNewUser(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request)
				throws ApplicationException, SQLException {	
			
			EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
			wfMgr.addNewUser(conn,sessionHelper,context,eemWFForm);
			EEMWFCodeCache objCache = EEMWFCodeCache.getInstance(sessionHelper.getMfId());
			eemWFForm.setNewUserList(objCache.getNewUserList(sessionHelper.getMfId()));
			//Excellus Retro fix for workflow -Start
			eemWFForm.setNewAddSuprUserList(objCache.getAddSuprNewUserList(sessionHelper.getMfId()));
			//Excellus Retro fix for workflow -End
			eemWFForm.setSupervisorList(objCache.getSupervisorList(sessionHelper.getMfId()));
			eemWFForm.setAdminList(objCache.getAdminList(sessionHelper.getMfId()));
			
			return mapping.findForward(EEMConstants.EEM_WF_ADDUSER);
		}
	
	/**
	 * This method is used to get admin summary info.
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */
	public ActionForward addUsersToWorkflow(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request)
				throws ApplicationException, SQLException {
		EEMWFCodeCache objCache = EEMWFCodeCache.getInstance(sessionHelper.getMfId());
		eemWFForm.setNewUserList(objCache.getNewUserList(sessionHelper.getMfId()));
		//Excellus Retro fix for workflow -Start
		eemWFForm.setNewAddSuprUserList(objCache.getAddSuprNewUserList(sessionHelper.getMfId()));
		//Excellus Retro fix for workflow -End
		eemWFForm.setSupervisorList(objCache.getSupervisorList(sessionHelper.getMfId()));
		eemWFForm.setAdminList(objCache.getAdminList(sessionHelper.getMfId()));

			return mapping.findForward(EEMConstants.EEM_WF_ADDUSER);
		}
	
	
	/**
	 * This method is used to get admin summary info.
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */
	public ActionForward eemAdminSummary(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request)
				throws ApplicationException, SQLException {		   
			EEMWorkFLowVO eemWorkFLowVO =  context.getWorkFlowVO();	
			int row = eemWFForm.getSelectedQueSupervisorInfoRow();	
			
			EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);	
			EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
			wfMgr.getSuperviosrQueses(conn,sessionHelper,context,eemWFForm);	
			EEMWorkFlowDao eemWorkFlowDao = DaoFactory.getInstance().getEEMWorkFlowDao();	       
			List<EMWFSupQueuesUserCountVO> userCountVOs = eemWorkFlowDao.getSupervisorQueues(conn, 
					eemWorkFLowVO.getCustomerID(), eemWorkFLowVO.getUserID());		
			eemWFForm.setUserId(sessionHelper.getUserId());
			eemWFForm.setSupervisorName(eemWorkFlowDao.getLastFirstName(conn, sessionHelper.getUserId(), sessionHelper.getMfId()));	
			eemWFForm.setListSupervisorQueueInfos(userCountVOs);		
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
			EEMWFCodeCache objCache = EEMWFCodeCache.getInstance(sessionHelper.getMfId());
			eemWFForm.setListSupervisor(objCache.getListSupervisorOnly(sessionHelper.getMfId(), sessionHelper.getUserId()));
			eemWFForm.setUserLevel("1");
			return mapping.findForward(EEMConstants.EEM_WF_ADMINSUMMARY);
		}
	
	
	/**
	 * This method is used to get supervisor summary info.
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */
	public ActionForward updateAdminSummaryQueueTotals(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request)
				throws ApplicationException, SQLException {		   
			EEMWorkFLowVO eemWorkFLowVO =  context.getWorkFlowVO();	
			int row = eemWFForm.getSelectedQueSupervisorInfoRow();	
			
			EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
			EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
			wfMgr.getAdminSuperviosrQuesesAndUpdateTotals(conn,sessionHelper,context,eemWFForm, eemWFForm.getSelectedSupervisor());
			EEMWorkFlowDao eemWorkFlowDao = DaoFactory.getInstance().getEEMWorkFlowDao();	       
			List<EMWFSupQueuesUserCountVO> userCountVOs = eemWorkFlowDao.getSupervisorQueues(conn, 
					eemWorkFLowVO.getCustomerID(), sessionHelper.getUserId());		
			eemWFForm.setUserId(eemWFForm.getSelectedSupervisor());
			eemWFForm.setSupervisorName(eemWorkFlowDao.getLastFirstName(conn, eemWFForm.getSelectedSupervisor(), sessionHelper.getMfId()));	
			eemWFForm.setListSupervisorQueueInfos(userCountVOs);		
			eemWFForm.setSelectedQueSupervisorInfoRow(row);					
			EEMWFCodeCache objCache = EEMWFCodeCache.getInstance(sessionHelper.getMfId());	
			eemWFForm.setListSupervisor(objCache.getListSupervisorOnly(sessionHelper.getMfId(), sessionHelper.getUserId()));	
			return mapping.findForward(EEMConstants.EEM_WF_ADMINSUMMARY);
		}
	
	/**
	 * This method is used to get supervisor summary info.
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */
	@SuppressWarnings("static-access")
	public ActionForward displaySupervisorDetail(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request)
				throws ApplicationException, SQLException {		   
			EEMWorkFLowVO eemWorkFLowVO =  context.getWorkFlowVO();	
			//Excellus Retro fix for workflow -Start
			eemWFForm.setSelectedUsrSupervisorInfoRow(0);//added to fix logout error.
			//Excellus Retro fix for workflow -End
			int row = eemWFForm.getSelectedQueSupervisorInfoRow();	
			int rowUser = eemWFForm.getSelectedUsrSupervisorInfoRow();
			EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
			EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();			
			wfMgr.getAdminSupervisorQueses(conn,sessionHelper,context,eemWFForm, eemWFForm.getSelectedSupervisor());
			EEMWorkFlowDao eemWorkFlowDao = DaoFactory.getInstance().getEEMWorkFlowDao();	       
			List<EMWFSupQueuesUserCountVO> userCountVOs = eemWorkFlowDao.getSupervisorQueues(conn, 
					eemWorkFLowVO.getCustomerID(), eemWFForm.getSelectedSupervisor());		
			eemWFForm.setUserId(eemWFForm.getSelectedSupervisor());
			eemWFForm.setSupervisorName(eemWorkFlowDao.getLastFirstName(conn, eemWFForm.getSelectedSupervisor(), sessionHelper.getMfId()));	
			eemWFForm.setListSupervisorQueueInfos(userCountVOs);		
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
			String queueCode = null;
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
				wfMgr.getSuperviosrUsers(conn,sessionHelper,context,eemWFForm, queueCode);
			List<EMWFSupervisorUserVO> userVOsList = eemWorkFlowDao.getSupervisorUsers(conn, 
						eemWorkFLowVO.getCustomerID(), eemWFForm.getSelectedSupervisor(), queueCode);	
			EEMWFCodeCache objCache = EEMWFCodeCache.getInstance(sessionHelper.getMfId());
			for(EMWFSupervisorUserVO emwfSupervisorUserVO : userVOsList){
				emwfSupervisorUserVO.setUserStatus(objCache.getUserStatus());
				emwfSupervisorUserVO.setPriorityMethod(objCache.getPriorityMethod());
				emwfSupervisorUserVO.setReassignmentType(objCache.getReassignmentType());
			}
			eemWFForm.setListSupervisor(objCache.getListSupervisorOnly(sessionHelper.getMfId(), sessionHelper.getUserId()));
			eemWFForm.setUserSupervisorAdminList(objCache.getUserSupervisorAdminList(sessionHelper.getMfId(), sessionHelper.getUserId()));
			eemWFForm.setListSupervisorUserInfosWithDisplay(userVOsList);
			eemWorkFLowVO.setListSupervisorUserInfos(userVOsList);
			eemWFForm.setListSupervisorUserInfos(userVOsList);	
			eemWFForm.setSelectedUsrSupervisorInfoRow(rowUser);	
			return mapping.findForward(EEMConstants.EEM_WF_ADMINWF);
		}
	
	/**
	 * This method is used to update queue details
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */
	@SuppressWarnings("static-access")
	public ActionForward updateQueueTotals(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request)
				throws ApplicationException, SQLException {		   	
			EEMWorkFLowVO eemWorkFLowVO =  context.getWorkFlowVO();	
			int row = eemWFForm.getSelectedQueSupervisorInfoRow();	
			int rowUser = eemWFForm.getSelectedUsrSupervisorInfoRow();
			EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
			EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
			wfMgr.getSuperviosrQuesesAndUpdateTotals(conn,sessionHelper,context,eemWFForm);
			EEMWorkFlowDao eemWorkFlowDao = DaoFactory.getInstance().getEEMWorkFlowDao();	       
			List<EMWFSupQueuesUserCountVO> userCountVOs = eemWorkFlowDao.getSupervisorQueues(conn, 
					eemWorkFLowVO.getCustomerID(), eemWorkFLowVO.getUserID());		
			eemWFForm.setUserId(sessionHelper.getUserId());
			eemWFForm.setSupervisorName(eemWorkFlowDao.getLastFirstName(conn, sessionHelper.getUserId(), sessionHelper.getMfId()));	
			eemWFForm.setListSupervisorQueueInfos(userCountVOs);		
			String queueCode = null;
			eemWFForm.setSelectedQueSupervisorInfoRow(row);				
				wfMgr.getSuperviosrUsers(conn,sessionHelper,context,eemWFForm, queueCode);
				List<EMWFSupervisorUserVO> userVOsList = eemWorkFlowDao.getSupervisorUsers(conn, 
						eemWorkFLowVO.getCustomerID(), eemWorkFLowVO.getUserID(), queueCode);	
				EEMWFCodeCache objCache = EEMWFCodeCache.getInstance(sessionHelper.getMfId());
				for(EMWFSupervisorUserVO emwfSupervisorUserVO : userVOsList){
					emwfSupervisorUserVO.setUserStatus(objCache.getUserStatus());
					emwfSupervisorUserVO.setPriorityMethod(objCache.getPriorityMethod());
					emwfSupervisorUserVO.setReassignmentType(objCache.getReassignmentType());
				}
				eemWFForm.setUserSupervisorList(objCache.getUserSupervisorList(sessionHelper.getMfId(), sessionHelper.getUserId()));
				eemWFForm.setListSupervisorUserInfosWithDisplay(userVOsList);
				eemWFForm.setListSupervisorUserInfos(userVOsList);	
				eemWFForm.setSelectedUsrSupervisorInfoRow(rowUser);	
			return mapping.findForward(EEMConstants.EEM_WF_SUPERVISOR);
		}	
	
	/**
	 * This method is used to update admin que details
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */
	@SuppressWarnings("static-access")
	public ActionForward updateAdminQueueTotals(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request)
				throws ApplicationException, SQLException {		   
			EEMWorkFLowVO eemWorkFLowVO =  context.getWorkFlowVO();	
			int row = eemWFForm.getSelectedQueSupervisorInfoRow();	
			int rowUser = eemWFForm.getSelectedUsrSupervisorInfoRow();
			EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
			EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
			wfMgr.getAdminSuperviosrQuesesAndUpdateTotals(conn,sessionHelper,context,eemWFForm, eemWFForm.getSelectedSupervisor());
			EEMWorkFlowDao eemWorkFlowDao = DaoFactory.getInstance().getEEMWorkFlowDao();	       
			List<EMWFSupQueuesUserCountVO> userCountVOs = eemWorkFlowDao.getSupervisorQueues(conn, 
					eemWorkFLowVO.getCustomerID(), eemWFForm.getSelectedSupervisor());		
			eemWFForm.setUserId(eemWFForm.getSelectedSupervisor());
			eemWFForm.setSupervisorName(eemWorkFlowDao.getLastFirstName(conn, eemWFForm.getSelectedSupervisor(), sessionHelper.getMfId()));	
			eemWFForm.setListSupervisorQueueInfos(userCountVOs);		
			String queueCode = null;
			eemWFForm.setSelectedQueSupervisorInfoRow(row);				
				wfMgr.getAdminSuperviosrUsers(conn,sessionHelper,context,eemWFForm, queueCode, eemWFForm.getSelectedSupervisor());
				List<EMWFSupervisorUserVO> userVOsList = eemWorkFlowDao.getSupervisorUsers(conn, 
						eemWorkFLowVO.getCustomerID(), eemWFForm.getSelectedSupervisor(), queueCode);	
				EEMWFCodeCache objCache = EEMWFCodeCache.getInstance(sessionHelper.getMfId());
				for(EMWFSupervisorUserVO emwfSupervisorUserVO : userVOsList){
					emwfSupervisorUserVO.setUserStatus(objCache.getUserStatus());
					emwfSupervisorUserVO.setPriorityMethod(objCache.getPriorityMethod());
					emwfSupervisorUserVO.setReassignmentType(objCache.getReassignmentType());
				}
				eemWFForm.setListSupervisor(objCache.getListSupervisorOnly(sessionHelper.getMfId(), sessionHelper.getUserId()));
				eemWFForm.setUserSupervisorAdminList(objCache.getUserSupervisorAdminList(sessionHelper.getMfId(), sessionHelper.getUserId()));
				eemWFForm.setListSupervisorUserInfosWithDisplay(userVOsList);
				eemWFForm.setListSupervisorUserInfos(userVOsList);	
				eemWFForm.setSelectedUsrSupervisorInfoRow(rowUser);	
			return mapping.findForward(EEMConstants.EEM_WF_ADMINWF);
		}
	
	/**
	 * This method is used to getsupervisor info.
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */
	@SuppressWarnings("static-access")
	public ActionForward eemWorkFlowSupervisor(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request)
				throws ApplicationException, SQLException {		   
			EEMWorkFLowVO eemWorkFLowVO =  context.getWorkFlowVO();	
			int row = eemWFForm.getSelectedQueSupervisorInfoRow();	
			int rowUser = eemWFForm.getSelectedUsrSupervisorInfoRow();
			EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
			EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
			wfMgr.getSuperviosrQueses(conn,sessionHelper,context,eemWFForm);
			EEMWorkFlowDao eemWorkFlowDao = DaoFactory.getInstance().getEEMWorkFlowDao();	       
			List<EMWFSupQueuesUserCountVO> userCountVOs = eemWorkFlowDao.getSupervisorQueues(conn, 
					eemWorkFLowVO.getCustomerID(), eemWorkFLowVO.getUserID());		
			eemWFForm.setUserId(sessionHelper.getUserId());
			eemWFForm.setSupervisorName(eemWorkFlowDao.getLastFirstName(conn, sessionHelper.getUserId(), sessionHelper.getMfId()));	
			eemWFForm.setListSupervisorQueueInfos(userCountVOs);		
			
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
			String queueCode = null;
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
				wfMgr.getSuperviosrUsers(conn,sessionHelper,context,eemWFForm, queueCode);
			List<EMWFSupervisorUserVO> userVOsList = eemWorkFlowDao.getSupervisorUsers(conn, 
						eemWorkFLowVO.getCustomerID(), eemWorkFLowVO.getUserID(), queueCode);	
			EEMWFCodeCache objCache = EEMWFCodeCache.getInstance(sessionHelper.getMfId());
			for(EMWFSupervisorUserVO emwfSupervisorUserVO : userVOsList){
				emwfSupervisorUserVO.setUserStatus(objCache.getUserStatus());
				emwfSupervisorUserVO.setPriorityMethod(objCache.getPriorityMethod());
				emwfSupervisorUserVO.setReassignmentType(objCache.getReassignmentType());
			}
			eemWFForm.setUserSupervisorList(objCache.getUserSupervisorList(sessionHelper.getMfId(), sessionHelper.getUserId()));
			eemWFForm.setListSupervisorUserInfosWithDisplay(userVOsList);
			eemWFForm.setListSupervisorUserInfos(userVOsList);	
			eemWFForm.setSelectedUsrSupervisorInfoRow(rowUser);	
			return mapping.findForward(EEMConstants.EEM_WF_SUPERVISOR);
		}
	
	/**
	 * This method is used to get selected queue from list
	 * @param holds workFlowVO object
	 */
	@SuppressWarnings("rawtypes")
	private void setQueueSelectFromList(EEMWorkFLowVO workFlowVO ){
		List queuesLst = workFlowVO.getListSupervisorQueueInfos();
		Iterator iter = queuesLst.iterator();
		while(iter.hasNext()){
			EMWFSupQueuesUserCountVO queVO = (EMWFSupQueuesUserCountVO)iter.next();
				if(null != workFlowVO.getSelectedQueueCode() 
						&& null != queVO.getQueueCode()){
				if(workFlowVO.getSelectedQueueCode().equalsIgnoreCase(queVO.getQueueCode())){
					queVO.setRowSelected("Y");
				}else{
					queVO.setRowSelected("");
				}
			}
		}//while		
	}
	
	/**
	 * This method is used to update que specific to user
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */
	@SuppressWarnings("static-access")
	public ActionForward updateQueueSpecificUsers(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request)
				throws ApplicationException, SQLException {	
			EEMWorkFLowVO eemWorkFLowVO =  context.getWorkFlowVO();	
			int row = eemWFForm.getSelectedQueSupervisorInfoRow();	
			int rowUser = eemWFForm.getSelectedUsrSupervisorInfoRow();
			EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
			eemWorkFLowVO.setSelectedQueueCode(eemWFForm.getSelectedQueueCode());
			this.setQueueSelectFromList(eemWorkFLowVO);
			List<EMWFSupQueuesUserCountVO> userCountVOs = eemWorkFLowVO.getListSupervisorQueueInfos();
			eemWFForm.setListSupervisorQueueInfos(userCountVOs);	
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
			eemWFForm.setSelectedUsrSupervisorInfoRow(rowUser);	
			EEMWorkFlowDao eemWorkFlowDao = DaoFactory.getInstance().getEEMWorkFlowDao();
			EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
			String queueCode = null;
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
			if(null != eemWFForm.getSelectedQueueCode()){
				queueCode = eemWFForm.getSelectedQueueCode();
			}		
				wfMgr.getSuperviosrUsers(conn,sessionHelper,context,eemWFForm, queueCode);
				List<EMWFSupervisorUserVO> userVOsList = eemWorkFlowDao.getSupervisorUsers(conn, 
						eemWorkFLowVO.getCustomerID(), eemWorkFLowVO.getUserID(), queueCode);	
				EEMWFCodeCache objCache = EEMWFCodeCache.getInstance(sessionHelper.getMfId());
				for(EMWFSupervisorUserVO emwfSupervisorUserVO : userVOsList){
					emwfSupervisorUserVO.setUserStatus(objCache.getUserStatus());
					emwfSupervisorUserVO.setPriorityMethod(objCache.getPriorityMethod());
					emwfSupervisorUserVO.setReassignmentType(objCache.getReassignmentType());
				}
				eemWFForm.setUserSupervisorList(objCache.getUserSupervisorList(sessionHelper.getMfId(), sessionHelper.getUserId()));
				eemWFForm.setSelectedUsrSupervisorInfoRow(0);	
				eemWFForm.setListSupervisorUserInfosWithDisplay(userVOsList);
				eemWFForm.setListSupervisorUserInfos(userVOsList);			
			return mapping.findForward(EEMConstants.EEM_WF_SUPERVISOR);
		}
	/**
	 * This method is used to update que specific to admin user
	 * @param conn holds the connection object	
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */	
	@SuppressWarnings("static-access")
	public ActionForward updateQueueSpecificAdminUsers(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request)
				throws ApplicationException, SQLException {	
			EEMWorkFLowVO eemWorkFLowVO =  context.getWorkFlowVO();
			int row = eemWFForm.getSelectedQueSupervisorInfoRow();	
			int rowUser = eemWFForm.getSelectedUsrSupervisorInfoRow();
			EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
			eemWorkFLowVO.setSelectedQueueCode(eemWFForm.getSelectedQueueCode());
			this.setQueueSelectFromList(eemWorkFLowVO);
			List<EMWFSupQueuesUserCountVO> userCountVOs = eemWorkFLowVO.getListSupervisorQueueInfos();
			eemWFForm.setListSupervisorQueueInfos(userCountVOs);	
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
			eemWFForm.setSelectedUsrSupervisorInfoRow(rowUser);	
			EEMWorkFlowDao eemWorkFlowDao = DaoFactory.getInstance().getEEMWorkFlowDao();
			EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
			String queueCode = null;
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
			if(null != eemWFForm.getSelectedQueueCode()){
				queueCode = eemWFForm.getSelectedQueueCode();
			}		
				wfMgr.getAdminSuperviosrUsers(conn,sessionHelper,context,eemWFForm, queueCode, eemWFForm.getSelectedSupervisor());
				List<EMWFSupervisorUserVO> userVOsList = eemWorkFlowDao.getSupervisorUsers(conn, 
						eemWorkFLowVO.getCustomerID(), eemWFForm.getSelectedSupervisor(), queueCode);	
				EEMWFCodeCache objCache = EEMWFCodeCache.getInstance(sessionHelper.getMfId());
				for(EMWFSupervisorUserVO emwfSupervisorUserVO : userVOsList){
					emwfSupervisorUserVO.setUserStatus(objCache.getUserStatus());
					emwfSupervisorUserVO.setPriorityMethod(objCache.getPriorityMethod());
					emwfSupervisorUserVO.setReassignmentType(objCache.getReassignmentType());
				}
				eemWFForm.setListSupervisor(objCache.getListSupervisorOnly(sessionHelper.getMfId(), sessionHelper.getUserId()));
				eemWFForm.setUserSupervisorAdminList(objCache.getUserSupervisorAdminList(sessionHelper.getMfId(), sessionHelper.getUserId()));
				eemWFForm.setSelectedUsrSupervisorInfoRow(row);	
				eemWFForm.setListSupervisorUserInfosWithDisplay(userVOsList);
				eemWFForm.setListSupervisorUserInfos(userVOsList);			
			return mapping.findForward(EEMConstants.EEM_WF_ADMINWF);
		}
	/**
	 * This method is used to get user details display 
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */	@SuppressWarnings("static-access")
	public ActionForward eemWorkFlowUserDetailDisplay(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request)
				throws ApplicationException, SQLException {	
			EEMWorkFLowVO eemWorkFLowVO =  context.getWorkFlowVO();
			int row = eemWFForm.getSelectedQueSupervisorInfoRow();	
			int rowUser = eemWFForm.getSelectedUsrSupervisorInfoRow();
			EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
			eemWorkFLowVO.setSelectedQueueCode(eemWFForm.getSelectedQueueCode());
			this.setQueueSelectFromList(eemWorkFLowVO);
			List<EMWFSupQueuesUserCountVO> userCountVOs = eemWorkFLowVO.getListSupervisorQueueInfos();
			eemWFForm.setListSupervisorQueueInfos(userCountVOs);	
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
			eemWFForm.setSelectedUsrSupervisorInfoRow(rowUser);				
			
			List<EMWFSupervisorUserVO> userVOsList = eemWorkFLowVO.getListSupervisorUserInfos();		
			EEMWFCodeCache objCache = EEMWFCodeCache.getInstance(sessionHelper.getMfId());
			for(EMWFSupervisorUserVO emwfSupervisorUserVO : userVOsList){
				emwfSupervisorUserVO.setUserStatus(objCache.getUserStatus());
				emwfSupervisorUserVO.setPriorityMethod(objCache.getPriorityMethod());
				emwfSupervisorUserVO.setReassignmentType(objCache.getReassignmentType());
			}
			eemWFForm.setUserSupervisorList(objCache.getUserSupervisorList(sessionHelper.getMfId(), sessionHelper.getUserId()));
			eemWFForm.setSelectedUsrSupervisorInfoRow(rowUser);	
			eemWFForm.setListSupervisorUserInfosWithDisplay(userVOsList);
			eemWFForm.setListSupervisorUserInfos(userVOsList);		
			return mapping.findForward(EEMConstants.EEM_WF_SUPERVISOR);
		}
	
		/**
		 * This method is used to get user details display 
		 * @param conn holds the connection object
		 * @param sessionHelper holds sessionHelper object
		 * @param context holds context object
		 * @param mapping holds ActionMapping object
		 * @param form holds ActionForm object
		 * @param request holds request object
		 * @return string value indicating which jsp to invoke
		 * @throws ApplicationException when code fails to execute
		 * @throws SQLException when sql fails to execute 
		 */	@SuppressWarnings("static-access")
	public ActionForward eemWorkFlowAdminUserDetailDisplay(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request)
				throws ApplicationException, SQLException {	
			EEMWorkFLowVO eemWorkFLowVO =  context.getWorkFlowVO();
			int row = eemWFForm.getSelectedQueSupervisorInfoRow();	
			int rowUser = eemWFForm.getSelectedUsrSupervisorInfoRow();
			EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
			eemWorkFLowVO.setSelectedQueueCode(eemWFForm.getSelectedQueueCode());
			this.setQueueSelectFromList(eemWorkFLowVO);
			List<EMWFSupQueuesUserCountVO> userCountVOs = eemWorkFLowVO.getListSupervisorQueueInfos();
			eemWFForm.setListSupervisorQueueInfos(userCountVOs);	
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
			eemWFForm.setSelectedUsrSupervisorInfoRow(rowUser);	
			List<EMWFSupervisorUserVO> userVOsList = eemWorkFLowVO.getListSupervisorUserInfos();		
			EEMWFCodeCache objCache = EEMWFCodeCache.getInstance(sessionHelper.getMfId());
			for(EMWFSupervisorUserVO emwfSupervisorUserVO : userVOsList){
				emwfSupervisorUserVO.setUserStatus(objCache.getUserStatus());
				emwfSupervisorUserVO.setPriorityMethod(objCache.getPriorityMethod());
				emwfSupervisorUserVO.setReassignmentType(objCache.getReassignmentType());
			}
			eemWFForm.setListSupervisor(objCache.getListSupervisorOnly(sessionHelper.getMfId(), sessionHelper.getUserId()));
			eemWFForm.setUserSupervisorAdminList(objCache.getUserSupervisorAdminList(sessionHelper.getMfId(), sessionHelper.getUserId()));
			//Fix for Jeff's workflow issue in HT
			eemWFForm.setSelectedUsrSupervisorInfoRow(rowUser);	
			eemWFForm.setListSupervisorUserInfosWithDisplay(userVOsList);
			eemWFForm.setListSupervisorUserInfos(userVOsList);		
			return mapping.findForward(EEMConstants.EEM_WF_ADMINWF);
		}
	
	/**
	 * This method is used to get user details display 
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */	
	@SuppressWarnings("static-access")
	public ActionForward reassignSupervisorUser(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request)
				throws ApplicationException, SQLException {	
			EEMWorkFLowVO eemWorkFLowVO =  context.getWorkFlowVO();
			
			int row = eemWFForm.getSelectedQueSupervisorInfoRow();			
			int rowUser = eemWFForm.getSelectedUsrSupervisorInfoRow();
			EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
			
			eemWorkFLowVO.setSelectedQueueCode(eemWFForm.getSelectedQueueCode());
			this.setQueueSelectFromList(eemWorkFLowVO);
			String queueCode = null;
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
			if(null != eemWFForm.getSelectedQueueCode()){
				queueCode = eemWFForm.getSelectedQueueCode();
			}
			EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
				wfMgr.reassignSupervisorUser(conn, sessionHelper, context, eemWFForm, queueCode);
			wfMgr.getSuperviosrQueses(conn,sessionHelper,context,eemWFForm);				
			EEMWorkFlowDao eemWorkFlowDao = DaoFactory.getInstance().getEEMWorkFlowDao();	       
			List<EMWFSupQueuesUserCountVO> userCountVOs = eemWorkFlowDao.getSupervisorQueues(conn, 
					eemWorkFLowVO.getCustomerID(), eemWorkFLowVO.getUserID());		
			eemWFForm.setUserId(sessionHelper.getUserId());
			eemWFForm.setSupervisorName(eemWorkFlowDao.getLastFirstName(conn, sessionHelper.getUserId(), sessionHelper.getMfId()));	
			eemWFForm.setListSupervisorQueueInfos(userCountVOs);		
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
			List<EMWFSupervisorUserVO> userVOsList = eemWorkFlowDao.getSupervisorUsers(conn, 
						eemWorkFLowVO.getCustomerID(), eemWorkFLowVO.getUserID(), queueCode);	
			EEMWFCodeCache objCache = EEMWFCodeCache.getInstance(sessionHelper.getMfId());
			for(EMWFSupervisorUserVO emwfSupervisorUserVO : userVOsList){
				emwfSupervisorUserVO.setUserStatus(objCache.getUserStatus());
				emwfSupervisorUserVO.setPriorityMethod(objCache.getPriorityMethod());
				emwfSupervisorUserVO.setReassignmentType(objCache.getReassignmentType());
			}	
			eemWFForm.setUserSupervisorList(objCache.getUserSupervisorList(sessionHelper.getMfId(), sessionHelper.getUserId()));
			eemWFForm.setSelectedUsrSupervisorInfoRow(rowUser);	
			eemWFForm.setListSupervisorUserInfosWithDisplay(userVOsList);
			eemWFForm.setListSupervisorUserInfos(userVOsList);		
			return mapping.findForward(EEMConstants.EEM_WF_SUPERVISOR);
		}
	
	/**
	 * This method is used to reassignAdminSupervisorUser
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */	
	@SuppressWarnings("static-access")
	public ActionForward reassignAdminSupervisorUser(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request)
				throws ApplicationException, SQLException {	
			EEMWorkFLowVO eemWorkFLowVO =  context.getWorkFlowVO();
			
			int row = eemWFForm.getSelectedQueSupervisorInfoRow();			
			int rowUser = eemWFForm.getSelectedUsrSupervisorInfoRow();
			EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
			eemWorkFLowVO.setSelectedQueueCode(eemWFForm.getSelectedQueueCode());
			this.setQueueSelectFromList(eemWorkFLowVO);
			String queueCode = null;
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
			if(null != eemWFForm.getSelectedQueueCode()){
				queueCode = eemWFForm.getSelectedQueueCode();
			}
			EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
				wfMgr.reassignAdminSupervisorUser(conn, sessionHelper, context, eemWFForm, queueCode, eemWFForm.getSelectedSupervisor());
			wfMgr.getAdminSupervisorQueses(conn,sessionHelper,context,eemWFForm, eemWFForm.getSelectedSupervisor());				
			EEMWorkFlowDao eemWorkFlowDao = DaoFactory.getInstance().getEEMWorkFlowDao();	       
			List<EMWFSupQueuesUserCountVO> userCountVOs = eemWorkFlowDao.getSupervisorQueues(conn, 
					eemWorkFLowVO.getCustomerID(), eemWFForm.getSelectedSupervisor());		
			eemWFForm.setUserId(eemWFForm.getSelectedSupervisor());
			eemWFForm.setSupervisorName(eemWorkFlowDao.getLastFirstName(conn, eemWFForm.getSelectedSupervisor(), sessionHelper.getMfId()));	
			eemWFForm.setListSupervisorQueueInfos(userCountVOs);		
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
			List<EMWFSupervisorUserVO> userVOsList = eemWorkFlowDao.getSupervisorUsers(conn, 
						eemWorkFLowVO.getCustomerID(), eemWFForm.getSelectedSupervisor(), queueCode);	
			EEMWFCodeCache objCache = EEMWFCodeCache.getInstance(sessionHelper.getMfId());
			for(EMWFSupervisorUserVO emwfSupervisorUserVO : userVOsList){
				emwfSupervisorUserVO.setUserStatus(objCache.getUserStatus());
				emwfSupervisorUserVO.setPriorityMethod(objCache.getPriorityMethod());
				emwfSupervisorUserVO.setReassignmentType(objCache.getReassignmentType());
			}	
			eemWFForm.setListSupervisor(objCache.getListSupervisorOnly(sessionHelper.getMfId(), sessionHelper.getUserId()));
			eemWFForm.setUserSupervisorAdminList(objCache.getUserSupervisorAdminList(sessionHelper.getMfId(), sessionHelper.getUserId()));
			eemWFForm.setSelectedUsrSupervisorInfoRow(rowUser);	
			eemWFForm.setListSupervisorUserInfosWithDisplay(userVOsList);
			eemWFForm.setListSupervisorUserInfos(userVOsList);		
			return mapping.findForward(EEMConstants.EEM_WF_ADMINWF);
		}
	
	/**
	 * This method is used to reassignAdminSupervisorUser
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */	
	
	@SuppressWarnings("static-access")
	public ActionForward updateSupervisorUserInfo(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request)
				throws ApplicationException, SQLException {	
		   
			context.setSelectedMenu(EEMConstants.MENU_WF);
			EEMWorkFLowVO eemWorkFLowVO =  context.getWorkFlowVO();
			int row = eemWFForm.getSelectedQueSupervisorInfoRow();			
			int rowUser = eemWFForm.getSelectedUsrSupervisorInfoRow();
			EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
			eemWorkFLowVO.setSelectedQueueCode(eemWFForm.getSelectedQueueCode());
			this.setQueueSelectFromList(eemWorkFLowVO);
			String queueCode = null;
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
			if(null != eemWFForm.getSelectedQueueCode()){
				queueCode = eemWFForm.getSelectedQueueCode();
			}
			EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
				wfMgr.supervisorUserInfoUpdate(conn, sessionHelper, context, eemWFForm, queueCode);
			wfMgr.getSuperviosrQueses(conn,sessionHelper,context,eemWFForm);			
			EEMWorkFlowDao eemWorkFlowDao = DaoFactory.getInstance().getEEMWorkFlowDao(); 
			List<EMWFSupQueuesUserCountVO> userCountVOs = eemWorkFlowDao.getSupervisorQueues(conn, 
					eemWorkFLowVO.getCustomerID(), eemWorkFLowVO.getUserID());		
			eemWFForm.setUserId(sessionHelper.getUserId());
			eemWFForm.setSupervisorName(eemWorkFlowDao.getLastFirstName(conn, sessionHelper.getUserId(), sessionHelper.getMfId()));	
			eemWFForm.setListSupervisorQueueInfos(userCountVOs);		
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
				eemWorkFLowVO.setSelectedQueueCode(eemWFForm.getSelectedQueueCode());
				this.setQueueSelectFromList(eemWorkFLowVO);	
				
			List<EMWFSupervisorUserVO> userVOsList = eemWorkFlowDao.getSupervisorUsers(conn, 
						eemWorkFLowVO.getCustomerID(), eemWorkFLowVO.getUserID(), queueCode);	
			EEMWFCodeCache objCache = EEMWFCodeCache.getInstance(sessionHelper.getMfId());
			
			for(EMWFSupervisorUserVO emwfSupervisorUserVO : userVOsList){
				emwfSupervisorUserVO.setUserStatus(objCache.getUserStatus());
				emwfSupervisorUserVO.setPriorityMethod(objCache.getPriorityMethod());
				emwfSupervisorUserVO.setReassignmentType(objCache.getReassignmentType());
			}
			eemWFForm.setUserSupervisorList(objCache.getUserSupervisorList(sessionHelper.getMfId(), sessionHelper.getUserId()));
			eemWFForm.setSelectedUsrSupervisorInfoRow(rowUser);	
			eemWFForm.setListSupervisorUserInfosWithDisplay(userVOsList);
			eemWFForm.setListSupervisorUserInfos(userVOsList);		
			
			return mapping.findForward(EEMConstants.EEM_WF_SUPERVISOR);
		}
	
	/**
	 * This method is used to reassignAdminSupervisorUser
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */	
	@SuppressWarnings("static-access")
	public ActionForward updateAdminSupervisorUserInfo(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request)
				throws ApplicationException, SQLException {	
			EEMWorkFLowVO eemWorkFLowVO =  context.getWorkFlowVO();
			
			int row = eemWFForm.getSelectedQueSupervisorInfoRow();			
			int rowUser = eemWFForm.getSelectedUsrSupervisorInfoRow();
			EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
			
			eemWorkFLowVO.setSelectedQueueCode(eemWFForm.getSelectedQueueCode());
			this.setQueueSelectFromList(eemWorkFLowVO);
			String queueCode = null;
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
			if(null != eemWFForm.getSelectedQueueCode()){
				queueCode = eemWFForm.getSelectedQueueCode();
			}
			EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
				wfMgr.adminSupervisorUserInfoUpdate(conn, sessionHelper, context, eemWFForm, queueCode, eemWFForm.getSelectedSupervisor());
			wfMgr.getAdminSupervisorQueses(conn,sessionHelper,context,eemWFForm, eemWFForm.getSelectedSupervisor());			
			EEMWorkFlowDao eemWorkFlowDao = DaoFactory.getInstance().getEEMWorkFlowDao(); 
			List<EMWFSupQueuesUserCountVO> userCountVOs = eemWorkFlowDao.getSupervisorQueues(conn, 
					eemWorkFLowVO.getCustomerID(), eemWorkFLowVO.getUserID());		
			eemWFForm.setUserId(eemWFForm.getSelectedSupervisor());
			eemWFForm.setSupervisorName(eemWorkFlowDao.getLastFirstName(conn, eemWFForm.getSelectedSupervisor(), sessionHelper.getMfId()));	
			eemWFForm.setListSupervisorQueueInfos(userCountVOs);		
			eemWFForm.setSelectedQueSupervisorInfoRow(row);	
				eemWorkFLowVO.setSelectedQueueCode(eemWFForm.getSelectedQueueCode());
				this.setQueueSelectFromList(eemWorkFLowVO);	
				
			List<EMWFSupervisorUserVO> userVOsList = eemWorkFlowDao.getSupervisorUsers(conn, 
						eemWorkFLowVO.getCustomerID(), eemWFForm.getSelectedSupervisor(), queueCode);	
			EEMWFCodeCache objCache = EEMWFCodeCache.getInstance(sessionHelper.getMfId());
			
			for(EMWFSupervisorUserVO emwfSupervisorUserVO : userVOsList){
				emwfSupervisorUserVO.setUserStatus(objCache.getUserStatus());
				emwfSupervisorUserVO.setPriorityMethod(objCache.getPriorityMethod());
				emwfSupervisorUserVO.setReassignmentType(objCache.getReassignmentType());
			}
			eemWFForm.setUserSupervisorAdminList(objCache.getUserSupervisorAdminList(sessionHelper.getMfId(), sessionHelper.getUserId()));
			eemWFForm.setListSupervisor(objCache.getListSupervisorOnly(sessionHelper.getMfId(), sessionHelper.getUserId()));
			eemWFForm.setSelectedUsrSupervisorInfoRow(rowUser);	
			eemWFForm.setListSupervisorUserInfosWithDisplay(userVOsList);
			eemWFForm.setListSupervisorUserInfos(userVOsList);		
			
			return mapping.findForward(EEMConstants.EEM_WF_ADMINWF);
		}
	
	/* Highmark 045 Workflow Iteration-2 Supervisor and Admin change ends   */
	
	/** Gets Search QueueName select list and Dashboard priorities data.
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param eemWFForm holds EEMWorkFlowForm object
	 * @param request holds request object
	 * @throws ApplicationException when code fails to execute
	 */
	private void userWorkFlowInit(Connection conn, SessionHelper sessionHelper, EEMContext context,
				ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request)
				throws ApplicationException{
		EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
		wfMgr.initUserWF(conn,sessionHelper,context,eemWFForm);
	}//userWorkFlowInit()
	
	
	/** //executes when clicked on Subset Activities button & gets Agreements list.
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param eemWFForm holds EEMWorkFlowForm object
	 * @param request holds request object
	 * @param move holds string value
	 * @throws ApplicationException when code fails to execute
	 */
	private void userSubsetAgreements(Connection conn, SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request, String move)
			throws ApplicationException{
		EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
		wfMgr.getUsrSubsetAgreements(conn, context, eemWFForm, move);
	}//userSubsetActivities()
	
	
	/** //--executes when clicked on GO button.
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param eemWFForm holds EEMWorkFlowForm object
	 * @param request holds request object
	 * @param move holds string value
	 * @throws ApplicationException when code fails to execute
	 */
	private void getSuprSelUsrData(Connection conn, EEMContext context, EEMWorkFlowForm eemWFForm, 
			EEMWorkFLowVO workFlowVO) throws ApplicationException{
		EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
		wfMgr.getSuprSelUsrData(conn, context, workFlowVO, eemWFForm, "first");		
	}//userSubsetActivities()
	
	
	/**
	 * This method used to save the search data
	 * @param workFlowVO holds EEMWorkFLowVO obj
	 * @param eemWFForm holds EEMWorkFlowForm obj
	 * @throws ApplicationException when code fails to execute
	 */
	private void saveUserSearchInput(EEMWorkFLowVO workFlowVO, EEMWorkFlowForm eemWFForm) 
			throws ApplicationException{
		workFlowVO.setUsrGetWrkQName(eemWFForm.getUsrGetWrkQName());
		workFlowVO.setUsrGetWrkQPrty(eemWFForm.getUsrGetWrkQPrty());
		workFlowVO.setUsrGetWrkQSrc(eemWFForm.getUsrGetWrkQSrc());
		workFlowVO.setUsrGetWrkQStatus(eemWFForm.getUsrGetWrkQStatus());		
	}//saveUserSearchInput()
	
	/**
	 * This method is used to get the user work
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param eemWFForm holds EEMWorkFlowForm object
	 * @param request holds request object
	 * @param move holds string value
	 * @throws ApplicationException when code fails to execute
	 */
	private void usergetWork(Connection conn, SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, HttpServletRequest request, String move)
			throws ApplicationException{
		EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
		wfMgr.getUsrWork(conn, sessionHelper, context, eemWFForm, move);
	}//usergetWork()
	/**
	 * This method is used to get the user priorities
	 * @param conn holds the connection object	
	 * @param eemWFForm holds EEMWorkFlowForm object
	 * @param workFlowVO holds workFlowVO object	
	 * @throws ApplicationException when code fails to execute
	 */
	private void getUserPrioritesData(Connection conn, EEMWorkFlowForm eemWFForm, EEMWorkFLowVO workFlowVO)
			throws ApplicationException{
		EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
		workFlowVO.setSuprSelectedUName(eemWFForm.getSuprSelectedUName());
		wfMgr.getUserPrioritiesData(conn, eemWFForm, workFlowVO);
	}//getUserPriorites()
	
	
	/**
	 * This method is used to search the user queues
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param eemWFForm holds EEMWorkFlowForm object
	 * @param request holds request object
	 * @param move holds string value
	 * @throws ApplicationException when code fails to execute
	 */
	private void userGWQueueSearch(Connection conn, SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, EEMWorkFLowVO workFlowVO, 
			HttpServletRequest request, String move) throws ApplicationException{
		
		EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
		workFlowVO.setUsrQueuesLst(null);
		workFlowVO.setUserAgreementId(eemWFForm.getUserAgreementId());
		workFlowVO.setUserQueueId(eemWFForm.getUserQueueId());
		wfMgr.getUserGWQueueSearch(conn, sessionHelper, context, eemWFForm, move);
	}//userGWQueueSearch()
	/**
	 * This method is used to get the user work
	 * @param conn holds the connection object	
	 * @param eemWFForm holds EEMWorkFlowForm object
	 * @param workFlowVO holds workFlowVO object	
	 * @param move holds string value
	 * @param saveInputData holds boolean value  
	 * @throws ApplicationException when code fails to execute
	 */
	private void getAdminHistoryDetails(Connection conn, EEMWorkFlowForm eemWFForm, EEMWorkFLowVO workFlowVO,
			String move, boolean saveInputData) throws ApplicationException{
		if(saveInputData){
			saveAdminHistSearchInput(workFlowVO, eemWFForm) ;
		}//if
		EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
		wfMgr.getAdminHistoryDetails(conn, eemWFForm, workFlowVO, move);
	}//userGWQueueSearch()
	/**
	 * 	
	 * @param workFlowVO holds workFlowVO object
	 * @param eemWFForm holds EEMWorkFlowForm object
	 */
	private void saveAdminHistSearchInput(EEMWorkFLowVO workFlowVO, EEMWorkFlowForm eemWFForm) 
			throws ApplicationException{	
		
		workFlowVO.setAdminHistDetSrchStartDt(eemWFForm.getAdminHistDetSrchStartDt());
		workFlowVO.setAdminHistDetSrchEndDt(eemWFForm.getAdminHistDetSrchEndDt());
		workFlowVO.setAdminSrchYear(eemWFForm.getAdminSrchYear());
		workFlowVO.setAdminSrchMonth(eemWFForm.getAdminSrchMonth());
		workFlowVO.setAdminSrchWeek(eemWFForm.getAdminSrchWeek());
		workFlowVO.setAdminSrchHistLvl(eemWFForm.getAdminSrchHistLvl());
		workFlowVO.setAdminSrchQName(eemWFForm.getAdminSrchQName());
		workFlowVO.setAdminSrchAdmin(eemWFForm.getAdminSrchAdmin());
		workFlowVO.setAdminSrchSuprv(eemWFForm.getAdminSrchSuprv());
		workFlowVO.setAdminSrchCompUsr(eemWFForm.getAdminSrchCompUsr());
		workFlowVO.setAdminSrchInitUsr(eemWFForm.getAdminSrchInitUsr());
		workFlowVO.setAdminSrchRiskInd(eemWFForm.getAdminSrchRiskInd());
		workFlowVO.setAdminSrchRiskRng(eemWFForm.getAdminSrchRiskRng());
		workFlowVO.setAdminSrchComplInd(eemWFForm.getAdminSrchComplInd());
		workFlowVO.setAdminSrchType(eemWFForm.getAdminSrchType());

	}//saveAdminHistSearchInput()	
	
	/**
	 * This method is used to search activities
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param eemWFForm holds EEMWorkFlowForm object
	 * @param workFlowVO holds workFlowVO object
	 * @param request holds request object
	 * @param move holds string value
	 * @throws ApplicationException when code fails to execute
	 */
	private void userGWActivitySearch(Connection conn, SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, EEMWorkFLowVO workFlowVO, 
			HttpServletRequest request, String move) throws ApplicationException{
		
		EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
		workFlowVO.setUsrActivitiesLst(null);
		workFlowVO.setUserAgreementId(eemWFForm.getUserAgreementId());
		workFlowVO.setUserQueueId(eemWFForm.getUserQueueId());
		wfMgr.getUserGWActivitySearch(conn, sessionHelper, context, eemWFForm, move);
	}//userGWActivitySearch()
	
	
	/**
	 * This method is used to clear all the activities list
	 * @param workFlowVO holds EEMWorkFLowVO obj
	 * @param eemWFForm holds EEMWorkFlowForm obj
	 * @throws ApplicationException when code fails to execute
	 */
	private void clearAgrQsActsLists(EEMWorkFLowVO workFlowVO, EEMWorkFlowForm eemWFForm) 
			throws ApplicationException{
		workFlowVO.setUsrAgreementsLst(null);
		workFlowVO.setUsrQueuesLst(null);
		workFlowVO.setUsrActivitiesLst(null);
		eemWFForm.setUsrAgreementsLst(null);
		eemWFForm.setUsrQueuesLst(null);
		eemWFForm.setUsrActivitiesLst(null);
	}//saveUserSearchInput()
	
	
	/**
	 * This method is used to clear the activites list
	 * @param workFlowVO holds EEMWorkFLowVO obj
	 * @param eemWFForm holds EEMWorkFlowForm obj
	 * @throws ApplicationException when code fails to execute
	 */
	private void clearActsLists(EEMWorkFLowVO workFlowVO, EEMWorkFlowForm eemWFForm) throws ApplicationException{
		workFlowVO.setUsrActivitiesLst(null);		
	}//clearActsLists()
	
	/**
	 * This method is used for Pagination when clicked on WorkFlow Menu.
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param eemWFForm holds EEMWorkFlowForm object
	 * @param request holds request object
	 * @param move holds string value
	 * @throws ApplicationException when code fails to execute
	 */
	private void usrGWMenuAgrPagination(Connection conn, EEMContext context, EEMWorkFlowForm eemWFForm, 
			String move) throws ApplicationException{
		EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
		wfMgr.getGWMenuAgrPagination(conn, context, eemWFForm, move);
	}//userGWAgrPagePrev()
	
	/**
	 * This method is used for Pagination when clicked on GO button upon selection of a user in drop down.
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param eemWFForm holds EEMWorkFlowForm object
	 * @param request holds request object
	 * @param move holds string value
	 * @throws ApplicationException when code fails to execute
	 */
	private void usrGoOptAgrPagination(Connection conn, EEMContext context, EEMWorkFlowForm eemWFForm, 
			String move) throws ApplicationException{
		EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
		wfMgr.getGoOptAgrPagination(conn, context, eemWFForm, move);
	}//userGWAgrPagePrev()
	
	/**
	 * This method is used for Pagination when clicked on SubsetActivities button.
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param eemWFForm holds EEMWorkFlowForm object
	 * @param request holds request object
	 * @param move holds string value
	 * @throws ApplicationException when code fails to execute
	 */
	private void usrSsActAgrPagination(Connection conn, EEMContext context, EEMWorkFlowForm eemWFForm, 
			String move) throws ApplicationException{
		EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
		wfMgr.getSsActAgrPagination(conn, context, eemWFForm, move);
	}//userGWAgrPagePrev()
	
	/**
	 * 045_HighMark_Queue Characteristics Start
	 */
	
	/**
	 * This method is used for queue char pagination
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */
	public ActionForward eemQueCharPage(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request,
			String move) throws ApplicationException, SQLException {
		
		EEMWorkFlowForm eemWorkFlowForm = (EEMWorkFlowForm) form;
		EEMWorkFLowVO filterVO = context.getWorkFlowVO();		
		EEMWorkFlowHelper.setFormToVO(eemWorkFlowForm, filterVO,
				sessionHelper);
		EEMQueCharDAO eemWorkFlowDao = new EEMQueCharDAO();           
		
		Pagination pagination = context.getQueCharPagination();
		if (pagination == null) {
			pagination = new Pagination();
			pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
			context.setQueCharPagination(pagination);
		}
		
		EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWorkFlowForm, sessionHelper);
		List<EEMQueCharVO> lstqueChar = eemWorkFlowDao.getQueCharInfos(conn ,sessionHelper.getMfId());	
		
		eemWorkFlowForm.setSelectedQueCharInfoRow(pagination.getSelectedLine());
		pagination.setListPaginationResults(move, lstqueChar);

		Integer newTop = (Integer) pagination.getFirstDetail();
		eemWorkFlowForm.setTopDisplayQueCharInfoRow(newTop.intValue());
		eemWorkFlowForm.setSelectedQueCharInfoRow(pagination.getSelectedLine());
		EEMWorkFlowHelper.setVOToForm(filterVO, eemWorkFlowForm,
				sessionHelper);	
		
		eemWorkFlowForm.setListQueCharInfosWithDisplay(lstqueChar);
		eemWorkFlowForm.setListQueCharInfos(lstqueChar);		
		request.setAttribute("eemWorkFlowForm", eemWorkFlowForm);
		request.setAttribute("arrQuePriority", eemWorkFlowForm.getArrQuePriority());
		
		return mapping.findForward(EEMConstants.EEM_WF_QUECHAR);

	}//eemQueCharPage()s
	
	/**
	 * This method is used for Queue Characteristics update functionality
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */
	public ActionForward eemQueCharUpdate(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)
				throws ApplicationException {
			
			EEMWorkFlowForm eemWFForm ;		
			if (!(form instanceof EEMWorkFlowForm)) {			
				eemWFForm = EEMWorkFlowHelper.getEEMWorkFlowForm(sessionHelper);
				if (eemWFForm == null) {
					eemWFForm = new EEMWorkFlowForm();				
				}
			}
			else{
				eemWFForm = (EEMWorkFlowForm) form;
			}
			EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
			
			EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();	
			wfMgr.queCharUpdate(conn, sessionHelper, context, eemWFForm);				
			request.setAttribute("eemWorkFlowForm", eemWFForm);
			return mapping.findForward(EEMConstants.EEM_WF_QUECHAR);
		}
	/**
	 * This method is used for getting queue char details
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */
	public ActionForward eemWorkFlowGetQueChar(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)
				throws ApplicationException, SQLException {	
		
		    EEMQueCharDAO eemWorkFlowDao = new EEMQueCharDAO();  
		   
			context.setSelectedMenu(EEMConstants.MENU_WF);
			
			EEMWorkFlowForm eemWFForm ;		
			if (!(form instanceof EEMWorkFlowForm)) {			
				eemWFForm = EEMWorkFlowHelper.getEEMWorkFlowForm(sessionHelper);
				if (eemWFForm == null) {
					eemWFForm = new EEMWorkFlowForm();				
				}
			}
			else{
				eemWFForm = (EEMWorkFlowForm) form;
			}
			EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
			eemWFForm.setUserGetWorkStatus("example");

			EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
			wfMgr.initQueChar(conn,sessionHelper,context,eemWFForm);
			
			request.setAttribute("eemWorkFlowForm", eemWFForm);
			sessionHelper.getSession().setAttribute("listQueCharInfos", eemWFForm.getListQueCharInfos());
			request.setAttribute("arrQuePriority", eemWFForm.getArrQuePriority());
			
			sessionHelper.getSession().setAttribute("eemWorkFlowForm", eemWFForm);
			sessionHelper.getSession().setAttribute("arrQuePriority", eemWFForm.getArrQuePriority());
			
			List<EEMQueCharVO> lstqueChar = eemWorkFlowDao.getQueCharInfos(conn ,sessionHelper.getMfId());
			eemWFForm.setListQueCharInfosWithDisplay(lstqueChar);
			eemWFForm.setListQueCharInfos(lstqueChar);			
			
			return mapping.findForward(EEMConstants.EEM_WF_QUECHAR);
		}
	/**
	 * 045_HighMark_Queue Characteristics End
	 */
	/**
	 * 045_UserList Start
	 */
	/**
	 * This method is used for getting show user list
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute
	 */
		public ActionForward eemWorkFlowGetUserList(Connection conn,
				SessionHelper sessionHelper, EEMContext context,
				ActionMapping mapping, ActionForm form, HttpServletRequest request)
					throws ApplicationException, SQLException {					
			List<EEMUserListVO> tempListUser = null;		   
				context.setSelectedMenu(EEMConstants.MENU_WF);			
				EEMWorkFlowForm eemWFForm ;		
				if (!(form instanceof EEMWorkFlowForm)) {			
					eemWFForm = EEMWorkFlowHelper.getEEMWorkFlowForm(sessionHelper);
					if (eemWFForm == null) {
						eemWFForm = new EEMWorkFlowForm();				
					}
				}
				else{
					eemWFForm = (EEMWorkFlowForm) form;
				}
				EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
				
				if(eemWFForm.getListUser() !=null){
								
				}else{
					eemWFForm.setListUserInfosWithDisplay(tempListUser);
					request.setAttribute("eemWorkFlowForm", eemWFForm);				
					sessionHelper.getSession().setAttribute("listUser", eemWFForm.getDisplayUserListInfo());				
				}		
				return mapping.findForward(EEMConstants.EEM_WF_USERLIST);
			}
		/**
		 * This method is used for show user search list
		 * @param conn holds the connection object
		 * @param sessionHelper holds sessionHelper object
		 * @param context holds context object
		 * @param mapping holds ActionMapping object
		 * @param form holds ActionForm object
		 * @param request holds request object
		 * @return string value indicating which jsp to invoke
		 * @throws ApplicationException when code fails to execute
		 * @throws SQLException when sql fails to execute 
		 */		
		 public ActionForward eemWorkFlowGetUserSearchList(Connection conn,
				SessionHelper sessionHelper, EEMContext context,
				ActionMapping mapping, ActionForm form, HttpServletRequest request)
					throws ApplicationException, SQLException {
			   	   
				context.setSelectedMenu(EEMConstants.MENU_WF);				 
				EEMWorkFlowForm eemWFForm ;		
				if (!(form instanceof EEMWorkFlowForm)) {			
					eemWFForm = EEMWorkFlowHelper.getEEMWorkFlowForm(sessionHelper);
					if (eemWFForm == null) {
						eemWFForm = new EEMWorkFlowForm();				
					}
				}
				else{
					eemWFForm = (EEMWorkFlowForm) form;
				}
				EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
				EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
				wfMgr.initUserList(conn,sessionHelper,context,eemWFForm);			
				request.setAttribute("eemWorkFlowForm", eemWFForm);
				return mapping.findForward(EEMConstants.EEM_WF_USERLIST);
			}
			/**
			 * This method is used for show user list update 
			 * @param conn holds the connection object
			 * @param sessionHelper holds sessionHelper object
			 * @param context holds context object
			 * @param mapping holds ActionMapping object
			 * @param form holds ActionForm object
			 * @param request holds request object
			 * @return string value indicating which jsp to invoke
			 * @throws ApplicationException when code fails to execute
			 * @throws SQLException when sql fails to execute 
			 */
			public ActionForward eemUserListUpdate(Connection conn,
					SessionHelper sessionHelper, EEMContext context,
					ActionMapping mapping, ActionForm form, HttpServletRequest request)
						throws ApplicationException, SQLException {	
				
					EEMWorkFlowForm  eemWFForm ;		
					if (!(form instanceof EEMWorkFlowForm)) {			
						eemWFForm = EEMWorkFlowHelper.getEEMWorkFlowForm(sessionHelper);
						if (eemWFForm == null) {
							eemWFForm = new EEMWorkFlowForm();				
						}
					}
					else{
						eemWFForm = (EEMWorkFlowForm) form;
					}
					EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
					
					EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();					
					wfMgr.userListUpdate(conn, sessionHelper, context, eemWFForm);				
					request.setAttribute("eemWorkFlowForm", eemWFForm);
					
					return mapping.findForward(EEMConstants.EEM_WF_USERLIST);
				}


			 /**
			 * This method is used for getting change assign activity list pagination
			 * @param conn holds the connection object
			 * @param sessionHelper holds sessionHelper object
			 * @param context holds context object
			 * @param mapping holds ActionMapping object
			 * @param form holds ActionForm object
			 * @param request holds request object
			 * @return string value indicating which jsp to invoke
			 * @throws ApplicationException when code fails to execute
			 * @throws SQLException when sql fails to execute 
			 */
			public ActionForward eemUserListPage(Connection conn,
					SessionHelper sessionHelper, EEMContext context,
					ActionMapping mapping, ActionForm form, HttpServletRequest request,
					String move) throws ApplicationException, SQLException {
				
				EEMWorkFlowForm eemWorkFlowForm = (EEMWorkFlowForm) form;
				EEMWorkFLowVO filterVO = context.getWorkFlowVO();		
				EEMWorkFlowHelper.setFormToVO(eemWorkFlowForm, filterVO,
						sessionHelper);
				EEMUserListDao eemUserListDao = new EEMUserListDao();           
				
				Pagination pagination = context.getUserListPagination();
				if (pagination == null) {
					pagination = new Pagination();
					pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);						
					context.setUserListPagination(pagination);
				}
				
				EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWorkFlowForm, sessionHelper);
				List<EEMUserListVO> lstUser = eemUserListDao.
						getUserListInfo(conn, filterVO)	;
				
				eemWorkFlowForm.setSelectedUserListInfoRow(pagination.getSelectedLine());
				pagination.setListPaginationResults(move, lstUser);

				Integer newTop = (Integer) pagination.getFirstDetail();
				eemWorkFlowForm.setTopDisplayUserListInfoRow(newTop.intValue());
				eemWorkFlowForm.setSelectedUserListInfoRow(pagination.getSelectedLine());
				EEMWorkFlowHelper.setVOToForm(filterVO, eemWorkFlowForm,
						sessionHelper);	
				
				eemWorkFlowForm.setListUserInfosWithDisplay(lstUser);
				eemWorkFlowForm.setListUser(lstUser);		
				request.setAttribute("eemWorkFlowForm", eemWorkFlowForm);
				
				return mapping.findForward(EEMConstants.EEM_WF_USERLIST);

			}

		/**
		 * 045_UserList End
		 */
		/**
		 * 045_AssignActivity Start
		 * 
		 */
		/**
		 * This method is used for getting change assign activity list
		 * @param conn holds the connection object
		 * @param sessionHelper holds sessionHelper object
		 * @param context holds context object
		 * @param mapping holds ActionMapping object
		 * @param form holds ActionForm object
		 * @param request holds request object
		 * @return string value indicating which jsp to invoke
		 * @throws ApplicationException when code fails to execute
		 * @throws SQLException when sql fails to execute
		 */
			public ActionForward getAssignActivityList(Connection conn,
					SessionHelper sessionHelper, EEMContext context,
					ActionMapping mapping, ActionForm form, HttpServletRequest request)
						throws ApplicationException, SQLException {				
				
				context.setSelectedMenu(EEMConstants.MENU_WF);	
				EEMWorkFLowVO workFlowVO = context.getWorkFlowVO();
				String supervisorId = null;
				String userLevel = null;
				EEMAssignActivityDao eemAssignActivityDao = new EEMAssignActivityDao();  
				EEMWorkFlowForm eemWFForm ;		
				if (!(form instanceof EEMWorkFlowForm)) {					
					eemWFForm = EEMWorkFlowHelper.getEEMWorkFlowForm(sessionHelper);
					if (eemWFForm == null) {
						eemWFForm = new EEMWorkFlowForm();				
					}
				}
				else{					
					eemWFForm = (EEMWorkFlowForm) form;
				}
				eemWFForm.setUserId(StringUtil.nonNullTrim(eemWFForm.getSuprSelectedUName()));
				eemWFForm.setCustomerID(workFlowVO.getCustomerID());
				userLevel = StringUtil.nonNullTrim(eemWFForm.getUserLevel());
				if(!userLevel.equals("") && userLevel.equalsIgnoreCase("1")){
				supervisorId = eemAssignActivityDao.getSupervisorId(conn, eemWFForm.getUserId(), eemWFForm.getCustomerID());
				eemWFForm.setSupervisorId(supervisorId);
				}
				
				EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);			
				
				EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
				wfMgr.initAssignActivityList(conn,sessionHelper,context,eemWFForm);			
				request.setAttribute("eemWorkFlowForm", eemWFForm);
		  		
				return mapping.findForward(EEMConstants.EEM_WF_ASSIGN_ACTIVITY_LIST);
						
			}

		/**
		 * This method is used for getting change assign activity search list
		 * @param conn holds the connection object
		 * @param sessionHelper holds sessionHelper object
		 * @param context holds context object
		 * @param mapping holds ActionMapping object
		 * @param form holds ActionForm object
		 * @param request holds request object
		 * @return string value indicating which jsp to invoke
		 * @throws ApplicationException when code fails to execute
		 * @throws SQLException when sql fails to execute 
		 */		
		 public ActionForward getAssignActivitySearchList(Connection conn,
				SessionHelper sessionHelper, EEMContext context,
				ActionMapping mapping, ActionForm form, HttpServletRequest request)
					throws ApplicationException, SQLException {
			   	   
				context.setSelectedMenu(EEMConstants.MENU_WF);	
				EEMWorkFlowForm eemWFForm ;		
				if (!(form instanceof EEMWorkFlowForm)) {			
					eemWFForm = EEMWorkFlowHelper.getEEMWorkFlowForm(sessionHelper);
					if (eemWFForm == null) {
						eemWFForm = new EEMWorkFlowForm();				
					}
				}
				else{
					eemWFForm = (EEMWorkFlowForm) form;
				}
				EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
				
				EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
				wfMgr.initAssignActivityList(conn,sessionHelper,context,eemWFForm);	
				request.setAttribute("eemWorkFlowForm", eemWFForm);
				
				return mapping.findForward(EEMConstants.EEM_WF_ASSIGN_ACTIVITY_LIST);
			}
		   /**
			 * This method is used for  change assign activity update
			 * @param conn holds the connection object
			 * @param sessionHelper holds sessionHelper object
			 * @param context holds context object
			 * @param mapping holds ActionMapping object
			 * @param form holds ActionForm object
			 * @param request holds request object
			 * @return string value indicating which jsp to invoke
			 * @throws ApplicationException when code fails to execute
			 * @throws SQLException when sql fails to execute 
			 */
			public ActionForward eemAssignActivityUpdate(Connection conn,
					SessionHelper sessionHelper, EEMContext context,
					ActionMapping mapping, ActionForm form, HttpServletRequest request)
						throws ApplicationException, SQLException {	
				
					EEMWorkFlowForm  eemWFForm ;		
					if (!(form instanceof EEMWorkFlowForm)) {			
						eemWFForm = EEMWorkFlowHelper.getEEMWorkFlowForm(sessionHelper);
						if (eemWFForm == null) {
							eemWFForm = new EEMWorkFlowForm();				
						}
					}
					else{
						eemWFForm = (EEMWorkFlowForm) form;
					}
					EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);						
					EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();						
					wfMgr.assignActivityUpdate(conn, sessionHelper, context, eemWFForm);
					request.setAttribute("eemWorkFlowForm", eemWFForm);
					
					return mapping.findForward(EEMConstants.EEM_WF_ASSIGN_ACTIVITY_LIST);
				}
			
			 /**
			 * This method is used for getting change assign activity list pagination
			 * @param conn holds the connection object
			 * @param sessionHelper holds sessionHelper object
			 * @param context holds context object
			 * @param mapping holds ActionMapping object
			 * @param form holds ActionForm object
			 * @param request holds request object
			 * @return string value indicating which jsp to invoke
			 * @throws ApplicationException when code fails to execute
			 * @throws SQLException when sql fails to execute 
			 */
			public ActionForward eemAssignActivityPage(Connection conn,
					SessionHelper sessionHelper, EEMContext context,
					ActionMapping mapping, ActionForm form, HttpServletRequest request,
					String move) throws ApplicationException, SQLException {
				
				EEMWorkFlowForm eemWorkFlowForm = (EEMWorkFlowForm) form;
				EEMWorkFLowVO filterVO = context.getWorkFlowVO();		
				EEMWorkFlowHelper.setFormToVO(eemWorkFlowForm, filterVO,
						sessionHelper);
				EEMAssignActivityDao eemAssignActivityDao = new EEMAssignActivityDao();           
				
				Pagination pagination = context.getAssignActivityPagination();
				if (pagination == null) {
					pagination = new Pagination();
					pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);						
					context.setAssignActivityPagination(pagination);
				}
				
				EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWorkFlowForm, sessionHelper);
				List<EEMAssignActivityVO> lstAssignActivity = eemAssignActivityDao.
						getAssignActivityListInfo(conn, filterVO)	;
				
				eemWorkFlowForm.setSelectedActivityListInfoRow(pagination.getSelectedLine());
				pagination.setListPaginationResults(move, lstAssignActivity);

				Integer newTop = (Integer) pagination.getFirstDetail();
				eemWorkFlowForm.setTopDisplayActListInfoRow(newTop.intValue());
				eemWorkFlowForm.setSelectedActivityListInfoRow(pagination.getSelectedLine());
				EEMWorkFlowHelper.setVOToForm(filterVO, eemWorkFlowForm,
						sessionHelper);	
				
				eemWorkFlowForm.setListActivityInfosWithDisplay(lstAssignActivity);
				eemWorkFlowForm.setListAssignActivity(lstAssignActivity);		
				request.setAttribute("eemWorkFlowForm", eemWorkFlowForm);
				
				return mapping.findForward(EEMConstants.EEM_WF_ASSIGN_ACTIVITY_LIST);

			}
		/**
		 * 045_AssignActivity end
		 */
	/**
	 * 045_AtRisk Changes start
	 */
	/**
	 * This method is used for getting At Risk info 
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */
	public ActionForward getAtRiskSummary(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)
				throws ApplicationException, SQLException {	
		
			context.setSelectedMenu(EEMConstants.MENU_WF);
				
			EEMWorkFlowForm eemWFForm ;		
			if (!(form instanceof EEMWorkFlowForm)) {			
				eemWFForm = EEMWorkFlowHelper.getEEMWorkFlowForm(sessionHelper);
				if (eemWFForm == null) {
					eemWFForm = new EEMWorkFlowForm();				
				}
			}
			else{
				eemWFForm = (EEMWorkFlowForm) form;
			}
			
			EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
			wfMgr.initAtRiskSummary(conn,sessionHelper,context,eemWFForm);					
			request.setAttribute("eemWorkFlowForm", eemWFForm);
			
			return mapping.findForward(EEMConstants.EEM_WF_AT_RISK);
		}
	/**
	 * This method is used for getting At Risk Detailsinfo 
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute 
	 */
	public ActionForward getAtRiskDetailsInfo(Connection conn, SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, EEMWorkFlowForm eemWFForm, EEMWorkFLowVO workFlowVO, 
			HttpServletRequest request, String move) throws ApplicationException{
		
			EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();					
			workFlowVO.setQueueCode(eemWFForm.getQueueCode());
			workFlowVO.setQueuePriority(eemWFForm.getQueuePriority());
			workFlowVO.setDaysLeft(eemWFForm.getDaysLeft());
			workFlowVO.setAtRiskRowCnt(eemWFForm.getAtRiskRowCnt());					
			wfMgr.getAtRiskDetails(conn, sessionHelper, context, eemWFForm, move);
			request.setAttribute("eemWorkFlowForm", eemWFForm);
		  return mapping.findForward(EEMConstants.EEM_WF_AT_RISK);
	}
	/**
	 * 045_AtRisk Changes End
	 */		
	/**
	 * CloseAssignActivity Starts
	 */
	/**
	 * This method is used for getting change assign activity list
	 * @param conn holds the connection object
	 * @param sessionHelper holds sessionHelper object
	 * @param context holds context object
	 * @param mapping holds ActionMapping object
	 * @param form holds ActionForm object
	 * @param request holds request object
	 * @return string value indicating which jsp to invoke
	 * @throws ApplicationException when code fails to execute
	 * @throws SQLException when sql fails to execute
	 */
		public ActionForward closeAssignActivityList(Connection conn,
				SessionHelper sessionHelper, EEMContext context,
				ActionMapping mapping, ActionForm form, HttpServletRequest request)
					throws ApplicationException, SQLException {			
			
			context.setSelectedMenu(EEMConstants.MENU_WF);	
			EEMWorkFLowVO workFlowVO = context.getWorkFlowVO();
			EEMWorkFlowForm eemWFForm ;		
			if (!(form instanceof EEMWorkFlowForm)) {					
				eemWFForm = EEMWorkFlowHelper.getEEMWorkFlowForm(sessionHelper);
				if (eemWFForm == null) {
					eemWFForm = new EEMWorkFlowForm();				
				}
			}
			else{					
				eemWFForm = (EEMWorkFlowForm) form;
			}
			eemWFForm.setCustomerID(workFlowVO.getCustomerID());
			eemWFForm.setLastName(StringUtil.nonNullTrim(eemWFForm.getHicNbr()));
			EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);			
			EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
			wfMgr.initAssignActivityList(conn,sessionHelper,context,eemWFForm);			
			request.setAttribute("eemWorkFlowForm", eemWFForm);	  		
			return mapping.findForward(EEMConstants.EEM_WF_CLOSE_ASSIGN_ACTIVITY_LIST);
					
		}
		/**
		 * This method is used for getting change assign activity search list
		 * @param conn holds the connection object
		 * @param sessionHelper holds sessionHelper object
		 * @param context holds context object
		 * @param mapping holds ActionMapping object
		 * @param form holds ActionForm object
		 * @param request holds request object
		 * @return string value indicating which jsp to invoke
		 * @throws ApplicationException when code fails to execute
		 * @throws SQLException when sql fails to execute 
		 */		
		 public ActionForward closeAssignActivitySearchList(Connection conn,
				SessionHelper sessionHelper, EEMContext context,
				ActionMapping mapping, ActionForm form, HttpServletRequest request)
					throws ApplicationException, SQLException {
			   	   
				context.setSelectedMenu(EEMConstants.MENU_WF);	
				EEMWorkFlowForm eemWFForm ;		
				if (!(form instanceof EEMWorkFlowForm)) {			
					eemWFForm = EEMWorkFlowHelper.getEEMWorkFlowForm(sessionHelper);
					if (eemWFForm == null) {
						eemWFForm = new EEMWorkFlowForm();				
					}
				}
				else{
					eemWFForm = (EEMWorkFlowForm) form;
				}
				EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);
				
				EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();
				wfMgr.initAssignActivityList(conn,sessionHelper,context,eemWFForm);	
				request.setAttribute("eemWorkFlowForm", eemWFForm);
				
				return mapping.findForward(EEMConstants.EEM_WF_CLOSE_ASSIGN_ACTIVITY_LIST);
			}
		 /**
			 * This method is used for  change assign activity update
			 * @param conn holds the connection object
			 * @param sessionHelper holds sessionHelper object
			 * @param context holds context object
			 * @param mapping holds ActionMapping object
			 * @param form holds ActionForm object
			 * @param request holds request object
			 * @return string value indicating which jsp to invoke
			 * @throws ApplicationException when code fails to execute
			 * @throws SQLException when sql fails to execute 
			 */
			public ActionForward eemCloseQueActivities(Connection conn,
					SessionHelper sessionHelper, EEMContext context,
					ActionMapping mapping, ActionForm form, HttpServletRequest request)
						throws ApplicationException, SQLException {	
				
					EEMWorkFlowForm  eemWFForm ;		
					if (!(form instanceof EEMWorkFlowForm)) {			
						eemWFForm = EEMWorkFlowHelper.getEEMWorkFlowForm(sessionHelper);
						if (eemWFForm == null) {
							eemWFForm = new EEMWorkFlowForm();				
						}
					}
					else{
						eemWFForm = (EEMWorkFlowForm) form;
					}
					EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWFForm, sessionHelper);						
					EEMWorkFlowManager wfMgr = new EEMWorkFlowManager();						
					wfMgr.closeQueActivities(conn, sessionHelper, context, eemWFForm);
					request.setAttribute("eemWorkFlowForm", eemWFForm);
					
					return mapping.findForward(EEMConstants.EEM_WF_CLOSE_ASSIGN_ACTIVITY_LIST);
				}
			/**
			 * This method is used for getting change assign activity list pagination
			 * @param conn holds the connection object
			 * @param sessionHelper holds sessionHelper object
			 * @param context holds context object
			 * @param mapping holds ActionMapping object
			 * @param form holds ActionForm object
			 * @param request holds request object
			 * @return string value indicating which jsp to invoke
			 * @throws ApplicationException when code fails to execute
			 * @throws SQLException when sql fails to execute 
			 */
			public ActionForward closeAssignActivityPage(Connection conn,
					SessionHelper sessionHelper, EEMContext context,
					ActionMapping mapping, ActionForm form, HttpServletRequest request,
					String move) throws ApplicationException, SQLException {
				
				EEMWorkFlowForm eemWorkFlowForm = (EEMWorkFlowForm) form;
				EEMWorkFLowVO filterVO = context.getWorkFlowVO();		
				EEMWorkFlowHelper.setFormToVO(eemWorkFlowForm, filterVO,
						sessionHelper);
				EEMAssignActivityDao eemAssignActivityDao = new EEMAssignActivityDao();           
				
				Pagination pagination = context.getAssignActivityPagination();
				if (pagination == null) {
					pagination = new Pagination();
					pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);						
					context.setAssignActivityPagination(pagination);
				}
				
				EEMWorkFlowHelper.setEEMWorkFlowFormList(eemWorkFlowForm, sessionHelper);
				List<EEMAssignActivityVO> lstAssignActivity = eemAssignActivityDao.
						getAssignActivityListInfo(conn, filterVO)	;
				
				eemWorkFlowForm.setSelectedActivityListInfoRow(pagination.getSelectedLine());
				pagination.setListPaginationResults(move, lstAssignActivity);

				Integer newTop = (Integer) pagination.getFirstDetail();
				eemWorkFlowForm.setTopDisplayActListInfoRow(newTop.intValue());
				eemWorkFlowForm.setSelectedActivityListInfoRow(pagination.getSelectedLine());
				EEMWorkFlowHelper.setVOToForm(filterVO, eemWorkFlowForm,
						sessionHelper);	
				
				eemWorkFlowForm.setListActivityInfosWithDisplay(lstAssignActivity);
				eemWorkFlowForm.setListAssignActivity(lstAssignActivity);		
				request.setAttribute("eemWorkFlowForm", eemWorkFlowForm);
				
				return mapping.findForward(EEMConstants.EEM_WF_CLOSE_ASSIGN_ACTIVITY_LIST);

			}
			/**
			 * CloseAssignActivity ends
			 */

}//class
