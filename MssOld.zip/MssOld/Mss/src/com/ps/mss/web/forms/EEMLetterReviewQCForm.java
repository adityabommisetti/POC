package com.ps.mss.web.forms;

import java.util.Collection;
import java.util.List;

import com.ps.mss.dao.model.EmCorrMbrVO;

public class EEMLetterReviewQCForm extends EEMSubMenuForm {
	private String searchReqFromDate;
	private String searchReqToDate;
	private String searchBatchId;
	private String bacthId1;
	private String batchId;
	private String searchLetterName;
	private String description;
	private String changedLetterStatus;
	private boolean searchExpanded;
	private String letterName;	
	private List lstLetterNames;
	private List lstBatchId;
	private List listSearchResults;
	private String move;
	public String getMove() {
		return move;
	}
	public void setMove(String move) {
		this.move = move;
	}
	private int selectedSearchRow;
	private int topDisplay;
	private EmCorrMbrVO displayCorrMbr = new EmCorrMbrVO();
	
	
	public String getLetterName() {
		return letterName;
	}
	public void setLetterName(String letterName) {
		this.letterName = letterName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getBacthId1() {
		return bacthId1;
	}
	public void setBacthId1(String bacthId1) {
		this.bacthId1 = bacthId1;
	}
	public String getBatchId() {
		return batchId;
	}
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}
	public String getSearchReqFromDate() {
		return searchReqFromDate;
	}
	public void setSearchReqFromDate(String searchReqFromDate) {
		this.searchReqFromDate = searchReqFromDate;
	}
	public String getSearchReqToDate() {
		return searchReqToDate;
	}
	public void setSearchReqToDate(String searchReqToDate) {
		this.searchReqToDate = searchReqToDate;
	}
	public String getSearchBatchId() {
		return searchBatchId;
	}
	public void setSearchBatchId(String searchBatchId) {
		this.searchBatchId = searchBatchId;
	}
	public String getSearchLetterName() {
		return searchLetterName;
	}
	public void setSearchLetterName(String searchLetterName) {
		this.searchLetterName = searchLetterName;
	}
	public boolean isSearchExpanded() {
		return searchExpanded;
	}
	public void setSearchExpanded(boolean searchExpanded) {
		this.searchExpanded = searchExpanded;
	}
	public List getLstLetterNames() {
		return lstLetterNames;
	}
	public void setLstLetterNames(List lstLetterNames) {
		this.lstLetterNames = lstLetterNames;
	}
	public List getLstBatchId() {
		return lstBatchId;
	}
	public void setLstBatchId(List lstBatchId) {
		this.lstBatchId = lstBatchId;
	}
	public int getSelectedSearchRow() {
		return selectedSearchRow;
	}
	public void setSelectedSearchRow(int selectedSearchRow) {
		this.selectedSearchRow = selectedSearchRow;
	}
	public List getListSearchResults() {
		return listSearchResults;
	}
	public void setListSearchResults(List listSearchResults) {
		this.listSearchResults = listSearchResults;
	}
	public EmCorrMbrVO getDisplayCorrMbr() {
		return displayCorrMbr;
	}
	public void setDisplayCorrMbr(EmCorrMbrVO displayCorrMbr) {
		this.displayCorrMbr = displayCorrMbr;
	}
	public int getTopDisplay() {
		return topDisplay;
	}
	public void setTopDisplay(int topDisplay) {
		this.topDisplay = topDisplay;
	}
	public String getChangedLetterStatus() {
		return changedLetterStatus;
	}
	public void setChangedLetterStatus(String changedLetterStatus) {
		this.changedLetterStatus = changedLetterStatus;
	}
	//IFOX - 430896 LTr QC CR : start
	private String [] letterQCCheck;
	/**
	 * @return the letterQCCheck
	 */
	public String[] getLetterQCCheck() {
		return letterQCCheck;
	}
	/**
	 * @param letterQCCheck the letterQCCheck to set
	 */
	public void setLetterQCCheck(String[] letterQCCheck) {
		this.letterQCCheck = letterQCCheck;
	}
	private String qcProfileInd;
	/**
	 * @return the qcProfileInd
	 */
	public String getQcProfileInd() {
		return qcProfileInd;
	}
	/**
	 * @param qcProfileInd the qcProfileInd to set
	 */
	public void setQcProfileInd(String qcProfileInd) {
		this.qcProfileInd = qcProfileInd;
	}
	
	private String searchType;
	private String searchId;
	/**
	 * @return the searchType
	 */
	public String getSearchType() {
		return searchType;
	}
	/**
	 * @param searchType the searchType to set
	 */
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	/**
	 * @return the searchId
	 */
	public String getSearchId() {
		return searchId;
	}
	/**
	 * @param searchId the searchId to set
	 */
	public void setSearchId(String searchId) {
		this.searchId = searchId;
	}
	
	
	//IFOX - 430896 LTr QC CR : end
 }
