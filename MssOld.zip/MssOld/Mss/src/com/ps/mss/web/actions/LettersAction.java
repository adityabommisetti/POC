package com.ps.mss.web.actions;

import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ps.mss.web.forms.LettersForm;
import com.ps.mss.web.helper.LettersActionDispatchHelper;
import com.ps.mss.web.helper.SessionHelper;

import com.ps.mss.security.SessionManager;
import com.ps.logger.LoggerConstants;
import com.ps.mss.db.DbConnWeb;
import com.ps.mss.db.MfIdSiteIdPersistence;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.framework.LettersConstants;
import com.ps.mss.helper.ServiceHelper;
import com.ps.mss.manager.LettersManager;
import com.ps.mss.model.LettersContext;
import com.ps.mss.model.LettersFilter;


/**
 * @author levin,alex
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class LettersAction extends Action {
	
	private static Logger logger=LoggerFactory.getLogger(LettersAction.class);

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		//log.println("Inside execute");
		LettersForm lettersForm = (LettersForm) form;
		String method = lettersForm.getMethod();
		String region = lettersForm.getRegion();
		Connection conn = null; boolean anyError = false;
		try {
			
			// use the default DB for security check
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = new SessionHelper(request);
			String errorMsg = sessionHelper.validateUser(conn);
			if (errorMsg != null) {
				request.setAttribute("Msg",errorMsg);
				logger.info(LoggerConstants.methodEndLevel());
				return mapping.findForward("lettersError");
			}
					
			LettersContext lc = LettersManager.getContext(sessionHelper.getSession(), region);
			LettersActionDispatchHelper.copyFromSessionToRequestLetters(lc, request, sessionHelper);
			
			//request.setAttribute(LettersConstants.LETTERS_CONTEXT, lc);
			lc.setReuseList(false);
			
			/*
			 * Everytime you reuse, it will just pull up the list from memory. 
			 */
			//if (LettersConstants.LETTERS_PAGE.equals(method))			
			//	 lc.setReuseList(true);
			
			String qadvDb = (String)sessionHelper.getAttribute(SessionManager.QADVDB);
			conn = DbConnWeb.reGetConnection(conn,qadvDb);
			logger.info(LoggerConstants.methodEndLevel());
			if ("initializeLettersPage".equals(method)) //entry point for Letters application
				return lettersDashboard(conn, lc, mapping, form, request, true, true);
			if ("lettersDashboard".equals(method))
				return lettersDashboard(conn, lc, mapping, form, request, true, false);
			if ("lettersPage".equals(method))
				return lettersPage(conn, lc, mapping, form, request, true);
			if ("lettersStatusUpdate".equals(method))
				return lettersStatusUpdate(conn, lc, mapping, form, request, true);
			if ("lettersGenerate".equals(method))
				return lettersGenerate(conn, lc, mapping, form, request);
			return mapping.findForward("lettersError");							
		} catch (Exception e) {
        	anyError = true;
        	request.setAttribute("Msg", e.getMessage());
        	logger.error(LoggerConstants.exceptionMessage(e.toString()));
        	//logger.error(e.getMessage());
        	logger.info(LoggerConstants.methodEndLevel());
        	return mapping.findForward("lettersError");
		}
		finally {
			if(conn != null){
				try {
					conn.close();
				} catch (SQLException e) {
		        	anyError = true;
				}
			}	
		}
    }

	private ActionForward lettersDashboard(Connection conn, LettersContext lc, ActionMapping mapping, ActionForm form, HttpServletRequest request, 
	          boolean searchMode, boolean initialize) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		LettersForm lettersForm = (LettersForm) form;
		LettersFilter filter = lc.getDashboardFilter();
		SessionHelper sessionHelper = new SessionHelper(request);
		
		if (initialize) { //The only time this is true is when Letters is selected from the main page.
			lc.init(lettersForm.getRegion());
			lettersForm.setStatus("LOADED");
			lettersForm.setMethod("lettersDashboard");
			String mfId = sessionHelper.getMfId();
			try {
				MfIdSiteIdPersistence mfSiteP = new MfIdSiteIdPersistence();
				String siteId = mfSiteP.getSiteId(conn,mfId,lc.getRegion());
				lc.setSiteId(siteId);
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				//logger.error(e.getMessage());
				throw new ApplicationException("Configuration Error");
			}
		}
		
		LettersActionDispatchHelper.getLettersDashboard(conn, request, lettersForm, lc, searchMode);
		logger.info(LoggerConstants.methodEndLevel());
		return buildForward(mapping, request, filter, LettersConstants.LETTERS_DASHBOARD);
	}
	
	private ActionForward lettersPage(Connection conn, LettersContext lc, ActionMapping mapping, ActionForm form, HttpServletRequest request, 
	          boolean searchMode) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		LettersForm lettersForm = (LettersForm) form;
		LettersFilter filter = lc.getLettersFilter();
		
		LettersActionDispatchHelper.saveExpandedItemsLetters(lc, lettersForm.getUiContext(), lettersForm.getPageName());
		lc.setListExpanded(true);
		lc.setDetailsExpanded(true);
		lc.setDataExpanded(true);
		
		LettersActionDispatchHelper.getLettersPage(conn, request, lettersForm, lc, searchMode);
		
		//lc.setDisplayLettersDetail(true); 	//this attribute is set to show Letter Details tab once user has visite this.
		logger.info(LoggerConstants.methodEndLevel());
		return buildForward(mapping, request, filter, LettersConstants.LETTERS_PAGE);
	}

	private ActionForward lettersStatusUpdate(Connection conn, LettersContext lc, ActionMapping mapping, ActionForm form, HttpServletRequest request, 
	          boolean searchMode) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		LettersForm lettersForm = (LettersForm) form;
		LettersFilter statusFilter = lc.getStatusFilter();
		SessionHelper sessionHelper = new SessionHelper(request);
		
        if ("tab".equals(lettersForm.getSearchType())) {
        	LettersFilter detailFilter = lc.getLettersFilter();
        	
        	statusFilter.setMemberId(detailFilter.getMemberId());
        	statusFilter.setSupplementalId(detailFilter.getSupplementalId());
        	statusFilter.setRequestor(detailFilter.getRequestor());
        	statusFilter.setLetterNbr(detailFilter.getLetterNbr());
        	statusFilter.setFileId(detailFilter.getFileId());
        	
        	statusFilter.setRequestDateFrom(detailFilter.getRequestDateFrom());
        	statusFilter.setRequestDateTo(detailFilter.getRequestDateTo());
        	
        	statusFilter.setStatus(detailFilter.getStatus());
        	statusFilter.setDeleteInd(detailFilter.getDeleteInd());
        	statusFilter.setStatusTo("");
        	statusFilter.setDeleteIndTo("");
        	
        }
        logger.info(LoggerConstants.methodEndLevel());
		return buildForward(mapping, request, statusFilter, LettersConstants.LETTERS_STATUS);
	}

	private ActionForward lettersGenerate(Connection conn, LettersContext lc, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		return mapping.findForward(LettersConstants.LETTERS_GENERATE);
	}
	
	private ActionForward buildForward(ActionMapping mapping, HttpServletRequest request, LettersFilter filter, String forwardName) {
		logger.info(LoggerConstants.methodStartLevel());
		if(request.getParameter("print") !=  null) {
			StringBuffer s = ServiceHelper.getLettersPrintCriteriaHeader(filter, forwardName);
			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, s.toString());
			forwardName = "print".concat(forwardName);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(forwardName);		
	}
}
