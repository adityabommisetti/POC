/*
 * $Id: EEMBillingHelper.java,v 1.2 2016/08/21 23:16:44 dinesh Exp $
 */
package com.ps.mss.web.helper;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.model.EmBBBDraftHeaderVO;
import com.ps.mss.dao.model.EmBBBInvoiceHeaderVO;
import com.ps.mss.dao.model.EmBBBPaymentsDetailVO;
import com.ps.mss.dao.model.EmBBBPaymentsHeaderVO;
import com.ps.mss.db.EEMCodeCache;
//Implementing DynaCache for performance :start
import com.ps.mss.dynaCache.EEMDynaCache;
//Implementing DynaCache for performance :end
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.web.forms.EEMBillDraftForm;
import com.ps.mss.web.forms.EEMBillInvoiceForm;
import com.ps.mss.web.forms.EEMBillMembPaymentsForm;
import com.ps.mss.web.forms.EEMBillPaymentsForm;
import com.ps.text.DateFormatter;
import com.ps.text.NumberFormatter;
import com.ps.util.NamedItem;
import com.ps.util.StringUtil;


public class EEMBillingHelper {
	private static Logger logger=LoggerFactory.getLogger(EEMBillingHelper.class);
	public static void clearInvoiceForm(EEMBillInvoiceForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		form.setSearchInvoiceNbr("");
		form.setSearchInvoiceId("");
		form.setSearchInvoiceStatus("");
		form.setSearchLastName("");
		form.setSearchHicNbr("");
		form.setSearchInvoiceGroup("M");
		form.setSearchInvoiceType("BM");
		
		form.setSearchExpanded(false);
		form.setSelectedSearchRow(0);
		
		form.setListSearchResults(null);
		form.setDisplayInvoiceHeader(new EmBBBInvoiceHeaderVO());
		logger.info(LoggerConstants.methodEndLevel());
	}
	public static void clearPaymentsForm(EEMBillPaymentsForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		form.setSearchPaySource("");
		form.setSearchExpanded(false);
		form.setSelectedSearchRow(0);
		
		form.setListSearchResults(null);
		//form.setDisplayInvoiceHeader(new EmBBBInvoiceHeaderVO());
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void clearMembPaymentsForm(EEMBillMembPaymentsForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		form.setSearchPaySource("");
		form.setDetailListExpanded(false);
		form.setSelectedDetailRow(0);
		form.setListDetail(null);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void saveEEMFormInv(SessionHelper sessionHelper, EEMBillInvoiceForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		sessionHelper.setAttribute("SaveEEMBillInvoiceForm",form);
	}
	public static EEMBillInvoiceForm getEEMFormInv(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (EEMBillInvoiceForm)sessionHelper.getAttribute("SaveEEMBillInvoiceForm");
	}
	public static void saveEEMFormPay(SessionHelper sessionHelper, EEMBillPaymentsForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		sessionHelper.setAttribute("SaveEEMBillPaymentForm",form);
	}
	public static EEMBillPaymentsForm getEEMFormPay(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (EEMBillPaymentsForm)sessionHelper.getAttribute("SaveEEMBillPaymentForm");
	}
	public static void saveEEMFormMembPay(SessionHelper sessionHelper, EEMBillMembPaymentsForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		sessionHelper.setAttribute("SaveEEMBillMembPaymentForm",form);
	}
	public static EEMBillMembPaymentsForm getEEMFormMembPay(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (EEMBillMembPaymentsForm)sessionHelper.getAttribute("SaveEEMBillMembPaymentForm");
	}	
	public static void setInvoiceFormLists(EEMBillInvoiceForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		//Implementing DynaCache for performance :start
		//EEMCodeCache cc = EEMCodeCache.getInstance();
		EEMCodeCache cc = EEMDynaCache.getDynaCacheMap();
		
		//Implementing DynaCache for performance :end
		
		form.setLstInvoiceStatus(cc.getLstInvoiceStatus());
		form.setLstInvoiceGroup(cc.getLstInvoiceGroup());
		setInvoiceTypeList(form, cc);
		form.setLstRelatedInvoiceType(cc.getLstRelatedInvoiceType());
		logger.info(LoggerConstants.methodEndLevel());
	}
	private static void setInvoiceTypeList(EEMBillInvoiceForm form, EEMCodeCache cc) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String invGrp = StringUtil.nonNullTrim(form.getSearchInvoiceGroup());
		if (!invGrp.equals("")) {
			List lstRelInvType = (List)cc.getLstRelatedInvoiceType();
			for (int i = 0; i < lstRelInvType.size(); i++) {
				NamedItem ni = (NamedItem)lstRelInvType.get(i);
				if (invGrp.equals(ni.getName())) {
					form.setLstInvoiceType((List)ni.getItem());
				}
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	private static void setAccountTypeList(EEMBillDraftForm form, EEMCodeCache cc) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String accountType = StringUtil.nonNullTrim(form.getAccountType());
		if (!accountType.equals("")) {
			List lstaccountType = (List)cc.getLstAccountType();
			for (int i = 0; i < lstaccountType.size(); i++) {
				NamedItem ni = (NamedItem)lstaccountType.get(i);
				if (accountType.equals(ni.getName())) {
					form.setLstAccountType((List)ni.getItem());
				}
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
	}	
	
	public static void setPaymentsFormLists(EEMBillPaymentsForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		//Implementing DynaCache for performance :start
		//EEMCodeCache cc = EEMCodeCache.getInstance();
		EEMCodeCache cc = EEMDynaCache.getDynaCacheMap();
				
		//Implementing DynaCache for performance :end
		
		form.setLstPaySource(cc.getLstPaySource());
		form.setLstBatchBalance(cc.getArrYesNo());
		form.setLstDetailRows(getNewDetailRowList(form));
		// Set the search Batch Date
		String searchBatchDate = StringUtil.nonNullTrim(form.getSearchBatchDate()); 
		if (!searchBatchDate.equals("") && searchBatchDate.indexOf("/") == -1) {
			form.setSearchBatchDate(DateFormatter.reFormat(form.getSearchBatchDate(), DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	public static void setMembPaymentsFormLists(EEMBillMembPaymentsForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		//Implementing DynaCache for performance :start
				
		//EEMCodeCache cc = EEMCodeCache.getInstance();
		EEMCodeCache cc = EEMDynaCache.getDynaCacheMap();
				
		//Implementing DynaCache for performance :end
		
		form.setLstPaySource(cc.getLstPaySource());
		logger.info(LoggerConstants.methodEndLevel());
	}
	public static List getNewDetailRowList(EEMBillPaymentsForm eemForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String[] arrInvoiceId = eemForm.getInvoiceId();
		String[] arrCheckDate = eemForm.getCheckDate();
		String[] arrCheckNbr = eemForm.getCheckNbr();
		String[] arrPaymentAmt = eemForm.getPaymentAmt();
		
		if(arrInvoiceId == null || arrInvoiceId.length == 0) {
			logger.info(LoggerConstants.methodEndLevel());
			return null;
		}
		
		EmBBBPaymentsDetailVO detailVO = null;
		List lstDetailRow = new ArrayList();
		for(int i = 0; i < arrInvoiceId.length; i++) {
			detailVO = new EmBBBPaymentsDetailVO();
			detailVO.setInvoiceId(arrInvoiceId[i]);
			detailVO.setCheckDate(arrCheckDate[i]);
			detailVO.setCheckNbr(arrCheckNbr[i]);
			detailVO.setPaymentAmt(arrPaymentAmt[i]);
			
			lstDetailRow.add(detailVO);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return lstDetailRow;
	}
	public static void setNewDetailTotalAmt(EEMBillPaymentsForm eemForm, EmBBBPaymentsHeaderVO headerVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		List lstDetailRow = eemForm.getLstDetailRows();
		if (lstDetailRow != null && lstDetailRow.size() > 0) {
			double cnt = 0;
			for (int i = 0; i < lstDetailRow.size(); i++) {
				EmBBBPaymentsDetailVO detailVO = (EmBBBPaymentsDetailVO)lstDetailRow.get(i);
				if (!detailVO.getPaymentAmt().equals("")) {
					try {
						cnt += Double.parseDouble(detailVO.getPaymentAmt());
					} catch(Exception e) {
					}
				}
			}
			cnt = cnt + Double.parseDouble(headerVO.getDetailTotalAmt());
			headerVO.setDetailTotalAmt(NumberFormatter.formatDecimal2PlacesDelim(cnt));
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	public static void setDraftFormLists(EEMBillDraftForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		//Implementing DynaCache for performance :start
		//EEMCodeCache cc = EEMCodeCache.getInstance();
		EEMCodeCache cc = EEMDynaCache.getDynaCacheMap();
						
		//Implementing DynaCache for performance :end
		form.setLstDraftStatus(cc.getLstDraftStatus());
		form.setLstUpdDraftStatus(cc.getLstUpdDraftStatuses());
		form.setLstAccountType(cc.getLstAccountType());
		
		//setInvoiceTypeList(form, cc);
		//form.setLstRelatedInvoiceType(cc.getLstRelatedInvoiceType());
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static EEMBillDraftForm getEEMFormDraft(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (EEMBillDraftForm)sessionHelper.getAttribute("SaveEEMBillDraftForm");
	}
	
   public static void clearDraftForm(EEMBillDraftForm form) {
	   logger.info(LoggerConstants.methodStartLevel());
		form.setSearchInvoiceNbr("");
		form.setSearchInvoiceId("");
		form.setSearchDraftStatus("");
		form.setSearchLastName("");
		form.setSearchHicNbr("");
//		form.setSearchInvoiceGroup("M");
//		form.setSearchInvoiceType("BM");
		
		form.setSearchExpanded(false);
		form.setSelectedSearchRow(0);
		
		form.setListSearchResults(null);
		form.setDisplayInvoiceHeader(new EmBBBDraftHeaderVO());
		logger.info(LoggerConstants.methodEndLevel());
	} 
   
   public static void saveEEMFormDraft(SessionHelper sessionHelper, EEMBillDraftForm form) {
	   logger.info(LoggerConstants.methodStartLevel());
	   sessionHelper.setAttribute("SaveEEMBillDraftForm",form);
	   logger.info(LoggerConstants.methodEndLevel());
	}
	
}
