package com.ps.mss.web.forms;
import java.util.ArrayList;
import java.util.List;

import com.ps.mss.dao.model.EEMAssignActivityVO;
import com.ps.mss.dao.model.EEMQueCharVO;
import com.ps.mss.dao.model.EEMUserListVO;
import com.ps.mss.dao.model.EMWFQSummaryVO;
import com.ps.mss.dao.model.EMWFSupervisorUserVO;
import com.ps.util.ListBoxItem;
/**
 * 
 * @author Praveen new form created for workflow
 *
 */
public class EEMWorkFlowForm extends EEMForm{
	/**
	 * holds serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Holds customerID value
	 */
	private String customerID;	
	/**
	 * Holds topDisplay value
	 */
	private int topDisplay;
	/**
	 * Holds selectedWorkFlow value
	 */
	public int selectedWorkFlow;
	/**
	 * Holds userName value
	 */
	private String userName;
	/**
	 * Holds supervisorName value
	 */
    private String supervisorName;
    /**
	 * Holds userId value
	 */
	private String userId;
	/**
	 * Holds supervisorId value
	 */
    private String supervisorId;
    /**
	 * Holds userAccessLevel value
	 */
    private String userAccessLevel;
    /**
	 * Holds activityCnt value
	 */
    private int activityCnt;	
    /**
	 * Holds lstWorkFlow value
	 */
	@SuppressWarnings("rawtypes")
	private List lstWorkFlow;
	//Excellus Retro fix for workflow -Start
	/**
	 * holds newAddsupruserList
	 */
	@SuppressWarnings("rawtypes")
	private List newAddSuprUserList;
	private String[] selectedUserId;
	private String[] selectedManagerId;
	//Excellus Retro fix for workflow -End
	//--USER- START
		//--i/p
	/**
	 * Holds usrGetWrkQName value
	 */
	private String usrGetWrkQName;
	/**
	 * Holds usrGetWrkQPrty value
	 */
	private String usrGetWrkQPrty;
	/**
	 * Holds usrGetWrkQSrc value
	 */
	private String usrGetWrkQSrc;
	/**
	 * Holds usrGetWrkQStatus value
	 */
	private String usrGetWrkQStatus;
	/**
	 * Holds userAgreementId value
	 */
	private int userAgreementId;//user clicks on agreement from Agreement list to get Queue.
	/**
	 * Holds userQueueId value
	 */
	private int userQueueId;//user clicks on agreement from Queue list to get Activities.
	/**
	 * Holds hicNbr value
	 */
	private String hicNbr;//user clicks on agreement from Activities list to get Application screen.
	/**
	 * Holds srchAppOrMbrId value
	 */
	private String srchAppOrMbrId;//user clicks on agreement from Activities list to get Application screen.
	/**
	 * Holds screenId value
	 */
	private String screenId;
	/**
	 * Holds suprSelectedUName value
	 */
	private String suprSelectedUName;
	
		//--Both/Internal Usage
	/**
	 * Holds usrOptedAction value
	 */
	private String usrOptedAction;//holds which button/link user clicked on UI.
	/**
	 * Holds userLevel value
	 */
	private String userLevel;  //admin/Supervosor/User.
	
		//--o/p
	/**
	 * Holds popupMsg value
	 */
	private String popupMsg = "";
	/**
	 * Holds wfStatus value
	 */
	@SuppressWarnings("rawtypes")
	private List wfStatus;
	/**
	 * Holds wfSource value
	 */
	@SuppressWarnings("rawtypes")
	private List wfSource;
	/**
	 * Holds wfQPriority value
	 */
	@SuppressWarnings("rawtypes")
	private List wfQPriority;
	/**
	 * Holds wfUserQLst value
	 */
	@SuppressWarnings("rawtypes")
	private List wfUserQLst;
	/**
	 * Holds usrQPrity0Lst value
	 */
	@SuppressWarnings("rawtypes")
	private List usrQPrity0Lst;
	/**
	 * Holds usrQPrity1Lst value
	 */
	@SuppressWarnings("rawtypes")
	private List usrQPrity1Lst;
	/**
	 * Holds usrQPrity2Lst value
	 */
	@SuppressWarnings("rawtypes")
	private List usrQPrity2Lst;
	/**
	 * Holds usrQPrity3Lst value
	 */
	@SuppressWarnings("rawtypes")
	private List usrQPrity3Lst;
	/**
	 * Holds usrQPrity4Lst value
	 */
	@SuppressWarnings("rawtypes")
	private List usrQPrity4Lst;
	/**
	 * Holds usrQPrity5Lst value
	 */
	@SuppressWarnings("rawtypes")
	private List usrQPrity5Lst;
	/**
	 * Holds usrAgreementsLst value
	 */
	@SuppressWarnings("rawtypes")
	private List usrAgreementsLst;
	/**
	 * Holds usrQueuesLst value
	 */
	@SuppressWarnings("rawtypes")
	private List usrQueuesLst;
	/**
	 * Holds usrActivitiesLst value
	 */
	@SuppressWarnings("rawtypes")
	private List usrActivitiesLst;
	/**
	 * Holds usrsUnderSupervisorLst value
	 */
	@SuppressWarnings("rawtypes")
	private List usrsUnderSupervisorLst;//may not require.
	/**
	 * Holds usrsUnderSupListBoxLst value
	 */
	@SuppressWarnings("rawtypes")
	private List usrsUnderSupListBoxLst;
	/**
	 * Holds usrAgrmntLstPageNbr value
	 */
	private int usrAgrmntLstPageNbr;
	/**
	 * Holds usrAgrLstCurrPageType value
	 */
	private String usrAgrLstCurrPageType;
	//below dummy
	/**
	 * Holds userGetWorkStatus value
	 */
	private String userGetWorkStatus;
	
	
	//--USER- END
	//--ADMINHist- START
		//-- i/p
	private int adminSrchYear;
	private int adminSrchMonth;
	private int adminSrchWeek;
	private String adminSrchHistLvl;
	private String adminSrchQName;
	private String adminSrchAdmin;
	private String adminSrchSuprv;
	private String adminSrchCompUsr;
	private String adminSrchInitUsr;
	private String adminSrchRiskInd;
	private String adminSrchRiskRng;
	private String adminSrchComplInd;
	private String adminSrchType;
	private String adminHistDetSrchStartDt;
	private String adminHistDetSrchEndDt;
	
	
	@SuppressWarnings("rawtypes")
	private List adminHistYears = new ArrayList();
	private ListBoxItem[] adminHistMonths;
	private ListBoxItem[] adminHistWeeks;
	private ListBoxItem[] adminHistLvls;
	@SuppressWarnings("rawtypes")
	private List adminHistQNames = new ArrayList();
	@SuppressWarnings("rawtypes")
	private List adminHistAdmins = new ArrayList();
	@SuppressWarnings("rawtypes")
	private List adminHistSuprvs = new ArrayList();
	@SuppressWarnings("rawtypes")
	private List adminHistUsrs = new ArrayList();
	private ListBoxItem[] adminHistRiskInds;
	private ListBoxItem[] adminHIstRiskRngs;
	private ListBoxItem[] adminHistRiskCompls;
	private ListBoxItem[] adminHistSrchTypes;
	
		//-- o/p
	/**
	 * Holds adminHistDetailVO List.
	 */
	@SuppressWarnings("rawtypes")
	private List adminHistDetailLst;
	/**
	 * Holds adminHistDetailsPageNbr value
	 */
	private int adminHistDetailsPageNbr;
	/**
	 * Holds adminHistDetailsCurrPageType value
	 */
	private String adminHistDetailsCurrPageType;
	/**
	 * Holds adminHistDetailsPAgination Option value
	 */
	private String adminHistPageOpt;// will be first, next, prev
		
	//--ADMINHist- END
	
	
	/**
	 * 045_HighMark_Queue Characteristics Start
	 */
	/**
	 * holds listQueCharInfos value
	 */
	@SuppressWarnings("rawtypes")
	private List listQueCharInfos;	
	/**
	 * holds selectedQueCharInfoRow value
	 */
	private int selectedQueCharInfoRow;	
	/**
	 * holds queCharInfoDisplayState value
	 */
	private String queCharInfoDisplayState;
	/**
	 * holds topDisplayQueCharInfoRow value
	 */
	private int topDisplayQueCharInfoRow;
	/**
	 * holds displayQueCharInfo value
	 */
	private EEMQueCharVO displayQueCharInfo = new EEMQueCharVO();
	/**
	 * holds queCharChanged value
	 */
	private boolean queCharChanged;
	/**
	 * holds arrYesNo value
	 */
	private ListBoxItem [] arrYesNo;
	/**
	 * holds arrQuePriority value
	 */
	private ListBoxItem [] arrQuePriority;
	/**
	 * holds arrCreationFreq value
	 */
	private ListBoxItem [] arrCreationFreq;
	/**
	 * holds activityEditable value
	 */
	
	private String activityEditable;
	/**
	 * holds addToStatushistFlag value
	 */
	private String addToStatushistFlag;
	/**
	 * holds addToCommentsFlag value
	 */
	private String addToCommentsFlag;
	/**
	 * holds queueLvlReqInd value
	 */
	private String queueLvlReqInd;
	/**
	 * holds iffTriggerFlag value
	 */
	private String iffTriggerFlag;
	/**
	 * holds redistributionFlag value
	 */
	private String redistributionFlag;
	/**
	 * holds autoCreateActivity value
	 */
	private String autoCreateActivity;
	/**
	 * holds timerReqInd value
	 */
	private String timerReqInd;
	
	/**
	 * 045_HighMark_Queue Characteristics End
	 */   
	//045_UserList start
	/**
	 * holds listUser value
	 */
	private List<EEMUserListVO> listUser;
	/**
	 * holds displayUserListInfo value
	 */
	private EEMUserListVO displayUserListInfo = new EEMUserListVO();
	/**
	 * holds selectedUserListInfoRow value
	 */
	private int selectedUserListInfoRow;
	/**
	 * holds userListInfoDisplayState value
	 */
	private String userListInfoDisplayState;
	/**
	 * holds userListChanged value
	 */
	private boolean userListChanged;	
	/**
	 * holds topDisplayUserListInfoRow value
	 */
	private int topDisplayUserListInfoRow;
	/**
	 * holds listSupervisor value
	 */
	@SuppressWarnings("rawtypes")
	private List listSupervisor;
	/**
	 * holds firstName value
	 */
	private String firstName;
	/**
	 * holds lastName value
	 */
	private String lastName;
	/**
	 * holds changedSupId value
	 */
	private String changedSupId;
	/**
	 * holds activityCount value
	 */
	private int activityCount;
	/**
	 * holds listUserLevel value
	 */
	private ListBoxItem [] listUserLevel;
		
		//045_UserList end
	//------------------------------
	//045_AssignActivity start
	/**
	 * Holds listAssignActivity value
	 */
	private List<EEMAssignActivityVO> listAssignActivity;
	/**
	 * Holds displayActivityListInfo object
	 */
	private EEMAssignActivityVO displayActivityListInfo = new EEMAssignActivityVO();
	/**
	 * Holds selectedActivityListInfoRow value
	 */
	private int selectedActivityListInfoRow;
	/**
	 * Holds activityListInfoDisplayState value
	 */
	private String activityListInfoDisplayState;
	/**
	 * Holds activityListChanged value
	 */
	private boolean activityListChanged;
	/**
	 * Holds topDisplayActListInfoRow value
	 */
	private int topDisplayActListInfoRow;
	/**
	 * Holds listActivitySupervisor value
	 */
	@SuppressWarnings("rawtypes")
	private List listActivitySupervisor;
	/**
	 * Holds listActivityUser value
	 */
	@SuppressWarnings("rawtypes")
	private List listActivityUser;	
	/**
	 * Holds changedSuperId value
	 */
	private String changedSuperId;
	/**
	 * Holds searchUserId value
	 */
	private String searchUserId;
	private String navUserId;
	private String addType;
	
	
	//045_AssignActivity end
	/**
	 * 045_AtRisk Changes start
	 */
	/**
	 * Holds usrAgreementsLst value
	 */
	@SuppressWarnings("rawtypes")
	private List listAtRiskSummary;
	

	/**
	 * Holds usrAgreementsLst value
	 */
	@SuppressWarnings("rawtypes")
	private List listAtRiskDetails;
	 /**
	 * Holds value of queueCode
	 */
	private String queueCode;    

	/**
	 * Holds value of queuePriority
	 */
	private Integer queuePriority;
	private Integer daysLeft;
	private int atRiskRowCnt;	
	/**
	 * 045_AtRisk Changes end
	 */
	/**
	 * 045_HighMark_Queue Characteristics Start
	 */
	/**
	 * @return the activityEditable
	 */
	public String getActivityEditable() {
		return activityEditable;
	}
	/**
	 * @param activityEditable the activityEditable to set
	 */
	public void setActivityEditable(String activityEditable) {
		this.activityEditable = activityEditable;
	}
	/**
	 * 
	 * @return
	 */	
	@SuppressWarnings("rawtypes")
	public List getListQueCharInfos() {
		return listQueCharInfos;
	}
	/**
	 * 
	 * @param listQueCharInfos
	 */	
	
	@SuppressWarnings("rawtypes")
	public void setListQueCharInfos(List listQueCharInfos) {
		this.listQueCharInfos = listQueCharInfos;
	}
	/**
	 * 
	 * @param listQueCharInfos
	 */
	@SuppressWarnings("rawtypes")
	public void setListQueCharInfosWithDisplay(List listQueCharInfos) {
		this.listQueCharInfos = listQueCharInfos;
		if ((this.listQueCharInfos != null) && (this.listQueCharInfos.isEmpty() == false)) {
			this.displayQueCharInfo = (EEMQueCharVO) this.listQueCharInfos.get(selectedQueCharInfoRow);
		}
		else {
			this.displayQueCharInfo = new EEMQueCharVO();
		}
	}
	/**
	 * 
	 * @return
	 */
	public int getSelectedQueCharInfoRow() {
		return selectedQueCharInfoRow;
	}
	/**
	 * 
	 * @param selectedQueCharInfoRow
	 */
	public void setSelectedQueCharInfoRow(int selectedQueCharInfoRow) {
		this.selectedQueCharInfoRow = selectedQueCharInfoRow;
	}
	/**
	 * 
	 * @return
	 */
	public String getQueCharInfoDisplayState() {
		return queCharInfoDisplayState;
	}
	/**
	 * 
	 * @param queCharInfoDisplayState
	 */
	public void setQueCharInfoDisplayState(String queCharInfoDisplayState) {
		this.queCharInfoDisplayState = queCharInfoDisplayState;
	}
	/**
	 * 
	 * @return
	 */
	public int getTopDisplayQueCharInfoRow() {
		return topDisplayQueCharInfoRow;
	}
	/**
	 * 
	 * @param topDisplayQueCharInfoRow
	 */
	public void setTopDisplayQueCharInfoRow(int topDisplayQueCharInfoRow) {
		this.topDisplayQueCharInfoRow = topDisplayQueCharInfoRow;
	}
	/**
	 * 
	 * @return
	 */
	public EEMQueCharVO getDisplayQueCharInfo() {
		return displayQueCharInfo;
	}
	/**
	 * 
	 * @param displayQueCharInfo
	 */
	public void setDisplayQueCharInfo(EEMQueCharVO displayQueCharInfo) {
		this.displayQueCharInfo = displayQueCharInfo;
	}
	/**
	 * 
	 * @return
	 */
	public boolean isQueCharChanged() {
		return queCharChanged;
	}
	/**
	 * 
	 * @param queCharChanged
	 */
	public void setQueCharChanged(boolean queCharChanged) {
		this.queCharChanged = queCharChanged;
	}
	/**
	 * 
	 * @return
	 */
	public ListBoxItem[] getArrYesNo() {
		return arrYesNo;
	}
	/**
	 * 
	 * @param arrYesNo
	 */
	public void setArrYesNo(ListBoxItem[] arrYesNo) {
		this.arrYesNo = arrYesNo;
	}
	/**
	 * @return the addToStatushistFlag
	 */
	public String getAddToStatushistFlag() {
		return addToStatushistFlag;
	}
	/**
	 * @param addToStatushistFlag the addToStatushistFlag to set
	 */
	public void setAddToStatushistFlag(String addToStatushistFlag) {
		this.addToStatushistFlag = addToStatushistFlag;
	}
	/**
	 * @return the addToCommentsFlag
	 */
	public String getAddToCommentsFlag() {
		return addToCommentsFlag;
	}
	/**
	 * @param addToCommentsFlag the addToCommentsFlag to set
	 */
	public void setAddToCommentsFlag(String addToCommentsFlag) {
		this.addToCommentsFlag = addToCommentsFlag;
	}
	/**
	 * @return the queueLvlReqInd
	 */
	public String getQueueLvlReqInd() {
		return queueLvlReqInd;
	}
	/**
	 * @param queueLvlReqInd the queueLvlReqInd to set
	 */
	public void setQueueLvlReqInd(String queueLvlReqInd) {
		this.queueLvlReqInd = queueLvlReqInd;
	}
	/**
	 * @return the iffTriggerFlag
	 */
	public String getIffTriggerFlag() {
		return iffTriggerFlag;
	}
	/**
	 * @param iffTriggerFlag the iffTriggerFlag to set
	 */
	public void setIffTriggerFlag(String iffTriggerFlag) {
		this.iffTriggerFlag = iffTriggerFlag;
	}
	/**
	 * @return the redistributionFlag
	 */
	public String getRedistributionFlag() {
		return redistributionFlag;
	}
	/**
	 * @param redistributionFlag the redistributionFlag to set
	 */
	public void setRedistributionFlag(String redistributionFlag) {
		this.redistributionFlag = redistributionFlag;
	}
	/**
	 * @return the autoCreateActivity
	 */
	public String getAutoCreateActivity() {
		return autoCreateActivity;
	}
	/**
	 * @param autoCreateActivity the autoCreateActivity to set
	 */
	public void setAutoCreateActivity(String autoCreateActivity) {
		this.autoCreateActivity = autoCreateActivity;
	}
	/**
	 * @return the timerReqInd
	 */
	public String getTimerReqInd() {
		return timerReqInd;
	}
	/**
	 * @param timerReqInd the timerReqInd to set
	 */
	public void setTimerReqInd(String timerReqInd) {
		this.timerReqInd = timerReqInd;
	}
	/**
	 * @return the arrQuePriority
	 */
	public ListBoxItem[] getArrQuePriority() {
		return arrQuePriority;
	}
	/**
	 * @param arrQuePriority the arrQuePriority to set
	 */
	public void setArrQuePriority(ListBoxItem[] arrQuePriority) {
		this.arrQuePriority = arrQuePriority;
	}
	/**
	 * @return the arrCreationFreq
	 */
	public ListBoxItem[] getArrCreationFreq() {
		return arrCreationFreq;
	}
	/**
	 * @param arrCreationFreq the arrCreationFreq to set
	 */
	public void setArrCreationFreq(ListBoxItem[] arrCreationFreq) {
		this.arrCreationFreq = arrCreationFreq;
	}
	
	/**
	* 045_HighMark_Queue Characteristics End
	*/
	//045_UserList starts
		/**
		 * 
		 * @return
		 */
		public List<EEMUserListVO> getListUser() {
			return listUser;
		}
		/**
		 * 
		 * @param listUser
		 */
		public void setListUser(List<EEMUserListVO> listUser) {
			this.listUser = listUser;
		}
		/**
		 * 
		 * @param listUser
		 */
		public void setListUserInfosWithDisplay(List<EEMUserListVO> listUser) {
			this.listUser = listUser;
			
			if ((this.listUser != null) && (this.listUser.isEmpty() == false)) {
				
				this.displayUserListInfo = (EEMUserListVO) this.listUser.get(selectedUserListInfoRow);
			}
			else {
				this.displayUserListInfo = new EEMUserListVO();
			}
		}
		
		public int getSelectedUserListInfoRow() {
			return selectedUserListInfoRow;
		}
		/**
		 * 
		 * @param selectedUserListRow
		 */
		public void setSelectedUserListInfoRow(int selectedUserListInfoRow) {
			this.selectedUserListInfoRow = selectedUserListInfoRow;
		}
		/**
		 * @return the displayUserListInfo
		 */
		public EEMUserListVO getDisplayUserListInfo() {
			return displayUserListInfo;
		}
		/**
		 * @param displayUserListInfo the displayUserListInfo to set
		 */
		public void setDisplayUserListInfo(EEMUserListVO displayUserListInfo) {
			this.displayUserListInfo = displayUserListInfo;
		}
		/**
		 * @return the userListInfoDisplayState
		 */
		public String getUserListInfoDisplayState() {
			return userListInfoDisplayState;
		}
		/**
		 * @param userListInfoDisplayState the userListInfoDisplayState to set
		 */
		public void setUserListInfoDisplayState(String userListInfoDisplayState) {
			this.userListInfoDisplayState = userListInfoDisplayState;
		}
		/**
		 * @return the userListChanged
		 */
		public boolean isUserListChanged() {
			return userListChanged;
		}
		/**
		 * @param userListChanged the userListChanged to set
		 */
		public void setUserListChanged(boolean userListChanged) {
			this.userListChanged = userListChanged;
		}
		/**
		 * @return the topDisplayUserListInfoRow
		 */
		public int getTopDisplayUserListInfoRow() {
			return topDisplayUserListInfoRow;
		}
		/**
		 * @param topDisplayUserListInfoRow the topDisplayUserListInfoRow to set
		 */
		public void setTopDisplayUserListInfoRow(int topDisplayUserListInfoRow) {
			this.topDisplayUserListInfoRow = topDisplayUserListInfoRow;
		}
		/**
		 * @return the listSupervisor
		 */
		@SuppressWarnings("rawtypes")
		public List getListSupervisor() {
			return listSupervisor;
		}
		/**
		 * @param listSupervisor the listSupervisor to set
		 */
		@SuppressWarnings("rawtypes")
		public void setListSupervisor(List listSupervisor) {
			this.listSupervisor = listSupervisor;
		}
		/**
		 * @return the firstName
		 */
		public String getFirstName() {
			return firstName;
		}
		/**
		 * @param firstName the firstName to set
		 */
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		/**
		 * @return the lastName
		 */
		public String getLastName() {
			return lastName;
		}
		/**
		 * @param lastName the lastName to set
		 */
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		/**
		 * @return the activityCount
		 */
		public int getActivityCount() {
			return activityCount;
		}
		/**
		 * @param activityCount the activityCount to set
		 */
		public void setActivityCount(int activityCount) {
			this.activityCount = activityCount;
		}
		/**
		 * @return the listUserLevel
		 */
		public ListBoxItem[] getListUserLevel() {
			return listUserLevel;
		}
		/**
		 * @param listUserLevel the listUserLevel to set
		 */
		public void setListUserLevel(ListBoxItem[] listUserLevel) {
			this.listUserLevel = listUserLevel;
		}	
		/**
		 * @return the changedSupId
		 */
		public String getChangedSupId() {
			return changedSupId;
		}
		/**
		 * @param changedSupId the changedSupId to set
		 */
		public void setChangedSupId(String changedSupId) {
			this.changedSupId = changedSupId;
		}
		//045_UserList ends
		/**
		 * @return the customerID
		 */
		public String getCustomerID() {
			return customerID;
		}
		/**
		 * @param customerID the customerID to set
		 */
		public void setCustomerID(String customerID) {
			this.customerID = customerID;
		}
		/**
		 * @return the topDisplay
		 */
		public int getTopDisplay() {
			return topDisplay;
		}
		/**
		 * @param topDisplay the topDisplay to set
		 */
		public void setTopDisplay(int topDisplay) {
			this.topDisplay = topDisplay;
		}
		/**
		 * @return the selectedWorkFlow
		 */
		public int getSelectedWorkFlow() {
			return selectedWorkFlow;
		}
		/**
		 * @param selectedWorkFlow the selectedWorkFlow to set
		 */
		public void setSelectedWorkFlow(int selectedWorkFlow) {
			this.selectedWorkFlow = selectedWorkFlow;
		}
		/**
		 * @return the userName
		 */
		public String getUserName() {
			return userName;
		}
		/**
		 * @param userName the userName to set
		 */
		public void setUserName(String userName) {
			this.userName = userName;
		}
		/**
		 * @return the supervisorName
		 */
		public String getSupervisorName() {
			return supervisorName;
		}
		/**
		 * @param supervisorName the supervisorName to set
		 */
		public void setSupervisorName(String supervisorName) {
			this.supervisorName = supervisorName;
		}
		/**
		 * @return the userId
		 */
		public String getUserId() {
			return userId;
		}
		/**
		 * @param userId the userId to set
		 */
		public void setUserId(String userId) {
			this.userId = userId;
		}
		/**
		 * @return the supervisorId
		 */
		public String getSupervisorId() {
			return supervisorId;
		}
		/**
		 * @param supervisorId the supervisorId to set
		 */
		public void setSupervisorId(String supervisorId) {
			this.supervisorId = supervisorId;
		}
		/**
		 * @return the userAccessLevel
		 */
		public String getUserAccessLevel() {
			return userAccessLevel;
		}
		/**
		 * @param userAccessLevel the userAccessLevel to set
		 */
		public void setUserAccessLevel(String userAccessLevel) {
			this.userAccessLevel = userAccessLevel;
		}
		/**
		 * @return the activityCnt
		 */
		public int getActivityCnt() {
			return activityCnt;
		}
		/**
		 * @param activityCnt the activityCnt to set
		 */
		public void setActivityCnt(int activityCnt) {
			this.activityCnt = activityCnt;
		}
		/**
		 * @return the lstWorkFlow
		 */
		@SuppressWarnings("rawtypes")
		public List getLstWorkFlow() {
			return lstWorkFlow;
		}
		/**
		 * @param lstWorkFlow the lstWorkFlow to set
		 */
		@SuppressWarnings("rawtypes")
		public void setLstWorkFlow(List lstWorkFlow) {
			this.lstWorkFlow = lstWorkFlow;
		}
		/**
		 * @return the usrGetWrkQName
		 */
		public String getUsrGetWrkQName() {
			return usrGetWrkQName;
		}
		/**
		 * @param usrGetWrkQName the usrGetWrkQName to set
		 */
		public void setUsrGetWrkQName(String usrGetWrkQName) {
			this.usrGetWrkQName = usrGetWrkQName;
		}
		/**
		 * @return the usrGetWrkQPrty
		 */
		public String getUsrGetWrkQPrty() {
			return usrGetWrkQPrty;
		}
		/**
		 * @param usrGetWrkQPrty the usrGetWrkQPrty to set
		 */
		public void setUsrGetWrkQPrty(String usrGetWrkQPrty) {
			this.usrGetWrkQPrty = usrGetWrkQPrty;
		}
		/**
		 * @return the usrGetWrkQSrc
		 */
		public String getUsrGetWrkQSrc() {
			return usrGetWrkQSrc;
		}
		/**
		 * @param usrGetWrkQSrc the usrGetWrkQSrc to set
		 */
		public void setUsrGetWrkQSrc(String usrGetWrkQSrc) {
			this.usrGetWrkQSrc = usrGetWrkQSrc;
		}
		/**
		 * @return the usrGetWrkQStatus
		 */
		public String getUsrGetWrkQStatus() {
			return usrGetWrkQStatus;
		}
		/**
		 * @param usrGetWrkQStatus the usrGetWrkQStatus to set
		 */
		public void setUsrGetWrkQStatus(String usrGetWrkQStatus) {
			this.usrGetWrkQStatus = usrGetWrkQStatus;
		}
		/**
		 * @return the userAgreementId
		 */
		public int getUserAgreementId() {
			return userAgreementId;
		}
		/**
		 * @param userAgreementId the userAgreementId to set
		 */
		public void setUserAgreementId(int userAgreementId) {
			this.userAgreementId = userAgreementId;
		}
		/**
		 * @return the userQueueId
		 */
		public int getUserQueueId() {
			return userQueueId;
		}
		/**
		 * @param userQueueId the userQueueId to set
		 */
		public void setUserQueueId(int userQueueId) {
			this.userQueueId = userQueueId;
		}
		/**
		 * @return the hicNbr
		 */
		public String getHicNbr() {
			return hicNbr;
		}
		/**
		 * @param hicNbr the hicNbr to set
		 */
		public void setHicNbr(String hicNbr) {
			this.hicNbr = hicNbr;
		}
		/**
		 * @return the srchAppOrMbrId
		 */
		public String getSrchAppOrMbrId() {
			return srchAppOrMbrId;
		}
		/**
		 * @param srchAppOrMbrId the srchAppOrMbrId to set
		 */
		public void setSrchAppOrMbrId(String srchAppOrMbrId) {
			this.srchAppOrMbrId = srchAppOrMbrId;
		}
		/**
		 * @return the screenId
		 */
		public String getScreenId() {
			return screenId;
		}
		/**
		 * @param screenId the screenId to set
		 */
		public void setScreenId(String screenId) {
			this.screenId = screenId;
		}
		/**
		 * @return the usrOptedAction
		 */
		public String getUsrOptedAction() {
			return usrOptedAction;
		}
		/**
		 * @param usrOptedAction the usrOptedAction to set
		 */
		public void setUsrOptedAction(String usrOptedAction) {
			this.usrOptedAction = usrOptedAction;
		}
		/**
		 * @return the popupMsg
		 */
		public String getPopupMsg() {
			return popupMsg;
		}
		/**
		 * @param popupMsg the popupMsg to set
		 */
		public void setPopupMsg(String popupMsg) {
			this.popupMsg = popupMsg;
		}
		/**
		 * @return the wfStatus
		 */
		@SuppressWarnings("rawtypes")
		public List getWfStatus() {
			return wfStatus;
		}
		/**
		 * @param wfStatus the wfStatus to set
		 */
		@SuppressWarnings("rawtypes")
		public void setWfStatus(List wfStatus) {
			this.wfStatus = wfStatus;
		}
		/**
		 * @return the wfSource
		 */
		@SuppressWarnings("rawtypes")
		public List getWfSource() {
			return wfSource;
		}
		/**
		 * @param wfSource the wfSource to set
		 */
		@SuppressWarnings("rawtypes")
		public void setWfSource(List wfSource) {
			this.wfSource = wfSource;
		}
		/**
		 * @return the wfQPriority
		 */
		@SuppressWarnings("rawtypes")
		public List getWfQPriority() {
			return wfQPriority;
		}
		/**
		 * @param wfQPriority the wfQPriority to set
		 */
		@SuppressWarnings("rawtypes")
		public void setWfQPriority(List wfQPriority) {
			this.wfQPriority = wfQPriority;
		}
		/**
		 * @return the wfUserQLst
		 */
		@SuppressWarnings("rawtypes")
		public List getWfUserQLst() {
			return wfUserQLst;
		}
		/**
		 * @param wfUserQLst the wfUserQLst to set
		 */
		@SuppressWarnings("rawtypes")
		public void setWfUserQLst(List wfUserQLst) {
			this.wfUserQLst = wfUserQLst;
		}
		/**
		 * @return the usrQPrity0Lst
		 */
		@SuppressWarnings("rawtypes")
		public List getUsrQPrity0Lst() {
			return usrQPrity0Lst;
		}
		/**
		 * @param usrQPrity0Lst the usrQPrity0Lst to set
		 */
		@SuppressWarnings("rawtypes")
		public void setUsrQPrity0Lst(List usrQPrity0Lst) {
			this.usrQPrity0Lst = usrQPrity0Lst;
		}
		/**
		 * @return the usrQPrity1Lst
		 */
		@SuppressWarnings("rawtypes")
		public List getUsrQPrity1Lst() {
			return usrQPrity1Lst;
		}
		/**
		 * @param usrQPrity1Lst the usrQPrity1Lst to set
		 */
		@SuppressWarnings("rawtypes")
		public void setUsrQPrity1Lst(List usrQPrity1Lst) {
			this.usrQPrity1Lst = usrQPrity1Lst;
		}
		/**
		 * @return the usrQPrity2Lst
		 */
		@SuppressWarnings("rawtypes")
		public List getUsrQPrity2Lst() {
			return usrQPrity2Lst;
		}
		/**
		 * @param usrQPrity2Lst the usrQPrity2Lst to set
		 */
		@SuppressWarnings("rawtypes")
		public void setUsrQPrity2Lst(List usrQPrity2Lst) {
			this.usrQPrity2Lst = usrQPrity2Lst;
		}
		/**
		 * @return the usrQPrity3Lst
		 */
		@SuppressWarnings("rawtypes")
		public List getUsrQPrity3Lst() {
			return usrQPrity3Lst;
		}
		/**
		 * @param usrQPrity3Lst the usrQPrity3Lst to set
		 */
		@SuppressWarnings("rawtypes")
		public void setUsrQPrity3Lst(List usrQPrity3Lst) {
			this.usrQPrity3Lst = usrQPrity3Lst;
		}
		/**
		 * @return the usrQPrity4Lst
		 */
		@SuppressWarnings("rawtypes")
		public List getUsrQPrity4Lst() {
			return usrQPrity4Lst;
		}
		/**
		 * @param usrQPrity4Lst the usrQPrity4Lst to set
		 */
		@SuppressWarnings("rawtypes")
		public void setUsrQPrity4Lst(List usrQPrity4Lst) {
			this.usrQPrity4Lst = usrQPrity4Lst;
		}
		/**
		 * @return the usrQPrity5Lst
		 */
		@SuppressWarnings("rawtypes")
		public List getUsrQPrity5Lst() {
			return usrQPrity5Lst;
		}
		/**
		 * @param usrQPrity5Lst the usrQPrity5Lst to set
		 */
		@SuppressWarnings("rawtypes")
		public void setUsrQPrity5Lst(List usrQPrity5Lst) {
			this.usrQPrity5Lst = usrQPrity5Lst;
		}
		/**
		 * @return the usrAgreementsLst
		 */
		@SuppressWarnings("rawtypes")
		public List getUsrAgreementsLst() {
			return usrAgreementsLst;
		}
		/**
		 * @param usrAgreementsLst the usrAgreementsLst to set
		 */
		@SuppressWarnings("rawtypes")
		public void setUsrAgreementsLst(List usrAgreementsLst) {
			this.usrAgreementsLst = usrAgreementsLst;
		}
		/**
		 * @return the usrQueuesLst
		 */
		@SuppressWarnings("rawtypes")
		public List getUsrQueuesLst() {
			return usrQueuesLst;
		}
		/**
		 * @param usrQueuesLst the usrQueuesLst to set
		 */
		@SuppressWarnings("rawtypes")
		public void setUsrQueuesLst(List usrQueuesLst) {
			this.usrQueuesLst = usrQueuesLst;
		}
		/**
		 * @return the usrActivitiesLst
		 */
		@SuppressWarnings("rawtypes")
		public List getUsrActivitiesLst() {
			return usrActivitiesLst;
		}
		/**
		 * @param usrActivitiesLst the usrActivitiesLst to set
		 */
		@SuppressWarnings("rawtypes")
		public void setUsrActivitiesLst(List usrActivitiesLst) {
			this.usrActivitiesLst = usrActivitiesLst;
		}
		/**
		 * @return the usrAgrmntLstPageNbr
		 */
		public int getUsrAgrmntLstPageNbr() {
			return usrAgrmntLstPageNbr;
		}
		/**
		 * @param usrAgrmntLstPageNbr the usrAgrmntLstPageNbr to set
		 */
		public void setUsrAgrmntLstPageNbr(int usrAgrmntLstPageNbr) {
			this.usrAgrmntLstPageNbr = usrAgrmntLstPageNbr;
		}
		/**
		 * @return the usrAgrLstCurrPageType
		 */
		public String getUsrAgrLstCurrPageType() {
			return usrAgrLstCurrPageType;
		}
		/**
		 * @param usrAgrLstCurrPageType the usrAgrLstCurrPageType to set
		 */
		public void setUsrAgrLstCurrPageType(String usrAgrLstCurrPageType) {
			this.usrAgrLstCurrPageType = usrAgrLstCurrPageType;
		}
		/**
		 * @return the userGetWorkStatus
		 */
		public String getUserGetWorkStatus() {
			return userGetWorkStatus;
		}
		/**
		 * @param userGetWorkStatus the userGetWorkStatus to set
		 */
		public void setUserGetWorkStatus(String userGetWorkStatus) {
			this.userGetWorkStatus = userGetWorkStatus;
		}
		/**
		 * @return the userLevel
		 */
		public String getUserLevel() {
			return userLevel;
		}
		/**
		 * @param userLevel the userLevel to set
		 */
		public void setUserLevel(String userLevel) {
			this.userLevel = userLevel;
		}
		/**
         * 045_AssignActivity start
         */
		/**
		 * @return the listAssignActivity
		 */
		public List<EEMAssignActivityVO> getListAssignActivity() {
			return listAssignActivity;
		}
		/**
		 * @param listAssignActivity the listAssignActivity to set
		 */
		public void setListAssignActivity(List<EEMAssignActivityVO> listAssignActivity) {
			this.listAssignActivity = listAssignActivity;
		}
		/**
		 * @return the displayActivityListInfo
		 */
		public EEMAssignActivityVO getDisplayActivityListInfo() {
			return displayActivityListInfo;
		}
		/**
		 * @param displayActivityListInfo the displayActivityListInfo to set
		 */
		public void setDisplayActivityListInfo(
				EEMAssignActivityVO displayActivityListInfo) {
			this.displayActivityListInfo = displayActivityListInfo;
		}
		/**
		 * 
		 * @param listUser
		 */
		public void setListActivityInfosWithDisplay(List<EEMAssignActivityVO> listAssignActivity) {
			this.listAssignActivity = listAssignActivity;
			
			if ((this.listAssignActivity != null) && (this.listAssignActivity.isEmpty() == false)) {				
				this.displayActivityListInfo = (EEMAssignActivityVO) this.listAssignActivity.get(selectedActivityListInfoRow);
			}
			else {
				this.displayActivityListInfo = new EEMAssignActivityVO();
			}
		}
		/**
		 * @return the selectedActivityListInfoRow
		 */
		public int getSelectedActivityListInfoRow() {
			return selectedActivityListInfoRow;
		}
		/**
		 * @param selectedActivityListInfoRow the selectedActivityListInfoRow to set
		 */
		public void setSelectedActivityListInfoRow(int selectedActivityListInfoRow) {
			this.selectedActivityListInfoRow = selectedActivityListInfoRow;
		}
		/**
		 * @return the activityListInfoDisplayState
		 */
		public String getActivityListInfoDisplayState() {
			return activityListInfoDisplayState;
		}
		/**
		 * @param activityListInfoDisplayState the activityListInfoDisplayState to set
		 */
		public void setActivityListInfoDisplayState(String activityListInfoDisplayState) {
			this.activityListInfoDisplayState = activityListInfoDisplayState;
		}
		/**
		 * @return the activityListChanged
		 */
		public boolean isActivityListChanged() {
			return activityListChanged;
		}
		/**
		 * @param activityListChanged the activityListChanged to set
		 */
		public void setActivityListChanged(boolean activityListChanged) {
			this.activityListChanged = activityListChanged;
		}
		/**
		 * @return the topDisplayActListInfoRow
		 */
		public int getTopDisplayActListInfoRow() {
			return topDisplayActListInfoRow;
		}
		/**
		 * @param topDisplayActListInfoRow the topDisplayActListInfoRow to set
		 */
		public void setTopDisplayActListInfoRow(int topDisplayActListInfoRow) {
			this.topDisplayActListInfoRow = topDisplayActListInfoRow;
		}
		/**
		 * @return the listActivitySupervisor
		 */
		@SuppressWarnings("rawtypes")
		public List getListActivitySupervisor() {
			return listActivitySupervisor;
		}
		/**
		 * @param listActivitySupervisor the listActivitySupervisor to set
		 */
		@SuppressWarnings("rawtypes")
		public void setListActivitySupervisor(List listActivitySupervisor) {
			this.listActivitySupervisor = listActivitySupervisor;
		}
		/**
		 * @return the listActivityUser
		 */
		@SuppressWarnings("rawtypes")
		public List getListActivityUser() {
			return listActivityUser;
		}
		/**
		 * @param listActivityUser the listActivityUser to set
		 */
		@SuppressWarnings("rawtypes")
		public void setListActivityUser(List listActivityUser) {
			this.listActivityUser = listActivityUser;
		}
		/**
		 * @return the changedSuperId
		 */
		public String getChangedSuperId() {
			return changedSuperId;
		}
		/**
		 * @param changedSuperId the changedSuperId to set
		 */
		public void setChangedSuperId(String changedSuperId) {
			this.changedSuperId = changedSuperId;
		}
		
		private int selectedQueSupervisorInfoRow;
		private String queSupervisorInfoDisplayState;
		private int topDisplayQueSupervisorInfoRow;
		private boolean queSupervisorChanged;
		private String supDet;
		private int selectedUsrSupervisorInfoRow;
		private int topDisplayUsrSupervisorInfoRow;
		/**
		 * @return the selectedUsrSupervisorInfoRow
		 */
		public int getSelectedUsrSupervisorInfoRow() {
			return selectedUsrSupervisorInfoRow;
		}
		/**
		 * @param selectedUsrSupervisorInfoRow the selectedUsrSupervisorInfoRow to set
		 */
		public void setSelectedUsrSupervisorInfoRow(int selectedUsrSupervisorInfoRow) {
			this.selectedUsrSupervisorInfoRow = selectedUsrSupervisorInfoRow;
		}
		/**
		 * @return the topDisplayUsrSupervisorInfoRow
		 */
		public int getTopDisplayUsrSupervisorInfoRow() {
			return topDisplayUsrSupervisorInfoRow;
		}
		/**
		 * @param topDisplayUsrSupervisorInfoRow the topDisplayUsrSupervisorInfoRow to set
		 */
		public void setTopDisplayUsrSupervisorInfoRow(int topDisplayUsrSupervisorInfoRow) {
			this.topDisplayUsrSupervisorInfoRow = topDisplayUsrSupervisorInfoRow;
		}
		
		

		/**
		* @return the searchUserId
		*/
		public String getSearchUserId() {
		return searchUserId;
		}
		/**
		* @param searchUserId the searchUserId to set
		*/
		public void setSearchUserId(String searchUserId) {
		this.searchUserId = searchUserId;
		}

		/**
		 * @return the navUserId
		 */
		public String getNavUserId() {
			return navUserId;
		}
		/**
		 * @param navUserId the navUserId to set
		 */
		public void setNavUserId(String navUserId) {
			this.navUserId = navUserId;
		}
		/**
		 * 045_AssignActivity end
		 */
		/**
		 * @return the usrsUnderSupervisorLst
		 */
		@SuppressWarnings("rawtypes")
		public List getUsrsUnderSupervisorLst() {
			return usrsUnderSupervisorLst;
		}
		/**
		 * @param usrsUnderSupervisorLst the usrsUnderSupervisorLst to set
		 */
		@SuppressWarnings("rawtypes")
		public void setUsrsUnderSupervisorLst(List usrsUnderSupervisorLst) {
			this.usrsUnderSupervisorLst = usrsUnderSupervisorLst;
		}
		/**
		 * @return the suprSelectedUName
		 */
		public String getSuprSelectedUName() {
			return suprSelectedUName;
		}
		/**
		 * @param suprSelectedUName the suprSelectedUName to set
		 */
		public void setSuprSelectedUName(String suprSelectedUName) {
			this.suprSelectedUName = suprSelectedUName;
		}
		/**
		 * @return the usrsUnderSupListBoxLst
		 */
		@SuppressWarnings("rawtypes")
		public List getUsrsUnderSupListBoxLst() {
			return usrsUnderSupListBoxLst;
		}
		/**
		 * @param usrsUnderSupListBoxLst the usrsUnderSupListBoxLst to set
		 */
		@SuppressWarnings("rawtypes")
		public void setUsrsUnderSupListBoxLst(List usrsUnderSupListBoxLst) {
			this.usrsUnderSupListBoxLst = usrsUnderSupListBoxLst;
		}

		/**
		 * @return the supDet
		 */
		public String getSupDet() {
			return supDet;
		}
		/**
		 * @param supDet the supDet to set
		 */
		public void setSupDet(String supDet) {
			this.supDet = supDet;
		}
		/**
		 * @return the queSupervisorChanged
		 */
		public boolean isQueSupervisorChanged() {
			return queSupervisorChanged;
		}
		/**
		 * @param queSupervisorChanged the queSupervisorChanged to set
		 */
		public void setQueSupervisorChanged(boolean queSupervisorChanged) {
			this.queSupervisorChanged = queSupervisorChanged;
		}
		/**
		 * @return the selectedQueSupervisorInfoRow
		 */
		public int getSelectedQueSupervisorInfoRow() {
			
			return selectedQueSupervisorInfoRow;
		}
		/**
		 * @param selectedQueSupervisorInfoRow the selectedQueSupervisorInfoRow to set
		 */
		public void setSelectedQueSupervisorInfoRow(int selectedQueSupervisorInfoRow) {
			this.selectedQueSupervisorInfoRow = selectedQueSupervisorInfoRow;
			
		}
		/**
		 * @return the queSupervisorInfoDisplayState
		 */
		public String getQueSupervisorInfoDisplayState() {
			return queSupervisorInfoDisplayState;
		}
		/**
		 * @param queSupervisorInfoDisplayState the queSupervisorInfoDisplayState to set
		 */
		public void setQueSupervisorInfoDisplayState(
				String queSupervisorInfoDisplayState) {
			this.queSupervisorInfoDisplayState = queSupervisorInfoDisplayState;
		}
		/**
		 * @return the topDisplayQueSupervisorInfoRow
		 */
		public int getTopDisplayQueSupervisorInfoRow() {
			return topDisplayQueSupervisorInfoRow;
		}
		/**
		 * @param topDisplayQueSupervisorInfoRow the topDisplayQueSupervisorInfoRow to set
		 */
		public void setTopDisplayQueSupervisorInfoRow(int topDisplayQueSupervisorInfoRow) {
			this.topDisplayQueSupervisorInfoRow = topDisplayQueSupervisorInfoRow;
		}
		
		@SuppressWarnings("rawtypes")
		private List dummyLst;
		
		/**
		 * @return the dummyLst
		 */
		@SuppressWarnings("rawtypes")
		public List getDummyLst() {
			return dummyLst;
		}
		/**
		 * @param dummyLst the dummyLst to set
		 */
		@SuppressWarnings("rawtypes")
		public void setDummyLst(List dummyLst) {
			this.dummyLst = dummyLst;
		}
		
		
		@SuppressWarnings("rawtypes")
		private List listSupervisorQueueInfos;
		@SuppressWarnings("rawtypes")
		private List listSupervisorUserInfos;
		private EMWFSupervisorUserVO displaySupervisorUserInfo = new EMWFSupervisorUserVO();
		private String userSupervisorInfoDisplayState;
		private boolean supervisorUserChanged;
		private String selectedQueueCode;
		private String selectedSupervisor;
		@SuppressWarnings("rawtypes")
		private List newUserList;
		@SuppressWarnings("rawtypes")
		private List supervisorList;
		@SuppressWarnings("rawtypes")
		private List adminList;
		/*private String selectedUserId;
		private String selectedManagerId;*/
		@SuppressWarnings("rawtypes")
		private List userSupervisorList;
		@SuppressWarnings("rawtypes")
		private List userSupervisorAdminList;

		/**
		 * @return the supervisorUserChanged
		 */
		public boolean isSupervisorUserChanged() {
			return supervisorUserChanged;
		}
		/**
		 * @param supervisorUserChanged the supervisorUserChanged to set
		 */
		public void setSupervisorUserChanged(boolean supervisorUserChanged) {
			this.supervisorUserChanged = supervisorUserChanged;
		}
		/**
		 * @return the userSupervisorInfoDisplayState
		 */
		public String getUserSupervisorInfoDisplayState() {
			return userSupervisorInfoDisplayState;
		}
		/**
		 * @param userSupervisorInfoDisplayState the userSupervisorInfoDisplayState to set
		 */
		public void setUserSupervisorInfoDisplayState(
				String userSupervisorInfoDisplayState) {
			this.userSupervisorInfoDisplayState = userSupervisorInfoDisplayState;
		}
		/**
		 * @return the displaySupervisorUserInfo
		 */
		public EMWFSupervisorUserVO getDisplaySupervisorUserInfo() {
			return displaySupervisorUserInfo;
		}
		/**
		 * @param displaySupervisorUserInfo the displaySupervisorUserInfo to set
		 */
		public void setDisplaySupervisorUserInfo(
				EMWFSupervisorUserVO displaySupervisorUserInfo) {
			this.displaySupervisorUserInfo = displaySupervisorUserInfo;
		}
		/**
		 * @return the listSupervisorUserInfos
		 */
		@SuppressWarnings("rawtypes")
		public List getListSupervisorUserInfos() {
			return listSupervisorUserInfos;
		}
		/**
		 * @param listSupervisorUserInfos the listSupervisorUserInfos to set
		 */
		public void setListSupervisorUserInfos(@SuppressWarnings("rawtypes") List listSupervisorUserInfos) {
			this.listSupervisorUserInfos = listSupervisorUserInfos;
		}
		
		/**
		 * 
		 * @param listSupervisorUserInfos the listSupervisorUserInfos to set
		 */
		@SuppressWarnings("rawtypes")
		public void setListSupervisorUserInfosWithDisplay(List listSupervisorUserInfos) {
			this.listSupervisorUserInfos = listSupervisorUserInfos;
			if ((this.listSupervisorUserInfos != null) && (this.listSupervisorUserInfos.isEmpty() == false)) {
				this.displaySupervisorUserInfo = (EMWFSupervisorUserVO) this.listSupervisorUserInfos.get(this.getSelectedUsrSupervisorInfoRow());
				List<EMWFQSummaryVO> summaryVOs = new ArrayList<EMWFQSummaryVO>();
				
				if(null == displaySupervisorUserInfo.getUsrQPrity0Lst()){
					displaySupervisorUserInfo.setUsrQPrity0Lst(summaryVOs);
		 		}
		 		if(null == displaySupervisorUserInfo.getUsrQPrity1Lst()){
		 			displaySupervisorUserInfo.setUsrQPrity1Lst(summaryVOs);
		 		}
		 		if(null == displaySupervisorUserInfo.getUsrQPrity2Lst()){
		 			displaySupervisorUserInfo.setUsrQPrity2Lst(summaryVOs);
		 		}
		 		if(null == displaySupervisorUserInfo.getUsrQPrity3Lst()){
		 			displaySupervisorUserInfo.setUsrQPrity3Lst(summaryVOs);
		 		}
		 		if(null == displaySupervisorUserInfo.getUsrQPrity4Lst()){
		 			displaySupervisorUserInfo.setUsrQPrity4Lst(summaryVOs);
		 		}
		 		if(null == displaySupervisorUserInfo.getUsrQPrity5Lst()){
		 			displaySupervisorUserInfo.setUsrQPrity5Lst(summaryVOs);
		 		}
			}
			else {
				this.displaySupervisorUserInfo = new EMWFSupervisorUserVO();
				List<EMWFQSummaryVO> summaryVOs = new ArrayList<EMWFQSummaryVO>();
				
				if(null == displaySupervisorUserInfo.getUsrQPrity0Lst()){
					displaySupervisorUserInfo.setUsrQPrity0Lst(summaryVOs);
		 		}
		 		if(null == displaySupervisorUserInfo.getUsrQPrity1Lst()){
		 			displaySupervisorUserInfo.setUsrQPrity1Lst(summaryVOs);
		 		}
		 		if(null == displaySupervisorUserInfo.getUsrQPrity2Lst()){
		 			displaySupervisorUserInfo.setUsrQPrity2Lst(summaryVOs);
		 		}
		 		if(null == displaySupervisorUserInfo.getUsrQPrity3Lst()){
		 			displaySupervisorUserInfo.setUsrQPrity3Lst(summaryVOs);
		 		}
		 		if(null == displaySupervisorUserInfo.getUsrQPrity4Lst()){
		 			displaySupervisorUserInfo.setUsrQPrity4Lst(summaryVOs);
		 		}
		 		if(null == displaySupervisorUserInfo.getUsrQPrity5Lst()){
		 			displaySupervisorUserInfo.setUsrQPrity5Lst(summaryVOs);
		 		}
			}
		}
		
		/**
		 * @return the listSupervisorQueueInfos
		 */
		@SuppressWarnings("rawtypes")
		public List getListSupervisorQueueInfos() {
			return listSupervisorQueueInfos;
		}
		/**
		 * @param listSupervisorQueueInfos the listSupervisorQueueInfos to set
		 */
		@SuppressWarnings("rawtypes")
		public void setListSupervisorQueueInfos(List listSupervisorQueueInfos) {
			this.listSupervisorQueueInfos = listSupervisorQueueInfos;
		}
		/**
		 * @return the selectedQueueCode
		 */
		public String getSelectedQueueCode() {
			return selectedQueueCode;
		}
		/**
		 * @param selectedQueueCode the selectedQueueCode to set
		 */
		public void setSelectedQueueCode(String selectedQueueCode) {
			this.selectedQueueCode = selectedQueueCode;
		}
		/**
		 * @return the selectedSupervisor
		 */
		public String getSelectedSupervisor() {
			return selectedSupervisor;
		}
		/**
		 * @param selectedSupervisor the selectedSupervisor to set
		 */
		public void setSelectedSupervisor(String selectedSupervisor) {
			this.selectedSupervisor = selectedSupervisor;
		}
		public String getAdminSrchHistLvl() {
			return adminSrchHistLvl;
		}
		public void setAdminSrchHistLvl(String adminSrchHistLvl) {
			this.adminSrchHistLvl = adminSrchHistLvl;
		}
		public String getAdminSrchQName() {
			return adminSrchQName;
		}
		public void setAdminSrchQName(String adminSrchQName) {
			this.adminSrchQName = adminSrchQName;
		}
		public String getAdminSrchAdmin() {
			return adminSrchAdmin;
		}
		public void setAdminSrchAdmin(String adminSrchAdmin) {
			this.adminSrchAdmin = adminSrchAdmin;
		}
		public String getAdminSrchSuprv() {
			return adminSrchSuprv;
		}
		public void setAdminSrchSuprv(String adminSrchSuprv) {
			this.adminSrchSuprv = adminSrchSuprv;
		}
		public String getAdminSrchCompUsr() {
			return adminSrchCompUsr;
		}
		public void setAdminSrchCompUsr(String adminSrchCompUsr) {
			this.adminSrchCompUsr = adminSrchCompUsr;
		}
		public String getAdminSrchInitUsr() {
			return adminSrchInitUsr;
		}
		public void setAdminSrchInitUsr(String adminSrchInitUsr) {
			this.adminSrchInitUsr = adminSrchInitUsr;
		}
		public String getAdminSrchRiskInd() {
			return adminSrchRiskInd;
		}
		public void setAdminSrchRiskInd(String adminSrchRiskInd) {
			this.adminSrchRiskInd = adminSrchRiskInd;
		}
		public String getAdminSrchRiskRng() {
			return adminSrchRiskRng;
		}
		public void setAdminSrchRiskRng(String adminSrchRiskRng) {
			this.adminSrchRiskRng = adminSrchRiskRng;
		}
		

		@SuppressWarnings("rawtypes")
		public List getAdminHistDetailLst() {
			return adminHistDetailLst;
		}
		@SuppressWarnings("rawtypes")
		public void setAdminHistDetailLst(List adminHistDetailLst) {
			this.adminHistDetailLst = adminHistDetailLst;
		}
		public int getAdminHistDetailsPageNbr() {
			return adminHistDetailsPageNbr;
		}
		public void setAdminHistDetailsPageNbr(int adminHistDetailsPageNbr) {
			this.adminHistDetailsPageNbr = adminHistDetailsPageNbr;
		}
		public String getAdminHistDetailsCurrPageType() {
			return adminHistDetailsCurrPageType;
		}
		public void setAdminHistDetailsCurrPageType(String adminHistDetailsCurrPageType) {
			this.adminHistDetailsCurrPageType = adminHistDetailsCurrPageType;
		}
		public String getAdminHistDetSrchStartDt() {
			return adminHistDetSrchStartDt;
		}
		public void setAdminHistDetSrchStartDt(String adminHistDetSrchStartDt) {
			this.adminHistDetSrchStartDt = adminHistDetSrchStartDt;
		}
		public String getAdminHistDetSrchEndDt() {
			return adminHistDetSrchEndDt;
		}
		public void setAdminHistDetSrchEndDt(String adminHistDetSrchEndDt) {
			this.adminHistDetSrchEndDt = adminHistDetSrchEndDt;
		}
		public String getAdminHistPageOpt() {
			return adminHistPageOpt;
		}
		public void setAdminHistPageOpt(String adminHistPageOpt) {
			this.adminHistPageOpt = adminHistPageOpt;
		}
		
		/**
		 * @return the newUserList
		 */
		@SuppressWarnings("rawtypes")
		public List getNewUserList() {
			return newUserList;
		}
		/**
		 * @param newUserList the newUserList to set
		 */
		@SuppressWarnings("rawtypes")
		public void setNewUserList(List newUserList) {
			this.newUserList = newUserList;
		}
		/**
		 * @return the supervisorList
		 */
		@SuppressWarnings("rawtypes")
		public List getSupervisorList() {
			return supervisorList;
		}
		/**
		 * @param supervisorList the supervisorList to set
		 */
		@SuppressWarnings("rawtypes")
		public void setSupervisorList(List supervisorList) {
			this.supervisorList = supervisorList;
		}
		/**
		 * @return the adminList
		 */
		@SuppressWarnings("rawtypes")
		public List getAdminList() {
			return adminList;
		}
		/**
		 * @param adminList the adminList to set
		 */
		@SuppressWarnings("rawtypes")
		public void setAdminList(List adminList) {
			this.adminList = adminList;
		}
		/**
		 * @return the addType
		 */
		public String getAddType() {
			return addType;
		}
		/**
		 * @param addType the addType to set
		 */
		public void setAddType(String addType) {
			this.addType = addType;
		}
		/**
		 * @return the selectedUserId
		 *//*
		public String getSelectedUserId() {
			return selectedUserId;
		}
		*//**
		 * @param selectedUserId the selectedUserId to set
		 *//*
		public void setSelectedUserId(String selectedUserId) {
			//System.out.println(" inform=="+selectedUserId);
			this.selectedUserId = selectedUserId;
		}
		*//**
		 * @return the selectedManagerId
		 *//*
		public String getSelectedManagerId() {
			return selectedManagerId;
		}
		*//**
		 * @param selectedManagerId the selectedManagerId to set
		 *//*
		public void setSelectedManagerId(String selectedManagerId) {
			this.selectedManagerId = selectedManagerId;
		}*/
		
		
		/**
		 * 045_AtRisk Changes start
		 */
		/**
		 * @return the listAtRiskSummary
		 */
		@SuppressWarnings("rawtypes")
		public List getListAtRiskSummary() {
			return listAtRiskSummary;
		}
		/**
		 * @param listAtRiskSummary the listAtRiskSummary to set
		 */
		@SuppressWarnings("rawtypes")
		public void setListAtRiskSummary(List listAtRiskSummary) {
			this.listAtRiskSummary = listAtRiskSummary;
		}
		/**
		 * @return the listAtRiskDetails
		 */
		@SuppressWarnings("rawtypes")
		public List getListAtRiskDetails() {
			return listAtRiskDetails;
		}
		/**
		 * @param listAtRiskDetails the listAtRiskDetails to set
		 */
		@SuppressWarnings("rawtypes")
		public void setListAtRiskDetails(List listAtRiskDetails) {
			this.listAtRiskDetails = listAtRiskDetails;
		}
		/**
		 * @return the queueCode
		 */
		public String getQueueCode() {
			return queueCode;
		}
		/**
		 * @param queueCode the queueCode to set
		 */
		public void setQueueCode(String queueCode) {
			this.queueCode = queueCode;
		}
		/**
		 * @return the queuePriority
		 */
		public Integer getQueuePriority() {
			return queuePriority;
		}
		/**
		 * @param queuePriority the queuePriority to set
		 */
		public void setQueuePriority(Integer queuePriority) {
			this.queuePriority = queuePriority;
		}
		/**
		 * @return the daysLeft
		 */
		public Integer getDaysLeft() {
			return daysLeft;
		}
		/**
		 * @param daysLeft the daysLeft to set
		 */
		public void setDaysLeft(Integer daysLeft) {
			this.daysLeft = daysLeft;
		}
		/**
		 * @return the atRiskRowCnt
		 */
		public int getAtRiskRowCnt() {
			return atRiskRowCnt;
		}

		/**
		 * @param atRiskRowCnt the atRiskRowCnt to set
		 */
		public void setAtRiskRowCnt(int atRiskRowCnt) {
			this.atRiskRowCnt = atRiskRowCnt;
		}
		/**
		 * 045_AtRisk Changes end
		 */
		public List getUserSupervisorAdminList() {
			return userSupervisorAdminList;
		}
		public void setUserSupervisorAdminList(List userSupervisorAdminList) {
			this.userSupervisorAdminList = userSupervisorAdminList;
		}
		/**
		 * @return the userSupervisorList
		 */
		public List getUserSupervisorList() {
			return userSupervisorList;
		}
		/**
		 * @param userSupervisorList the userSupervisorList to set
		 */
		public void setUserSupervisorList(List userSupervisorList) {
			this.userSupervisorList = userSupervisorList;
		}
		/**
		 * @return the adminSrchComplInd
		 */
		public String getAdminSrchComplInd() {
			return adminSrchComplInd;
		}
		/**
		 * @param adminSrchComplInd the adminSrchComplInd to set
		 */
		public void setAdminSrchComplInd(String adminSrchComplInd) {
			this.adminSrchComplInd = adminSrchComplInd;
		}
		/**
		 * @return the adminSrchYear
		 */
		public int getAdminSrchYear() {
			return adminSrchYear;
		}
		/**
		 * @param adminSrchYear the adminSrchYear to set
		 */
		public void setAdminSrchYear(int adminSrchYear) {
			this.adminSrchYear = adminSrchYear;
		}
		/**
		 * @return the adminSrchMonth
		 */
		public int getAdminSrchMonth() {
			return adminSrchMonth;
		}
		/**
		 * @param adminSrchMonth the adminSrchMonth to set
		 */
		public void setAdminSrchMonth(int adminSrchMonth) {
			this.adminSrchMonth = adminSrchMonth;
		}
		/**
		 * @return the adminSrchWeek
		 */
		public int getAdminSrchWeek() {
			return adminSrchWeek;
		}
		/**
		 * @param adminSrchWeek the adminSrchWeek to set
		 */
		public void setAdminSrchWeek(int adminSrchWeek) {
			this.adminSrchWeek = adminSrchWeek;
		}
		/**
		 * @return the adminHistYears
		 */
		public List getAdminHistYears() {
			return adminHistYears;
		}
		/**
		 * @param adminHistYears the adminHistYears to set
		 */
		public void setAdminHistYears(List adminHistYears) {
			this.adminHistYears = adminHistYears;
		}
		
		/**
		 * @return the adminSrchType
		 */
		public String getAdminSrchType() {
			return adminSrchType;
		}
		/**
		 * @param adminSrchType the adminSrchType to set
		 */
		public void setAdminSrchType(String adminSrchType) {
			this.adminSrchType = adminSrchType;
		}
		/**
		 * @return the adminHistMonths
		 */
		public ListBoxItem[] getAdminHistMonths() {
			return adminHistMonths;
		}
		/**
		 * @param adminHistMonths the adminHistMonths to set
		 */
		public void setAdminHistMonths(ListBoxItem[] adminHistMonths) {
			this.adminHistMonths = adminHistMonths;
		}
		/**
		 * @return the adminHistWeeks
		 */
		public ListBoxItem[] getAdminHistWeeks() {
			return adminHistWeeks;
		}
		/**
		 * @param adminHistWeeks the adminHistWeeks to set
		 */
		public void setAdminHistWeeks(ListBoxItem[] adminHistWeeks) {
			this.adminHistWeeks = adminHistWeeks;
		}
		/**
		 * @return the adminHistLvls
		 */
		public ListBoxItem[] getAdminHistLvls() {
			return adminHistLvls;
		}
		/**
		 * @param adminHistLvls the adminHistLvls to set
		 */
		public void setAdminHistLvls(ListBoxItem[] adminHistLvls) {
			this.adminHistLvls = adminHistLvls;
		}		
		/**
		 * @return the adminHistRiskInds
		 */
		public ListBoxItem[] getAdminHistRiskInds() {
			return adminHistRiskInds;
		}
		/**
		 * @param adminHistRiskInds the adminHistRiskInds to set
		 */
		public void setAdminHistRiskInds(ListBoxItem[] adminHistRiskInds) {
			this.adminHistRiskInds = adminHistRiskInds;
		}
		/**
		 * @return the adminHIstRiskRngs
		 */
		public ListBoxItem[] getAdminHIstRiskRngs() {
			return adminHIstRiskRngs;
		}
		/**
		 * @param adminHIstRiskRngs the adminHIstRiskRngs to set
		 */
		public void setAdminHIstRiskRngs(ListBoxItem[] adminHIstRiskRngs) {
			this.adminHIstRiskRngs = adminHIstRiskRngs;
		}
		/**
		 * @return the adminHistRiskCompls
		 */
		public ListBoxItem[] getAdminHistRiskCompls() {
			return adminHistRiskCompls;
		}
		/**
		 * @param adminHistRiskCompls the adminHistRiskCompls to set
		 */
		public void setAdminHistRiskCompls(ListBoxItem[] adminHistRiskCompls) {
			this.adminHistRiskCompls = adminHistRiskCompls;
		}
		/**
		 * @return the adminHistSrchTypes
		 */
		public ListBoxItem[] getAdminHistSrchTypes() {
			return adminHistSrchTypes;
		}
		/**
		 * @param adminHistSrchTypes the adminHistSrchTypes to set
		 */
		public void setAdminHistSrchTypes(ListBoxItem[] adminHistSrchTypes) {
			this.adminHistSrchTypes = adminHistSrchTypes;
		}
		/**
		 * @return the adminHistQNames
		 */
		public List getAdminHistQNames() {
			return adminHistQNames;
		}
		/**
		 * @param adminHistQNames the adminHistQNames to set
		 */
		public void setAdminHistQNames(List adminHistQNames) {
			this.adminHistQNames = adminHistQNames;
		}
		/**
		 * @return the adminHistAdmins
		 */
		public List getAdminHistAdmins() {
			return adminHistAdmins;
		}
		/**
		 * @param adminHistAdmins the adminHistAdmins to set
		 */
		public void setAdminHistAdmins(List adminHistAdmins) {
			this.adminHistAdmins = adminHistAdmins;
		}
		/**
		 * @return the adminHistSuprvs
		 */
		public List getAdminHistSuprvs() {
			return adminHistSuprvs;
		}
		/**
		 * @param adminHistSuprvs the adminHistSuprvs to set
		 */
		public void setAdminHistSuprvs(List adminHistSuprvs) {
			this.adminHistSuprvs = adminHistSuprvs;
		}
		/**
		 * @return the adminHistUsrs
		 */
		public List getAdminHistUsrs() {
			return adminHistUsrs;
		}
		/**
		 * @param adminHistUsrs the adminHistUsrs to set
		 */
		public void setAdminHistUsrs(List adminHistUsrs) {
			this.adminHistUsrs = adminHistUsrs;
		}
		//Excellus Retro fix for workflow -Start
		/**
		 * @return the newAddSuprUserList
		 */
		public List getNewAddSuprUserList() {
			return newAddSuprUserList;
		}
		/**
		 * @param newAddSuprUserList the newAddSuprUserList to set
		 */
		public void setNewAddSuprUserList(List newAddSuprUserList) {
			this.newAddSuprUserList = newAddSuprUserList;
		}
		/**
		 * @return the selectedUserId
		 */
		public String[] getSelectedUserId() {
			return selectedUserId;
		}
		/**
		 * @param selectedUserId the selectedUserId to set
		 */
		public void setSelectedUserId(String[] selectedUserId) {
			this.selectedUserId = selectedUserId;
		}
		/**
		 * @return the selectedManagerId
		 */
		public String[] getSelectedManagerId() {
			return selectedManagerId;
		}
		/**
		 * @param selectedManagerId the selectedManagerId to set
		 */
		public void setSelectedManagerId(String[] selectedManagerId) {
			this.selectedManagerId = selectedManagerId;
		}
		
		
		
		//Excellus Retro fix for workflow -End
		
}
