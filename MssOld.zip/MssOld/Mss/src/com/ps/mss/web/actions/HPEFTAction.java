/*
 * $Id: HPEFTAction.java,v 1.2 2015/11/26 10:10:55 praveen Exp $
 */
package com.ps.mss.web.actions;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.model.HpeSearchVO;
import com.ps.mss.db.DbConn;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.ChartConstants;
import com.ps.mss.framework.Constants;
import com.ps.mss.framework.HPEConstants;
import com.ps.mss.manager.HPEManager;
import com.ps.mss.model.HPEContext;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.forms.HPEEncounterForm;
import com.ps.mss.web.forms.HPEFileTrackingForm;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.util.NameValuePair;

/**
 * EDPS File Tracking Action Class.
 * 
 * @author bsanthos
 */
public class HPEFTAction extends Action {
	/**
	 * logger.
	 */
	private static Logger logger=LoggerFactory.getLogger(HPEFTAction.class);

	/**
	 * Core method in the Action class where the execution takes place.
	 */
	@SuppressWarnings("rawtypes")
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws IOException, ServletException {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		String forward = HPEConstants.HPE_ERROR;
		String mmpPlan = null;
		HpeSearchVO searchVO = null;	
		String strUrl = "";
		
		String remarksFileId = request.getParameter("orig_intrchg_ctrl_nbr");
		String remarksField = request.getParameter("cust_comments");
		String remarkMenu = request.getParameter("menu");
		String selSubId = request.getParameter("selSubId");
		String tab = request.getParameter("tab");
		 StringBuffer msg= new StringBuffer("");

		try {
			// get the session
			SessionHelper sessionHelper = new SessionHelper(request);

			// get a connection
			conn = DbConn.getConnection();

			// use the default DB for security check
			String errorMsg = sessionHelper.validateUser(conn);
			if (errorMsg != null) {
				request.setAttribute("Msg", "Login Has Timed Out");
				throw new Exception(errorMsg);//k
			}

			// re-get the connection in case the environment is different (QA,
			// etc.)
			conn = DbConn.reGetConnection(conn, (String) sessionHelper.getAttribute(SessionManager.HPEDB));

			// get the context
			HPEContext context = HPEManager.getContext(sessionHelper.getSession());
			mmpPlan = (String) sessionHelper.getAttribute("MMP");
			// get the form

			HPEFileTrackingForm hpeFTForm = (HPEFileTrackingForm) form;

			// get the method/menu
			String method = hpeFTForm.getMethod();
			String menu = hpeFTForm.getMenu();
			String dailyDetHL = hpeFTForm.getDailyDetHL();
			String searchBy = hpeFTForm.getSearchBy();
			String claimRefNo = hpeFTForm.getSearchClmRefNbr();

			String formSearch = hpeFTForm.getFormSearch();
			if(tab!=null && !tab.isEmpty() && tab.equals("refresh")){
				//FileName
				sessionHelper.removeAttribute("edpsFileDashMngtByFileNameSearchCriteria");
				sessionHelper.removeAttribute("submitterIdByFileNameSearchCriteria");
				sessionHelper.removeAttribute("fileNameByFileNameSearchCriteria");
				sessionHelper.removeAttribute("encTypeByFileNameSearchCriteria");
				//FileID
				sessionHelper.removeAttribute("edpsFileDashMngtByFileIdSearchCriteria");
				sessionHelper.removeAttribute("submitterIdByFileIdSearchCriteria");
				sessionHelper.removeAttribute("origIntrchgNbrByFileIdSearchCriteria");
				sessionHelper.removeAttribute("encTypeByFileIdSearchCriteria");
				//Claim Number
                sessionHelper.removeAttribute("searchDailyFileProcesing");
				sessionHelper.removeAttribute("submitterIdSearchDailyFP");
				sessionHelper.removeAttribute("searchClaimType"); 
				sessionHelper.removeAttribute("searchClmRefNbr");
				//Submitter Id Search
				sessionHelper.removeAttribute("edpsFileDashMngtBySearchCriteria");
				sessionHelper.removeAttribute("submitterIdBySearchCriteria");
				sessionHelper.removeAttribute("sourceIdBySearchCriteria");
				sessionHelper.removeAttribute("encTypeBySearchCriteria");
				sessionHelper.removeAttribute("fromDateBySearchCriteria");
				sessionHelper.removeAttribute("toDateBySearchCriteria");
				sessionHelper.removeAttribute("lineOfBusinessBySearchCriteria");
				sessionHelper.removeAttribute("typeOfBusinessBySearchCriteria");
				//Monthly Encounters **searchFileTrackByFileDshbMngt**
				sessionHelper.removeAttribute("searchMonEncDetails");
				sessionHelper.removeAttribute("submitterIdSearchMonEncDetails");
				sessionHelper.removeAttribute("encTypeSearchMonEncDetails"); 
				sessionHelper.removeAttribute("spltFleStatusTempSearchMonEncDetails");
				sessionHelper.removeAttribute("dateYearMonthSearchMonEncDetails");
				sessionHelper.removeAttribute("intrChgRecvrIdSearchMonEncDetails");
				sessionHelper.removeAttribute("sourceIdSearchMonEncDetails");
				sessionHelper.removeAttribute("fileDsbMgmtHLSearchMonEncDetails");
				//Daily File processing **searchFileTrackByMonEncDetails**
				sessionHelper.removeAttribute("searchDailyFileProcesing");
				sessionHelper.removeAttribute("submitterIdSearchDailyFP");
				sessionHelper.removeAttribute("encTypeSearchDailyFP"); 
				sessionHelper.removeAttribute("dateYearMonthSearchDailyFP");
				sessionHelper.removeAttribute("intrChgRecvrIdSearchDailyFP");
				sessionHelper.removeAttribute("submissionDateSearchDailyFP");
				sessionHelper.removeAttribute("origIntrchgCtrlNbrSearchDailyFP");
				sessionHelper.removeAttribute("splitFileStatusSearchDailyFP");
				sessionHelper.removeAttribute("moEncDetHLSearchDailyFP");
				sessionHelper.removeAttribute("dailyDetHLSearchDailyFP");
				//Failed File List **searchFailedFileTrackByFileDshbMngt**
				sessionHelper.removeAttribute("searchFailedFileListDetails");
				sessionHelper.removeAttribute("submitterIdFailedFileSession");
				sessionHelper.removeAttribute("dateYearMonthFailedSession"); 
				sessionHelper.removeAttribute("sourceIdFailedSession");
				sessionHelper.removeAttribute("fileDsbMgmtHLFailedSession");
				sessionHelper.removeAttribute("encTypeFailedSession");
				sessionHelper.removeAttribute("spltFleStatusTempFailedSession");
				hpeFTForm.setRefreshTab("TRUE");
			}else{
				hpeFTForm.setRefreshTab("FALSE");
			}
			
			
			logger.debug("formsearch is from after setting hidden varaible :" + formSearch);
			
			if(!remarkMenu.isEmpty() && (remarkMenu.equals(HPEConstants.HPE_FILETRACK_REMARK_UPDATE) || remarkMenu.equals(HPEConstants.HPE_FILETRACK_REMARK_RETRIEVE)) ){				
				menu =remarkMenu;
				method = remarkMenu;
			}


			int enumMethod = HPEConstants.getEnumMethod(method);

			if (enumMethod == HPEConstants.ENUM_METHOD_SWITCHMENU && HPEConstants.MENU_FILE_TRACK.equals(menu)
					&& method != null) {
				enumMethod = HPEConstants.getEnumMethod(method);

			}

			switch (enumMethod) {
			case HPEConstants.ENUM_METHOD_INITIALIZE:
				setSubmitter(conn, sessionHelper, context, hpeFTForm);
				break;
			case HPEConstants.ENUM_METHOD_SWITCHMENU:

				/* File Track Code - Start */
				if (HPEConstants.MENU_FILE_TRACK.equals(menu)) {
					context.setSelectedMenu(HPEConstants.MENU_FILE_TRACK);
					context.setSelectedOption(HPEConstants.OPTION_FILETRACKTREE);
 					if (StringUtils.isEmpty(hpeFTForm.getSearchSummarySubmitterId())) {
						setSubmitter(conn, sessionHelper, context, hpeFTForm);
					}
					logger.debug("HPEFTAction.execute(): hpeFTForm.getSearchSummarySubmitterId: "
							+ hpeFTForm.getSearchSummarySubmitterId());
					HPEFTProcessing.fileTrackSwitchTab(conn, sessionHelper, context, hpeFTForm, request);

					forward = HPEConstants.HPE_FILETRACKTREE;
				}
				
				logger.debug("menu value is from HPEFTAction.java :"+menu);
				if (HPEConstants.MENU_FILE_TRACK_EXPORT.equals(menu)) {
					context.setSelectedMenu(HPEConstants.MENU_FILE_TRACK_EXPORT);
					context.setSelectedOption(HPEConstants.OPTION_FILETRACKTREE_EXPORT);
					sessionHelper.setAttribute(HPEConstants.FILETRACK_EXPORT_IND_FLAG, "TRUE");
					logger.debug("HPEFTAction.execute(): MENU_FILE_TRACK_EXPORT: ");
					logger.debug("forward value is from HPEFTAction.java :"+forward);
					forward = HPEConstants.HPE_FILETRACKTREE_EXPORT;
				}
				
				break;
				
			case HPEConstants.ENUM_METHOD_FILETREESEARCH:
				context.setSelectedMenu(HPEConstants.MENU_FILE_TRACK);
				context.setSelectedOption(HPEConstants.OPTION_FILETRACKTREE);
				logger.debug("in execute method from::::ENUM_METHOD_FILETREESEARCH::::");
				sessionHelper.removeAttribute(HPEConstants.FILETRACK_EXPORT_IND_FLAG);
				
				if((!hpeFTForm.getOrig_intrchg_ctrl_nbr().equals("") || !hpeFTForm.getFileName().equals("")) && (!hpeFTForm.getSearchClaimType().equals("N") && !hpeFTForm.getSearchClmRefNbr().equals(""))){
					hpeFTForm.setOrig_intrchg_ctrl_nbr("");
					hpeFTForm.setCustFileId("");//IFOX-00416789 - Add customer ICN in File management
					hpeFTForm.setFileName("");
					HPEFTProcessing.fileTrackSearch(conn, sessionHelper, context, hpeFTForm, request);
				
				}else if((StringUtils.isNotEmpty(remarksFileId) || StringUtils.isNotEmpty(remarksField)) && (!hpeFTForm.getOrig_intrchg_ctrl_nbr().equals("") || !hpeFTForm.getFileName().equals(""))){
					hpeFTForm.setOrig_intrchg_ctrl_nbr("");
					hpeFTForm.setCustFileId("");//IFOX-00416789 - Add customer ICN in File management
					hpeFTForm.setFileName("");
					HPEFTProcessing.fileTrackSearch(conn, sessionHelper, context, hpeFTForm, request);	
				
				}else if((StringUtils.isNotEmpty(remarksFileId) || StringUtils.isNotEmpty(remarksField)) && (!hpeFTForm.getSearchClaimType().equals("N") && !hpeFTForm.getSearchClmRefNbr().equals(""))){
					hpeFTForm.setOrig_intrchg_ctrl_nbr("");
					hpeFTForm.setCustFileId("");//IFOX-00416789 - Add customer ICN in File management
					hpeFTForm.setFileName("");
					HPEFTProcessing.fileTrackSearch(conn, sessionHelper, context, hpeFTForm, request);
				
				}else{
				     HPEFTProcessing.fileTrackSearch(conn, sessionHelper, context, hpeFTForm, request);
				}
				forward = HPEConstants.HPE_FILETRACKTREE;
				break;
				
			case HPEConstants.ENUM_METHOD_FILETREE_EXPORT:
				context.setSelectedMenu(HPEConstants.MENU_FILE_TRACK_EXPORT);
				context.setSelectedOption(HPEConstants.OPTION_FILETRACKTREE_EXPORT);
				logger.debug("in ENUM_METHOD_FILETREE_EXPORT::::");
				String csv = HPEFTProcessing.exportFileNames(conn, sessionHelper, context, hpeFTForm, request, response);
				request.setAttribute("fileName", csv);
				request.setAttribute("fileTrackingExportType", "CSV");
				forward = "download";
				break;
				
			case HPEConstants.ENUM_METHOD_FILE_DASHBOARD_EXPORT:
				context.setSelectedMenu(HPEConstants.MENU_FILE_DASHBOARD_EXPORT);
				context.setSelectedOption(HPEConstants.OPTION_FILE_DASHBOARD_EXPORT);
				logger.debug("in ENUM_METHOD_FILETREE_EXPORT::::");
				sessionHelper.removeAttribute(HPEConstants.FILETRACK_EXPORT_IND_FLAG);
				String csvFileName = HPEFTProcessing.exportFileDashBoardList(conn, sessionHelper, context, hpeFTForm, request, response);
				request.setAttribute("fileName", csvFileName);
				request.setAttribute("fileTrackingExportType", "CSV");
		        logger.debug("Export File Dashboard details seciton" );
		        forward = "download";
				break;	
		
			case HPEConstants.ENUM_HPE_FILETRACK_REMARK_UPDATE:	
				logger.debug("in ENUM_HPE_FILETRACK_REMARK_UPDATE::::");
				hpeFTForm.setRemarks(remarksField);
				hpeFTForm.setRemarksFileId(remarksFileId);
				hpeFTForm.setSearchSubmitterId(selSubId);
				String updt = HPEFTProcessing.updateRemarkSection(conn, sessionHelper, context, hpeFTForm, request, response);
				hpeFTForm.setOrig_intrchg_ctrl_nbr("");
				hpeFTForm.setCustFileId("");//IFOX-00416789 - Add customer ICN in File management
				hpeFTForm.setFileName("");
				forward = HPEConstants.HPE_FILETRACKTREE;
				
				break;
				
			case HPEConstants.ENUM_HPE_FILETRACK_REMARK_RETREIVE:	
				logger.debug("in ENUM_HPE_FILETRACK_REMARK_RETREIVE::::");
				hpeFTForm.setRemarks(remarksField);
				hpeFTForm.setRemarksFileId(remarksFileId);
				if(StringUtils.isNotEmpty(selSubId)){
					int pos = selSubId.indexOf("?");
					selSubId=selSubId.substring(0, pos); 
				}
				hpeFTForm.setSearchSubmitterId(selSubId);
				String txt = HPEFTProcessing.retrieveRemarkSection(conn, sessionHelper, context, hpeFTForm, request, response);
				PrintWriter out = response.getWriter();	
				 msg.append(txt);
				 out.println(msg.toString());
                 out.flush();
                 out.close();
		        logger.debug("Retrieved the Remarks from Xref table -"+txt);
				forward = HPEConstants.HPE_FILETRACKTREE;	
				break;	
				
			case HPEConstants.ENUM_SWITCH_MENU_CR:
				// get the form
				HPEEncounterForm hpeEncounterForm = (HPEEncounterForm) form;
				menu = hpeEncounterForm.getMenu();
				method = "switchMenu";

				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
				if (searchVO != null) {
					if (searchVO.getEncType().equals("I")) {
						searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
						searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
						searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
						searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
						searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
						searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
						searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
						searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
						searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isInstClaimProvDetailExpanded());
						searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
						searchVO.setClaimOtherSubsProvDetailExpanded(
								hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
						searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
						searchVO.setClaimOtherSubsDetailExpanded(hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
						searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
						searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isInstClaimLineDetailExpanded());
						searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
						searchVO.setClaimLineProvDetailExpanded(hpeEncounterForm.isInstClaimLineProvDetailExpanded());
						searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
						searchVO.setClaimLineAdjudDetailExpanded(hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());
					} else if (searchVO.getEncType().equals("P")) {
						searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
						searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
						searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
						searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
						searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
						searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());
						searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
						searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isProfClaimProvDetailExpanded());
						searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
						searchVO.setClaimOtherSubsProvDetailExpanded(
								hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
						searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
						searchVO.setClaimOtherSubsDetailExpanded(hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
						searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
						searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isProfClaimLineDetailExpanded());
						searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
						searchVO.setClaimLineProvDetailExpanded(hpeEncounterForm.isProfClaimLineProvDetailExpanded());
						searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
						searchVO.setClaimLineAdjudDetailExpanded(hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
					}
					searchVO.setIconFlag("Y");
				}
				sessionHelper.setAttribute(HPEConstants.SEARCH_ERROR_VO, searchVO);

				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
				if (searchVO != null) {
					if (searchVO.getEncType().equals("I")) {
						searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
						searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
						searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
						searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
						searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
						searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
						searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
						searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
						searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isInstClaimProvDetailExpanded());
						searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
						searchVO.setClaimOtherSubsProvDetailExpanded(
								hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
						searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
						searchVO.setClaimOtherSubsDetailExpanded(hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
						searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
						searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isInstClaimLineDetailExpanded());
						searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
						searchVO.setClaimLineProvDetailExpanded(hpeEncounterForm.isInstClaimLineProvDetailExpanded());
						searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
						searchVO.setClaimLineAdjudDetailExpanded(hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());
					} else if (searchVO.getEncType().equals("P")) {
						searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
						searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
						searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
						searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
						searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
						searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());
						searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
						searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isProfClaimProvDetailExpanded());
						searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
						searchVO.setClaimOtherSubsProvDetailExpanded(
								hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
						searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
						searchVO.setClaimOtherSubsDetailExpanded(hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
						searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
						searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isProfClaimLineDetailExpanded());
						searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
						searchVO.setClaimLineProvDetailExpanded(hpeEncounterForm.isProfClaimLineProvDetailExpanded());
						searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
						searchVO.setClaimLineAdjudDetailExpanded(hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
					}
					searchVO.setIconFlag("Y");
				}
				sessionHelper.setAttribute(HPEConstants.SEARCH_ENCOUNTER_VO, searchVO);

				strUrl = "/chartAction.do?menu=" + menu + "&method=" + method;
				response.sendRedirect(strUrl);
				logger.info(LoggerConstants.methodEndLevel());
				return null;
				
		//Traverse CR from file tracking to chart management		
			case HPEConstants.ENUM_FILETREE_MOVE_CR:
								
				 menu = HPEConstants.FILETRACK_DASH_MOVE_CHART;				
				 method = HPEConstants.FILETRACK_DASH_MOVE_CHART;
				 
				 searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_FILE_TRACK_VO);
				  if(searchVO==null){
					  searchVO = new HpeSearchVO(); 
				  }
			      
				  searchVO.setEncType(hpeFTForm.getEncType());
				  searchVO.setGroupStatus(hpeFTForm.getStatus());
				  searchVO.setSelectedOrigFileId(hpeFTForm.getOrig_intrchg_ctrl_nbr());
				  searchVO.setSubmitterId(hpeFTForm.getSearchSubmitterId());
				  searchVO.setClmType(hpeFTForm.getSearchDetailClmType());
				 
				  sessionHelper.setAttribute(HPEConstants.SEARCH_FILE_TRACK_VO, searchVO);
				  sessionHelper.setAttribute("dailyDetHLSearchDailyFP", dailyDetHL);
				  sessionHelper.setAttribute("checkboxSelected", searchBy);
				  strUrl = "/chartAction.do?menu=" + menu + "&method=" + method;
				  logger.debug(strUrl);
				  response.sendRedirect(strUrl);
				  logger.info(LoggerConstants.methodEndLevel());
				  return null;
				 
			case HPEConstants.ENUM_FILETREE_MOVE_EN:
				  menu = HPEConstants.FILETRACK_DASH_MOVE_CR;				
				  method = HPEConstants.FILETRACK_DASH_MOVE_CR;
				  searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_FILE_TRACK_VO);
				  if(searchVO==null){
					  searchVO = new HpeSearchVO(); 
				  }
			      
				  searchVO.setEncType(hpeFTForm.getEncType());
				  searchVO.setGroupStatus(hpeFTForm.getStatus());
				  searchVO.setSelectedOrigFileId(hpeFTForm.getOrig_intrchg_ctrl_nbr());
				  searchVO.setSubmitterId(hpeFTForm.getSearchSubmitterId());
				 
				  sessionHelper.setAttribute(HPEConstants.SEARCH_FILE_TRACK_VO, searchVO);
				  sessionHelper.setAttribute("dailyDetHLSearchDailyFP", dailyDetHL);
				  sessionHelper.setAttribute("checkboxSelected", searchBy);
				  sessionHelper.setAttribute("claimNumber", claimRefNo);
				  
				   strUrl = "/hpeAction.do?menu="+menu+"&method="+method;
				  response.sendRedirect(strUrl);
				  logger.info(LoggerConstants.methodEndLevel());
				  return null;
			/* File Track Code - End */
			default:
				forward = HPEConstants.HPE_FILETRACKTREE;
				break;
			}
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//logger.error(e.getMessage());
		} finally {
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				//logger.error(e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(forward);
	}

	private void setSubmitter(Connection conn, SessionHelper sessionHelper, HPEContext context,
			HPEFileTrackingForm hpeFTForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		List lst = context.getOptionsSubmitters();
		NameValuePair nvp = (NameValuePair) lst.get(0);
		hpeFTForm.setSearchSummarySubmitterId(nvp.getName());
		logger.info(LoggerConstants.methodEndLevel());
	}
}
