/*
 * $Id: EEMPopUpAction.java,v 1.2 2014/10/02 20:10:36 praveen Exp $
 */
package com.ps.mss.web.actions;

import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EEMGroupProduct;
import com.ps.mss.db.DbConn;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.forms.EEMEnrollGPSearchForm;
import com.ps.mss.web.forms.EEMEnrollLtcSearchForm;
import com.ps.mss.web.forms.EEMEnrollPcpSearchForm;
import com.ps.mss.web.forms.EEMForm;
import com.ps.mss.web.forms.EEMTrrDataForm;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.manager.EEMEnrollManager;
import com.ps.text.DateFormatter;

/**
 * @author nenne.robert
 */
public class EEMPopUpAction extends Action {

	private static Logger logger=LoggerFactory.getLogger(EEMPopUpAction.class);

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		try {
			EEMForm eemForm = (EEMForm) form;
			String method = eemForm.getMethod();
			
			// use the default DB for security check
			conn = DbConn.getConnection();
			SessionHelper sessionHelper = new SessionHelper(request);
			String errorMsg = sessionHelper.validateUser(conn);
			if (errorMsg != null) {
				throw new Exception(errorMsg);
			}
			
			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			if ("initEnrlGPSearch".equals(method)) {
				logger.info(LoggerConstants.methodEndLevel());
				return initEnrollGrpPrdSearch(conn, sessionHelper, mapping, form, request);
			} 
			if ("searchGP".equals(method)) {
				logger.info(LoggerConstants.methodEndLevel());
				return enrollGrpPrdSearch(conn, sessionHelper, mapping, form, request);
			} 
			if ("initEnrlPcpSearch".equals(method)) {
				logger.info(LoggerConstants.methodEndLevel());
				return initEnrollPcpSearch(conn, sessionHelper, mapping, form, request);
			}
			if ("searchPCP".equals(method)) {
				logger.info(LoggerConstants.methodEndLevel());
				return enrollPcpSearch(conn, sessionHelper, mapping, form, request);
			} 
			//IFOX-00399921 LTC Tab. START
			if ("initEnrlLtcSearch".equals(method)) {
				logger.info(LoggerConstants.methodEndLevel());
				return initEnrollLtcSearch(conn, sessionHelper, mapping, form, request);
			}
			if ("searchLTC".equals(method)) {
				logger.info(LoggerConstants.methodEndLevel());
				return enrollLtcSearch(conn, sessionHelper, mapping, form, request);
			} 
			//IFOX-00399921 LTC Tab. END
			
			
			/*IFOX-00427238 June 2020 CMS changes - start*/
			if ("trrDataSearch".equals(method)) {
				logger.info(LoggerConstants.methodEndLevel());
				return eemEnrollTrrData(conn, sessionHelper, mapping, form, request);
			}
			/*IFOX-00427238 June 2020 CMS changes - end*/
			
			
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//logger.error(e.getMessage());
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				//logger.error(e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward("eemError");
	}
	
	private ActionForward enrollGrpPrdSearch(Connection conn, SessionHelper sessionHelper, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollManager mgr = new EEMEnrollManager();	
		EEMEnrollGPSearchForm ff= (EEMEnrollGPSearchForm)form;
        ff.setProductName(ff.getProductName().replace("^", "+"));
		mgr.memberGrpPrdSearch(conn,sessionHelper,(EEMEnrollGPSearchForm)form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_ENROLL_GPSEARCH);
	}
	
	private ActionForward initEnrollGrpPrdSearch(Connection conn, SessionHelper sessionHelper, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollGPSearchForm gpSearchForm = (EEMEnrollGPSearchForm)form;
		gpSearchForm.setOutOfArea("lookup");
		
		String effStart = DateFormatter.reFormat(gpSearchForm.getEffStartDate(),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
		String effEnd = DateFormatter.reFormat(gpSearchForm.getEffEndDate(),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
		String effLookupDate = EEMGroupProduct.getNameLookupEffDate(gpSearchForm.getEnrollStatus(),effStart,effEnd);
		
		gpSearchForm.setEffDate(DateFormatter.reFormat(effLookupDate,DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
		logger.info(LoggerConstants.methodEndLevel());
		return enrollGrpPrdSearch(conn,sessionHelper,mapping,form,request);
	}

	private ActionForward initEnrollPcpSearch(Connection conn, SessionHelper sessionHelper, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollPcpSearchForm pcpSearchForm = (EEMEnrollPcpSearchForm)form;
		logger.info(LoggerConstants.methodEndLevel());
		return enrollPcpSearch(conn,sessionHelper,mapping,form,request);
	}
	
	private ActionForward enrollPcpSearch(Connection conn, SessionHelper sessionHelper, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollManager mgr = new EEMEnrollManager();		
		String memberId = request.getParameter("memberId"); //IFOX-414925 Network ID CR Changes
		mgr.memberPcpSearch(conn,sessionHelper,(EEMEnrollPcpSearchForm)form, memberId); //Updated memberid param IFOX-414925 Network ID CR Changes
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_ENROLL_PCPSEARCH);
	}
	//IFOX-00399921 LTC Tab. START
	private ActionForward initEnrollLtcSearch(Connection conn, SessionHelper sessionHelper, ActionMapping mapping,
			ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		return enrollLtcSearch(conn, sessionHelper, mapping, form, request);
	}

	private ActionForward enrollLtcSearch(Connection conn, SessionHelper sessionHelper, ActionMapping mapping,
			ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollManager mgr = new EEMEnrollManager();
		mgr.memberLtcSearch(conn, sessionHelper, (EEMEnrollLtcSearchForm) form);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_ENROLL_LTCSEARCH);
	}
	//IFOX-00399921 LTC Tab. END
	
	
	/*June 2020 CMS changes - start*/
	
	private ActionForward eemEnrollTrrData(Connection conn, SessionHelper sessionHelper, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		return enrollTrrDataSearch(conn,sessionHelper,mapping,form,request);
	}
	
	private ActionForward enrollTrrDataSearch(Connection conn, SessionHelper sessionHelper, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollManager mgr = new EEMEnrollManager();		
		mgr.memberTrrDataSearch(conn,sessionHelper,(EEMTrrDataForm) form); 
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_ENROLL_TRRDATA);
	}
	
	
	/*June 2020 CMS changes - End*/
}
