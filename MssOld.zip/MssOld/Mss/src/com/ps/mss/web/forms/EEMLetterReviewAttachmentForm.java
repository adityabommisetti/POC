package com.ps.mss.web.forms;

import java.util.Collection;
import java.util.List;

import org.apache.struts.upload.FormFile;

import com.ps.mss.dao.model.EmCorrMbrVO;
import com.ps.util.ListBoxItem;

public class EEMLetterReviewAttachmentForm extends EEMSubMenuForm {
	private String searchReqFromDate;
	private String searchReqToDate;
	private String searchBatchId;
	private String bacthId1;
	private String batchId;
	private String searchLetterName;
	private String description;
	private String changedLetterStatus;
	private boolean searchExpanded;
	private String letterName;	
	private List lstLetterNames;
	private List lstBatchId;
	private List listSearchResults;
	private String move;
	public String getMove() {
		return move;
	}
	public void setMove(String move) {
		this.move = move;
	}
	private int selectedSearchRow;
	private int topDisplay;
	private EmCorrMbrVO displayCorrMbr = new EmCorrMbrVO();
	
	
	public String getLetterName() {
		return letterName;
	}
	public void setLetterName(String letterName) {
		this.letterName = letterName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getBacthId1() {
		return bacthId1;
	}
	public void setBacthId1(String bacthId1) {
		this.bacthId1 = bacthId1;
	}
	public String getBatchId() {
		return batchId;
	}
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}
	public String getSearchReqFromDate() {
		return searchReqFromDate;
	}
	public void setSearchReqFromDate(String searchReqFromDate) {
		this.searchReqFromDate = searchReqFromDate;
	}
	public String getSearchReqToDate() {
		return searchReqToDate;
	}
	public void setSearchReqToDate(String searchReqToDate) {
		this.searchReqToDate = searchReqToDate;
	}
	public String getSearchBatchId() {
		return searchBatchId;
	}
	public void setSearchBatchId(String searchBatchId) {
		this.searchBatchId = searchBatchId;
	}
	public String getSearchLetterName() {
		return searchLetterName;
	}
	public void setSearchLetterName(String searchLetterName) {
		this.searchLetterName = searchLetterName;
	}
	public boolean isSearchExpanded() {
		return searchExpanded;
	}
	public void setSearchExpanded(boolean searchExpanded) {
		this.searchExpanded = searchExpanded;
	}
	public List getLstLetterNames() {
		return lstLetterNames;
	}
	public void setLstLetterNames(List lstLetterNames) {
		this.lstLetterNames = lstLetterNames;
	}
	public List getLstBatchId() {
		return lstBatchId;
	}
	public void setLstBatchId(List lstBatchId) {
		this.lstBatchId = lstBatchId;
	}
	public int getSelectedSearchRow() {
		return selectedSearchRow;
	}
	public void setSelectedSearchRow(int selectedSearchRow) {
		this.selectedSearchRow = selectedSearchRow;
	}
	public List getListSearchResults() {
		return listSearchResults;
	}
	public void setListSearchResults(List listSearchResults) {
		this.listSearchResults = listSearchResults;
	}
	public EmCorrMbrVO getDisplayCorrMbr() {
		return displayCorrMbr;
	}
	public void setDisplayCorrMbr(EmCorrMbrVO displayCorrMbr) {
		this.displayCorrMbr = displayCorrMbr;
	}
	public int getTopDisplay() {
		return topDisplay;
	}
	public void setTopDisplay(int topDisplay) {
		this.topDisplay = topDisplay;
	}
	public String getChangedLetterStatus() {
		return changedLetterStatus;
	}
	public void setChangedLetterStatus(String changedLetterStatus) {
		this.changedLetterStatus = changedLetterStatus;
	}
	private String searchType;
	private String searchId;
	public String getSearchType() {
		return searchType;
	}
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	public String getSearchId() {
		return searchId;
	}
	public void setSearchId(String searchId) {
		this.searchId = searchId;
	}
	
	private String fileName;
	private FormFile file;
	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	/**
	 * @return the file
	 */
	public FormFile getFile() {
		return file;
	}
	/**
	 * @param file the file to set
	 */
	public void setFile(FormFile file) {
		this.file = file;
	}
	private ListBoxItem [] arrSearchTypes;
	public ListBoxItem[] getArrSearchTypes() {
		return arrSearchTypes;
	}
	public void setArrSearchTypes(ListBoxItem[] arrSearchTypes) {
		this.arrSearchTypes = arrSearchTypes;
	}
	
	private String enableUpload;
	/**
	 * @return the enableUpload
	 */
	public String getEnableUpload() {
		return enableUpload;
	}
	/**
	 * @param enableUpload the enableUpload to set
	 */
	public void setEnableUpload(String enableUpload) {
		this.enableUpload = enableUpload;
	}
	private String customerId;
	private String userID;
	private String fileBatchId;
	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}
	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	/**
	 * @return the userID
	 */
	public String getUserID() {
		return userID;
	}
	/**
	 * @param userID the userID to set
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}
	/**
	 * @return the fileBatchId
	 */
	public String getFileBatchId() {
		return fileBatchId;
	}
	/**
	 * @param fileBatchId the fileBatchId to set
	 */
	public void setFileBatchId(String fileBatchId) {
		this.fileBatchId = fileBatchId;
	}
	private String name;
	private String mbi;


	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the mbi
	 */
	public String getMbi() {
		return mbi;
	}
	/**
	 * @param mbi the mbi to set
	 */
	public void setMbi(String mbi) {
		this.mbi = mbi;
	}
	private String uploadedFilePath;
	/**
	 * @return the uploadedFilePath
	 */
	public String getUploadedFilePath() {
		return uploadedFilePath;
	}
	/**
	 * @param uploadedFilePath the uploadedFilePath to set
	 */
	public void setUploadedFilePath(String uploadedFilePath) {
		this.uploadedFilePath = uploadedFilePath;
	}
	
}
