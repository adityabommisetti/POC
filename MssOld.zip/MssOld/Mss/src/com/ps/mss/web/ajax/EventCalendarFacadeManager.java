package com.ps.mss.web.ajax;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EventCalendarService;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.MedicareEventVOList;
import com.ps.mss.web.helper.AjaxHelper;

/**
 * @author Hemant
 *
 */
public class EventCalendarFacadeManager {
	private static Logger logger=LoggerFactory.getLogger(EventCalendarFacadeManager.class);
    
	/**
	 * This method creates object of  EventCalendarService to return an array of event objects.
	 * @author hemant
	 * @param month
	 * @param year
	 * @param action
	 * @return an array of event objects
	 * @throws ApplicationException
	 */
	public MedicareEventVOList getMedicareEventList(String month,String year,String action) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		AjaxHelper.validateUser();
		logger.info(LoggerConstants.methodEndLevel());
		return new EventCalendarService().getMedicareEventList(month,year,action);
	} 
	
	/**
	 * This method returns current date in YYYYMM format
	 * @author hemant
	 * @return 
	 * @throws ApplicationException
	 */
	public String getCurrentDate()throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		AjaxHelper.validateUser();
		logger.info(LoggerConstants.methodEndLevel());
		return new EventCalendarService().getCurrentDate();
	}
}
