/*
 * $Id: LettersActionDispatchHelper.java,v 1.1 2014/06/26 07:55:08 praveen Exp $
 */
package com.ps.mss.web.helper;

import java.sql.Connection;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.CodeCacheService;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.framework.LettersConstants;
import com.ps.mss.manager.LettersManager;
import com.ps.mss.model.LettersDashboardList;
import com.ps.mss.model.LettersFilter;
import com.ps.mss.model.Pagination;
import com.ps.mss.model.LettersContext;
import com.ps.mss.model.LettersItem;
import com.ps.mss.model.LettersListItem;
import com.ps.mss.web.forms.LettersForm;
import com.ps.util.DateUtil;
import com.ps.util.StringUtil;

public class LettersActionDispatchHelper {
	//static ModuleLog log = new ModuleLog("LettersActionDispatchHelper");
	private static Logger logger=LoggerFactory.getLogger(LettersActionDispatchHelper.class);

	public static void copyFromSessionToRequestLetters(LettersContext lc, HttpServletRequest request, SessionHelper sessionHelper) {
		 logger.info(LoggerConstants.methodStartLevel());
		 request.setAttribute(LettersConstants.LETTERS_CONTEXT, lc);
		request.setAttribute(Constants.SESSION_USER_ID, sessionHelper.getUserId());
		String custName = (String) sessionHelper.getAttribute(Constants.SESSION_CUSTOMER_NAME);
		request.setAttribute(Constants.SESSION_CUSTOMER_NAME, custName);
		 logger.info(LoggerConstants.methodEndLevel());
	}

	/**
	 * This function saves uiContext found in the form into LettersContext (which is stored in session). 
	 * @param lc  - LettersContext 
	 * @param lf - LettersForm
	 */
	public static void saveExpandedItemsLetters(LettersContext lc, String expandedListString, String pageName) {
		 logger.info(LoggerConstants.methodStartLevel());
		 List expandedList = null ;
		if (expandedListString != null  && !"".equals(expandedListString.trim())) {		
			String[] uiContext = expandedListString.split("\\|"); //need to escape it.
			if(uiContext != null) 
				expandedList = Arrays.asList(uiContext);
		}
	    if(LettersConstants.LETTERS_PAGE.equals(pageName)){
			/* This will be like "list", "detail", or "data" */
    		lc.setListExpanded(false);
    		lc.setDetailsExpanded(false);
    		lc.setDataExpanded(false);
			if (expandedList == null) return;
			Iterator it = expandedList.iterator();
			while(it.hasNext()) {
				String expandedItem = (String) it.next();
				if(LettersConstants.LETTERS_EXPANDABLE_LIST.equals(expandedItem)) 
					lc.setListExpanded(true);
				else if (LettersConstants.LETTERS_EXPANDABLE_DETAILS.equals(expandedItem))
					lc.setDetailsExpanded(true);
				else if(LettersConstants.LETTERS_EXPANDABLE_DATA.equals(expandedItem))
					lc.setDataExpanded(true);
			}		
		}
	    logger.info(LoggerConstants.methodEndLevel());
	}
	
	/**
 	 * TAB: Letters (Production/Model Office/Staging)
	 * Page: Letters Page - this is building the whole page.
     * @param request
     * @param lettersForm 
	 * @throws ApplicationException
     */
    public static void getLettersDashboard(Connection conn, HttpServletRequest request, LettersForm lettersForm, LettersContext context, boolean searchMode) throws ApplicationException {
    	 logger.info(LoggerConstants.methodStartLevel());
    	SessionHelper sessionHelper = new SessionHelper(request);
        String move = null;
        
        Pagination pagination = null;
        pagination = context.getDashboardPagination();
        
        //save the filter in the session
        LettersFilter filterVO = context.getDashboardFilter();
        if (!"tab".equals(lettersForm.getSearchType())) {
        	String errMsg = copyFilterFromForm(sessionHelper, context, lettersForm, filterVO, searchMode);
        	if (errMsg != null ) {
        		throw new ApplicationException(errMsg);
        	}
        	
            if (searchMode) {
            	pagination = new Pagination();
            	pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
            }
        } else {
        	move = "current";
        }
        
        if (pagination == null) {
        	pagination = new Pagination();
        	pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
        }
        context.setDashboardPagination(pagination);
        
        LettersDashboardList lettersDashboardList = LettersManager.getLettersDashboardList(conn, context, filterVO, move);
        lettersForm.setPageInfo(lettersDashboardList);
        logger.info(LoggerConstants.methodEndLevel());      				       
    }
	
	/**
 	 * TAB: Letters (Production/Model Office/Staging)
	 * Page: Letters Page - this is building the whole page.
     * @param request
     * @param lettersForm 
	 * @throws ApplicationException
     */
    public static void getLettersPage(Connection conn, HttpServletRequest request, LettersForm lettersForm, LettersContext context, boolean searchMode) throws ApplicationException {
    	 logger.info(LoggerConstants.methodStartLevel());
    	 SessionHelper sessionHelper = new SessionHelper(request);
        String move = null;
        
        Pagination pagination = null;
        pagination = context.getLettersPagination();
        
        //save the filter in the session
        LettersFilter filterVO = context.getLettersFilter();
        if (!"tab".equals(lettersForm.getSearchType())) {
        	if ("drill".equals(lettersForm.getSearchType())) {
        		lettersForm.setStatus(lettersForm.getDrillStatus());
        		lettersForm.setDeleteInd(lettersForm.getDrillDeleteInd());
        	}            
            String errMsg = copyFilterFromForm(sessionHelper, context, lettersForm, filterVO, searchMode);
            if (errMsg != null ) {
            	throw new ApplicationException(errMsg);
            }
            if (searchMode)
            	pagination = new Pagination();        
        }
        if (pagination == null)
        	pagination = new Pagination();
        context.setLettersPagination(pagination);
        	       
        String uiContextRange = null;
        if(request.getParameter("print") !=  null) {
        	//request for all kind of export
        	move = "current";
        	uiContextRange = request.getParameter("uiContextRange");
	        boolean list = context.isListExpanded();
	        boolean detail = context.isDetailsExpanded();
			boolean data = context.isDataExpanded();
 			if(Constants.CONSTANTS_ALL.equals(uiContextRange)){
				list = true; detail = false; data = false; //if "all" request, only display the list.
				CodeCacheService codeCache=new CodeCacheService();
				Integer maxRecordCount=codeCache.getMaxRecordCount();
				pagination.setMaxRecordCount(maxRecordCount.intValue());
				pagination.setAllPage(true);
				move = "first";
			}
			request.setAttribute("expandableItems", expandable(list, detail, data).toString());
   		}
        
        LettersListItem lettersListItem = LettersManager.getLettersListItem(conn, context, filterVO, move);
        lettersForm.setPageInfo(lettersListItem);
               
		if(request.getParameter("print") ==  null) { //not a print request
			setLettersPagination(pagination, lettersListItem, context);
			if (lettersListItem != null) 
				context.setLastLettersDetail(lettersListItem.getLettersDetailInfo());
		}
		// resetting MAX record count to 10, which may modified by print request with ALL
		pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
		pagination.setAllPage(false);
				       
        //Checking & correcting Request Date format
        checkLettersRequestDateFormat(lettersForm);
        logger.info(LoggerConstants.methodEndLevel());
    }
	
	public static String copyFilterFromForm(SessionHelper sessionHelper, LettersContext context, 
			                                LettersForm baseForm, LettersFilter filterVO, boolean searchMode) {
		 logger.info(LoggerConstants.methodStartLevel());
		 String result=null;
		if(searchMode) {
			/* Filter criteria changed only on the following conditions:
			 * 1. when action execute from go button.
			 */
			String temp;
			
			filterVO.setMfId(sessionHelper.getMfId());
			filterVO.setRegion(context.getRegion());
			filterVO.setSiteId(context.getSiteId());
			
			temp = StringUtil.trimToNull(baseForm.getFileId());
			if (temp != null && !StringUtil.isValidString(temp)){
				 logger.info(LoggerConstants.methodEndLevel());
				 return("Invalid File Id " + temp);
			}
			filterVO.setFileId(temp);

			temp = StringUtil.trimToNull(baseForm.getMemberId());
			if (temp != null && !StringUtil.isValidString(temp)){
				 logger.info(LoggerConstants.methodEndLevel());
				 return("Invalid Member Id " + temp);
			}
			filterVO.setMemberId(temp);
			
			temp = StringUtil.trimToNull(baseForm.getSupplementalId());
			if (temp != null && !StringUtil.isAlphaNumeric(temp)){
				 logger.info(LoggerConstants.methodEndLevel());
				 return("Invalid Alternate Id " + temp);
			}
			filterVO.setSupplementalId(temp);
			
			temp = StringUtil.trimToNull(baseForm.getRequestor());
			if (temp != null && !StringUtil.isAlphaNumeric(temp)){
				 logger.info(LoggerConstants.methodEndLevel());
				 return("Invalid Requestor " + temp);
			}
			filterVO.setRequestor(temp);
			
			temp = StringUtil.trimToNull(baseForm.getStatus());
			if (temp != null && !StringUtil.isAlphaNumeric(temp)){
				 logger.info(LoggerConstants.methodEndLevel());
				 return("Invalid Status " + temp);
			}
			filterVO.setStatus(temp);
			
			temp = StringUtil.trimToNull(baseForm.getDeleteInd());
			if (temp != null && !StringUtil.isAlphaNumeric(temp)){
				 logger.info(LoggerConstants.methodEndLevel());
				 return("Invalid Delete Indicator " + temp);
			}
			filterVO.setDeleteInd(temp);
			
			temp = StringUtil.trimToNull(baseForm.getRequestDateFrom());
			if (temp != null && !DateUtil.isGoodDate(temp)) {
				 logger.info(LoggerConstants.methodEndLevel());
				 return("Invalid From Date " + temp);
			}
			filterVO.setRequestDateFrom(temp);
			
			temp = StringUtil.trimToNull(baseForm.getRequestDateTo());
			if (temp != null && !DateUtil.isGoodDate(temp)) {
				 logger.info(LoggerConstants.methodEndLevel());
				 return("Invalid To Date " + temp);
			}
			filterVO.setRequestDateTo(temp);
			
			temp = StringUtil.trimToNull(baseForm.getLetterNbr());
			if (temp != null && !StringUtil.isAlphaNumeric(temp)) {
				 logger.info(LoggerConstants.methodEndLevel());
				 return("Invalid Letter# " + temp);
			}
			filterVO.setLetterNbr(temp);
			
		}
		 logger.info(LoggerConstants.methodEndLevel());
		return result;
	}
	
	/**
	 * This sets pagination which contain total number of page ,records , first and last record of Letters 
	 * @param pagination
	 * @param detailPage
	 * @param context
	 */
    private static void setLettersPagination(Pagination pagination, LettersListItem lettersListItem, LettersContext context) {
    	 logger.info(LoggerConstants.methodStartLevel());
    	 if(lettersListItem != null) {
        	LettersItem[] items = lettersListItem.getLettersItem();
            if(items != null ){
            	pagination.setFirstDetail(items[0]);
            	pagination.setLastDetail(items[items.length-1]);
            	pagination.setCurrentPage(lettersListItem.getCurrentPage());
            	pagination.setPageNumber(lettersListItem.getPageNumber());
                
            }
            context.setLettersPagination(pagination);
        }
    	 logger.info(LoggerConstants.methodEndLevel());
    }
	
	private static StringBuffer expandable(boolean list, boolean detail, boolean data) {
		 logger.info(LoggerConstants.methodStartLevel());
		 StringBuffer s = new StringBuffer("");
		s.append((list? LettersConstants.LETTERS_EXPANDABLE_LIST: ""))
		.append(detail?LettersConstants.LETTERS_EXPANDABLE_DETAILS:"")
		.append(data?LettersConstants.LETTERS_EXPANDABLE_DATA:"");
		 logger.info(LoggerConstants.methodEndLevel());
		return s;
	}
	
	/**
	 * Checking & correcting Service Date formate
	 * @param lettersForm
	 */
	private static void checkLettersRequestDateFormat(LettersForm lettersForm) {
		 logger.info(LoggerConstants.methodStartLevel());
		 String startDate = lettersForm.getRequestDateFrom();
		String endDate = lettersForm.getRequestDateTo(); 
		
		if(startDate != null && startDate.length() == 7 ){
			startDate = DateUtil.getFirstOrLastDayOfMonth(startDate, true);
			lettersForm.setRequestDateFrom(startDate);
		}
		
		if(endDate != null && endDate.length() == 7 ){
			endDate = DateUtil.getFirstOrLastDayOfMonth(endDate, false);
			lettersForm.setRequestDateTo(endDate);
		}
		 logger.info(LoggerConstants.methodEndLevel());
	}
}