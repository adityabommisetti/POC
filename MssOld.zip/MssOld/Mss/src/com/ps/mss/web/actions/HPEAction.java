/*
 * $Id: HPEAction.java,v 1.1 2014/06/26 07:56:48 praveen Exp $
 */
package com.ps.mss.web.actions;

import java.io.PrintWriter;
import java.sql.Connection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.HPEEncounterDao;
import com.ps.mss.dao.model.EncProvtypeVOs;
import com.ps.mss.dao.model.HpeSearchVO;
import com.ps.mss.db.CodeCache;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.ENCCodeCache;
import com.ps.mss.framework.ChartConstants;
import com.ps.mss.framework.HPEConstants;
import com.ps.mss.manager.HPEManager;
import com.ps.mss.model.HPEContext;
import com.ps.mss.model.Pagination;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.forms.HPEEncounterForm;
import com.ps.mss.web.helper.HPEInstHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.web.helper.Utility;
import com.ps.text.DateFormatter;
import com.ps.util.NameValuePair;
import com.ps.util.StringUtil;

/**
 * @author nenne.robert
 */
public class HPEAction extends Action {

	private static Logger logger=LoggerFactory.getLogger(HPEAction.class);
	private static Logger replogger=LoggerFactory.getLogger("reportsLogger");

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		long startTime = System.currentTimeMillis();
		Connection conn = null;
		HpeSearchVO searchVO = null;
		HpeSearchVO searchCRVO = null;
		String forward = HPEConstants.HPE_ERROR;
		String previousMethod = null, previousCRMethod = null;
		String requestStatus = "0";
		String valueChanged = "N";
		Pagination pagi = null;
		String oldPosition = null;
		String oldStateVal = null;
		String backCRFlag = "false";
		String claimRefNo = null;
		String claimType = null;
		String submitterId = null, clmType = null;
		String prevMethod = null;
		String prevMenu = null, strUrl = null, dateInd = null, mmpPlan = null;
		StringBuffer msg= new StringBuffer("");

		try {
			// get the session
			SessionHelper sessionHelper = new SessionHelper(request);

			// get a connection
			conn = DbConn.getConnection();

			// use the default DB for security check
			String errorMsg = sessionHelper.validateUser(conn);
			if (errorMsg != null) {
				request.setAttribute("Msg", "Login Has Timed Out");
				throw new Exception(errorMsg);
			}

			// re-get the connection in case the environment is different (QA,
			// etc.)
			conn = DbConn.reGetConnection(conn, (String) sessionHelper.getAttribute(SessionManager.HPEDB));

			mmpPlan = (String) sessionHelper.getAttribute("MMP");

			// get the context
			HPEContext context = HPEManager.getContext(sessionHelper.getSession());

			// get the form
			HPEEncounterForm hpeEncounterForm = (HPEEncounterForm) form;

			// get the method/menu
			String method = hpeEncounterForm.getMethod();
			String menu = hpeEncounterForm.getMenu();
			
			//Editable Fileds CHS -- IFOX-00395627
			if(StringUtils.isNotEmpty(method) &&  method.startsWith("editableClaimCodesSection")){
			//	int pos = method.indexOf("?");
				method=method;				
			}
			
			//Editable Fileds CHS -- IFOX-00395627
			
			if (request.getParameter("backCR") != null) {
				backCRFlag = request.getParameter("backCR");
			}

			int enumMethod = 0;
			if (!StringUtil.isNullOrEmpty(method)) {
				enumMethod = HPEConstants.getEnumMethod(method);
			}

			if (enumMethod == HPEConstants.ENUM_METHOD_SWITCHMENU) {
				previousCRMethod = (String) sessionHelper.getAttribute(ChartConstants.ENUM_CR_SUMM_METHOD);
				sessionHelper.setAttribute(ChartConstants.PREV_CR_SUMM_METHOD, previousCRMethod);

				previousCRMethod = null;
				previousCRMethod = (String) sessionHelper.getAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
				sessionHelper.setAttribute(ChartConstants.PREV_CR_DASH_METHOD, previousCRMethod);

				if (HPEConstants.MENU_DASHBOARD.equals(menu)) {
					method = (String) sessionHelper.getAttribute(HPEConstants.PREV_DASH_METHOD);
					if (method != null) {
						if (!StringUtil.isNullOrEmpty(method)) {
							enumMethod = HPEConstants.getEnumMethod(method);
						}
						previousMethod = (String) sessionHelper.getAttribute(HPEConstants.ENUM_SUMM_METHOD);
						sessionHelper.setAttribute(HPEConstants.PREV_SUMM_METHOD, previousMethod);

						searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
						if (searchVO != null) {
							if (searchVO.getIconFlag().equals("N")) {
								if (searchVO.getEncType().equals("I")) {
									searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
									searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
									searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
									searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
									searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
									searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
									searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
									searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
									searchVO.setClaimProvDetailExpanded(
											hpeEncounterForm.isInstClaimProvDetailExpanded());
									searchVO.setClaimOtherSubsProvExpanded(
											hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
									searchVO.setClaimOtherSubsProvDetailExpanded(
											hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
									searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
									searchVO.setClaimOtherSubsDetailExpanded(
											hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
									searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
									searchVO.setClaimLineDetailExpanded(
											hpeEncounterForm.isInstClaimLineDetailExpanded());
									searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
									searchVO.setClaimLineProvDetailExpanded(
											hpeEncounterForm.isInstClaimLineProvDetailExpanded());
									searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
									searchVO.setClaimLineAdjudDetailExpanded(
											hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());

								} else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")) {
									searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
									searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
									searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
									searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
									searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
									searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());
									searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
									searchVO.setClaimProvDetailExpanded(
											hpeEncounterForm.isProfClaimProvDetailExpanded());
									searchVO.setClaimOtherSubsProvExpanded(
											hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
									searchVO.setClaimOtherSubsProvDetailExpanded(
											hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
									searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
									searchVO.setClaimOtherSubsDetailExpanded(
											hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
									searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
									searchVO.setClaimLineDetailExpanded(
											hpeEncounterForm.isProfClaimLineDetailExpanded());
									searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
									searchVO.setClaimLineProvDetailExpanded(
											hpeEncounterForm.isProfClaimLineProvDetailExpanded());
									searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
									searchVO.setClaimLineAdjudDetailExpanded(
											hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
								}
							}
							// searchVO.setIconFlag("Y");
							sessionHelper.setAttribute(HPEConstants.SEARCH_ERROR_VO, searchVO);
						}
						requestStatus = "1";
					}
				}
				if (HPEConstants.MENU_SUMMARY.equals(menu)) {
					method = (String) sessionHelper.getAttribute(HPEConstants.PREV_SUMM_METHOD);
					if (method != null) {
						if (!StringUtil.isNullOrEmpty(method)) {
							enumMethod = HPEConstants.getEnumMethod(method);
						}

						previousMethod = (String) sessionHelper.getAttribute(HPEConstants.ENUM_DASH_METHOD);
						sessionHelper.setAttribute(HPEConstants.PREV_DASH_METHOD, previousMethod);
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
						if (searchVO != null) {
							if (searchVO.getIconFlag().equals("N")) {
								if (searchVO.getEncType().equals("I")) {
									searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
									searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
									searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
									searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
									searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
									searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
									searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
									searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
									searchVO.setClaimProvDetailExpanded(
											hpeEncounterForm.isInstClaimProvDetailExpanded());
									searchVO.setClaimOtherSubsProvExpanded(
											hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
									searchVO.setClaimOtherSubsProvDetailExpanded(
											hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
									searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
									searchVO.setClaimOtherSubsDetailExpanded(
											hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
									searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
									searchVO.setClaimLineDetailExpanded(
											hpeEncounterForm.isInstClaimLineDetailExpanded());
									searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
									searchVO.setClaimLineProvDetailExpanded(
											hpeEncounterForm.isInstClaimLineProvDetailExpanded());
									searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
									searchVO.setClaimLineAdjudDetailExpanded(
											hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());

								} else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")) {
									searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
									searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
									searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
									searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
									searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
									searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());
									searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
									searchVO.setClaimProvDetailExpanded(
											hpeEncounterForm.isProfClaimProvDetailExpanded());
									searchVO.setClaimOtherSubsProvExpanded(
											hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
									searchVO.setClaimOtherSubsProvDetailExpanded(
											hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
									searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
									searchVO.setClaimOtherSubsDetailExpanded(
											hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
									searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
									searchVO.setClaimLineDetailExpanded(
											hpeEncounterForm.isProfClaimLineDetailExpanded());
									searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
									searchVO.setClaimLineProvDetailExpanded(
											hpeEncounterForm.isProfClaimLineProvDetailExpanded());
									searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
									searchVO.setClaimLineAdjudDetailExpanded(
											hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
								}
							}
							// searchVO.setIconFlag("Y");
							sessionHelper.setAttribute(HPEConstants.SEARCH_ENCOUNTER_VO, searchVO);
						}
						requestStatus = "1";
					}
				}
			}

			switch (enumMethod) {
			case HPEConstants.ENUM_METHOD_INITIALIZE:
				HPEEncounterDao dao = new HPEEncounterDao();
				List lst = dao.getEDPSSubmitterList(conn, sessionHelper.getMfId());
				context.setOptionsSubmitters(lst);

				// These belong in application rather than session
				EncProvtypeVOs encProvtypes = dao.selectProviders(conn);

				context.setEncProvtypes(encProvtypes);
				// Set State List
				CodeCache cc = CodeCache.getInstance();
				context.setStateList(cc.getStateArr());
				ENCCodeCache encCC = ENCCodeCache.getInstance();
				context.setLstPlaceOfService(encCC.getLstPlaceOfService());
				context.setLstEntityType(encCC.getLstEntityType());

				context.setSelectedMenu(HPEConstants.MENU_DASHBOARD);
				context.setSelectedOption(HPEConstants.OPTION_DASHTREE);

				// Set Group Status List
				List groupList = encCC.getLstENCGroupStatus();
				context.setOptionsGroupStatus(groupList);

				List errorList = encCC.getLstENCErrorSource();
				context.setOptionsErrorSource(errorList);

				List errorGroup = encCC.getLstENCErrorGroup();
				context.setOptionsErrorGroup(errorGroup);

				List encTypeList = encCC.getLstENCEncType();
				context.setOptionsEncType(encTypeList);

				// v 1.3 Populate clmType i.e. EN/MD
				List clmTypeList = encCC.getLstClmType();
				context.setOptionsClmType(clmTypeList);

				// v 1.3 Populate clmType i.e. CR/MC
				List crClmTypeList = encCC.getCRLstClmType();
				context.setOptionsCRClmType(crClmTypeList);
				
				/* File Track Code - Start */
				List lobList = encCC.getLstLoB();
				context.setLobList(lobList);
				/* File Track Code - End */

				Pagination pg = context.getClaimDetailPagination();
				pg.setPageNumber(0);
				pg.setCurrentPage("current");

				// Delete all the HpeSearchVO objects from session
				sessionHelper.removeAttribute(HPEConstants.SEARCH_DASH_VO);
				sessionHelper.removeAttribute(HPEConstants.SEARCH_REJECT_VO);
				sessionHelper.removeAttribute(HPEConstants.SEARCH_VO);
				sessionHelper.removeAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
				sessionHelper.removeAttribute(HPEConstants.SEARCH_ERROR_VO);
				sessionHelper.removeAttribute(HPEConstants.DEFAULT_SEARCH_VO);
				sessionHelper.removeAttribute(HPEConstants.PREV_DASH_METHOD);
				sessionHelper.removeAttribute(HPEConstants.PREV_SUMM_METHOD);
				sessionHelper.removeAttribute(HPEConstants.ENUM_DASH_METHOD);
				sessionHelper.removeAttribute(HPEConstants.ENUM_SUMM_METHOD);

				sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_DASH_VO);
				sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_REJECT_VO);
				sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_VO);
				sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_ENCOUNTER_VO);
				sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_ERROR_VO);
				sessionHelper.removeAttribute(ChartConstants.DEFAULT_CR_SEARCH_VO);
				sessionHelper.removeAttribute(ChartConstants.PREV_CR_DASH_METHOD);
				sessionHelper.removeAttribute(ChartConstants.PREV_CR_SUMM_METHOD);
				sessionHelper.removeAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
				sessionHelper.removeAttribute(ChartConstants.ENUM_CR_SUMM_METHOD);
				sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_BACK_VO);
				sessionHelper.removeAttribute(ChartConstants.HPE_BACK);

				NameValuePair nvp = (NameValuePair) lst.get(0);
				hpeEncounterForm.setSearchSummarySubmitterId(nvp.getName());

				// Create VO to store the default screen data
				searchVO = new HpeSearchVO();
				searchVO.setSubmitterId(hpeEncounterForm.getSearchSummarySubmitterId());
				searchVO.setClmType(hpeEncounterForm.getSearchSummaryType());
				searchVO.setDateInd(hpeEncounterForm.getSearchSummaryDateInd());
				searchVO.setFromDate(hpeEncounterForm.getSearchSummaryFromDate());
				searchVO.setToDate(hpeEncounterForm.getSearchSummaryToDate());

				sessionHelper.setAttribute(HPEConstants.DEFAULT_SEARCH_VO, searchVO);

				// Create VO to store the default screen data for Chart Review
				searchCRVO = new HpeSearchVO();
				searchCRVO.setSubmitterId(hpeEncounterForm.getSearchSummarySubmitterId());
				searchCRVO.setClmType("CR");
				searchCRVO.setDateInd(hpeEncounterForm.getSearchSummaryDateInd());
				searchCRVO.setFromDate(hpeEncounterForm.getSearchSummaryFromDate());
				searchCRVO.setToDate(hpeEncounterForm.getSearchSummaryToDate());
				sessionHelper.setAttribute(ChartConstants.DEFAULT_CR_SEARCH_VO, searchCRVO);

				HPEInstHelper.buildStatusSummary(conn, sessionHelper, context, hpeEncounterForm, request);
				forward = HPEConstants.HPE_DASHBOARD;
				break;
			case HPEConstants.ENUM_METHOD_SWITCHMENU:
				if (HPEConstants.MENU_DASHBOARD.equals(menu)) {
					previousMethod = (String) sessionHelper.getAttribute(HPEConstants.ENUM_SUMM_METHOD);
					sessionHelper.setAttribute(HPEConstants.PREV_SUMM_METHOD, previousMethod);
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
					if (searchVO != null) {
						if (searchVO.getIconFlag().equals("N")) {
							if (searchVO.getEncType().equals("I")) {
								searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
								searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
								searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
								searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
								searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
								searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
								searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
								searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
								searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isInstClaimProvDetailExpanded());
								searchVO.setClaimOtherSubsProvExpanded(
										hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
								searchVO.setClaimOtherSubsProvDetailExpanded(
										hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
								searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
								searchVO.setClaimOtherSubsDetailExpanded(
										hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
								searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
								searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isInstClaimLineDetailExpanded());
								searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
								searchVO.setClaimLineProvDetailExpanded(
										hpeEncounterForm.isInstClaimLineProvDetailExpanded());
								searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
								searchVO.setClaimLineAdjudDetailExpanded(
										hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());

							} else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")) {
								searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
								searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
								searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
								searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
								searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
								searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());
								searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
								searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isProfClaimProvDetailExpanded());
								searchVO.setClaimOtherSubsProvExpanded(
										hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
								searchVO.setClaimOtherSubsProvDetailExpanded(
										hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
								searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
								searchVO.setClaimOtherSubsDetailExpanded(
										hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
								searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
								searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isProfClaimLineDetailExpanded());
								searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
								searchVO.setClaimLineProvDetailExpanded(
										hpeEncounterForm.isProfClaimLineProvDetailExpanded());
								searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
								searchVO.setClaimLineAdjudDetailExpanded(
										hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
							}
						}
						// searchVO.setIconFlag("Y");
						sessionHelper.setAttribute(HPEConstants.SEARCH_ERROR_VO, searchVO);
					}

					context.setSelectedMenu(HPEConstants.MENU_DASHBOARD);
					context.setSelectedOption(HPEConstants.OPTION_DASHTREE);
					HPEInstHelper.buildStatusSummary(conn, sessionHelper, context, hpeEncounterForm, request);
					forward = HPEConstants.HPE_DASHTREE;
					long endTime = System.currentTimeMillis();
					replogger.debug("EDPS|Dashboard|"+"|"+(endTime - startTime)+" ms|");
					
				}
				if (HPEConstants.MENU_SUMMARY.equals(menu)) {
					previousMethod = (String) sessionHelper.getAttribute(HPEConstants.ENUM_DASH_METHOD);
					sessionHelper.setAttribute(HPEConstants.PREV_DASH_METHOD, previousMethod);
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
					if (searchVO != null) {
						if (searchVO.getIconFlag().equals("N")) {
							if (searchVO.getEncType().equals("I")) {
								searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
								searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
								searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
								searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
								searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
								searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
								searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
								searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
								searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isInstClaimProvDetailExpanded());
								searchVO.setClaimOtherSubsProvExpanded(
										hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
								searchVO.setClaimOtherSubsProvDetailExpanded(
										hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
								searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
								searchVO.setClaimOtherSubsDetailExpanded(
										hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
								searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
								searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isInstClaimLineDetailExpanded());
								searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
								searchVO.setClaimLineProvDetailExpanded(
										hpeEncounterForm.isInstClaimLineProvDetailExpanded());
								searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
								searchVO.setClaimLineAdjudDetailExpanded(
										hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());

							} else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")) {
								searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
								searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
								searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
								searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
								searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
								searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());
								searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
								searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isProfClaimProvDetailExpanded());
								searchVO.setClaimOtherSubsProvExpanded(
										hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
								searchVO.setClaimOtherSubsProvDetailExpanded(
										hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
								searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
								searchVO.setClaimOtherSubsDetailExpanded(
										hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
								searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
								searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isProfClaimLineDetailExpanded());
								searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
								searchVO.setClaimLineProvDetailExpanded(
										hpeEncounterForm.isProfClaimLineProvDetailExpanded());
								searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
								searchVO.setClaimLineAdjudDetailExpanded(
										hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
							}
						}
						// searchVO.setIconFlag("Y");
						sessionHelper.setAttribute(HPEConstants.SEARCH_ENCOUNTER_VO, searchVO);
					}
					context.setSelectedMenu(HPEConstants.MENU_SUMMARY);
					context.setSelectedOption(HPEConstants.OPTION_SUMMTREE);
					HPEInstHelper.buildErrorStatusSummary(conn, sessionHelper, context, hpeEncounterForm, request);
					forward = HPEConstants.HPE_SUMMTREE;
					long endTime = System.currentTimeMillis();
					replogger.debug("EDPS|EDPS Summary|"+"|"+(endTime - startTime)+" ms|");
					
				}
				break;
			case HPEConstants.ENUM_METHOD_DASHTREEOPTION:
				sessionHelper.setAttribute(HPEConstants.ENUM_DASH_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_DASHBOARD);
				context.setSelectedOption(HPEConstants.OPTION_DASHTREE);
				if ("0".equals(requestStatus)) {
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
					if (searchVO != null) {
						if (searchVO.getIconFlag().equals("N")) {
							if (searchVO.getEncType().equals("I")) {
								searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
								searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
								searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
								searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
								searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
								searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
								searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
								searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
								searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isInstClaimProvDetailExpanded());
								searchVO.setClaimOtherSubsProvExpanded(
										hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
								searchVO.setClaimOtherSubsProvDetailExpanded(
										hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
								searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
								searchVO.setClaimOtherSubsDetailExpanded(
										hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
								searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
								searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isInstClaimLineDetailExpanded());
								searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
								searchVO.setClaimLineProvDetailExpanded(
										hpeEncounterForm.isInstClaimLineProvDetailExpanded());
								searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
								searchVO.setClaimLineAdjudDetailExpanded(
										hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());

							} else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")) {
								searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
								searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
								searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
								searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
								searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
								searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());
								searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
								searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isProfClaimProvDetailExpanded());
								searchVO.setClaimOtherSubsProvExpanded(
										hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
								searchVO.setClaimOtherSubsProvDetailExpanded(
										hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
								searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
								searchVO.setClaimOtherSubsDetailExpanded(
										hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
								searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
								searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isProfClaimLineDetailExpanded());
								searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
								searchVO.setClaimLineProvDetailExpanded(
										hpeEncounterForm.isProfClaimLineProvDetailExpanded());
								searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
								searchVO.setClaimLineAdjudDetailExpanded(
										hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
							}
							searchVO.setIconFlag("Y");
						}
						sessionHelper.setAttribute(HPEConstants.SEARCH_ENCOUNTER_VO, searchVO);
					}
				}
				HPEInstHelper.buildStatusSummary(conn, sessionHelper, context, hpeEncounterForm, request);
				forward = HPEConstants.HPE_DASHTREE;
				break;
			case HPEConstants.ENUM_METHOD_DASHDETAILOPTION:
				sessionHelper.setAttribute(HPEConstants.ENUM_DASH_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_DASHBOARD);
				context.setSelectedOption(HPEConstants.OPTION_DASHINSTDETAIL);
				requestStatus = "0";
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
				if (searchVO != null) {
					searchVO.setIconFlag("N");
					sessionHelper.setAttribute(HPEConstants.SEARCH_ENCOUNTER_VO, searchVO);
				}
				forward = HPEInstHelper.selectClaims(conn, sessionHelper, context, hpeEncounterForm, request,
						requestStatus);
				break;
			case HPEConstants.ENUM_METHOD_DASHTREESEARCH:
				sessionHelper.setAttribute(HPEConstants.ENUM_DASH_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_DASHBOARD);
				context.setSelectedOption(HPEConstants.OPTION_DASHTREE);

				if ("0".equals(requestStatus)) {
					// Delete the default VO and recreate the new one to store
					// the search criterias
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_DASH_VO);
					if (searchVO != null) {
						sessionHelper.removeAttribute(HPEConstants.SEARCH_DASH_VO);
					}

					searchVO = new HpeSearchVO();
					searchVO.setSubmitterId(hpeEncounterForm.getSearchSummarySubmitterId());
					searchVO.setDateInd(hpeEncounterForm.getSearchSummaryDateInd());
					searchVO.setFromDate(hpeEncounterForm.getSearchSummaryFromDate());
					searchVO.setToDate(hpeEncounterForm.getSearchSummaryToDate());
					searchVO.setClmType(hpeEncounterForm.getSearchSummaryType());

					sessionHelper.setAttribute(HPEConstants.SEARCH_DASH_VO, searchVO);
				}

				HPEInstHelper.buildStatusSummary(conn, sessionHelper, context, hpeEncounterForm, request);
				forward = HPEConstants.HPE_DASHTREE;
				break;
			case HPEConstants.ENUM_METHOD_DASHINSTMONTH:
				sessionHelper.setAttribute(HPEConstants.ENUM_DASH_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_DASHBOARD);
				context.setSelectedOption(HPEConstants.OPTION_DASHINSTDETAIL);

				if (backCRFlag.equalsIgnoreCase("false")) {
					if ("0".equals(requestStatus)) {
						hpeEncounterForm.setSearchDetailSubmitterId(hpeEncounterForm.getSearchSummarySubmitterId());
						hpeEncounterForm.setSearchDetailClmType(hpeEncounterForm.getSearchSummaryType());
						hpeEncounterForm.setSearchDetailEncType(hpeEncounterForm.getSearchSummaryEncType());
						hpeEncounterForm.setSearchDetailDateInd(hpeEncounterForm.getSearchSummaryDateInd());
						hpeEncounterForm.setSelectedDateYrmo(hpeEncounterForm.getSelectedDateYrmo());
						hpeEncounterForm.setSearchDetailFromDate(
								DateFormatter.reFormat(hpeEncounterForm.getSearchSummaryFromDate(),
										DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_START));
						hpeEncounterForm
								.setSearchDetailToDate(DateFormatter.reFormat(hpeEncounterForm.getSearchSummaryToDate(),
										DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_END));
						hpeEncounterForm.setSearchDetailGroupStatus(hpeEncounterForm.getSearchSummaryGroupStatus());

						/*
						 * Create the VO to store the data of the user selected
						 * row of the EDPS dashboard It will be used, when user
						 * wants to view the previuos screen data
						 */
						searchVO = new HpeSearchVO();
						searchVO.setSubmitterId(hpeEncounterForm.getSearchSummarySubmitterId());
						searchVO.setEncType(hpeEncounterForm.getSearchSummaryEncType());
						searchVO.setClmType(hpeEncounterForm.getSearchSummaryType());
						searchVO.setDateInd(hpeEncounterForm.getSearchSummaryDateInd());
						searchVO.setSelectedDate(hpeEncounterForm.getSelectedDateYrmo());
						searchVO.setFromDate(DateFormatter.reFormat(hpeEncounterForm.getSearchSummaryFromDate(),
								DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_START));
						searchVO.setToDate(DateFormatter.reFormat(hpeEncounterForm.getSearchSummaryToDate(),
								DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_END));
						searchVO.setGroupStatus(hpeEncounterForm.getSearchSummaryGroupStatus());

						sessionHelper.setAttribute(HPEConstants.SEARCH_ENCOUNTER_VO, searchVO);
					}
				} else {
					sessionHelper.removeAttribute(ChartConstants.HPE_BACK);
					sessionHelper.removeAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_BACK_VO);
					sessionHelper.removeAttribute(ChartConstants.PREV_CR_DASH_METHOD);
				}
				requestStatus = "0";
				forward = HPEInstHelper.selectClaims(conn, sessionHelper, context, hpeEncounterForm, request,
						requestStatus);
				break;
			case HPEConstants.ENUM_METHOD_DASHDETAILSEARCH:
				sessionHelper.setAttribute(HPEConstants.ENUM_DASH_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_DASHBOARD);
				context.setSelectedOption(HPEConstants.OPTION_DASHINSTDETAIL);

				if (backCRFlag.equalsIgnoreCase("false")) {
					if ("0".equals(requestStatus)) {
						// Delete the default VO and recreate the new one to
						// store the search criterias
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
						if (searchVO != null) {
							sessionHelper.removeAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
						}

						hpeEncounterForm.setSubscriberDisplayState(HPEConstants.HPE_SCREEN_VIEW);
						hpeEncounterForm.setClaimDisplayState(HPEConstants.HPE_SCREEN_VIEW);
						hpeEncounterForm.setProviderDisplayState(HPEConstants.HPE_SCREEN_VIEW);
						hpeEncounterForm.setClmProviderDisplayState(HPEConstants.HPE_SCREEN_VIEW);

						searchVO = new HpeSearchVO();
						searchVO.setSubmitterId(hpeEncounterForm.getSearchDetailSubmitterId());
						searchVO.setClmType(hpeEncounterForm.getSearchDetailClmType());
						searchVO.setEncType(hpeEncounterForm.getSearchDetailEncType());
						searchVO.setDateInd(hpeEncounterForm.getSearchDetailDateInd());
						searchVO.setFromDate(hpeEncounterForm.getSearchDetailFromDate());
						searchVO.setToDate(hpeEncounterForm.getSearchDetailToDate());
						searchVO.setGroupStatus(hpeEncounterForm.getSearchDetailGroupStatus());
						searchVO.setErrorCode(hpeEncounterForm.getSearchDetailErrorCode());
						searchVO.setErrorGroup(hpeEncounterForm.getSearchDetailErrorGroup());
						searchVO.setErrorSource(hpeEncounterForm.getSearchDetailErrorSource());
						searchVO.setClaimRefNbr(hpeEncounterForm.getSearchDetailClaimRefNbr());
						searchVO.setHicNbr(hpeEncounterForm.getSearchDetailHicNbr());
						
						//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : Start
						searchVO.setMaoflag(hpeEncounterForm.getMaoflag());
						//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : End
						
						//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - Start
						searchVO.setPayerSecId(hpeEncounterForm.getSearchPayerSecId());
						searchVO.setSubsGrpOrPolNbr(hpeEncounterForm.getSearchSubsGrpOrPolNbr());
						//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - End
						if (hpeEncounterForm.getSearchDetailEncType().equals("I")) {
							searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
							searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
							searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
							searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
							searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
							searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
							searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
							searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isInstClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(
									hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(
									hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isInstClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(
									hpeEncounterForm.isInstClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(
									hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());
						} else if (hpeEncounterForm.getSearchDetailEncType().equals("P") || hpeEncounterForm.getSearchDetailEncType().equals("E")) {
							searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
							searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
							searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
							searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
							searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
							searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());
							searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isProfClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(
									hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(
									hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isProfClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(
									hpeEncounterForm.isProfClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(
									hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
						}
						sessionHelper.setAttribute(HPEConstants.SEARCH_ENCOUNTER_VO, searchVO);
					}
				} else {
					sessionHelper.removeAttribute(ChartConstants.HPE_BACK);
					sessionHelper.removeAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_BACK_VO);
					sessionHelper.removeAttribute(ChartConstants.PREV_CR_DASH_METHOD);
				}
				requestStatus = "0";
				forward = HPEInstHelper.selectClaims(conn, sessionHelper, context, hpeEncounterForm, request,
						requestStatus);
				break;
			case HPEConstants.ENUM_METHOD_SUMMDETAILSEARCH:
				sessionHelper.setAttribute(HPEConstants.ENUM_SUMM_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_SUMMARY);
				context.setSelectedOption(HPEConstants.OPTION_SUMMINSTDETAIL);

				if (backCRFlag.equalsIgnoreCase("false")) {
					if ("0".equals(requestStatus)) {
						// Delete the default VO and recreate the new one to
						// store the search criterias
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
						if (searchVO != null) {
							sessionHelper.removeAttribute(HPEConstants.SEARCH_ERROR_VO);
						}

						searchVO = new HpeSearchVO();
						searchVO.setSubmitterId(hpeEncounterForm.getSearchDetailSubmitterId());
						searchVO.setClmType(hpeEncounterForm.getSearchDetailClmType());
						searchVO.setEncType(hpeEncounterForm.getSearchDetailEncType());
						searchVO.setDateInd(hpeEncounterForm.getSearchDetailDateInd());
						searchVO.setFromDate(hpeEncounterForm.getSearchDetailFromDate());
						searchVO.setToDate(hpeEncounterForm.getSearchDetailToDate());
						searchVO.setGroupStatus(hpeEncounterForm.getSearchDetailGroupStatus());
						searchVO.setErrorCode(hpeEncounterForm.getSearchDetailErrorCode());
						searchVO.setErrorGroup(hpeEncounterForm.getSearchDetailErrorGroup());
						searchVO.setErrorSource(hpeEncounterForm.getSearchDetailErrorSource());
						searchVO.setClaimRefNbr(hpeEncounterForm.getSearchDetailClaimRefNbr());
						searchVO.setHicNbr(hpeEncounterForm.getSearchDetailHicNbr());
						
						//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : Start
						searchVO.setMaoflag(hpeEncounterForm.getMaoflag());
						//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : End
						
						//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - Start
						searchVO.setPayerSecId(hpeEncounterForm.getSearchPayerSecId());
						searchVO.setSubsGrpOrPolNbr(hpeEncounterForm.getSearchSubsGrpOrPolNbr());
						//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - End
						
						if (hpeEncounterForm.getSearchDetailEncType().equals("I")) {
							searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
							searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
							searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
							searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
							searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
							searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
							searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
							searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isInstClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(
									hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(
									hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isInstClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(
									hpeEncounterForm.isInstClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(
									hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());
						} else if (hpeEncounterForm.getSearchDetailEncType().equals("P") || hpeEncounterForm.getSearchDetailEncType().equals("E")) {
							searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
							searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
							searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
							searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
							searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
							searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());
							searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isProfClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(
									hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(
									hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isProfClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(
									hpeEncounterForm.isProfClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(
									hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
						}
						sessionHelper.setAttribute(HPEConstants.SEARCH_ERROR_VO, searchVO);
					}
				} else {
					sessionHelper.removeAttribute(ChartConstants.HPE_BACK);
					sessionHelper.removeAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_BACK_VO);
					sessionHelper.removeAttribute(ChartConstants.PREV_CR_DASH_METHOD);
				}
				requestStatus = "1";
				forward = HPEInstHelper.selectClaims(conn, sessionHelper, context, hpeEncounterForm, request,
						requestStatus);
				break;
			case HPEConstants.ENUM_METHOD_DASH_DETAIL_PAGE_FIRST:
				sessionHelper.setAttribute(HPEConstants.ENUM_DASH_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_DASHBOARD);
				context.setSelectedOption(HPEConstants.OPTION_DASHINSTDETAIL);
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
				pagi = new Pagination();
				if (backCRFlag.equalsIgnoreCase("false")) {
					if ("0".equals(requestStatus)) {
						valueChanged = "Y";
						searchVO.setClaimDetailPagination(context.getClaimDetailPagination());
						searchVO.setMove("first");
						searchVO.setOldState("false");
					}
				} else {
					sessionHelper.removeAttribute(ChartConstants.HPE_BACK);
					sessionHelper.removeAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_BACK_VO);
					sessionHelper.removeAttribute(ChartConstants.PREV_CR_DASH_METHOD);
				}
				requestStatus = "0";
				forward = HPEInstHelper.pageClaims(conn, sessionHelper, context, hpeEncounterForm, request, "first",
						requestStatus);
				if ("Y".equals(valueChanged)) {
					searchVO.setOldState("true");
					// Create replica of pagination object
					pagi.setCurrentPage(context.getClaimDetailPagination().getCurrentPage());
					pagi.setPageNumber(context.getClaimDetailPagination().getPageNumber());
					pagi.setFirstDetail(context.getClaimDetailPagination().getFirstDetail());
					pagi.setLastDetail(context.getClaimDetailPagination().getLastDetail());
					pagi.setPageHistory(context.getClaimDetailPagination().getPageHistory());
					pagi.setMaxRecordCount(context.getClaimDetailPagination().getMaxRecordCount());
					pagi.setRecordCount(context.getClaimDetailPagination().getRecordCount());
					pagi.setPageRecordCount(context.getClaimDetailPagination().getPageRecordCount());
					// End
					searchVO.setClaimDetailPagination(pagi);
					searchVO.setSelectedClaimType("");
					searchVO.setSelectedClaimRefNbr("");
					searchVO.setSelectedClaimRevNbr("");
					searchVO.setSelectedClaimSeqNbr("");
				}
				searchVO.setIconFlag("N");
				sessionHelper.setAttribute(HPEConstants.SEARCH_ENCOUNTER_VO, searchVO);
				break;
			case HPEConstants.ENUM_METHOD_DASH_DETAIL_PAGE_PREV:
				sessionHelper.setAttribute(HPEConstants.ENUM_DASH_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_DASHBOARD);
				context.setSelectedOption(HPEConstants.OPTION_DASHINSTDETAIL);
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
				pagi = new Pagination();
				if (backCRFlag.equalsIgnoreCase("false")) {
					if ("0".equals(requestStatus)) {
						valueChanged = "Y";
						searchVO.setClaimDetailPagination(context.getClaimDetailPagination());
						searchVO.setMove("previous");
						searchVO.setOldState("false");
					}
				} else {
					sessionHelper.removeAttribute(ChartConstants.HPE_BACK);
					sessionHelper.removeAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_BACK_VO);
					sessionHelper.removeAttribute(ChartConstants.PREV_CR_DASH_METHOD);
				}
				requestStatus = "0";
				forward = HPEInstHelper.pageClaims(conn, sessionHelper, context, hpeEncounterForm, request, "previous",
						requestStatus);
				if ("Y".equals(valueChanged)) {
					searchVO.setOldState("true");
					// Create replica of pagination object
					pagi.setCurrentPage(context.getClaimDetailPagination().getCurrentPage());
					pagi.setPageNumber(context.getClaimDetailPagination().getPageNumber());
					pagi.setFirstDetail(context.getClaimDetailPagination().getFirstDetail());
					pagi.setLastDetail(context.getClaimDetailPagination().getLastDetail());
					pagi.setPageHistory(context.getClaimDetailPagination().getPageHistory());
					pagi.setMaxRecordCount(context.getClaimDetailPagination().getMaxRecordCount());
					pagi.setRecordCount(context.getClaimDetailPagination().getRecordCount());
					pagi.setPageRecordCount(context.getClaimDetailPagination().getPageRecordCount());
					// End
					searchVO.setClaimDetailPagination(pagi);
					searchVO.setSelectedClaimType("");
					searchVO.setSelectedClaimRefNbr("");
					searchVO.setSelectedClaimRevNbr("");
					searchVO.setSelectedClaimSeqNbr("");
				}
				searchVO.setIconFlag("N");
				sessionHelper.setAttribute(HPEConstants.SEARCH_ENCOUNTER_VO, searchVO);
				break;
			case HPEConstants.ENUM_METHOD_DASH_DETAIL_PAGE_NEXT:
				sessionHelper.setAttribute(HPEConstants.ENUM_DASH_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_DASHBOARD);
				context.setSelectedOption(HPEConstants.OPTION_DASHINSTDETAIL);
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
				pagi = new Pagination();
				if (backCRFlag.equalsIgnoreCase("false")) {
					if ("0".equals(requestStatus)) {
						valueChanged = "Y";
						searchVO.setClaimDetailPagination(context.getClaimDetailPagination());
						searchVO.setMove("next");
						searchVO.setOldState("false");
					}
				} else {
					sessionHelper.removeAttribute(ChartConstants.HPE_BACK);
					sessionHelper.removeAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_BACK_VO);
					sessionHelper.removeAttribute(ChartConstants.PREV_CR_DASH_METHOD);
				}
				requestStatus = "0";
				forward = HPEInstHelper.pageClaims(conn, sessionHelper, context, hpeEncounterForm, request, "next",
						requestStatus);
				if ("Y".equals(valueChanged)) {
					searchVO.setOldState("true");
					// Create replica of pagination object
					pagi.setCurrentPage(context.getClaimDetailPagination().getCurrentPage());
					pagi.setPageNumber(context.getClaimDetailPagination().getPageNumber());
					pagi.setFirstDetail(context.getClaimDetailPagination().getFirstDetail());
					pagi.setLastDetail(context.getClaimDetailPagination().getLastDetail());
					pagi.setPageHistory(context.getClaimDetailPagination().getPageHistory());
					pagi.setMaxRecordCount(context.getClaimDetailPagination().getMaxRecordCount());
					pagi.setRecordCount(context.getClaimDetailPagination().getRecordCount());
					pagi.setPageRecordCount(context.getClaimDetailPagination().getPageRecordCount());
					// End
					searchVO.setClaimDetailPagination(pagi);
					searchVO.setSelectedClaimType("");
					searchVO.setSelectedClaimRefNbr("");
					searchVO.setSelectedClaimRevNbr("");
					searchVO.setSelectedClaimSeqNbr("");
				}
				searchVO.setIconFlag("N");
				sessionHelper.setAttribute(HPEConstants.SEARCH_ENCOUNTER_VO, searchVO);
				break;
			case HPEConstants.ENUM_METHOD_SUMM_DETAIL_PAGE_FIRST:
				sessionHelper.setAttribute(HPEConstants.ENUM_SUMM_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_SUMMARY);
				context.setSelectedOption(HPEConstants.OPTION_SUMMINSTDETAIL);
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
				pagi = new Pagination();
				if (backCRFlag.equalsIgnoreCase("false")) {
					if ("0".equals(requestStatus)) {
						valueChanged = "Y";
						searchVO.setClaimDetailPagination(context.getClaimDetailPagination());
						searchVO.setMove("first");
						searchVO.setOldState("false");
					}
				} else {
					sessionHelper.removeAttribute(ChartConstants.HPE_BACK);
					sessionHelper.removeAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_BACK_VO);
					sessionHelper.removeAttribute(ChartConstants.PREV_CR_DASH_METHOD);
				}
				requestStatus = "1";
				forward = HPEInstHelper.pageClaims(conn, sessionHelper, context, hpeEncounterForm, request, "first",
						requestStatus);
				if ("Y".equals(valueChanged)) {
					searchVO.setOldState("true");
					// Create replica of pagination object
					pagi.setCurrentPage(context.getClaimDetailPagination().getCurrentPage());
					pagi.setPageNumber(context.getClaimDetailPagination().getPageNumber());
					pagi.setFirstDetail(context.getClaimDetailPagination().getFirstDetail());
					pagi.setLastDetail(context.getClaimDetailPagination().getLastDetail());
					pagi.setPageHistory(context.getClaimDetailPagination().getPageHistory());
					pagi.setMaxRecordCount(context.getClaimDetailPagination().getMaxRecordCount());
					pagi.setRecordCount(context.getClaimDetailPagination().getRecordCount());
					pagi.setPageRecordCount(context.getClaimDetailPagination().getPageRecordCount());
					// End
					searchVO.setClaimDetailPagination(pagi);
					searchVO.setSelectedClaimType("");
					searchVO.setSelectedClaimRefNbr("");
					searchVO.setSelectedClaimRevNbr("");
					searchVO.setSelectedClaimSeqNbr("");
				}
				searchVO.setIconFlag("N");
				sessionHelper.setAttribute(HPEConstants.SEARCH_ERROR_VO, searchVO);
				break;
			case HPEConstants.ENUM_METHOD_SUMM_DETAIL_PAGE_PREV:
				sessionHelper.setAttribute(HPEConstants.ENUM_SUMM_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_SUMMARY);
				context.setSelectedOption(HPEConstants.OPTION_SUMMINSTDETAIL);
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
				pagi = new Pagination();
				if (backCRFlag.equalsIgnoreCase("false")) {
					if ("0".equals(requestStatus)) {
						valueChanged = "Y";
						searchVO.setClaimDetailPagination(context.getClaimDetailPagination());
						searchVO.setMove("previous");
						searchVO.setOldState("false");
					}
				} else {
					sessionHelper.removeAttribute(ChartConstants.HPE_BACK);
					sessionHelper.removeAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_BACK_VO);
					sessionHelper.removeAttribute(ChartConstants.PREV_CR_DASH_METHOD);
				}
				requestStatus = "1";
				forward = HPEInstHelper.pageClaims(conn, sessionHelper, context, hpeEncounterForm, request, "previous",
						requestStatus);
				if ("Y".equals(valueChanged)) {
					searchVO.setOldState("true");
					// Create replica of pagination object
					pagi.setCurrentPage(context.getClaimDetailPagination().getCurrentPage());
					pagi.setPageNumber(context.getClaimDetailPagination().getPageNumber());
					pagi.setFirstDetail(context.getClaimDetailPagination().getFirstDetail());
					pagi.setLastDetail(context.getClaimDetailPagination().getLastDetail());
					pagi.setPageHistory(context.getClaimDetailPagination().getPageHistory());
					pagi.setMaxRecordCount(context.getClaimDetailPagination().getMaxRecordCount());
					pagi.setRecordCount(context.getClaimDetailPagination().getRecordCount());
					pagi.setPageRecordCount(context.getClaimDetailPagination().getPageRecordCount());
					// End
					searchVO.setClaimDetailPagination(pagi);
					searchVO.setSelectedClaimType("");
					searchVO.setSelectedClaimRefNbr("");
					searchVO.setSelectedClaimRevNbr("");
					searchVO.setSelectedClaimSeqNbr("");
				}
				searchVO.setIconFlag("N");
				sessionHelper.setAttribute(HPEConstants.SEARCH_ERROR_VO, searchVO);
				break;
			case HPEConstants.ENUM_METHOD_SUMM_DETAIL_PAGE_NEXT:
				sessionHelper.setAttribute(HPEConstants.ENUM_SUMM_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_SUMMARY);
				context.setSelectedOption(HPEConstants.OPTION_SUMMINSTDETAIL);
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
				pagi = new Pagination();
				if (backCRFlag.equalsIgnoreCase("false")) {
					if ("0".equals(requestStatus)) {
						valueChanged = "Y";
						searchVO.setClaimDetailPagination(context.getClaimDetailPagination());
						searchVO.setMove("next");
						searchVO.setOldState("false");
					}
				} else {
					sessionHelper.removeAttribute(ChartConstants.HPE_BACK);
					sessionHelper.removeAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_BACK_VO);
					sessionHelper.removeAttribute(ChartConstants.PREV_CR_DASH_METHOD);
				}
				requestStatus = "1";
				forward = HPEInstHelper.pageClaims(conn, sessionHelper, context, hpeEncounterForm, request, "next",
						requestStatus);
				if ("Y".equals(valueChanged)) {
					searchVO.setOldState("true");
					// Create replica of pagination object
					pagi.setCurrentPage(context.getClaimDetailPagination().getCurrentPage());
					pagi.setPageNumber(context.getClaimDetailPagination().getPageNumber());
					pagi.setFirstDetail(context.getClaimDetailPagination().getFirstDetail());
					pagi.setLastDetail(context.getClaimDetailPagination().getLastDetail());
					pagi.setPageHistory(context.getClaimDetailPagination().getPageHistory());
					pagi.setMaxRecordCount(context.getClaimDetailPagination().getMaxRecordCount());
					pagi.setRecordCount(context.getClaimDetailPagination().getRecordCount());
					pagi.setPageRecordCount(context.getClaimDetailPagination().getPageRecordCount());
					// End
					searchVO.setClaimDetailPagination(pagi);
					searchVO.setSelectedClaimType("");
					searchVO.setSelectedClaimRefNbr("");
					searchVO.setSelectedClaimRevNbr("");
					searchVO.setSelectedClaimSeqNbr("");
				}
				searchVO.setIconFlag("N");
				sessionHelper.setAttribute(HPEConstants.SEARCH_ERROR_VO, searchVO);
				break;
			case HPEConstants.ENUM_METHOD_DASHDETAILSELECT:
				sessionHelper.setAttribute(HPEConstants.ENUM_DASH_METHOD, HPEConstants.METHOD_DASHDETAILOPTION);
				context.setSelectedMenu(HPEConstants.MENU_DASHBOARD);
				context.setSelectedOption(HPEConstants.OPTION_DASHINSTDETAIL);
				context.getEncounterVO().setInstClaim(null);
				context.getEncounterVO().setProfClaim(null);
				if (backCRFlag.equalsIgnoreCase("false")) {
					if ("0".equals(requestStatus)) {
						// Delete the default VO and recreate the new one to
						// store the search criterias
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
						if (searchVO != null) {
							pagi = searchVO.getClaimDetailPagination();
							oldPosition = searchVO.getMove();
							oldStateVal = searchVO.getOldState();
							sessionHelper.removeAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
						}

						searchVO = new HpeSearchVO();
						searchVO.setSubmitterId(hpeEncounterForm.getSearchDetailSubmitterId());
						searchVO.setClmType(hpeEncounterForm.getSearchDetailClmType());
						searchVO.setEncType(hpeEncounterForm.getSearchDetailEncType());
						searchVO.setDateInd(hpeEncounterForm.getSearchDetailDateInd());
						searchVO.setFromDate(hpeEncounterForm.getSearchDetailFromDate());
						searchVO.setToDate(hpeEncounterForm.getSearchDetailToDate());
						searchVO.setGroupStatus(hpeEncounterForm.getSearchDetailGroupStatus());
						searchVO.setErrorCode(hpeEncounterForm.getSearchDetailErrorCode());
						searchVO.setErrorGroup(hpeEncounterForm.getSearchDetailErrorGroup());
						searchVO.setErrorSource(hpeEncounterForm.getSearchDetailErrorSource());
						searchVO.setClaimRefNbr(hpeEncounterForm.getSearchDetailClaimRefNbr());
						searchVO.setHicNbr(hpeEncounterForm.getSearchDetailHicNbr());
						searchVO.setSelectedClaimType(hpeEncounterForm.getSelectedClaimType());
						searchVO.setSelectedClaimRefNbr(hpeEncounterForm.getSelectedClaimRefNbr());
						searchVO.setSelectedClaimRevNbr(hpeEncounterForm.getSelectedClaimRevNbr());
						searchVO.setSelectedClaimSeqNbr(hpeEncounterForm.getSelectedClaimSeqNbr());
						if (pagi != null) {
							searchVO.setClaimDetailPagination(pagi);
							searchVO.setMove(oldPosition);
							searchVO.setOldState(oldStateVal);
						}
						if (hpeEncounterForm.getSearchDetailEncType().equals("I")) {
							searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
							searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
							searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
							searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
							searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
							searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
							searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
							searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isInstClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(
									hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(
									hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isInstClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(
									hpeEncounterForm.isInstClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(
									hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());
						} else if (hpeEncounterForm.getSearchDetailEncType().equals("P") || hpeEncounterForm.getSearchDetailEncType().equals("E")) {
							searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
							searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
							searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
							searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
							searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
							searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());
							searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isProfClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(
									hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(
									hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isProfClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(
									hpeEncounterForm.isProfClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(
									hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
						}

						sessionHelper.setAttribute(HPEConstants.SEARCH_ENCOUNTER_VO, searchVO);
					}
				} else {
					sessionHelper.removeAttribute(ChartConstants.HPE_BACK);
					sessionHelper.removeAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_BACK_VO);
					sessionHelper.removeAttribute(ChartConstants.PREV_CR_DASH_METHOD);
				}
				requestStatus = "0";
				forward = HPEInstHelper.selectClaim(conn, sessionHelper, context, hpeEncounterForm, request,
						requestStatus);
				break;
			case HPEConstants.ENUM_METHOD_SUMMDETAILSELECT:
				sessionHelper.setAttribute(HPEConstants.ENUM_SUMM_METHOD, HPEConstants.METHOD_SUMMDETAILOPTION);
				context.setSelectedMenu(HPEConstants.MENU_SUMMARY);
				context.setSelectedOption(HPEConstants.OPTION_SUMMINSTDETAIL);
				context.getEncounterVO().setInstClaim(null);
				context.getEncounterVO().setProfClaim(null);

				if (backCRFlag.equalsIgnoreCase("false")) {
					if ("0".equals(requestStatus)) {
						// Delete the default VO and recreate the new one to
						// store the search criterias
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
						if (searchVO != null) {
							pagi = searchVO.getClaimDetailPagination();
							oldPosition = searchVO.getMove();
							oldStateVal = searchVO.getOldState();
							sessionHelper.removeAttribute(HPEConstants.SEARCH_ERROR_VO);
						}

						searchVO = new HpeSearchVO();
						searchVO.setSubmitterId(hpeEncounterForm.getSearchDetailSubmitterId());
						searchVO.setClmType(hpeEncounterForm.getSearchDetailClmType());
						searchVO.setEncType(hpeEncounterForm.getSearchDetailEncType());
						searchVO.setDateInd(hpeEncounterForm.getSearchDetailDateInd());
						searchVO.setFromDate(hpeEncounterForm.getSearchDetailFromDate());
						searchVO.setToDate(hpeEncounterForm.getSearchDetailToDate());
						searchVO.setGroupStatus(hpeEncounterForm.getSearchDetailGroupStatus());
						searchVO.setErrorCode(hpeEncounterForm.getSearchDetailErrorCode());
						searchVO.setErrorGroup(hpeEncounterForm.getSearchDetailErrorGroup());
						searchVO.setErrorSource(hpeEncounterForm.getSearchDetailErrorSource());
						searchVO.setClaimRefNbr(hpeEncounterForm.getSearchDetailClaimRefNbr());
						searchVO.setHicNbr(hpeEncounterForm.getSearchDetailHicNbr());
						searchVO.setSelectedClaimType(hpeEncounterForm.getSelectedClaimType());
						searchVO.setSelectedClaimRefNbr(hpeEncounterForm.getSelectedClaimRefNbr());
						searchVO.setSelectedClaimRevNbr(hpeEncounterForm.getSelectedClaimRevNbr());
						searchVO.setSelectedClaimSeqNbr(hpeEncounterForm.getSelectedClaimSeqNbr());
						if (pagi != null) {
							searchVO.setClaimDetailPagination(pagi);
							searchVO.setMove(oldPosition);
							searchVO.setOldState(oldStateVal);
						}
						if (hpeEncounterForm.getSearchDetailEncType().equals("I")) {
							searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
							searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
							searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
							searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
							searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
							searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
							searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
							searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isInstClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(
									hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(
									hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isInstClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(
									hpeEncounterForm.isInstClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(
									hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());
						} else if (hpeEncounterForm.getSearchDetailEncType().equals("P") || hpeEncounterForm.getSearchDetailEncType().equals("E")) {
							searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
							searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
							searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
							searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
							searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
							searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());
							searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isProfClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(
									hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(
									hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isProfClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(
									hpeEncounterForm.isProfClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(
									hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
						}

						sessionHelper.setAttribute(HPEConstants.SEARCH_ERROR_VO, searchVO);
					}
				} else {
					sessionHelper.removeAttribute(ChartConstants.HPE_BACK);
					sessionHelper.removeAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_BACK_VO);
					sessionHelper.removeAttribute(ChartConstants.PREV_CR_DASH_METHOD);
				}
				requestStatus = "1";
				forward = HPEInstHelper.selectClaim(conn, sessionHelper, context, hpeEncounterForm, request,
						requestStatus);
				break;
			case HPEConstants.ENUM_METHOD_DASHDETAILSAVE:
				// context.setSelectedMenu(HPEConstants.MENU_DASHBOARD);
				// context.setSelectedOption(HPEConstants.OPTION_DASHINSTDETAIL);
				forward = HPEInstHelper.updateFormData(conn, sessionHelper, context, hpeEncounterForm, request);
				break;
			/*
			 * case HPEConstants.ENUM_METHOD_DASHDETAILCLMSAVE:
			 * //context.setSelectedMenu(HPEConstants.MENU_DASHBOARD);
			 * //context.setSelectedOption(HPEConstants.OPTION_DASHINSTDETAIL);
			 * forward = HPEInstHelper.updateClaim(conn, sessionHelper, context,
			 * hpeEncounterForm, request); break;
			 */
			case HPEConstants.ENUM_METHOD_DASHPROFMONTH:
				context.setSelectedMenu(HPEConstants.MENU_DASHBOARD);
				context.setSelectedOption(HPEConstants.OPTION_DASHPROFDETAIL);
				forward = HPEConstants.HPE_PROFDETAIL;
				break;
			case HPEConstants.ENUM_METHOD_SUMMTREEOPTION:
				sessionHelper.setAttribute(HPEConstants.ENUM_SUMM_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_SUMMARY);
				context.setSelectedOption(HPEConstants.OPTION_SUMMTREE);
				if ("0".equals(requestStatus)) {
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
					if (searchVO != null) {
						if (searchVO.getIconFlag().equals("N")) {
							if (searchVO.getEncType().equals("I")) {
								searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
								searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
								searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
								searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
								searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
								searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
								searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
								searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
								searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isInstClaimProvDetailExpanded());
								searchVO.setClaimOtherSubsProvExpanded(
										hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
								searchVO.setClaimOtherSubsProvDetailExpanded(
										hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
								searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
								searchVO.setClaimOtherSubsDetailExpanded(
										hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
								searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
								searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isInstClaimLineDetailExpanded());
								searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
								searchVO.setClaimLineProvDetailExpanded(
										hpeEncounterForm.isInstClaimLineProvDetailExpanded());
								searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
								searchVO.setClaimLineAdjudDetailExpanded(
										hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());

							} else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")) {
								searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
								searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
								searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
								searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
								searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
								searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());								
								searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
								searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isProfClaimProvDetailExpanded());
								searchVO.setClaimOtherSubsProvExpanded(
										hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
								searchVO.setClaimOtherSubsProvDetailExpanded(
										hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
								searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
								searchVO.setClaimOtherSubsDetailExpanded(
										hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
								searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
								searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isProfClaimLineDetailExpanded());
								searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
								searchVO.setClaimLineProvDetailExpanded(
										hpeEncounterForm.isProfClaimLineProvDetailExpanded());
								searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
								searchVO.setClaimLineAdjudDetailExpanded(
										hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
							}
							searchVO.setIconFlag("Y");
						}
						sessionHelper.setAttribute(HPEConstants.SEARCH_ERROR_VO, searchVO);
					}
				}
				HPEInstHelper.buildErrorStatusSummary(conn, sessionHelper, context, hpeEncounterForm, request);
				forward = HPEConstants.HPE_SUMMTREE;
				break;
			case HPEConstants.ENUM_METHOD_SUMMTREESEARCH:
				sessionHelper.setAttribute(HPEConstants.ENUM_SUMM_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_SUMMARY);
				context.setSelectedOption(HPEConstants.OPTION_SUMMTREE);

				if ("0".equals(requestStatus)) {
					// Delete the default VO and recreate the new one to store
					// the search criterias
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_REJECT_VO);
					if (searchVO != null) {
						sessionHelper.removeAttribute(HPEConstants.SEARCH_REJECT_VO);
					}

					searchVO = new HpeSearchVO();
					searchVO.setSubmitterId(hpeEncounterForm.getSearchSummarySubmitterId());
					searchVO.setClmType(hpeEncounterForm.getSearchSummaryType());
					searchVO.setDateInd(hpeEncounterForm.getSearchSummaryDateInd());
					searchVO.setFromDate(hpeEncounterForm.getSearchSummaryFromDate());
					searchVO.setToDate(hpeEncounterForm.getSearchSummaryToDate());

					sessionHelper.setAttribute(HPEConstants.SEARCH_REJECT_VO, searchVO);
				}
				HPEInstHelper.buildErrorStatusSummary(conn, sessionHelper, context, hpeEncounterForm, request);
				forward = HPEConstants.HPE_SUMMTREE;
				break;
			case HPEConstants.ENUM_METHOD_SUMMINSTMONTH:
				sessionHelper.setAttribute(HPEConstants.ENUM_SUMM_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_SUMMARY);
				context.setSelectedOption(HPEConstants.OPTION_SUMMINSTREJECTCODES);

				if ("0".equals(requestStatus)) {
					hpeEncounterForm.setSearchSummarySubmitterId(hpeEncounterForm.getSearchSummarySubmitterId());
					hpeEncounterForm.setSearchSummaryType(hpeEncounterForm.getSearchSummaryType());
					hpeEncounterForm.setSearchSummaryEncType(hpeEncounterForm.getSearchSummaryEncType());
					hpeEncounterForm.setSearchSummaryDateInd(hpeEncounterForm.getSearchSummaryDateInd());
					hpeEncounterForm.setSearchSummaryFromDate(hpeEncounterForm.getSearchSummaryFromDate());
					hpeEncounterForm.setSearchSummaryToDate(hpeEncounterForm.getSearchSummaryToDate());
					hpeEncounterForm.setSelectedDateYrmo(hpeEncounterForm.getSelectedDateYrmo());
					hpeEncounterForm.setSearchSummaryErrorSource(hpeEncounterForm.getSearchSummaryErrorSource());
					hpeEncounterForm.setSearchSummaryErrorCode(hpeEncounterForm.getSearchSummaryErrorCode());

					/*
					 * Create the VO to store the data of the user selected row
					 * of the Reject Analysis dashboard It will be used, when
					 * user wants to view the previuos screen data
					 */
					searchVO = new HpeSearchVO();
					searchVO.setSubmitterId(hpeEncounterForm.getSearchSummarySubmitterId());
					searchVO.setClmType(hpeEncounterForm.getSearchSummaryType());
					searchVO.setEncType(hpeEncounterForm.getSearchSummaryEncType());
					searchVO.setDateInd(hpeEncounterForm.getSearchSummaryDateInd());
					searchVO.setSelectedDate(hpeEncounterForm.getSelectedDateYrmo());
					searchVO.setFromDate(hpeEncounterForm.getSearchSummaryFromDate());
					searchVO.setToDate(hpeEncounterForm.getSearchSummaryToDate());
					searchVO.setErrorSource(hpeEncounterForm.getSearchSummaryErrorSource());
					searchVO.setErrorCode(hpeEncounterForm.getSearchSummaryErrorCode());

					sessionHelper.setAttribute(HPEConstants.SEARCH_VO, searchVO);
				}

				forward = HPEInstHelper.getErrorDetails(conn, sessionHelper, context, hpeEncounterForm, request);
				break;
			case HPEConstants.ENUM_METHOD_SUMMREJECTCODESOPTION:
				sessionHelper.setAttribute(HPEConstants.ENUM_SUMM_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_SUMMARY);
				context.setSelectedOption(HPEConstants.OPTION_SUMMINSTREJECTCODES);
				
				if ("0".equals(requestStatus)) {
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
					if (searchVO != null) {
						if (searchVO.getIconFlag().equals("N")) {
							if (searchVO.getEncType().equals("I")) {
								searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
								searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
								searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
								searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
								searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
								searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
								searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
								searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
								searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isInstClaimProvDetailExpanded());
								searchVO.setClaimOtherSubsProvExpanded(
										hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
								searchVO.setClaimOtherSubsProvDetailExpanded(
										hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
								searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
								searchVO.setClaimOtherSubsDetailExpanded(
										hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
								searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
								searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isInstClaimLineDetailExpanded());
								searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
								searchVO.setClaimLineProvDetailExpanded(
										hpeEncounterForm.isInstClaimLineProvDetailExpanded());
								searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
								searchVO.setClaimLineAdjudDetailExpanded(
										hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());

							} else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")) {
								searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
								searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
								searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
								searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
								searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
								searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());
								;
								searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
								searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isProfClaimProvDetailExpanded());
								searchVO.setClaimOtherSubsProvExpanded(
										hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
								searchVO.setClaimOtherSubsProvDetailExpanded(
										hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
								searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
								searchVO.setClaimOtherSubsDetailExpanded(
										hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
								searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
								searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isProfClaimLineDetailExpanded());
								searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
								searchVO.setClaimLineProvDetailExpanded(
										hpeEncounterForm.isProfClaimLineProvDetailExpanded());
								searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
								searchVO.setClaimLineAdjudDetailExpanded(
										hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
							}
							searchVO.setIconFlag("Y");
						}
						sessionHelper.setAttribute(HPEConstants.SEARCH_ERROR_VO, searchVO);
					}
				}

				hpeEncounterForm.setSelectedDateYrmo("");
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_VO);

				if (searchVO != null) {
					forward = HPEInstHelper.getErrorDetails(conn, sessionHelper, context, hpeEncounterForm, request);
				} else {
					hpeEncounterForm.setSearchSummarySubmitterId("");
					hpeEncounterForm.setSearchSummaryType("EN");
					hpeEncounterForm.setSearchSummaryEncType(Utility.getEncTypeFromSelectedTab(HPEConstants.REJECT_ANALYSIS_SUMMARY_TAB, sessionHelper)); //DME_Dashboard_changes);
					hpeEncounterForm.setSearchSummaryDateInd("0"); // set value
																	// zero to
																	// make
																	// Submission
																	// Date
																	// radio
																	// button as
																	// selected
																	// by
																	// default,
																	// IFOX
																	// 00363843
					hpeEncounterForm.setSearchSummaryFromDate("");
					hpeEncounterForm.setSearchSummaryToDate("");
					hpeEncounterForm.setSearchSummaryErrorSource("");
					hpeEncounterForm.setSearchSummaryErrorCode("");

					forward = HPEConstants.HPE_SUMMINSTREJECTCODES;
				}
				break;
			case HPEConstants.ENUM_METHOD_ERRORSEARCH:
				sessionHelper.setAttribute(HPEConstants.ENUM_SUMM_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_SUMMARY);
				context.setSelectedOption(HPEConstants.OPTION_SUMMINSTREJECTCODES);

				if ("0".equals(requestStatus)) {
					// Delete and recreate the VO to store the search criteria
					// of error dashboard page
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_VO);
					if (searchVO != null) {
						sessionHelper.removeAttribute(HPEConstants.SEARCH_VO);
					}

					searchVO = new HpeSearchVO();
					searchVO.setSubmitterId(hpeEncounterForm.getSearchSummarySubmitterId());
					searchVO.setClmType(hpeEncounterForm.getSearchSummaryType());
					searchVO.setEncType(hpeEncounterForm.getSearchSummaryEncType());
					searchVO.setDateInd(hpeEncounterForm.getSearchSummaryDateInd());
					searchVO.setFromDate(hpeEncounterForm.getSearchSummaryFromDate());
					searchVO.setToDate(hpeEncounterForm.getSearchSummaryToDate());
					searchVO.setErrorSource(hpeEncounterForm.getSearchSummaryErrorSource());
					searchVO.setErrorGroup(hpeEncounterForm.getSearchSummaryErrorGroup());
					searchVO.setErrorCode(hpeEncounterForm.getSearchSummaryErrorCode());
					sessionHelper.setAttribute(HPEConstants.SEARCH_VO, searchVO);
				}

				forward = HPEInstHelper.getErrorDetails(conn, sessionHelper, context, hpeEncounterForm, request);
				break;
			case HPEConstants.ENUM_METHOD_SUMMINSTSYNMONTH:
			case HPEConstants.ENUM_METHOD_SUMMINSTCCRMONTH:
			case HPEConstants.ENUM_METHOD_SUMMINSTREJMONTH:
			case HPEConstants.ENUM_METHOD_SUMMINSTTOTMONTH:
				context.setSelectedMenu(HPEConstants.MENU_SUMMARY);
				context.setSelectedOption(HPEConstants.OPTION_SUMMINSTREJECTCODES);

				// List lst = new ArrayList();
				// HPETestVO objVO = new HPETestVO();
				//
				// switch (enumMethod) {
				// case HPEConstants.ENUM_METHOD_SUMMINSTSYNMONTH:
				// objVO.setCol("Syntax");
				// break;
				// case HPEConstants.ENUM_METHOD_SUMMINSTCCRMONTH:
				// objVO.setCol("CCR");
				// break;
				// case HPEConstants.ENUM_METHOD_SUMMINSTREJMONTH:
				// objVO.setCol("Rejected");
				// break;
				// case HPEConstants.ENUM_METHOD_SUMMINSTTOTMONTH:
				// objVO.setCol("Syntax");
				// break;
				// }
				//
				// lst.add(objVO);
				// formHPE.setTestList(lst);

				forward = HPEConstants.HPE_SUMMINSTREJECTCODES;
				break;
			case HPEConstants.ENUM_METHOD_SUMMPROFSYNMONTH:
			case HPEConstants.ENUM_METHOD_SUMMPROFCCRMONTH:
			case HPEConstants.ENUM_METHOD_SUMMPROFREJMONTH:
			case HPEConstants.ENUM_METHOD_SUMMPROFTOTMONTH:
				context.setSelectedMenu(HPEConstants.MENU_SUMMARY);
				context.setSelectedOption(HPEConstants.OPTION_SUMMPROFREJECTCODES);

				// List lst = new ArrayList();
				// HPETestVO objVO = new HPETestVO();
				//
				// switch (enumMethod) {
				// case HPEConstants.ENUM_METHOD_SUMMPROFSYNMONTH:
				// objVO.setCol("Syntax");
				// break;
				// case HPEConstants.ENUM_METHOD_SUMMPROFCCRMONTH:
				// objVO.setCol("CCR");
				// break;
				// case HPEConstants.ENUM_METHOD_SUMMPROFREJMONTH:
				// objVO.setCol("Rejected");
				// break;
				// case HPEConstants.ENUM_METHOD_SUMMPROFTOTMONTH:
				// objVO.setCol("Syntax");
				// break;
				// }
				//
				// lst.add(objVO);
				// formHPE.setTestList(lst);

				forward = HPEConstants.HPE_SUMMPROFREJECTCODES;
				break;
			case HPEConstants.ENUM_METHOD_SUMMDETAILOPTION:
				sessionHelper.setAttribute(HPEConstants.ENUM_SUMM_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_SUMMARY);
				context.setSelectedOption(HPEConstants.OPTION_SUMMINSTDETAIL);

				if (backCRFlag.equalsIgnoreCase("false")) {
					if ("0".equals(requestStatus)) {
						hpeEncounterForm.setSearchDetailSubmitterId(hpeEncounterForm.getSearchSummarySubmitterId());
						hpeEncounterForm.setSearchDetailClmType(hpeEncounterForm.getSearchSummaryType());
						hpeEncounterForm.setSearchDetailEncType(hpeEncounterForm.getSearchSummaryEncType());
						hpeEncounterForm.setSearchDetailDateInd(hpeEncounterForm.getSearchSummaryDateInd());
						hpeEncounterForm
								.setSearchDetailFromDate(DateFormatter.reFormat(hpeEncounterForm.getSelectedDateYrmo(),
										DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_START));
						hpeEncounterForm
								.setSearchDetailToDate(DateFormatter.reFormat(hpeEncounterForm.getSelectedDateYrmo(),
										DateFormatter.MM_YYYY, DateFormatter.MM_DD_YYYY, DateFormatter.ASSUME_END));
						hpeEncounterForm.setFormattedErrorSource(hpeEncounterForm.getFormattedErrorSource());
						hpeEncounterForm.setRejectCode(hpeEncounterForm.getRejectCode());

						/*
						 * Create the VO to store the data of the user selected
						 * row of the Error dashboard It will be used, when user
						 * wants to view the previuos screen data
						 */
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
						if (searchVO != null) {
							sessionHelper.removeAttribute(HPEConstants.SEARCH_ERROR_VO);
						}

						searchVO = new HpeSearchVO();
						searchVO.setSubmitterId(hpeEncounterForm.getSearchSummarySubmitterId());
						searchVO.setClmType(hpeEncounterForm.getSearchSummaryType());
						searchVO.setEncType(hpeEncounterForm.getSearchSummaryEncType());
						searchVO.setDateInd(hpeEncounterForm.getSearchSummaryDateInd());
						searchVO.setSelectedDate(hpeEncounterForm.getSelectedDateYrmo());
						searchVO.setFromDate(hpeEncounterForm.getSearchSummaryFromDate());
						searchVO.setToDate(hpeEncounterForm.getSearchSummaryToDate());
						searchVO.setErrorSource(hpeEncounterForm.getSearchSummaryErrorSource());
						searchVO.setErrorCode(hpeEncounterForm.getSearchSummaryErrorCode());
						searchVO.setFormattedErrorSource(hpeEncounterForm.getFormattedErrorSource());
						searchVO.setRejectCode(hpeEncounterForm.getRejectCode());
						searchVO.setErrorGroup(hpeEncounterForm.getSelectedErrorGroup());
						sessionHelper.setAttribute(HPEConstants.SEARCH_ERROR_VO, searchVO);
					}
				} else {
					sessionHelper.removeAttribute(ChartConstants.HPE_BACK);
					sessionHelper.removeAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_BACK_VO);
					sessionHelper.removeAttribute(ChartConstants.PREV_CR_DASH_METHOD);
				}

				forward = HPEInstHelper.selectErrorSpecificClaims(conn, sessionHelper, context, hpeEncounterForm,
						request);
				break;
			case HPEConstants.ENUM_METHOD_SUMMENCOUNTEROPTION:
				sessionHelper.setAttribute(HPEConstants.ENUM_SUMM_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_SUMMARY);
				context.setSelectedOption(HPEConstants.OPTION_SUMMINSTDETAIL);
				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
				if (searchVO != null) {
					searchVO.setIconFlag("N");
					sessionHelper.setAttribute(HPEConstants.SEARCH_ERROR_VO, searchVO);
				}
				forward = HPEInstHelper.selectErrorSpecificClaims(conn, sessionHelper, context, hpeEncounterForm,
						request);
				break;
			case HPEConstants.ENUM_METHOD_SUMMPROFREJECTCODES:
				sessionHelper.setAttribute(HPEConstants.ENUM_SUMM_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_SUMMARY);
				context.setSelectedOption(HPEConstants.OPTION_SUMMPROFDETAIL);
				forward = HPEConstants.HPE_PROFDETAIL;
				break;
			case HPEConstants.ENUM_METHOD_LOGDETAIL:
				forward = HPEInstHelper.getClaimChangeLogDetails(conn, sessionHelper, context, hpeEncounterForm,
						request);
				break;
			case HPEConstants.ENUM_METHOD_LOGHISTORY:
				forward = HPEInstHelper.getClaimChangeLogHistory(conn, sessionHelper, context, hpeEncounterForm,
						request);
				break;
			case HPEConstants.ENUM_DASH_MOVE_CR:
				claimRefNo = hpeEncounterForm.getSelectedClaimRefNbr();
				claimType = hpeEncounterForm.getSelectedClaimType();
				submitterId = hpeEncounterForm.getSearchDetailSubmitterId();
				clmType = hpeEncounterForm.getSearchDetailClmType();
				prevMethod = hpeEncounterForm.getPrevMethod();
				prevMenu = hpeEncounterForm.getPrevMenu();
				dateInd = hpeEncounterForm.getSearchDetailDateInd();

				if ("0".equals(requestStatus)) {
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
					if (searchVO != null) {
						if (searchVO.getEncType().equals("I")) {
							searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
							searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
							searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
							searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
							searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
							searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
							searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
							searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isInstClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(
									hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(
									hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isInstClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(
									hpeEncounterForm.isInstClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(
									hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());
						} else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")) {
							searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
							searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
							searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
							searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
							searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
							searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());
							searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isProfClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(
									hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(
									hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isProfClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(
									hpeEncounterForm.isProfClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(
									hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
						}
						searchVO.setIconFlag("Y");
					}
					sessionHelper.setAttribute(HPEConstants.SEARCH_ENCOUNTER_VO, searchVO);
				}

				if (clmType.equalsIgnoreCase("EN")) {
					clmType = "CR";
				} else if (clmType.equalsIgnoreCase("MD")) {
					clmType = "MC";
				}

				strUrl = "/chartAction.do?claimType=" + claimType + "&method=chartDetailOption&prevMenu=" + prevMenu
						+ "&prevMethod=" + prevMethod + "&claimRefNbr=" + claimRefNo + "&submitterId=" + submitterId
						+ "&dateInd=" + dateInd + "&clmType=" + clmType;
				response.sendRedirect(strUrl);
				logger.info(LoggerConstants.methodEndLevel());
				return null;
			case HPEConstants.ENUM_SUMM_MOVE_CR:
				claimRefNo = hpeEncounterForm.getSelectedClaimRefNbr();
				claimType = hpeEncounterForm.getSelectedClaimType();
				clmType = hpeEncounterForm.getSearchDetailClmType();
				submitterId = hpeEncounterForm.getSearchDetailSubmitterId();
				prevMethod = hpeEncounterForm.getPrevMethod();
				prevMenu = hpeEncounterForm.getPrevMenu();
				dateInd = hpeEncounterForm.getSearchDetailDateInd();

				if ("0".equals(requestStatus)) {
					searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
					if (searchVO != null) {
						if (searchVO.getEncType().equals("I")) {
							searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
							searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
							searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
							searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
							searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
							searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
							searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
							searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isInstClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(
									hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(
									hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isInstClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(
									hpeEncounterForm.isInstClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(
									hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());
						} else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")) {
							searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
							searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
							searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
							searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
							searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
							searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());
							searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isProfClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(
									hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(
									hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isProfClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(
									hpeEncounterForm.isProfClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(
									hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
						}
						searchVO.setIconFlag("Y");
					}
					sessionHelper.setAttribute(HPEConstants.SEARCH_ERROR_VO, searchVO);
				}

				strUrl = "/chartAction.do?claimType=" + claimType + "&method=chartDetailOption&prevMenu=" + prevMenu
						+ "&prevMethod=" + prevMethod + "&claimRefNbr=" + claimRefNo + "&submitterId=" + submitterId
						+ "&dateInd=" + dateInd + "&clmType=" + clmType;
				response.sendRedirect(strUrl);
				logger.info(LoggerConstants.methodEndLevel());
				return null;
			case HPEConstants.ENUM_SWITCH_MENU_CR:
				menu = hpeEncounterForm.getMenu();
				method = "switchMenu";

				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ERROR_VO);
				if (searchVO != null) {
					if (searchVO.getEncType().equals("I")) {
						searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
						searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
						searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
						searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
						searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
						searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
						searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
						searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
						searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isInstClaimProvDetailExpanded());
						searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
						searchVO.setClaimOtherSubsProvDetailExpanded(
								hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
						searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
						searchVO.setClaimOtherSubsDetailExpanded(hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
						searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
						searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isInstClaimLineDetailExpanded());
						searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
						searchVO.setClaimLineProvDetailExpanded(hpeEncounterForm.isInstClaimLineProvDetailExpanded());
						searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
						searchVO.setClaimLineAdjudDetailExpanded(hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());
					} else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")) {
						searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
						searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
						searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
						searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
						searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
						searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());
						searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
						searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isProfClaimProvDetailExpanded());
						searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
						searchVO.setClaimOtherSubsProvDetailExpanded(
								hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
						searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
						searchVO.setClaimOtherSubsDetailExpanded(hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
						searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
						searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isProfClaimLineDetailExpanded());
						searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
						searchVO.setClaimLineProvDetailExpanded(hpeEncounterForm.isProfClaimLineProvDetailExpanded());
						searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
						searchVO.setClaimLineAdjudDetailExpanded(hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
					}
					searchVO.setIconFlag("Y");
				}
				sessionHelper.setAttribute(HPEConstants.SEARCH_ERROR_VO, searchVO);

				searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
				if (searchVO != null) {
					if (searchVO.getEncType().equals("I")) {
						searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
						searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
						searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
						searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
						searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
						searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
						searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
						searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
						searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isInstClaimProvDetailExpanded());
						searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
						searchVO.setClaimOtherSubsProvDetailExpanded(
								hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
						searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
						searchVO.setClaimOtherSubsDetailExpanded(hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
						searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
						searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isInstClaimLineDetailExpanded());
						searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
						searchVO.setClaimLineProvDetailExpanded(hpeEncounterForm.isInstClaimLineProvDetailExpanded());
						searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
						searchVO.setClaimLineAdjudDetailExpanded(hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());
					} else if (searchVO.getEncType().equals("P") || searchVO.getEncType().equals("E")) {
						searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
						searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
						searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
						searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
						searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
						searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());
						searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
						searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isProfClaimProvDetailExpanded());
						searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
						searchVO.setClaimOtherSubsProvDetailExpanded(
								hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
						searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
						searchVO.setClaimOtherSubsDetailExpanded(hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
						searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
						searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isProfClaimLineDetailExpanded());
						searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
						searchVO.setClaimLineProvDetailExpanded(hpeEncounterForm.isProfClaimLineProvDetailExpanded());
						searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
						searchVO.setClaimLineAdjudDetailExpanded(hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
					}
					searchVO.setIconFlag("Y");
				}
				sessionHelper.setAttribute(HPEConstants.SEARCH_ENCOUNTER_VO, searchVO);

				strUrl = "/chartAction.do?menu=" + menu + "&method=" + method;
				response.sendRedirect(strUrl);
				logger.info(LoggerConstants.methodEndLevel());
				return null;
				
				
		// File Tracking Project Start 		
			case HPEConstants.ENUM_FILETREE_MOVE_EN:
				menu = hpeEncounterForm.getMenu();
				
				sessionHelper.setAttribute(HPEConstants.ENUM_DASH_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_DASHBOARD);
				context.setSelectedOption(HPEConstants.OPTION_DASHINSTDETAIL);				
				
				if (backCRFlag.equalsIgnoreCase("false")) {
					if ("0".equals(requestStatus)) {
						// Delete the default VO and recreate the new one to
						// store the search criterias
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_FILE_TRACK_VO);
						if (searchVO != null) {
							
							hpeEncounterForm.setFileTrackingFlag(true);
							hpeEncounterForm.setOrigFileId(searchVO.getSelectedOrigFileId());
							hpeEncounterForm.setSearchDetailEncType(searchVO.getEncType());
							hpeEncounterForm.setSearchDetailGroupStatus(searchVO.getGroupStatus());
							hpeEncounterForm.setSearchDetailSubmitterId(searchVO.getSubmitterId());
							
							//sessionHelper.removeAttribute(HPEConstants.SEARCH_FILE_TRACK_VO);
						}

						hpeEncounterForm.setSubscriberDisplayState(HPEConstants.HPE_SCREEN_VIEW);
						hpeEncounterForm.setClaimDisplayState(HPEConstants.HPE_SCREEN_VIEW);
						hpeEncounterForm.setProviderDisplayState(HPEConstants.HPE_SCREEN_VIEW);
						hpeEncounterForm.setClmProviderDisplayState(HPEConstants.HPE_SCREEN_VIEW);
						
						

						searchVO = new HpeSearchVO();
						searchVO.setSubmitterId(hpeEncounterForm.getSearchDetailSubmitterId());
						searchVO.setClmType(hpeEncounterForm.getSearchDetailClmType());
						if(hpeEncounterForm.getSearchDetailEncType().equals("P") || hpeEncounterForm.getSearchDetailEncType().equals("E")){
							searchVO.setEncType("P");
						}else{
						searchVO.setEncType(hpeEncounterForm.getSearchDetailEncType());
						}
						searchVO.setDateInd(hpeEncounterForm.getSearchDetailDateInd());
						searchVO.setFromDate(hpeEncounterForm.getSearchDetailFromDate());
						searchVO.setToDate(hpeEncounterForm.getSearchDetailToDate());
						searchVO.setGroupStatus(hpeEncounterForm.getSearchDetailGroupStatus());
						searchVO.setErrorCode(hpeEncounterForm.getSearchDetailErrorCode());
						searchVO.setErrorGroup(hpeEncounterForm.getSearchDetailErrorGroup());
						searchVO.setErrorSource(hpeEncounterForm.getSearchDetailErrorSource());
						searchVO.setClaimRefNbr(hpeEncounterForm.getSearchDetailClaimRefNbr());
						searchVO.setHicNbr(hpeEncounterForm.getSearchDetailHicNbr());
						if (hpeEncounterForm.getSearchDetailEncType().equals("I")) {
							searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
							searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
							searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
							searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
							searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
							searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
							searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
							searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isInstClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(
									hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(
									hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isInstClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(
									hpeEncounterForm.isInstClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(
									hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());
						} else if (hpeEncounterForm.getSearchDetailEncType().equals("P") || hpeEncounterForm.getSearchDetailEncType().equals("E")) {
							searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
							searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
							searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
							searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
							searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
							searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());
							searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isProfClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(
									hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(
									hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isProfClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(
									hpeEncounterForm.isProfClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(
									hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
						}
						sessionHelper.setAttribute(HPEConstants.SEARCH_FILE_TRACK_VO, searchVO);
					}
				} else {
					sessionHelper.removeAttribute(ChartConstants.HPE_BACK);
					sessionHelper.removeAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_BACK_VO);
					sessionHelper.removeAttribute(ChartConstants.PREV_CR_DASH_METHOD);
				}
				requestStatus = "2";
				forward = HPEInstHelper.selectClaims(conn, sessionHelper, context, hpeEncounterForm, request,
						requestStatus);
				break;
			// File Tracking project End	
				
			
		    
				//Editable Fileds CHS -- IFOX-00395627
				
			case HPEConstants.ENUM_METHOD_EDITABLE_CLAIM_CODE_SECTION:	
				logger.debug("in ENUM_METHOD_EDITABLE_CLAIM_CODE_SECTION::::");
				 String heir = (String)request.getParameter("heir");
				 String mfId =  (String)request.getParameter("mfId");
			//	 clmType = (String)request.getParameter("clmType");
				 clmType = context.getEncounterVO().getSearchDetailEncType();
				
				 String clmNbr = (String)request.getParameter("clmNbr");
				 String clmRvNbr = (String)request.getParameter("clmRvNbr");
				 String clmSqNbr= (String)request.getParameter("clmSqNbr");
				 String cndSqNbr= (String)request.getParameter("cndSqNbr");	
				 String encType= (String)request.getParameter("encType");
				// String encType = hpeEncounterForm.getSelectedClaimType();
				 String delFlag = (String)request.getParameter("delFlag");
				 
				 if(StringUtils.isNotEmpty(mfId)){
					 hpeEncounterForm.setEditableMfid(mfId);
				 }
				 if(StringUtils.isNotEmpty(encType)){
					 hpeEncounterForm.setEditableEncType(encType);
				 }
				 if(StringUtils.isNotEmpty(clmType)){
					 hpeEncounterForm.setSelectedClaimType(clmType);
				 }
				 if(StringUtils.isNotEmpty(clmNbr)){
					 hpeEncounterForm.setSelectedClaimRefNbr(clmNbr);
				 }
				 
				 if(StringUtils.isNotEmpty(clmRvNbr)){
					 hpeEncounterForm.setSelectedClaimRevNbr(clmRvNbr);
				 }
				 if(StringUtils.isNotEmpty(clmSqNbr)){
					 hpeEncounterForm.setSelectedClaimSeqNbr(clmSqNbr);
				 }
				 if(StringUtils.isNotEmpty(cndSqNbr)){
					 hpeEncounterForm.setEditableCndSeqNbr(cndSqNbr);
				 }
				 		 
				 
				 if(StringUtils.isNotEmpty(heir)){
					 
					 hpeEncounterForm.setHier(heir);
					 
					 if(HPEConstants.EDITABLE_COND_CODE_CNSTNT.equals(heir) || HPEConstants.EDITABLE_TREATMENT_CODE_CNSTNT.equals(heir)){
						 hpeEncounterForm.setEditableCode((String)request.getParameter("code")); 
					 }
					 
					 if(HPEConstants.EDITABLE_DIAG_CODE_CNSTNT.equals(heir) || HPEConstants.EDITABLE_EXT_INJ_CODE_CNSTNT.equals(heir)){
						 hpeEncounterForm.setEditableCode((String)request.getParameter("code")); 
						 hpeEncounterForm.setEditableType((String)request.getParameter("type"));
						 hpeEncounterForm.setEditablePOA((String)request.getParameter("poa"));
					 }
					 
					 if(HPEConstants.EDITABLE_PROCEDURE_CODE_CNSTNT.equals(heir)){
						 hpeEncounterForm.setEditableCode((String)request.getParameter("code")); 
						 hpeEncounterForm.setEditableType((String)request.getParameter("type"));
						 hpeEncounterForm.setEditableDate((String)request.getParameter("date"));
					 }
					 if(HPEConstants.EDITABLE_OCCURSPAN_CODE_CNSTNT.equals(heir)){
						 hpeEncounterForm.setEditableCode((String)request.getParameter("code"));
						 hpeEncounterForm.setEditableFromDt((String)request.getParameter("from"));
						 hpeEncounterForm.setEditableThruDt((String)request.getParameter("thru"));
					 }
					 if(HPEConstants.EDITABLE_VALUE_CODE_CNSTNT.equals(heir)){
						 hpeEncounterForm.setEditableCode((String)request.getParameter("code"));
						 String amntVal = (String)request.getParameter("amnt");
						 amntVal=amntVal.replaceAll("\\$", "");
						 double amntValue= Double.parseDouble(amntVal);
						 hpeEncounterForm.setEditableAmount(amntValue);
						 
					 }
					 if(HPEConstants.EDITABLE_OCCURENCE_CODE_CNSTNT.equals(heir)){
						 hpeEncounterForm.setEditableCode((String)request.getParameter("code"));
						 hpeEncounterForm.setEditableDate((String)request.getParameter("date"));
					 }
					//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
					 if(HPEConstants.EDITABLE_CLMLINE_ADJUD_ADJUST.equals(heir)){
						 hpeEncounterForm.setEditableAdjGroupCode((String)request.getParameter("code"));
						 hpeEncounterForm.setEditableAdjReasonCode((String)request.getParameter("reason"));
						 hpeEncounterForm.setEditableAdjAmount(Double.parseDouble(request.getParameter("amount").replace("$", "")));
						 hpeEncounterForm.setEditableAdjQuantity(Integer.parseInt(request.getParameter("quantity")));
						 hpeEncounterForm.setEditableAdjudSeqNbr(Integer.parseInt(request.getParameter("adjudseqnbr")));
						 hpeEncounterForm.setEditableAdjustSeqNbr(Integer.parseInt(request.getParameter("adjustseqnbr")));
						 hpeEncounterForm.setClmliSeqNbr((String)request.getParameter("clmliseqnbr"));
					 }
					//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
					
				 }
					
					 
					 forward = HPEInstHelper.EditableUpdateCodes(conn, sessionHelper, context, request, hpeEncounterForm, delFlag); 
					 
				
				PrintWriter out = response.getWriter();	
				 msg.append(forward);
				 out.println(msg.toString());
                 out.flush();
                 out.close();
		        logger.debug("Retrieved the Remarks from Xref table -"+forward);
								
				break;
				
			case HPEConstants.ENUM_METHOD_EDITABLE_ADD_CODE_SECTION:
				sessionHelper.setAttribute(HPEConstants.ENUM_DASH_METHOD, method);
				context.setSelectedMenu(HPEConstants.MENU_DASHBOARD);
				context.setSelectedOption(HPEConstants.OPTION_DASHINSTDETAIL);

				if (backCRFlag.equalsIgnoreCase("false")) {
					if ("0".equals(requestStatus)) {
						// Delete the default VO and recreate the new one to
						// store the search criterias
						searchVO = (HpeSearchVO) sessionHelper.getAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
						if (searchVO != null) {
							sessionHelper.removeAttribute(HPEConstants.SEARCH_ENCOUNTER_VO);
						}

						hpeEncounterForm.setSubscriberDisplayState(HPEConstants.HPE_SCREEN_VIEW);
						hpeEncounterForm.setClaimDisplayState(HPEConstants.HPE_SCREEN_VIEW);
						hpeEncounterForm.setProviderDisplayState(HPEConstants.HPE_SCREEN_VIEW);
						hpeEncounterForm.setClmProviderDisplayState(HPEConstants.HPE_SCREEN_VIEW);

						searchVO = new HpeSearchVO();
						searchVO.setSubmitterId(hpeEncounterForm.getSearchDetailSubmitterId());
						searchVO.setClmType(hpeEncounterForm.getSearchDetailClmType());
						searchVO.setEncType(hpeEncounterForm.getSearchDetailEncType());
						searchVO.setDateInd(hpeEncounterForm.getSearchDetailDateInd());
						searchVO.setFromDate(hpeEncounterForm.getSearchDetailFromDate());
						searchVO.setToDate(hpeEncounterForm.getSearchDetailToDate());
						searchVO.setGroupStatus(hpeEncounterForm.getSearchDetailGroupStatus());
						searchVO.setErrorCode(hpeEncounterForm.getSearchDetailErrorCode());
						searchVO.setErrorGroup(hpeEncounterForm.getSearchDetailErrorGroup());
						searchVO.setErrorSource(hpeEncounterForm.getSearchDetailErrorSource());
						searchVO.setClaimRefNbr(hpeEncounterForm.getSearchDetailClaimRefNbr());
						searchVO.setHicNbr(hpeEncounterForm.getSearchDetailHicNbr());
						if (hpeEncounterForm.getSearchDetailEncType().equals("I")) {
							searchVO.setListExpanded(hpeEncounterForm.isInstListExpanded());
							searchVO.setErrorsExpanded(hpeEncounterForm.isInstErrorsExpanded());
							searchVO.setSubscriberExpanded(hpeEncounterForm.isInstSubscriberExpanded());
							searchVO.setProviderExpanded(hpeEncounterForm.isInstProviderExpanded());
							searchVO.setClaimExpanded(hpeEncounterForm.isInstClaimExpanded());
							searchVO.setClaimCodesExpanded(hpeEncounterForm.isInstClaimCodesExpanded());
							searchVO.setClaimNotesExpanded(hpeEncounterForm.isInstClaimNotesExpanded());
							searchVO.setClaimProvExpanded(hpeEncounterForm.isInstClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isInstClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isInstClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(
									hpeEncounterForm.isInstClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isInstClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(
									hpeEncounterForm.isInstClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(hpeEncounterForm.isInstClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isInstClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(hpeEncounterForm.isInstClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(
									hpeEncounterForm.isInstClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isInstClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(
									hpeEncounterForm.isInstClaimLineAdjudDetailExpanded());
						} else if (hpeEncounterForm.getSearchDetailEncType().equals("P") || hpeEncounterForm.getSearchDetailEncType().equals("E")) {
							searchVO.setListExpanded(hpeEncounterForm.isProfListExpanded());
							searchVO.setErrorsExpanded(hpeEncounterForm.isProfErrorsExpanded());
							searchVO.setSubscriberExpanded(hpeEncounterForm.isProfSubscriberExpanded());
							searchVO.setProviderExpanded(hpeEncounterForm.isProfProviderExpanded());
							searchVO.setClaimExpanded(hpeEncounterForm.isProfClaimExpanded());
							searchVO.setClaimCodesExpanded(hpeEncounterForm.isProfClaimCodesExpanded());
							searchVO.setClaimProvExpanded(hpeEncounterForm.isProfClaimProvExpanded());
							searchVO.setClaimProvDetailExpanded(hpeEncounterForm.isProfClaimProvDetailExpanded());
							searchVO.setClaimOtherSubsProvExpanded(hpeEncounterForm.isProfClaimOtherSubsProvExpanded());
							searchVO.setClaimOtherSubsProvDetailExpanded(
									hpeEncounterForm.isProfClaimOtherSubsProvDetailExpanded());
							searchVO.setClaimOtherSubsExpanded(hpeEncounterForm.isProfClaimOtherSubsExpanded());
							searchVO.setClaimOtherSubsDetailExpanded(
									hpeEncounterForm.isProfClaimOtherSubsDetailExpanded());
							searchVO.setClaimLineExpanded(hpeEncounterForm.isProfClaimLineExpanded());
							searchVO.setClaimLineDetailExpanded(hpeEncounterForm.isProfClaimLineDetailExpanded());
							searchVO.setClaimLineProvExpanded(hpeEncounterForm.isProfClaimLineProvExpanded());
							searchVO.setClaimLineProvDetailExpanded(
									hpeEncounterForm.isProfClaimLineProvDetailExpanded());
							searchVO.setClaimLineAdjudExpanded(hpeEncounterForm.isProfClaimLineAdjudExpanded());
							searchVO.setClaimLineAdjudDetailExpanded(
									hpeEncounterForm.isProfClaimLineAdjudDetailExpanded());
						}
						sessionHelper.setAttribute(HPEConstants.SEARCH_ENCOUNTER_VO, searchVO);
					}
				} else {
					sessionHelper.removeAttribute(ChartConstants.HPE_BACK);
					sessionHelper.removeAttribute(ChartConstants.ENUM_CR_DASH_METHOD);
					sessionHelper.removeAttribute(ChartConstants.SEARCH_CR_BACK_VO);
					sessionHelper.removeAttribute(ChartConstants.PREV_CR_DASH_METHOD);
				}
				requestStatus = "0";
				
				hpeEncounterForm.setSelectedClaimRefNbr(hpeEncounterForm.getFirstClaimRefNbr());
				hpeEncounterForm.setEditableMfid(sessionHelper.getMfId());
				hpeEncounterForm.setSelectedClaimRevNbr(hpeEncounterForm.getFirstClaimRevNbr());
				hpeEncounterForm.setSelectedClaimSeqNbr(hpeEncounterForm.getFirstClaimSeqNbr());
				hpeEncounterForm.setEditableEncType(searchVO.getClmType());
				hpeEncounterForm.setSelectedClaimType(hpeEncounterForm.getFirstClaimType());
				
				
				 forward = HPEInstHelper.EditableUpdateCodes(conn, sessionHelper, context, request, hpeEncounterForm, "ADD");
				
				forward = HPEInstHelper.selectClaims(conn, sessionHelper, context, hpeEncounterForm, request,
						requestStatus);
				break;	
				
			default:
				forward = HPEConstants.HPE_ERROR;
				break;
			}
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//logger.error(e.getMessage());
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				//logger.error(e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		
		return mapping.findForward(forward);
	}
	
}
