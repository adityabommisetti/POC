/*
 * $Id: FacadeManager.java,v 1.4 2015/11/16 23:07:01 dinesh Exp $
 */
package com.ps.mss.web.ajax;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.DaoFactory;
import com.ps.mss.dao.EEMApplDao;
import com.ps.mss.dao.ProfileDao;
import com.ps.mss.dao.model.EEMApplCommentsVO;
import com.ps.mss.dao.model.EMLEPMaximusVO;
import com.ps.mss.dao.model.EmBBBPaymentDtlInvoiceVO;
import com.ps.mss.dao.model.EmCorrVarDataVO;
import com.ps.mss.dao.model.EmMbrAgentVO;
import com.ps.mss.dao.model.EmMbrLepAttestInfoVO;
import com.ps.mss.dao.model.LepPtnlUncovMthsVO;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.BeneficiaryPymtDetailVO;
import com.ps.mss.model.DiscrepancyDashBoardVO;
import com.ps.mss.model.DiscrepancyDetailVOList;
import com.ps.mss.model.DiscrepancyListVO;
import com.ps.mss.model.EEMApplicationVO;
import com.ps.mss.model.FilterVO;
import com.ps.mss.model.HPEEncounterVO;
import com.ps.mss.model.LettersDashboardList;
import com.ps.mss.model.LettersFilter;
import com.ps.mss.model.LettersItem;
import com.ps.mss.model.LettersListItem;
import com.ps.mss.model.MedicareEventVOList;
import com.ps.mss.model.PaymentDashBoardVO;
import com.ps.mss.model.PaymentSummaryVOList;
import com.ps.mss.model.PdeDashboardVO;
import com.ps.mss.model.PdeDetailVO;
import com.ps.mss.model.PdeEventDetailVoList;
import com.ps.mss.model.ProfileSearchDetailVO;
import com.ps.mss.model.RapsClaimDetailItem;
import com.ps.mss.model.RapsClaimsDetailPage;
import com.ps.mss.model.RapsDetailItem;
import com.ps.mss.model.RapsDetailPage;
import com.ps.mss.model.RapsErrorsItem;
import com.ps.mss.model.RapsErrorsHistoryItem;
import com.ps.mss.model.RapsErrorsPage;
import com.ps.mss.model.TroopDashBoardVOList;
import com.ps.mss.model.TroopDetailVOList;
import com.ps.mss.web.forms.GenericDisplayPageForm;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.util.DateMath;
import com.ps.util.DateUtil;
import com.ps.util.NameValuePair;
import com.ps.util.StringUtil;
import com.ps.mss.security.SessionManager;

import java.sql.Connection;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.DbConnWeb;
import com.ps.mss.db.MBD;
import com.ps.mss.web.helper.AjaxHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.text.ParseException;



/**
 * @author indrapradja.adriana
 *
 */
public class FacadeManager {
	private static Logger logger=LoggerFactory.getLogger(FacadeManager.class);
	 //Session management  IFOX-00428243 : end 
	public Object[] extendSession(int sessionCount)throws ApplicationException{
		
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		HttpSession sesObj = sessionHelper.getSession();
		sesObj.setAttribute("extendCounter", sessionCount);
		sesObj.setMaxInactiveInterval(900);//allow extending session for 15 min after sxesion expire 
		//System.out.println("Session id in manager--"+sesObj.getId());
		//System.out.println(" Session in extendSession"+ sesObj.getLastAccessedTime());
		Object[] returnValue = new Object[3];
		returnValue[0] = sesObj.getLastAccessedTime();
		returnValue[1] = sesObj.getMaxInactiveInterval();
		returnValue[2] = sesObj.getAttribute("extendCounter");
		return returnValue;
	}
	 //Session management  IFOX-00428243 : end 
	public String isExportDiscDetailRequestValid(String menuName, String pageType)throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		return new DiscrepancyFacadeManager().isExportDiscDetailRequestValid(menuName, pageType);
	}
	public DiscrepancyDetailVOList getDiscrepancyList(String move, String menuName, String partName, String pageType ) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		return new DiscrepancyFacadeManager().getDiscrepancyList(move, menuName, partName, pageType);
	}
	public DiscrepancyDashBoardVO[] getDiscrepancyDashBoard(String searchType, FilterVO filterVO, String menuName) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		return new DiscrepancyFacadeManager().getDiscrepancyDashBoard(searchType, filterVO, menuName);
	}
	public GenericDisplayPageForm getDiscrepancyDetails(DiscrepancyListVO discList, int rowId ,String menuName, String pageType, String partName) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		return new DiscrepancyFacadeManager().getDiscrepancyDetails(discList, rowId, menuName, pageType, partName);
	}
	public NameValuePair [] getDiscrpType(String partName) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		return new DiscrepancyFacadeManager().getDiscrpType(partName);
	}
	public GenericDisplayPageForm updateDiscrepancyStatus(DiscrepancyListVO discrepancyVO, String menuName, String selectRow) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		return new DiscrepancyFacadeManager().updateDiscrepancyStatus(discrepancyVO, menuName, selectRow);
	}
	public int cancelWriteoffRequest(DiscrepancyListVO discrepancyListVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		return new DiscrepancyFacadeManager().cancelWriteoffRequest(discrepancyListVO);
	}
	public int updateDiscWriteOff(DiscrepancyListVO discrepancyListVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		return new DiscrepancyFacadeManager().updateDiscWriteOff(discrepancyListVO);
	}
	
	public MedicareEventVOList getMedicareEventList(String month,String year,String action) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		return new EventCalendarFacadeManager().getMedicareEventList(month, year, action);
	}
	public String getCurrentDate()throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		return new EventCalendarFacadeManager().getCurrentDate();
	}
	
	public String[] createExport(String tableName,  String exportType, String uiContextRange , String menuName ,
			  String searchType,  String pageType, String partName,Map parameterMap, String expandedItems ) throws ApplicationException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		return new ExportFacadeManager().createExport(tableName, exportType, uiContextRange, menuName, 
			searchType, pageType, partName, parameterMap, expandedItems);
	}
	
	public String[] createEncounterExport(String tableName, String exportType, String claimType,boolean historyFlag,String uiContextRange) throws ApplicationException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		return new ExportFacadeManager().createEncounterExport(tableName, exportType,claimType, historyFlag,uiContextRange);
	}
	public void setSelectedTab(String mainTabName,String encType) throws ApplicationException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		new UtilityFacadeManager().setSelectedTab(mainTabName,encType);
	}
	//-------- UPDATABLE ADDITION CODE : SWAGAT-----------
	public String addUpdatableFields(HPEEncounterVO encounterVO) throws ApplicationException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		return new UtilityFacadeManager().addUpdatableFields(encounterVO);
	}
	public String[] createFileTrackExport(String subId, String subFrom, String subTo, String fName, String typBus,String tableName, String exportType, String claimType,boolean historyFlag,String uiContextRange) throws ApplicationException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		return new ExportFacadeManager().createFileTrackExport(subId, subFrom, subTo, fName, typBus, tableName, exportType,claimType, historyFlag,uiContextRange);
	}
	
	public String isExportRequestValid(String pageName)throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		return new ExportFacadeManager().isExportRequestValid(pageName);
	}
	
	public PaymentDashBoardVO[] getPlanDashBoard (String searchType, FilterVO filterVO, String menuName) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		return new PaymentFacadeManager().getPlanDashBoard(searchType, filterVO, menuName);
	}
	
	public PaymentSummaryVOList getPaymentSummary(String searchType, FilterVO filterVO, String partName) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		return new PaymentFacadeManager().getPaymentSummary(searchType, filterVO, partName);
	}
	public BeneficiaryPymtDetailVO [] getPymtDetailOnEffDate(String effDate, String partName, boolean isPopUp, String paymentType, String pageType) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		return new PaymentFacadeManager().getPymtDetailOnEffDate(effDate, partName, isPopUp, paymentType, pageType);
	}
	public void saveUiContext(String [] uiContext, String pageName, String menuName, String pageType) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		new PaymentFacadeManager().saveUiContext(uiContext, pageName, menuName, pageType);
	}
	public List getLastSelectedTab(String menuName) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		return new PaymentFacadeManager().getLastSelectedTab(menuName);
	}
	public String isExportPdeDetailRequestValid()throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		return new PdeTroopFacadeManager().isExportPdeDetailRequestValid();
	}
	public String isExportTroopDetailRequestValid()throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		return new PdeTroopFacadeManager().isExportTroopDetailRequestValid();
	}
    public TroopDashBoardVOList getTroopDashBoard (String searchType, FilterVO filterVO) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new PdeTroopFacadeManager().getTroopDashBoard(searchType, filterVO);
    }
    public TroopDetailVOList getTroopDetail(String move ) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new PdeTroopFacadeManager().getTroopDetail(move);
    }
    public PdeDetailVO getPdeDetail(String seqNum, int rowId, String menuName) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
    	return new PdeTroopFacadeManager().getPdeDetail(seqNum, rowId, menuName);
    }
    public PdeDashboardVO[] getPdeDashBoard (String searchType, FilterVO filterVO, String menuName) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new PdeTroopFacadeManager().getPdeDashBoard(searchType, filterVO, menuName);
    }
    public PdeEventDetailVoList getPdeEventDetailList(String move) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new PdeTroopFacadeManager().getPdeEventDetailList(move);   	
    }
    public PdeEventDetailVoList getPdeErrDetailList(String move) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new PdeTroopFacadeManager().getPdeErrDetailList(move);
    }
	public ProfileSearchDetailVO getProfileSearchDetailVO(String move, String menuName, String partName, String pdFetchList) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		return new ProfileFacadeManager().getProfileSearchDetailVO(move, menuName, partName, pdFetchList);
	}
    public RapsDetailPage getRapsDetailPage(String move) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new RapsFacadeManager().getRapsDetailPage(move);
    }
    public RapsDetailPage getRapsDetail(int rowId, RapsDetailItem rapsDetailItem) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
    	return new RapsFacadeManager().getRapsDetail(rowId, rapsDetailItem);
    }
    public RapsClaimsDetailPage getRapsClaimDetailPage(String move) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new RapsFacadeManager().getRapsClaimDetailPage(move);
    }
    public RapsClaimsDetailPage getRapsClaimDetail(int rowId, RapsClaimDetailItem rapsDetailItem) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
    	return new RapsFacadeManager().getRapsClaimDetail(rowId, rapsDetailItem);
    }
    public RapsErrorsPage getRapsErrorsPage(String move) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new RapsFacadeManager().getRapsErrorsPage(move);
    }
    public RapsErrorsPage getRapsErrorsDetail(int rowId, RapsErrorsItem rapsErrorsItem) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
    	return new RapsFacadeManager().getRapsErrorsDetail(rowId, rapsErrorsItem);
    }
    public RapsErrorsHistoryItem[] updateErrorStatus(int rowId, RapsErrorsItem rapsErrorsItem, String newStatus, String newComment, boolean changeStatus) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new RapsFacadeManager().updateRapsErrorStatusComment(rowId, rapsErrorsItem, newStatus, newComment, changeStatus);
    }
    public LettersListItem getLettersDetail(String region, int rowId, LettersItem lettersItem) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
    	return new LettersFacadeManager().getLettersDetail(region, rowId, lettersItem);
    }
    public LettersListItem getLettersPage(String region, String move) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
    	return new LettersFacadeManager().getLettersListItem(region, move);
    }
    public LettersDashboardList getLettersDashboard(String region, String move) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
    	return new LettersFacadeManager().getLettersDashboardList(region, move);
    }
    public LettersItem updateLetterStatus(String region, int rowId, LettersItem lettersItem, String newStatus, String newDeleteInd) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
    	return new LettersFacadeManager().updateLetterStatus(region, rowId,lettersItem,newStatus,newDeleteInd);
    }
    public int massUpdateLetterStatus(String region, LettersFilter criteria) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
    	return new LettersFacadeManager().massUpdateLetterStatus(region, criteria);
    }
    public int lettersGenerateRequest(String region) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
    	return new LettersFacadeManager().lettersGenerateRequest(region);
    }
    public EEMApplicationVO getProducts(String groupName, String productName, String zipCode5,
			String zipCode4, String planId, String pbp, String segment,
			String outOfArea, String covDt, String type) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getProducts(groupName, productName, zipCode5,
				zipCode4, planId, pbp, segment, outOfArea, covDt, type);
	}
    public NameValuePair[] getSelectOptions(String source, String option1) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getSelectOptions(source, option1);
    }
    public NameValuePair[] getAgencies(String covDt, String lob) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getAgencies(covDt, lob);
    }
	
	// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - Start
    public NameValuePair[] getBrokerAgents(String type, String agencyId,String singDt,
			String covDt,String lob) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	System.out.println("covDt is "+ covDt);
    	System.out.println("Sign Dt is "+ singDt);
    	logger.info(LoggerConstants.methodEndLevel());
       	return new EEMFacadeManager().getBrokerAgents(type, agencyId,singDt, covDt, lob);
    }
  //IFOX-00415856 - New Agent Look Up CR :START
    public NameValuePair[] getAgentName(String type, String agencyId,String singDt,
			String covDt, String agentId, String lob) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	System.out.println("covDt is "+ covDt);
    	System.out.println("Sign Dt is "+ singDt);
    	logger.info(LoggerConstants.methodEndLevel());
       	return new EEMFacadeManager().getAgentName(type, agencyId,singDt, covDt, agentId, lob);
    }
  //IFOX-00415856 - New Agent Look Up CR :END
    // IFOX-00397816 : Add comments button
    public String updateComments(String customerId,String appId, String commentListString) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	System.out.println("updateComments customerId:"+customerId+" ,appId:"+appId+" ,commentListString:"+commentListString);
    	logger.info(LoggerConstants.methodEndLevel());
    	return new EEMFacadeManager().updateComments(customerId,appId, populateCommentsList(customerId, appId,commentListString));
       }
    
	// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - End
	/** BasePlus change - swagat: start */	
    public List getCounty(String zip5, String zip4) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getCounty(zip5, zip4);
       }
    public List getCity(String zip5, String zip4) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getCity(zip5, zip4);
    	}
    public List getCities(String zip5, String zip4 , String county) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getCities(zip5, zip4,county);
    }
	   /** BasePlus change - swagat: End */
    
    /*For Defect#93,42-Hometown */
    public List getMailingAddress(String zip5, String zip4){
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getMailingAddress(zip5, zip4);
    }
    /** print ID card trigger**/
    public String insertPrintIDCardMbrTrigger(String concatenatedValue){
    	logger.info(LoggerConstants.methodStartLevel());   	
    	return new EEMFacadeManager().insertPrintIDCardMbrTrigger(concatenatedValue);
    }
    public String[] getCityName(String zip5, String zip4) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getCityName(zip5, zip4);
    }
    public String getBillMbrGrpName(String id, String mbrGrpInd) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getBillMbrGrpName(id, mbrGrpInd);
    }
    public String getTotalInvoiceDetailAmt(String customerId, String invoiceNbr, String itemNbr) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getTotalInvoiceDetailAmt(customerId, invoiceNbr, itemNbr);
    }
    public String getTimeStamp(String format) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getTimeStamp(format);
    }
    public String getInstDetails(String instId, String dateOfCov, String lob) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getInstDetails(instId, dateOfCov, lob);
    }
    public NameValuePair[] getInstLookUp(String dateOfCov, String lob) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getInstLookUp(dateOfCov, lob);
    }
	/**
	 * Updated signature for IFOX-00389053 
	 * Added Line of Business
	 * Updated code to include LOB while fetching the results
	 */
    public EEMApplicationVO getPCPName(String dateOfCov, String docName,
			String currPatient,String lob) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getPCPName(dateOfCov, docName, currPatient,lob);
    }
    public String checkMember(String hicNbr, String applType, String reqDtCov)
			throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().checkMember(hicNbr, applType, reqDtCov);
    }
    public EmCorrVarDataVO [] getLetterVarData(int rowNbr) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMEnrollFacadeManager().getLetterVarData(rowNbr);
    }
    public EmBBBPaymentDtlInvoiceVO[] getPaymentDetail(String row, String isMember) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getPaymentDetail(row, isMember);
    }
    public EmBBBPaymentDtlInvoiceVO[] getMembPaymentDetail(String row, String isMember) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getPaymentDetail(row, isMember);
    }
    public NameValuePair[] getAgencyList(String dateOfCov, String lob) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getAgencyList(dateOfCov, lob);
    }
    public EmMbrAgentVO getAgencyDetails(String agencyId, String startDate, String lob) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getAgencyDetails(agencyId, startDate, lob);
    }
    public EmMbrAgentVO getAgentDetails(String agencyId, String agentType, String agentId, String startDate, String lob) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getAgentDetails(agencyId, agentType, agentId, startDate, lob);
    }
    
    //original application start
    public boolean checkOriginalApplication(String applId, String customerId) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().checkOriginalApplication(applId, customerId); 
    	
    }
    //original application end	
	   /**
 * 045_AssignActivity Starts
 */
/**
 * 
 * @param supervisiorId holds supervisorId value
 * @param customerId holds customerId value
 * @return responseList
 * @throws ApplicationException throws when code fails to execute
 */
@SuppressWarnings("rawtypes")
public List getUserList(String supervisiorId, String customerId, String userLevel) throws ApplicationException{
	logger.info(LoggerConstants.methodStartLevel());
	Connection conn = null;
	List responseList = new ArrayList();
	try {
		
		conn = DbConnWeb.getConnection();
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		conn = DbConn.reGetConnection(conn,eemDb);
		responseList = new EEMFacadeManager().getUserList(conn,supervisiorId,customerId,userLevel);		
		
	}catch (Exception e) {
		logger.error(LoggerConstants.exceptionMessage(e.toString()));
		//System.out.println(e.getMessage());
		throw new ApplicationException(e);
	} finally {
		try {
			if (conn != null)
				conn.close();
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//System.out.println(e.getMessage());
		}
	}
	logger.info(LoggerConstants.methodEndLevel());
	return responseList;
}
/**
 * This method is used to get supervisorId for a selected userId
 * @param userId holds userId value
 * @param customerId holds customerId value
 * @return supervisorId which holds String value returned by query
 * @throws ApplicationException throws when code failed to execute
 */
public String getSupervisorId(String userId, String customerId) throws ApplicationException{
	logger.info(LoggerConstants.methodStartLevel());
	Connection conn = null;
	String supervisorId = null;
	try {
		
		conn = DbConnWeb.getConnection();
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		conn = DbConn.reGetConnection(conn,eemDb);
		supervisorId = new EEMFacadeManager().getSupervisorId(conn,userId,customerId);		
		
	}catch (Exception e) {
		System.out.println(e.getMessage());
		throw new ApplicationException(e);
	} finally {
		try {
			if (conn != null)
				conn.close();
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//System.out.println(e.getMessage());
		}
	}
	logger.info(LoggerConstants.methodEndLevel());
	return supervisorId;
}
/**
 * 045_AssignActivity Ends
 */

	/**
	 * This method will retrieve queue lst of a user based upon search by supervisor.
	 * @param txn holds transaction type (add/update/delete)
	 * @param prty holds priority method (Critical/High/Medium/Low)
	 * @param userId holds user Id for which queue data to be modified.
	 * @return List of queues with queue_CD and Queue_name. 
	 */
	@SuppressWarnings("rawtypes")
	public List supWorkFlowUserQuesChange(String txn, String prty, String prtyMtd, String userId) throws ApplicationException, ParseException {	
		logger.info(LoggerConstants.methodStartLevel());
		List queList = new ArrayList();
		try {
			queList = new WorkFlowFacadeManager().getSupWFUsrQueChangesLst(txn, prty, prtyMtd, userId);
		}catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//System.out.println(e.getMessage());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return queList;
	}//supWorkFlowUserQuesChange()

	/**
	 * This method will update queue data of a user by the supervisor.
	 * @param txn holds transaction type (add/update/delete)
	 * @param prty holds priority method (Critical/High/Medium/Low)
	 * @param queue holds queue code
	 * @param userId holds user Id for which queue data to be modified.
	 * @param supUserId holds supervisor user Id.
	 * @return boolean whether transaction success/failure.
	 */
	public boolean supWorkFlowUserQueUpdate(String txn, String prty, String queue, String userId, String supUserId) throws ApplicationException, ParseException {
		logger.info(LoggerConstants.methodStartLevel());
		boolean success = false;
		try { 
			success = new WorkFlowFacadeManager().supWorkFlowUserQueUpdate(txn, prty, queue, userId, supUserId);
		}catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//System.out.println(e.getMessage());
		} 
		logger.info(LoggerConstants.methodEndLevel());
		return success;
	}//supWorkFlowUserQueUpdate()

	
	/**
	 * This method will retrieve queue lst of a user based upon search by supervisor.
	 * @param txn holds transaction type (add/update/delete)
	 * @param prty holds priority method (Critical/High/Medium/Low)
	 * @param userId holds user Id for which queue data to be modified.
	 * @return List of queues with queue_CD and Queue_name. 
	 */
	@SuppressWarnings("rawtypes")
	public List supLoadUserQNames(String userId) throws ApplicationException, ParseException {	
		logger.info(LoggerConstants.methodStartLevel());
		List queList = new ArrayList();
		try {
			queList = new WorkFlowFacadeManager().getUserQNames(userId);
		}catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//System.out.println(e.getMessage());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return queList;
	}//supLoadUserQNames()

	
	
	@SuppressWarnings("rawtypes")
	public List adminHistLoadSuprvs(String adminId) throws ApplicationException{	
		logger.info(LoggerConstants.methodStartLevel());
		List queList = new ArrayList();
		try {
			queList = new WorkFlowFacadeManager().getAdminHistSuprvLst(adminId);
		}catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//System.out.println(e.getMessage());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return queList;
	}//adminHistLoadSuprvs()
	
	
	@SuppressWarnings("rawtypes")
	public List adminHistLoadUsers(String suprvId) throws ApplicationException{	
		logger.info(LoggerConstants.methodStartLevel());
		List queList = new ArrayList();
		try {
			queList = new WorkFlowFacadeManager().getAdminHistUserLst(suprvId);
		}catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			System.out.println(e.getMessage());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return queList;
	}//adminHistLoadUsers()
    // Start -- Modified for Letter Review QC
    public List getFileBatchId(String fromDate, String toDate) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
    	List batchIdList = new ArrayList();
    	logger.info(LoggerConstants.methodEndLevel());
    	return new LettersFacadeManager().getFileBatchId(fromDate,toDate);
	}
	public List getLetterDesc(String batchId) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		return new LettersFacadeManager().getLetterDesc(batchId);
	}
	// End -- Modified for Letter Review QC
	 /**
  	 * Excellus letter Request #17
  	 * author - pranitha
  	 */
   public ArrayList getPlanDetails(String primaryId,String effdate) throws ApplicationException {
	   logger.info(LoggerConstants.methodStartLevel());
	   return new EEMFacadeManager().getPlanDetails(primaryId,effdate);
   }
   
// IFOX-00381706 - COB Fix CR Summacare - Start
   public String getCOBParmCD(String isInCmpltCOB) throws ApplicationException {
	   logger.info(LoggerConstants.methodStartLevel());
	   return new EEMFacadeManager().getCOBParmCD(isInCmpltCOB);
	   }
// IFOX-00381706 - COB Fix CR Summacare - End
   
 //new LEP changes -- start
 	public boolean fetchActiveUncovRecords(String customerId, String Id, String startDate, String endDate,
 			String tableName, String type) throws ApplicationException {
 		logger.info(LoggerConstants.methodStartLevel());
 		Connection conn = null;
 		boolean result=false;
 		boolean result2=false;
 		try {
 			conn = DbConnWeb.getConnection();
 			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
 			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
 			conn = DbConn.reGetConnection(conn,eemDb);

 			String uncovMthStDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(startDate));
 			String uncovMthEnDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(endDate));
 			
 			EEMApplDao applDao = new EEMApplDao();
 			List fetchActiveUncovRecords = applDao.fetchActiveUncovRecords(conn, customerId, Id, tableName, type);
 			Iterator itr = fetchActiveUncovRecords.iterator();
 			
 			while (itr.hasNext() && !result) {
 				LepPtnlUncovMthsVO lepVo = (LepPtnlUncovMthsVO) itr.next();
 				if (DateMath.isBetween(uncovMthStDt, lepVo.getUncovMthStDt(), lepVo.getUncovMthEndDt()) ||
 						DateMath.isBetween(uncovMthEnDt, lepVo.getUncovMthStDt(), lepVo.getUncovMthEndDt())) {
 					result = true;
 				}
 				if (DateMath.isBetween(lepVo.getUncovMthStDt(), uncovMthStDt, uncovMthEnDt) ||
 						DateMath.isBetween(lepVo.getUncovMthEndDt(), uncovMthStDt, uncovMthEnDt)) {
 					result2 = true;
 				}
 				
 			}
 			
 			if(result || result2){
 				logger.info(LoggerConstants.methodEndLevel());
 				return true;
 			}
 			
 		}catch (Exception e) {
 			logger.error(LoggerConstants.exceptionMessage(e.toString()));
 			//System.out.println(e.getMessage());
 			throw new ApplicationException(e);
 		} finally {
 			try {
 				if (conn != null)
 					conn.close();
 			} catch(Exception e) {
 				logger.error(LoggerConstants.exceptionMessage(e.toString()));
 				//System.out.println(e.getMessage());
 			}
 		}
 		logger.info(LoggerConstants.methodEndLevel());
 		return result;
 	}
 	
 	public boolean getApplAttnDetails(String applId){
 		logger.info(LoggerConstants.methodStartLevel());
 		return new EEMFacadeManager().getApplAttnDetails(applId);
 	}
	/* Added for IFOX-00406912 Primary Procedure Code*/	
	public String checkDupPrincipalProcCode(String mfId,String clmNbr,int clmRvNbr,int cndSqNbr,String encType,int clmSqNbr) throws ApplicationException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		return new UtilityFacadeManager().checkDupPrincipalProcCode(mfId,clmNbr,clmRvNbr,cndSqNbr,encType,clmSqNbr);
	}
 	
 // new LEP Member's changes -- start
    public EMLEPMaximusVO updateLepMaximus(String caseFileRecDate, String decisionRecDate, String decisionType,
                  String caseFileNumber, String memberId, String createTime, String isUpdate) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().updateLepMaximus(caseFileRecDate, decisionRecDate, decisionType, caseFileNumber,
                        memberId, createTime, isUpdate);
    }
    // new LEP changes -- end
    
    // new LEP Member's changes -- start
    public boolean getEnrollMbrAttnDetails(String memberId){
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().getEnrollMbrAttnDetails(memberId);
    }
    
    public boolean validateLEPAttesCovMnth(String memberId){
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().validateLEPAttesCovMnth(memberId);
    }
    public EmMbrLepAttestInfoVO updateAttes90DaysInfo(String memberId,String atRecdate,String  atChannel, String appealFlag){
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().updateAttes90DaysInfo(memberId, atRecdate, atChannel, appealFlag);
    }
    // new LEP changes -- end
    
    /*IFOX-00397816 : Add comments button*/
    ArrayList<EEMApplCommentsVO> populateCommentsList(String customerId,String appId,String commentListString){
    	logger.info(LoggerConstants.methodStartLevel());
    	ArrayList<EEMApplCommentsVO> lstComments=new ArrayList<EEMApplCommentsVO>();
    	String[] splittedStr=StringUtil.splitByDelimiter(commentListString,"~");
    	for(int i=0;i< splittedStr.length;i++ ){
    		EEMApplCommentsVO commentVO=new EEMApplCommentsVO();
    		String[] tokenArr=StringUtil.splitByDelimiter(commentListString,"|");	
    		commentVO.setCustomerId(customerId);
    		commentVO.setApplicationId(appId);    		
    		commentVO.setCreateTime(tokenArr[0]);
    		commentVO.setCreateUserId(tokenArr[1]);
    		commentVO.setApplComments(tokenArr[2]);
    		commentVO.setInsert(tokenArr[3]);
    		lstComments.add(commentVO);
    	}
    	logger.info(LoggerConstants.methodEndLevel());
    	return lstComments;
    }
    
    // IFOX-00400257 : START
    public boolean validateInvoiceId(String toValidate) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	return new EEMFacadeManager().validateInvoiceId(toValidate);
    }
    // IFOX-00400257 : END
    //Super User changes - start
  	/**
  	 * Method is used to fetch the MED HIC details
  	 * @param hicNbr
  	 * @return
  	 * @throws ApplicationException
  	 */
  	public Map<String, String> checkMEDvalue(String hicNbr) throws ApplicationException {
  		logger.info(LoggerConstants.methodStartLevel());
  		System.out.println("MED in facade manager" + hicNbr);
  		MBD mbd = new EEMFacadeManager().checkMEDvalue(hicNbr);
  		Map<String, String> mbdData = new HashMap<String, String>();
  		if (mbd != null) {
  			mbdData.put("dataFound", "true");
  			mbdData.put("hicNbr", mbd.getHicNbr());
  			mbdData.put("firstName", mbd.getFirstName());
  			mbdData.put("lastName", mbd.getLastName());
  			mbdData.put("middleName", mbd.getMiddleInit() != null ? mbd.getMiddleInit() : "");
  			mbdData.put("birthDate", DateUtil.formatMmDdYyyy(mbd.getBirthDate()));
  		} else {
  			mbdData.put("dataFound", "false");
  		}
  		logger.info(LoggerConstants.methodEndLevel());
  		return mbdData;
  	}
  	//Super User changes - end
  	
  	// CMS 2019 changes- requirement 5-Start
 	public String getCcmDate() throws ApplicationException {
 		logger.info(LoggerConstants.methodStartLevel());
 		return new EEMFacadeManager().getCcmDate();
 	}
 	// CMS 2019 changes- requirement 5-End
 	/**AAH BasePlus Migration IFOX-00426351 START*/
 	public String getLOBAAHQ(String prodId,String effDate) {
 		return new EEMFacadeManager().getLOBAAHQ(prodId,effDate);
 	}
 	/**AAH BasePlus Migration IFOX-00426351 END*/
 	/* Added for IFOX-00406912 Primary Procedure Code*/	
 	
 	/*June 2020 CMS changes - start*/
 	 public String getTrrData(String memberId, String replyCd) throws ApplicationException {
 		String replyCD =replyCd.substring(0, 3);
     	logger.info(LoggerConstants.methodStartLevel());
     	System.out.println("memberIdis "+ memberId);
        System.out.println("replyCd is "+ replyCd);
     	 	return new EEMFacadeManager().getTrrDataFlag(memberId, replyCD);
     }
 	/*June 2020 CMS changes - end*/
 	//IFOX - 431608 : CMS Changes 2020 - start
 	public String trigger92TXN(String memberId) throws ApplicationException {
 		
     	logger.info(LoggerConstants.methodStartLevel());
     	System.out.println("memberIdis "+ memberId);
       
     	 	return new EEMFacadeManager().trigger92TXN(memberId);
     }
 	//IFOX - 431608 : CMS Changes 2020 - end
 	//IFOX - 426356 Attachment CR : start
 	 public String[] getMemberDetails(String type, String primaryId) throws ApplicationException {
     	logger.info(LoggerConstants.methodStartLevel());
     	return new EEMFacadeManager().getMemberDetails(type, primaryId);
     }
 	//IFOX - 426356 Attachment CR : end
 	 
 	 public List<String> getDiscList(String user) throws ApplicationException {
      	logger.info(LoggerConstants.methodStartLevel());
      	List<String> discs = null;
      	SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
      	HashMap<String, List> listMap = (HashMap<String, List>) sessionHelper.getAttribute("autoAsgnMap");
      	if(listMap != null && listMap.size() >0 ){
      		for (String key : listMap.keySet()) {
      		    if(key.contains(user)){
      		    	discs = new ArrayList<String>();
      	      		discs = listMap.get(key);
      		    }
      		}
      		
      		
      	}
      	return discs;

      }
 	 
 	 public String validateAutoAssignTask(String selected, String reassignTo) throws ApplicationException {
       	logger.info(LoggerConstants.methodStartLevel());
       	ProfileDao profDao = null;
       	String msg = null;
       	try {
	       		
	       		Connection conn = DbConnWeb.getConnection();
				SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
				String eemDb = (String)sessionHelper.getAttribute(SessionManager.RECONDB);
				conn = DbConn.reGetConnection(conn,eemDb);
		
				
				DaoFactory factory = DaoFactory.getInstance();
			
				String dbId = sessionHelper.getActiveDataBaseName();
				Map planMap = sessionHelper.getPlanForParts();
				String user = sessionHelper.getUserId();
				profDao = factory.getProfileDao(dbId);
				msg = profDao.validateAutoAssignTask(planMap,selected,reassignTo,user);
				
				
			} catch(Exception e){
				e.printStackTrace();
			}
       		finally { //This block will execute after execution of this method.
				if(profDao != null)
					profDao.closeConnection();
			}
			return msg;

 	 }
}


