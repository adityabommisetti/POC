package com.ps.mss.web.actions;

import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.model.McaidPaymentDashBoardVO;
import com.ps.mss.db.DbConn;
import com.ps.mss.framework.McaidReconConstants;
import com.ps.mss.manager.McaidReconManager;
import com.ps.mss.model.McaidReconContext;
import com.ps.mss.security.SessionManager;
import com.ps.mss.util.MssProperties;
import com.ps.mss.web.forms.McaidReconAnomForm;
import com.ps.mss.web.forms.McaidReconBaseForm;
import com.ps.mss.web.forms.McaidReconDiscForm;
//import com.ps.mss.web.forms.McaidReconFCLOForm;
import com.ps.mss.web.forms.McaidReconFileForm;
import com.ps.mss.web.forms.McaidReconPaymentForm;
import com.ps.mss.web.helper.McaidReconAnomHelper;
import com.ps.mss.web.helper.McaidReconDiscHelper;
import com.ps.mss.web.helper.McaidReconFileHelper;
import com.ps.mss.web.helper.McaidReconPaymentHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.web.process.McaidReconProcess;
import com.ps.util.StringUtil;

public class McaidReconAction  extends Action {
	private static Logger logger=LoggerFactory.getLogger(McaidReconAction.class);

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		
		Connection conn = null;
		try {
			String target = null;
			McaidReconBaseForm mcBaseReconForm = (McaidReconBaseForm) form;
			String method = mcBaseReconForm.getMethod();
			
			// use the default DB for security check
			conn = DbConn.getConnection();
			SessionHelper sessionHelper = new SessionHelper(request);
			String errorMsg = sessionHelper.validateUser(conn);
			if (errorMsg != null) {
				request.setAttribute("Msg", "Login Has Timed Out");
				throw new Exception(errorMsg);
			}


			McaidReconContext context = McaidReconManager.getContext(sessionHelper.getSession());
			//Common login code has been commented as this is planned for later release.
			/* String source = request.getParameter("source");

			//if(null != mcBaseReconForm.getMenu() && (mcBaseReconForm.getMenu().equals("NM") || mcBaseReconForm.getMenu().equals("IL") || mcBaseReconForm.getMenu().equals("TX")))
			if(null != source && source.trim().equals("MCaidReconTabs"))
			{
				MCaidReconSessionHelper mCaidReconSessionHelper = new MCaidReconSessionHelper();
				mCaidReconSessionHelper.resetMedicaidReconObjects(context);
				mCaidReconSessionHelper.resetSessionAttibutes(conn, request, this.getMCaidReconGroupId(mcBaseReconForm));
			}*/


			String eemDb = (String)sessionHelper.getAttribute(SessionManager.RECONDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			// For QA
			/*String eemdb = sessionHelper.getDBBasedOnUserId();*/
			String eemdb = sessionHelper.getActiveDataBaseName();
			conn = DbConn.reGetConnection(conn, eemdb);
			//For QA
			
			//McaidReconContext context = McaidReconManager.getContext(sessionHelper.getSession());
			
			if(null != method && method.equals("paymentInialize")) {
				context.setSelectedMenu("Payment");
			} else {
				if(null != method && method.equals("discrepancySummaryDashboard")) {
					method = McaidReconConstants.SUMM_GO_OPT;
					this.setDescrepancySummarySearchFields(mcBaseReconForm, request, context);
				}
			}
			
			String selectedMenu = context.getSelectedMenu();
			logger.debug("McaidReconAction.execute()::::selectedMenu::"+selectedMenu);
			logger.debug("McaidReconAction.execute():::method::::"+method);
			logger.debug(" menu---form::"+mcBaseReconForm);
			mcBaseReconForm.setMessage(null);// Reset the Exception/Error messages
			
			if ("initialize".equals(method)) {
				logger.debug("I am in action:: initialize method");				
				logger.info(LoggerConstants.methodEndLevel());
				return initialize(conn, sessionHelper, context, mapping, mcBaseReconForm, request);				
			} 
			else if ("switchMenu".equals(method)) {
				String menu = mcBaseReconForm.getMenu();
				logger.debug(" menu---form::"+mcBaseReconForm);
				if(mcBaseReconForm instanceof McaidReconDiscForm) {
					McaidReconDiscHelper.saveDiscForm(sessionHelper,(McaidReconDiscForm)mcBaseReconForm);
				}
				else if(mcBaseReconForm instanceof McaidReconPaymentForm) {
					//McaidReconPaymentHelper.setDsbLatestPbpVosToForm(context, (McaidReconPaymentForm)mcBaseReconForm);
					McaidReconPaymentHelper.savePaymentForm(sessionHelper,(McaidReconPaymentForm)mcBaseReconForm);
				}
				else if(mcBaseReconForm instanceof McaidReconAnomForm) {
					McaidReconAnomHelper.saveAnomForm(sessionHelper,(McaidReconAnomForm)mcBaseReconForm);
				}	
				else if(mcBaseReconForm instanceof McaidReconFileForm) {
					McaidReconFileHelper.saveFileForm(sessionHelper,(McaidReconFileForm)mcBaseReconForm);
				}
				//------------	
				
				if (McaidReconConstants.MENU_DISC.equals(menu)){
					logger.info(LoggerConstants.methodEndLevel());
					return discrepencyMenu(conn, sessionHelper, context, mapping, form, request);
				}
				else if (McaidReconConstants.MENU_PAYMENT.equals(menu)){					
					logger.info(LoggerConstants.methodEndLevel());
					return paymentMenu(conn, sessionHelper, context, mapping, form, request);
				}
				else if (McaidReconConstants.MENU_ANOM.equals(menu)){
					logger.info(LoggerConstants.methodEndLevel());
					return anamolyMenu(conn, sessionHelper, context, mapping, form, request);
				}
				else if (McaidReconConstants.MENU_FILE.equals(menu)) {
					logger.info(LoggerConstants.methodEndLevel());
					return fileMenu(conn, sessionHelper, context, mapping, form, request);
				}
			}//--switchMenu-END
			
			else 
				if(null != method && "paymentInialize".equals(method)) { //ZZZZZZZZ
					
					McaidReconPaymentForm mcaidPaymentForm = (McaidReconPaymentForm) form;
					String menu = mcaidPaymentForm.getMenu();
					if(menu.equals("IL")){
						sessionHelper.setAttribute(McaidReconConstants.USER_STATE, McaidReconConstants.ST_ILLINOIS);
					}else if(menu.equals("NM")){
						sessionHelper.setAttribute(McaidReconConstants.USER_STATE, McaidReconConstants.ST_NEWMEXICO);
					}else if(menu.equals("TX")){
						sessionHelper.setAttribute(McaidReconConstants.USER_STATE, McaidReconConstants.ST_TEXAS);
					}else if(menu.equals("MT")){
						sessionHelper.setAttribute(McaidReconConstants.USER_STATE, McaidReconConstants.ST_MONTANA);
					}
					context.setStateCode((String)sessionHelper.getAttribute(McaidReconConstants.USER_STATE));
					logger.info(LoggerConstants.methodEndLevel());
					return paymentMenu(conn, sessionHelper, context, mapping, form, request);
					
				}
				else
					if (McaidReconConstants.MENU_PAYMENT.equals(selectedMenu)) {
				//return paymentDashboardMenu(conn, sessionHelper, context, mapping, form, request,method);
				target = new McaidReconProcess().paymentMenu(conn, sessionHelper, context, form, request, response, method);				
			}
			else if (McaidReconConstants.MENU_DISC.equals(selectedMenu)) {
				target = new McaidReconProcess().discrepancyMenu(conn, sessionHelper, context, form, request, response, method);
			}
			else if (McaidReconConstants.MENU_ANOM.equals(selectedMenu)) {
				target = new McaidReconProcess().anamolyMenu(conn, sessionHelper, context, form, request, response, method);
			}
			else if (McaidReconConstants.MENU_FILE.equals(selectedMenu)) {
				target = new McaidReconProcess().fileMenu(conn, sessionHelper, context, form, request, response, method);
			}
			
			if (target == null){
				target = "mcaidDisc";
			}
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward(target);
			

		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//logger.error(e.getMessage());
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				//logger.error(e.getMessage());
			}
		}		
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward("eemError");
	}//execute



	/*private ActionForward paymentDashboardMenu(Connection conn,
			SessionHelper sessionHelper, McaidReconContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request,
			String method) {
		String target = new McaidReconProcess().paymentMenu(conn, sessionHelper, context, form, request, method);
		
		System.out.println("McaidReconAction.paymentDashboardMenu()target:======="+target);
		return mapping.findForward(target);
	}*/



	private ActionForward initialize(Connection conn, SessionHelper sessionHelper, McaidReconContext context, ActionMapping mapping, McaidReconBaseForm mcBaseReconForm, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		String target = "error";
		String menu = "";
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.RECONDB);
		HttpSession session =request.getSession(false);
		McaidReconContext mcaidContext = (McaidReconContext)session.getAttribute("mcReconContext");
	
		//NEED TO TEST & WRITE CODE HERE- WHEN WINDOW IS CLOSED AND CLICKED ON MEDICAID RECON- THE LAST UI(FORM) SHOULD BE LOADED BASED ON LAST MENU SELECTED('context.selectedMenu').
		sessionHelper.removeAttribute("SavediscForm");
		sessionHelper.removeAttribute("SavePaymentForm");
		sessionHelper.removeAttribute("SaveAnomForm");
		
		context.setSelectedMenu(McaidReconConstants.MENU_DISC); //ZZZZZ
		//context.setSelectedMenu(McaidReconConstants.MENU_PAYMENT);
		
		menu = mcBaseReconForm.getMenu();
		if(menu.equals("IL")){
			sessionHelper.setAttribute(McaidReconConstants.USER_STATE, McaidReconConstants.ST_ILLINOIS);
		}else if(menu.equals("NM")){
			sessionHelper.setAttribute(McaidReconConstants.USER_STATE, McaidReconConstants.ST_NEWMEXICO);
		}else if(menu.equals("TX")){
			sessionHelper.setAttribute(McaidReconConstants.USER_STATE, McaidReconConstants.ST_TEXAS);
		}else if(menu.equals("MT")){
			sessionHelper.setAttribute(McaidReconConstants.USER_STATE, McaidReconConstants.ST_MONTANA);
		}
		context.setStateCode((String)sessionHelper.getAttribute(McaidReconConstants.USER_STATE));
		
		//ZZZZZ
		McaidReconDiscForm mcaidDiscForm = (McaidReconDiscForm)mcBaseReconForm;
		target = new McaidReconProcess().initDisc(conn, sessionHelper, context, mcaidDiscForm, request);
		//target = new McaidReconProcess().paymentMenu(conn, sessionHelper, context, mcBaseReconForm, request, "");
		logger.debug(" target=="+target);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(target); 
	}//initialize()
	
	private ActionForward discrepencyMenu(Connection conn, SessionHelper sessionHelper, McaidReconContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		long starttime = System.currentTimeMillis();
		String target = "error";
		McaidReconDiscForm mcaidDiscForm = null;
		context.setSelectedMenu(McaidReconConstants.MENU_DISC);
		logger.info(" discrepancyMenu");
		if (!(form instanceof McaidReconDiscForm)) {						
			mcaidDiscForm = McaidReconDiscHelper.getDiscForm(sessionHelper);			
			if (mcaidDiscForm == null) {
				mcaidDiscForm = new McaidReconDiscForm();							
			}
			mcaidDiscForm.setMenu("");
			mcaidDiscForm.setMethod("");
			request.setAttribute(McaidReconConstants.FORM_DISC, mcaidDiscForm);
		} else {
			mcaidDiscForm = (McaidReconDiscForm)form;
		}
		logger.info(" before going to target");
		target = new McaidReconProcess().initDisc(conn, sessionHelper, context, mcaidDiscForm, request);
		
		long endtime = System.currentTimeMillis();
		System.out.println("Difference in discrepencyMenu : " + (endtime-starttime));
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(target);
	}//discrepencyMenu()
	
	private ActionForward fileMenu(Connection conn, SessionHelper sessionHelper, McaidReconContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		String target = "error";
		McaidReconFileForm mcaidFileForm = null;
		context.setSelectedMenu(McaidReconConstants.MENU_FILE);
		logger.info(" fileMenu");
		if (!(form instanceof McaidReconFileForm)) {						
			mcaidFileForm = McaidReconFileHelper.getFileForm(sessionHelper);			
			if (mcaidFileForm == null) {
				mcaidFileForm = new McaidReconFileForm();							
			}
			mcaidFileForm.setMenu("");
			mcaidFileForm.setMethod("");
			request.setAttribute(McaidReconConstants.FORM_FILE, mcaidFileForm);
		} else {
			mcaidFileForm = (McaidReconFileForm)form;
		}
		logger.info(" before going to target");
		target = new McaidReconProcess().initFile(conn, sessionHelper, context, mcaidFileForm, request);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(target);
	}//fileMenu()
	
	/*//IFOX-00407694-FCLO/WRTO Changes: start
	private ActionForward fcloMenu(Connection conn, SessionHelper sessionHelper, McaidReconContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) {
		String target = "error";
		McaidReconFCLOForm mcaidFcloForm = null;
		//context.setSelectedMenu(McaidReconConstants.MENU_FCLO);
		System.out.println(" fcloMenu");
		if (!(form instanceof McaidReconFCLOForm)) {						
			//mcaidFcloForm = McaidReconFileHelper.getFileForm(sessionHelper);			
			if (mcaidFcloForm == null) {
				mcaidFcloForm = new McaidReconFCLOForm();							
			}
			mcaidFcloForm.setMenu("");
			mcaidFcloForm.setMethod("");
			request.setAttribute(McaidReconConstants.FORM_FCLO, mcaidFcloForm);
		} else {
			mcaidFcloForm = (McaidReconFCLOForm)form;
		}
		System.out.println(" before going to target");
		//target = "mcaidDiscFCLOSearch";
		target = new McaidReconProcess().initFclo(conn, sessionHelper, context, mcaidFcloForm, request);
		//target = new McaidReconProcess().initFile(conn, sessionHelper, context, mcaidFcloForm, request);
		 
		return mapping.findForward(target);
	}
	//IFOX-00407694-FCLO/WRTO Changes: end
*/	private ActionForward paymentMenu(Connection conn, SessionHelper sessionHelper, McaidReconContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) {
	logger.info(LoggerConstants.methodStartLevel());
	String target = "error";
		McaidReconPaymentForm mcaidPaymentForm = null;
		context.setSelectedMenu(McaidReconConstants.MENU_PAYMENT);
		long starttime = System.currentTimeMillis();
		if (!(form instanceof McaidReconPaymentForm)) {						
			mcaidPaymentForm = McaidReconPaymentHelper.getPaymentForm(sessionHelper);			
			if (mcaidPaymentForm == null) {
				mcaidPaymentForm = new McaidReconPaymentForm();							
			}
			mcaidPaymentForm.setMenu("");
			mcaidPaymentForm.setMethod("");
			request.setAttribute(McaidReconConstants.FORM_PAYMENT, mcaidPaymentForm);
		} else {
			mcaidPaymentForm = (McaidReconPaymentForm)form;
		}
		if(mcaidPaymentForm.getDateType() == null || StringUtil.nonNullTrim(mcaidPaymentForm.getDateType()).equals(""))
			mcaidPaymentForm.setDateType("E");
		
		target = new McaidReconProcess().initPayment(conn, sessionHelper, context, mcaidPaymentForm, request);
		
		long endtime = System.currentTimeMillis();
		System.out.println("Difference in paymentMenu : " + (endtime-starttime));
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(target);
	}//paymentMenu()
	
	private ActionForward anamolyMenu(Connection conn, SessionHelper sessionHelper, McaidReconContext context, ActionMapping mapping, ActionForm form, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		String target = "error";
		McaidReconAnomForm mcaidAnomForm = null;
		context.setSelectedMenu(McaidReconConstants.MENU_ANOM);
		
		if (!(form instanceof McaidReconAnomForm)) {						
			mcaidAnomForm = McaidReconAnomHelper.getAnomForm(sessionHelper);			
			if (mcaidAnomForm == null) {
				mcaidAnomForm = new McaidReconAnomForm();							
			}
			mcaidAnomForm.setMenu("");
			mcaidAnomForm.setMethod("");
			request.setAttribute(McaidReconConstants.FORM_ANOM, mcaidAnomForm);
		} else {
			mcaidAnomForm = (McaidReconAnomForm)form;
		}

		target = new McaidReconProcess().initAnamoly(conn, sessionHelper, context, mcaidAnomForm, request);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(target);
	}//anamolyMenu()
	

	private void setDescrepancySummarySearchFields(McaidReconBaseForm mcBaseReconForm, HttpServletRequest request, McaidReconContext context)
	{
		logger.info(LoggerConstants.methodStartLevel());
		mcBaseReconForm.setMethod(McaidReconConstants.SUMM_GO_OPT);
		context.setSelectedMenu(McaidReconConstants.MENU_DISC);
		logger.debug(" in setDescrepancySummarySearchFields");
//		logger.info(" in setDescrepancySummarySearchFields");
		if(mcBaseReconForm instanceof McaidReconDiscForm) {
			McaidReconDiscForm mcaidDiscForm = (McaidReconDiscForm) mcBaseReconForm;
			mcaidDiscForm.setSubMenu(McaidReconConstants.SUBMENU_DISC_SUMMARY);
			mcaidDiscForm.setSummSrchGoStatus(request.getParameter("status"));
			mcaidDiscForm.setSummSrchType(request.getParameter("type"));
			mcaidDiscForm.setSummSrchMedicaidId(request.getParameter("medicadeId"));
			mcaidDiscForm.setSummSrchFromEffDate(request.getParameter("effectiveDate"));
			mcaidDiscForm.setSummSrchToEffDate(request.getParameter("applyDate"));
			//mcaidDiscForm.setSummSrchFromUpdtDate(request.getParameter(""));
			//mcaidDiscForm.setSummSrchToUpdtDate(request.getParameter(""));
			//mcaidDiscForm.setSummSrchUpdtUserId(request.getParameter(""));

			context.getPaymentVO().setPaymentSummaryMedicaidIdViewIndicator(request.getParameter("pymntSummMedicaidIdViewIndicator"));
			
			java.util.List mcaidPymntSummLst = context.getPaymentVO().getMcaidPymntSummLst();
			if(null != mcaidPymntSummLst && mcaidPymntSummLst.size() > 0) {
				McaidPaymentDashBoardVO mcaidPaymentDashBoardVO = (McaidPaymentDashBoardVO) mcaidPymntSummLst.get(0);
				mcaidDiscForm.setSummSrchPbp(mcaidPaymentDashBoardVO.getPbpId());
				mcaidDiscForm.setSummSrchGoPbp(mcaidPaymentDashBoardVO.getPbpId());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	private String getMCaidReconGroupId(McaidReconBaseForm mcBaseReconForm) {
		logger.info(LoggerConstants.methodStartLevel());
		if(mcBaseReconForm.getMenu().equalsIgnoreCase("NM")){
			logger.info(LoggerConstants.methodEndLevel());
			return MssProperties.getGroupIdForNMMcaidRecon();
		}
		else
			if(mcBaseReconForm.getMenu().equalsIgnoreCase("IL")){
				logger.info(LoggerConstants.methodEndLevel());
				return MssProperties.getGroupIdForILMcaidRecon();
			}
			else{ //Menu is TX
				logger.info(LoggerConstants.methodEndLevel());
				return MssProperties.getGroupIdForTXMcaidRecon();
			}
	}
	
}//class
