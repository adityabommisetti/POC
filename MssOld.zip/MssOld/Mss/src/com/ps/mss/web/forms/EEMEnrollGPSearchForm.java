/*
 * $Id: EEMEnrollGPSearchForm.java,v 1.1 2014/06/26 07:55:46 praveen Exp $
 */
package com.ps.mss.web.forms;

import java.util.List;

public class EEMEnrollGPSearchForm extends EEMForm {

	private String customerId;
	private String memberId;
	private String effStartDate;
	private String effEndDate;
	private String enrollStatus;
	private String grpId;
	private String groupName;
	private String productId;
	private String productName;
	private String effDate;
	private String outOfArea;
	private String zipCd5;
	private String zipCd4;
	private String planId;
	private String pbpId;
	private String pbpSegmentId;
	
	private List searchResults;
	
	
	/**
	 * @return Returns the effEndDate.
	 */
	public String getEffEndDate() {
		return effEndDate;
	}
	/**
	 * @param effEndDate The effEndDate to set.
	 */
	public void setEffEndDate(String effEndDate) {
		this.effEndDate = effEndDate;
	}
	/**
	 * @return Returns the effStartDate.
	 */
	public String getEffStartDate() {
		return effStartDate;
	}
	/**
	 * @param effStartDate The effStartDate to set.
	 */
	public void setEffStartDate(String effStartDate) {
		this.effStartDate = effStartDate;
	}
	/**
	 * @return Returns the enrollStatus.
	 */
	public String getEnrollStatus() {
		return enrollStatus;
	}
	/**
	 * @param enrollStatus The enrollStatus to set.
	 */
	public void setEnrollStatus(String enrollStatus) {
		this.enrollStatus = enrollStatus;
	}
	/**
	 * @return Returns the customerId.
	 */
	public String getCustomerId() {
		return customerId;
	}
	/**
	 * @param customerId The customerId to set.
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	/**
	 * @return Returns the memberId.
	 */
	public String getMemberId() {
		return memberId;
	}
	/**
	 * @param memberId The memberId to set.
	 */
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	/**
	 * @return Returns the effDate.
	 */
	public String getEffDate() {
		return effDate;
	}
	/**
	 * @param effDate The effDate to set.
	 */
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	/**
	 * @return Returns the groupName.
	 */
	public String getGroupName() {
		return groupName;
	}
	/**
	 * @param groupName The groupName to set.
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	/**
	 * @return Returns the grpId.
	 */
	public String getGrpId() {
		return grpId;
	}
	/**
	 * @param grpId The grpId to set.
	 */
	public void setGrpId(String grpId) {
		this.grpId = grpId;
	}
	/**
	 * @return Returns the pbpId.
	 */
	public String getPbpId() {
		return pbpId;
	}
	/**
	 * @param pbpId The pbpId to set.
	 */
	public void setPbpId(String pbpId) {
		this.pbpId = pbpId;
	}
	/**
	 * @return Returns the planId.
	 */
	public String getPlanId() {
		return planId;
	}
	/**
	 * @param planId The planId to set.
	 */
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	/**
	 * @return Returns the productId.
	 */
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId The productId to set.
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	/**
	 * @return Returns the productName.
	 */
	public String getProductName() {
		return productName;
	}
	/**
	 * @param productName The productName to set.
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}
	/**
	 * @return Returns the outOfArea.
	 */
	public String getOutOfArea() {
		return outOfArea;
	}
	/**
	 * @param outOfArea The outOfArea to set.
	 */
	public void setOutOfArea(String outOfArea) {
		this.outOfArea = outOfArea;
	}
	/**
	 * @return Returns the zipCd4.
	 */
	public String getZipCd4() {
		return zipCd4;
	}
	/**
	 * @param zipCd4 The zipCd4 to set.
	 */
	public void setZipCd4(String zipCd4) {
		this.zipCd4 = zipCd4;
	}
	/**
	 * @return Returns the zipCd5.
	 */
	public String getZipCd5() {
		return zipCd5;
	}
	/**
	 * @param zipCd5 The zipCd5 to set.
	 */
	public void setZipCd5(String zipCd5) {
		this.zipCd5 = zipCd5;
	}
	/**
	 * @return Returns the pbpSegmentId.
	 */
	public String getPbpSegmentId() {
		return pbpSegmentId;
	}
	/**
	 * @param pbpSegmentId The pbpSegmentId to set.
	 */
	public void setPbpSegmentId(String pbpSegmentId) {
		this.pbpSegmentId = pbpSegmentId;
	}

	/**
	 * @return Returns the searchResults.
	 */
	public List getSearchResults() {
		return searchResults;
	}
	/**
	 * @param searchResults The searchResults to set.
	 */
	public void setSearchResults(List searchResults) {
		this.searchResults = searchResults;
	}
}
