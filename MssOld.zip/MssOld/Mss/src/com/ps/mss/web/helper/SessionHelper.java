/*
 * $Id: SessionHelper.java,v 1.2 2014/06/27 12:59:56 praveen Exp $
 * Created on Nov 16, 2007
 *
 */
package com.ps.mss.web.helper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import com.ps.mss.security.SessionManager;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.db.DbConn;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.manager.MasterManager;
import com.ps.mss.model.FilterVO;
import com.ps.mss.model.PlanEntityVO;
import com.ps.util.DateUtil;
import com.ps.util.NameValuePair;
import com.ps.util.StringUtil;

/**
 * @author rakesh
 *
 */
public class SessionHelper {
	private static Logger logger=LoggerFactory.getLogger(SessionHelper.class);

	private HttpSession session;
	
	/**
	 * @throws ApplicationException
	 * 
	 */
	public SessionHelper(HttpServletRequest request) throws ApplicationException{
		this(request,false);
		//logger.info(LoggerConstants.methodEndLevel());
	}
	
	public SessionHelper(HttpServletRequest request, boolean createNew) throws ApplicationException {
		// validate the request is secure or not.
		if(! request.isSecure())
			throw new ApplicationException(Constants.MSG_NON_HTTPS_REQUEST);
		
		session = request.getSession(createNew);
		
		if(session == null)
			throw new ApplicationException(Constants.MSG_PAGE_EXPIRED);
		
			LoggerConstants.session=session;
	}
	
	public String getMfId(){
		logger.info(LoggerConstants.methodStartLevel());
		return (String) session.getAttribute(Constants.SESSION_MF_ID);
	}

	public String getUserId(){
		logger.info(LoggerConstants.methodStartLevel());
		return (String) session.getAttribute(Constants.SESSION_USER_ID);
	}
	
	public String getCustomerNumber(){
		logger.info(LoggerConstants.methodStartLevel());
		return (String) session.getAttribute(Constants.SESSION_CUSTOMER_NUMBER); 
	}
	
	public Object getAttribute(String attrName){
		return session.getAttribute(attrName);
	}
	
	public void setAttribute(String attrName, Object attrValue){
		logger.info(LoggerConstants.methodStartLevel());
		if(attrValue != null)
			this.session.setAttribute(attrName, attrValue);
		logger.info(LoggerConstants.methodEndLevel());
	}

	public boolean isEEMSupervisor() {
		logger.info(LoggerConstants.methodStartLevel());
		String val = (String)session.getAttribute("EEMS");
		if (val != null)
			if (val.equals("TRUE")){
				logger.info(LoggerConstants.methodEndLevel());
				return true;
			}
		logger.info(LoggerConstants.methodEndLevel());
		return false;
	}
	public boolean isEEMUpdate() {
		logger.info(LoggerConstants.methodStartLevel());
			String val = (String)session.getAttribute("EEMU");
			if (val != null)
				if (val.equals("TRUE")){
					logger.info(LoggerConstants.methodEndLevel());
					return true;
				}
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
	
	/**
	 * @return Returns the session.
	 */
	public HttpSession getSession() {
		logger.info(LoggerConstants.methodStartLevel());
		return session;
	}
	
	/**
	 * Function fatch list of nameValue pair that contains planId and it's name.
	 * @param request
	 * @return
	 * @throws ApplicationException
	 */
	public  NameValuePair[] getPlanIdArray() throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Map custPlanMap = getPlansForCustomer();
		NameValuePair [] planArray = null;
		List list = null;
		if(custPlanMap != null) { 
		    NameValuePair  nameValuePair = null ;
		    String key = null;
			String planName = null; 
			list = new ArrayList();
			Set keySet = new TreeMap(custPlanMap).keySet();
			Iterator iterator = keySet.iterator();
			while(iterator.hasNext()) {
			    key = (String)iterator.next();
				planName = StringUtil.trimToNull(getPlanName(key, custPlanMap));
				nameValuePair = new NameValuePair();
				nameValuePair.setName(key);
				nameValuePair.setValue(planName != null ? key +" - " + planName : key);
				list.add(nameValuePair);
			}
			planArray = (NameValuePair[]) list.toArray(new NameValuePair[list.size()]);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return planArray ;
	}
	
	/**
	 * Function fatch list of nameValue pair for part D that contains planId and it's name.If there is not plan then it return null.
	 * @param request
	 * @return
	 * @throws ApplicationException
	 */
	public  NameValuePair[] getPartDPlanIdArr() throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Map custPlanMap = getPlansForCustomer();
		NameValuePair [] planArray = null;
		List list = null;
		if(custPlanMap != null) { 
		    PlanEntityVO planEntityVO = null;
		    NameValuePair  nameValuePair = null ;
			String planName = null; 
			String planId = null;
			boolean flag = false;
			
			list = new ArrayList();
			Set keySet = new TreeMap(custPlanMap).keySet();
			Iterator iterator = keySet.iterator();
			while( iterator.hasNext()) {
				planId = (String)iterator.next();
				planEntityVO = (PlanEntityVO) custPlanMap.get(planId);
				if(planEntityVO.isPartD()) {
				    flag = true;
				    planName = planEntityVO.getPlanName();
				    nameValuePair = new NameValuePair();
				    nameValuePair.setName(planId);
			        nameValuePair.setValue(planName != null ? planId +" - " + planName : planId);
			        list.add(nameValuePair);
				}
			}
			if(flag)
			    planArray = (NameValuePair[]) list.toArray(new NameValuePair[list.size()]);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return planArray ;
	}
	/**
	 * Fucntion find planName for planId from custPlanMap.
	 * @param planId
	 * @param custPlanMap
	 * @return
	 * @throws ApplicationException
	 */
	public String getPlanName(String planId, Map custPlanMap) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String planName = null;
		if(custPlanMap != null) { 
			PlanEntityVO planEntityVO = (PlanEntityVO) custPlanMap.get(planId);
			if(planId.equals(planEntityVO.getPlanId())) {
				planName = planEntityVO.getPlanName();
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return planName;
	}
	
	/**
	 * This funtion create partC/part D plan list from custPlanMap 
	 * @param request
	 * @return
	 * @throws ApplicationException
	 */
	public Map getPlanForParts() throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		Map custPlanMap = getPlansForCustomer();
		// plans map have partC , part D plan list and planName Map.
		Map plansMap = getPartPlan(custPlanMap);
		logger.info(LoggerConstants.methodEndLevel());
		return plansMap;
	}
	
	
	/**
	 * Fucntion fatch planList for a customer.
	 * @param request
	 * @return
	 * @throws ApplicationException
	 */
	public Map getPlansForCustomer() throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Map custPlanMap = null;
		String custNumber = getReconCustomerNumber();
		//check use to fatch those paln that are acceable to him.
		String custPlanMapName = Constants.DEMO_CUSTOMER_NUMBER.equals(custNumber) ?
								 Constants.SESSION_DEMO_PLAN_MAP : Constants.SESSION_CUST_PLAN_MAP;
		
		custPlanMap = (Map) session.getAttribute(custPlanMapName);
		if (custPlanMap == null) {
			custPlanMap = MasterManager.getPlanArr(custNumber);
			session.setAttribute(custPlanMapName,custPlanMap);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return custPlanMap;
	}
	

	/**
	 * This funtion create partC/part D plan list from custPlanMap ( this map contain all plan for an customer)
	 * @param planMap
	 * @return
	 */
	private Map getPartPlan(Map custPlanMap) {
		logger.info(LoggerConstants.methodStartLevel());
		List partCPlanList = null;
		List partDPlanList = null;
		List allPlansList = null; //Added for IFOX-00431034 :: All-Plans in Discrepancy Drop down
		Map planName = null;
		if( custPlanMap != null ) {
		    partCPlanList = new ArrayList() ;
			partDPlanList = new ArrayList() ;
			allPlansList = new ArrayList() ;//Added for IFOX-00431034 :: All-Plans in Discrepancy Drop down
			planName = new HashMap();
			Set planSet = custPlanMap.keySet();
			Iterator planItr = planSet.iterator();
			PlanEntityVO planEntityVO = null;
			String planId = null;
			while( planItr.hasNext()) {
				planId = (String)planItr.next();
				planEntityVO = (PlanEntityVO) custPlanMap.get(planId);
				planName.put(planId,planEntityVO.getPlanName());
				if(planEntityVO.isPartC()) 
					partCPlanList.add(planId);
				
				if(planEntityVO.isPartD()) 
					partDPlanList.add(planId);
				
				allPlansList.add(planId); //Added for IFOX-00431034 :: All-Plans in Discrepancy Drop down
			}
		}
		Map planMap = new HashMap();
		planMap.put(Constants.PartC_Plan, partCPlanList);
		planMap.put(Constants.PartD_Plan, partDPlanList);
		planMap.put(Constants.PLAN_NAME, planName);
		planMap.put(Constants.CONSTANTS_ALL, allPlansList); //Added for IFOX-00431034 :: All-Plans in Discrepancy Drop down
		logger.info(LoggerConstants.methodEndLevel());
		return planMap;
	}
	
	/**
	 * @param request
	 * @return Error Messange (if validation failed)
	 */
	public String validateUser() {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		try {
			conn = DbConn.getConnection();
			return validateUser(conn);
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return Constants.MSG_INVALID_SESSION;
		
	}

	public String validateUser(Connection conn) {
		logger.info(LoggerConstants.methodStartLevel());
		HttpSession session = this.getSession();
		if (session == null)
			return Constants.MSG_PAGE_EXPIRED;
		
		String wasSId = session.getId();
		String userId = (String)session.getAttribute("User_id");
		if (userId == null){
			logger.info(LoggerConstants.methodEndLevel());
			return Constants.MSG_INVALID_SESSION;
		}

		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement("SELECT was_sid FROM secuser WHERE User_id = ? AND was_sid = ?");
			ps.setString(1,userId);
			ps.setString(2,wasSId);
			rs = ps.executeQuery();
			if (rs.next()){
				logger.info(LoggerConstants.methodEndLevel());
				return null;
			}
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
		} finally {
			try {
				if (rs != null) rs.close();
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				//logger.error(e.getMessage());
			}
			try {
				if (ps != null) ps.close();
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				//logger.error(e.getMessage());
			}
		}
		
//		logger.error(" SessionHelper : validateUser : Before Redirecting to Expire Page :  UserId [" + userId + "] "); //Added for IFOX-00392277
		logger.debug(" SessionHelper : validateUser : Before Redirecting to Expire Page :  UserId [" + userId + "] "); //Added for IFOX-00392277
		logger.info(LoggerConstants.methodEndLevel());
		return Constants.MSG_PAGE_EXPIRED;
	}
	/**
	 * @param demo_version
	 */
	public void removeAttribute(String key) {
		logger.info(LoggerConstants.methodStartLevel());
		this.session.removeAttribute(key);
		logger.info(LoggerConstants.methodEndLevel());
	}

	/**
	 * @param reconCustomerNo
	 */
	public void setReconCutomserNo(String reconCustomerNo) {
		logger.info(LoggerConstants.methodStartLevel());
		session.setAttribute(Constants.SESSION_RECON_CUSTOMER_NUMBER, reconCustomerNo);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	/**
	 * @return Recon Cutomer No from HttpSession
	 */
	public String getReconCustomerNumber(){
		logger.info(LoggerConstants.methodStartLevel());
		String custNbr = (String) session.getAttribute(Constants.SESSION_RECON_CUSTOMER_NUMBER);
		if (custNbr == null)
			custNbr = (String) session.getAttribute("Cust_nbr");
		logger.info(LoggerConstants.methodEndLevel());
		return custNbr;
	}
	
	/**
	 * This method will return Database name, if request is for demo user then it will return blank, 
	 * else will return active database name from session. 
	 * 
	 * @return Database name thru which all db query will execute 
	 */
	public String getActiveDataBaseName(){
		logger.info(LoggerConstants.methodStartLevel());
		String custNumber = getReconCustomerNumber();
		if (Constants.DEMO_CUSTOMER_NUMBER.equals(custNumber)) {
			String loginCustNbr = StringUtil.nonNullTrim((String)session.getAttribute("Cust_nbr"));
			if (!Constants.DEMO_CUSTOMER_NUMBER.equals(loginCustNbr)){
				logger.info(LoggerConstants.methodEndLevel());
				return "";
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return (String)session.getAttribute(Constants.SESSION_RECONUIDB);
	}
	
	public String getRapsDatabaseName() {
		logger.info(LoggerConstants.methodStartLevel());
		//TODO: Do I need to check for custNumber like getActiveDataBaseName() above?
		return (String) session.getAttribute(SessionManager.RAPSDB);
	}
	
	public String getEEMDatabaseName() {
		logger.info(LoggerConstants.methodStartLevel());
		return (String) session.getAttribute(SessionManager.EEMDB);
	}
	
	/**
	 * This method find out the searchType (plan : when there is not date into searching criteria or haveing different year,
	 * year : when searching criteria have search for year ,
	 * month : when searching is done for a perticular month)
	 * @param filterVO
	 * @return
	 */
	public String evaluteSearchType(FilterVO filterVO ) {
		logger.info(LoggerConstants.methodStartLevel());
		String startDate = StringUtil.nonNull(DateUtil.changedDateFormat(filterVO.getStartDate()));
		String endDate = StringUtil.nonNull(DateUtil.changedDateFormat(filterVO.getEndDate()));
		String searchType = "plan";
		if(startDate.length() > 0 && endDate.length() > 0) {
			int firstMonth = Integer.parseInt(startDate.substring(4,6));
			int secondMonth = Integer.parseInt(endDate.substring(4,6));
			int firstYear = Integer.parseInt(startDate.substring(0,4));
			int secondYear = Integer.parseInt(endDate.substring(0,4));
			if(firstMonth == secondMonth && firstYear == secondYear ) {
				searchType = "month";
			} else if ( firstYear == secondYear ) {
				searchType = "year";
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return searchType;
	}
	
	/**
	 * This function check that user is visiting demo link.
	 * @return true if user come from demo otherwise flase.
	 */
	public boolean isClickOnDemo(){
		logger.info(LoggerConstants.methodStartLevel());
		String custNumber = getReconCustomerNumber();
		logger.info(LoggerConstants.methodEndLevel());
		return Constants.DEMO_CUSTOMER_NUMBER.equals(custNumber) ? true : false;
	}
	
	/**
	 * If User has both discrepancy type permsission (based on "RECON" & "RXRECON" flag in session) then return TRUE 
	 *  else returns FALSE
	 * 
	 * If User came thru Demo Link then this method will always return TRUE 
	 * @return true / false
	 */
	public boolean hasBothDiscAccessPermission(){
		logger.info(LoggerConstants.methodStartLevel());
		// DEMO user always have both Discrepancy Type permission.
		if(isClickOnDemo()){
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}
		
		String recon = (String) session.getAttribute(Constants.SESSION_SERVICE_RECON);
    	String rxRecon = (String) session.getAttribute(Constants.SESSION_SERVICE_RXRECON);
    	logger.info(LoggerConstants.methodEndLevel());
		return ("TRUE".equalsIgnoreCase(recon) && "TRUE".equalsIgnoreCase(rxRecon)) ? true : false;
	}
	
	
	/**
	 * Function will return the Service Nam <code>'Both', 'Part C', 'Part D'</code> based on the access permissions given to him
	 * 
	 * If user is DEMO USER then he will always get 'BOTH' permission   
	 * @return
	 */
	public String getServicesToAccess(){
		logger.info(LoggerConstants.methodStartLevel());
		if(hasBothDiscAccessPermission()){
			logger.info(LoggerConstants.methodEndLevel());
			return Constants.BOTH_PARTS;
		}
		
		String recon = (String) session.getAttribute(Constants.SESSION_SERVICE_RECON);

		if("TRUE".equalsIgnoreCase(recon)){
			logger.info(LoggerConstants.methodEndLevel());
			return Constants.PARTC;
		}
		logger.info(LoggerConstants.methodEndLevel());
		return Constants.PARTD;
	}
	
	
	public boolean hasWriteOffPermission(){
		logger.info(LoggerConstants.methodStartLevel());
		// DEMO user always have both Discrepancy Type permission.
		if(isClickOnDemo()){
			logger.info(LoggerConstants.methodEndLevel());	return true;
		}
		
		String writeOffSerivce = (String) session.getAttribute(Constants.SESSION_WRITE_OFF_REQUEST_SERVICE);
		logger.info(LoggerConstants.methodEndLevel());
		return ("TRUE".equals(writeOffSerivce)) ? true : false;
	}
}
