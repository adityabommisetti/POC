/**
 * $Id: EEMTimersForm.java,v 1.1 2014/06/26 07:55:49 praveen Exp $
 */
package com.ps.mss.web.forms;
import java.util.List;
import com.ps.util.ListBoxItem;

public class EEMTimersForm extends EEMForm{
	/**
	 * searchType : Holds the value Application or member
	 */
	private String searchType;
	/**
	 * searchId : Holds Applciation Id or member Id
	 */
	private String searchId;
	/**
	 * customerId : Holds Customer Id
	 */
	private String customerId;
	/**
     * applId : Holds Application Id
     */
	private String applId;
	/**
	 * checkBoxStatus : Holds the status of the timer check box
	 */
    private String[] checkBoxStatus;
    /**
	 * editActivationDateStatus : Holds the new Effective date
	 */
    private String[] editActivationDateStatus;

	/**
	 * timersList : Holds the list of the timers
	 */
	private List timersList;
	/**
	 * message : Holds the message 
	 */
	private String message;
	
	 /**
     * triggerType:Holds triggerCode(FUA/FUM)
     */
	private String triggerType;
	/**
	 * arrSearchTypes : To display drop down consisting of Application or member
	 */
	private ListBoxItem [] arrSearchTypes;
	
	/**
	 * triggerTypes : To display drop down consisting of ALL,OPEN,CLOSED
	 */
	private ListBoxItem[] triggerTypes;
	/**
	 * @return the arrSearchTypes
	 */
	public ListBoxItem[] getArrSearchTypes() {
		return arrSearchTypes;
	}

	/**
	 * @return the triggerTypes
	 */
	public ListBoxItem[] getTriggerTypes() {
		return triggerTypes;
	}

	/**
	 * @param triggerTypes the triggerTypes to set
	 */
	public void setTriggerTypes(ListBoxItem[] triggerTypes) {
		this.triggerTypes = triggerTypes;
	}

	/**
	 * @param arrSearchTypes the arrSearchTypes to set
	 */
	public void setArrSearchTypes(ListBoxItem[] arrSearchTypes) {
		this.arrSearchTypes = arrSearchTypes;
	}

	/**
	 * @return the triggerType
	 */
	public String getTriggerType() {
		return triggerType;
	}

	/**
	 * @param triggerType the triggerType to set
	 */
	public void setTriggerType(String triggerType) {
		this.triggerType = triggerType;
	}

	
/**
 * @return the searchType
 */
	public String getSearchType() {
		return searchType;
	}

/**
 * @param searchType the searchType to set
 */
	public void setSearchType(String searchType) {
	this.searchType = searchType;
	}

public String getMessage() {
	return message;
}

public void setMessage(String message) {
	this.message = message;
}

/**
 * @return the searchId
 */
	public String getSearchId() {
		return searchId;
	}

/**
 * @param searchId the searchId to set
 */
	public void setSearchId(String searchId) {
	this.searchId = searchId;
	}


/**
 * @return the customerId
 */

	public String getCustomerId() {
		return customerId;
	}

/**
 * @param customerId the customerId to set
 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}



/**
 * @return the applId
 */
	public String getApplId() {
		return applId;
	}



/**
 * @param applId the applId to set
 */
	public void setApplId(String applId) {
		this.applId = applId;
	}

/**
 * @return the checkBoxStatus
 */
public String[] getCheckBoxStatus() {
	return checkBoxStatus;
}

/**
 * @param checkBoxStatus the checkBoxStatus to set
 */
public void setCheckBoxStatus(String[] checkBoxStatus) {
this.checkBoxStatus = checkBoxStatus;
}

/**
 * @return the editActivationDateStatus
 */
public String[] getEditActivationDateStatus() {
	return editActivationDateStatus;
}

/**
 * @param editActivationDateStatus the editActivationDateStatus to set
 */
public void setEditActivationDateStatus(String[] editActivationDateStatus) {

	this.editActivationDateStatus = editActivationDateStatus;
}


/**
 * @return the timersList
 */
public List getTimersList() {

	return timersList;
}

/**
 * @param timersList the timersList to set
 */
public void setTimersList(List timersList) {
	this.timersList = timersList;
}
}
