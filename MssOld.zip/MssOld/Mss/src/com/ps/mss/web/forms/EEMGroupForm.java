/*
 * $Id: EEMGroupForm.java,v 1.1 2014/06/26 07:55:47 praveen Exp $
 */
package com.ps.mss.web.forms;

import java.util.List;
import java.util.ArrayList;
import com.ps.text.DateFormatter;

public class EEMGroupForm extends EEMForm {

	private String searchGroupID;
	private String searchSupplGroupID;
	private String searchStartDate;
	
	private int searchItemSelected;
	private ArrayList searchResults;
	
	private int newSelectedRow;
	
	private String groupId;
	private String grpStartDate;
	private String grpEndDate;
	private String supplGrpId;
	private String createTime;
	private String createUserId;
	private String lastUpdtTime;
	private String lastUpdtUserId;
	
	private String prevGrpName;
	private String grpName;
	private String grpNameStartDate;
	private String grpNameEndDate;
	private String grpNameLastUpdtTime;
	private String grpNameLastUpdtUserId;
	
	private int grpAddrItemSelected;
	private ArrayList lstGrpAddresses;
	
	private int newSelectedAddrRow;
	
	private String addrType;
	private String addrStartDate;
	private String addrEndDate;
	private String addrAttention;
	private String addrLine1;
	private String addrLine2;
	private String addrLine3;
	private String addrCity;
	private String addrState;
	private String addrZip;
	private String addrCountry;
	private String officePhone;
	private String faxNbr;
	private String addrCreateTime;
	private String addrCreateUserId;
	private String addrLastUpdtTime;
	private String addrLastUpdtUserId;

	private List lstGrpAddrTypes;

	/**
	 * @return Returns the lstGrpAddrTypes.
	 */
	public List getLstGrpAddrTypes() {
		return lstGrpAddrTypes;
	}
	/**
	 * @param lstGrpAddrTypes The lstGrpAddrTypes to set.
	 */
	public void setLstGrpAddrTypes(List lstGrpAddrTypes) {
		this.lstGrpAddrTypes = lstGrpAddrTypes;
	}
	/**
	 * @return Returns the lstGrpAddresses.
	 */
	public ArrayList getLstGrpAddresses() {
		return lstGrpAddresses;
	}
	/**
	 * @param lstGrpAddresses The lstGrpAddresses to set.
	 */
	public void setLstGrpAddresses(ArrayList lstGrpAddresses) {
		this.lstGrpAddresses = lstGrpAddresses;
	}
	/**
	 * @return Returns the newSelectedRow.
	 */
	public int getNewSelectedRow() {
		return newSelectedRow;
	}
	/**
	 * @param newSelectedRow The newSelectedRow to set.
	 */
	public void setNewSelectedRow(int newSelectedRow) {
		this.newSelectedRow = newSelectedRow;
	}
	/**
	 * @return Returns the addrAttention.
	 */
	public String getAddrAttention() {
		return addrAttention;
	}
	/**
	 * @param addrAttention The addrAttention to set.
	 */
	public void setAddrAttention(String addrAttention) {
		this.addrAttention = addrAttention;
	}
	/**
	 * @return Returns the addrCity.
	 */
	public String getAddrCity() {
		return addrCity;
	}
	/**
	 * @param addrCity The addrCity to set.
	 */
	public void setAddrCity(String addrCity) {
		this.addrCity = addrCity;
	}
	/**
	 * @return Returns the addrCountry.
	 */
	public String getAddrCountry() {
		return addrCountry;
	}
	/**
	 * @param addrCountry The addrCountry to set.
	 */
	public void setAddrCountry(String addrCountry) {
		this.addrCountry = addrCountry;
	}
	/**
	 * @return Returns the addrCreateTime.
	 */
	public String getFrmtAddrCreateTime() {
		return DateFormatter.reFormat(addrCreateTime,DateFormatter.DB2_TIMESTAMP,DateFormatter.YYYY_MM_DD_HH_MM_SS);
	}
	/**
	 * @return Returns the addrCreateTime.
	 */
	public String getAddrCreateTime() {
		return addrCreateTime;
	}
	/**
	 * @param addrCreateTime The addrCreateTime to set.
	 */
	public void setAddrCreateTime(String addrCreateTime) {
		this.addrCreateTime = addrCreateTime;
	}
	/**
	 * @return Returns the addrCreateUserId.
	 */
	public String getAddrCreateUserId() {
		return addrCreateUserId;
	}
	/**
	 * @param addrCreateUserId The addrCreateUserId to set.
	 */
	public void setAddrCreateUserId(String addrCreateUserId) {
		this.addrCreateUserId = addrCreateUserId;
	}
	/**
	 * @return Returns the addrEndDate.
	 */
	public String getAddrEndDate() {
		return addrEndDate;
	}
	/**
	 * @param addrEndDate The addrEndDate to set.
	 */
	public void setAddrEndDate(String addrEndDate) {
		this.addrEndDate = addrEndDate;
	}
	/**
	 * @return Returns the addrLastUpdtTime.
	 */
	public String getFrmtAddrLastUpdtTime() {
		return DateFormatter.reFormat(addrLastUpdtTime,DateFormatter.DB2_TIMESTAMP,DateFormatter.YYYY_MM_DD_HH_MM_SS);
	}
	/**
	 * @return Returns the addrLastUpdtTime.
	 */
	public String getAddrLastUpdtTime() {
		return addrLastUpdtTime;
	}
	/**
	 * @param addrLastUpdtTime The addrLastUpdtTime to set.
	 */
	public void setAddrLastUpdtTime(String addrLastUpdtTime) {
		this.addrLastUpdtTime = addrLastUpdtTime;
	}
	/**
	 * @return Returns the addrLastUpdtUserId.
	 */
	public String getAddrLastUpdtUserId() {
		return addrLastUpdtUserId;
	}
	/**
	 * @param addrLastUpdtUserId The addrLastUpdtUserId to set.
	 */
	public void setAddrLastUpdtUserId(String addrLastUpdtUserId) {
		this.addrLastUpdtUserId = addrLastUpdtUserId;
	}
	/**
	 * @return Returns the addrLine1.
	 */
	public String getAddrLine1() {
		return addrLine1;
	}
	/**
	 * @param addrLine1 The addrLine1 to set.
	 */
	public void setAddrLine1(String addrLine1) {
		this.addrLine1 = addrLine1;
	}
	/**
	 * @return Returns the addrLine2.
	 */
	public String getAddrLine2() {
		return addrLine2;
	}
	/**
	 * @param addrLine2 The addrLine2 to set.
	 */
	public void setAddrLine2(String addrLine2) {
		this.addrLine2 = addrLine2;
	}
	/**
	 * @return Returns the addrLine3.
	 */
	public String getAddrLine3() {
		return addrLine3;
	}
	/**
	 * @param addrLine3 The addrLine3 to set.
	 */
	public void setAddrLine3(String addrLine3) {
		this.addrLine3 = addrLine3;
	}
	/**
	 * @return Returns the addrStartDate.
	 */
	public String getAddrStartDate() {
		return addrStartDate;
	}
	/**
	 * @param addrStartDate The addrStartDate to set.
	 */
	public void setAddrStartDate(String addrStartDate) {
		this.addrStartDate = addrStartDate;
	}
	/**
	 * @return Returns the addrState.
	 */
	public String getAddrState() {
		return addrState;
	}
	/**
	 * @param addrState The addrState to set.
	 */
	public void setAddrState(String addrState) {
		this.addrState = addrState;
	}
	/**
	 * @return Returns the addrType.
	 */
	public String getAddrType() {
		return addrType;
	}
	/**
	 * @param addrType The addrType to set.
	 */
	public void setAddrType(String addrType) {
		this.addrType = addrType;
	}
	/**
	 * @return Returns the addrZip.
	 */
	public String getAddrZip() {
		return addrZip;
	}
	/**
	 * @param addrZip The addrZip to set.
	 */
	public void setAddrZip(String addrZip) {
		this.addrZip = addrZip;
	}
	/**
	 * @return Returns the createTime.
	 */
	public String getFrmtCreateTime() {
		return DateFormatter.reFormat(createTime,DateFormatter.DB2_TIMESTAMP,DateFormatter.YYYY_MM_DD_HH_MM_SS);
	}
	/**
	 * @return Returns the createTime.
	 */
	public String getCreateTime() {
		return createTime;
	}
	/**
	 * @param createTime The createTime to set.
	 */
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	/**
	 * @return Returns the createUserId.
	 */
	public String getCreateUserId() {
		return createUserId;
	}
	/**
	 * @param createUserId The createUserId to set.
	 */
	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}
	/**
	 * @return Returns the faxNbr.
	 */
	public String getFaxNbr() {
		return faxNbr;
	}
	/**
	 * @param faxNbr The faxNbr to set.
	 */
	public void setFaxNbr(String faxNbr) {
		this.faxNbr = faxNbr;
	}
	/**
	 * @return Returns the groupId.
	 */
	public String getGroupId() {
		return groupId;
	}
	/**
	 * @param groupId The groupId to set.
	 */
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	/**
	 * @return Returns the grpAddrItemSelected.
	 */
	public int getGrpAddrItemSelected() {
		return grpAddrItemSelected;
	}
	/**
	 * @param grpAddrItemSelected The grpAddrItemSelected to set.
	 */
	public void setGrpAddrItemSelected(int grpAddrItemSelected) {
		this.grpAddrItemSelected = grpAddrItemSelected;
	}
	/**
	 * @return Returns the grpEndDate.
	 */
	public String getGrpEndDate() {
		return grpEndDate;
	}
	/**
	 * @param grpEndDate The grpEndDate to set.
	 */
	public void setGrpEndDate(String grpEndDate) {
		this.grpEndDate = grpEndDate;
	}
	
	/**
	 * @return Returns the prevGrpName.
	 */
	public String getPrevGrpName() {
		return prevGrpName;
	}
	/**
	 * @param prevGrpName The prevGrpName to set.
	 */
	public void setPrevGrpName(String prevGrpName) {
		this.prevGrpName = prevGrpName;
	}
	/**
	 * @return Returns the grpName.
	 */
	public String getGrpName() {
		return grpName;
	}
	/**
	 * @param grpName The grpName to set.
	 */
	public void setGrpName(String grpName) {
		this.grpName = grpName;
	}
	
	
	/**
	 * @return Returns the grpNameEndDate.
	 */
	public String getGrpNameEndDate() {
		return grpNameEndDate;
	}
	/**
	 * @param grpNameEndDate The grpNameEndDate to set.
	 */
	public void setGrpNameEndDate(String grpNameEndDate) {
		this.grpNameEndDate = grpNameEndDate;
	}
	/**
	 * @return Returns the grpNameLastUpdtTime.
	 */
	public String getGrpNameLastUpdtTime() {
		return grpNameLastUpdtTime;
	}
	/**
	 * @param grpNameLastUpdtTime The grpNameLastUpdtTime to set.
	 */
	public void setGrpNameLastUpdtTime(String grpNameLastUpdtTime) {
		this.grpNameLastUpdtTime = grpNameLastUpdtTime;
	}
	/**
	 * @return Returns the grpNameLastUpdtUserId.
	 */
	public String getGrpNameLastUpdtUserId() {
		return grpNameLastUpdtUserId;
	}
	/**
	 * @param grpNameLastUpdtUserId The grpNameLastUpdtUserId to set.
	 */
	public void setGrpNameLastUpdtUserId(String grpNameLastUpdtUserId) {
		this.grpNameLastUpdtUserId = grpNameLastUpdtUserId;
	}
	/**
	 * @return Returns the grpNameStartDate.
	 */
	public String getGrpNameStartDate() {
		return grpNameStartDate;
	}
	/**
	 * @param grpNameStartDate The grpNameStartDate to set.
	 */
	public void setGrpNameStartDate(String grpNameStartDate) {
		this.grpNameStartDate = grpNameStartDate;
	}
	/**
	 * @return Returns the grpStartDate.
	 */
	public String getGrpStartDate() {
		return grpStartDate;
	}
	/**
	 * @param grpStartDate The grpStartDate to set.
	 */
	public void setGrpStartDate(String grpStartDate) {
		this.grpStartDate = grpStartDate;
	}
	/**
	 * @return Returns the lastUpdtTime.
	 */
	public String getFrmtLastUpdtTime() {
		return DateFormatter.reFormat(lastUpdtTime,DateFormatter.DB2_TIMESTAMP,DateFormatter.YYYY_MM_DD_HH_MM_SS);
	}
	/**
	 * @return Returns the lastUpdtTime.
	 */
	public String getLastUpdtTime() {
		return lastUpdtTime;
	}
	/**
	 * @param lastUpdtTime The lastUpdtTime to set.
	 */
	public void setLastUpdtTime(String lastUpdtTime) {
		this.lastUpdtTime = lastUpdtTime;
	}
	/**
	 * @return Returns the lastUpdtUserId.
	 */
	public String getLastUpdtUserId() {
		return lastUpdtUserId;
	}
	/**
	 * @param lastUpdtUserId The lastUpdtUserId to set.
	 */
	public void setLastUpdtUserId(String lastUpdtUserId) {
		this.lastUpdtUserId = lastUpdtUserId;
	}
	/**
	 * @return Returns the officePhone.
	 */
	public String getOfficePhone() {
		return officePhone;
	}
	/**
	 * @param officePhone The officePhone to set.
	 */
	public void setOfficePhone(String officePhone) {
		this.officePhone = officePhone;
	}
	/**
	 * @return Returns the searchSupplGroupID.
	 */
	public String getSearchSupplGroupID() {
		return searchSupplGroupID;
	}
	/**
	 * @param searchSupplGroupID The searchSupplGroupID to set.
	 */
	public void setSearchSupplGroupID(String searchSupplGroupID) {
		this.searchSupplGroupID = searchSupplGroupID;
	}
	/**
	 * @return Returns the supplGrpId.
	 */
	public String getSupplGrpId() {
		return supplGrpId;
	}
	/**
	 * @param supplGrpId The supplGrpId to set.
	 */
	public void setSupplGrpId(String supplGrpId) {
		this.supplGrpId = supplGrpId;
	}
	/**
	 * @return Returns the searchGroupID.
	 */
	public String getSearchGroupID() {
		return searchGroupID;
	}
	/**
	 * @param searchGroupID The searchGroupID to set.
	 */
	public void setSearchGroupID(String searchGroupID) {
		this.searchGroupID = searchGroupID;
	}
	/**
	 * @return Returns the searchItemSelected.
	 */
	public int getSearchItemSelected() {
		return searchItemSelected;
	}
	/**
	 * @param searchItemSelected The searchItemSelected to set.
	 */
	public void setSearchItemSelected(int searchItemSelected) {
		this.searchItemSelected = searchItemSelected;
	}
	/**
	 * @return Returns the searchResults.
	 */
	public ArrayList getSearchResults() {
		return searchResults;
	}
	/**
	 * @param searchResults The searchResults to set.
	 */
	public void setSearchResults(ArrayList searchResults) {
		this.searchResults = searchResults;
	}
	/**
	 * @return Returns the searchStartDate.
	 */
	public String getSearchStartDate() {
		return searchStartDate;
	}
	/**
	 * @param searchStartDate The searchStartDate to set.
	 */
	public void setSearchStartDate(String searchStartDate) {
		this.searchStartDate = searchStartDate;
	}
	/**
	 * @return Returns the newSelectedAddrRow.
	 */
	public int getNewSelectedAddrRow() {
		return newSelectedAddrRow;
	}
	/**
	 * @param newSelectedAddrRow The newSelectedAddrRow to set.
	 */
	public void setNewSelectedAddrRow(int newSelectedAddrRow) {
		this.newSelectedAddrRow = newSelectedAddrRow;
	}
}
