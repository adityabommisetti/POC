/*
 * $Id: EEMHelper.java,v 1.1 2014/06/26 07:55:09 praveen Exp $
 */
package com.ps.mss.web.helper;

import java.util.PropertyResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.db.DbConn;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.EEMConstants;

public class EEMHelper {
	private static Logger logger=LoggerFactory.getLogger(EEMHelper.class);
	private PropertyResourceBundle bundle = null;
	
	public String getBundleProperty(String sKey) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String sValue = null;
		try {
			if (bundle == null) {
				bundle = (PropertyResourceBundle)PropertyResourceBundle.getBundle("mss.resources.EEMProperties");
			}
			sValue = bundle.getString(sKey);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return sValue;
	}
	
	public static boolean hasAppService(SessionHelper sessionHelper) {		
		logger.info(LoggerConstants.methodStartLevel());
		return hasService(sessionHelper,EEMConstants.EEM_APPLICATION);
	}
	public static boolean hasAppUpdateService(SessionHelper sessionHelper) {		
		logger.info(LoggerConstants.methodStartLevel());
		return hasService(sessionHelper,EEMConstants.EEM_APPUPDATE);
	}
	public static boolean hasMbrService(SessionHelper sessionHelper) {		
		logger.info(LoggerConstants.methodStartLevel());
		return hasService(sessionHelper,EEMConstants.EEM_MEMBER);
	}
	public static boolean hasMbrUpdateService(SessionHelper sessionHelper) {		
		logger.info(LoggerConstants.methodStartLevel());
		return hasService(sessionHelper,EEMConstants.EEM_MBRUPDATE);
	}
	public static boolean hasLtrService(SessionHelper sessionHelper) {		
		logger.info(LoggerConstants.methodStartLevel());
		return hasService(sessionHelper,EEMConstants.EEM_LETTER);
	}
	public static boolean hasLtrUpdateService(SessionHelper sessionHelper) {		
		logger.info(LoggerConstants.methodStartLevel());
		return hasService(sessionHelper,EEMConstants.EEM_LTRUPDATE);
	}
	public static boolean hasBilService(SessionHelper sessionHelper) {		
		logger.info(LoggerConstants.methodStartLevel());
		return hasService(sessionHelper,EEMConstants.EEM_BILLING);
	}
	public static boolean hasBilUpdateService(SessionHelper sessionHelper) {		
		logger.info(LoggerConstants.methodStartLevel());
		return hasService(sessionHelper,EEMConstants.EEM_BILUPDATE);
	}
	public static boolean hasService(SessionHelper sessionHelper,String serviceId) {
		logger.info(LoggerConstants.methodStartLevel());
		if ("TRUE".equals(sessionHelper.getAttribute(serviceId))){
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}
		logger.info(LoggerConstants.methodEndLevel());
		return false;
	}
	public static String getRegion(String eemDb) throws IllegalArgumentException {
		logger.info(LoggerConstants.methodStartLevel());
		if (DbConn.DB_PROD.equals(eemDb)){
			logger.info(LoggerConstants.methodEndLevel());
			return "EEMP";
		}
		if (DbConn.DB_QA.equals(eemDb)){
			logger.info(LoggerConstants.methodEndLevel());
			return "EEMT";
		}
		if (DbConn.DB_TEST.equals(eemDb)){
			logger.info(LoggerConstants.methodEndLevel());
			return "EEMD";	
		}
		logger.info(LoggerConstants.methodEndLevel());
		throw new IllegalArgumentException("Unable to map region indicator");
	}
}
