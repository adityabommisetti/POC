package com.ps.mss.web.actions;

import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.db.DbConn;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.manager.EEMManager;
import com.ps.mss.model.EEMContext;
import com.ps.mss.security.SessionManager;

import com.ps.mss.web.forms.EEMForm;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.web.process.EEMWorkFlowProcess;
import com.ps.mss.web.util.EEMSwitchUtil;

public class EEMWorkFlowAction extends Action{
	
	private static Logger logger = LoggerFactory.getLogger(EEMSecurityAction.class);
	
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		try {
			EEMForm eemForm = (EEMForm) form;
			String method = eemForm.getMethod();
			
			// use the default DB for security check
			conn = DbConn.getConnection();
			SessionHelper sessionHelper = new SessionHelper(request);
			String errorMsg = sessionHelper.validateUser(conn);
			if (errorMsg != null) {
				request.setAttribute("Msg", "Login Has Timed Out");
				throw new Exception(errorMsg);
			}
			
			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			EEMContext context = EEMManager.getContext(sessionHelper.getSession());
			String selectedMenu = context.getSelectedMenu();
			eemForm.setMessage(null);
			//Excellus Retro fix for workflow -Start
			selectedMenu = ("closeQueActivities".equals(method)) ? "EEWF" : selectedMenu ;
			//Excellus Retro fix for workflow -End
			if ("switchMenu".equals(method)) {
				logger.info(LoggerConstants.methodEndLevel());
				return EEMSwitchUtil.switchMenu( mapping, conn, context,  form, eemForm,  sessionHelper,  request,  response);
			}else if (EEMConstants.MENU_WF.equals(selectedMenu) ) {
				logger.info(LoggerConstants.methodEndLevel());
				return new EEMWorkFlowProcess().selectedMenu(conn, sessionHelper, context, mapping,form, request);
			}
			//on multiple Click in Activity in workflow main screen issue - Start
			else{
				logger.info(LoggerConstants.methodEndLevel());
				return new EEMWorkFlowProcess().selectedMenu(conn, sessionHelper, context, mapping,form, request);
			}
						
			//return mapping.findForward("eemError");
			//on multiple Click in Activity in workflow main screen issue - End
			
		}catch(Exception e){
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward("eemError");
		
	}

}
