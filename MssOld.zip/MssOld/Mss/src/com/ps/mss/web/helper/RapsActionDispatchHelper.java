/*
 * $Id: RapsActionDispatchHelper.java,v 1.1 2014/06/26 07:55:00 praveen Exp $
 */
package com.ps.mss.web.helper;
import java.sql.Connection;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.CodeCacheService;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.RapsConstants;
import com.ps.mss.framework.Constants;
import com.ps.mss.manager.RapsManager;
import com.ps.mss.model.RapsContext;
import com.ps.mss.model.RapsDetailItem;
import com.ps.mss.model.RapsErrorsItem;
import com.ps.mss.model.RapsFilter;
import com.ps.mss.model.RapsDetailPage;
import com.ps.mss.model.RapsClaimsDetailPage;
import com.ps.mss.model.RapsClaimDetailItem;
import com.ps.mss.model.RapsWorkflowPage;
//import com.ps.mss.model.RapsWorkflowDetalInfo;
import com.ps.mss.model.RapsWorkflowItem;
import com.ps.mss.model.Pagination;
import com.ps.mss.model.PlanEntityVO;
import com.ps.mss.web.forms.RapsForm;
import com.ps.util.DateUtil;
import com.ps.util.StringUtil;
import com.ps.util.NameValuePair;
import com.ps.mss.model.RapsErrorsPage;

public class RapsActionDispatchHelper {
    //	static ModuleLog log = new ModuleLog("RapsActionDispatchHelper");
	private static Logger logger=LoggerFactory.getLogger(RapsActionDispatchHelper.class);

	/**
 	 * TAB: RAPS Summary
	 * Page: RAPS Details - this is building the whole page.
     * @param request
     * @param rapsForm 
	 * @throws ApplicationException
     */
    public static void getRapsDetailPage(Connection conn, HttpServletRequest request, RapsForm rapsForm, RapsContext context, boolean searchMode) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	SessionHelper sessionHelper = new SessionHelper(request);
        String move = null;
        
        Pagination pagination = null;
        if (searchMode) //new search, reset pagination information
        	pagination = new Pagination();
        else //reuse old pagination info
        	pagination = context.getRapsDetailsPagination();
        context.setRapsDetailsPagination(pagination);

        //save the filter in the session
        RapsFilter filterVO = context.getRapsDetailFilter();
        String errMsg = copyFilterFromForm(sessionHelper, context.getPlanNameList(), rapsForm, filterVO, searchMode);
        if (errMsg != null ) {
        	throw new ApplicationException(errMsg);
        }
        	       
        String uiContextRange = null;
        if(request.getParameter("print") !=  null) {
        	//request for all kind of export
        	move = "current";
        	uiContextRange = request.getParameter("uiContextRange");
	        boolean list = context.isListOnSummaryDetailExpanded();
	        boolean detail = context.isDetailsOnSummaryDetailExpanded();
	        boolean more = false; //don't have additional information page
			boolean history = context.isHistoryOnSummaryDetailExpanded();
 			if(Constants.CONSTANTS_ALL.equals(uiContextRange)){
				list = true; detail = false; more = false; history = false; //if "all" request, only display the list.
				CodeCacheService codeCache=new CodeCacheService();
				Integer maxRecordCount=codeCache.getMaxRecordCount();
				pagination.setMaxRecordCount(maxRecordCount.intValue());
				pagination.setAllPage(true);
				move = "first";
			}
			request.setAttribute("expandableItems", expandable(list, detail, more, history).toString());
   		}
        
        Map planMap = sessionHelper.getPlanForParts();
        
        RapsDetailPage detailPage = RapsManager.getRapsDetailPage(conn, context, filterVO, move, planMap);
        rapsForm.setPageInfo(detailPage);
               
		if(request.getParameter("print") ==  null) { //not a print request
			setRapsDetailPagination(pagination, detailPage, context);
			if (detailPage != null) 
				context.setLastRapsDetail(detailPage.getDetailInfo());
		}
		// resetting MAX record count to 10, which may modified by print request with ALL
		pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
		pagination.setAllPage(false);
				       
        //Checking & correcting Service Date format
        checkRapsServiceDateFormat(rapsForm);
        logger.info(LoggerConstants.methodEndLevel());
    }


	/**
	 * TAB: Claims Summary
	 * Page: Claims Details
     * @param request
     * @param rapsForm 
	 * @throws ApplicationException
     */
    public static void getClaimsDetail(Connection conn, HttpServletRequest request, RapsForm rapsForm, RapsContext context, boolean searchMode) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	SessionHelper sessionHelper = new SessionHelper(request);
        String move = null;
        String errMsg = null;
        Pagination pagination = null;
        if (searchMode) //new search, reset pagination information
        	pagination = new Pagination();
        else {//reuse old pagination info
        	pagination = context.getClaimsDetailsPagination();
        	if (pagination == null)
        		pagination = new Pagination();
        }
        context.setClaimsDetailsPagination(pagination);

        //save the filter in the session
        RapsFilter filterVO = context.getClaimsDetailFilter();
        errMsg= copyFilterFromForm(sessionHelper, context.getPlanNameList(), rapsForm, filterVO, searchMode);
        if ( errMsg != null)           	
        	throw new ApplicationException(errMsg);

        if (searchMode && filterVO.getPlanName() == null)
           	throw new ApplicationException("Plan name is required");
        
        String uiContextRange = null;
        if(request.getParameter("print") !=  null) {
        	//request for all kind of export
        	move = "current";
        	uiContextRange = request.getParameter("uiContextRange");
	        boolean list = context.isListOnClaimsDetailExpanded();
	        boolean detail = context.isDetailsOnClaimsDetailExpanded();
	        boolean more = context.isAdditionalClaimInfoExpanded();
			boolean history = context.isHistoryOnClaimsDetailExpanded();
			if(Constants.CONSTANTS_ALL.equals(uiContextRange)){
				list = true; detail = false; more = false; history = false; //if "all" request, only display the list.
				CodeCacheService codeCache=new CodeCacheService();
				Integer maxRecordCount=codeCache.getMaxRecordCount();
				pagination.setMaxRecordCount(maxRecordCount.intValue());
				pagination.setAllPage(true);
				move = "first";
			}
			request.setAttribute("expandableItems", expandable(list, detail, more, history).toString());
   		}
        
        Map planMap = sessionHelper.getPlanForParts();
        
        //String custName = (String) sessionHelper.getAttribute(Constants.SESSION_CUSTOMER_NAME);
        
        RapsClaimsDetailPage detailPage = RapsManager.getClaimsDetailPage(conn, context, filterVO, move, planMap);
        rapsForm.setPageInfo(detailPage);
               
		if(request.getParameter("print") ==  null) {
			setClaimsDetailPagination(pagination, detailPage, context);
			if (detailPage != null) 
				context.setLastClaimDetail(detailPage.getDetailInfo());
		}
		// resetting MAX record count to 10, which may modified by print request with ALL
		pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
		pagination.setAllPage(false);
				       
        //Checking & correcting Service Date format
        checkRapsServiceDateFormat(rapsForm);
        logger.info(LoggerConstants.methodEndLevel());
    }     
    
    /**
 	 * TAB: RAPS Summary
	 * Page: RAPS Errors - this is building the whole page.
     * @param request
     * @param rapsForm 
     * @param context 
     * @param searchMode
	 * @throws ApplicationException
     */
    public static void getRapsErrorsPage(Connection conn, HttpServletRequest request, RapsForm rapsForm, RapsContext context, boolean initialize, boolean searchMode) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
    	SessionHelper sessionHelper = new SessionHelper(request);
        String move = null;
        
        Pagination pagination = null;
        if (searchMode) //new search, reset pagination information
        	pagination = new Pagination();
        else //reuse old pagination info
        	pagination = context.getRapsErrorsPagination();
        if (pagination == null)
        	pagination = new Pagination();
        context.setRapsErrorsPagination(pagination);

        //save the filter in the session
        RapsFilter filterVO = context.getRapsErrorsFilter();
        
        if (!initialize) {
	        String errMsg = copyFilterFromForm(sessionHelper, context.getPlanNameList(), rapsForm, filterVO, searchMode);
	        if (errMsg != null ) {
	        	throw new ApplicationException(errMsg);
	        }
        }
        	       
        String uiContextRange = null;
        if(request.getParameter("print") !=  null) {
        	//request for all kind of export
        	move = "current";
        	uiContextRange = request.getParameter("uiContextRange");
	        boolean list = context.isListOnErrorsExpanded();
	        boolean detail = context.isDetailsOnErrorsExpanded();
	        boolean more = false; //don't have additional information page
			boolean history = context.isHistoryOnErrorsExpanded();
 			if(Constants.CONSTANTS_ALL.equals(uiContextRange)){
				list = true; detail = false; more = false; history = false; //if "all" request, only display the list.
				CodeCacheService codeCache=new CodeCacheService();
				Integer maxRecordCount=codeCache.getMaxRecordCount();
				pagination.setMaxRecordCount(maxRecordCount.intValue());
				pagination.setAllPage(true);
				move = "first";
			}
			request.setAttribute("expandableItems", expandable(list, detail, more, history).toString());
   		}
        
        Map planMap = sessionHelper.getPlanForParts();
        
        RapsErrorsPage errorsPage = RapsManager.getRapsErrorsPage(conn, context, filterVO, move, planMap);
        rapsForm.setPageInfo(errorsPage);
               
		if(request.getParameter("print") ==  null) { //not a print request
			setRapsErrorsPagination(pagination, errorsPage, context);
			if (errorsPage != null) 
				context.setLastRapsErrors(errorsPage.getErrorsInfo());
		}
		// resetting MAX record count to 10, which may modified by print request with ALL
		pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
		pagination.setAllPage(false);
				       
        //Checking & correcting Service Date format
        checkRapsServiceDateFormat(rapsForm);
        logger.info(LoggerConstants.methodEndLevel());
    }
    
	/**
	 * TAB: WORKFLOW MANAGEMENT
	 * Page: Workflow Management
     * @param request
     * @param rapsForm 
	 * @throws ApplicationException
     */
 /*   public static void getWorkflow(Connection conn, HttpServletRequest request, RapsForm rapsForm, RapsContext context, boolean searchMode) throws ApplicationException {
        SessionHelper sessionHelper = new SessionHelper(request);
        String move = null;
        
        Pagination pagination = null;
    	pagination = context.getWorkflowPagination();
        if (searchMode || pagination == null) //new search, reset pagination information
        	pagination = new Pagination();
         context.setWorkflowPagination(pagination);

        //save the filter in the session
        RapsFilter filterVO = context.getWorkflowFilter();
        if (! copyFilterFromForm(sessionHelper, context.getPlanNameList(), rapsForm, filterVO, searchMode)){
        	throw new ApplicationException("getWorkflow: copyFilterFromForm found an error");
        }
        
        String uiContextRange = null;
        if(request.getParameter("print") !=  null) {
        	//request for all kind of export
        	move = "current";
        	uiContextRange = StringUtil.nonNullTrim(request.getParameter("uiContextRange"));
			request.setAttribute("uiContextRange", uiContextRange); //??? what for???
			if(Constants.CONSTANTS_ALL.equals(uiContextRange)){
				CodeCacheService codeCache=new CodeCacheService();
				Integer maxRecordCount=codeCache.getMaxRecordCount();
				pagination.setMaxRecordCount(maxRecordCount.intValue());
				pagination.setAllPage(true);
				move = "first";
			}
			
   			String searchCreiteriaHeader = PaymentManager.getSearchCreiteriaHeader(filterVO, Constants.RAPS_DETAIL, null, sessionHelper.getRapsDatabaseName());
   			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCreiteriaHeader);
   			
   		}
        
        Map planMap = sessionHelper.getPlanForParts();
        
        String custName = (String) sessionHelper.getAttribute(Constants.SESSION_CUSTOMER_NAME);
        
        RapsWorkflowPage detailPage = RapsManager.getWorkflowPage(conn, context, filterVO, "plan", move, planMap, custName);
        rapsForm.setPageInfo(detailPage);
               
		if(request.getParameter("print") ==  null) {
			setWorkflowPagination(pagination, detailPage, context);
		}
		// resetting MAX record count to 10, which may modified by print request with ALL
		pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
		pagination.setAllPage(false);
				       
        //Checking & correcting Service Date format
        checkRapsServiceDateFormat(rapsForm);
    }   */
    
	
	public static String copyFilterFromForm(SessionHelper sessionHelper, NameValuePair [] planMap, RapsForm baseForm, 
			RapsFilter filterVO, boolean searchMode) {
		logger.info(LoggerConstants.methodStartLevel());
		String result=null;
		if(searchMode) {
			/* Filter criteria changed only on the following conditions:
			 * 1. when action execute from go button.
			 * 2. When jumping from somewhere else. e.g.: Selecting something from RAPS DashBoard.
			 */
			String temp = StringUtil.trimToNull(baseForm.getPlanName()); 
			//validate planName - it has to be in the supported plan list
			if (temp != null) {
				int i ;
				for (i = 0; i<planMap.length; i++) {
					if (temp.equals(planMap[i].getName())) 
						break;
				}
				if (i == planMap.length) {
					logger.info(LoggerConstants.methodEndLevel());
					return ("Illegal plan " + temp);
				}
				try {
					Map custMap = sessionHelper.getPlansForCustomer();
					PlanEntityVO planEntityVO = (PlanEntityVO)custMap.get(temp);
					if (planEntityVO == null) {
						logger.info(LoggerConstants.methodEndLevel());
						return("PlanEntityVO is null for plan " + temp);
					}
					filterVO.setPartC(planEntityVO.isPartC());
				}
				catch (Exception e) {
					logger.info(LoggerConstants.methodEndLevel());
					return ("copyFilterFromForm  " + e.toString());
				}
			}
			filterVO.setPlanName(temp);
			temp = StringUtil.trimToNull(baseForm.getFromDate());
			if (temp != null && ! DateUtil.isGoodDate(temp)){
				logger.info(LoggerConstants.methodEndLevel());
				return("Invalid Date " + temp);
			}
			filterVO.setFromDate(temp);
			
			temp = StringUtil.trimToNull(baseForm.getToDate());
			if (temp != null && ! DateUtil.isGoodDate(temp)) {
				logger.info(LoggerConstants.methodEndLevel());
				return("Invalid Date " + temp);
			}
			filterVO.setToDate(temp);
			
			temp = StringUtil.trimToNull(baseForm.getHicNbr());
			if (temp != null && !StringUtil.isAlphaNumeric(temp)) {
				logger.info(LoggerConstants.methodEndLevel());
				return("Invalid Hic# " + temp);
			}
			filterVO.setHicNbr(temp);
			/*SSNRI Changes*/ 
			temp = StringUtil.trimToNull(baseForm.getMbi());
			if (temp != null && !StringUtil.isAlphaNumeric(temp)) {
				logger.info(LoggerConstants.methodEndLevel());
				return("Invalid Mbi# " + temp);
			}
			filterVO.setMbi(temp);
			/*SSNRI Changes*/ 
			temp = StringUtil.trimToNull(baseForm.getClaimId());
			if (temp != null && !StringUtil.isValidString(temp)){ //' ' and '-' should be a valid character for claim id
				logger.info(LoggerConstants.methodEndLevel());
				return("Invalid Claim ID " + temp);
			}
			filterVO.setClaimId(temp);
			
			temp = StringUtil.trimToNull(baseForm.getStatus());
			if (temp != null && !StringUtil.isAlphaNumeric(temp)) {
				logger.info(LoggerConstants.methodEndLevel());
				return("Invalid Status field " + temp);
			}
			filterVO.setStatus(temp);
			
			temp = StringUtil.trimToNull(baseForm.getErrorStatus());
			if (temp != null && !StringUtil.isAlphaNumeric(temp)) {
				logger.info(LoggerConstants.methodEndLevel());
				return("Invalid Error Status field " + temp);
			}
			filterVO.setErrorStatus(temp);
			
			temp = StringUtil.trimToNull(baseForm.getHcc());
			if (temp != null && !StringUtil.isAlphaNumeric(temp)) {
				logger.info(LoggerConstants.methodEndLevel());
				return("Invalid HCC " + temp);
			}
			filterVO.setHcc(temp);
			
			temp = StringUtil.trimToNull(baseForm.getSortBy());
			if (temp != null && !StringUtil.isAlphaNumeric(temp)) {
				logger.info(LoggerConstants.methodEndLevel());
				return("Invalid Sort By Option " + temp);
			}
			filterVO.setSortBy(temp);
			
			/* The following are for workflow
			filterVO.setFromLastUpdate(StringUtil.trimToNull(baseForm.getFromLastUpdate()));
			filterVO.setToLastUpdate(StringUtil.trimToNull(baseForm.getToLastUpdate()));
			*/
		}
		logger.info(LoggerConstants.methodEndLevel());
		return result;
	}	
	/**
	 * This set detailMap which contain total number of page ,records , first and last record of Pde Event Detail List 
	 * @param pdeMap
	 * @param pdeDetailVOList
	 * @param sessionHelper
	 */
    private static void setRapsDetailPagination(Pagination pagination, RapsDetailPage detailPage, RapsContext context) {
    	logger.info(LoggerConstants.methodStartLevel());
    	if(detailPage != null) {
            RapsDetailItem[] items = detailPage.getRapsDetails();
            if(items != null ){
            	pagination.setFirstDetail(items[0]);
            	pagination.setLastDetail(items[items.length-1]);
            	pagination.setCurrentPage(detailPage.getCurrentPage());
            	pagination.setPageNumber(detailPage.getPageNumber());
                
            }
            context.setRapsDetailsPagination(pagination);
        }
    	logger.info(LoggerConstants.methodEndLevel());
    }
	/**
	 * This set detailMap which contain total number of page ,records , first and last record of Pde Event Detail List 
	 * @param pdeMap
	 * @param pdeDetailVOList
	 * @param sessionHelper
	 */
    private static void setClaimsDetailPagination(Pagination pagination, RapsClaimsDetailPage detailPage, RapsContext context) {
    	logger.info(LoggerConstants.methodStartLevel());
    	if(detailPage != null) {
            RapsClaimDetailItem[] items = detailPage.getClaimsList();
            if(items != null ){
            	pagination.setFirstDetail(items[0]);
            	pagination.setLastDetail(items[items.length-1]);
            	pagination.setCurrentPage(detailPage.getCurrentPage());
            	pagination.setPageNumber(detailPage.getPageNumber());               
            }
            context.setClaimsDetailsPagination(pagination);
        }
    	logger.info(LoggerConstants.methodEndLevel());
    }
	/**
	 * This set detailMap which contain total number of page ,records , first and last record of Pde Event Detail List 
	 * @param pdeMap
	 * @param pdeDetailVOList
	 * @param sessionHelper
	 */
    private static void setWorkflowPagination(Pagination pagination, RapsWorkflowPage detailPage, RapsContext context) {
    	logger.info(LoggerConstants.methodStartLevel());
    	if(detailPage != null) {
            RapsWorkflowItem[] items = detailPage.getWorkflowItems();
            if(items != null ){
            	pagination.setFirstDetail(items[0]);
            	pagination.setLastDetail(items[items.length-1]);
            	pagination.setCurrentPage(detailPage.getCurrentPage());
            	pagination.setPageNumber(detailPage.getPageNumber());               
            }
            context.setWorkflowPagination(pagination);
        }
    	logger.info(LoggerConstants.methodEndLevel());
    }
    /**
	 * This set detailMap which contain total number of page ,records , first and last record of RAPS Errors Page 
	 * @param pagination
	 * @param errorsPage
	 * @param context
	 */
    private static void setRapsErrorsPagination(Pagination pagination, RapsErrorsPage errorsPage, RapsContext context) {
    	logger.info(LoggerConstants.methodStartLevel());
    	if(errorsPage != null) {
            RapsErrorsItem[] items = errorsPage.getRapsErrors();
            if(items != null ){
            	pagination.setFirstDetail(items[0]);
            	pagination.setLastDetail(items[items.length-1]);
            	pagination.setCurrentPage(errorsPage.getCurrentPage());
            	pagination.setPageNumber(errorsPage.getPageNumber());
                
            }
            context.setRapsErrorsPagination(pagination);
        }
    	logger.info(LoggerConstants.methodEndLevel());
    }
    /**
	 * Checking & correcting Service Date formate
	 * @param rapsForm
	 */
	private static void checkRapsServiceDateFormat(RapsForm rapsForm) {
		logger.info(LoggerConstants.methodStartLevel());
		String startDate = rapsForm.getFromDate();
		String endDate = rapsForm.getToDate(); 
		
		if(startDate != null && startDate.length() == 7 ){
			startDate = DateUtil.getFirstOrLastDayOfMonth(startDate, true);
			rapsForm.setFromDate(startDate);
		}
		
		if(endDate != null && endDate.length() == 7 ){
			endDate = DateUtil.getFirstOrLastDayOfMonth(endDate, false);
			rapsForm.setToDate(endDate);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	private static StringBuffer expandable(boolean list, boolean detail, boolean more, boolean history) {
		logger.info(LoggerConstants.methodStartLevel());
		StringBuffer s = new StringBuffer("");
		s.append((list? RapsConstants.RAPS_EXPANDABLE_LIST: "")).append(detail?RapsConstants.RAPS_EXPANDABLE_DETAILS:"")
		.append((more? RapsConstants.RAPS_EXPANDABLE_MOREINFO: "")).append(history?RapsConstants.RAPS_EXPANDABLE_HISTORY:"");
		logger.info(LoggerConstants.methodEndLevel());
		return s;
	}

}
