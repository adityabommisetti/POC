
package com.ps.mss.web.helper;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.web.forms.McaidReconAnomForm;

public class McaidReconAnomHelper {
	private static Logger logger=LoggerFactory.getLogger(McaidReconAnomHelper.class);
	public static void saveAnomForm(SessionHelper sessionHelper, McaidReconAnomForm form) {
		 logger.info(LoggerConstants.methodStartLevel());
		 sessionHelper.setAttribute("SaveAnomForm",form);
		 logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static McaidReconAnomForm getAnomForm(SessionHelper sessionHelper) {
		 logger.info(LoggerConstants.methodStartLevel());
		 return (McaidReconAnomForm)sessionHelper.getAttribute("SaveAnomForm");
	}
	
}//MCReconDiscHelper
