/*
 * $Id: EEMLetterReviewGenerateForm.java,v 1.1 2014/06/26 07:55:49 praveen Exp $
 */
package com.ps.mss.web.forms;

public class EEMLetterReviewGenerateForm extends EEMSubMenuForm {

}
