/*
 * $Id: EEMEnrollHelper.java,v 1.5 2016/08/21 23:16:44 dinesh Exp $
 */
package com.ps.mss.web.helper;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpSession;
import com.ps.mss.dynaCache.EEMDynaCache;
import org.slf4j.Logger;
import com.ps.text.DateFormatter;
import com.ps.util.NamedItem;
import com.ps.util.StringUtil;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.model.EmCorrMbrVO;
import com.ps.mss.dao.model.EmMbrAccretionVO;
import com.ps.mss.dao.model.EmMbrAddressVO;
import com.ps.mss.dao.model.EmMbrAgentVO;
import com.ps.mss.dao.model.EmMbrBillingVO;
import com.ps.mss.dao.model.EmMbrCobVO;
import com.ps.mss.dao.model.EmMbrCommentVO;
import com.ps.mss.dao.model.EmMbrDsInfoVO;
import com.ps.mss.dao.model.EmMbrEnrollmentVO;
import com.ps.mss.dao.model.EmMbrErrorVO;
import com.ps.mss.dao.model.EmMbrLepInfoVO;
import com.ps.mss.dao.model.EmMbrLisInfoVO;
import com.ps.mss.dao.model.EmMbrOoaInfoVO;
import com.ps.mss.dao.model.EmMbrTrrLogVO;
import com.ps.mss.dao.model.EmPresetVo;
import com.ps.mss.db.EEMCodeCache;
import com.ps.mss.db.EEMProfileSettings;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.EEMEnrollVO;
import com.ps.mss.model.EMGroupProductSearchVO;
import com.ps.mss.model.EMMbrLTCInfoVO;
import com.ps.mss.model.EMMbrPCPInfoVO;
import com.ps.mss.model.EmMbrPosEditVO;
import com.ps.mss.web.forms.EEMEnrollForm;
import com.ps.mss.web.forms.EEMEnrollGPSearchForm;
import com.ps.mss.framework.EEMConstants;

import com.ps.mss.dao.model.EmMbrAsesVO;

/**
 * @author DParker
 */
public class EEMEnrollHelper {

	private static Properties prop;
	private static Logger logger=LoggerFactory.getLogger(EEMEnrollHelper.class);
	
	public static void clearContextDisplay(EEMEnrollVO enrollVO) {
		logger.info(LoggerConstants.methodStartLevel());
		enrollVO.setSearchResults(null);
		enrollVO.setDemographics(null);
		enrollVO.setEnrollments(null);
		enrollVO.setDsInfos(null);
		enrollVO.setLisInfos(null);
		enrollVO.setLepInfos(null);
		//New LEP changes - Start
		enrollVO.setLepPotential(null);
		//New LEP changes - end
		enrollVO.setAddresses(null);
		enrollVO.setLetters(null);
		enrollVO.setLetterData(null);
		enrollVO.setPcpInfos(null);
		enrollVO.setComments(null);
		enrollVO.setErrors(null);
		enrollVO.setTrrLogs(null);		
		enrollVO.setListAgents(null);
		enrollVO.setListCobs(null);
		/** Triple S BasePlus Migration START **/
		//ASES CR For TripleS -Start
		enrollVO.setListAses(null);
		//ASES CR For TripleS -End
		/** Triple S BasePlus Migration END **/
		/**
	     * 033_Highmark_SUC_OOASCCprocess  - Start
	     */
		
		enrollVO.setOoaInfos(null);

		/**
	     * 033_Highmark_SUC_OOASCCprocess  -end
	     * 
	     */
		/**
	     * 020_Highmark_SUC_UI_v1.03 (Accretion)  - Start
	     */
		
		enrollVO.setListAccretion(null);

		/**
	     * 020_Highmark_SUC_UI_v1.03 (Accretion)  -end
	     * 
	     */
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void clearFormDisplay(EEMEnrollForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		form.setListSearchResults(null);
		form.setSelectedSearchRow(0);
		form.setListDemographicsWithDisplay(null);

		form.setListEnrollmentsWithDisplay(null);
		form.setSelectedEnrollmentRow(0);
		form.setTopDisplayEnrollmentRow(0);
		
		form.setListDsInfosWithDisplay(null);
		form.setSelectedDsInfoRow(0);
		form.setTopDisplayDsInfoRow(0);
		
		form.setListLisInfosWithDisplay(null);
		form.setSelectedLisInfoRow(0);
		form.setTopDisplayLisInfoRow(0);
		
		form.setListLepInfosWithDisplay(null);
		form.setSelectedLepInfoRow(0);
		form.setTopDisplayLepInfoRow(0);
		//New LEP changes - Start
		form.setListLepPotentialWithDisplay(null);
		form.setSelectedLepPotentialRow(0);
		form.setTopDisplayLepPotentialRow(0);
		//New LEP changes - end
		form.setListAddressesWithDisplay(null);
		form.setSelectedAddressRow(0);
		form.setTopDisplayAddressRow(0);
		
		form.setListLettersWithDisplay(null);
		form.setSelectedLetterRow(0);
		form.setTopDisplayLetterRow(0);	
		form.setDisplayLetterVarData(null);
		
		form.setListPcpInfosWithDisplay(null);			
		form.setSelectedPcpInfoRow(0);
		form.setTopDisplayPcpInfoRow(0);
		
		form.setListCommentsWithDisplay(null);		
		form.setSelectedCommentRow(0);
		form.setTopDisplayCommentRow(0);

		form.setListErrorsWithDisplay(null);		
		form.setSelectedErrorRow(0);
		form.setTopDisplayErrorRow(0);
		
		form.setListTrrLogsWithDisplay(null);		
		form.setSelectedTrrLogRow(0);
		form.setTopDisplayTrrLogRow(0);
		
		form.setListAgentsWithDisplay(null);			
		form.setSelectedAgentRow(0);
		form.setTopDisplayAgentRow(0);
		
		form.setListCobsWithDisplay(null);			
		form.setSelectedCobRow(0);
		form.setTopDisplayCobRow(0);
		
		/**
	     * 033_Highmark_SUC_OOASCCprocess  - Start
	     */

		form.setListOoaWithDisplay(null);
		form.setSelectedOoaInfoRow(0);
		form.setTopDisplayOoaInfoRow(0);

		/**
	     * 033_Highmark_SUC_OOASCCprocess  -end
	     * 
	     */
		/**
	     * 020_Highmark_SUC_UI_v1.03 (Accretion)  - Start
	     */
		
		form.setListAccretionWithDisplay(null);
		form.setSelectedAccretionRow(0);
		form.setTopDisplayAccretionRow(0);
		/**
	     * 020_Highmark_SUC_UI_v1.03 (Accretion)  - End
	     */
		/** Triple S BasePlus Migration START **/
		//ASES CR For TripleS -Start
		form.setListAsesWithDisplay(null);
		form.setSelectedAsesRow(0);
		form.setTopDisplayAsesRow(0);
		//ASES CR For TripleS -End
		/** Triple S BasePlus Migration END **/
		
		
		/**
		 * 024_Cambia_SUC_LEP - Start 01
		 */
		form.setListLepAttestInfosWithDisplay(null);
		form.setOutInitAttests(null);
		form.setInInitAttests(null);
		form.setOutIncAttests(null);
		form.setInIncAttests(null);
		form.setInLateAttests(null);
		
		/**
		 * 024_Cambia_SUC_LEP - End 01
		 */
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void setEnrollFormList(EEMEnrollForm eemEnrollForm, HttpSession session)
	throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		//Implementing DynaCache for performance :start
		//EEMCodeCache objCache = EEMCodeCache.getInstance();
		EEMCodeCache objCache = EEMDynaCache.getDynaCacheMap();
		
		//Implementing DynaCache for performance :end
		eemEnrollForm.setValidAddressTypes(objCache.getLstAddrTypes());
		eemEnrollForm.setValidAgentTypes(objCache.getLstAgentTypes());
		eemEnrollForm.setValidDisenrollmentReasons(objCache.getLstDisReasonCode());
		//added for Lumeris Plan reason code
		eemEnrollForm.setValidPlanReasons(objCache.getLstPlanReasonCode((session.getAttribute("MF_id").toString())));
		eemEnrollForm.setValidElectionTypes(objCache.getLstElectionTypes());
		eemEnrollForm.setValidEnrollSources(objCache.getLstEnrollSrce());
		eemEnrollForm.setValidEnrollStatuses(objCache.getLstEnrollStatus());	
		eemEnrollForm.setValidEnrollReasons(objCache.getLstEnrollReasonCode());
		eemEnrollForm.setValidEnrollStatusReasons(objCache.getLstEnrollStatusReason());
		eemEnrollForm.setValidGenderCodes(objCache.getLstGenderCds());
		eemEnrollForm.setValidLanguages(objCache.getLstLanguages());
		eemEnrollForm.setValidAlternateCorrespondenceMethods(objCache.getLstAltCorrespondences());
		eemEnrollForm.setValidMaritalStatuses(objCache.getLstMaritalStatus());
		eemEnrollForm.setValidPrefixes(objCache.getLstPrefix());
		eemEnrollForm.setValidRaceCodes(objCache.getLstRaceCds());
		eemEnrollForm.setValidRelations(objCache.getLstRelations());
		eemEnrollForm.setValidSepExceptions(objCache.getLstSepExceptions());
		eemEnrollForm.setValidStates(objCache.getLstStates());
		eemEnrollForm.setArrYesNo(objCache.getArrYesNo());
		eemEnrollForm.setValidDsCodes(objCache.getLstUserDsCodes());
		eemEnrollForm.setValidMemberStatus(objCache.getLstMemberStatus());
		eemEnrollForm.setValidLiPercents(objCache.getLstLiPercents());
		eemEnrollForm.setValidLiCopays(objCache.getLstLiCopays());
		eemEnrollForm.setValidCountry(objCache.getLstCountry());
		eemEnrollForm.setValidSEPReasons(objCache.getLstSEPReasons());
		eemEnrollForm.setValidSubsidySrce(objCache.getLstSubsidySrce());
		eemEnrollForm.setValidCobTypes(objCache.getLstCobTypes());
		eemEnrollForm.setValidOhiInd(objCache.getLstOhiInd());
		eemEnrollForm.setValidAccountType(objCache.getLstAccountType());
		eemEnrollForm.setValidBillPayMethod(objCache.getLstBillPayMethod());
		eemEnrollForm.setValidBillFrequency(objCache.getLstBillFrequency());
		/** Triple S BasePlus Migration START **/
		// TSA : Spanish Language Change :start
		String corrLang = (String) (session.getAttribute("CORRLANG")== null ? "" : session.getAttribute("CORRLANG") )  ;
		if ("SPA".equalsIgnoreCase(corrLang))
			eemEnrollForm.setValidLanguages(objCache.getTsaLstLanguages(corrLang));
		else
			eemEnrollForm.setValidLanguages(objCache.getLstLanguages());
		// TSA : Spanish Language Change :End
		
		//TSA : COB Types Change :start
		String cobType = (String) (session.getAttribute("COBPRIM")== null ? "" : session.getAttribute("COBPRIM") )  ;
		//System.out.println("cobType--"+cobType);
		if("PRIM".equalsIgnoreCase(cobType))
			eemEnrollForm.setValidCobTypes(objCache.getLstTSACobTypes("Primary"));
		else
			eemEnrollForm.setValidCobTypes(objCache.getLstCobTypes());
		//TSA : COB Types Change :End
		
		//TSA :Address Date Validation Change IFOX-00407264 :start
		String addrVal	=  (String) (session.getAttribute("ADRVAL")== null ? "" : session.getAttribute("ADRVAL") )  ;
		if("VALID".equalsIgnoreCase(addrVal))
			eemEnrollForm.setAddValidation("true");
		//TSA :Address Date Validation Change IFOX-00407264 :end
		/** Triple S BasePlus Migration END **/
		
		/*CMS 2019 changes- requirement 5-Start*/
		eemEnrollForm.setValidDrugEditClass(objCache.getLstDrugEditClass());
		/*CMS 2019 changes- requirement 5-Start*/
		
		
		/**
		 * 024_Cambia_SUC_LEP - Start 02
		 */
		eemEnrollForm.setValidStatus(objCache.getLstAttestStatus());

		eemEnrollForm.setValidLEPType(objCache.getLstLEPType());
		eemEnrollForm.setLepNunCmoStstus(objCache.getLstLepNunCmoStatus());
		eemEnrollForm.setMaxReconTypes(objCache.getLstMaximusType());
		eemEnrollForm.setRecvdChannel(objCache.getChannelList());
		eemEnrollForm.setMemberAppeal(objCache.getMemberAppealList());
		eemEnrollForm.setBrkInCoverageType(objCache.getBreakInCoverageTypeList());
		//New LEP changes - start
		eemEnrollForm.setRespType(objCache.getRespTypeList());
		//New LEP changes - end
		/**
		 * 024_Cambia_SUC_LEP - End 02
		 */
		 /**
	     * Cambia_PRE-SET NOTES - Start
	     */
		
		eemEnrollForm.setPreSetNoteList(objCache.getHmPreSetNotes(session.getAttribute("MF_id").toString()));
		// Performance Changes -Start
		//EmPresetVo pre = (EmPresetVo)eemEnrollForm.getPreSetNoteList().get(0);
		//eemEnrollForm.setMaxId(pre.getMaxId());
		//session.setAttribute("PresetMaxId", pre.getMaxId());
		// Performance Changes -End
		 /**
	     * Cambia_PRE-SET NOTES - End
	     */
		/**
		 *Cambia_OEVprocess-start
		 */
		eemEnrollForm.setOevCallStatusDrop(objCache.getLstOevCallStatus(session.getAttribute("MF_id").toString()));
		eemEnrollForm.setOevCallSubReasonDrop(objCache.getLstOevCallSubsetReason(session.getAttribute("MF_id").toString()));
		/**
		 * Cambia_OEVprocess-end
		 */
		EmMbrCobVO dispCob = eemEnrollForm.getDisplayCob(); 
		if (dispCob != null)
			dispCob.setLstOhiInd(objCache.getRelatedList(dispCob.getCobType(), objCache.getLstOhiInd()));
		/**
		 *  033_Highmark_OOA_SCC_UI-Start
		 */
		
		eemEnrollForm.setOoaReasonList(objCache.getOoaReasonList(session.getAttribute("MF_id").toString()));
		eemEnrollForm.setOoaSourceList(objCache.getOoaSourceList(session.getAttribute("MF_id").toString()));
		eemEnrollForm.setOoaDeReasonList(objCache.getOoaDeReasons(session.getAttribute("MF_id").toString()));
		/**
		 * Cambia_Member Cancellation -Start
		 */
		eemEnrollForm.setEnrollCancelReasons(objCache.getLstCancellationReasons(session.getAttribute("MF_id").toString()));
		/**
		 * Cambia_Member Cancellation -End
		 */
		
		/**
		 * cambia pos start
		 */
		eemEnrollForm.setValidTxnStatus(objCache.getValidTxnStatus());
		
		/**
		 * cambia pos end
		 */
		
		/** Triple S BasePlus Migration START **/
		//ASES CR For TripleS -Start
		eemEnrollForm.setValidPlanVersions(objCache.getLstPlanVersions());
		eemEnrollForm.setValidStatuses(objCache.getLstStatuses());
		//ASES CR For TripleS -End
		/** Triple S BasePlus Migration END **/
		
		//Start IFOX-00389053 
		if(session.getAttribute(EEMProfileSettings.LOB_VALD)!= null)
			eemEnrollForm.setLobValidation(session.getAttribute(EEMProfileSettings.LOB_VALD).toString());
		//End IFOX-00389053 
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void setValidOhiList(EEMEnrollForm eemEnrollForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		if (eemEnrollForm.getDisplayCob() != null) {
			String cobType = StringUtil.nonNullTrim(eemEnrollForm.getDisplayCob().getCobType());
			if (!cobType.equals("")) {
				List lstInd = EEMCodeCache.getInstance().getLstOhiInd();
				for (int i = 0; i < lstInd.size(); i++) {
					NamedItem item = (NamedItem)lstInd.get(i);
					if (item.getName().equals(cobType)) {
						eemEnrollForm.setValidOhiInd((List)item.getItem());	
						break;
					}
				}
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void copyGPSearchFormToVO(EEMEnrollGPSearchForm gpForm,EMGroupProductSearchVO gpVO) {
		logger.info(LoggerConstants.methodStartLevel());
		gpVO.setCustomerId(gpForm.getCustomerId());
		gpVO.setMemberId(gpForm.getMemberId());
		gpVO.setEffDate(DateFormatter.reFormat(gpForm.getEffDate(),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD));
		gpVO.setGrpId(gpForm.getGrpId());
		gpVO.setGroupName(gpForm.getGroupName());
		gpVO.setProductId(gpForm.getProductId());
		gpVO.setProductName(gpForm.getProductName());
		gpVO.setOutOfArea(gpForm.getOutOfArea());
		gpVO.setZipCd5(gpForm.getZipCd5());
		gpVO.setZipCd4(gpForm.getZipCd4());
		gpVO.setPlanId(gpForm.getPlanId());
		gpVO.setPbpId(gpForm.getPbpId());
		gpVO.setPbpSegmentId(gpForm.getPbpSegmentId());		
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void copyVOToForm(EEMEnrollVO enrollVO, EEMEnrollForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		if (!StringUtil.nonNullTrim(enrollVO.getMessage()).equals(""))
			form.setMessage(enrollVO.getMessage());

		form.setListSearchResults(enrollVO.getSearchResults());
		form.setListDemographics(enrollVO.getDemographics());		
		form.setListEnrollments(enrollVO.getEnrollments());
		form.setListDsInfos(enrollVO.getDsInfos());
		form.setListLisInfos(enrollVO.getLisInfos());
		form.setListLepInfos(enrollVO.getLepInfos());
		//New LEP changes - Start
		form.setListLepPotential(enrollVO.getLepPotential());
		form.setLepAttestationCcf(enrollVO.getLepAttestationCcf());
		form.setTotalPlepMonths(enrollVO.getTotalPlepMonths());
		//New LEP changes - end
		form.setListAddresses(enrollVO.getAddresses());
		form.setListLetters(enrollVO.getLetters());
		//IFOX-00426356: Attachment CR
		form.setAttachments(enrollVO.getAttachments());
		form.setDisplayLetterVarData(enrollVO.getLetterData());
		form.setListPcpInfos(enrollVO.getPcpInfos());
		//IFOX-00399921 LTC Tab. START
		form.setListLtcInfos(enrollVO.getLtcInfos());
		//IFOX-00399921 LTC Tab. END
		form.setListComments(enrollVO.getComments());
		form.setListErrors(enrollVO.getErrors());		
		form.setListTrrLogs(enrollVO.getTrrLogs());
		form.setListAgents(enrollVO.getListAgents());
		form.setListCobs(enrollVO.getListCobs());
		form.setListBilling(enrollVO.getListBilling());
		/**
		 *  033_Highmark_OOA_SCC_UI-Start
		 */
		
		form.setListOoaInfos(enrollVO.getOoaInfos());
		/**
		 *  033_Highmark_OOA_SCC_UI-End
		 */
		/**
	     * 020_Highmark_SUC_UI_v1.03 (Accretion)  - Start
	     */
		form.setListAccretion(enrollVO.getListAccretion());
		/**
	     * 020_Highmark_SUC_UI_v1.03 (Accretion)  - End
	     */
		

		/**
		 * Cambia POS - Start
		 */
		form.setListPosEdits(enrollVO.getListPosEdit());
		/**
		 * Cambia POS - end
		 */
		/**
		 * 024_Cambia_SUC_LEP - Start 03
		 */
		form.setCheckLep(enrollVO.getCheckLep());
		form.setCredCovInfo(enrollVO.getCredCovInfo());
		form.setLepAdjInfo(enrollVO.getLepAdjInfo());
		form.setCredcovTimer(enrollVO.getCredcovTimer());
		form.setListLepAttestInfosWithDisplay(enrollVO.getLepAttestInfo());	
		form.setOutInitAttests(enrollVO.getOutInitAttests());
		form.setInInitAttests(enrollVO.getInInitAttests());
		form.setOutIncAttests(enrollVO.getOutIncAttests());
		form.setInIncAttests(enrollVO.getInIncAttests());
		form.setInLateAttests(enrollVO.getInLateAttests());

		/**
		 * 024_Cambia_SUC_LEP - End 03
		 */
		/** Triple S BasePlus Migration START **/
		//ASES CR For TripleS -Start
		form.setListAses(enrollVO.getListAses());
		//ASES CR For TripleS -End
		/** Triple S BasePlus Migration END **/
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void setDisplayItems(EEMEnrollVO enrollVO, EEMEnrollForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		int selectedRow;
		List lst;
		
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form.getEnrollmentDisplayState())) {
			selectedRow = form.getSelectedEnrollmentRow();
			lst = form.getListEnrollments();
			if (lst != null) {
				if (lst.size() > 0) {
					form.setDisplayEnrollment((EmMbrEnrollmentVO)lst.get(selectedRow));
				}
			}
		}
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form.getDsInfoDisplayState())) {
			selectedRow = form.getSelectedDsInfoRow();
			lst = form.getListDsInfos();
			if (lst != null) {
				if (lst.size() > 0) {
					form.setDisplayDsInfo((EmMbrDsInfoVO)lst.get(selectedRow));
				}
			}
		}
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form.getLisInfoDisplayState())) {
			selectedRow = form.getSelectedLisInfoRow();
			lst = form.getListLisInfos();
			if (lst != null) {
				if (lst.size() > 0) {
					form.setDisplayLisInfo((EmMbrLisInfoVO)lst.get(selectedRow));
				}
			}
		}
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form.getLepInfoDisplayState())) {
			selectedRow = form.getSelectedLepInfoRow();
			lst = form.getListLepInfos();
			if (lst != null) {
				if (lst.size() > 0) {
					form.setDisplayLepInfo((EmMbrLepInfoVO)lst.get(selectedRow));
					/**
					 * 024_Cambia_SUC_LEP - Start 04
					 */
					form.setCheckLep(enrollVO.getCheckLep());
					form.setCredCovInfo(enrollVO.getCredCovInfo());
					form.setLepAdjInfo(enrollVO.getLepAdjInfo());
					form.setCredcovTimer(enrollVO.getCredcovTimer());
					/**
					 * 024_Cambia_SUC_LEP - End 04
					 */
				}
			}
		}
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form.getAddressDisplayState())) {
			selectedRow = form.getSelectedAddressRow();
			lst = form.getListAddresses();
			if (lst != null) {
				if (lst.size() > 0) {
					form.setDisplayAddress((EmMbrAddressVO)lst.get(selectedRow));
				}
			}
		}
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form.getLetterDisplayState())) {
			selectedRow = form.getSelectedLetterRow();
			lst = form.getListLetters();
			if (lst != null) {
				if (lst.size() > 0) {
					form.setDisplayLetter((EmCorrMbrVO)lst.get(selectedRow));
				}
			}
		}
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form.getPcpInfoDisplayState())) {
			selectedRow = form.getSelectedPcpInfoRow();
			lst = form.getListPcpInfos();
			if (lst != null) {
				if (lst.size() > 0) {
					form.setDisplayPcpInfo((EMMbrPCPInfoVO)lst.get(selectedRow));
				}
			}
		}
		//IFOX-00399921 LTC Tab. START
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form.getLtcInfoDisplayState())) {
			selectedRow = form.getSelectedLtcInfoRow();
			lst = form.getListLtcInfos();
			if (lst != null) {
				if (lst.size() > 0) {
					form.setDisplayLtcInfo((EMMbrLTCInfoVO)lst.get(selectedRow));
				}
			}
		}
		//IFOX-00399921 LTC Tab. END
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form.getCommentDisplayState())) {
			selectedRow = form.getSelectedCommentRow();
			lst = form.getListComments();
			if (lst != null) {
				if (lst.size() > 0) {
					form.setDisplayComment((EmMbrCommentVO)lst.get(selectedRow));
				}
			}
		}
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form.getTrrLogDisplayState())) {
			selectedRow = form.getSelectedTrrLogRow();
			lst = form.getListTrrLogs();
			if (lst != null) {
				if (lst.size() > 0) {
					form.setDisplayTrrLog((EmMbrTrrLogVO)lst.get(selectedRow));
				}
			}
		}
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form.getErrorDisplayState())) {
			selectedRow = form.getSelectedErrorRow();
			lst = form.getListErrors();
			if (lst != null) {
				if (lst.size() > 0) {
					form.setDisplayError((EmMbrErrorVO)lst.get(selectedRow));
				}
			}
		}
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form.getAgentDisplayState())) {
			selectedRow = form.getSelectedAgentRow();
			lst = form.getListAgents();
			if (lst != null) {
				if (lst.size() > 0) {
					form.setDisplayAgent((EmMbrAgentVO)lst.get(selectedRow));
				}
			}
		}
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form.getCobDisplayState())) {
			selectedRow = form.getSelectedCobRow();
			lst = form.getListCobs();
			if (lst != null) {
				if (lst.size() > 0) {
					form.setDisplayCob((EmMbrCobVO)lst.get(selectedRow));
				}
			}
		}
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form.getBillingDisplayState())) {
			selectedRow = form.getSelectedBillingRow();
			lst = form.getListBilling();
			if (lst != null) {
				if (lst.size() > 0) {
					form.setDisplayBilling((EmMbrBillingVO)lst.get(selectedRow));
				}
			}
		}
		/**
		 * 024_Cambia_SUC_LEP - Start 05
		 */
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form
				.getLepInfoDisplayState())) {			
			form.setListLepAttestInfosWithDisplay(enrollVO.getLepAttestInfo());			
//			lst = form.getLepAttestationInfo();
			
			
		}
		
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form
				.getLepInfoDisplayState())) {
			
			form.setOutInitAttests(enrollVO.getOutInitAttests());
			form.setInInitAttests(enrollVO.getInInitAttests());
			form.setOutIncAttests(enrollVO.getOutIncAttests());
			form.setInIncAttests(enrollVO.getInIncAttests());
			form.setInLateAttests(enrollVO.getInLateAttests());
			
		}
		/**
		 * 024_Cambia_SUC_LEP - End 05
		 */
		/**
		 *  033_Highmark_OOA_SCC_UI-Start
		 */
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form
				.getOoaInfoDisplayState())) {
			selectedRow = form.getSelectedOoaInfoRow();
			lst = form.getListOoaInfos();
			if (lst != null) {
				if (lst.size() > 0) {
					form.setDisplayOoaInfo((EmMbrOoaInfoVO) lst
							.get(selectedRow));
				}
			}
		}
		/**
		 *  033_Highmark_OOA_SCC_UI-End
		 */
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form.getAccretionDisplayState())) {
			selectedRow = form.getSelectedAccretionRow();
			lst = form.getListAccretion();
			if (lst != null) {
				if (lst.size() > 0) {
					form.setDisplayAccretion((EmMbrAccretionVO)lst.get(selectedRow));
				}
			}
		}
		

		/**
		 * Cambia POS - Start
		 */
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form
				.getPosEditDisplayState())) {
			selectedRow = form.getSelectedPosEditRow();
			lst = form.getListPosEdits();
			if (lst != null) {
				if (lst.size() > 0) {
				//	form.setDisplayPosEdit((EmMbrPosEditVO)lst.get(selectedRow));
					form.setDisplayPosEdit((EmMbrPosEditVO)lst.get(selectedRow));
				}
			}
		}
		/**
		 * Cambia POS - End
		 */
		
		
		/** Triple S BasePlus Migration START **/
		//ASES CR For TripleS -Start
		if (EEMConstants.EEM_MBR_SCREEN_VIEW.equals(form.getAsesDisplayState())) {
			selectedRow = form.getSelectedAsesRow();
			lst = form.getListAses();
			if (lst != null) {
				if (lst.size() > 0) {
					form.setDisplayAses((EmMbrAsesVO)lst.get(selectedRow));
				}
			}
		}
		//ASES CR For TripleS -End
		/** Triple S BasePlus Migration END **/
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void saveEEMForm(SessionHelper sessionHelper, EEMEnrollForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		sessionHelper.setAttribute("SaveEEMEnrollForm",form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	public static EEMEnrollForm getEEMForm(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (EEMEnrollForm)sessionHelper.getAttribute("SaveEEMEnrollForm");
	}
	
	public static String getProperty(String sKey) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String sValue = null;
		FileInputStream propFile = null;
		try {
			if (prop == null) {
				prop = new Properties();
				propFile = new FileInputStream("EEMProperties.properties");
				prop.load(propFile);
			}
			sValue = prop.getProperty(sKey);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}finally {
			try {
				if(propFile != null)
					propFile.close();
			} catch (IOException e) {
				throw new ApplicationException(e);
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return sValue;
	}

	public static boolean isDsInfoEditable(EmMbrDsInfoVO dsiVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMCodeCache objCache = EEMCodeCache.getInstance();
		
		String desc = objCache.getListBoxDesc(dsiVO.getDsCd(),objCache.getLstUserDsCodes());
		if (desc == null){
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		logger.info(LoggerConstants.methodEndLevel());
		return true;
	}
	
}
