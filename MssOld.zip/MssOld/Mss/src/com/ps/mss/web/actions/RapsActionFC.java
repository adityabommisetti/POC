
/*
 * $Id: RapsActionFC.java,v 1.1 2014/06/26 07:56:38 praveen Exp $
 */
package com.ps.mss.web.actions;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.CodeCacheDao;
import com.ps.mss.model.RapsContext;
import com.ps.mss.model.RapsDetailItem;
import com.ps.mss.model.RapsDetailPage;
import com.ps.mss.model.RapsFilter;
import com.ps.mss.model.RapsClaimDetailItem;
import com.ps.mss.model.RapsClaimsDetailPage;
import com.ps.mss.model.RapsDetailInfo;
import com.ps.mss.model.RapsDiagnosisCode;
import com.ps.mss.model.RapsSource;
import com.ps.mss.model.RapsClaimDetailInfo;
import com.ps.mss.db.DbConnWeb;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.RapsConstants;
import com.ps.mss.framework.Constants;
import com.ps.mss.manager.ContextManager;
import com.ps.mss.manager.RapsManager;
import com.ps.mss.web.forms.RapsForm;
import com.ps.mss.web.helper.RapsActionDispatchHelper;
import com.ps.mss.helper.ServiceHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.web.helper.Utility;
import com.ps.util.DateUtil;
import com.ps.util.StringUtil;
import com.ps.mss.model.RapsClusterForm;
import java.text.SimpleDateFormat; //IFOX-00412304 - RAPS Entry Error
import java.util.Date;
/**
 * @author indrapradja.adriana
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class RapsActionFC extends Action {
	private static Logger logger=LoggerFactory.getLogger(RapsActionFC.class);

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		//logger.error("Inside execute");
		RapsForm rapsForm = (RapsForm) form;
		String method = rapsForm.getMethod();
		Connection conn = null; boolean anyError = false;
		try {
			
			// use the default DB for security check
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = new SessionHelper(request);
			String errorMsg = sessionHelper.validateUser(conn);
			if (errorMsg != null) {
				request.setAttribute("Msg",errorMsg);
				logger.info(LoggerConstants.methodEndLevel());
				return mapping.findForward("rapsError");
			}
			
			// now get the connection to the RAPS Db
			String dbId = sessionHelper.getRapsDatabaseName();
			conn = DbConnWeb.reGetConnection(conn,dbId);
			
			RapsContext rc = (RapsContext) ContextManager.getContext(request, RapsConstants.RAPS_CONTEXT);
			Utility.copyFromSessionToRequest(rc, request, sessionHelper);
			request.setAttribute(RapsConstants.RAPS_CONTEXT, rc);
			rc.setReuseList(false);
			/*The only time you can reuse :
			 * 1. going back to claim detail from "cluster detail"  
			 * 2. going back to raps detail from delete cluster, because customer clicks cancel  
			 * 3. Going back to raps detail from "claim detail" or "manual entry cluster"
			 * Everytime you reuse, it will just pull up the list from memory. 
			 */
			if ((RapsConstants.RAPS_CLAIMS_DETAILS.equals(method) && RapsConstants.RAPS_DETAIL_POP.equals(rapsForm.getPageName())) ||
				 ("cancelFromRapsDetail".equals(method) && RapsConstants.RAPS_DELETE.equals(rapsForm.getPageName())) ||			
				 (RapsConstants.RAPS_DETAIL.equals(method) && RapsConstants.RAPS_CLAIMS_DETAILS_POP.equals(rapsForm.getPageName())))			
				 rc.setReuseList(true);
			logger.info(LoggerConstants.methodEndLevel());
			if ("initRapsDashboard".equals(method)) //entry point for RAPS application
				return summaryDashBoard(conn, rc, mapping, form, request, false, true);
			else if (RapsConstants.RAPS_DASHBOARD.equals(method)) //RAPS summary tab is selected
				return summaryDashBoard(conn, rc, mapping, form, request, false, false);
			else if ("searchRapsDashboard".equals(method)) //GO button on RAPS summary dashboard
				return summaryDashBoard(conn, rc, mapping, form, request, true, false);		
			else if ("searchRapsDetail".equals(method)) //go button on RAPS summary detail
				return rapsDetailPage(conn, rc, mapping, form, request, true); 
			else if ("jumpToRapsDetail".equals(method)) // An item is selected on the RAPS dashboard page.
				return jumpToRapsDetail(conn, rc, mapping, form, request); 
			else if (RapsConstants.RAPS_DETAIL.equals(method) || "cancelFromRapsDetail".equals(method)) //RAPS summary detail tab is selected
								// or click "cancel" from delete RAPS screen, RAPS summary TAB
				return rapsDetailPage(conn, rc, mapping, form, request, false); // flag = false. Just repaint the screen, no new search.
			else if (RapsConstants.RAPS_DETAIL_POP.equals(method)) // print request from raps detail popup
				return rapsDetailPop(conn, rc, mapping, form, request);
			else if (RapsConstants.RAPS_CLAIMS_DASHBOARD.equals(method))
				return claimsDashBoard(conn, rc, mapping, form, request, false);
			else if ("searchRapsClaimsDashboard".equals(method)) //come here from "go" button
				return claimsDashBoard(conn, rc, mapping, form, request, true);		
			else if ("jumpToRapsClaimsDetail".equals(method)) //an item is selected from claim dashboard
				return jumpToRapsClaimsDetail(conn, rc, mapping, form, request);
			else if ("searchRapsClaimsDetail".equals(method)) //search mode from "GO" button
				return rapsClaimsDetail(conn, rc, mapping, form, request, true); 
			else if (RapsConstants.RAPS_CLAIMS_DETAILS.equals(method)) //claim detail tab is selected
				return rapsClaimsDetail(conn, rc, mapping, form, request, false);
			else if ("buildClaimDetail".equals(method)) { //a source is selected from raps detail
														  //or cancel delete raps detail on the claim sub tab
				return buildClaimDetail(conn, rc, mapping, form, request);
			}
			else if (RapsConstants.RAPS_CLAIMS_DETAILS_POP.equals(method)) //print request from claim detail
				return rapsClaimsDetailPop(conn, rc, mapping, form, request);
			else if (RapsConstants.RAPS_STATISTIC.equals(method)) //RAPS statistic tab is selected
				return rapsStatistic(conn, rc, mapping, form, request);
			else if ("validateInput".equals(method)) //validate button on RAPS input
				return validateRaps(conn, rc, mapping, form, request);
			else if ("createEntryInput".equals(method)) //Customer click "create entry" on RAPS input
				return addCluster(conn, rc, mapping, form, request);
			else if ("buildRapsDetail".equals(method)) //request is coming from Claim detail, to display raps detail popup
				return buildRapsDetail(conn, rc, mapping, form, request);
			else if ("initRapsErrors".equals(method)) //Customer clicks on "RAPS Errors" from the Raps Details page
				return rapsErrorsPage(conn, rc, mapping, form, request, true, true);
			else if (RapsConstants.RAPS_ERRORS.equals(method)) //RAPS Errors tab is selected
				return rapsErrorsPage(conn, rc, mapping, form, request, false, false);
			else if ("searchRapsErrors".equals(method)) //go button on RAPS Errors page
				return rapsErrorsPage(conn, rc, mapping, form, request, false, true);
			else
				return mapping.findForward("rapsError");							
		} catch (Exception e) {
        	anyError = true; 
        	request.setAttribute("Msg", e.getMessage());
        	logger.error(LoggerConstants.exceptionMessage(e.toString()));
        	//logger.error(e.getMessage());
        	logger.info(LoggerConstants.methodEndLevel());
        	return mapping.findForward("rapsError");
		}
		finally {
			if(conn != null){
				try {
					conn.close();
				} catch (SQLException e) {
		        	anyError = true;
				}
			}	
		}
    }

	
	/* ===========================================================================================================
	 * RAPS summary TAB
	 */
	
	/**
	 * The workhorse to build the summary dashboard page.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @param searchMode should be true whenever we need to change the search criteria.
	 * @param initialize Should be true if we're starting RAPS. 
	 * @return
	 * @throws Exception
	 */
	private ActionForward summaryDashBoard(Connection conn, RapsContext rc, ActionMapping mapping, ActionForm form, HttpServletRequest request, 
			          boolean searchMode, boolean initialize) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		RapsForm rapsForm = (RapsForm) form;
		RapsFilter filter = rc.getRapsDashboardFilter();
		SessionHelper sessionHelper = new SessionHelper(request);

		if (initialize) { //The only time this is true is when RAPS is selected from the main page.
			CodeCacheDao.getInstance().initializeRaps(conn);
			rc.init();
		    //TODO What is the criteria to get the list of plans for RAPS?
		    rc.setPlanNameList(sessionHelper.getPlanIdArray());
		}
		else 
			Utility.saveExpandedItems(rc, rapsForm.getUiContext(), rapsForm.getPageName());
		
		String errMsg = RapsActionDispatchHelper.copyFilterFromForm(sessionHelper, rc.getPlanNameList(), rapsForm, filter, searchMode);
        if (errMsg != null ) {
        	logger.debug("SummaryDashboard, copyFilterFromForm has an error " + errMsg);			
        	logger.info(LoggerConstants.methodEndLevel());
        	return mapping.findForward("rapsError");
        }

		List expandedList = rc.getDashBoardExpandedItems(); 
        rapsForm.setResultArray(RapsManager.getRapsDashBoard(conn, rc, filter, expandedList));
        logger.info(LoggerConstants.methodEndLevel());
        return buildForward(mapping, request, filter, RapsConstants.RAPS_DASHBOARD);
}	

	/**
	 * This method is called when:
	 * 		- An item is selected on the RAPS dashboard page. 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	private ActionForward jumpToRapsDetail(Connection conn, RapsContext rc, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		//Whenever coming from summary dashboard, reset hic #, duplicate , diag cd, resubmit
		RapsForm rapsForm = (RapsForm) form;
		rapsForm.setHicNbr(rc.getRapsDashboardFilter().getHicNbr()); //inherit filter from dashboard. 
		rapsForm.setClaimId(null); 
		
		//  when we are coming from Dashboard, we only have 'mm/yyyy' date, and Detail page needs 'mm/dd/yyyy' format.
		String fromDate = StringUtil.trimToNull(rapsForm.getFromDate());
		String toDate = StringUtil.trimToNull(rapsForm.getToDate());
		if(fromDate != null && fromDate.length() == 7){
			fromDate = DateUtil.getFirstOrLastDayOfMonth(fromDate, true);
			rapsForm.setFromDate(fromDate);
		}
				
		if(toDate != null && toDate.length() == 7) {
			toDate = DateUtil.getFirstOrLastDayOfMonth(toDate, false);
			rapsForm.setToDate(toDate);
		}
		logger.info(LoggerConstants.methodEndLevel());		
		return rapsDetailPage(conn, rc, mapping, form, request, true); //flag = true. Coming from dashboard, new search mode.
	}   
	
	/**
	 * This method is called when:
	 * 		- customer selects a diagnostic code row on Claim Details screen. On this event, we should
	 *        display the raps detail popup. 
	 *  	- Called from openRapsPopup() javascript.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	private ActionForward buildRapsDetail(Connection conn, RapsContext rc, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		RapsFilter filter = new RapsFilter();
		RapsForm rapsForm = (RapsForm) form;
		Utility.saveExpandedItems(rc, rapsForm.getUiContext(), rapsForm.getPageName());
		rc.setManualEntry(false); // it's always false, whenever coming from claim detail screen.
		//It's called from claim detail screen, so get the information from claim detail page if necessary.
		RapsClaimDetailInfo detailItem = rc.getLastClaimDetail();  //contains the last selected claim detail.
		String diagId = StringUtil.trimToNull(request.getParameter("id")); //the id of selected row of the diagnostic code
		if (diagId != null) 
			detailItem.setSelectedDiagCodeId(Integer.parseInt(diagId));
		RapsDetailItem rapsDetailItem = getClusterFromClaim(detailItem);
		rc.setRapsItemPopup(rapsDetailItem); 
		if (rapsDetailItem == null){
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward("rapsError");
		}

		RapsDetailPage detailPage = RapsManager.getRapsDetail(conn, rc, rapsDetailItem);
		rapsForm.setPageInfo(detailPage);
		rc.setLastRapsDetail(detailPage.getDetailInfo()); //save the last fetched raps detail.
		rapsForm.setPageName(RapsConstants.RAPS_DETAIL_POP);
		request.setAttribute("disableCSV","true");
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward("rapsDetail_Claim");
    }   


	private ActionForward rapsDetailPop(Connection conn, RapsContext rc, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		RapsForm rapsForm = (RapsForm) form;
		if(request.getParameter("print") !=  null) 
			Utility.saveExpandedItems(rc, rapsForm.getUiContext(), rapsForm.getPageName());			
		RapsDetailItem detailItem = rc.getRapsItemPopup(); //RapsService.getClusterFromClaim(rc.getLastClaimDetail());
		RapsDetailPage detailPage = RapsManager.getRapsDetail(conn, rc, detailItem);
		rapsForm.setPageInfo(detailPage);    
		logger.info(LoggerConstants.methodEndLevel());
		return buildForward(mapping, request, rc.getClaimsDetailFilter(), RapsConstants.RAPS_DETAIL_POP);
	}  		
	
	private ActionForward rapsDetailPage(Connection conn, RapsContext rc, ActionMapping mapping, ActionForm form, HttpServletRequest request, boolean searchMode) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		RapsForm rapsForm = (RapsForm) form;
	    RapsFilter filter = null; 
		//If request is to print for "all" items, do not save expandable list.
    	String uiContextRange = StringUtil.nonNullTrim(request.getParameter("uiContextRange"));
		request.setAttribute("uiContextRange", uiContextRange); //trimmed version
		if(!Constants.CONSTANTS_ALL.equals(uiContextRange))
			Utility.saveExpandedItems(rc, rapsForm.getUiContext(), rapsForm.getPageName());

		RapsActionDispatchHelper.getRapsDetailPage(conn, request,rapsForm, rc, searchMode);
		
		rc.setDisplayRapsDetail(true) ; 	//this attribute is set to show Raps Detail tab once user has visite this.
											//It's accessed by rapsDashBoard.jsp
		rc.setDisplayRapsErrors(true) ;		//this attribute is set to show Raps Errors tab
		logger.info(LoggerConstants.methodEndLevel());
		return buildForward(mapping, request, rc.getRapsDetailFilter(), RapsConstants.RAPS_DETAIL);
	} 
	
	/* ===========================================================================================================
	 * Claims summary TAB
	 */


	private ActionForward claimsDashBoard(Connection conn, RapsContext rc, ActionMapping mapping, ActionForm form, HttpServletRequest request, 
	          boolean searchMode) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		RapsForm rapsForm = (RapsForm) form;
		Utility.saveExpandedItems(rc, rapsForm.getUiContext(), rapsForm.getPageName());
		
	    RapsFilter filter = null; 
		filter = rc.getClaimsDashboardFilter();
		SessionHelper sessionHelper = new SessionHelper(request);
		String errMsg = RapsActionDispatchHelper.copyFilterFromForm(sessionHelper, rc.getPlanNameList(), rapsForm, filter, searchMode);
		if (errMsg != null) {
			logger.debug("claimsDashboard: copyFilterFromForm has error " + errMsg);
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward("rapsError");	
		}
	    List expandedItems = rc.getClaimsDashboardExpandedItems();
	    rapsForm.setResultArray(RapsManager.getRapsClaimsDashBoard(conn, rc, filter, expandedItems));
	    logger.info(LoggerConstants.methodEndLevel());
	    return buildForward(mapping, request, filter, RapsConstants.RAPS_CLAIMS_DASHBOARD);
 	}	

	
	/**
	 * This method is called when:
	 * 		- An item is selected on the claims summary dashboard page.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	private ActionForward jumpToRapsClaimsDetail(Connection conn, RapsContext rc, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		//Whenever coming from summary dashboard, reset hic #, duplicate , diag cd, resubmit
		RapsForm rapsForm = (RapsForm) form;
		rapsForm.setHicNbr(rc.getClaimsDashboardFilter().getHicNbr()); //inherit hic number from dashboard
		rapsForm.setClaimId(null);
		
		//  when we are coming from Dashboard, we only have 'mm/yyyy' date, and claim Detail needs 'mm/dd/yyyy' format.
		String fromDate = StringUtil.trimToNull(rapsForm.getFromDate());
		String toDate = StringUtil.trimToNull(rapsForm.getToDate());
		if(fromDate != null && fromDate.length() == 7){
			fromDate = DateUtil.getFirstOrLastDayOfMonth(fromDate, true);
			rapsForm.setFromDate(fromDate);
		}
				
		if(toDate != null && toDate.length() == 7) {
			toDate = DateUtil.getFirstOrLastDayOfMonth(toDate, false);
			rapsForm.setToDate(toDate);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return rapsClaimsDetail(conn, rc, mapping, form, request, true); 
	}   
	
	/**
	 * This method is called when:
	 * 		- customer selects a source row on RAPS Details screen. On this event, we should
	 *        display the claim detail. 
	 *  	- Called from gotoDetail() javascript.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	private ActionForward buildClaimDetail(Connection conn, RapsContext rc, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		RapsForm rapsForm = (RapsForm) form; 
		Utility.saveExpandedItems(rc, rapsForm.getUiContext(), rapsForm.getPageName());

		//It's called from raps detail screen, so get the information from raps detail page if necessary.
		RapsDetailInfo detailItem = rc.getLastRapsDetail();  //contains the last selected RAPS detail.
		int sourceId = -1;
		String temp = StringUtil.trimToNull(request.getParameter("id")); //the id of selected row of the diagnostic code
		if (temp != null) {
			sourceId = Integer.parseInt(temp);
			detailItem.setSelectedDiagID(sourceId);
		}
		else 
			sourceId = detailItem.getSelectedDiagID();
		if (sourceId < 0){
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward("rapsError");
		}
		//find the source
		RapsSource[] sources = detailItem.getSources();
		if (sources == null){
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward("rapsError");
		}
		RapsSource source = null;
		for (int i = 0; i <sources.length ; i++) {
			source = sources[i];
			if (source.getId() == sourceId) 
				break;
		}
		if (source == null){
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward("rapsError");
		}
		
		rapsForm.setPageName(RapsConstants.RAPS_CLAIMS_DETAILS_POP); 
		request.setAttribute("disableCSV","true");
		//see whether it's manual entry
		if (RapsConstants.MANUAL_ENTRY.equalsIgnoreCase(source.getType())) {
			RapsDetailItem item = new RapsDetailItem();
			item.setDcType(detailItem.getDcType());
			item.setPlanID(detailItem.getPlanId());
			item.setHicNbr(detailItem.getHicNbr());
			item.setProviderType(detailItem.getProviderType());
			item.setDiagCode(detailItem.getDiagCode());
			item.setFromServiceDate(detailItem.getFromServiceDate());
			item.setThruServiceDate(detailItem.getThruServiceDate());
			rc.setRapsItemPopup(item);
			RapsDetailPage detailPage = RapsManager.getRapsDetail(conn, rc, item);
			rapsForm.setPageInfo(detailPage);
			rc.setManualEntry(true);
			rc.setDeleteInd(source.getDeleteInd());
			String comment =  RapsManager.getComment(conn, item, source.getId());

			rc.setClusterComment(comment);
			request.setAttribute("pageNo", RapsConstants.PNO_RAPS_DETAIL);
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward("rapsDetail_Raps");
		}
		else {
			RapsClaimDetailItem claimDetailItem = new RapsClaimDetailItem();
			claimDetailItem.setMfId(source.getMfId());
			claimDetailItem.setSyntheticFileId(source.getSyntheticFileId());
			claimDetailItem.setPhysicalRecNbr(source.getPhysicalRecNbr());
			claimDetailItem.setPlanId(detailItem.getPlanId());	
			rc.setClaimItemPopup(claimDetailItem);
	        RapsClaimsDetailPage detailPage = RapsManager.getRapsClaimDetail (conn, rc, claimDetailItem, true);
			rapsForm.setPageInfo(detailPage);
			request.setAttribute("pageNo", RapsConstants.PNO_CLAIM_DETAIL);
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward("claimDetail_Raps");
		}
	}  	

	
	/**
	 * This method is called when:
	 * 		- print button is clicked on the claim detail screen
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	private ActionForward rapsClaimsDetailPop(Connection conn, RapsContext rc, ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		RapsForm rapsForm = (RapsForm) form;
		if(request.getParameter("print") !=  null) 
			Utility.saveExpandedItems(rc, rapsForm.getUiContext(), rapsForm.getPageName());			
		RapsClaimDetailItem claimDetailItem = rc.getClaimItemPopup();
		if (claimDetailItem == null)
			throw new ApplicationException("fail building claimDetailItem");
		RapsClaimsDetailPage detailPage = RapsManager.getRapsClaimDetail (conn, rc, claimDetailItem, true);
		rapsForm.setPageInfo(detailPage);    
		logger.info(LoggerConstants.methodEndLevel());
		return buildForward(mapping, request, rc.getRapsDetailFilter(), RapsConstants.RAPS_CLAIMS_DETAILS_POP);
	}  		
	
	private ActionForward rapsClaimsDetail(Connection conn, RapsContext rc, ActionMapping mapping, ActionForm form, HttpServletRequest request, boolean searchMode) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		RapsForm rapsForm = (RapsForm) form;
		
	    RapsFilter filter = null; 
    	String uiContextRange = StringUtil.nonNullTrim(request.getParameter("uiContextRange"));
		request.setAttribute("uiContextRange", uiContextRange); 
		if(!Constants.CONSTANTS_ALL.equals(uiContextRange))
			Utility.saveExpandedItems(rc, rapsForm.getUiContext(), rapsForm.getPageName());
		
		RapsActionDispatchHelper.getClaimsDetail(conn, request,rapsForm, rc, searchMode);
		
		rc.setDisplayClaimsDetail(true) ; 	//this attribute is set to show Raps Detail tab once user has visite this.
											//It's accessed by rapsClaimsDashBoard.jsp
		logger.info(LoggerConstants.methodEndLevel());
		return buildForward(mapping, request, rc.getClaimsDetailFilter(), RapsConstants.RAPS_CLAIMS_DETAILS);
	} 	


	private ActionForward rapsStatistic(Connection conn, RapsContext rc, ActionMapping mapping, ActionForm form, HttpServletRequest request) 
		throws Exception {
		logger.info(LoggerConstants.methodStartLevel()); 
		RapsForm rapsForm = (RapsForm) form;
		Utility.saveExpandedItems(rc, rapsForm.getUiContext(), rapsForm.getPageName());
		
		List expandedList = rc.getStatisticExpandedItems();
        rapsForm.setResultArray(RapsManager.getStatistics(conn, rc, expandedList));	
        logger.info(LoggerConstants.methodEndLevel());
        return buildForward(mapping, request, null, RapsConstants.RAPS_STATISTIC);
	}	

	private ActionForward validateRaps(Connection conn, RapsContext rc, ActionMapping mapping, ActionForm form, HttpServletRequest request) 
		throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		RapsForm rapsForm = (RapsForm) form;
		String pageName = rapsForm.getPageName();
		RapsClusterForm entry = rc.getRapsEntry();
		RapsDetailInfo detail = new RapsDetailInfo(); 
		rc.setRapsDetailEntry(detail);
		
		//copy info from form to session
		entry.setPlanId(StringUtil.trimToNull(rapsForm.getPlanId()));
		entry.setHicNbr(StringUtil.trimToNull(rapsForm.getHicNbr()));
		entry.setMbi(StringUtil.trimToNull(rapsForm.getMbi()));
		entry.setFromDate(StringUtil.trimToNull(rapsForm.getFromDate()));
		entry.setToDate(StringUtil.trimToNull(rapsForm.getToDate()));
		entry.setDiagCd(StringUtil.trimToNull(rapsForm.getDiagCd()));
		entry.setComments(StringUtil.trimToNull(rapsForm.getComments()));
		entry.setPatientControlNo(StringUtil.trimToNull(rapsForm.getPatientControlNo()));
		entry.setProviderType(StringUtil.trimToNull(rapsForm.getProviderType()));
		entry.setActDel(StringUtil.trimToNull(rapsForm.getActDel()));
		SessionHelper sessionHelper = new SessionHelper(request);
		entry.setUserId(sessionHelper.getUserId());
		
		detail.setPlanId(entry.getPlanId());
		detail.setPlanName(rc.getPlanName(detail.getPlanId()));
		detail.setHicNbr(entry.getHicNbr());
		//IFOX-00412304 - RAPS Entry Error - Start
				Date fromDt = new SimpleDateFormat("MM/dd/yyyy").parse(rapsForm.getFromDate()); 
					if(fromDt.compareTo(new SimpleDateFormat("MM/dd/yyyy").parse("10/01/2015"))>=0) {
							detail.setDcType(RapsConstants.ICD_10);
					}else {
						detail.setDcType(RapsConstants.ICD_09);
					}
				
//				detail.setDcType(RapsConstants.ICD_09);
				//IFOX-00412304 - RAPS Entry Error - End
		detail.setMbi(entry.getMbi());
		
//		detail.setDcType(RapsConstants.ICD_09);
		//IFOX-00412304 - RAPS Entry Error - End
		detail.setDiagCode(entry.getDiagCd());
		detail.setFromServiceDate(entry.getFromDate());
		detail.setThruServiceDate(entry.getToDate());
		detail.setProviderType(entry.getProviderType());
		detail.setProviderDescr(CodeCacheDao.getInstance().getDescription(Constants.MAP_SHORT_PROVIDER_TYPE, entry.getProviderType()));
		detail.setPatientControlNo(entry.getPatientControlNo());
		detail.setSubmissionType(RapsConstants.MANUAL_ENTRY);
		//Note: submissionDate is set inside RapsManager
		
		StringBuffer errorMsg = new StringBuffer("");
		boolean result = RapsManager.validateCluster(conn, rc, errorMsg);
		if (result) {
			entry.setDetailExpanded(true);
			entry.setStatus(RapsConstants.STATUS_VALIDATED);
		}
		else {
			entry.setDetailExpanded(false);
			request.setAttribute("ERROR_MSG", errorMsg);
			entry.setStatus(RapsConstants.STATUS_ERROR);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return buildForward(mapping, request, null, pageName); 
	}	
	
	private ActionForward addCluster(Connection conn, RapsContext rc, ActionMapping mapping, ActionForm form, HttpServletRequest request) 
	throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		RapsForm rapsForm = (RapsForm) form;
		String pageName = rapsForm.getPageName();
		RapsClusterForm entry = rc.getRapsEntry();
		if (entry.getStatus()== RapsConstants.STATUS_VALIDATED) { //check in case page is resubmitted after record is added/updated
			StringBuffer errorMsg = new StringBuffer("");
			boolean result = RapsManager.addCluster(conn, rc, errorMsg);
			if (result) {
				entry.reset();
				entry.setStatus(RapsConstants.STATUS_ADDED); //mark it as added, to prevent F5.
				entry.setDetailExpanded(false);
				request.setAttribute("ERROR_MSG", "You have successfully add the entry");
			}
			else {
				if (StringUtil.trimToNull(errorMsg.toString()) == null)
					errorMsg.append("createEntry Encounter an error");
				request.setAttribute("ERROR_MSG", errorMsg);
				entry.setStatus(RapsConstants.STATUS_ERROR);
				entry.setDetailExpanded(false);  //whenever there's an error, do not display the detail information
			}
		}		
		logger.info(LoggerConstants.methodEndLevel());
		return buildForward(mapping, request, null, pageName); 
	}	
	
	private ActionForward rapsErrorsPage(Connection conn, RapsContext rc, ActionMapping mapping, ActionForm form, HttpServletRequest request, boolean initialize, boolean searchMode) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		RapsForm rapsForm = (RapsForm) form;
	    RapsFilter filter = null; 
		//If request is to print for "all" items, do not save expandable list.
    	String uiContextRange = StringUtil.nonNullTrim(request.getParameter("uiContextRange"));
		request.setAttribute("uiContextRange", uiContextRange); //trimmed version
		if(!Constants.CONSTANTS_ALL.equals(uiContextRange))
			Utility.saveExpandedItems(rc, rapsForm.getUiContext(), rapsForm.getPageName());

		RapsActionDispatchHelper.getRapsErrorsPage(conn, request,rapsForm, rc, initialize, searchMode);
		
		rc.setDisplayRapsErrors(true) ; 	//this attribute is set to show Raps Errors tab once user has visited this.
											//It's accessed by rapsDashBoard.jsp
		logger.info(LoggerConstants.methodEndLevel());
		return buildForward(mapping, request, rc.getRapsErrorsFilter(), RapsConstants.RAPS_ERRORS);
	}
	
	private ActionForward buildForward(ActionMapping mapping, HttpServletRequest request, RapsFilter filter, String forwardName) {
		if(request.getParameter("print") !=  null) {
			StringBuffer s = ServiceHelper.getPrintCriteriaHeader(filter, forwardName);
			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, s.toString());
			forwardName = "print".concat(forwardName);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(forwardName);		
	}
	
	/*
	private static RapsClaimDetailItem getClaimFromCluster(RapsDetailInfo detailItem) {
		RapsClaimDetailItem claimDetailItem = null;
		RapsSource[] sources = detailItem.getSources();
		if (sources != null) {
			int sourceId = detailItem.getSelectedDiagID();
			for (int i = 0; i <sources.length ; i++) {
				RapsSource source = sources[i];
				if (source.getId() == sourceId) {
					claimDetailItem = new RapsClaimDetailItem();
					claimDetailItem.setMfId(source.getMfId());
					claimDetailItem.setSyntheticFileId(source.getSyntheticFileId());
					claimDetailItem.setAaaHSeqNbr(source.getAaaHSeqNbr());
					claimDetailItem.setFileId(source.getFileId());
					claimDetailItem.setBbbDSeqNbr(source.getBbbDSeqNbr());
					claimDetailItem.setPhysicalRecNbr(source.getPhysicalRecNbr());
					claimDetailItem.setPlanId(detailItem.getPlanId());
					break;
				}
			}
		}
		return claimDetailItem;
	}
	*/
	private static RapsDetailItem getClusterFromClaim(RapsClaimDetailInfo detailItem) {
		logger.info(LoggerConstants.methodStartLevel());
		RapsDetailItem detail = null;
		RapsDiagnosisCode[] diagCodes = detailItem.getDiagCodes();
		if (diagCodes != null) {
			int diagId = detailItem.getSelectedDiagCodeId();
			for (int i=0; i < diagCodes.length; i++) {
				RapsDiagnosisCode diagCode = diagCodes[i];
				if (diagCode.getId() == diagId) {
					detail = new RapsDetailItem();
					detail.setPlanID(detailItem.getPlanId());
					detail.setHicNbr(detailItem.getHicNbr());
					detail.setProviderType(diagCode.getProviderType());
					detail.setDcType(diagCode.getDcType());
					detail.setDiagCode(diagCode.getDiagCode());
					detail.setFromServiceDate(diagCode.getServiceFrom());
					detail.setThruServiceDate(diagCode.getServiceThru());
					break;
				}
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return detail;
	}
	
	/**WORKFLOW management****************************************************/
	/**
	 * This method is called whenever a Detail tab is selected.
	 * TAB	 : WORKFLOW MANAGEMENT
	 * SUBTAB: Workflow management
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
		private ActionForward rapsWorkflow(ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
			return rapsWorkflow(mapping, form, request, false);
		}    
	 */

	/**
	 * This method is called when:
	 * 		- GO button is selected on the workflow management screen.
	 * TAB	 : WORKFLOW MANAGEMENT
	 * SUBTAB: Workflow management
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
		private ActionForward searchRapsWorkflow(ActionMapping mapping, ActionForm form, HttpServletRequest request) throws Exception {
			return rapsWorkflow(mapping, form, request, true); //search mode from "GO" button
		}   

	private ActionForward rapsWorkflow(ActionMapping mapping, ActionForm form, HttpServletRequest request, boolean searchMode) throws Exception {
		RapsForm rapsForm = (RapsForm) form;
		RapsContext rc = null;
	    RapsFilter filter = null; Connection conn = null; boolean anyError = false;
		try {
			SessionHelper sessionHelper = new SessionHelper(request);
			String dbId = sessionHelper.getRapsDatabaseName();
			if(StringUtil.isNullOrEmpty(dbId))
				conn = DbConnWeb.getConnection();
			else
				conn = DbConnWeb.getConnection(dbId);
			String errorMsg = sessionHelper.validateUser();
			if (errorMsg != null) {
				request.setAttribute("Msg",errorMsg);
				return mapping.findForward("rapsError");
			}		//If request is to pring for "all" items, do not save expandable list.		//If request is to pring for "all" items, do not save expandable list.
			rc = (RapsContext) ContextManager.getContext(request, RapsConstants.RAPS_CONTEXT);
			Utility.saveExpandedItems(rc, rapsForm.getUiContext(), rapsForm.getPageName());
			
			//  when we are coming from Dashboard, we only have 'mm/yyyy' date, and Event Detail needs 'mm/dd/yyyy' format.
			String fromDate = StringUtil.trimToNull(rapsForm.getFromDate());
			String toDate = StringUtil.trimToNull(rapsForm.getToDate());
			if(fromDate != null && fromDate.length() == 7){
				fromDate = DateUtil.getFirstOrLastDayOfMonth(fromDate, true);
				rapsForm.setFromDate(fromDate);
			}
					
			if(toDate != null && toDate.length() == 7) {
				toDate = DateUtil.getFirstOrLastDayOfMonth(toDate, false);
				rapsForm.setToDate(toDate);
			}
					
			RapsActionDispatchHelper.getWorkflow(conn, request,rapsForm, rc, searchMode);
		} catch (Exception e) {
			anyError = true;
			logger.error("summaryDashBoard encounters exception " + e.getMessage());
		}
		finally {
			if(conn != null){
				try {
					conn.close();
				} catch (SQLException e) {
					anyError = true;
				}
			}	
		}
		if (anyError)
			return mapping.findForward("rapsError");		
	    return buildForward(mapping, request, rc.getWorkflowFilter(), RapsConstants.RAPS_WORKFLOW);
	} 
	*/




}
