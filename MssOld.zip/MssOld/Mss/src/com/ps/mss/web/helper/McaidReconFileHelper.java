
package com.ps.mss.web.helper;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.web.forms.McaidReconFileForm;

public class McaidReconFileHelper {
	private static Logger logger=LoggerFactory.getLogger(McaidReconFileHelper.class);
	public static void saveFileForm(SessionHelper sessionHelper, McaidReconFileForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		sessionHelper.setAttribute("SavefileForm",form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	public static McaidReconFileForm getFileForm(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (McaidReconFileForm)sessionHelper.getAttribute("SavefileForm");
	}
	
}//MCReconDiscHelper
