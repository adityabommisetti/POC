/*
 * $Id: EEMForm.java,v 1.1 2014/06/26 07:55:45 praveen Exp $
 */
package com.ps.mss.web.forms;

import java.util.List;

import org.apache.struts.action.ActionForm;

/**
 * @author nenne.robert
 */
public class EEMForm extends ActionForm {

    /* Main form fields */
	private String method;
    private String menu;
    
    private String message;
    private String focusField;
    
    // List of EEMErrorVO object
    private List lstErrors;
    
    
	/**
	 * @return Returns the message.
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message The message to set.
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @return Returns the menu.
	 */
	public String getMenu() {
		return menu;
	}
	/**
	 * @param menu The menu to set.
	 */
	public void setMenu(String menu) {
		this.menu = menu;
	}
	/**
	 * @return Returns the method.
	 */
	public String getMethod() {
		return method;
	}
	/**
	 * @param method The method to set.
	 */
	public void setMethod(String method) {
		this.method = method;
	}
	public String getFocusField() {
		return focusField;
	}
	public void setFocusField(String focusField) {
		this.focusField = focusField;
	}
	/**
	 * @return Returns the lstErrors.
	 */
	public List getLstErrors() {
		return lstErrors;
	}
	/**
	 * @param lstErrors The lstErrors to set.
	 */
	public void setLstErrors(List lstErrors) {
		this.lstErrors = lstErrors;
	}
}
