
package com.ps.mss.web.helper;


import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.model.McaidPaymentDashBoardVO;
import com.ps.mss.model.McaidReconContext;
import com.ps.mss.web.forms.McaidReconPaymentForm;

public class McaidReconPaymentHelper {
	private static Logger logger=LoggerFactory.getLogger(McaidReconPaymentHelper.class);
	public static void savePaymentForm(SessionHelper sessionHelper, McaidReconPaymentForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		sessionHelper.setAttribute("SavePaymentForm",form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	public static McaidReconPaymentForm getPaymentForm(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (McaidReconPaymentForm)sessionHelper.getAttribute("SavePaymentForm");
	}
	
	
	public static void setDsbLatestPbpVosToForm(McaidReconContext context, McaidReconPaymentForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		form.setMcaidPymntDsbPBPLst(context.getPaymentVO().getMcaidPymntDsbPBPLst());
		logger.info(LoggerConstants.methodEndLevel());
	}
	

	
}//class
