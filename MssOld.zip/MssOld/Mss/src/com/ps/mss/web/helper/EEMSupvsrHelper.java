/*
 * $Id: EEMSupvsrHelper.java,v 1.1 2014/06/26 07:55:02 praveen Exp $
 */
package com.ps.mss.web.helper;

import java.io.FileInputStream;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Properties;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.db.EEMCodeCache;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.model.EEMSupvsrVO;
import com.ps.mss.web.forms.EEMSupvsrForm;

/**
 * @author Raghu Gorur
 *
 */
public class EEMSupvsrHelper {
	private static Logger logger = LoggerFactory.getLogger(EEMSupvsrHelper.class);
	private static Properties prop;

	public static void saveEEMForm(SessionHelper sessionHelper, EEMSupvsrForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		sessionHelper.setAttribute("SaveEEMSupvsrForm",form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	public static EEMSupvsrForm getEEMForm(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (EEMSupvsrForm)sessionHelper.getAttribute("SaveEEMSupvsrForm");
	}
	
	public static String getProperty(String sKey) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String sValue = null;
		try {
			if (prop == null) {
				prop = new Properties();
				prop.load(new FileInputStream("EEMProperties.properties"));
			}

			sValue = prop.getProperty(sKey);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return sValue;
	}
	
	public static void setFormToVO(EEMSupvsrForm eemSupvsrForm,
			EEMSupvsrVO filterVO, SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try{	
			BeanUtils.copyProperties(filterVO, eemSupvsrForm);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void setVOToForm(EEMSupvsrVO filterVO,
			EEMSupvsrForm eemSupvsrForm, SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try{	
			BeanUtils.copyProperties(eemSupvsrForm, filterVO);
			//setApplFormList(eemFormAppl, sessionHelper);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void setSupvsrFormList(EEMSupvsrForm eemSupvsrForm,
			SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMCodeCache objCache = EEMCodeCache.getInstance();
		eemSupvsrForm.setLstApplStatus(objCache.getLstApplStatus());
		eemSupvsrForm.setLstApplType(objCache.getLstApplType());
		eemSupvsrForm.setLstEsrd(objCache.getArrYesNo());
		eemSupvsrForm.setLstApprovalStatus(objCache.getLstApprovalStatus());
		
		eemSupvsrForm.setCustomerId(sessionHelper.getMfId());
		eemSupvsrForm.setCustomerNbr(sessionHelper.getCustomerNumber());
		eemSupvsrForm.setOperId(sessionHelper.getUserId());
		
		// Set Search list
		eemSupvsrForm.setLstSearch((List)sessionHelper.getSession().getAttribute(
								EEMConstants.SESSION_SUPVSR_SEARCH));
		
		// Convert all the fields in to Upper Case
		convertToUpper(eemSupvsrForm);
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void convertToUpper(EEMSupvsrForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Get the Form class
			Class objClass = Class.forName(EEMConstants.EEM_SUPVSRFORM_CLASS);

			// Loop through all the fields
			Field[] arrField = objClass.getDeclaredFields();
			for (int i = 0; i < arrField.length; i++) {
				Field field = arrField[i];
				field.setAccessible(true);
				
				// Check for fields of String type
				if (field.getType().toString().equals("class java.lang.String")) {
					Object val = field.get(form);
					if (val != null) {
						// Set the variable
						field.set(form, val.toString().toUpperCase());
					}
				}
			}

		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void cancelSearch(EEMSupvsrForm eemSupvsrForm,
			SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		eemSupvsrForm.setSearchApplRcvdDt("");
		eemSupvsrForm.setSearchApplStatus("");
		eemSupvsrForm.setSearchApplType("");
		eemSupvsrForm.setSearchEffDt("");
		eemSupvsrForm.setSearchEsrd("");
		eemSupvsrForm.setSearchOperId("");
		eemSupvsrForm.setLstSearch(null);
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_SUPVSR_SEARCH, null);
		logger.info(LoggerConstants.methodEndLevel());
	}
}
