/*
 * Created on Sep 26, 2011
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ps.mss.web.helper;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EEMDshBrdService;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.EEMDshBrdDrillVO;
import com.ps.mss.model.EEMDshBrdVO;
import com.ps.mss.web.forms.EEMDshBrdForm;
import com.ps.util.StringUtil;

/**
 * @author Raghu Gorur
 *
 */
public class EEMDshBrdHelper {
	
	private static Properties prop;
	private static Logger logger = LoggerFactory.getLogger(EEMDshBrdHelper.class);
	public static String getProperty(String sKey) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String sValue = null;
		try {
			if (prop == null) {
				prop = new Properties();
				prop.load(new FileInputStream("EEMProperties.properties"));
			}

			sValue = prop.getProperty(sKey);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return sValue;
	}
	
	public static void saveEEMForm(SessionHelper sessionHelper, EEMDshBrdForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		sessionHelper.setAttribute("SaveEEMDshBrdForm",form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	public static EEMDshBrdForm getEEMForm(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (EEMDshBrdForm)sessionHelper.getAttribute("SaveEEMDshBrdForm");
	}

	public static void saveDrillDown(SessionHelper sessionHelper, List lstDrill) {
		logger.info(LoggerConstants.methodStartLevel());
		sessionHelper.setAttribute("SaveApplDshBrdDrill",lstDrill);
		logger.info(LoggerConstants.methodEndLevel());
	}
	public static List getDrillDown(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (List)sessionHelper.getAttribute("SaveApplDshBrdDrill");
	}

	public static void setFormToVO(EEMDshBrdForm eemDshBrdForm,
			EEMDshBrdVO filterVO, SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try{	
			BeanUtils.copyProperties(filterVO, eemDshBrdForm);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void setVOToForm(EEMDshBrdVO filterVO,
			EEMDshBrdForm eemDshBrdForm, SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try{	
			BeanUtils.copyProperties(eemDshBrdForm, filterVO);
		
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void setDshBrdFormList(EEMDshBrdForm eemDshBrdForm,
			SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		eemDshBrdForm.setCustomerId(sessionHelper.getMfId());
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void getDashBoardList(EEMDshBrdForm eemDshBrdForm,
			SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMDshBrdVO filterVO = new EEMDshBrdVO();
		setFormToVO(eemDshBrdForm, filterVO, sessionHelper);
		
		EEMDshBrdService service = new EEMDshBrdService();
		eemDshBrdForm.setLstDashBoard(service.getDashBoardList(filterVO));
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void getWorkLoadList(EEMDshBrdForm eemDshBrdForm,
			SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMDshBrdVO filterVO = new EEMDshBrdVO();
		setFormToVO(eemDshBrdForm, filterVO, sessionHelper);
		
		EEMDshBrdService service = new EEMDshBrdService();
		eemDshBrdForm.setLstDshBrdWrkld(service.getDshBrdWrkldList(filterVO));
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void getDrillDownList(EEMDshBrdForm eemDshBrdForm,
			SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		List lstTemp = new ArrayList();
		EEMDshBrdDrillVO objVO = null;
		
		if (StringUtil.nonNullTrim(eemDshBrdForm.getUser()).equals("HCHENG")) {
			objVO = new EEMDshBrdDrillVO();
			objVO.setApplId("83");
			objVO.setHicNbr("999000306D");
			objVO.setLastName("TESTARNES");
			objVO.setFirstName("FAYRENE");
			objVO.setApplStatus("INCRFIREQ");
			objVO.setApplDate("09/22/2011");
			objVO.setCreateDate("09/22/2011 ");
			objVO.setDueDate("10/13/2011");
			objVO.setCurrOper("HCHENG");
			objVO.setAssignTo("CHARLIE");
			lstTemp.add(objVO);
			
			objVO = new EEMDshBrdDrillVO();
			objVO.setApplId("88");
			objVO.setHicNbr("999901926A");
			objVO.setLastName("TESTNA");
			objVO.setFirstName("MARIA");
			objVO.setApplStatus("INCRFIREQ");
			objVO.setApplDate("09/22/2011");
			objVO.setCreateDate("09/23/2011 ");
			objVO.setDueDate("10/14/2011");
			objVO.setCurrOper("HCHENG");
			objVO.setAssignTo("CHARLIE");
			lstTemp.add(objVO);
		} else if (StringUtil.nonNullTrim(eemDshBrdForm.getUser()).equals("RNENNE")) {
			objVO = new EEMDshBrdDrillVO();
			objVO.setApplId("92");
			objVO.setHicNbr("111111111");
			objVO.setLastName("JONES");
			objVO.setFirstName("");
			objVO.setApplStatus("INCRFIREQ");
			objVO.setApplDate("09/15/2011");
			objVO.setCreateDate("09/23/2011 ");
			objVO.setDueDate("10/14/2011");
			objVO.setCurrOper("RNENNE");
			objVO.setAssignTo("TRAM");
			lstTemp.add(objVO);
		} else if (StringUtil.nonNullTrim(eemDshBrdForm.getUser()).equals("JMANCINI")) {
			objVO = new EEMDshBrdDrillVO();
			objVO.setApplId("87");
			objVO.setHicNbr("999000346A");
			objVO.setLastName("TESTLARKSONN");
			objVO.setFirstName("HELEODORA");
			objVO.setApplStatus("INCRFIREQ");
			objVO.setApplDate("09/21/2011");
			objVO.setCreateDate("09/22/2011 ");
			objVO.setDueDate("10/13/2011");
			objVO.setCurrOper("JMANCINI");
			objVO.setAssignTo("TRAM");
			lstTemp.add(objVO);
		} else {
			objVO = new EEMDshBrdDrillVO();
			objVO.setApplId("83");
			objVO.setHicNbr("999000306D");
			objVO.setLastName("TESTARNES");
			objVO.setFirstName("FAYRENE");
			objVO.setApplStatus("INCRFIREQ");
			objVO.setApplDate("09/22/2011");
			objVO.setCreateDate("09/22/2011 ");
			objVO.setDueDate("10/13/2011");
			objVO.setCurrOper("HCHENG");
			objVO.setAssignTo("CHARLIE");
			lstTemp.add(objVO);

			objVO = new EEMDshBrdDrillVO();
			objVO.setApplId("87");
			objVO.setHicNbr("999000346A");
			objVO.setLastName("TESTLARKSONN");
			objVO.setFirstName("HELEODORA");
			objVO.setApplStatus("INCRFIREQ");
			objVO.setApplDate("09/21/2011");
			objVO.setCreateDate("09/22/2011 ");
			objVO.setDueDate("10/13/2011");
			objVO.setCurrOper("JMANCINI");
			objVO.setAssignTo("TRAM");
			lstTemp.add(objVO);
			
			objVO = new EEMDshBrdDrillVO();
			objVO.setApplId("92");
			objVO.setHicNbr("111111111");
			objVO.setLastName("JONES");
			objVO.setFirstName("");
			objVO.setApplStatus("INCRFIREQ");
			objVO.setApplDate("09/15/2011");
			objVO.setCreateDate("09/23/2011 ");
			objVO.setDueDate("10/14/2011");
			objVO.setCurrOper("RNENNE");
			objVO.setAssignTo("TRAM");
			lstTemp.add(objVO);

			objVO = new EEMDshBrdDrillVO();
			objVO.setApplId("88");
			objVO.setHicNbr("999901926A");
			objVO.setLastName("TESTNA");
			objVO.setFirstName("MARIA");
			objVO.setApplStatus("INCRFIREQ");
			objVO.setApplDate("09/22/2011");
			objVO.setCreateDate("09/23/2011 ");
			objVO.setDueDate("10/14/2011");
			objVO.setCurrOper("HCHENG");
			objVO.setAssignTo("CHARLIE");
			lstTemp.add(objVO);
		}

		eemDshBrdForm.setLstDshBrdDrill(lstTemp);
		saveDrillDown(sessionHelper, lstTemp);
		logger.info(LoggerConstants.methodEndLevel());
	}
}
