package com.ps.mss.web.actions;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.mss.framework.Constants;
import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EEMTimersService;
import com.ps.mss.dao.model.EMTimersSearchVO;
import com.ps.mss.dao.model.EMTimersVO;
import com.ps.mss.db.DbConn;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.manager.EEMManager;
import com.ps.mss.model.EEMContext;
import com.ps.mss.model.Pagination;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.forms.EEMForm;
import com.ps.mss.web.forms.EEMTimersForm;
import com.ps.mss.web.helper.EEMTimersHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.web.util.EEMSwitchUtil;

public class EEMTimersAction extends Action {
	private static Logger logger = LoggerFactory.getLogger(EEMTimersAction.class);
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		try {
			EEMForm eemForm = (EEMForm) form;
			String method = eemForm.getMethod();
			
			
			// use the default DB for security check
			conn = DbConn.getConnection();
			SessionHelper sessionHelper = new SessionHelper(request);
			String errorMsg = sessionHelper.validateUser(conn);
			if (errorMsg != null) {
				request.setAttribute("Msg", "Login Has Timed Out");
				throw new Exception(errorMsg);
			}
			
			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			EEMContext context = EEMManager.getContext(sessionHelper.getSession());
			String selectedMenu = context.getSelectedMenu();
			eemForm.setMessage(null);
			
			if ("switchMenu".equals(method)) {
				logger.info(LoggerConstants.methodEndLevel());
				return EEMSwitchUtil.switchMenu( mapping, conn, context,  form, eemForm,  sessionHelper,  request,  response);			
			}
			else if (EEMConstants.MENU_TIMERS.equals(selectedMenu)) {
				
				if (eemForm instanceof EEMTimersForm) {
				
						EEMTimersHelper.setTimersFormList(
								(EEMTimersForm) eemForm, sessionHelper);
				}
				if ("search".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemTimersSearch(conn, sessionHelper, context,
							mapping, eemForm, request);
				}
				if ("timersPageNext".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemTimersSearchPage(conn, sessionHelper, context,
							mapping, form, request, "next");
				}
				if ("timersPageFirst".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemTimersSearchPage(conn, sessionHelper, context,
							mapping, form, request, "first");
				}
				if ("timersPagePrev".equals(method)){
					logger.info(LoggerConstants.methodEndLevel());
					return eemTimersSearchPage(conn, sessionHelper, context,
							mapping, form, request, "previous");
				}
					
					if("eemTimersUpdate".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemTimersUpdate(conn, sessionHelper, context, mapping,form, request);	
					}
					
					if("eemTimersSearch".equals(method)){
						logger.info(LoggerConstants.methodEndLevel());
						return eemTimersSearch(conn, sessionHelper, context, mapping,form, request);
					}
				
			}
			
				
			logger.info(LoggerConstants.methodEndLevel());
			return mapping.findForward("eemError");
			
		}catch(Exception e){
			
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward("eemError");
		
	}
	/**
	 * To search the timers
	 * @param conn contains Connection
	 * @param sessionHelper contains Session
	 * @param context contains EEMContext
	 * @param mapping contains ActionMapping
	 * @param form contains ActionForm
	 * @param request contains HTTPServletRequest 
	 * @return
	 * @throws ApplicationException
	 */
	private ActionForward eemTimersSearch(Connection conn,
		SessionHelper sessionHelper, EEMContext context,
		ActionMapping mapping, ActionForm form, HttpServletRequest request)
		throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
	logger.debug("Timer Search : Begin : ");  
//	logger.info("Timer Search : Begin : ");  

	EEMTimersForm eemTimersForm = (EEMTimersForm) form;
	EMTimersVO filterVO = context.getTimerVO();
	EEMTimersHelper.setFormToVO(eemTimersForm, filterVO, sessionHelper);

	Pagination pagination = context.getTimersPagination();
	if (pagination == null) {
		pagination = new Pagination();
		pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
		context.setTimersPagination(pagination);
	}
	
	String custId = sessionHelper.getMfId();

	// Get the form fields
	EEMTimersService service = context.getTimerService();
	List lstSearch = service.getSearchList(conn, filterVO, pagination,
			"first",custId);


	 if (lstSearch.size() > 0) {
		filterVO.setTimersList(lstSearch);
		sessionHelper.getSession().setAttribute(
				EEMConstants.SESSION_TIMERS_SEARCH, lstSearch);
	} else {
		filterVO.setTimersList(null);
		sessionHelper.getSession().setAttribute(
			EEMConstants.SESSION_TIMERS_SEARCH, null);
	}

	EEMTimersHelper.setVOToForm(filterVO, eemTimersForm, sessionHelper);
logger.debug("Timer Search : End : "); 
//logger.info("Timer Search : End : "); 
logger.info(LoggerConstants.methodEndLevel());
	return mapping.findForward(EEMConstants.EEM_TIMERS_APP);
	}
	/**
	 * To search the timers
	 * @param conn contains Connection
	 * @param sessionHelper contains session
	 * @param context contains EEMContext
	 * @param mapping contains Action Mapping
	 * @param form contains Action form
	 * @param request contains HTTPServletRequest
	 * @param move contains the String
	 * @return Action foward
	 * @throws ApplicationException
	 */
	private ActionForward eemTimersSearchPage(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request,
			String move) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("Timer Search Next Page: Begin : ");  
//		logger.info("Timer Search Next Page: Begin : ");  
		
	 EEMTimersForm eemTimersForm = (EEMTimersForm) form;
		EMTimersVO filterVO = context.getTimerVO();
		EEMTimersHelper.setFormToVO(eemTimersForm, filterVO, sessionHelper);

		Pagination pagination = context.getTimersPagination();
		if (pagination == null) {
			pagination = new Pagination();
			pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
			context.setTimersPagination(pagination);
		}
		
		String custId = sessionHelper.getMfId();

		EEMTimersService service = context.getTimerService();
		List lstSearch = service.getSearchList(conn, filterVO, pagination, move,custId);
	
	if (lstSearch.size() > 0) {
			filterVO.setTimersList(lstSearch);
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_TIMERS_SEARCH, lstSearch);
		} else {
			sessionHelper.getSession().setAttribute(
					EEMConstants.SESSION_TIMERS_SEARCH, null);
		}
		EEMTimersHelper.setVOToForm(filterVO, eemTimersForm, sessionHelper);
		logger.debug("Timer Search Next Page: End : ");  
//		logger.info("Timer Search Next Page: End : ");  
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_TIMERS_APP);
	}
	/**
	 * To update the timers
	 * @param conn contains Connection
	 * @param sessionHelper contains Session
	 * @param context contains EEMContext
	 * @param mapping contains Action Mapping
	 * @param form contains Action form
	 * @param request contains HttpServletRequest
	 * @return Action Forward
	 * @throws ApplicationException
	 * @throws SQLException
	 */
	private ActionForward eemTimersUpdate(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			ActionMapping mapping, ActionForm form, HttpServletRequest request)
			throws ApplicationException, SQLException{
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("Timer Update: Begin : ");  
//		logger.info("Timer Update: Begin : ");  
		EEMTimersForm eemTimersForm = (EEMTimersForm) form;
		EMTimersVO filterVO = context.getTimerVO();
		EMTimersSearchVO timerSearch =context.getTimerSearchVO();
		String userId=sessionHelper.getUserId();
		String customerId =sessionHelper.getCustomerNumber();
	    timerSearch.setCustomerId(customerId);
		EEMTimersService service = context.getTimerService();
	    EEMTimersHelper.setFormToVO(eemTimersForm, filterVO, sessionHelper);

		Pagination pagination = context.getTimersPagination();
		if (pagination == null) {
			pagination = new Pagination();
			pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
			context.setTimersPagination(pagination);
		}
	     boolean result = service.holdTimersUpdate(conn, filterVO,userId,pagination);
	  
	     String custId = sessionHelper.getMfId();
	   
		if(result==true){
			List lstSearch = service.getSearchList(conn, filterVO, pagination, "first",custId);
		
			 if (lstSearch.size() > 0) {
					filterVO.setTimersList(lstSearch);
					sessionHelper.getSession().setAttribute(
							EEMConstants.SESSION_TIMERS_SEARCH, lstSearch);
				} else {
					filterVO.setTimersList(null);
					sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_TIMERS_SEARCH, null);
				}
		}


		EEMTimersHelper.setVOToForm(filterVO, eemTimersForm, sessionHelper);
		logger.debug("Timer Update: End : ");  
//		logger.info("Timer Update: End : ");  
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(EEMConstants.EEM_TIMERS_APP);
		
	}

}
