/*
 * $Id: EEMFacadeManager.java,v 1.6 2015/11/16 23:07:01 dinesh Exp $
 */
package com.ps.mss.web.ajax;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EEMApplService;
import com.ps.mss.businesslogic.EEMEnrollService;
import com.ps.mss.dao.EEMApplDao;
import com.ps.mss.dao.EEMBillDao;
import com.ps.mss.dao.EEMAssignActivityDao;
import com.ps.mss.dao.EEMDao;
import com.ps.mss.dao.EEMEnrollDao;
import com.ps.mss.dao.EEMLetterDao;
import com.ps.mss.dao.model.EEMApplCommentsVO;
import com.ps.mss.dao.model.EMLEPMaximusVO;
import com.ps.mss.dao.model.EMMbrTriggerVO;
import com.ps.mss.dao.model.EmBBBInvoiceDetailVO;
import com.ps.mss.dao.model.EmBBBPaymentDtlInvoiceVO;
import com.ps.mss.dao.model.EmMbrAgentVO;
import com.ps.mss.dao.model.EmMbrEnrollmentVO;
import com.ps.mss.dao.model.EmMbrLepAttestInfoVO;
import com.ps.mss.dao.model.EmMbrLepInfoVO;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.DbConnWeb;
import com.ps.mss.db.EEMCodeCache;
import com.ps.mss.db.EEMProfileSettings;
import com.ps.mss.db.EEMWFCodeCache;
import com.ps.mss.db.EEMWFCodeCacheContoller;
import com.ps.mss.db.MBD;
import com.ps.mss.db.MBDPersistence;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.exception.DaoException;
import com.ps.mss.framework.Constants;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.manager.EEMBillingManager;
import com.ps.mss.model.EEMApplicationVO;
import com.ps.mss.model.EEMProfileItem;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.helper.AjaxHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.text.DateFormatter;
import com.ps.util.DateMath;
import com.ps.util.DateUtil;
import com.ps.util.NameValuePair;
import com.ps.util.StringUtil;

/**
 * @author Raghu Gorur
 *  
 */
public class EEMFacadeManager {

	private static Logger logger=LoggerFactory.getLogger(EEMFacadeManager.class);
	public EEMApplicationVO getProducts(String groupName, String productName, String zipCode5,
			String zipCode4, String planId, String pbp, String segment,
			String outOfArea, String covDt, String type) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplicationVO products = null;
		Connection conn = null;
		try {
			//System.out.println("Product - " + productName + "," + zipCode5
			//		+ "," + planId + "," + pbp + "," + segment + "," + outOfArea);

			// use the default DB for security check
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);

			EEMApplService service = new EEMApplService();
			EEMApplicationVO objVO = new EEMApplicationVO();
			objVO.setCustomerId(sessionHelper.getMfId());
			objVO.setEnrollGroupName(groupName);
			objVO.setEnrollProdName(productName);
			objVO.setPerZip4(zipCode4);
			objVO.setPerZip5(zipCode5);
			objVO.setEnrollPlan(planId);
			objVO.setEnrollPbp(pbp);
			objVO.setEnrollSegment(segment);
			objVO.setOutOfArea(outOfArea);
			objVO.setReqDtCov(covDt);
			objVO.setApplType(type);
			products = service.getProducts(conn, objVO);

			// For multiple products put in to session.
			/*if (products != null && products.getProducts().size() > 1) {
				sessionHelper.getSession().setAttribute(
						EEMConstants.EEM_APPL_PRODUCTS, products.getProducts());
			}*/
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				throw new ApplicationException(e);
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return products;
	}
	
	public NameValuePair[] getSelectOptions(String source, String option1) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		NameValuePair[] options = null;
		try {
			// Validate user
			AjaxHelper.validateUser();
			
			// Get servlet context object
			EEMCodeCache objCache = EEMCodeCache.getInstance();
			if (source.equals("perCounty") || source.equals("mailCounty")) {
				Map hmpCounty = objCache.getHmpCounty();
				if (hmpCounty.get(option1) != null) {
					List lstCounty = (ArrayList)hmpCounty.get(option1);
					options = convertListToArray(lstCounty);
				}
			} 
			
		} catch (Exception e) {
			throw new ApplicationException(e);
		} 
		logger.info(LoggerConstants.methodEndLevel());
		return options;
	}

	public NameValuePair[] getAgencies(String covDt, String lob) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		NameValuePair[] options = null;
		Connection conn = null;
		try {
			// use the default DB for security check
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);

			List lstIds = (new EEMApplDao()).getLstAgencies(conn, sessionHelper.getMfId(), covDt, lob);
			options = convertListToArray(lstIds);
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return options;		
	}
	
	// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - Start
	public NameValuePair[] getBrokerAgents(String type, String agencyId, String signDt,String covDt, String lob) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String effDate = signDt;
		//get em profile
		try{
		    SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		    String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			EEMProfileItem item = EEMProfileSettings.getProfileObject(
					eemDb, sessionHelper.getMfId(), EEMProfileSettings.AGENTDT);			
			if("R".equalsIgnoreCase(item.getProfileValue())){

				if(! StringUtil.nonNullTrim(covDt).equals("")) //Modified for IFOX-00402313
					effDate = covDt;
			}
		}catch(Exception e){
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
		}	
		// added this additional condition to filter the empty dates.
		if(effDate == null || "".equals(effDate)){
			logger.info(LoggerConstants.methodEndLevel());
			return new NameValuePair[0];
		}
		logger.info(LoggerConstants.methodEndLevel());
		return getBrokerAgents(type,agencyId,effDate, lob);
	}
	// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - End
	//IFOX-00415856 - New Agent Look Up CR :START
	public NameValuePair[] getAgentName(String type, String agencyId, String signDt,String covDt, String agentId, String lob) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String effDate = signDt;
		//get em profile
		try{
		    SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		    String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			EEMProfileItem item = EEMProfileSettings.getProfileObject(
					eemDb, sessionHelper.getMfId(), EEMProfileSettings.AGENTDT);			
			if("R".equalsIgnoreCase(item.getProfileValue())){

				if(! StringUtil.nonNullTrim(covDt).equals("")) //Modified for IFOX-00402313
					effDate = covDt;
			}
		}catch(Exception e){
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
		}	
		// added this additional condition to filter the empty dates.
		if(effDate == null || "".equals(effDate)){
			logger.info(LoggerConstants.methodEndLevel());
			return new NameValuePair[0];
		}
		logger.info(LoggerConstants.methodEndLevel());
		
		return getAgentNameList(type,agencyId,effDate, agentId, lob);
	}
	public NameValuePair[] getAgentNameList(String type, String agencyId, String covDt, String agentId, String lob) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		NameValuePair[] options = null;
		Connection conn = null;
		try {
			// use the default DB for security check
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);

			List lstIds = (new EEMApplDao()).getLstBrokAgentsNew(conn, sessionHelper
					.getMfId(), type, agencyId, covDt, agentId, lob);
			options = convertListToArray(lstIds);
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return options;		
	}
	//IFOX-00415856 - New Agent Look Up CR :END
	public NameValuePair[] getBrokerAgents(String type, String agencyId, String covDt, String lob) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		NameValuePair[] options = null;
		Connection conn = null;
		try {
			// use the default DB for security check
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);

			List lstIds = (new EEMApplDao()).getLstBrokAgents(conn, sessionHelper
					.getMfId(), type, agencyId, covDt, lob);
			options = convertListToArray(lstIds);
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return options;		
	}
	
	public NameValuePair[] getInstLookUp(String dateOfCov, String lob) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		NameValuePair[] options = null;
		Connection conn = null;
		try {
			// use the default DB for security check
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);

			List lstIds = (new EEMApplDao()).getInstLookUp(conn, sessionHelper.getMfId(), dateOfCov, lob);
			options = convertListToArray(lstIds);
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return options;		
	}

	public NameValuePair[] getAgencyList(String dateOfCov, String lob) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		NameValuePair[] options = null;
		Connection conn = null;
		try {
			// use the default DB for security check
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);

			List lstIds = (new EEMApplDao()).getLstAgencies(conn, sessionHelper.getMfId(), dateOfCov, lob);
			options = convertListToArray(lstIds);
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return options;		
	}

	/**
	 * 
	 * @param dateOfCov
	 * @param docName
	 * @param currPatient
	 * @return EEMApplicationVO
	 * @throws ApplicationException
	 */
	/**
	 * Updated signature for IFOX-00389053 
	 * Added Line of Business
	 * Updated code to include LOB while fetching the results
	 */
	public EEMApplicationVO getPCPName(String dateOfCov, String docName,
			String currPatient,String lob) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplicationVO objVO = null;
		Connection conn = null;
		try {
			// use the default DB for security check
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);

			List lstNames = (new EEMApplDao()).getLstPCPNames(conn,
					sessionHelper.getMfId(), dateOfCov, docName, "",
					currPatient, "",lob,"");
			
			if (lstNames.size() == 1) {
				objVO = (EEMApplicationVO)lstNames.get(0);
			} 
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Error Message::::"+e.getMessage());
//			logger.error("Error Message::::"+e.getMessage());
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("Error Code::::"+e.getMessage()+"Error Message::::"+e.getMessage());
//				logger.error("Error Code::::"+e.getMessage()+"Error Message::::"+e.getMessage());
				throw new DaoException(Constants.EXCEPTION_MSG,e);
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objVO;		
	}
	
	public String getInstDetails(String instId, String dateOfCov, String lob) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String instDetails = "";
		Connection conn = null;
		try {
			// use the default DB for security check
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);

			instDetails = (new EEMApplDao()).getInstDetails(conn,
									sessionHelper.getMfId(), instId, dateOfCov, lob);
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return instDetails;
	}
	
	/*public String getCounty(String zip5, String zip4) throws ApplicationException {
		String county = "";
		Connection conn = null;
		try {
			
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			county = new EEMApplDao().getCounty(conn, zip5, zip4); 
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}

		return county;
	}*/

	/**
	 * BasePlus County Changes - Start1
	 * author - swagat
	 */
	/* IFOX-00397816 : Add comments button */	
	public String updateComments(String customerId,String appId, ArrayList<EEMApplCommentsVO> lstComments) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		int count =0;
		String status=null;
		logger.debug("updateComments FacadeMgr- customerId:"+customerId+" ,appId:"+appId+" ,lstComments:"+lstComments);
		try {
			
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);

			EEMApplCommentsVO commentVO=null;
			if (lstComments == null) {
				return "No Comments to Update.";
			}
			for (int i = lstComments.size()-1; i >= 0; i--) {
				commentVO = (EEMApplCommentsVO)lstComments.get(i);
				if (commentVO.getInsert().equals("Y")) {
					String comment = StringUtil.nonNullTrim(commentVO.getApplComments());
					if (comment.length() > 255) {
						comment = comment.substring(0, 255);
						commentVO.setApplComments(comment);
					}

					count = new EEMApplDao().insertCommentDetails(conn, commentVO, "");
					logger.debug("Update Comments Status is "+count+"for comment:["+commentVO.getApplComments()+"]");
//					logger.info("Update Comments Status is "+count+"for comment:["+commentVO.getApplComments()+"]");
					
					
				}
			}
			status="SUCCESS : Comments updated successfully!";
			
		} catch (Exception e) {
			status="ERROR: Failed to update Comments";
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("ERROR: Failed to update Comments :"+e.getMessage());
//			logger.error("ERROR: Failed to update Comments :"+e.getMessage());
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return status;
	}
	
	/**
	 * BasePlus County Changes - Start1
	 * author - swagat
	 */
	
	public List getCounty(String zip5, String zip4) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String county = "";
		List countyList = null;
		Connection conn = null;
		try {
			
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			//county = new EEMApplDao().getCounty(conn, zip5, zip4);
			countyList = new EEMApplDao().getCountyList(conn, zip5, zip4);
//			for(int i=0;i<countyList.size();i++)
//			{
//				NameValuePair nvPair = (NameValuePair)countyList.get(i);
//				System.out.println("County Values are as below:\n County ID: "+nvPair.getValue()+"\t County Name: "+nvPair.getName());
//			}
			
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return countyList;
	}
	
	/*For Defect#93,42-Hometown */
	public List getMailingAddress(String zip5, String zip4) {
		logger.info(LoggerConstants.methodStartLevel());
		List cityList = null;
		Connection conn = null;
		try {
			
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			cityList = new EEMApplDao().getCityNameswithCounty(conn, zip5, zip4);

		} catch (Exception e) {
			try {
				throw new ApplicationException(e);
			} catch (ApplicationException e1) {
				// TODO Auto-generated catch block
				logger.error(LoggerConstants.exceptionMessage(e1.toString()));
				//e1.printStackTrace();
			}
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return cityList;
	}
	
	public String insertPrintIDCardMbrTrigger(String concatenatedValue){
		logger.info(LoggerConstants.methodStartLevel());
		/*String msg="ID CARD PRINT REQUEST COULD'NT BE SUBMITTED.";*/
		String msg="PRINT MATERIAL REQUEST COULD'NT BE SUBMITTED.";
		Connection conn = null;
		try {
			

			
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);
			
			EMMbrTriggerVO trigVO =getEMMbrTriggerVO(concatenatedValue);
			EEMEnrollDao enrolDAO=new EEMEnrollDao();

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			int updtcount = enrolDAO.closeOpenPrintIDCardTrigger(conn,trigVO );
			logger.info("ID card open triggers updated:"+updtcount);
			
			conn = DbConn.reGetConnection(conn,eemDb);			
			int count = enrolDAO.insertPrintIDCardMbrTrigger(conn,trigVO );
			
			/*msg=(count > 0)?"ID CARD PRINT REQUEST SUBMITTED.":msg;*/
			msg=(count > 0)?"PRINT MATERIAL REQUEST SUBMITTED.":msg;
			
			

		} catch(ParseException e){
			msg="INVALID DATE FORMAT";		
		}catch (Exception e) {
			/*msg="ERROR SUBMITTING ID CARD PRINT REQUEST";*/
			msg="ERROR SUBMITTING PRINT MATERIAL REQUEST";
			try {
				throw new ApplicationException(e);
			} catch (ApplicationException e1) {
				// TODO Auto-generated catch block
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				//e1.printStackTrace();
			}
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return msg;
	}
	
	public EMMbrTriggerVO getEMMbrTriggerVO(String concatenatedValue) throws ParseException{
		logger.info(LoggerConstants.methodStartLevel());
		/*customerIdValue+delimiter+memberIdValue+delimiter+triggerTypeValue+delimiter+triggerCodeValue+delimiter+
		planIdValue+delimiter+pbpIdValue+delimiter+planDesignationValue+delimiter+printCodeValue+delimiter+effStartDateValue
		+delimiter+mfId;*/
		DateUtil dutil=new DateUtil();
		//IFOX-413172 - Welcome Kit Entries - CR - Start
		
		Map<String,String> sourceTriggerCodeMap = new HashMap<String,String>();
		sourceTriggerCodeMap.put("100", "DCONF");
		sourceTriggerCodeMap.put("101", "DANOC");
		sourceTriggerCodeMap.put("102", "DPROV");
		sourceTriggerCodeMap.put("103", "DEOC");
		sourceTriggerCodeMap.put("104", "DDENTAL");
		sourceTriggerCodeMap.put("105", "DFORM");
		sourceTriggerCodeMap.put("106", "DVISION");
		//sourceTriggerCodeMap.put("107", "DPLAN");
		
		EMMbrTriggerVO trigVO=new EMMbrTriggerVO();
		
		String[] trigArr=StringUtil.split(concatenatedValue, "|");
		
		trigVO.setCustomerId(trigArr[0]);
		trigVO.setMemberId(trigArr[1]);
		trigVO.setTriggerType(trigArr[2]);
		trigVO.setTriggerCode(trigArr[3]);
		trigVO.setTriggerStatus("OPEN");
		
		trigVO.setPlanId(trigArr[4]);
		trigVO.setPbpId(trigArr[5]);
		trigVO.setPlanDesignation(trigArr[6]);
		
		if(sourceTriggerCodeMap.get(trigArr[7]) != null && ! sourceTriggerCodeMap.get(trigArr[7]).equals("")){
			trigVO.setTriggerCode(sourceTriggerCodeMap.get(trigArr[7]));
			logger.debug("sourceTriggerCodeMap.get(trigArr[7]:"+sourceTriggerCodeMap.get(trigArr[7]));
		}

		//IFOX-413172 - Welcome Kit Entries - CR - End
		trigVO.setProcessSource(trigArr[7]);
		//Convert to Trigger and check the effDate
		//	IFOX-00397810 eff date will be calculated based on IDUSREFFDT profile option
		// if IDUSREFFDT - Y use user enetered value or use getEffDateForIDC method
		boolean isUserEnteredEffDt = false;
		try {
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			String eemDb = (String) sessionHelper.getAttribute(SessionManager.EEMDB);
			isUserEnteredEffDt = "Y".equalsIgnoreCase(EEMProfileSettings.getCalendarProfileItem(eemDb,
					sessionHelper.getMfId(), EEMProfileSettings.IDUSREFFDT)) ? true : false;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.debug("ERROR while fetching IDUSREFFDT for "+trigVO.getCustomerId());
			//System.err.println("ERROR while fetching IDUSREFFDT for "+trigVO.getCustomerId());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
		}		
		trigVO.setEffectiveDate(dutil.getEffDateForIDC(trigArr[8],"MM/dd/yyyy","yyyyMMdd",isUserEnteredEffDt));		
		trigVO.setCreateUserid(trigArr[9]);
		trigVO.setLastUpdtUserid(trigArr[9]);
		logger.info(LoggerConstants.methodEndLevel());
		return trigVO;
	}
	
	
	public List getCity(String zip5, String zip4) {
		logger.info(LoggerConstants.methodStartLevel());
		String city = "";
		List cityList = null;
		Connection conn = null;
		try {
			
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			//county = new EEMApplDao().getCounty(conn, zip5, zip4);
			cityList = new EEMApplDao().getCityList(conn, zip5, zip4);
			for(int i=0;i<cityList.size();i++)
			{
				//String city = (String) lstCity.get(i);
				//System.out.println("City Code: "+city);
				NameValuePair nvPair = (NameValuePair) cityList.get(i);				
				String city1 = nvPair.getName();
				if(city1.length() >= 20){
					String cityName = city1.substring(0, 19);
					nvPair.setName(cityName);
					nvPair.setValue(cityName);
					cityList.add(nvPair);
				}
			}
		} catch (Exception e) {
			try {
				throw new ApplicationException(e);
			} catch (ApplicationException e1) {
				// TODO Auto-generated catch block
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				//e1.printStackTrace();
			}
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return cityList;
	}
	public List getCities(String zip5, String zip4, String county) {
		logger.info(LoggerConstants.methodStartLevel());
		String city = "";
		List cityList = null;
		Connection conn = null;
		try {
			
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			//county = new EEMApplDao().getCounty(conn, zip5, zip4);
			cityList = new EEMApplDao().getCities(conn, zip5, zip4, county);
			for(int i=0;i<cityList.size();i++)
			{
				//String city = (String) lstCity.get(i);
				//System.out.println("City Code: "+city);
				NameValuePair nvPair = (NameValuePair) cityList.get(i);				
				String city1 = nvPair.getName();
				if(city1.length() >= 20){
					String cityName = city1.substring(0, 19);
					nvPair.setName(cityName);
					nvPair.setValue(cityName);
					cityList.add(nvPair);
				}
			}
		} catch (Exception e) {
			try {
				throw new ApplicationException(e);
			} catch (ApplicationException e1) {
				// TODO Auto-generated catch block
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				//e1.printStackTrace();
			}
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return cityList;
	}
	
	/**
	 * BasePlus County Changes - End1
	 * author - swagat

	 */
	
	public String[] getCityName(String zip5, String zip4) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String[] city = null;
		Connection conn = null;
		try {
			
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			city = new EEMDao().getCityName(conn, zip5, zip4); 
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return city;
	}
	
	public String getBillMbrGrpName(String id, String mbrGrpInd) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String strName = null;
		Connection conn = null;
		try {
			
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			List lstObj = new EEMBillDao().getBillMbrGrpList(conn, sessionHelper.getMfId(), id, "", "", mbrGrpInd);
			if (lstObj != null && lstObj.size() > 0) {
				strName = ((EmBBBInvoiceDetailVO)lstObj.get(0)).getGroupName();
			}
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return strName;
	}
	
	public String getTotalInvoiceDetailAmt(String customerId, String invoiceNbr, String itemNbr) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		double val = 0;
		Connection conn = null;
		try {
			
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			val = new EEMBillDao().getTotalInvoiceDetailAmt(conn, customerId, invoiceNbr, itemNbr);
			
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return ""+val;
	}
	
	public String getTimeStamp(String format) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String time = "";
		try {
			// Validate user
			AjaxHelper.validateUser();
			time = (new DateUtil()).getTodaysDate(format);
		} catch (Exception e) {
			throw new ApplicationException(e);
		} 
		logger.debug(time);
		logger.info(LoggerConstants.methodEndLevel());
		return time;
	}
	
	public String checkMember(String hicNbr, String applType, String reqDtCov)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		try {
			
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			EEMApplicationVO objVO = new EEMApplicationVO();
			objVO.setApplType(applType);
			objVO.setReqDtCov(reqDtCov);
			objVO.setCustomerId(sessionHelper.getMfId());
			objVO.setMbrHicNbr(hicNbr);
			if (new EEMApplService().checkMember(new EEMApplDao(), conn, objVO)) {
				logger.info(LoggerConstants.methodEndLevel());
				return objVO.getMbrHicNbr(); 
			}
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		} 
		logger.info(LoggerConstants.methodEndLevel());
		return "";
	}
	
	public EmBBBPaymentDtlInvoiceVO[] getPaymentDetail(String row, String isMember) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		EmBBBPaymentDtlInvoiceVO[] detailVO = null;
		try {
			
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			EEMBillingManager mgr = new EEMBillingManager();
			if (!StringUtil.nonNullTrim(isMember).equals("true")) {
				detailVO = mgr.getPaymentDetails(conn, sessionHelper, Integer.parseInt(row));
			} else {
				detailVO = mgr.getMembPaymentDetails(conn, sessionHelper, Integer.parseInt(row));
			}
			
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		} 
		logger.info(LoggerConstants.methodEndLevel());
		return detailVO;
	}
	
	public EmMbrAgentVO getAgencyDetails(String agencyId, String startDate, String lob) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		EmMbrAgentVO agentVO = null;
		try {
			
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			EEMEnrollDao eemDao = new EEMEnrollDao();
			agentVO = eemDao.getAgencyDetails(conn, sessionHelper.getMfId(), agencyId, startDate, lob);
			
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		} 
		logger.info(LoggerConstants.methodEndLevel());
		return agentVO;
	}

	public EmMbrAgentVO getAgentDetails(String agencyId, String agentType, String agentId, String startDate, String lob) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		EmMbrAgentVO agentVO = null;
		try {
			
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			EEMEnrollDao eemDao = new EEMEnrollDao();
			agentVO = eemDao.getAgentDetails(conn, sessionHelper.getMfId(), agencyId, agentType, agentId, startDate,lob);
			
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		} 
		logger.info(LoggerConstants.methodEndLevel());
		return agentVO;
	}
	//IFOX - 426356 Attachment CR : start
	public String[] getMemberDetails(String type, String primId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String[] values = null;
		Connection conn = null;
		try {
			
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			values = new EEMLetterDao().getMemberDetails(conn, type,primId,sessionHelper.getMfId()); 
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		} 
		logger.info(LoggerConstants.methodEndLevel());
		return values;
	}
	//IFOX - 426356 Attachment CR : end
	private NameValuePair[] convertListToArray(List lstSource) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		NameValuePair[] options = null;
		if (lstSource.size() > 0) {
			options = new NameValuePair[lstSource.size()];
			for(int i = 0; i < lstSource.size(); i++) {
				options[i] = (NameValuePair)lstSource.get(i);
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return options;
	}
	
	//original application start
	public boolean checkOriginalApplication(String applId, String customerId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		boolean flag = false;
		try {
			// use the default DB for security check
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);

			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);
			
			flag =  new EEMApplDao().getOrigAppl(conn,applId,customerId);
			//System.out.println("flag"+flag);
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("Exeception:::::::::"+e.getMessage());
//				logger.error("Exeception:::::::::"+e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return flag;		
	}
	//original application end
   	/*
	 * 045_AssignActivity start
	 */
	/**
	 * 
	 * @param conn holds Connection object
	 * @param supervisiorId holds supervisorId value
	 * @param customerId holds customerId value
	 * @return List userList
	 * @throws ApplicationException throws when application fails to execute
	 */
	@SuppressWarnings("rawtypes")
	public List getUserList(Connection conn, String supervisiorId, String customerId,String userLevel)
			throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		logger.info(" getUserList  :Start");
		List userList;
		try {
			conn = DbConnWeb.getConnection();			
			userList = EEMWFCodeCacheContoller.getEEMWFCodeCache(customerId).getLstActivityUser(customerId, supervisiorId,userLevel);
			//userList = new EEMWFCodeCache().getLstActivityUser(customerId, supervisiorId,userLevel);
//			userList = new EEMWFPersistence().getLstActivityAdminUsers(customerId);
			
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Error Message:::::::"+e.getMessage());
//			logger.error("Error Message:::::::"+e.getMessage());
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("getUserList Error: "+e.getMessage());
//				logger.error("getUserList Error: "+e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		logger.info(" getUserList :End");
		return userList;
	
		
	}	/**
	 * This method is used to get supervisorID for a selected userId
	 * @param conn holds Connection object
	 * @param userId holds userId value
	 * @param customerId holds customerId value
	 * @return String supervisorId holds the supervisorId value returned by query
	 * @throws ApplicationException throws when application fails to execute
	 */
	public String getSupervisorId(Connection conn, String userId, String customerId)
			throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug(" getSupervisorId  :Start");
//		logger.info(" getSupervisorId  :Start");
		String supervisorId = null;
		try {			
			conn = DbConnWeb.getConnection();			
			supervisorId = new EEMAssignActivityDao().getSupervisorId(conn,userId,customerId);			
			
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Error Message:::::::"+e.getMessage());
//			logger.error("Error Message:::::::"+e.getMessage());
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("getSupervisorId Error: "+e.getMessage());
//				logger.error("getSupervisorId Error: "+e.getMessage());
			}
		}
		logger.debug(" getSupervisorId :End");
//		logger.info(" getSupervisorId :End");
		logger.info(LoggerConstants.methodEndLevel());
		return supervisorId;
	
		
	}
	/*
	 * 045_AssignActivity End
	 */
	
	/**
   	 * Excellus letter request  CR #17- Starts
   	 * author - pranitha
   	 */
	public ArrayList getPlanDetails(String primaryId, String effdate) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		ArrayList plan = null;
		Connection conn = null;
		try {
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);
			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);			
			plan = new EEMDao().getPlanDetails(conn, sessionHelper.getMfId(),primaryId,effdate); 
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return plan;
	}
	
	// IFOX-00381706 - COB Fix CR Summacare - Start
	public String getCOBParmCD(String isInCmpltCOB) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String parmCd = null;
		Connection conn = null;
		try {
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);
			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);			
			parmCd = new EEMDao().getParmCd(conn, sessionHelper.getMfId(),isInCmpltCOB); 
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return parmCd;
	}
	// IFOX-00381706 - COB Fix CR Summacare - End
	
	public EMLEPMaximusVO updateLepMaximus(String caseFileRecDate, String decisionRecDate, String decisionType,
			String caseFileNumber, String memberId, String createTime, String isUpdate) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		EMLEPMaximusVO vo1 = null;
		try {
			conn = DbConnWeb.getConnection();
			conn.setAutoCommit(false);
			EEMEnrollDao dao = new EEMEnrollDao();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			String userId = sessionHelper.getUserId();
			String custId = sessionHelper.getMfId();
			String eemDb = (String) sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn, eemDb);
			EMLEPMaximusVO vo = new EMLEPMaximusVO();
			decisionType = decisionType == null ? "" : decisionType.trim();
			caseFileNumber = caseFileNumber == null ? "" : caseFileNumber.trim();
			caseFileRecDate = caseFileRecDate == null ? "" : DateFormatter.reFormat(
					StringUtil.nonNullTrim(caseFileRecDate), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
			String caseFileDueDate = StringUtils.isEmpty(caseFileRecDate) ? "" : DateMath.addDay(caseFileRecDate, 14);
			decisionRecDate = decisionRecDate == null ? "" : DateFormatter.reFormat(
					StringUtil.nonNullTrim(decisionRecDate), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
			String tXN73DueDate = StringUtils.isEmpty(decisionRecDate) ? "" : DateMath.addDay(decisionRecDate, 14);
			vo.setCaseFileNumber(caseFileNumber);
			vo.setCaseFileRecDate(caseFileRecDate);
			vo.setCaseFileDueDate(caseFileDueDate);
			vo.setCreateUserId(userId);
			vo.setCustomerId(custId);
			vo.setDecisionRecDate(decisionRecDate);
			vo.setDecisionType(decisionType);
			vo.setIsUpdate(isUpdate);
			vo.setMemberId(memberId);
			vo.setTransactionDueDate(tXN73DueDate);
			vo.setCreateTime(createTime);
			vo.setLastUpdtUserId(userId);
			System.out.println("LEP MAX:" + vo);
			dao.insertOrUpdateLEPMaximus(conn, vo);
			vo1 = dao.getLepMaximusDetails(conn, vo.getCustomerId(), vo.getMemberId());
			vo.setLastUpdtTime(vo1.getLastUpdtTime());
			int result = processLepMaxTimer(conn, vo, EEMConstants.TRIGGER_CODE_LEP_MAX_90);
			if(result == 0){
				processLepMaxTimer(conn, vo, EEMConstants.TRIGGER_CODE_LEP_MAX_14);
			}
			vo1 = null;
			vo1 = dao.getLepMaximusDetails(conn, vo.getCustomerId(), vo.getMemberId());
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
			try {
				conn.rollback();
				conn.close();
			} catch (SQLException e1) {
				logger.error(LoggerConstants.exceptionMessage(e1.toString()));
				//e1.printStackTrace();
			}
		} finally {
			try {
				if (conn != null && !conn.isClosed()) {
					conn.commit();
					conn.close();
				}
			} catch (Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				//logger.error(e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return vo1;
	}
	private int processLepMaxTimer(Connection conn, EMLEPMaximusVO vo, String triggerCode) throws SQLException,
			ApplicationException, ParseException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollDao dao = new EEMEnrollDao();
		DateUtil util = new DateUtil();
		String todaysDate = util.getTodaysDate();
		int result = 0;
		EMMbrTriggerVO trig = new EMMbrTriggerVO();
		trig.setCustomerId(vo.getCustomerId());
		trig.setMemberId(vo.getMemberId());
		trig.setTriggerType(EMMbrTriggerVO.TRIG_TYPE_FUM);
		trig.setCreateTime(vo.getLastUpdtTime());
		trig.setTriggerCode(triggerCode);
		trig.setPlanId("");
		trig.setPbpId("");
		trig.setPlanDesignation("");
		trig.setTriggerStatus(EMMbrTriggerVO.TRIG_STATUS_OPEN);
		trig.setProcessSource(EMMbrTriggerVO.TRIG_PROCESS_SOURCE_WEBENRL);
		trig.setOrigTriggerType("");
		trig.setOrigTriggerCode("");
		trig.setOrigEffectiveDate("");
		trig.setOrigTriggerCreateTime("");
		trig.setCreateUserid(vo.getLastUpdtUserId());
		trig.setLastUpdtUserid(vo.getLastUpdtUserId());
		trig.setLastUpdtTime(vo.getLastUpdtTime());
		if (EEMConstants.TRIGGER_CODE_LEP_MAX_14.equalsIgnoreCase(triggerCode)) {
			if(StringUtils.isEmpty(vo.getCaseFileDueDate())){
				dao.cancelAnyOpenTriggers(conn, trig);
				logger.info(LoggerConstants.methodEndLevel());
				return 0;
			}
			if (DateMath.isLessThan(vo.getCaseFileDueDate(), todaysDate)) {
				logger.info(LoggerConstants.methodEndLevel());
				return 0;
			}
			trig.setEffectiveDate(vo.getCaseFileDueDate());
		} else {
			if(StringUtils.isEmpty(vo.getDecisionRecDate())){
				dao.cancelAnyOpenTriggers(conn, trig);
				logger.info(LoggerConstants.methodEndLevel());
				return 0;
			}
			String duedate = DateMath.addDay(vo.getDecisionRecDate(), 14); //updated for IFOX-00390584
			if (DateMath.isLessThan(duedate, todaysDate)) {
				logger.info(LoggerConstants.methodEndLevel());
				return 0;
			}
			trig.setEffectiveDate(duedate);
		}
		boolean check = dao.checkMbrTrigger(conn, trig);
		if (check != true) {
			dao.cancelAnyOpenTriggers(conn, trig);
			result = dao.insertMbrTrigger(conn, trig);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return result;
	}
	public boolean getApplAttnDetails(String applId) {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		EEMApplicationVO objVO = new EEMApplicationVO();
		boolean isApplAttnHaveValidData = false;
		try {
			conn = DbConnWeb.getConnection();
			conn.setAutoCommit(false);
			EEMApplDao dao = new EEMApplDao();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			String custId = sessionHelper.getMfId();
			String eemDb = (String) sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn, eemDb);
			objVO.setApplicationId(Integer.parseInt(applId));
			objVO.setCustomerId(custId);
			isApplAttnHaveValidData = dao.getApplAttnDetails(conn,objVO);
		}catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
			try {
				conn.rollback();
				conn.close();
			} catch (SQLException e1) {
				logger.error(LoggerConstants.exceptionMessage(e1.toString()));
				//e1.printStackTrace();
			}
		} finally {
			try {
				if (conn != null && !conn.isClosed()) {
					conn.commit();
					conn.close();
				}
			} catch (Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				//logger.error(e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return isApplAttnHaveValidData;
	}
	public boolean getEnrollMbrAttnDetails(String memberId) {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		EmMbrEnrollmentVO mbrVO = new EmMbrEnrollmentVO();
		boolean isEnrollMbrAttnHaveValidData = false;
		try {
			conn = DbConnWeb.getConnection();
			conn.setAutoCommit(false);
			EEMEnrollDao dao = new EEMEnrollDao();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			String custId = sessionHelper.getMfId();
			String eemDb = (String) sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn, eemDb);
			mbrVO.setMemberId((memberId));
			mbrVO.setCustomerId(custId);
			isEnrollMbrAttnHaveValidData = dao.getEnrollMbrAttnDetails(conn,mbrVO);
		}catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
			try {
				conn.rollback();
				conn.close();
			} catch (SQLException e1) {
				logger.error(LoggerConstants.exceptionMessage(e1.toString()));
				//e1.printStackTrace();
}
		} finally {
			try {
				if (conn != null && !conn.isClosed()) {
					conn.commit();
					conn.close();
				}
			} catch (Exception e) {
				logger.error(e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return isEnrollMbrAttnHaveValidData;
	}
	public boolean validateLEPAttesCovMnth(String memberId){
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		EmMbrEnrollmentVO mbrVO = new EmMbrEnrollmentVO();
		boolean firstValidtion = false;
		boolean secondValidtion = false;
		try {
			conn = DbConnWeb.getConnection();
			conn.setAutoCommit(false);
			EEMEnrollDao dao = new EEMEnrollDao();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			String custId = sessionHelper.getMfId();
			String eemDb = (String) sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn, eemDb);
			mbrVO.setMemberId((memberId));
			mbrVO.setCustomerId(custId);
			ArrayList<EmMbrLepInfoVO> mbrPlepList = dao.getMbrLepPotential(conn, custId, memberId, "N");
			ArrayList<EmMbrLepAttestInfoVO> mbrLepCcfInfo = dao.getMbrLepCcf(conn, custId, memberId, "N");
			for(EmMbrLepAttestInfoVO ccfInfo: mbrLepCcfInfo){
				if(ccfInfo.getTxtBrkInCoverage().equalsIgnoreCase("YES")){
					for(EmMbrLepInfoVO attnInfo: mbrPlepList){
						if(DateMath.isBetween(toDBFormat(ccfInfo.getTxtFromDate()), toDBFormat(attnInfo.getPotentialuncovMthStDt()), toDBFormat(attnInfo.getPotentialuncovMthEndDt()))
								|| DateMath.isBetween(toDBFormat(ccfInfo.getTxtToDate()), toDBFormat(attnInfo.getPotentialuncovMthStDt()), toDBFormat(attnInfo.getPotentialuncovMthEndDt()))){
							firstValidtion = true;							
						}
					}
				}
			}
			if(firstValidtion){ // upadated for 390310
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		}catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
		} finally {
			try {
				if (conn != null && !conn.isClosed()) {
					conn.close();
				}
			} catch (Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				//logger.error(e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return true;
	}
	public EmMbrLepAttestInfoVO updateAttes90DaysInfo(String memberId, String atRecdate, String atChannel, String appealFlag) {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		EmMbrLepAttestInfoVO newEmMbrLepAttestInfoVO = null;
		int sqlCnt = 0;
		try {
			conn = DbConnWeb.getConnection();
			conn.setAutoCommit(false);
			EEMEnrollDao enrlDao = new EEMEnrollDao();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			String custId = sessionHelper.getMfId();
			String userId = sessionHelper.getUserId();
			String eemDb = (String) sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn, eemDb);

			newEmMbrLepAttestInfoVO = new EmMbrLepAttestInfoVO();
			newEmMbrLepAttestInfoVO.setMemberId(memberId);
			newEmMbrLepAttestInfoVO.setCustomerId(custId);
			newEmMbrLepAttestInfoVO.setEnableAttestAfter90DaysSection(true);
			newEmMbrLepAttestInfoVO.setAttestationRecDate(StringUtil.nonNullTrim(atRecdate));
			newEmMbrLepAttestInfoVO.setLastUpdtUserId(userId);
			newEmMbrLepAttestInfoVO.setCreateUserId(userId);
			newEmMbrLepAttestInfoVO.setAttestationRecChannel(StringUtil.nonNullTrim(atChannel));
			newEmMbrLepAttestInfoVO.setNotifiedMemberAppeal(StringUtil.nonNullTrim(appealFlag));
			if (enrlDao.getMbrLepAttest90DaysObj(conn, newEmMbrLepAttestInfoVO) != null) {
				sqlCnt = enrlDao.updateMbrLepAttn90DaysDetails(conn, newEmMbrLepAttestInfoVO);
			} /** Insert the record in 'EM_MBR_LEP_ATTN_OTHER' table' */
			else {
				sqlCnt = enrlDao.insertMbrLepAttn90DaysDetails(conn, newEmMbrLepAttestInfoVO);
			}
			if (sqlCnt > 0) {
				logger.debug("Attestation Received after 90 days Section Successfully Updated.");
//				logger.info("Attestation Received after 90 days Section Successfully Updated.");
				logger.info(LoggerConstants.methodEndLevel());
				return enrlDao.getMbrLepAttest90DaysObj(conn, newEmMbrLepAttestInfoVO);
			}
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
		} finally {
			try {
				if (conn != null && !conn.isClosed()) {
					conn.close();
				}
			} catch (Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				//logger.error(e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return null;
	}
	public static String toDBFormat(String input){
		logger.info(LoggerConstants.methodStartLevel());
		return DateFormatter.reFormat(
				StringUtil.nonNullTrim(input), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
	}
//new LEP changes -- end

	// IFOX-00400257 : START
	public boolean validateInvoiceId(String toValidate) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		boolean isValid = false;
		Connection conn = null;
		try {
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);
			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			conn = DbConn.reGetConnection(conn,eemDb);			
			isValid = new EEMDao().validateInvoiceId(conn, sessionHelper.getMfId(),toValidate); 
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return isValid;
	}
	// IFOX-00400257 : END
	//Super User changes - start
	public MBD checkMEDvalue(String hicNbr) throws ApplicationException  {
		logger.info(LoggerConstants.methodStartLevel());
		Connection conn = null;
		try {
			conn = DbConnWeb.getConnection();
			SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
			AjaxHelper.validateUser(sessionHelper, conn);
			String eemDb = (String) sessionHelper.getAttribute(SessionManager.EEMDB);
			String beqCheck = EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),
					EEMProfileSettings.BEQCHECK);
			conn = DbConn.reGetConnection(conn, eemDb);
			MBDPersistence persistence = new MBDPersistence();
			MBD mbd = persistence.get(conn, hicNbr, beqCheck);
			logger.info(LoggerConstants.methodEndLevel());
			return mbd;
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("Exeception:::::::::" + e.getMessage());
//				logger.error("Exeception:::::::::" + e.getMessage());
			}
		}
	}
	//Super User changes - end
	
	// CMS 2019 changes- requirement 5-Start
		public String getCcmDate() throws ApplicationException {
			logger.info(LoggerConstants.methodStartLevel());
			String ccmDate = "";
			Connection conn = null;
//			logger.info("Inside getCcmDate() method");
			logger.debug("Inside getCcmDate() method");
			try {
				conn = DbConnWeb.getConnection();
				SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
				AjaxHelper.validateUser(sessionHelper, conn);
				String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
				conn = DbConn.reGetConnection(conn,eemDb);			
				ccmDate = new EEMApplDao().getCCMDate(conn, sessionHelper.getMfId()); 
				
				if(!ccmDate.equals("")){
					ccmDate = DateUtil.formatMmDdYyyy(ccmDate+"01");
				}
			} catch (Exception e) {
				throw new ApplicationException(e);
			} finally {
				try {
					if (conn != null)
						conn.close();
				} catch(Exception e) {
				}
			}
//			logger.info("Value of getCcmDate: " + ccmDate);
			logger.debug("Value of getCcmDate: " + ccmDate);
			logger.info(LoggerConstants.methodEndLevel());
			return ccmDate;
		}	
		// CMS 2019 changes- requirement 5-End
		/**AAH BasePlus Migration IFOX-00426351 START*/
		public String getLOBAAHQ(String prodId, String effDate) {
			logger.info(LoggerConstants.methodStartLevel(null));
			String lob = "";
			prodId = "LOB"+StringUtil.nonNullTrim(prodId);
			
			effDate = DateFormatter.reFormat(StringUtil.nonNullTrim(effDate), DateFormatter.MM_DD_YYYY,
					DateFormatter.YYYYMMDD);
			logger.debug("PROD ID:"+prodId+":: EFF DATE"+effDate);
			// get em profile
			try {
				SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
				String eemDb = (String) sessionHelper.getAttribute(SessionManager.EEMDB);
				lob = EEMProfileSettings.getProfileText(eemDb, sessionHelper.getMfId(), prodId, effDate);
			} catch (Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				e.printStackTrace();
			}
			logger.info(LoggerConstants.methodEndLevel(null));
			return lob;
		}
		/**AAH BasePlus Migration IFOX-00426351 END*/
		
		
		
		// IFOX-00427238 : START /*June 2020 CMS changes - start*/
		public String getTrrDataFlag(String memberId, String replyCd) throws ApplicationException {
			logger.info(LoggerConstants.methodStartLevel());
			String isValid = "";
			/*boolean isValid = false;*/
			Connection conn = null;
			try {
				conn = DbConnWeb.getConnection();
				SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
				AjaxHelper.validateUser(sessionHelper, conn);
				String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
				conn = DbConn.reGetConnection(conn,eemDb);			
				isValid = new EEMDao().getTrrDataFlag1(conn, sessionHelper.getMfId(),memberId,replyCd); 
			} catch (Exception e) {
				throw new ApplicationException(e);
			} finally {
				try {
					if (conn != null)
						conn.close();
				} catch(Exception e) {
				}
			}
			logger.info(LoggerConstants.methodEndLevel());
			return isValid;
		}
		// IFOX-00427238 : END/*June 2020 CMS changes - end*/
		//IFOX - 431608 : CMS Changes 2020 - start
		public String trigger92TXN(String memberId) throws ApplicationException {
			logger.info(LoggerConstants.methodStartLevel());
			String msg = null;
			Connection conn = null;
			try {
				conn = DbConnWeb.getConnection();
				SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
				AjaxHelper.validateUser(sessionHelper, conn);
				String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
				conn = DbConn.reGetConnection(conn,eemDb);			
				int result = new EEMEnrollService().demographicTriggerCheck(conn, null, null, sessionHelper.getUserId(),
						sessionHelper.getMfId(), memberId,true,null) ;
				if(result == 1)
					msg ="Could not trigger 92TXN. Enrollment segment does not exist for the member";
				else if(result ==0)
					msg ="92 TXN triggered successfully";
				else if ( result == -1)
					msg ="92 TXN already exists for the member";
				else 
					msg = "Could not trigger 92 TXN";
			} catch (Exception e) {
				throw new ApplicationException(e);
			} finally {
				try {
					if (conn != null)
						conn.close();
				} catch(Exception e) {
				}
			}
			logger.info(LoggerConstants.methodEndLevel());
			return msg;
		}
		//IFOX - 431608 : CMS Changes 2020 - end
}