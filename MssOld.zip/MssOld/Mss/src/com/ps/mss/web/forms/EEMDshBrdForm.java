/*
 * $Id: EEMDshBrdForm.java,v 1.1 2014/06/26 07:55:48 praveen Exp $
 */
package com.ps.mss.web.forms;

import java.util.List;

/**
 * @author Raghu Gorur
 *
 */
public class EEMDshBrdForm extends EEMForm {
	private String selectedSubMenuTab;
	
	private String customerId;
	private String applId;
	private String applStatus;
	private String dateRange;
	private String user;
	
	private List lstDashBoard;
	private List lstDshBrdDrill;
	private List lstDshBrdWrkld;
	
	/**
	 * @return Returns the customerId.
	 */
	public String getCustomerId() {
		return customerId;
	}
	/**
	 * @param customerId The customerId to set.
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	/**
	 * @return Returns the applStatus.
	 */
	public String getApplStatus() {
		return applStatus;
	}
	/**
	 * @param applStatus The applStatus to set.
	 */
	public void setApplStatus(String applStatus) {
		this.applStatus = applStatus;
	}
	/**
	 * @return Returns the dateRange.
	 */
	public String getDateRange() {
		return dateRange;
	}
	/**
	 * @param dateRange The dateRange to set.
	 */
	public void setDateRange(String dateRange) {
		this.dateRange = dateRange;
	}
	/**
	 * @return Returns the lstDashBoard.
	 */
	public List getLstDashBoard() {
		return lstDashBoard;
	}
	/**
	 * @param lstDashBoard The lstDashBoard to set.
	 */
	public void setLstDashBoard(List lstDashBoard) {
		this.lstDashBoard = lstDashBoard;
	}
	/**
	 * @return Returns the lstDshBrdDrill.
	 */
	public List getLstDshBrdDrill() {
		return lstDshBrdDrill;
	}
	/**
	 * @param lstDshBrdDrill The lstDshBrdDrill to set.
	 */
	public void setLstDshBrdDrill(List lstDshBrdDrill) {
		this.lstDshBrdDrill = lstDshBrdDrill;
	}
	/**
	 * @return Returns the applId.
	 */
	public String getApplId() {
		return applId;
	}
	/**
	 * @param applId The applId to set.
	 */
	public void setApplId(String applId) {
		this.applId = applId;
	}
	/**
	 * @return Returns the selectedSubMenuTab.
	 */
	public String getSelectedSubMenuTab() {
		return selectedSubMenuTab;
	}
	/**
	 * @param selectedSubMenuTab The selectedSubMenuTab to set.
	 */
	public void setSelectedSubMenuTab(String selectedSubMenuTab) {
		this.selectedSubMenuTab = selectedSubMenuTab;
	}
	/**
	 * @return Returns the lstDshBrdWrkld.
	 */
	public List getLstDshBrdWrkld() {
		return lstDshBrdWrkld;
	}
	/**
	 * @param lstDshBrdWrkld The lstDshBrdWrkld to set.
	 */
	public void setLstDshBrdWrkld(List lstDshBrdWrkld) {
		this.lstDshBrdWrkld = lstDshBrdWrkld;
	}
	/**
	 * @return Returns the user.
	 */
	public String getUser() {
		return user;
	}
	/**
	 * @param user The user to set.
	 */
	public void setUser(String user) {
		this.user = user;
	}
}
