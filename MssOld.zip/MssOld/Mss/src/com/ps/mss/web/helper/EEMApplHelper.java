/*
 * $Id: EEMApplHelper.java,v 1.15 2016/09/22 17:15:28 dinesh Exp $
 */
package com.ps.mss.web.helper;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import com.ps.mss.dynaCache.EEMDynaCache;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EEMApplService;
import com.ps.mss.dao.DaoFactory;
import com.ps.mss.dao.EEMApplDao;
import com.ps.mss.dao.model.EEMApplAttestationVO;
import com.ps.mss.dao.model.EEMApplCommentsVO;
import com.ps.mss.dao.model.EmMbrEnrollmentVO;
import com.ps.mss.dao.model.EmPresetVo;
import com.ps.mss.db.CodeCache;
import com.ps.mss.db.EEMCodeCache;
import com.ps.mss.db.EEMProfileSettings;
import com.ps.mss.db.MBD;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.model.EEMApplicationVO;
import com.ps.mss.model.EEMContext;
import com.ps.mss.model.EEMErrorVO;
import com.ps.mss.model.EEMOriginalApplicationVO;
import com.ps.mss.model.EEMProfileItem;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.forms.EEMApplForm;
import com.ps.text.DateFormatter;
import com.ps.util.DateMath;
import com.ps.util.DateUtil;
import com.ps.util.ListBoxItem;
import com.ps.util.NameValuePair;
import com.ps.util.StringUtil;

/**
 * @author Raghu Gorur
 * 
 * Functions used for EEM modules
 */
public class EEMApplHelper {

	private static Properties prop;
	private static Logger logger=LoggerFactory.getLogger(EEMApplHelper.class);
	public static void saveEEMForm(SessionHelper sessionHelper, EEMApplForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		sessionHelper.setAttribute("SaveEEMApplForm",form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	public static EEMApplForm getEEMForm(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (EEMApplForm)sessionHelper.getAttribute("SaveEEMApplForm");
	}
	
	public static String getProperty(String sKey) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String sValue = null;
		FileInputStream propFile = null;
		try {
			if (prop == null) {
				prop = new Properties();
				propFile = new FileInputStream("EEMProperties.properties");
				prop.load(propFile);
			}

			sValue = prop.getProperty(sKey);
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			try {
				if(propFile != null)
					propFile.close();
			} catch (IOException e) {
				throw new ApplicationException(e);
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return sValue;
	}

	public static String getPage(EEMApplForm eemApplForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String sApplType = StringUtil.nonNullTrim(eemApplForm.getApplType());
		String sPage = null;
		if(sApplType.equals(EEMConstants.OPTION_APPLNEWMBR_MA)) {
			sPage = EEMConstants.EEM_APPLNEWMBR_MA; 
		} else if (sApplType.equals(EEMConstants.OPTION_APPLNEWMBR_PD)) {
			sPage = EEMConstants.EEM_APPLNEWMBR_PD;
		} else if (sApplType.equals(EEMConstants.OPTION_CNTRCHG_MA)) {
			sPage = EEMConstants.EEM_CNTRCHG_MA;
		} else if (sApplType.equals(EEMConstants.OPTION_CNTRCHG_PD)) {
			sPage = EEMConstants.EEM_CNTRCHG_PD;
		} else
			sPage = EEMConstants.EEM_APPL;
		logger.info(LoggerConstants.methodEndLevel());
		return sPage;
	}

	public static void setApplFormList(EEMApplForm eemApplForm,
			SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		//Implementing DynaCache for performance :start
		//EEMCodeCache objCache = EEMCodeCache.getInstance();
		/**Added new validation for customer ID: START*/
		String customerId = StringUtil.nonNullTrim(sessionHelper.getMfId());
		/**Added new validation for customer ID: END*/
		EEMCodeCache objCache = EEMDynaCache.getDynaCacheMap();
				
		//Implementing DynaCache for performance :end
		/** Triple S BasePlus Migration START **/
		/* Fix for IFOX-00378075 -- START*/
		eemApplForm.setParamcd((String)sessionHelper.getAttribute("MEDIINDVALUE"));
		/* Fix for IFOX-00378075 -- END*/
		/** Triple S BasePlus Migration END **/
		eemApplForm.setLstApplType(objCache.getLstApplType());
		eemApplForm.setLstPrefix(objCache.getLstPrefix());
		eemApplForm.setLstStates(objCache.getLstStates());
		eemApplForm.setLstCountry(objCache.getLstCountry());
		/** Triple S BasePlus Migration START **/
		// TSA : Spanish Language Change :start
		String corrLang = sessionHelper.getAttribute("CORRLANG").toString();
		if (corrLang.equalsIgnoreCase("SPA")){
			eemApplForm.setLstLanguages(objCache.getTsaLstLanguages(corrLang));
		}else
			eemApplForm.setLstLanguages(objCache.getLstLanguages());
		// TSA : Spanish Language Change :End
		/** Triple S BasePlus Migration END **/
		/**
		 * BasePlus County Changes - Start
		 * author - swagat
		 */
		
		if(eemApplForm.getPerZip5()!=null)
		{
			eemApplForm.setLstCounty(objCache.getLstCounty(eemApplForm.getPerZip5(), eemApplForm.getPerZip4()));
		}
		else
		{
			eemApplForm.setLstCounty(new ArrayList());
		}
			

		
		if(eemApplForm.getPerZip5()!=null)
		{
			eemApplForm.setLstCity(objCache.getLstCity(eemApplForm.getPerZip5(), eemApplForm.getPerZip4(),eemApplForm.getPerCounty()));
		}
		else
		{
			eemApplForm.setLstCity(new ArrayList());
		}
		
				/**
		 * BasePlus County Changes - End
		 * author - swagat
		 */
			
		eemApplForm.setLstLanguages(objCache.getLstLanguages());
		eemApplForm.setLstAltCorrespondences(objCache.getLstAltCorrespondences());
		eemApplForm.setLstPWOptions(objCache.getLstPWOptions());
		eemApplForm.setLstElectionTypes(objCache.getLstElectionTypes());
		eemApplForm.setLstSepExceptions(objCache.getLstSepExceptions());
		eemApplForm.setLstRelations(objCache.getLstRelations());
		eemApplForm.setLstAgentTypes(objCache.getLstAgentTypes());
		//NEw agent Lookup CR 00415856- start
		eemApplForm.setLstAgencyTypes(objCache.getLstAgencyTypes());
		//NEw agent Lookup CR  00415856- end
		//eemApplForm.setLstEnrollSrce(objCache.getLstEnrollSrce());
		eemApplForm.setLstEnrollSrce(objCache.getEnrollSrceListForPlan(EmMbrEnrollmentVO.MBR_SRCE_APPL));
		eemApplForm.setLstPCO(objCache.getLstPCO());
		eemApplForm.setLstSepReasons(objCache.getLstSEPReasons());
		eemApplForm.setLstApplStatus(objCache.getLstApplStatus());
		/**Added new validation for customer ID: START*/
		eemApplForm.setLstApplCategory(objCache.getLstApplCategory(customerId));
		/**Added new validation for customer ID: END*/
		 /**
		 * Cambia_Application Cancellation- Start
		 */
		eemApplForm.setDate(eemApplForm.getFrmtDate());
		eemApplForm.setReasonList(objCache.getRejectReasonList(sessionHelper.getMfId()));
		 /**
		 * Cambia_Application Cancellation- End
		 */
		 /**
	     * Cambia_PRE-SET NOTES - Start
	     */
	     
	   
		eemApplForm.setPreSetNoteList(objCache.getHmPreSetNotes(sessionHelper.getMfId()));
	    
		// Performance Changes -Start
	    /*if(eemApplForm.getPreSetNoteList().size() > 0){
	    	EmPresetVo pre = (EmPresetVo)eemApplForm.getPreSetNoteList().get(0);
	    	eemApplForm.setMaxId(pre.getMaxId());
	   
			sessionHelper.setAttribute("PresetMaxId", pre.getMaxId());
			
	    }*/
		// Performance Changes -End
	
		 /**
	     * Cambia_PRE-SET NOTES- End
	     */
	    /**
		 * Cambia_OevProcess-start
		 */
		eemApplForm.setOevCallStatusDrop(objCache.getLstOevCallStatus(sessionHelper.getMfId()));
		eemApplForm.setOevCallSubReasonDrop(objCache.getLstOevCallSubsetReason(sessionHelper.getMfId()));
		/**
		 * Cambia_OevProcess-end
		 */
		/**
  		 * 024_LEP-ApplicationEntrySide-Iteration1_LeftOverScope - Start 1
  		 */
  	    
  		eemApplForm.setValidStatus(objCache.getLstAttestStatus());
  		eemApplForm.setBrkInCoverageType(objCache.getBreakInCoverageTypeList());
  		
  		/*LEP CR Changes Start.*/
  		eemApplForm.setRespType(objCache.getRespTypeList());
		/*LEP CR Changes End.*/
  		
  		eemApplForm.setLepNunCmoStstus(objCache.getLstLepNunCmoStatus());
  	    /**
  		 * 024_LEP-ApplicationEntrySide-Iteration1_LeftOverScope - End 1
  		 */
		if (sessionHelper.isEEMSupervisor()) {
			eemApplForm.setLstUsrApplStatus(objCache.getLstMgrApplStatus());
		} else {
			eemApplForm.setLstUsrApplStatus(objCache.getLstUsrApplStatus());
		}
		eemApplForm.setCustomerId(sessionHelper.getMfId());
		eemApplForm.setCustomerNbr(sessionHelper.getCustomerNumber());
		eemApplForm.setOperId(sessionHelper.getUserId());
		
		eemApplForm.setElectionDesc(objCache.getListBoxDesc(eemApplForm
					.getElectionType(), objCache.getLstElectionTypes()));
		/**UseCaseName 015_Highmark_SUC_Denials for Enrollment and Disenrollment - Start  */
		eemApplForm.setApplDenialReasons(objCache.getLstApplDenialReasons(sessionHelper.getMfId()));
		//IFOX - 431608 : CMS Changes 2020 - start
		eemApplForm.setAppDenialReasonsESRD(objCache.getLstApplDenialReasonsWithoutESRD(sessionHelper.getMfId()));
		//IFOX - 431608 : CMS Changes 2020 -end
		//Modified for displaying correct Denial Received Date
		//eemApplForm.setDenialDateFrmt(eemApplForm.getFrmtDate());
		//eemApplForm.setDenialDateFrmt(DateFormatter.reFormatFiltered(eemApplForm.getDenialDate(), DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		
		/**UseCaseName 015_Highmark_SUC_Denials for Enrollment and Disenrollment - End  */
		/**
		 * Cambia-ACH Banking Data-Start
		 */
		eemApplForm.setAchLstActType(objCache.getLstAccountType());
		eemApplForm.setAchLstBillPayMethod(objCache.getLstBillPayMethod());
		eemApplForm.setAchLstBillFrequency(objCache.getLstBillFrequency());
		/**
		 * Cambia-ACH Banking Data-End
		 */
		/**
		 * Cambia LIS -Start
		 */
		eemApplForm.setValidLiPercents(objCache.getLstLiPercents());
		eemApplForm.setValidLiCopays(objCache.getLstLiCopays());
		/**
		 * Cambia LIS -End
		 */

		//IFOX-414925 Network ID CR - Start
		if(sessionHelper.getAttribute(EEMProfileSettings.LOB_VALD)!= null)
			eemApplForm.setLobValidation(sessionHelper.getAttribute(EEMProfileSettings.LOB_VALD).toString());
		//IFOX-414925 Network ID CR - End 		
		
		// Convert all the fields in to Upper Case
		convertToUpper(eemApplForm);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void convertToUpper(EEMApplForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Get the Form class
			Class objClass = Class.forName(EEMConstants.EEM_APPLFORM_CLASS);

			// Loop through all the fields
			Field[] arrField = objClass.getDeclaredFields();
			for (int i = 0; i < arrField.length; i++) {
				Field field = arrField[i];
				field.setAccessible(true);
				
				// Check for fields of String type
				if (field.getType().toString().equals("class java.lang.String")) {
					Object val = field.get(form);
					if (val != null) {
						// Set the variable
						field.set(form, StringUtil.nonNullTrim(val.toString()).toUpperCase());
					}
				}
			}

		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void setFormToVO(EEMApplForm eemFormAppl,
			EEMApplicationVO filterVO, SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try{	
			BeanUtils.copyProperties(filterVO, eemFormAppl);
			filterVO.setEligOverrideInd(checkEligOverrideInd(filterVO));
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	private static String checkEligOverrideInd(EEMApplicationVO objVO){
		logger.info(LoggerConstants.methodStartLevel(null));
		MBD mbd = objVO.getMbd();
		String prtAStDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getPartAEffDt()));
		String prtAEndDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtAEntitleEndDate()));
		String prtBStDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getPartBEffDt()));
		String prtBEndDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtBEntitleEndDate()));
		
		String prtAMbd = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtAEntitleDate()));
		String prtBMbd = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtBEntitleDate()));
		String prtDMbd = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtDEligibleDate()));
		String prtDDate = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getPartDEffDt()));
		

		if((StringUtil.nonNullTrim(prtAStDt).equalsIgnoreCase(StringUtil.nonNullTrim(prtAMbd)) && !StringUtil.nonNullTrim(prtAStDt).equals("")) &
				(StringUtil.nonNullTrim(prtBStDt).equalsIgnoreCase(StringUtil.nonNullTrim(prtBMbd)) && !StringUtil.nonNullTrim(prtBStDt).equals("") ) &
				(StringUtil.nonNullTrim(prtDDate).equalsIgnoreCase(StringUtil.nonNullTrim(prtDMbd)) && !StringUtil.nonNullTrim(prtDDate).equals("") )){
			logger.info(LoggerConstants.methodEndLevel("Return N, If PartA Start Date is equal to PartA MBD date And Part A Start Date is not Empty"));
			return "N";
		} else {
			logger.info(LoggerConstants.methodEndLevel("Return Y, If PartA Sstart Date is notEqual to PartA MBD date And Part A Start Date is be Empty"));
			return "Y";
		}
	}
	
	public static void setVOToForm(EEMApplicationVO filterVO,
			EEMApplForm eemFormAppl, SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try{	
			BeanUtils.copyProperties(eemFormAppl, filterVO);
			setApplFormList(eemFormAppl, sessionHelper);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void setSearchVOToForm(EEMApplicationVO filterVO, EEMApplForm eemFormAppl) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());	
		eemFormAppl.setSearchHicNo(StringUtil.nonNullTrim(filterVO.getSearchHicNo()));
		eemFormAppl.setSearchLastName(StringUtil.nonNullTrim(filterVO.getSearchLastName()));
		eemFormAppl.setSearchBirthDt(StringUtil.nonNullTrim(filterVO.getSearchBirthDt()));
		eemFormAppl.setSearchApplId(StringUtil.nonNullTrim(filterVO.getSearchApplId()));
		eemFormAppl.setSearchStatus(StringUtil.nonNullTrim(filterVO.getSearchStatus()));
		logger.info(LoggerConstants.methodEndLevel());	
	}

	public static boolean checkLockInd(Connection conn, EEMApplForm eemApplForm,
			SessionHelper sessionHelper, EEMContext context) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		boolean valid = false;
		
		// Get the lock indicator for the current status
		String lockInd = context.getService().getLockInd(conn, eemApplForm.getCurrStatus());
		
		// Check for Lock
		if (sessionHelper.isEEMSupervisor()) {// Manager
			if (lockInd.equals("M") || lockInd.equals("L") ||
					lockInd.equals("I") || lockInd.equals("")) {
				valid = true;
			}
		} else {// User
			if (!lockInd.equals("M")) {
				valid = true;
			}
		}
		
		// Check for valid
		if (!valid) {
			eemApplForm.setMessage("User doesnot have permission to Update when status is "
							+ eemApplForm.getCurrStatus());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return valid;
	}
	
	public static void loadLookUps(Connection conn, EEMApplForm eemApplForm,
			SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			EEMApplDao eemDao = new EEMApplDao();
			if (!StringUtil.nonNullTrim(eemApplForm.getReqDtCov()).equals("")) {
				eemApplForm.setLstInstitutes(eemDao.getInstLookUp(conn, sessionHelper
						.getMfId(), eemApplForm.getReqDtCov(),eemApplForm.getEnrollLineOfBusiness()));//AAH BasePlus Migration IFOX-00426351 Changes
			}
			
			// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - Start
			// 2017-10-30|Kishore changed the logic to have signDt as optional if profile option is R
		//	if (!StringUtil.nonNullTrim(eemApplForm.getSignDt()).equals("")) {
			    String effDate = eemApplForm.getSignDt();
				//get em profile
				try{
					EEMProfileItem item = EEMProfileSettings.getProfileObject(
							eemDb, sessionHelper.getMfId(), EEMProfileSettings.AGENTDT);			
					if("R".equalsIgnoreCase(item.getProfileValue())){
					    effDate = eemApplForm.getReqDtCov();
					}
				}catch(Exception e){
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					//e.printStackTrace();
				}
				if(!"".equalsIgnoreCase(StringUtil.nonNullTrim(effDate))) {
					eemApplForm.setLstAgencyIds(eemDao.getLstAgencies(conn, sessionHelper
							.getMfId(),effDate, eemApplForm.getEnrollLineOfBusiness()));//AAH BasePlus Migration IFOX-00426351 Changes
					eemApplForm.setLstBrokAgentIds(eemDao.getLstBrokAgents(conn, 
								sessionHelper.getMfId(), eemApplForm.getBrokerType(),
								eemApplForm.getCommAgencyId(), effDate, eemApplForm.getEnrollLineOfBusiness()));//AAH BasePlus Migration IFOX-00426351 Changes
				}
		//	}
			// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - End
			
			eemApplForm.setLstSearch((List) sessionHelper
					.getAttribute(EEMConstants.SESSION_APPL_SEARCH));
			if (eemApplForm.getLstErrors() == null
					|| eemApplForm.getLstErrors().size() == 0) {
				eemApplForm.setLstErrors((List) sessionHelper
						.getAttribute(EEMConstants.SESSION_APPL_ERRORS));
			}
			eemApplForm.setElgOveride(EEMProfileSettings
					.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),
							EEMProfileSettings.ELGOVERIDE));
			
			
			
			eemApplForm.setIsSubscriberIdRequired(EEMProfileSettings
					.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),
							"SUBSCID"));
			/** Triple S BasePlus Migration START **/		
//TSA Changes :Start	
			
			eemApplForm.setIsSubscriberIdMandatory(EEMProfileSettings
					.getCalendarProfileText(eemDb, sessionHelper.getMfId(),
							"SUBSCID"));
//TSA Changes :End
		/** Triple S BasePlus Migration END **/
		
			// IFOX-00381706 - COB Fix CR Summacare - Start
			eemApplForm.setIsInCmpltCOB(EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),"INCMPLTCOB"));
			// IFOX-00381706 - COB Fix CR Summacare - End
			
			
			logger.debug("Subscriber Id returned " +eemApplForm.getIsSubscriberIdRequired());
		} catch(Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void setApplicationStatus(EEMApplForm eemApplForm, SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String currStatus = StringUtil.nonNullTrim(eemApplForm.getCurrStatus());
		EEMCodeCache objCache = EEMCodeCache.getInstance();
		if (!currStatus.equals("")) {
			List lstStatus = null;
			if (sessionHelper.isEEMSupervisor()) {
				lstStatus = objCache.getLstMgrApplStatus();
			} else {
				lstStatus = objCache.getLstUsrApplStatus();
			}
			boolean found = false;
			for (int i = 0; i < lstStatus.size(); i++) {
				NameValuePair nvp = (NameValuePair)lstStatus.get(i);
				if (currStatus.equals(nvp.getName())) {
					found = true;
					eemApplForm.setApplStatus(currStatus);
					break;
				}
			}
	
			if (!found) {
				eemApplForm.setApplStatus("READY");
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static List validateUpdateFields(Connection conn, String eemDb, EEMApplService service,
			EEMApplicationVO filterVO, List lstFields) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		List lstErrors = new ArrayList();
		EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
		String checkMedicaid = "";
		filterVO.setCurrentPlan(eemDao.getPlanType(conn, filterVO));
		try {
			 checkMedicaid = EEMProfileSettings.getCalendarProfileItem(eemDb, 
					 filterVO.getCustomerId(),EEMProfileSettings.MEDICAID);
			//CR-IFOX-00408061. START. Functionality not Approved
			 /*filterVO.setDentalApplFlag(EEMProfileSettings.getCalendarProfileItem(eemDb, 
					 filterVO.getCustomerId(),EEMProfileSettings.DENTALAPP));*/
			//CR-IFOX-00408061. END
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
		}
		
		// Check Eligibility
		EEMErrorVO objError = service.validateEligibility(conn, eemDb, filterVO, lstFields);
		if (objError != null) {
			lstErrors.add(objError);
		}
		
		
		/*// Check duplicate Enrollment
		objError = service.checkDupilcateEnrollment(conn, filterVO, lstFields);
		if (objError != null) {
			lstErrors.add(objError);
		}*/

		// Check Requested Date of Coverage
		objError = service.checkReqDtCov(conn, eemDb, filterVO, lstFields);
		if (objError != null) {
			lstErrors.add(objError);
		}
		
		objError = service.checkSupplId(conn, eemDb, filterVO, lstFields);
		if (objError != null) {
			lstErrors.add(objError);
		}
		objError = service.checkDuplSupplId(conn, eemDb, filterVO, lstFields);
		if (objError != null) {
			lstErrors.add(objError);
		}
		// Check Enrolling Product
		objError = service.checkEnrollProduct(conn, eemDb, filterVO, lstFields);
		boolean validProduct = true;
		if (objError != null) {
			validProduct = false;
			lstErrors.add(objError);
		}
		
		// Check RxId
		objError = service.checkRxId(conn, eemDb, filterVO, lstFields); 
		if (objError != null) {
			lstErrors.add(objError);
		}
		
		// Check Election Type
		objError = service.checkElectionType(conn, eemDb, filterVO, lstFields); 
		if (objError != null) {
			lstErrors.add(objError);
		}
		
		// Check Application Date
		objError = service.checkApplDate(conn, eemDb, filterVO, lstFields); 
		if (objError != null) {
			lstErrors.add(objError);
		}
		// IFOX-00400051 app will go to RFI status based on the DB config, no spl handling is required
		// Check Signature Date
//		objError = service.checkSignatureDate(conn, eemDb, filterVO, lstFields); 
//		if (objError != null) {
//			lstErrors.add(objError);
//		}

		// Check for ESRD Ind
		//IFOX - 431608 : CMS Changes 2020 - start
		String reqDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(filterVO.getReqDtCov()));
		if(DateMath.isLessThan(reqDt, "20210101")||
				filterVO.getEnrollPlanDesgn().equals(EEMConstants.PLAN_DESGN_CO)||
				filterVO.getEnrollPlanDesgn().equals(EEMConstants.PLAN_DESGN_COPD)){
		
			if(filterVO.getApplType().equalsIgnoreCase(EEMConstants.OPTION_APPLNEWMBR_MA)){
				objError = service.checkEsrdInd(conn, eemDb, filterVO, lstFields, validProduct); 
				if (objError != null) {
					lstErrors.add(objError);
				}
				
				// Check for ESRD Override Indicator
				objError = service.checkEsrdOverrideInd(conn, filterVO, lstFields); 
				if (objError != null) {
					lstErrors.add(objError);
				}
			}
		}
		//IFOX - 431608 : CMS Changes 2020 - end
		// Check for Election Reason Code
		objError = service.checkElcReasonCd(conn, filterVO, lstFields); 
		if (objError != null) {
			lstErrors.add(objError);
		}
		
		// Check for LTC facility Id
		objError = service.checkLTCFacility(conn, filterVO, lstFields); 
		if (objError != null) {
			lstErrors.add(objError);
		}
		

		if(!"N".equalsIgnoreCase(checkMedicaid)){
		
			//  IFOX-00380952, IFOX-00381707: Medicaid ID & ELGWARNING Apps to Suppend Fix -- Start
			if (filterVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_MA) || 
					filterVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_PD)){
			objError = service.checkMedicaidId(conn, filterVO, lstFields); 
				if (objError != null) {
					lstErrors.add(objError);
				}
			}
			//  IFOX-00380952, IFOX-00381707: Medicaid ID & ELGWARNING Apps to Suppend Fix -- Start
		}
		
		// PCP performance issue 
		List lstPcpErors = service.checkProviderDates(conn, eemDb, filterVO, lstFields);
		if (lstPcpErors != null ) {
			Iterator iter = lstPcpErors.iterator();  
			while (iter.hasNext())  
			{  
				lstErrors.add(iter.next());   
				
			} 
		
		}
		
		//Agent Performance Issue
		List agentErrors =  service.validateAgent(conn, eemDb, filterVO, lstFields);
		
		if (agentErrors != null) {
			Iterator iter = agentErrors.iterator();  
			while (iter.hasNext())  
			{  
				lstErrors.add(iter.next());   
				
			} 
		
		}
		objError = service.checkActiveAgent(conn, eemDb, filterVO, lstFields);
		if (objError != null) {
			lstErrors.add(objError);
		}
		objError = service.checkInvalidAgency(conn, eemDb, filterVO, lstFields);
		if (objError != null) {
			lstErrors.add(objError);
		}
		
		// IFOX-00382607: Retro Application CR - Start
		// Check duplicate Application - Brought this method below as the Error weightage is more
		if (!"Y".equalsIgnoreCase(filterVO.getAppDuplicateCheck())) {
			objError = service.checkDuplcateApplication(conn, filterVO, lstFields);
			//CR-IFOX-00408061. START Functionality not Approved
			/*filterVO.setAppDuplicateCheck("Y");*/
			//CR-IFOX-00408061. END
			 if (objError != null) {
			    lstErrors.add(objError);
			}
		}
		
		if ("CMA".equalsIgnoreCase(filterVO.getApplType())
				&& "Y".equalsIgnoreCase(filterVO.getAppDuplicateCheck())) {
			// Check duplicate Application
			objError = service.checkDupilcateEnrollmentNew(conn, filterVO,
					lstFields);
			if (objError != null) {
				lstErrors.add(objError);
			}
		} else {
			objError = service.checkDupilcateEnrollment(conn, filterVO,
					lstFields);
			if (objError != null) {
				lstErrors.add(objError);
			}
		}
		
		
		
		objError = service.checkRetroAppl(conn, filterVO, lstFields);
		if (objError != null) {
			lstErrors.remove(objError);// Remove the duplicate, if list is having.
			lstErrors.add(objError);
		}
		// IFOX-00382607: Retro Application CR - End
		// Set the errors to form
		List lstMaster = filterVO.getLstErrors();
		if (lstErrors.size() > 0) {
			if (lstMaster == null) {
				lstMaster = new ArrayList();
			}
			lstMaster.addAll(lstErrors);	
		}
		logger.info(LoggerConstants.methodEndLevel());
		return lstMaster;
	}
	
	public static void formatMBD(MBD mbd, EEMApplForm eemForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMCodeCache cache = EEMCodeCache.getInstance();
		mbd.setBirthDate(DateFormatter.reFormat(DateFormatter.dateFilter(mbd.getBirthDate()),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setGenderCd(CodeCache.getShortGenderNumDesc(mbd.getGenderCd()));
		eemForm.setMbdState(cache.getDesc(mbd.getStateCd(), cache.getLstStates()));
		eemForm.setMbdCounty(cache.getCountyNameByCd(mbd.getStateCd(), mbd.getCountyCd()));
		mbd.setEsrdInd(setInd(mbd.getEsrdInd()));
		mbd.setEsrdStartDate(DateFormatter.reFormat(DateFormatter.dateFilter(mbd.getEsrdStartDate()),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setEsrdEndDate(DateFormatter.reFormat(DateFormatter.dateFilter(mbd.getEsrdEndDate()),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setInstInd(setInd(mbd.getInstInd()));
		mbd.setInstStartDate(DateFormatter.reFormat(DateFormatter.dateFilter(mbd.getInstStartDate()),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setInstEndDate(DateFormatter.reFormat(DateFormatter.dateFilter(mbd.getInstEndDate()),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setMedicInd(setInd(mbd.getMedicInd()));
		mbd.setMedicStartDate(DateFormatter.reFormat(DateFormatter.dateFilter(mbd.getMedicStartDate()),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setMedicEndDate(DateFormatter.reFormat(DateFormatter.dateFilter(mbd.getMedicEndDate()),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setHospiceInd(setInd(mbd.getHospiceInd()));
		mbd.setHospiceStartDate(DateFormatter.reFormat(DateFormatter.dateFilter(mbd.getHospiceStartDate()),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setHospiceEndDate(DateFormatter.reFormat(DateFormatter.dateFilter(mbd.getHospiceEndDate()),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setPrtAEntitleDate(DateFormatter.reFormatFiltered(mbd.getPrtAEntitleDate(),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setPrtAEntitleEndDate(DateFormatter.reFormatFiltered(mbd.getPrtAEntitleEndDate(),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setPrtBEntitleDate(DateFormatter.reFormatFiltered(mbd.getPrtBEntitleDate(),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setPrtBEntitleEndDate(DateFormatter.reFormatFiltered(mbd.getPrtBEntitleEndDate(),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setPrtDEligibleDate(DateFormatter.reFormatFiltered(mbd.getPrtDEligibleDate(),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setSubsidyStartDate1(DateFormatter.reFormatFiltered(mbd.getSubsidyStartDate1(),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setSubsidyEndDate1(DateFormatter.reFormatFiltered(mbd.getSubsidyEndDate1(),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		mbd.setDeathDate(DateFormatter.reFormatFiltered(mbd.getDeathDate(),
				DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY));
		
		eemForm.setMbd(mbd);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void setCommentList(EEMApplForm eemForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String[] arrComments = eemForm.getCommentRows();
		if(arrComments == null || arrComments.length == 0) {
			return;
		}
		
		String[] arrValues = null;
		String[] arrInsert = eemForm.getInsertRows();
		EEMApplCommentsVO objComment = null;
		List lstTemp = new ArrayList();
		for(int i = 0; i < arrComments.length; i++) {
			arrValues = splitValues(arrComments[i], "|");
			objComment = new EEMApplCommentsVO();
			objComment.setCreateTime(arrValues[0]);
			objComment.setCreateUserId(arrValues[1]);
			/**IFOX-00429319 START*/
			if(arrValues.length == 3)
				objComment.setApplComments(arrValues[2]);
			else
				objComment.setApplComments("");
			/**IFOX-00429319 END*/
			objComment.setInsert(arrInsert[i]);
			
			lstTemp.add(objComment);
		}
		
		eemForm.setLstComments(lstTemp);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	/*public static void setAttestationList(EEMApplForm eemForm) throws ApplicationException {
		String[] arrExceptions = eemForm.getSepException();
		String[] arrAttestDts = eemForm.getAttestDt();
		if(arrExceptions == null || arrAttestDts == null) {
			return;
		}
		
		EEMApplAttestationVO objAttest = null;
		List lstTemp = new ArrayList();
		for(int i = 0; i < arrExceptions.length; i++) {
			objAttest = new EEMApplAttestationVO();
			objAttest.setSepException(arrExceptions[i]);
			objAttest.setAttestDt(arrAttestDts[i]);
			objAttest.setIndex("" + i);
			lstTemp.add(objAttest);
		}
		
		eemForm.setLstAttestation(lstTemp);
	}*/

	public static EEMApplicationVO validateForm(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMApplForm eemFormAppl) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplicationVO filterVO = null;
		try {
			// Get the filter
			filterVO = context.getApplicationFilter();
	
			// Copy form values to filter
			EEMApplHelper.setFormToVO(eemFormAppl, filterVO, sessionHelper);
	
			// Get the form fields
			EEMApplService service = context.getService();
			List lstFields = service.getValidatingFormFields(
					EEMConstants.EEM_APPL_FORM, conn, sessionHelper.getMfId());
	
			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			// Validate with form values
			if (lstFields != null) {
				service.validateFormFields(conn, eemDb, lstFields, filterVO,
						EEMConstants.EEM_APPL_FILTER);
				// Validate specific fields
				filterVO.setLstErrors(validateUpdateFields(conn, eemDb, service, filterVO, lstFields));
				sessionHelper.getSession().setAttribute(
						EEMConstants.SESSION_APPL_ERRORS, filterVO.getLstErrors());
			}
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
			filterVO.setMessage("Error during Field Validation");
		}
		logger.info(LoggerConstants.methodEndLevel());
		return filterVO;
	}
	
	public static boolean isIncomplete(EEMApplForm eemApplForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		/**UseCaseName 015_Highmark_SUC_Denials for Enrollment and Disenrollment - Start  */
		String applStatus = StringUtil.nonNullTrim(eemApplForm.getApplStatus());
		if (applStatus.equals(EEMConstants.APPL_STATUS_DENIEDELG) ||
				applStatus.equals(EEMConstants.APPL_STATUS_DENIEDETYP) ||
				applStatus.equals(EEMConstants.APPL_STATUS_DENIEDOTHR)) {
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		/**UseCaseName 015_Highmark_SUC_Denials for Enrollment and Disenrollment - End  */
		
		if ((eemApplForm.getCurrStatus().equals(EEMConstants.APPL_STATUS_READY) || 
				eemApplForm.getCurrStatus().equals(EEMConstants.APPL_STATUS_INCOMPLETE)) && 
					eemApplForm.getApplStatus().equals(EEMConstants.APPL_STATUS_INCOMPLETE)) {
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}
		
		if (StringUtil.nonNullTrim(eemApplForm.getMbrHicNbr()).equals("") ||
				StringUtil.nonNullTrim(eemApplForm.getMbrLastName()).equals("") ||
				StringUtil.nonNullTrim(eemApplForm.getMbrFirstName()).equals("") ||
				StringUtil.nonNullTrim(eemApplForm.getReqDtCov()).equals("") ||
				StringUtil.nonNullTrim(eemApplForm.getEnrollProduct()).equals("") ||
				StringUtil.nonNullTrim(eemApplForm.getPerAdd1()).equals("") ||
				StringUtil.nonNullTrim(eemApplForm.getPerCity()).equals("") ||
				StringUtil.nonNullTrim(eemApplForm.getPerState()).equals("") ||
				StringUtil.nonNullTrim(eemApplForm.getPerZip5()).equals("") ) {
			
			eemApplForm.setApplStatus(EEMConstants.APPL_STATUS_INCOMPLETE);
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}
		logger.info(LoggerConstants.methodEndLevel());
		return false;
	}

	public static void loadFormDetails(Connection conn, String applType,
			EEMApplForm eemApplForm, SessionHelper sessionHelper)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		eemApplForm.setApplType(applType);
		EEMApplHelper.setApplFormList(eemApplForm, sessionHelper);
		EEMApplHelper.loadLookUps(conn, eemApplForm, sessionHelper);
		eemApplForm.setApplStatus(EEMConstants.APPL_STATUS_READY);
		if(eemApplForm.getReqDtCov() == null) {
			eemApplForm.setLstSearch(null);
			sessionHelper.getSession().setAttribute(EEMConstants.SESSION_APPL_SEARCH, null);
			eemApplForm.setLstErrors(null);
			sessionHelper.getSession().setAttribute(EEMConstants.SESSION_APPL_ERRORS, null);
		}
		/**AAH BasePlus Migration IFOX-00426351 START*/ 
		try {
			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			eemApplForm.setAllyAlignLTCQues(EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),EEMProfileSettings.LTC_QUES));
			String lobValidation 	=	EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(),EEMProfileSettings.LOB_VALD);
			eemApplForm.setLobValidation(lobValidation);	
			sessionHelper.setAttribute(EEMProfileSettings.LOB_VALD, lobValidation);
			logger.info("LOB Validation : "+lobValidation);
		/**AAH BasePlus Migration IFOX-00426351 END*/
	
		/*Access health PCP CR- Start */
		String npiInd = (String) sessionHelper.getAttribute("NPIIND");
		if(null == npiInd || npiInd.trim().equals(""))
		{
			npiInd = EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(), "NPIIND");
			sessionHelper.setAttribute("NPIIND", npiInd);
		}
		/*Access health PCP CR- End */
		
		}
		catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
			logger.debug("Error in fecting LOB_VALD profile option");
//			System.err.println("Error in fecting LOB_VALD profile option");
		}
		//End IFOX-00389053 
		logger.info(LoggerConstants.methodEndLevel());
	}
		
	
	// IFOX-00377758 -- Added the below method
	public static void resetMbrPersonalInfo(EEMApplForm eemApplForm)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		//reset personal details
		eemApplForm.setMbrApplNo("");
		//Added as fix for IFOX:  00386712 
		//eemApplForm.setMbrId("");
		//Added as fix for IFOX:  00386712 
		//eemApplForm.setAltMbrId("");
		eemApplForm.setMbrRxId("");
		eemApplForm.setMbrPhone("");
		eemApplForm.setMbrGender("");
		
		
		//reset personal details permanent and mailing address
		eemApplForm.setMbrEmail("");
	    eemApplForm.setPerAdd1("");
	    eemApplForm.setPerAdd2("");
	    eemApplForm.setPerAdd3("");
	    eemApplForm.setPerCity("");
	    eemApplForm.setPerState("");
	    eemApplForm.setPerZip5("");
	    eemApplForm.setPerZip4("");
	    eemApplForm.setPerCounty("");
	    eemApplForm.setPerPhone("");
	    eemApplForm.setPerCell("");
	    eemApplForm.setPerWorkPhone("");
	    eemApplForm.setPerFax("");
	    eemApplForm.setMailFirstName("");
	    eemApplForm.setMailMiddleName("");
	    eemApplForm.setMailLastName("");
	    eemApplForm.setMailAdd1("");
	    eemApplForm.setMailAdd2("");
	    eemApplForm.setMailAdd3("");
	    eemApplForm.setMailCity("");
	    eemApplForm.setMailState("");
	    eemApplForm.setMailZip5("");
	    eemApplForm.setMailZip4("");
	    eemApplForm.setMailCounty("");
	    eemApplForm.setMailCountry("");
	    eemApplForm.setMailSuffix("");
		//IFOX-00406767 -start
	    eemApplForm.setHealthPlanNews("");
		//IFOX-00406767 -end
	    //Added to reset Auth Rep Address for IFOX: 386712 : start
	    
	    eemApplForm.setAuthRepCity("");
	    eemApplForm.setAuthRepState("");
	    eemApplForm.setAuthRepStreet("");
	    eemApplForm.setAuthRepZip4("");
	    eemApplForm.setAuthRepZip5("");
	    eemApplForm.setAuthRepFirstName("");
	    eemApplForm.setAuthRepLastName("");
	    eemApplForm.setAuthRepMidName("");
	    eemApplForm.setAuthRepPhone("");
	    eemApplForm.setAuthRepRelation("");
	    eemApplForm.setPwOption("");
	    eemApplForm.setEmergName("");
	    eemApplForm.setEmergPhone("");
	    eemApplForm.setEmergRelation("");
	    // To Prevent Language Code Reset & Avoid AP049 Error from online - Start
	    //eemApplForm.setLanguage("");
	    // To Prevent Language Code Reset & Avoid AP049 Error from online - End
	  //  eemApplForm.setSpouseWork("");
	   	    
	    //Added to reset Auth Rep Address for IFOX: 386712 : end
	    
	   /* IFOX-00431133 -CMS Changes Start*/  
	   // eemApplForm.setDoYouWork("");
	    /* IFOX-00431133 -CMS Changes End*/  
	    
	    
	    //reset agent details
	    eemApplForm.setCommAgencyId("");
	    eemApplForm.setBrokAgentId("");
	    eemApplForm.setBrokerType("");
	    eemApplForm.setAgentDt("");
	    // Fix for IFOX-00378491 - Commented the below line
	    //eemApplForm.setApplCategory("");
	    
	    //reset application details
	    eemApplForm.setReceiptDate("");
	    eemApplForm.setSignDt("");
	    
	    
	    logger.info(LoggerConstants.methodEndLevel());
	}
	
	private static String[] splitValues(String source, String delimit) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String[] arrValues = null;
		StringTokenizer stk = new StringTokenizer(source, delimit);
		if (stk.countTokens() > 0) {
			int count = stk.countTokens();
			arrValues = new String[count];
			for(int i = 0; i < count; i++) {
				arrValues[i] = stk.nextToken();
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return arrValues;
	}
	
	private static String setInd(String value) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		if (value.equals("")) {
			logger.info(LoggerConstants.methodEndLevel());
			return "N";
		}
		logger.info(LoggerConstants.methodEndLevel());
		return value;
	}
	
	//original application start
	public static void setOrigVOToForm(EEMOriginalApplicationVO filterVO,
			EEMApplForm eemFormAppl, SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try{	
			BeanUtils.copyProperties(eemFormAppl, filterVO);
			setApplFormList(eemFormAppl, sessionHelper);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	// original appplication end
	
	//original application start
	public static void postPhoneOrder(EEMApplForm eemApplForm){
		logger.info(LoggerConstants.methodStartLevel());
		if(eemApplForm.getPerPhone()!=null){
        if(eemApplForm.getPerPhone().length()==10){
        	eemApplForm.setPerPhone(eemApplForm.getPerPhone().substring(0, 3)+"-"+eemApplForm.getPerPhone().substring(3, 6)+"-"+eemApplForm.getPerPhone().substring(6));
        }}
		if(eemApplForm.getPerWorkPhone()!=null){
        if(eemApplForm.getPerWorkPhone().length()==10){
        	eemApplForm.setPerWorkPhone(eemApplForm.getPerWorkPhone().substring(0, 3)+"-"+eemApplForm.getPerWorkPhone().substring(3, 6)+"-"+eemApplForm.getPerWorkPhone().substring(6));
        }}
		if(eemApplForm.getPerCell()!=null){
        if(eemApplForm.getPerCell().length()==10){
        	eemApplForm.setPerCell(eemApplForm.getPerCell().substring(0, 3)+"-"+eemApplForm.getPerCell().substring(3, 6)+"-"+eemApplForm.getPerCell().substring(6));
        }}
		if(eemApplForm.getPerFax()!=null){
        if(eemApplForm.getPerFax().length()==10){
        	eemApplForm.setPerFax(eemApplForm.getPerFax().substring(0, 3)+"-"+eemApplForm.getPerFax().substring(3, 6)+"-"+eemApplForm.getPerFax().substring(6));
        }}
		logger.info(LoggerConstants.methodEndLevel());
	}
//original application end



	public static void setAttestationList(EEMApplForm eemForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String[] arrExceptions = eemForm.getSepException();
		String[] arrAttestDts = eemForm.getAttestDt();
		/**
		  * Cambia_Election Logic - Start
		**/
		
		String[] attestIndicator = eemForm.getSepInd();
		String[] attestQuestionNo = eemForm.getSepQueNo();
				
		/**
		  * Cambia_Election Logic - End
		**/
		if(arrExceptions == null || arrAttestDts == null) {
			logger.info(LoggerConstants.methodEndLevel());
			return;
		}
		
		EEMApplAttestationVO objAttest = null;
		List lstTemp = new ArrayList();
		for(int i = 0; i < arrExceptions.length; i++) {
			objAttest = new EEMApplAttestationVO();
			objAttest.setSepException(arrExceptions[i]);
			objAttest.setAttestDt(arrAttestDts[i]);
			objAttest.setIndex("" + i);
			lstTemp.add(objAttest);
		}
		/**
		  *Cambia_Election Logic - Start
		**/
		
		if(attestQuestionNo != null ){
			for(int i=0; i < attestQuestionNo.length ; i++){
				if(attestQuestionNo[i] != null && !attestQuestionNo[i].equals("")){	
					objAttest = (EEMApplAttestationVO) lstTemp.get(i);
					objAttest.setValidInd(attestIndicator[i]);
					objAttest.setAttestQues(attestQuestionNo[i]);
					
				}
			
			}
		}
		
		/**
		  * Cambia_Election Logic - End
		**/
		
		eemForm.setLstAttestation(lstTemp);
		logger.info(LoggerConstants.methodEndLevel());
	}

}
