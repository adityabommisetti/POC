package com.ps.mss.web.forms;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import com.ps.mss.dao.model.DiscViewReconVO;
import com.ps.mss.dao.model.EmMbrDemographicVO;
import com.ps.mss.dao.model.McaidAnomSummDetailDataVO;
import com.ps.mss.model.DiscrepancyDashBoardVO;
import com.ps.mss.model.DiscrepancySummaryVOList;

/**
 * Form bean for a Struts application.
 * @version 	1.0
 * @author
 */
public class McaidReconAnomForm extends McaidReconBaseForm {

	
	/*private String pbpId;
	private String year;	
	private String quarter;
	private String month;
	
	private String total;
	private String open;
	private String inProgress;		
	private String forceClose;
	private String resolved;
	*/
	private List mcaidAnomDsbPBPLst;
	
	
	//-------------- Summary-------------------	
	
	private String summSrchPbp;
	private String summSrchYear;
	private String summSrchQtr;
	private String summSrchMonth;
	private String summSrchStatus;
	
	private String summPageLabel1;
	private String summPageLabel2;
	private int summSrchListRowSelect;
	
	//for Search
	private String summSrchGoPbp;
	private String summSrchGoStatus;
	private String summSrchType;
	private String summSrchMedicaidId;
	private String summSrchFromEffDate;
	private String summSrchToEffDate;
	private String summSrchFromUpdtDate;
	private String summSrchToUpdtDate;
	private String summSrchUpdtUserId;
	private String summSrchAnmlyCd;
	
	//State and plan value addition: start
	private String summSrchStateValue;
	private String summSrchPlanValue;
	//State and plan value addition: end
	
	private List summSrchPbpLst;
	private List summSrchStatusLst;
	private List summSrchTypeLst;
	
	//--Summary Page section-1- Anomaly List
	private List summAnomListLst;
	private List summAnomTotalLst;
	/**
	 * @return the summAnomTotalLst
	 */
	public List getSummAnomTotalLst() {
		return summAnomTotalLst;
	}


	/**
	 * @param summAnomTotalLst the summAnomTotalLst to set
	 */
	public void setSummAnomTotalLst(List summAnomTotalLst) {
		this.summAnomTotalLst = summAnomTotalLst;
	}
	private int summAnomLstPageNbr;
	private String summAnomLstPageType;
	
	//--Summary Page section-2	
	private McaidAnomSummDetailDataVO anomSummDetailDataVo = new McaidAnomSummDetailDataVO();
	
	private String changeStatus;
	private String changeComment;
	
	private String popupMsg = "";
	
	private List discrpDetailsLst;
	private List discrpDetailsTotalLst;
	
	// Details Status List
	private List summDetailStatusLst;
	public List getSummDetailStatusLst() {
		return summDetailStatusLst;
	}

	public void setSummDetailStatusLst(List summDetailStatusLst) {
		this.summDetailStatusLst = summDetailStatusLst;
	}

	public Map getSummDetailStatusChngLst() {
		return summDetailStatusChngLst;
	}

	public void setSummDetailStatusChngLst(Map summDetailStatusChngLst) {
		this.summDetailStatusChngLst = summDetailStatusChngLst;
	}

	private Map summDetailStatusChngLst;
	// Details Status List

	
	DiscViewReconVO discviewPVO = new DiscViewReconVO();
	DiscViewReconVO discviewSVO = new DiscViewReconVO();
	
	private String firstName;
	private String lastName;
	private String suppIdEffDate;
	private String recentSuppId;
	private String pbpId;
	private String effDate;
	
	private String summCmsPaid;
	private String summPlanExpected;
	private String summDataDiffrence;
	private List mcaidViewPymntDetailLst;
	private String medicaidId;
	private String diffrence;
	
	private String ViewPymtPageLabel;
	
	
	private String anamolyCategory;
	private List anamolyCategoryList;
	
	
	//------------------------------------------------
	/**
	 * @return the mcaidAnomDsbPBPLst
	 */
	public List getMcaidAnomDsbPBPLst() {
		return mcaidAnomDsbPBPLst;
	}

	/**
	 * @param mcaidAnomDsbPBPLst the mcaidAnomDsbPBPLst to set
	 */
	public void setMcaidAnomDsbPBPLst(List mcaidAnomDsbPBPLst) {
		this.mcaidAnomDsbPBPLst = mcaidAnomDsbPBPLst;
	}

	/**
	 * @return the summSrchPbp
	 */
	public String getSummSrchPbp() {
		return summSrchPbp;
	}

	/**
	 * @param summSrchPbp the summSrchPbp to set
	 */
	public void setSummSrchPbp(String summSrchPbp) {
		this.summSrchPbp = summSrchPbp;
	}

	/**
	 * @return the summSrchYear
	 */
	public String getSummSrchYear() {
		return summSrchYear;
	}

	/**
	 * @param summSrchYear the summSrchYear to set
	 */
	public void setSummSrchYear(String summSrchYear) {
		this.summSrchYear = summSrchYear;
	}

	/**
	 * @return the summSrchQtr
	 */
	public String getSummSrchQtr() {
		return summSrchQtr;
	}

	/**
	 * @param summSrchQtr the summSrchQtr to set
	 */
	public void setSummSrchQtr(String summSrchQtr) {
		this.summSrchQtr = summSrchQtr;
	}

	/**
	 * @return the summSrchMonth
	 */
	public String getSummSrchMonth() {
		return summSrchMonth;
	}

	/**
	 * @param summSrchMonth the summSrchMonth to set
	 */
	public void setSummSrchMonth(String summSrchMonth) {
		this.summSrchMonth = summSrchMonth;
	}

	/**
	 * @return the summSrchStatus
	 */
	public String getSummSrchStatus() {
		return summSrchStatus;
	}

	/**
	 * @param summSrchStatus the summSrchStatus to set
	 */
	public void setSummSrchStatus(String summSrchStatus) {
		this.summSrchStatus = summSrchStatus;
	}

	/**
	 * @return the summPageLabel1
	 */
	public String getSummPageLabel1() {
		return summPageLabel1;
	}

	/**
	 * @param summPageLabel1 the summPageLabel1 to set
	 */
	public void setSummPageLabel1(String summPageLabel1) {
		this.summPageLabel1 = summPageLabel1;
	}

	/**
	 * @return the summPageLabel2
	 */
	public String getSummPageLabel2() {
		return summPageLabel2;
	}

	/**
	 * @param summPageLabel2 the summPageLabel2 to set
	 */
	public void setSummPageLabel2(String summPageLabel2) {
		this.summPageLabel2 = summPageLabel2;
	}

	/**
	 * @return the summAnomListLst
	 */
	public List getSummAnomListLst() {
		return summAnomListLst;
	}

	/**
	 * @param summAnomListLst the summAnomListLst to set
	 */
	public void setSummAnomListLst(List summAnomListLst) {
		this.summAnomListLst = summAnomListLst;
	}

	/**
	 * @return the summAnomLstPageNbr
	 */
	public int getSummAnomLstPageNbr() {
		return summAnomLstPageNbr;
	}

	/**
	 * @param summAnomLstPageNbr the summAnomLstPageNbr to set
	 */
	public void setSummAnomLstPageNbr(int summAnomLstPageNbr) {
		this.summAnomLstPageNbr = summAnomLstPageNbr;
	}

	/**
	 * @return the summAnomLstPageType
	 */
	public String getSummAnomLstPageType() {
		return summAnomLstPageType;
	}

	/**
	 * @param summAnomLstPageType the summAnomLstPageType to set
	 */
	public void setSummAnomLstPageType(String summAnomLstPageType) {
		this.summAnomLstPageType = summAnomLstPageType;
	}
	

	/**
	 * @return the anomSummDetailDataVo
	 */
	public McaidAnomSummDetailDataVO getAnomSummDetailDataVo() {
		return anomSummDetailDataVo;
	}

	/**
	 * @param anomSummDetailDataVo the anomSummDetailDataVo to set
	 */
	public void setAnomSummDetailDataVo(
			McaidAnomSummDetailDataVO anomSummDetailDataVo) {
		this.anomSummDetailDataVo = anomSummDetailDataVo;
	}

	/**
	 * @return the summSrchListRowSelect
	 */
	public int getSummSrchListRowSelect() {
		return summSrchListRowSelect;
	}

	/**
	 * @param summSrchListRowSelect the summSrchListRowSelect to set
	 */
	public void setSummSrchListRowSelect(int summSrchListRowSelect) {
		this.summSrchListRowSelect = summSrchListRowSelect;
	}
	/* View Reconciliation - Start*/
	
	/**
	 * @return the discviewPVO
	 */
	public DiscViewReconVO getDiscviewPVO() {
		return discviewPVO;
	}
	/**
	 * @param discviewPVO the discviewPVO to set
	 */
	public void setDiscviewPVO(DiscViewReconVO discviewPVO) {
		this.discviewPVO = discviewPVO;
	}
	/**
	 * @return the discviewSVO
	 */
	public DiscViewReconVO getDiscviewSVO() {
		return discviewSVO;
	}
	/**
	 * @param discviewSVO the discviewSVO to set
	 */
	public void setDiscviewSVO(DiscViewReconVO discviewSVO) {
		this.discviewSVO = discviewSVO;
	} 
	
	/* View Reconciliation - End*/
	
	public String getChangeStatus() {
		return changeStatus;
	}

	public void setChangeStatus(String changeStatus) {
		this.changeStatus = changeStatus;
	}

	public String getChangeComment() {
		return changeComment;
	}

	public void setChangeComment(String changeComment) {
		this.changeComment = changeComment;
	}

	/**
	 * @return the popupMsg
	 */
	public String getPopupMsg() {
		return popupMsg;
	}

	/**
	 * @param popupMsg the popupMsg to set
	 */
	public void setPopupMsg(String popupMsg) {
		this.popupMsg = popupMsg;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the suppIdEffDate
	 */
	public String getSuppIdEffDate() {
		return suppIdEffDate;
	}

	/**
	 * @param suppIdEffDate the suppIdEffDate to set
	 */
	public void setSuppIdEffDate(String suppIdEffDate) {
		this.suppIdEffDate = suppIdEffDate;
	}

	/**
	 * @return the recentSuppId
	 */
	public String getRecentSuppId() {
		return recentSuppId;
	}

	/**
	 * @param recentSuppId the recentSuppId to set
	 */
	public void setRecentSuppId(String recentSuppId) {
		this.recentSuppId = recentSuppId;
	}

	/**
	 * @return the pbpId
	 */
	public String getPbpId() {
		return pbpId;
	}

	/**
	 * @param pbpId the pbpId to set
	 */
	public void setPbpId(String pbpId) {
		this.pbpId = pbpId;
	}

	

	/**
	 * @return the effDate
	 */
	public String getEffDate() {
		return effDate;
	}

	/**
	 * @param effDate the effDate to set
	 */
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}

	/**
	 * @return the summCmsPaid
	 */
	public String getSummCmsPaid() {
		return summCmsPaid;
	}

	/**
	 * @param summCmsPaid the summCmsPaid to set
	 */
	public void setSummCmsPaid(String summCmsPaid) {
		this.summCmsPaid = summCmsPaid;
	}

	/**
	 * @return the summPlanExpected
	 */
	public String getSummPlanExpected() {
		return summPlanExpected;
	}

	/**
	 * @param summPlanExpected the summPlanExpected to set
	 */
	public void setSummPlanExpected(String summPlanExpected) {
		this.summPlanExpected = summPlanExpected;
	}

	/**
	 * @return the summDataDiffrence
	 */
	

	/**
	 * @param summDataDiffrence the summDataDiffrence to set
	 */
	public void setSummDataDiffrence(String summDataDiffrence) {
		this.summDataDiffrence = summDataDiffrence;
	}

	/**
	 * @return the mcaidViewPymntDetailLst
	 */
	public List getMcaidViewPymntDetailLst() {
		return mcaidViewPymntDetailLst;
	}

	/**
	 * @param mcaidViewPymntDetailLst the mcaidViewPymntDetailLst to set
	 */
	public void setMcaidViewPymntDetailLst(List mcaidViewPymntDetailLst) {
		this.mcaidViewPymntDetailLst = mcaidViewPymntDetailLst;
	}

	/**
	 * @return the medicaidId
	 */
	public String getMedicaidId() {
		return medicaidId;
	}

	/**
	 * @param medicaidId the medicaidId to set
	 */
	public void setMedicaidId(String medicaidId) {
		this.medicaidId = medicaidId;
	}

	/**
	 * @return the diffrence
	 */
	public String getDiffrence() {
		return diffrence;
	}

	/**
	 * @param diffrence the diffrence to set
	 */
	public void setDiffrence(String diffrence) {
		this.diffrence = diffrence;
	}

	/**
	 * @return the summDataDiffrence
	 */
	public String getSummDataDiffrence() {
		return summDataDiffrence;
	}

	/**
	 * @return the viewPymtPageLabel
	 */
	public String getViewPymtPageLabel() {
		return ViewPymtPageLabel;
	}

	/**
	 * @param viewPymtPageLabel the viewPymtPageLabel to set
	 */
	public void setViewPymtPageLabel(String viewPymtPageLabel) {
		ViewPymtPageLabel = viewPymtPageLabel;
	}

	/**
	 * @return the summSrchGoPbp
	 */
	public String getSummSrchGoPbp() {
		return summSrchGoPbp;
	}

	/**
	 * @param summSrchGoPbp the summSrchGoPbp to set
	 */
	public void setSummSrchGoPbp(String summSrchGoPbp) {
		this.summSrchGoPbp = summSrchGoPbp;
	}

	/**
	 * @return the summSrchGoStatus
	 */
	public String getSummSrchGoStatus() {
		return summSrchGoStatus;
	}

	/**
	 * @param summSrchGoStatus the summSrchGoStatus to set
	 */
	public void setSummSrchGoStatus(String summSrchGoStatus) {
		this.summSrchGoStatus = summSrchGoStatus;
	}

	/**
	 * @return the summSrchType
	 */
	public String getSummSrchType() {
		return summSrchType;
	}

	/**
	 * @param summSrchType the summSrchType to set
	 */
	public void setSummSrchType(String summSrchType) {
		this.summSrchType = summSrchType;
	}

	/**
	 * @return the summSrchMedicaidId
	 */
	public String getSummSrchMedicaidId() {
		return summSrchMedicaidId;
	}

	/**
	 * @param summSrchMedicaidId the summSrchMedicaidId to set
	 */
	public void setSummSrchMedicaidId(String summSrchMedicaidId) {
		this.summSrchMedicaidId = summSrchMedicaidId;
	}

	/**
	 * @return the summSrchFromEffDate
	 */
	public String getSummSrchFromEffDate() {
		return summSrchFromEffDate;
	}

	/**
	 * @param summSrchFromEffDate the summSrchFromEffDate to set
	 */
	public void setSummSrchFromEffDate(String summSrchFromEffDate) {
		this.summSrchFromEffDate = summSrchFromEffDate;
	}

	/**
	 * @return the summSrchToEffDate
	 */
	public String getSummSrchToEffDate() {
		return summSrchToEffDate;
	}

	/**
	 * @param summSrchToEffDate the summSrchToEffDate to set
	 */
	public void setSummSrchToEffDate(String summSrchToEffDate) {
		this.summSrchToEffDate = summSrchToEffDate;
	}

	/**
	 * @return the summSrchFromUpdtDate
	 */
	public String getSummSrchFromUpdtDate() {
		return summSrchFromUpdtDate;
	}

	/**
	 * @param summSrchFromUpdtDate the summSrchFromUpdtDate to set
	 */
	public void setSummSrchFromUpdtDate(String summSrchFromUpdtDate) {
		this.summSrchFromUpdtDate = summSrchFromUpdtDate;
	}

	/**
	 * @return the summSrchToUpdtDate
	 */
	public String getSummSrchToUpdtDate() {
		return summSrchToUpdtDate;
	}

	/**
	 * @param summSrchToUpdtDate the summSrchToUpdtDate to set
	 */
	public void setSummSrchToUpdtDate(String summSrchToUpdtDate) {
		this.summSrchToUpdtDate = summSrchToUpdtDate;
	}

	/**
	 * @return the summSrchUpdtUserId
	 */
	public String getSummSrchUpdtUserId() {
		return summSrchUpdtUserId;
	}

	/**
	 * @param summSrchUpdtUserId the summSrchUpdtUserId to set
	 */
	public void setSummSrchUpdtUserId(String summSrchUpdtUserId) {
		this.summSrchUpdtUserId = summSrchUpdtUserId;
	}
	
	//State and plan value addition: start
	/**
	 * @return the summSrchStateValue
	 */
	public String getSummSrchStateValue() {
		return summSrchStateValue;
	}

	
	/**
	 * @param summSrchStateValue the summSrchStateValue to set
	 */
	public void setSummSrchStateValue(String summSrchStateValue) {
		this.summSrchStateValue = summSrchStateValue;
	}

	
	/**
	 * @return the summSrchPlanValue
	 */
	public String getSummSrchPlanValue() {
		return summSrchPlanValue;
	}


	/**
	 * @param summSrchPlanValue the summSrchPlanValue to set
	 */
	public void setSummSrchPlanValue(String summSrchPlanValue) {
		this.summSrchPlanValue = summSrchPlanValue;
	}
	//State and plan value addition: end	

	/**
	 * @return the summSrchPbpLst
	 */
	public List getSummSrchPbpLst() {
		return summSrchPbpLst;
	}

	/**
	 * @param summSrchPbpLst the summSrchPbpLst to set
	 */
	public void setSummSrchPbpLst(List summSrchPbpLst) {
		this.summSrchPbpLst = summSrchPbpLst;
	}

	/**
	 * @return the summSrchStatusLst
	 */
	public List getSummSrchStatusLst() {
		return summSrchStatusLst;
	}

	/**
	 * @param summSrchStatusLst the summSrchStatusLst to set
	 */
	public void setSummSrchStatusLst(List summSrchStatusLst) {
		this.summSrchStatusLst = summSrchStatusLst;
	}

	/**
	 * @return the summSrchTypeLst
	 */
	public List getSummSrchTypeLst() {
		return summSrchTypeLst;
	}

	/**
	 * @param summSrchTypeLst the summSrchTypeLst to set
	 */
	public void setSummSrchTypeLst(List summSrchTypeLst) {
		this.summSrchTypeLst = summSrchTypeLst;
	}

	public String getAnamolyCategory() {
		return anamolyCategory;
	}

	public void setAnamolyCategory(String anamolyCategory) {
		this.anamolyCategory = anamolyCategory;
	}

	public List getAnamolyCategoryList() {
		return anamolyCategoryList;
	}

	public void setAnamolyCategoryList(List anamolyCategoryList) {
		this.anamolyCategoryList = anamolyCategoryList;
	}

	public String getSummSrchAnmlyCd() {
		return summSrchAnmlyCd;
	}

	public void setSummSrchAnmlyCd(String summSrchAnmlyCd) {
		this.summSrchAnmlyCd = summSrchAnmlyCd;
	}

	public List getDiscrpDetailsLst() {
		return discrpDetailsLst;
	}

	public void setDiscrpDetailsLst(List discrpDetailsLst) {
		this.discrpDetailsLst = discrpDetailsLst;
	}


	/**
	 * @return the discrpDetailsTotalLst
	 */
	public List getDiscrpDetailsTotalLst() {
		return discrpDetailsTotalLst;
	}


	/**
	 * @param discrpDetailsTotalLst the discrpDetailsTotalLst to set
	 */
	public void setDiscrpDetailsTotalLst(List discrpDetailsTotalLst) {
		this.discrpDetailsTotalLst = discrpDetailsTotalLst;
	}
	// Added for Extract All Records Changes : start
	
		private String countOfRecords;
		private String extractQuery;
		
		public String getExtractQuery() {
			return extractQuery;
		}


		public void setExtractQuery(String extractQuery) {
			this.extractQuery = extractQuery;
		}


		public String getCountOfRecords() {
			return countOfRecords;
		}


		public void setCountOfRecords(String countOfRecords) {
			this.countOfRecords = countOfRecords;
		}


		// Added for Extract All Records Changes : end
	
}//class
