/*
 * $Id: PaymentFacadeManager.java,v 1.5 2011/03/02 06:00:31 rnenne Exp $
 */
package com.ps.mss.web.ajax;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.manager.MCPaymentManager;
import com.ps.mss.manager.PaymentManager;
import com.ps.mss.model.BeneficiaryPymtDetailVO;
import com.ps.mss.model.FilterVO;
import com.ps.mss.model.PaymentDashBoardVO;
import com.ps.mss.model.PaymentSummaryVOList;
import com.ps.mss.model.PdeContext;
import com.ps.mss.web.helper.AjaxHelper;
import com.ps.mss.web.helper.SessionHelper;

/**
 * @author deepak
 *
 * ReconManager class intrect with UI layer.UI layer call ReconManager class method's through javaScript
 * and respose is send back to UI layer.
 */
public class MCPaymentFacadeManager {
	private static Logger logger=LoggerFactory.getLogger(MCPaymentFacadeManager.class);

	/**
	 * This function is call by UI to get  values for palnDashBoard.
	 * @param searchType : On the  basis of this value we decide search criteria. 
	 * @param filterVO : this Vo contain all the criteria to be use in searching.
	 * @return
	 * @throws ApplicationException
	 */
	public PaymentDashBoardVO[] getPlanDashBoard (String searchType, FilterVO filterVO, String menuName) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		AjaxHelper.validateUser();
		Map planMap = getPlanForParts();
		FilterVO sessionFilterVO = null;
		if(Constants.BENEFICIARY_MENU.equals(menuName)){
			sessionFilterVO = (FilterVO) AjaxHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_DASHBOARD_FILTERVO);
		} else {
			sessionFilterVO = (FilterVO) AjaxHelper.getAttribute(Constants.SESSION_PAYMENT_DASHBOARD_FILTERVO);
		}
		AjaxHelper.updateFilterVo(sessionFilterVO,filterVO,searchType);
		logger.info(LoggerConstants.methodEndLevel());
		return MCPaymentManager.getPlanDashBoard(filterVO, planMap, searchType, null, menuName, AjaxHelper.getActiveDataBaseName());
	}

	/**
	 * This method is for getting payment summary for plan detail
	 * @param searchType : On the  basis of this value we decide search criteria. 
	 * @param filterVO : This Vo contain all the criteria to be use in searching.
	 * @param partName : partName can be Part C /Part D .
	 * @return
	 * @throws ApplicationException
	 */
	public PaymentSummaryVOList getPaymentSummary(String searchType, FilterVO filterVO, String partName) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		AjaxHelper.validateUser();
		Map planMap = getPlanForParts();
		logger.info(LoggerConstants.methodEndLevel());
		return MCPaymentManager.getPaymentSummary(filterVO, searchType, planMap, AjaxHelper.getActiveDataBaseName());
	}

	
	/** <Method >getPymtDetailOnEffDate </Method> is use to get payment Detail on Effective Date .
	 * @param effDate - Effective date for which we have to find payment detail.
	 * @param partName - partName can be Part C /Part D .
	 * @param isPopUp - TRUE/FALSE use to decide wether method is call by popUp.
	 * @param paymentType - payment Type.
	 * @param pageType - use to decide wether page is read only page.
	 * @return
	 * @throws ApplicationException
	 */
	public BeneficiaryPymtDetailVO [] getPymtDetailOnEffDate(String effDate, String partName, boolean isPopUp, String paymentType, String pageType) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		AjaxHelper.validateUser();
		Map planMap = getPlanForParts();
		FilterVO filterVO = null;
		BeneficiaryPymtDetailVO [] beneficiaryPymtDetailVOs = null;
		if(isPopUp)
			filterVO = (FilterVO) AjaxHelper.getAttribute(Constants.SESSION_PYMT_DETAIL_POP_UP_FILTERVO);
		else {
			// getting beneficiary discrepancy details search filter for "Show Payment" Window
 			if(Constants.READ_ONLY.equals(pageType))
				filterVO = (FilterVO) AjaxHelper.getAttribute(Constants.SESSION_BENEFICIARY_DETAIL_FILTERVO);
			else
				filterVO = (FilterVO) AjaxHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_FILTERVO);
		}
		
		if(filterVO != null) {
			String startDate = filterVO.getStartDate();
			String endDate = filterVO.getEndDate();
			filterVO.setStartDate(effDate);
			filterVO.setEndDate(effDate);
			beneficiaryPymtDetailVOs = MCPaymentManager.getPymtDetailOnEffDate(filterVO, planMap, partName, AjaxHelper.getActiveDataBaseName(), paymentType);
			filterVO.setStartDate(startDate);
			filterVO.setEndDate(endDate);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return beneficiaryPymtDetailVOs ;
	}

	/**
	 * This function save uiContext into session for all pages .
	 * @param uiContext 
	 * @param pageName - pageName for which we have to save ui context.
	 * @param menuName 
	 * @param pageType
	 * @throws ApplicationException
	 */
	public void saveUiContext(String [] uiContext, String pageName, String menuName, String pageType) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		AjaxHelper.validateUser();
		List pymtList = null ;
		if(uiContext != null) 
			pymtList = Arrays.asList(uiContext);
		List lastSelectedTabList = new ArrayList();
		logger.debug(" in MCPaymentFacadeManager----values ::"+pageName+" "+menuName+" "+pageType);
		lastSelectedTabList.add(pageName);
		lastSelectedTabList.add(pageType);
		lastSelectedTabList.add(menuName);
		//saving UI-Context for page 'paymentDashboar' in plan & beneficiary menu.
		if(Constants.PAYMENT_DASHBOARD.equals(pageName) && Constants.BENEFICIARY_MENU.equals(menuName)) {
			AjaxHelper.setAttribute(Constants.SESSION_BENEFICIARY_PYMT_DESH_STATUS , pymtList);
			AjaxHelper.setAttribute(Constants.SESSION_BENEFICIARY_LAST_SELECTED_TAB , lastSelectedTabList);
		} else if(Constants.PAYMENT_DASHBOARD.equals(pageName)) {
			AjaxHelper.setAttribute(Constants.SESSION_PAYMENT_DESH_STATUS , pymtList);
			AjaxHelper.setAttribute(Constants.SESSION_PLAN_LAST_SELECTED_TAB , lastSelectedTabList);
		}//saving UI-Context for page 'discrepancyDashboard' in plan & beneficiary menu.	
		else if (Constants.DISCREPANCY_DASHBOARD.equals(pageName) && Constants.BENEFICIARY_MENU.equals(menuName)) {
			AjaxHelper.setAttribute(Constants.SESSION_BENEFICIARY_DISCREPANCY_DESH_STATUS , pymtList);
			AjaxHelper.setAttribute(Constants.SESSION_BENEFICIARY_LAST_SELECTED_TAB , lastSelectedTabList);
		} else if (Constants.DISCREPANCY_DASHBOARD.equals(pageName)) { 
			AjaxHelper.setAttribute(Constants.SESSION_DISCREPANCY_DESH_STATUS , pymtList);
			AjaxHelper.setAttribute(Constants.SESSION_PLAN_LAST_SELECTED_TAB , lastSelectedTabList);
		} //saving UI-Context for page 'paymentSummary/paymentDetail' in plan & beneficiary menu.
		else if (Constants.PAYMENT_SUMMARY.equals(pageName)&& Constants.BENEFICIARY_MENU.equals(menuName)) {
			// checking is request comming from "Show Payment"
			if(Constants.READ_ONLY.equals(pageType))
				AjaxHelper.setAttribute(Constants.SESSION_BENEFICIARY_SHOW_PYMT_SUMMARY_STATUS , pymtList);
			else 
				AjaxHelper.setAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_STATUS , pymtList);
			
			AjaxHelper.setAttribute(Constants.SESSION_BENEFICIARY_LAST_SELECTED_TAB , lastSelectedTabList);
		} else if (Constants.PAYMENT_SUMMARY.equals(pageName)) {
			if(Constants.READ_ONLY.equals(pageType))
				AjaxHelper.setAttribute(Constants.SESSION_SHOW_PAYMENT_SUMMARY_STATUS , pymtList);
			else
				AjaxHelper.setAttribute(Constants.SESSION_PAYMENT_SUMMARY_STATUS , pymtList);
			
			AjaxHelper.setAttribute(Constants.SESSION_PLAN_LAST_SELECTED_TAB , lastSelectedTabList);
		} //saving UI-Context for page 'discreapncySummary' in plan  menu.
		else if (Constants.DISCREPANCY_SUMMARY.equals(pageName)) {
			// READ_ONLY means Saving UI Context for Show Discrepancy Summary   
			if(Constants.READ_ONLY.equals(pageType)) {
				List uiContextList = (List) AjaxHelper.getAttribute(Constants.SESSION_SHOW_DISCREPANCY_SUMMARY_STATUS);
				uiContextList = createDefaultContextList(uiContextList,pageName);
				uiContextList = createContextList(uiContextList,uiContext);
				AjaxHelper.setAttribute(Constants.SESSION_SHOW_DISCREPANCY_SUMMARY_STATUS , uiContextList);	
			} else {
				List uiContextList = (List)AjaxHelper.getAttribute(Constants.SESSION_DISCREPANCY_SUMMARY_STATUS);
				uiContextList = createDefaultContextList(uiContextList,pageName);
				uiContextList = createContextList(uiContextList,uiContext);
				AjaxHelper.setAttribute(Constants.SESSION_DISCREPANCY_SUMMARY_STATUS , uiContextList);
			}
			AjaxHelper.setAttribute(Constants.SESSION_PLAN_LAST_SELECTED_TAB , lastSelectedTabList);
		} //saving UI-Context for page 'discrepancyDetail' in discrepancy & beneficiary menu.
		else if (Constants.DISCREPANCY_DETAIL.equals(pageName) && Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(menuName) ) {
			if(Constants.READ_ONLY.equals(pageType)) {
				List uiContextList = (List)AjaxHelper.getAttribute(Constants.SESSION_BENEFICIARY_SHOW_DISCRP_DETAIL_STATUS);
				uiContextList = createDefaultContextList(uiContextList,pageName);
				uiContextList = createContextList(uiContextList,uiContext);
				AjaxHelper.setAttribute(Constants.SESSION_BENEFICIARY_SHOW_DISCRP_DETAIL_STATUS , uiContextList);	
			} else {
				List uiContextList = (List)AjaxHelper.getAttribute(Constants.SESSION_BENEFICIARY_DISCRP_DETAIL_STATUS);
				uiContextList = createDefaultContextList(uiContextList,pageName);
				uiContextList = createContextList(uiContextList,uiContext);
				AjaxHelper.setAttribute(Constants.SESSION_BENEFICIARY_DISCRP_DETAIL_STATUS , uiContextList);
			}
			AjaxHelper.setAttribute(Constants.SESSION_BENEFICIARY_LAST_SELECTED_TAB , lastSelectedTabList);
		} else if (Constants.DISCREPANCY_DETAIL.equals(pageName)) {
			List uiContextList = (List)AjaxHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_STATUS);
			uiContextList = createDefaultContextList(uiContextList,pageName);
			uiContextList = createContextList(uiContextList,uiContext);
			AjaxHelper.setAttribute(Constants.SESSION_DISCREPANCY_DETAIL_STATUS , uiContextList);
		}
		//	saving UI-Context for page 'toopDashBoard' in troopDetail
		else if(Constants.TROOP_DASHBOARD.equals(pageName) ) {
		    AjaxHelper.setAttribute(Constants.SESSION_TROOP_DESH_STATUS , pymtList);
		    AjaxHelper.setAttribute(Constants.SESSION_TROOP_LAST_SELECTED_TAB , lastSelectedTabList);
		} else if(Constants.TROOP_DETAIL.equals(pageName)){
		    AjaxHelper.setAttribute(Constants.SESSION_TROOP_DETAIL_STATUS , pymtList);
		    AjaxHelper.setAttribute(Constants.SESSION_TROOP_LAST_SELECTED_TAB , lastSelectedTabList);
		} else if(Constants.PDE_DASHBOARD.equals(pageName)){
		    AjaxHelper.setAttribute(Constants.SESSION_PDE_DESH_STATUS , pymtList);
		    AjaxHelper.setAttribute(Constants.SESSION_PDE_LAST_SELECTED_TAB , lastSelectedTabList);
		} else if(Constants.PDE_EVENT_DETAIL.equals(pageName)){
		    AjaxHelper.setAttribute(Constants.SESSION_PDE_EVENT_DETAIL_STATUS , pymtList);
		    AjaxHelper.setAttribute(Constants.SESSION_PDE_LAST_SELECTED_TAB , lastSelectedTabList);
		} else if(Constants.PDE_ERR_DASHBOARD.equals(pageName)){
			PdeContext context = (PdeContext)AjaxHelper.getAttribute(Constants.SESSION_PDE_CONTEXT);
		    context.setErrDBExpandableItems(pymtList);
		    AjaxHelper.setAttribute(Constants.SESSION_PDE_LAST_SELECTED_TAB , lastSelectedTabList);
		} else if(Constants.PDE_ERR_DETAIL.equals(pageName)){
			PdeContext context = (PdeContext)AjaxHelper.getAttribute(Constants.SESSION_PDE_CONTEXT);
		    context.setErrDetailExpandableItems(pymtList);
		    AjaxHelper.setAttribute(Constants.SESSION_PDE_LAST_SELECTED_TAB , lastSelectedTabList);
		} else if (Constants.PDE_ERR_CODES.equals(pageName))
		    AjaxHelper.setAttribute(Constants.SESSION_PDE_LAST_SELECTED_TAB , lastSelectedTabList);
		// saving UI-Context for profile
		else if ( Constants.PROFILE_SEARCH.equals(pageName)){
			List uiContextList = (List)AjaxHelper.getAttribute(Constants.SESSION_PROFILE_DETAIL_STATUS);
			uiContextList = createDefaultContextList(uiContextList,pageName);
			uiContextList = createContextList(uiContextList,uiContext);			
			AjaxHelper.setAttribute(Constants.SESSION_PROFILE_DETAIL_STATUS, uiContextList);
			AjaxHelper.setAttribute(Constants.SESSION_PROFILE_LAST_SELECTED_TAB , lastSelectedTabList);
		}
		else if (Constants.PARTD_MENU.equals(menuName))
			if (Constants.PAGE_FORECASTSUM.equals(pageName) || Constants.PAGE_LICS_DETAIL.equals(pageName) ||
					Constants.PAGE_REIN_DETAIL.equals(pageName) || Constants.PAGE_RISK_DETAIL.equals(pageName)) {
				/* annual recon need to have it's own storage since it has 4 subtabs.
				 * When jumping from DDIR Update to Annual Recon, getLastSelectedTab(Constants.SESSION_ANNUAL_RECON_LAST_TAB)
				 * will be  called.
				 */
				AjaxHelper.setAttribute(Constants.SESSION_ANNUAL_RECON_LAST_TAB , lastSelectedTabList);
				AjaxHelper.setAttribute(Constants.SESSION_PARTD_LAST_SELECTED_TAB, lastSelectedTabList);
			}
			else
				AjaxHelper.setAttribute(Constants.SESSION_PARTD_LAST_SELECTED_TAB, lastSelectedTabList);
		
		AjaxHelper.setAttribute(Constants.SESSION_LAST_SELECTED_TAB ,lastSelectedTabList);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	/**
	 * This create default Context for discreapcny Detail/discreapncy summary
	 * @param uiContextList
	 * @param pageName
	 * @return
	 */
	private List createDefaultContextList(List uiContextList,String pageName){
		logger.info(LoggerConstants.methodStartLevel());
		if(uiContextList == null){
			uiContextList = new ArrayList();
			if(Constants.DISCREPANCY_DETAIL.equals(pageName)) {
				uiContextList.add(Constants.DISCRP_LIST);
				uiContextList.add(Constants.PARTD_DISCRP_LIST);
				uiContextList.add(Constants.DISCRP_DETAIL);
				uiContextList.add(Constants.DISCRP_HISTORY);
			} else if(Constants.DISCREPANCY_SUMMARY.equals(pageName)) {
				uiContextList.add(Constants.PARTC);
				uiContextList.add(Constants.PARTD);
			} else if(Constants.PROFILE_SEARCH.equals(pageName)){
				uiContextList.add(Constants.PROFILE_PARTC_PLNLIST);
				uiContextList.add(Constants.PROFILE_PARTD_PLNLIST);
				uiContextList.add(Constants.PROFILE_PARTD_PBPLIST);
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return uiContextList;
	}
	
	/**
	 * This method create uiContext List from list which is send by client side thru saveUIContext
	 * @param uiContextList
	 * @param uiContext
	 * @return
	 */
	private List createContextList(List uiContextList, String[] uiContext) {
		logger.info(LoggerConstants.methodStartLevel());
		if(uiContext != null){
			String status = null;
			String [] token = null ;
			for(int i = 0 ; i < uiContext.length ; i++){
				status = uiContext[i];
				token = status != null ? status.split(",") : null;
				if(token != null ) {
					if(uiContextList.contains(token[0])){
						if("false".equals(token[1]))
							uiContextList.remove(token[0]);
					} else {
						if("true".equals(token[1]))
							uiContextList.add(token[0]);
					}
				}
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return uiContextList;
	}

	/**
	 * This find plans Map for partC/partD
	 * @param request
	 * @return
	 * @throws ApplicationException
	 */
	private Map getPlanForParts() throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		Map planMap = sessionHelper.getPlanForParts();
		logger.info(LoggerConstants.methodEndLevel());
		return planMap;
	}
	
	/**
	 * <Method>getLastSelectedTab</Method> return last selected tab (e.g planDashboard ,discrepancyDashboard,paymentsummary,discrepancysummary
	 * etc  )
	 * @param menuName
	 * @return
	 * @throws ApplicationException
	 */
	public List getLastSelectedTab(String menuName) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		AjaxHelper.validateUser();
		
		if(Constants.PROFILE_MENU.equals(menuName)) {
			logger.info(LoggerConstants.methodEndLevel());
			return (List)AjaxHelper.getAttribute(Constants.SESSION_PROFILE_LAST_SELECTED_TAB);
		} else if(Constants.BENEFICIARY_MENU.equals(menuName)) {
			logger.info(LoggerConstants.methodEndLevel());
			return (List)AjaxHelper.getAttribute(Constants.SESSION_BENEFICIARY_LAST_SELECTED_TAB);
		} else if(Constants.TROOP_MENU.equals(menuName)) {
			logger.info(LoggerConstants.methodEndLevel());
			return (List)AjaxHelper.getAttribute(Constants.SESSION_TROOP_LAST_SELECTED_TAB);
		} else if(Constants.PDE_MENU.equals(menuName)) {
			logger.info(LoggerConstants.methodEndLevel());
			return (List)AjaxHelper.getAttribute(Constants.SESSION_PDE_LAST_SELECTED_TAB);
		} else if (Constants.DISCREPANCY_DETAIL.equals(menuName)){
			logger.info(LoggerConstants.methodEndLevel());
			return null;
		}
		
		logger.info(LoggerConstants.methodEndLevel());	
		return (List)AjaxHelper.getAttribute(Constants.SESSION_PLAN_LAST_SELECTED_TAB);
	}
}
