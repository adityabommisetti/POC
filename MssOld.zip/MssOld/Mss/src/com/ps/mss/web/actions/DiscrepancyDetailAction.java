/*
 * $Id: DiscrepancyDetailAction.java,v 1.1 2014/06/26 07:56:39 praveen Exp $
*/
package com.ps.mss.web.actions;

import java.awt.Menu;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.framework.Constants;
import com.ps.mss.manager.DiscrepancyManager;
import com.ps.mss.manager.MasterManager;
import com.ps.mss.model.DiscrepancyDetailVO;
import com.ps.mss.model.DiscrepancyDetailVOList;
import com.ps.mss.model.DiscrepancyListVO;
import com.ps.mss.model.FilterVO;
import com.ps.mss.web.forms.DiscrepancyDetailForm;
import com.ps.mss.web.helper.DispatchActionHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.util.NameValuePair;
import com.ps.util.StringUtil;

/**
 * This action is execute by client(UI) for discrepancy detail.
 * @version 	1.0
 * @author
 */
public class DiscrepancyDetailAction extends Action {
	private static Logger logger=LoggerFactory.getLogger(DiscrepancyDetailAction.class);
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		String target = "error";
		SessionHelper sessionHelper = new SessionHelper(request);
		DiscrepancyDetailForm discrpDetailForm = (DiscrepancyDetailForm) form;
		discrpDetailForm.init(request);
		
		List uiContext = null;
		FilterVO filterVO = null;
		Map discrpMap = null ;
		String actiontype = null;
		
		//we are setting menu name and page type which are send throug request in case of print 
		//so that it can fatch data according to menu(Beneficiary or Discrepancy)
/*		if(request.getParameter("print") != null) {
			discrpDetailForm.setMenuName(request.getParameter("menuName"));
			discrpDetailForm.setPageType(request.getParameter("pageType"));
			discrpDetailForm.setActionType("");
			discrpDetailForm.setPartName(request.getParameter("partName"));
		}*/
		
		actiontype = discrpDetailForm.getActionType();
		String move = null;
		System.out.println(" in DiscrepancyAction"+discrpDetailForm.getMenuName());
		//when request is for discrepancydetail
		//(action type : summaryPage when we want to see detail from discrepancy summary page by clicking discreapncy.
		// actionType  : search when we have made search using go button.
		if (!"summaryPage".equals(actiontype) && ! "search".equals(actiontype)) { 
			if(Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(discrpDetailForm.getMenuName())){ // we want to see beneficiary detail
				if(Constants.READ_ONLY.equals(discrpDetailForm.getPageType())) {//when request is from show discrepancy (which is read only screen)
					if(request.getParameter("print")!=null)
						discrpMap = (Map)sessionHelper.getAttribute(Constants.SESSION_READ_ONLY_DISCRP_DETAIL_MAP);
					else
						discrpMap = null; //Because we are considering that payment detail search criteria has changed. 
					//(Map)sessionHelper.getAttribute(Constants.SESSION_READ_ONLY_DISCRP_DETAIL_MAP);
				}
				else 
					discrpMap = (Map)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DISCRP_DETAIL_MAP);
			} else // we want to see discrepancy detail.
				discrpMap = (Map)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_MAP);
		}
				
		int selectedRowNo = 0;
		if(discrpMap != null) {
			Integer temp = ((Integer)discrpMap.get(Constants.PAGE_SELECTED_LINE));
			if(temp != null)
				selectedRowNo = temp.intValue() ; 
		}
		Map detailmap = null;
		if(request.getParameter("print") != null){ // when request is for print
			if(Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(discrpDetailForm.getMenuName())){
				if(Constants.READ_ONLY.equals(request.getParameter("pageType"))) {//when request is from show discrepancy (which is read only screen)
					filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_FILTERVO);
					
					//	filterVO.setPartName(Constants.BOTH_PARTS);
//					filterVO.setPartName(discrpDetailForm.getPartName());
					filterVO.setDiscrpStatus("NotClosed"); // Because we are considering "NotClosed" discrepancy only
					uiContext = (List)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_SHOW_DISCRP_DETAIL_STATUS);
					target = "printBeneficiaryDiscDetail";
				}else{
					filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DETAIL_FILTERVO);
					uiContext = (List)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DISCRP_DETAIL_STATUS);
					target = "printBeneficiaryDiscDetail";
				}
			} else {
				filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_FILTERVO);
				uiContext = (List)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_STATUS);
				target = "successForPrint";
			}
			String searchCreiteriaHeader = DiscrepancyManager.getSearchCreiteriaHeader(filterVO, Constants.DISCREPANCY_DETAIL, discrpDetailForm.getMenuName(), sessionHelper.getActiveDataBaseName());
   			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCreiteriaHeader);
		} else {// when request is not for print
			if(Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(discrpDetailForm.getMenuName())){ // request is from beneficiary menu
				if(Constants.READ_ONLY.equals(discrpDetailForm.getPageType())) {//when request is from show discrepancy (which is read only screen)
					filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_FILTERVO);
//					filterVO.setPartName(Constants.BOTH_PARTS);
					
					filterVO.setDiscrpStatus("NotClosed"); // Because we are considering "NotClosed" discrepancy only
					uiContext = (List)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_SHOW_DISCRP_DETAIL_STATUS);
					target = "showBeneDiscrpDetail";
					DispatchActionHelper.setTabAndFormName(request, Constants.BENEFICIARY_MENU, "DiscrepancyDetailForm");
				} else {// when request is for beneficiary detail.
					filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DETAIL_FILTERVO);
					filterVO = setFilterVO(discrpDetailForm,filterVO);
					sessionHelper.setAttribute(Constants.SESSION_BENEFICIARY_DETAIL_FILTERVO,filterVO);
					uiContext = (List)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DISCRP_DETAIL_STATUS);
					sessionHelper.setAttribute(Constants.BENEFICIARY_DISCRP_DETAIL_MENU,"true");
					target = "beneDiscrpDetail";
					DispatchActionHelper.setTabAndFormName(request, Constants.BENEFICIARY_MENU, "DiscrepancyDetailForm");
				}
			} 
			else { // when request is for discrepancy detail.
				filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_FILTERVO);
				filterVO = setFilterVO(discrpDetailForm,filterVO);
				sessionHelper.setAttribute(Constants.SESSION_DISCREPANCY_DETAIL_FILTERVO, filterVO);
				uiContext = (List)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_STATUS);
				target = "success";
				DispatchActionHelper.setTabAndFormName(request, Constants.DISCREPANCY_MENU, "DiscrepancyDetailForm");
			}
		}	
		
		String discInd = filterVO.getPartName();

		//	if(Constants.PARTD.equals(request.getParameter("partName")) && selectedRowNo == 0)
		if(Constants.PARTD.equals(filterVO.getPartName()) && selectedRowNo == 0)
			selectedRowNo = 10;//because for part D, first row is default selected row with selectedRowNo '10'
		
		String uiContextRange = StringUtil.nonNullTrim(request.getParameter("uiContextRange"));
		Integer maxRecordCount = MasterManager.getMaxRecordCount();
		move = "current";
		request.setAttribute("uiContextRange",uiContextRange);
		//In the case of all we have to fetch records( records count is  according to sysparm table ) for selected line.
		if(Constants.CONSTANTS_ALL.equals(uiContextRange)){ 
			move = "first";
			if(discrpMap!= null){
				if(selectedRowNo < 10) { //when part C has selectd line
					detailmap =  discrpMap != null ?(Map)discrpMap.get(Constants.PARTC_DISCRP_DETAIL_MAP) : null ;
					request.setAttribute("showDiscrepancyListC",Constants.PARTC);
					
					// setting detaulf PART_NAME to PART_C
					filterVO.setPartName(Constants.PARTC);
					
				} else { // when part D has selected line
					detailmap =  discrpMap != null ?(Map)discrpMap.get(Constants.PARTD_DISCRP_DETAIL_MAP) : null ;
					request.setAttribute("showDiscrepancyListD",Constants.PARTD);

					// setting detaulf PART_NAME to PART_D
					filterVO.setPartName(Constants.PARTD);
				}
				if(detailmap != null){
					detailmap.put(Constants.SESSION_MAX_RECORD_COUNT,maxRecordCount);
					detailmap.put(Constants.UI_CONTEXT_RANGE,Constants.CONSTANTS_ALL);
				}
			}
		}
	
		filterVO.setEOTBOT("summaryPage".equals(actiontype) ? true : false ); //This is set because we want to set EOT?BOT inot date field when filterVO does not contains date.
		
		if(filterVO != null && StringUtil.trimToNull(filterVO.getPlanName())!= null ) { //This condition is true when use click first time on discrepancy detail tab
			Map planMap = sessionHelper.getPlanForParts();
			filterVO.setSearchType(sessionHelper.evaluteSearchType(filterVO));
			
			if(Constants.BOTH_PARTS.equals(filterVO.getPartName()))
				filterVO.setPartName(sessionHelper.getServicesToAccess());
			
			boolean hasWriteOffService = sessionHelper.hasWriteOffPermission();
			DiscrepancyDetailVOList discrepancyDetailVOList = DiscrepancyManager.getDiscrepancyList(filterVO,discrpMap,move, sessionHelper.getActiveDataBaseName(),planMap,filterVO.getSearchType(),discrpDetailForm.getMenuName(), hasWriteOffService);

			if(detailmap != null){
				detailmap.put(Constants.SESSION_MAX_RECORD_COUNT,new Integer(10));
				detailmap.remove(Constants.UI_CONTEXT_RANGE);
			}
			
			
			// restoring prev. filterVO partName, which might be modified by PRINT _ALL request.
			filterVO.setPartName(discInd);
		//	setPageHistAttribut(discrepancyDetailVOList, discrpDetailForm); // set pageHist attribute into form  
	        
			if(discrepancyDetailVOList != null){
				discrpDetailForm.setDiscrepancyDetailVOList(discrepancyDetailVOList);
				
				if( Constants.EXPORT_NO_DATA_FOUND.equals("TRUE") && Constants.CONSTANTS_ALL.equals(StringUtil.nonNullTrim(request.getParameter("uiContextRange")))){
					DiscrepancyDetailVO discListPartC =discrepancyDetailVOList.getPartCDiscrpDetailVO();
					DiscrepancyDetailVO discListPartD =discrepancyDetailVOList.getPartDDiscrpDetailVO();
					DiscrepancyListVO[] discListPartCObjArr = discListPartC!=null?discListPartC.getDiscrepancyListVO():null;
					DiscrepancyListVO[] discListPartDObjArr = discListPartD!=null?discListPartD.getDiscrepancyListVO():null;
					if(discListPartCObjArr == null && discListPartDObjArr == null){
						if(Constants.PARTC.equals(discInd)|| Constants.BOTH_PARTS.equals(discInd))
							request.setAttribute("showDiscrepancyListC",Constants.PARTC);
						if(Constants.PARTD.equals(discInd)|| Constants.BOTH_PARTS.equals(discInd))
							request.setAttribute("showDiscrepancyListD",Constants.PARTD);
					}
				}
				if(request.getParameter("print") == null) {
					setDetailMap(discrpMap,discrepancyDetailVOList, sessionHelper, discrpDetailForm.getMenuName(), filterVO.getPartName(),discrpDetailForm.getPageType());
				}
			}
		}	
		
			//this call for set ui context into form
			setUiContext(uiContext,discrpDetailForm);
			setForm(discrpDetailForm , filterVO);	//this set discrepancy detail form using filtervo		
			setpartName(discrpDetailForm);
			logger.info(LoggerConstants.methodEndLevel());
			System.out.println(" Target before submit--"+target);
		return mapping.findForward(target);
	}
	
	/**
	 * @param discrpDetailForm
	 */
	private void setpartName(DiscrepancyDetailForm discrpDetailForm) {
		logger.info(LoggerConstants.methodStartLevel());
		NameValuePair[] planIdArr = discrpDetailForm.getPlanNameList();
		if( StringUtil.trimToNull(discrpDetailForm.getHicNbr()) == null && StringUtil.trimToNull(discrpDetailForm.getFromDate()) == null && StringUtil.trimToNull(discrpDetailForm.getToDate()) == null)
				discrpDetailForm.setCriteriaAvailable("false");
		if(planIdArr != null && planIdArr.length == 1) {
			discrpDetailForm.setPlanName(planIdArr[0].getName());
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	/**
	 * 
	 */
	private void setPageHistAttribut(DiscrepancyDetailVOList discrepancyDetailVOList , DiscrepancyDetailForm discrpDetailForm) {
		logger.info(LoggerConstants.methodStartLevel());
		if(discrepancyDetailVOList != null){
        	DiscrepancyDetailVO discrepancyDetailVO  = null ;
        	//adding pageHist attribute of first reconde of current pager for part C
			discrepancyDetailVO = discrepancyDetailVOList.getPartCDiscrpDetailVO();
        	DiscrepancyListVO [] discrepancyListVOs = discrepancyDetailVO != null  ? discrepancyDetailVO.getDiscrepancyListVO() : null;
        	if(discrepancyListVOs != null && discrepancyListVOs.length > 0){
        		String pdePageHist = discrepancyListVOs[0].getPagingKeySet();
        	}
        	//adding pageHist attribute of first reconde of current pager for part D
        	discrepancyDetailVO = discrepancyDetailVOList.getPartDDiscrpDetailVO();
        	discrepancyListVOs = discrepancyDetailVO != null  ? discrepancyDetailVO.getDiscrepancyListVO() : null;
        	if(discrepancyListVOs != null && discrepancyListVOs.length > 0){
        		String pdePageHist = discrepancyListVOs[0].getPagingKeySet();
        	}
        }
		logger.info(LoggerConstants.methodEndLevel());
	}

	/**
	 * This set form bean value using filter vo
	 * @param baseForm
	 * @param filterVO
	 */
	private void setForm(DiscrepancyDetailForm discrpDetailForm, FilterVO filterVO) {
		logger.info(LoggerConstants.methodStartLevel());
		discrpDetailForm.setPlanName(StringUtil.nonNullTrim(filterVO.getPlanName()));
		discrpDetailForm.setFromDate(filterVO.getStartDate());
		discrpDetailForm.setToDate(filterVO.getEndDate());
		discrpDetailForm.setHicNbr(filterVO.getHicNumber());
		discrpDetailForm.setUpdateDateFrom(filterVO.getUpdateDateFrom());
		discrpDetailForm.setUpdateDateTo(filterVO.getUpdateDateTo());
		discrpDetailForm.setUpdateId(filterVO.getUpdateId());

		if(! Constants.BOTH_PARTS.equals(discrpDetailForm.getActiveService()) && Constants.BOTH_PARTS.equals(filterVO.getPartName()) )
			discrpDetailForm.setPartName(discrpDetailForm.getActiveService());
		else
			discrpDetailForm.setPartName(filterVO.getPartName());

		discrpDetailForm.setSearchType(filterVO.getSearchType());
		logger.info(LoggerConstants.methodEndLevel());
	}

	/**
	 * This set detailMap which contain total number of page ,records , first and last record of discrpancyList 
	 * @param discrpMap
	 * @param discrepancyDetailVOList
	 * @param sessionHelper
	 * @param partName
	 * @param pageType
	 * @param string
	 */
	private void setDetailMap(Map discrpMap, DiscrepancyDetailVOList discDetailVOList, SessionHelper sessionHelper, String menuName, String partName, String pageType) {
		logger.info(LoggerConstants.methodStartLevel());
		if(discDetailVOList != null) {
			if(discrpMap == null )
				discrpMap = new HashMap ();
			if(Constants.PARTC.equals(partName)) {
				discrpMap.put(Constants.PARTC_DISCRP_DETAIL_MAP,createMap(discDetailVOList.getPartCDiscrpDetailVO(), (Map)discrpMap.get(Constants.PARTC_DISCRP_DETAIL_MAP)));
			} else if(Constants.PARTD.equals(partName)) {
				discrpMap.put(Constants.PARTD_DISCRP_DETAIL_MAP,createMap(discDetailVOList.getPartDDiscrpDetailVO(), (Map)discrpMap.get(Constants.PARTD_DISCRP_DETAIL_MAP)));
			} else if(Constants.BOTH_PARTS.equals(partName)) {
				discrpMap.put(Constants.PARTC_DISCRP_DETAIL_MAP,createMap(discDetailVOList.getPartCDiscrpDetailVO(), (Map)discrpMap.get(Constants.PARTC_DISCRP_DETAIL_MAP)));
				discrpMap.put(Constants.PARTD_DISCRP_DETAIL_MAP,createMap(discDetailVOList.getPartDDiscrpDetailVO(), (Map)discrpMap.get(Constants.PARTD_DISCRP_DETAIL_MAP)));
			}
			discrpMap.put(Constants.PAGE_SELECTED_LINE , new Integer(discDetailVOList.getSelectedLine()));
			
			discrpMap.remove(Constants.SESSION_MAX_RECORD_COUNT);
			discrpMap.remove(Constants.CONSTANTS_ALL);			

			if(Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(menuName)) { 
				if(Constants.READ_ONLY.equals(pageType))
					sessionHelper.setAttribute(Constants.SESSION_READ_ONLY_DISCRP_DETAIL_MAP,discrpMap);
				else
					sessionHelper.setAttribute(Constants.SESSION_BENEFICIARY_DISCRP_DETAIL_MAP,discrpMap);
			} else
				sessionHelper.setAttribute(Constants.SESSION_DISCREPANCY_DETAIL_MAP,discrpMap);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	/**
	 * 
	 * @param discrepancyDetailVO
	 * @param discrpMap
	 * @return
	 */
	private Map createMap(DiscrepancyDetailVO discrepancyDetailVO, Map discrpMap){
		logger.info(LoggerConstants.methodStartLevel());
		if(discrepancyDetailVO != null) {
			if(discrpMap == null)
			discrpMap = new HashMap ();
				DiscrepancyListVO [] discrepancyListVO = discrepancyDetailVO.getDiscrepancyListVO();
				if(discrepancyListVO != null ){
					discrpMap.put(Constants.FIRST_DETAIL_VO,discrepancyListVO[0]);
					discrpMap.put(Constants.LAST_DETAIL_VO,discrepancyListVO[discrepancyListVO.length-1]);
					discrpMap.put(Constants.CURRENT_PAGE,discrepancyDetailVO.getCurrentPage());
					discrpMap.put(Constants.PAGE_NUMBER , new Integer(discrepancyDetailVO.getPageNumber()));
					
				}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return discrpMap;
	}

	/**
	 *  This function reset filterVO using form Bean values when user change filter cretaria.
	 * @param discrepancyDetailForm
	 * @param filterVO
	 * @return
	 */
	private FilterVO setFilterVO(DiscrepancyDetailForm discrepancyDetailForm, FilterVO filterVO) {
		logger.info(LoggerConstants.methodStartLevel());
		String action = discrepancyDetailForm.getActionType();
		
		if (filterVO == null)
			filterVO = new FilterVO();
		//filterVO.setDiscrepancyIndicator(StringUtil.trimToNull(discrepancyDetailForm.getPartName()));
		
		if ("search".equals(action) || "summaryPage".equals(action)) {
			//see if a different hic number is entered.
			String baseHic = StringUtil.nonNullTrim(discrepancyDetailForm.getHicNbr());
			String filterHic = StringUtil.nonNullTrim(filterVO.getHicNumber());
			if (!filterHic.equals(baseHic)) { //a new one is entered, clear memberId and HicNumberList.
				filterVO.setMemberId(null);
				filterVO.setHicNumberList(null);		
			}
			filterVO.setSearchType(discrepancyDetailForm.getSearchType());
			filterVO.setPlanName(StringUtil.trimToNull(discrepancyDetailForm.getPlanName()));
			filterVO.setStartDate(StringUtil.trimToNull(discrepancyDetailForm.getFromDate()));
			filterVO.setEndDate(StringUtil.trimToNull(discrepancyDetailForm.getToDate()));
			filterVO.setDateType("E");
			filterVO.setDiscrpCd(StringUtil.trimToNull(discrepancyDetailForm.getDiscCd()));
			filterVO.setDiscrpStatus(StringUtil.trimToNull(discrepancyDetailForm.getDiscrepancyType()));
			filterVO.setHicNumber(StringUtil.trimToNull(discrepancyDetailForm.getHicNbr()));
			filterVO.setUpdateDateFrom(StringUtil.trimToNull(discrepancyDetailForm.getUpdateDateFrom()));
			filterVO.setUpdateDateTo(StringUtil.trimToNull(discrepancyDetailForm.getUpdateDateTo()));
			filterVO.setUpdateId(StringUtil.trimToNull(discrepancyDetailForm.getUpdateId()));
			filterVO.setPageHeaderMsg("");
			String indicator = StringUtil.trimToNull(discrepancyDetailForm.getPartName());
			filterVO.setPartName(indicator); 
		}	
		
		logger.info(LoggerConstants.methodEndLevel());
		return filterVO;
	}
	
	/**
	 * This setUIContext for discrepancy detail
	 * @param uiContext
	 * @param baseForm
	 */
	private void setUiContext(List uiContext, DiscrepancyDetailForm discrepancyDetailForm) {
		logger.info(LoggerConstants.methodStartLevel());
		if(uiContext != null) {
			String contextString = null;
			Iterator it = uiContext.iterator();
			while(it.hasNext()) {
				contextString = (String) it.next();
				if(Constants.DISCRP_LIST.equals(contextString)) {
					discrepancyDetailForm.setShowDiscrpList(contextString);
				} else if(Constants.DISCRP_DETAIL.equals(contextString)) {
					discrepancyDetailForm.setShowDiscrpDetail(contextString);
				} else if(Constants.DISCRP_HISTORY.equals(contextString)) {
					discrepancyDetailForm.setShowDiscrpHistory(contextString);
				} else if(Constants.DEMOGRAPHIC_INFO.equals(contextString)) {
					discrepancyDetailForm.setShowDemoGrpInfo(contextString);
				} else if(Constants.PARTD_DISCRP_LIST.equals(contextString)) {
					discrepancyDetailForm.setShowPartDDiscrpList(contextString);
				}
			}
		} else { // This is for default context because in defult detail  must be open
			discrepancyDetailForm.setShowDiscrpList(Constants.DISCRP_LIST);
			discrepancyDetailForm.setShowDiscrpDetail(Constants.DISCRP_DETAIL);
			discrepancyDetailForm.setShowDiscrpHistory(Constants.DISCRP_HISTORY);
			discrepancyDetailForm.setShowPartDDiscrpList(Constants.PARTD_DISCRP_LIST);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
}
