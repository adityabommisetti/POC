/*
 * Created on May 2, 2008
 */
/**$Id: ProfileFacadeManager.java,v 1.1 2014/06/26 07:56:57 praveen Exp $*/
package com.ps.mss.web.ajax;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.manager.ProfileManager;
import com.ps.mss.model.FilterVO;
import com.ps.mss.model.ProfileSearchDetailVO;
import com.ps.mss.model.ProfileSearchVO;
import com.ps.mss.model.ProfileSearchVOList;
import com.ps.mss.web.helper.AjaxHelper;
import com.ps.mss.web.helper.SessionHelper;

/**
 * @author palat.pradeep
 */
public class ProfileFacadeManager {
	private static Logger logger=LoggerFactory.getLogger(ProfileFacadeManager.class);
	/**
	 * @return "TRUE" or Max valid Number of records to show  
	 * @throws ApplicationException
	 */
	/*
	public String isPrintPDFDiscDetailRequestValid(String menuName)throws ApplicationException{
		AjaxHelper.validateUser();
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		FilterVO filterVO = null;
		Map discrpVOMap = null;
		if(Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(menuName)) {
			filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DETAIL_FILTERVO);
			discrpVOMap = (Map)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DISCRP_DETAIL_MAP);
		} else {
			filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_FILTERVO);
			discrpVOMap = (Map)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_MAP);
		}
		
		return DiscrepancyManager.isPrintPDFDiscDetailRequestValid(AjaxHelper.getActiveDataBaseName(),filterVO,discrpVOMap);	
	}
*/	
	/**
	 * This method is get list of all discrepancies satisfying the search criteria
	 * @param move
	 * @return
	 * @throws ApplicationException
	 */
	public ProfileSearchDetailVO getProfileSearchDetailVO(String move, String menuName, String partName, String pdFetchList) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		AjaxHelper.validateUser();
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		FilterVO filterVO = null;
		Map profileVOMap = null;

		filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_PROFILE_DETAIL_FILTERVO);
		profileVOMap = (Map)sessionHelper.getAttribute(Constants.SESSION_PROFILE_DETAIL_MAP);

		Map planMap = getPlanForParts();
		Map profileDateRangeMap = (Map)sessionHelper.getAttribute(Constants.SESSION_PROFILE_DATE_RANGE);
		String tempPartName = filterVO.getDiscrepancyIndicator();
		filterVO.setDiscrepancyIndicator(partName);
		ProfileSearchDetailVO profileSearchDetailVO =  ProfileManager.getProfileSearchDetailVO(filterVO, profileVOMap, move, AjaxHelper.getActiveDataBaseName(),planMap, pdFetchList,menuName, profileDateRangeMap);
		//DiscrepancyListVO discrepancyListVO []  = discrepancyDetailVOList.getDiscrepancyListVO();
		setDetailMap(profileVOMap, profileSearchDetailVO,sessionHelper,menuName,partName, pdFetchList);
		filterVO.setDiscrepancyIndicator(tempPartName);
		logger.info(LoggerConstants.methodEndLevel());
		return profileSearchDetailVO;
	}

	
	/**
	 * @param request
	 * @return
	 * @throws ApplicationException
	 */
	private Map getPlanForParts() throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		Map planMap = sessionHelper.getPlanForParts();
		logger.info(LoggerConstants.methodEndLevel());
		return planMap;
	}
	
	/**
	 * This set detailMap which contain total number of page ,records , first and last record of discrpancyList 
	 * @param discrpMap
	 * @param discrepancyDetailVOList
	 * @param sessionHelper
	 * @param partName
	 * @param string
	 */
	private void setDetailMap(Map discrpMap, ProfileSearchDetailVO profileSearchDetailVO, SessionHelper sessionHelper, String menuName, String partName, String pdFetchList) {
		logger.info(LoggerConstants.methodStartLevel());
		if(profileSearchDetailVO != null) {
			if(discrpMap == null )
				discrpMap = new HashMap ();
			if(Constants.PARTC.equals(partName)) {
				discrpMap.put(Constants.PARTC_PROFILE_DETAIL_MAP,createMap(profileSearchDetailVO.getPartCProfileSearchVOList()));
				
			} else if(Constants.PARTD.equals(partName)) {
				if ( Constants.PROFILE_PARTD_FETCH_BOTHLIST.equals(pdFetchList) || Constants.PROFILE_PARTD_FETCH_PLNLIST.equals(pdFetchList)){
					discrpMap.put(Constants.PARTD_PROFILE_DETAIL_MAP,createMap(profileSearchDetailVO.getPartDProfileSearchVOList()));
				}
				
				if ( Constants.PROFILE_PARTD_FETCH_BOTHLIST.equals(pdFetchList) || Constants.PROFILE_PARTD_FETCH_PBPLIST.equals(pdFetchList)){
					discrpMap.put(Constants.PARTD_PBP_PROFILE_DETAIL_MAP,createPbpMap(profileSearchDetailVO.getPartDPBPProfileSearchVOList()));
				}
			}

			discrpMap.remove(Constants.SESSION_MAX_RECORD_COUNT);
			sessionHelper.setAttribute(Constants.SESSION_PROFILE_DETAIL_MAP,discrpMap);	
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	/**
	 * 
	 * @param profileSearchVOList
	 * @return
	 */
	private Map createMap(ProfileSearchVOList profileSearchVOList){
		logger.info(LoggerConstants.methodStartLevel());
		Map discrpMap = null;
		if(profileSearchVOList != null) {
			discrpMap = new HashMap ();
				ProfileSearchVO [] profileSearchVOArr = profileSearchVOList.getProfileSearchVOList();
				if(profileSearchVOArr != null ){
					discrpMap.put(Constants.FIRST_DETAIL_VO,profileSearchVOArr[0]);
					discrpMap.put(Constants.LAST_DETAIL_VO,profileSearchVOArr[profileSearchVOArr.length-1]);
					discrpMap.put(Constants.CURRENT_PAGE, profileSearchVOList.getCurrentPage());
					discrpMap.put(Constants.PAGE_NUMBER , new Integer(profileSearchVOList.getPageNumber()));
				}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return discrpMap;
	}
	
	/**
	 * 
	 * @param profileSearchVOList
	 * @return
	 */
	private Map createPbpMap(ProfileSearchVOList profileSearchVOList){
		logger.info(LoggerConstants.methodStartLevel());
		Map profileMap = null;
		if ( profileSearchVOList != null) {
			profileMap = new HashMap ();
				ProfileSearchVO [] profileSearchVOArr = profileSearchVOList.getProfileSearchVOList();
				if ( profileSearchVOArr != null ){
					profileMap.put(Constants.FIRST_PBP_DETAIL_VO, profileSearchVOArr[0]);
					profileMap.put(Constants.LAST_PBP_DETAIL_VO, profileSearchVOArr[profileSearchVOArr.length-1]);
					profileMap.put(Constants.CURRENT_PBP_DISCRP_PAGE, profileSearchVOList.getCurrentPage());
					profileMap.put(Constants.PBP_PAGE_NUMBER , new Integer(profileSearchVOList.getPageNumber()));
				}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return profileMap;
	}	

}
