/*
 * $Id: ReinsuranceAction.java,v 1.1 2014/06/26 07:56:47 praveen Exp $
 */
package com.ps.mss.web.actions;

import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.Action;
import org.apache.struts.action.DynaActionForm;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.ReinsuranceService;
import com.ps.mss.framework.Constants;
import com.ps.mss.model.FilterVO;
import com.ps.mss.model.ReinddirItem;
import com.ps.mss.model.ReinsuranceContext;
import com.ps.mss.web.forms.GenericDisplayPageForm;
import com.ps.mss.web.helper.DispatchActionHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.web.helper.Utility;
import com.ps.util.NameValuePair;
import com.ps.util.StringUtil;
import com.ps.mss.helper.ServiceHelper;
import com.ps.mss.exception.ApplicationException;

/**
 * @author palat.pradeep
 */
public class ReinsuranceAction extends Action {

	private static Logger logger=LoggerFactory.getLogger(ReinsuranceAction.class);


/*	public ReinsuranceAction(){
		logger.error("Called in constructor of ReinsuranceAction");
	}*/

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		DynaActionForm genericForm = (DynaActionForm) form;
		String target = "error";
		SessionHelper sessionHelper = new SessionHelper(request);
		String method = (String)genericForm.get("method");		
		String tabName = "";
		FilterVO filter = null;
		try{			
			ReinsuranceService reinsuranceService = new ReinsuranceService(sessionHelper.getActiveDataBaseName());		
			ReinsuranceContext reinsuranceForm = (ReinsuranceContext) sessionHelper.getAttribute(Constants.SESSION_REINSURANCE_FORM);	
			if (reinsuranceForm == null) {
				reinsuranceForm = new ReinsuranceContext();
				sessionHelper.setAttribute(Constants.SESSION_REINSURANCE_FORM, reinsuranceForm);
				init(sessionHelper, reinsuranceService, reinsuranceForm);
			}
			reinsuranceForm.setMethod(method);
			if (Constants.PAGE_FORECASTSUM.equals(method)) {
				filter = reinsuranceForm.getSummaryFilter();
				copyFilterToContext(filter, reinsuranceForm);
				target = forecastSummary(request, sessionHelper, reinsuranceService, genericForm, reinsuranceForm, filter); 
			} else if (Constants.PAGE_LICS_DETAIL.equals(method)) {
				filter = reinsuranceForm.getDetailFilter();
				copyFilterToContext(filter, reinsuranceForm);
				target = getLicsDetail(request, sessionHelper, reinsuranceService, genericForm, reinsuranceForm, filter); 
			} 
			//Added for CGAP Screen IFOX-00432723 :: START
			else if (Constants.PAGE_CGAP_DETAIL.equals(method)) {
				filter = reinsuranceForm.getDetailFilter();
				copyFilterToContext(filter, reinsuranceForm);
				target = getCgapDetail(request, sessionHelper, reinsuranceService, genericForm, reinsuranceForm, filter); 
			} 
			//Added for CGAP Screen IFOX-00432723 :: END
			else if (Constants.PAGE_REIN_DETAIL.equals(method)) {
				filter = reinsuranceForm.getDetailFilter();
				copyFilterToContext(filter, reinsuranceForm);
				target = getReinDetail(request, sessionHelper, reinsuranceService, genericForm, reinsuranceForm, filter); 
			} else if (Constants.PAGE_RISK_DETAIL.equals(method)) {
				filter = reinsuranceForm.getDetailFilter();
				copyFilterToContext(filter, reinsuranceForm);
				target = getRiskRecon(request, sessionHelper, reinsuranceService, genericForm, reinsuranceForm, filter);
			} else{
				filter = reinsuranceForm.getFilter();
				NameValuePair[] planIdArr = reinsuranceForm.getPlanNameList();
				
				if(planIdArr != null && planIdArr.length == 1) {
					filter.setPlanName(planIdArr[0].getName());
				}
				copyFilterToContext(filter, reinsuranceForm);
				target = getReinsurance(request, sessionHelper, reinsuranceService, genericForm, reinsuranceForm);
			}
			String planPbpArray = Utility.buildPlanPBPArray(reinsuranceForm.getPlanPbpSegMap());
			request.setAttribute("tree", planPbpArray);
			
		}catch ( Exception ex){
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			logger.debug("Exception in execute "  + ex);
//			logger.error("Exception in execute "  + ex);
		}
		
		DispatchActionHelper.setTabAndFormName(request, Constants.PARTD_MENU, "ReinsuranceForm");
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(target);
	}

	private void init(SessionHelper sessionHelper, ReinsuranceService reinsuranceService, ReinsuranceContext reinsuranceForm)throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		Map planMap = sessionHelper.getPlanForParts(); //this is part C and part D
		List partD = (List)planMap.get(Constants.PartD_Plan);
		if (partD != null) {
			NameValuePair[] planNameList = new NameValuePair[partD.size()];
			Iterator it = partD.iterator();
			int i = 0;
			Map planNamesMap = (Map)planMap.get(Constants.PLAN_NAME);
			while(it.hasNext()) {
				String planId = (String) it.next();
				NameValuePair item = new NameValuePair();
				item.setValue(planId);
				String planName = StringUtil.trimToNull((String)planNamesMap.get(planId));
				item.setName(planName != null ? planId +" - " + planName : planId);
				planNameList[i++] = item;
			}
			reinsuranceForm.setPlanNameList(planNameList);
			NameValuePair[] planIdArr = reinsuranceForm.getPlanNameList();
			
			if(planIdArr != null && planIdArr.length == 1) {
				reinsuranceForm.setPlanName(planIdArr[0].getName());
			}
		}	
		
		String update = StringUtil.nonNullTrim((String)sessionHelper.getAttribute("REIN_UPDATE"));
		if (update.equals("TRUE"))
			reinsuranceForm.setUpdateAble(true);
		else
			reinsuranceForm.setUpdateAble(false);
		
		Map planPbpSegMap = reinsuranceService.getPlanPbpAndDates(partD);
		reinsuranceForm.setPlanPbpSegMap(planPbpSegMap);
		reinsuranceForm.generatePaymentYears(2006, getEndYear());
		logger.info(LoggerConstants.methodEndLevel());
	}
	/**
	 * This method fetches the Profile Search Result  
	 * @param request
	 * @param reinsuranceForm
	 * @return
	 * @throws Exception
	 */
	private String getReinsurance(HttpServletRequest request, SessionHelper sessionHelper, ReinsuranceService reinsuranceService ,
			DynaActionForm genericForm, ReinsuranceContext reinsuranceForm) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		String target = "search";		
		String actionType = (String)genericForm.get("actionType");			
		String move = null;
		String print = request.getParameter("print");
		
		FilterVO filter = reinsuranceForm.getFilter();
		
		boolean newSearch = true;
		if (actionType == null || "null".equals(actionType)) {
			actionType = "search";
			newSearch = false;
		}
		
		if( print != null){			
			target = "printReinsurance";		
			//request.setAttribute("uiContextRange",Constants.CONSTANTS_ALL);
			String searchCriteriaHeader = ServiceHelper.getSearchCreiteriaHeader(filter, Constants.PAGE_REINSURANCE, Constants.PARTD_MENU);
   			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCriteriaHeader);			
			
		}else if ("search".equals(actionType)){
			copyInputToFilter(sessionHelper, filter, genericForm, reinsuranceForm);
			//if(filter.getPlanName()!= null) { //commented for FOR IFOX-00406212  //Base Plus Recon UI Issues-Devoted Imp
			//added for FOR IFOX-00406212 START //Base Plus Recon UI Issues-Devoted Imp
			String planName = filter.getPlanName();
			String reinPlanName= reinsuranceForm.getPlanName();
			  if(filter.getPlanName()==null){
				  NameValuePair[] planIdArr = reinsuranceForm.getPlanNameList();
					
					if(planIdArr != null && planIdArr.length == 1) {
						filter.setPlanName(planIdArr[0].getName().substring(0,5));
						reinsuranceForm.setPlanName(planIdArr[0].getName().substring(0,5));
					}
			  }
			//added for FOR IFOX-00406212  END //Base Plus Recon UI Issues-Devoted Imp
				List reindirList = reinsuranceService.getReinddir(filter, reinsuranceForm.getPbpList(), reinsuranceForm.getPaymentYears());
				reinsuranceForm.setReinddirItems(reindirList);
				//added for FOR IFOX-00406212  Start //Base Plus Recon UI Issues-Devoted Imp, added to put filter and reinsuranceForm plan names to what they were before
				filter.setPlanName(planName);
				reinsuranceForm.setPlanName(reinPlanName);
				//added for FOR IFOX-00406212  END //Base Plus Recon UI Issues-Devoted Imp
			//}
			copyFilterToContext(filter, reinsuranceForm);
			reinsuranceForm.setLastAction(ReinsuranceContext.SEARCH);
			if (newSearch) {
				reinsuranceForm.setDetailFilter(filter.cloneFilter());
				reinsuranceForm.setSummaryFilter(filter.cloneFilter());
			}
		}
		
		else if ("update".equals(actionType)) {
			String amounts = StringUtil.trimToNull((String)genericForm.get("amounts"));
			if (amounts == null) {
				//request.setAttribute("Msg", )
				logger.info(LoggerConstants.methodEndLevel());
				return "error";
			}
			String[] amountArray = amounts.split("\\|");
			List reindirList = reinsuranceForm.getReinddirItems();
			if (amountArray.length != reindirList.size()){
				logger.info(LoggerConstants.methodEndLevel());
				return "error";
			}
			reindirList = reinsuranceService.updateReinddir(filter, reindirList, amountArray, sessionHelper.getUserId());
			Iterator it = reindirList.iterator();
			boolean anyError = false;
			while (it.hasNext()) {
				ReinddirItem item = (ReinddirItem) it.next();
				if (item.getStatus() == ReinddirItem.FAIL || item.getStatus() == ReinddirItem.INVALID_FORMAT)
					anyError = true;
			}
			reinsuranceForm.setAnyError(anyError);
			reinsuranceForm.setReinddirItems(reindirList);
			reinsuranceForm.setLastAction(ReinsuranceContext.UPDATED); //Very important!!
		}
		else if ("repaint".equals(actionType) && reinsuranceForm.getLastAction() == ReinsuranceContext.SEARCH 
				&& filter.getPlanName()!= null) { 
			List reindirList = reinsuranceService.getReinddir(filter, reinsuranceForm.getPbpList(), reinsuranceForm.getPaymentYears());
			reinsuranceForm.setReinddirItems(reindirList);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return target;
	}

	private String forecastSummary(HttpServletRequest request, SessionHelper sessionHelper, ReinsuranceService reinsuranceService ,DynaActionForm genericForm, 
			ReinsuranceContext context, FilterVO filter) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		String target = Constants.PAGE_FORECASTSUM; 
		boolean printRequest = StringUtil.trimToNull(request.getParameter("print"))!=null;
		String actionType = StringUtil.trimToNull((String)genericForm.get("actionType"));	
		//I know... this is weird, that it's checking for "null". This is set in the script.js, and I don't want to
		//break existing stuff.
		if (actionType == null || "null".equals(actionType))
			actionType = "repaint";
		
		//setup return object for the viewer
		GenericDisplayPageForm display = new GenericDisplayPageForm();
		request.setAttribute(Constants.ATTR_DISPLAY_PAGE, display);
		StringBuffer header = new StringBuffer("");
		List forecastList = null;
		if ("search".equals(actionType)){
			copyInputToFilter(sessionHelper, filter, genericForm, context);
			//Added fix for all plans search START 
			if(filter.getPlanName() == null){
				forecastList = reinsuranceService.forecastSummaryAll(filter, header, context.getPlanNameList());
			} else {
				forecastList = reinsuranceService.forecastSummary(filter, header);
			}
			//Added fix for all plans search END 
			copyFilterToContext(filter, context);
			context.setDetailFilter(filter.cloneFilter());
			context.setFilter(filter.cloneFilter());
			context.setLastAction(ReinsuranceContext.ANNUAL_RECON_SEARCH);
		}		
		else if ("repaint".equals(actionType))
			forecastList = reinsuranceService.forecastSummary(filter, header);
		
		display.setTitle(header.toString());
		display.setListObject(forecastList);		
		display.setDetail(ServiceHelper.calculateTotals(forecastList)); //calculate total for the viewer
		
		if( printRequest){			
			target = "print" + Constants.PAGE_FORECASTSUM;
			String searchCriteriaHeader = ServiceHelper.getSearchCreiteriaHeader(filter, Constants.PAGE_FORECASTSUM, Constants.PARTD_MENU );
   			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCriteriaHeader);			
		}		
		logger.info(LoggerConstants.methodEndLevel());
		return target;
	}

	private String getLicsDetail(HttpServletRequest request, SessionHelper sessionHelper, ReinsuranceService reinsuranceService ,DynaActionForm genericForm, 
			ReinsuranceContext context, FilterVO filter) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		String target = Constants.PAGE_LICS_DETAIL; 
		boolean printRequest = StringUtil.trimToNull(request.getParameter("print"))!=null;
		String actionType = StringUtil.trimToNull((String)genericForm.get("actionType"));	
		//I know... this is weird, that it's checking for "null". This is set in the script.js, and I don't want to
		//break existing stuff.
		if (actionType == null || "null".equals(actionType))
			actionType = "repaint";
		
		//setup return object for the viewer
		GenericDisplayPageForm display = new GenericDisplayPageForm();
		request.setAttribute(Constants.ATTR_DISPLAY_PAGE, display);
		StringBuffer header = new StringBuffer("");
		List items = null;
		if ("search".equals(actionType) || "drill".equals(actionType)){
			copyInputToFilter(sessionHelper, filter, genericForm, context);
			items = reinsuranceService.licsDetail(filter, header);
			copyFilterToContext(filter, context);
			if ("search".equals(actionType)) {
				context.setSummaryFilter(filter.cloneFilter());
				context.setFilter(filter.cloneFilter());
				context.setLastAction(ReinsuranceContext.DETAIL_SEARCH);
			}
				
		}		
		else if ("repaint".equals(actionType))  
			items = reinsuranceService.licsDetail(filter, header);
		
		display.setTitle(header.toString());
		display.setListObject(items);	
		display.setDetail(ServiceHelper.calculateTotals(items)); //calculate total for the viewer
		
		if( printRequest){			
			target = "print" + Constants.PAGE_LICS_DETAIL;
			String searchCriteriaHeader = ServiceHelper.getSearchCreiteriaHeader(filter, Constants.PAGE_LICS_DETAIL, Constants.PARTD_MENU );
   			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCriteriaHeader);			
		}		
		logger.info(LoggerConstants.methodEndLevel());
		return target;
	}
	
	//Added for CGAP Screen IFOX-00432723 :: START
	private String getCgapDetail(HttpServletRequest request, SessionHelper sessionHelper, ReinsuranceService reinsuranceService ,DynaActionForm genericForm, 
			ReinsuranceContext context, FilterVO filter) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		String target = Constants.PAGE_CGAP_DETAIL; 
		boolean printRequest = StringUtil.trimToNull(request.getParameter("print"))!=null;
		String actionType = StringUtil.trimToNull((String)genericForm.get("actionType"));	
		//I know... this is weird, that it's checking for "null". This is set in the script.js, and I don't want to
		//break existing stuff.
		if (actionType == null || "null".equals(actionType))
			actionType = "repaint";
		
		//setup return object for the viewer
		GenericDisplayPageForm display = new GenericDisplayPageForm();
		request.setAttribute(Constants.ATTR_DISPLAY_PAGE, display);
		StringBuffer header = new StringBuffer("");
		List items = null;
		if ("search".equals(actionType) || "drill".equals(actionType)){
			copyInputToFilter(sessionHelper, filter, genericForm, context);
			items = reinsuranceService.cgapDetail(filter, header);
			copyFilterToContext(filter, context);
			if ("search".equals(actionType)) {
				context.setSummaryFilter(filter.cloneFilter());
				context.setFilter(filter.cloneFilter());
				context.setLastAction(ReinsuranceContext.DETAIL_SEARCH);
			}
				
		}		
		else if ("repaint".equals(actionType))  
			items = reinsuranceService.cgapDetail(filter, header);
		
		display.setTitle(header.toString());
		display.setListObject(items);	
		display.setDetail(ServiceHelper.calculateTotals(items)); //calculate total for the viewer
		
		if( printRequest){			
			target = "print" + Constants.PAGE_CGAP_DETAIL;
			String searchCriteriaHeader = ServiceHelper.getSearchCreiteriaHeader(filter, Constants.PAGE_CGAP_DETAIL, Constants.PARTD_MENU );
   			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCriteriaHeader);			
		}		
		logger.info(LoggerConstants.methodEndLevel());
		return target;
	}
	//Added for CGAP Screen IFOX-00432723 :: END
	
	private String getReinDetail(HttpServletRequest request, SessionHelper sessionHelper, ReinsuranceService reinsuranceService ,DynaActionForm genericForm, 
			ReinsuranceContext context, FilterVO filter) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		String target = Constants.PAGE_REIN_DETAIL; 
		boolean printRequest = StringUtil.trimToNull(request.getParameter("print"))!=null;
		String actionType = StringUtil.trimToNull((String)genericForm.get("actionType"));	
		//I know... this is weird, that it's checking for "null". This is set in the script.js, and I don't want to
		//break existing stuff.
		if (actionType == null || "null".equals(actionType))
			actionType = "repaint";
		
		//setup return object for the viewer
		GenericDisplayPageForm display = new GenericDisplayPageForm();
		request.setAttribute(Constants.ATTR_DISPLAY_PAGE, display);
		StringBuffer header = new StringBuffer("");
		List items = null;
		if ("search".equals(actionType) || "drill".equals(actionType)){
			copyInputToFilter(sessionHelper, filter, genericForm, context);
			items = reinsuranceService.reinDetail(filter, header);
			copyFilterToContext(filter, context);
			if ("search".equals(actionType)) {
				context.setSummaryFilter(filter.cloneFilter());
				context.setFilter(filter.cloneFilter());
				context.setLastAction(ReinsuranceContext.DETAIL_SEARCH);
			}
		}		
		else if ("repaint".equals(actionType))  
			items = reinsuranceService.reinDetail(filter, header);
		
		display.setTitle(header.toString());
		display.setListObject(items);	
		display.setDetail(ServiceHelper.calculateTotals(items)); //calculate total for the viewer
		
		if( printRequest){			
			target = "print" + Constants.PAGE_REIN_DETAIL;
			String searchCriteriaHeader = ServiceHelper.getSearchCreiteriaHeader(filter, Constants.PAGE_REIN_DETAIL, Constants.PARTD_MENU );
   			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCriteriaHeader);			
		}		
		logger.info(LoggerConstants.methodEndLevel());
		return target;
	}
	
	private String getRiskRecon(HttpServletRequest request, SessionHelper sessionHelper, ReinsuranceService reinsuranceService ,DynaActionForm genericForm, 
			ReinsuranceContext context, FilterVO filter) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		String target = Constants.PAGE_RISK_DETAIL; 
		boolean printRequest = StringUtil.trimToNull(request.getParameter("print"))!=null;
		String actionType = StringUtil.trimToNull((String)genericForm.get("actionType"));	
		//I know... this is weird, that it's checking for "null". This is set in the script.js, and I don't want to
		//break existing stuff.
		if (actionType == null || "null".equals(actionType))
			actionType = "repaint";
		
		//setup return object for the viewer
		GenericDisplayPageForm display = new GenericDisplayPageForm();
		request.setAttribute(Constants.ATTR_DISPLAY_PAGE, display);
		StringBuffer header = new StringBuffer("");
		List items = null;
		if ("search".equals(actionType) || "drill".equals(actionType)){
			copyInputToFilter(sessionHelper, filter, genericForm, context);
			items = reinsuranceService.riskRecon(filter, header);
			copyFilterToContext(filter, context);
			if ("search".equals(actionType)) {
				context.setSummaryFilter(filter.cloneFilter());
				context.setFilter(filter.cloneFilter());
				context.setLastAction(ReinsuranceContext.DETAIL_SEARCH);
			}
		}		
		else if ("repaint".equals(actionType))  
			items = reinsuranceService.riskRecon(filter, header);
		
		display.setTitle(header.toString());
		display.setListObject(items);	
		display.setDetail(ServiceHelper.calculateTotals(items)); //calculate total for the viewer
		
		if( printRequest){			
			target = "print" + Constants.PAGE_RISK_DETAIL;
			String searchCriteriaHeader = ServiceHelper.getSearchCreiteriaHeader(filter, Constants.PAGE_RISK_DETAIL, Constants.PARTD_MENU );
   			request.setAttribute(Constants.SESSION_SEARCH_CREITERIA_HEADER, searchCriteriaHeader);			
		}		
		logger.info(LoggerConstants.methodEndLevel());
		return target;
	}
	
	private void copyInputToFilter(SessionHelper sessionHelper, FilterVO filter, DynaActionForm genericForm, 
			ReinsuranceContext context) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		//copy input to filter
		
		FilterVO ddirFilter = new FilterVO();
		FilterVO sumFilter = new FilterVO();
		FilterVO dtlFilter = new FilterVO();
		
		boolean ddir = false;
		boolean sum = false;
		boolean dtl = false;
		
		if (context.getLastAction() == ReinsuranceContext.SEARCH) {
			ddirFilter = context.getFilter();
			ddir = true;
		}
		else if (context.getLastAction() == ReinsuranceContext.ANNUAL_RECON_SEARCH) {
			sumFilter = context.getSummaryFilter();
			sum = true;
		}
		else if (context.getLastAction() == ReinsuranceContext.DETAIL_SEARCH) {
			dtlFilter = context.getDetailFilter();
			dtl = true;
		}
		
		String planName = StringUtil.trimToNull((String)genericForm.get("planName"));
		if (planName != null) {
			if (! validatePlanName(planName, sessionHelper)) {
				logger.debug("planName " + planName + " is not valid for this customer");
				throw new ApplicationException("Unexpected Error");
			}
		}
		filter.setPlanName(planName);
		context.setPlanName(planName);
		String temp = StringUtil.trimToNull((String)genericForm.get("pbpId"));
		context.setPbpId(temp);
		filter.setPbpId(temp);
		int quarter = 0;
		temp = StringUtil.trimToNull((String)genericForm.get("quarter"));
		if (temp != null) {
			quarter = Integer.parseInt(temp);
			filter.setQuarter(String.valueOf(quarter));
		}
		else{
			if (ddir) {
				temp = ddirFilter.getQuarter();
				if (temp != null) {
					quarter = Integer.parseInt(ddirFilter.getQuarter());
					filter.setQuarter(String.valueOf(quarter));
				}
			}
			else if (sum) {
				temp = sumFilter.getQuarter();
				if (temp != null) {
					quarter = Integer.parseInt(sumFilter.getQuarter());
					filter.setQuarter(String.valueOf(quarter));
				}
			}
			else if (dtl) {
				temp = dtlFilter.getQuarter();
				if (temp != null) {
					quarter = Integer.parseInt(dtlFilter.getQuarter());
					filter.setQuarter(String.valueOf(quarter));
				}
			}
		}
		context.setQuarter(quarter);
		temp = StringUtil.nonNullTrim((String)genericForm.get("fromDate"));
		if (temp.length() == 0 && sum) {
			temp = sumFilter.getStartDate();
		}
		else if (temp.length() == 0 && dtl) {
			temp = dtlFilter.getStartDate();
		}
		else if (temp.length() == 0 && ddir) {
			temp = ddirFilter.getStartDate();
		}
		if(temp.length() > 4)
			temp = temp.substring(0,4);
		context.setPaymentYear(temp);
		if ("".equals(temp))
			filter.setStartDate(temp);
		else {
			switch (quarter) {
			case 1: 
				filter.setEndDate(temp.concat("03"));
				filter.setStartDate(temp.concat("01"));
				break;
			case 2: 
				filter.setEndDate(temp.concat("06"));
				filter.setStartDate(temp.concat("04"));
				break;
			case 3: 
				filter.setEndDate(temp.concat("09"));
				filter.setStartDate(temp.concat("07"));
				break;
			case 4: 
				filter.setEndDate(temp.concat("12"));
				filter.setStartDate(temp.concat("10"));
				break;
			default: //0 - all quarter from jan to dec
				filter.setEndDate(temp.concat("12"));
				filter.setStartDate(temp.concat("01"));
				break;
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	private void copyFilterToContext(FilterVO filter, ReinsuranceContext context) {
		logger.info(LoggerConstants.methodStartLevel());
		context.setPlanName(filter.getPlanName());
		context.setPbpId(filter.getPbpId());
		String temp="";
		if (StringUtil.trimToNull(filter.getStartDate()) != null)
			temp = filter.getStartDate().substring(0,4);
		context.setPaymentYear(temp);
		//TODO set qtr based on startDate and endDate
		int qtr = 0;
		if (StringUtil.trimToNull(filter.getStartDate())!=null && StringUtil.trimToNull(filter.getEndDate())!=null) {
			String startDate = filter.getStartDate().substring(4,6);
			String endDate = filter.getEndDate().substring(4,6);
			if ("01".equals(startDate) && "03".equals(endDate)) qtr=1;
			else if ("04".equals(startDate) && "06".equals(endDate)) qtr=2;
			else if ("07".equals(startDate) && "09".equals(endDate)) qtr=3;
			else if ("10".equals(startDate) && "12".equals(endDate)) qtr=4;
		}
		context.setQuarter(qtr);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	private int getEndYear() {
		logger.info(LoggerConstants.methodStartLevel());
		Calendar calendar = Calendar.getInstance();
		int yr= calendar.get(Calendar.YEAR);
		//int mt = calendar.get(Calendar.MONTH); // [0..11]
		//if (mt <= Calendar.MARCH) //previous quarter will be last year
		//	yr--;
		logger.info(LoggerConstants.methodEndLevel());
		return yr;
	}
	private boolean validatePlanName(String planName, SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		boolean result = false;
		try {
			Map planMap = sessionHelper.getPlanForParts(); //this is part C and part D
			List partD = (List)planMap.get(Constants.PartD_Plan);
			if (partD.contains(planName))
				result = true;
		}
		catch (ApplicationException e){ 
		}
		logger.info(LoggerConstants.methodEndLevel());
		return result;
	}
	

}
