/*
 * $Id: EEMEnrollForm.java,v 1.8 2014/12/10 10:04:10 praveen Exp $
 */

package com.ps.mss.web.forms;

import java.util.List;

import com.ps.mss.dao.model.EmCorrMbrVO;
import com.ps.mss.dao.model.EmMbrAccretionVO;
import com.ps.mss.dao.model.EmMbrAddressVO;
import com.ps.mss.dao.model.EmMbrAgentVO;
import com.ps.mss.dao.model.EmMbrBillingVO;
import com.ps.mss.dao.model.EmMbrCobVO;
import com.ps.mss.dao.model.EmMbrCommentVO;
import com.ps.mss.dao.model.EmMbrDemographicVO;
import com.ps.mss.dao.model.EmMbrDsInfoVO;
import com.ps.mss.dao.model.EmMbrEnrollmentVO;
import com.ps.mss.dao.model.EmMbrErrorVO;
import com.ps.mss.dao.model.EmMbrLepAttestInfoVO;
import com.ps.mss.dao.model.EmMbrLepInfoVO;
import com.ps.mss.dao.model.EmMbrLisInfoVO;
import com.ps.mss.dao.model.EmMbrOevInfoVO;
import com.ps.mss.dao.model.EmMbrOoaInfoVO;
import com.ps.mss.dao.model.EmMbrTrrLogVO;
import com.ps.mss.model.EMMbrPCPInfoVO;
import com.ps.mss.model.EmMbrPosEditVO;
import com.ps.text.DateFormatter;
import com.ps.util.ListBoxItem;

public class EEMMedicaidForm extends EEMForm {

	// Search criteria
	private String searchMemberId;
	private String searchHicNo;
	private String searchSSN;
	private String searchSupplementalId;
    private String searchLastName;
    private String searchEffectiveMonth;
    private String searchShowAll;

    // Search results
    private List listSearchResults;
	private int selectedSearchRow;
	private boolean searchExpanded;
	
	private String selectedMemberTab;
	private String tabPageMove;
	
	// Demographic tab
	private List listDemographics;
	private EmMbrDemographicVO displayDemographic = new EmMbrDemographicVO();
	private boolean demographicChanged;

	// Enrollment tab
	private List listEnrollments;
	private int selectedEnrollmentRow;
	private int topDisplayEnrollmentRow;	
	private EmMbrEnrollmentVO displayEnrollment = new EmMbrEnrollmentVO();
	private boolean enrollmentChanged;
	private String enrollmentDisplayState;
	//Cancellation
	private List enrollCancelReasons;	
	private String currEnrlStatus;
	private String currEnrlResCd;
	

	// DSInfo tab
	private List listDsInfos;
	private int selectedDsInfoRow;
	private int topDisplayDsInfoRow;
	private EmMbrDsInfoVO displayDsInfo = new EmMbrDsInfoVO();
	private boolean dsInfoChanged;
	private String dsInfoDisplayState;

	// LisInfo tab
	private List listLisInfos;
	private int selectedLisInfoRow;
	private int topDisplayLisInfoRow;
	private EmMbrLisInfoVO displayLisInfo = new EmMbrLisInfoVO();
	private boolean lisInfoChanged;
	private String lisInfoDisplayState;
	
	// LepInfo tab
	/**
	 * Holds LEP related information
	 */
	private List listLepInfos;
	private int selectedLepInfoRow;
	private int topDisplayLepInfoRow;
	private EmMbrLepInfoVO displayLepInfo = new EmMbrLepInfoVO();
	private boolean lepInfoChanged;
	private String lepInfoDisplayState;

	// pcp tab
	private List listPcpInfos;
	private int selectedPcpInfoRow;
	private int topDisplayPcpInfoRow;
	private EMMbrPCPInfoVO displayPcpInfo = new EMMbrPCPInfoVO();
	private boolean pcpInfoChanged;
	private String pcpInfoDisplayState;

	// Address tab
	private List listAddresses;
	private int selectedAddressRow;
	private int topDisplayAddressRow;
	private EmMbrAddressVO displayAddress = new EmMbrAddressVO();
	private boolean addressChanged;
	private String addressDisplayState;

	// Letter tab
	private List listLetters;
	private int selectedLetterRow;
	private int topDisplayLetterRow;
	private EmCorrMbrVO displayLetter = new EmCorrMbrVO();
	private List displayLetterVarData;
	private boolean letterChanged;
	private String letterDisplayState;

	// Comment tab
	private List listComments;
	private int topDisplayCommentRow;
	private int selectedCommentRow;
	private EmMbrCommentVO displayComment = new EmMbrCommentVO();
	private boolean commentChanged;
	private String commentDisplayState;
	
	// TRR tab
	private List listTrrLogs;
	private int selectedTrrLogRow;
	private int topDisplayTrrLogRow;
	private EmMbrTrrLogVO displayTrrLog = new EmMbrTrrLogVO();
	private boolean trrLogChanged;
	private String trrLogDisplayState;
	
	// Agent tab
	private List listAgents;
	private List lstAgentTypes;
	private List lstAgents;
	private List lstAgencyTypes;
	private List lstAgencies;
	private List lstPlans;
	private int selectedAgentRow;
	private int topDisplayAgentRow;
	private EmMbrAgentVO displayAgent = new EmMbrAgentVO();
	private boolean agentChanged;
	private String agentDisplayState;
	//Agent Search
	private String searchAgencyId;	
	private String searchAgencyName;	
	private List lstSearchAgencies;
	private int agencySrchPageNbr;
    private String agencySrchPageType;
    private String agencySrchMove;

	// COB tab
	private List listCobs;
	private int selectedCobRow;
	private int topDisplayCobRow;
	private EmMbrCobVO displayCob = new EmMbrCobVO();
	private boolean cobChanged;
	private String cobDisplayState;
	
	// Billing tab
	private List listBilling;
	private int selectedBillingRow;
	private int topDisplayBillingRow;
	private EmMbrBillingVO displayBilling = new EmMbrBillingVO();
	private boolean billingChanged;
	private String billingDisplayState;
	
	// error tab
	private List listErrors;
	private int selectedErrorRow;
	private int topDisplayErrorRow;
	private EmMbrErrorVO displayError = new EmMbrErrorVO();
	private boolean errorChanged;
	private String errorDisplayState;

	// Validation lists
	private List validMemberStatus;
	private List validAddressTypes;
	private List validAgentTypes;
	private List validElectionTypes;
	private List validDisenrollmentReasons;
	private List validEnrollStatuses;
	private List validEnrollReasons;
	private List validEnrollStatusReasons;
	private List validEnrollSources;
	private List validGenderCodes;
	private List validLanguages;
	private List validMaritalStatuses;
	private List validPrefixes;
	private List validRaceCodes;
	private List validRelations;
	private List validSepExceptions;
	private List validStates;
	private List validDsCodes;
	private ListBoxItem [] arrYesNo;
	private List validLiPercents;
	private List validLiCopays;
	private List validCountry;
	private List validSEPReasons;
	private List validSubsidySrce;
	private List validCobTypes;
	private List validOhiInd;
	private List validAccountType;
	private List validBillPayMethod;
	private List validBillFrequency;
	/**
	 * Cambia_PWO-Start
	 */
	private String effDate;
	/**
	 * Cambia_PWO-End
	 */
	/**
	 *  033_Highmark_OOA_SCC_UI-Start
	 */
	
	// Ooa Tab
	private List listOoaInfos;
	private List ooaReasonList;
	private List ooaSourceList;
	private List ooaDeReasonList;
	private int selectedOoaInfoRow;
	private int topDisplayOoaInfoRow;
	private EmMbrOoaInfoVO displayOoaInfo = new EmMbrOoaInfoVO();
	private boolean OoaChanged;
	private String ooaInfoDisplayState;
	private String planDesignation;
	private String enrollStatus;
	private String enrollReason;

	/**
     *Cambia (Accretion)  - Start
     */
	//accretion tab
	private List listAccretion;
	private int selectedAccretionRow;
	private int topDisplayAccretionRow;
	private EmMbrAccretionVO displayAccretion = new EmMbrAccretionVO();
	private String accretionDisplayState;
		
	/**
     * Cambia (Accretion)  - End
     */
	/**
	 * Cambia_OEVProcess - Start
	 */
	//OEV tab
 	private  boolean oevDateCheck;
 	private boolean oevDateNext; 
 	private boolean oevInfoChanged;
	private boolean oevReturnInfoChanged;
 	private EmMbrOevInfoVO oevInfo = new EmMbrOevInfoVO();
 	private EmMbrOevInfoVO oevRetInfo = new EmMbrOevInfoVO();
 	private boolean oevCheck;
 	private String oevTimerCheck;
 	private boolean oev2TimerCheck;
 	private String oevButton;
 	private String applDate;
 	//OevCalls
	private List oevCallStatusDrop;
	private List oevCallSubReasonDrop;
	private List oevCallAttempts;
    private List oevCallStatus;
    private List oevCallStatusSaved;
	private List oevRetStatus;
	private List oevRetStatusSaved;
	private List returnCalls;
	private String oevUpdtdate;

//OEV Script
	private String premium;
	private String primCoPay;
	private String spclCoPay;
    private String tier1;
	private String brandTier;
	private String firstName;
	private String lastName;
	private String operId;
	private String genderCd;
	private String planId;
	 private String selectedRowInMemberLetters;
	private String fedralConrtStmt;
	private String userName;
 	private String approvalCode;
    private String oevplanName;
    
    
    // Pos Edit Tab  
    
    	/**
    	 * holds POS related data
    	 */
    	private int selectedPosEditRow;
    	private int topDisplayPosEditRow;
    	private EmMbrPosEditVO displayPosEdit = new EmMbrPosEditVO();
    	private boolean poseditChanged;
    	private String posEditDisplayState;
    	private String posEditOrDeleteOrModifyStatus;
    	private List validTxnStatus;
    	
    	private List listPosEdits;
    	public List getListPosEdits() {
    		return listPosEdits;
    	}
    	public void setListPosEdits(List listPosEdits) {
    		this.listPosEdits = listPosEdits;
    	}
    	public int getSelectedPosEditRow() {
    		return selectedPosEditRow;
    	}
    	public void setSelectedPosEditRow(int selectedPosEditRow) {
    		this.selectedPosEditRow = selectedPosEditRow;
    	}
    	public int getTopDisplayPosEditRow() {
    		return topDisplayPosEditRow;
    	}
    	public void setTopDisplayPosEditRow(int topDisplayPosEditRow) {
    		this.topDisplayPosEditRow = topDisplayPosEditRow;
    	}
    	public EmMbrPosEditVO getDisplayPosEdit() {
    		return displayPosEdit;
    	}
    	public void setDisplayPosEdit(EmMbrPosEditVO displayPosEdit) {
    		this.displayPosEdit = displayPosEdit;
    	}
    	public boolean isPoseditChanged() {
    		return poseditChanged;
    	}
    	public void setPoseditChanged(boolean poseditChanged) {
    		this.poseditChanged = poseditChanged;
    	}
    	public String getPosEditDisplayState() {
    		return posEditDisplayState;
    	}
    	public void setPosEditDisplayState(String posEditDisplayState) {
    		this.posEditDisplayState = posEditDisplayState;
    	}
    	public String getPosEditOrDeleteOrModifyStatus() {
    		return posEditOrDeleteOrModifyStatus;
    	}
    	public void setPosEditOrDeleteOrModifyStatus(
    			String posEditOrDeleteOrModifyStatus) {
    		this.posEditOrDeleteOrModifyStatus = posEditOrDeleteOrModifyStatus;
    	}
    	public List getValidTxnStatus() {
    		return validTxnStatus;
    	}
    	public void setValidTxnStatus(List validTxnStatus) {
    		this.validTxnStatus = validTxnStatus;
    	}

    	public void setListPosWithDisplay(List listPosEdits) {
    		this.listPosEdits = listPosEdits;
    		if ((this.listPosEdits != null) && (this.listPosEdits.isEmpty() == false)) {
    			this.displayPosEdit = (EmMbrPosEditVO) this.listPosEdits.get(selectedCobRow);
    		}
    		else {
    			this.displayPosEdit = new EmMbrPosEditVO();
    		}
    	}
    	/**
    	 * pos end
    	 */
    	
         /**
     	 * Cambia_OEVProcess - End
     	 */
  //To display WorkFlow Activities error message.
    private String wfScreenMsg="";
	  /**
     * Cambia_PRE-SET NOTES- Start
     */
     /**
      * preSetNoteList : Holds the List of the preset notes
      */
    private List preSetNoteList;
    /**
     * preSet : Holds the selected value from the dropdown
     */
 	private String preSet;
 	/**
 	 * radioCheck : Holds the value of the radio button
 	 */
 	private String radioCheck;
 	/**
 	 * ind : Holds the value of the button clicked
 	 */
 	private String indicator;
 	/**
	 * @return the preSetNoteList
	 */
	public List getPreSetNoteList() {
		return preSetNoteList;
	}
	/**
	 * @param preSetNoteList the preSetNoteList to set
	 */
	public void setPreSetNoteList(List preSetNoteList) {
		this.preSetNoteList = preSetNoteList;
	}
	/**
	 * @return the preSet
	 */
	public String getPreSet() {
		return preSet;
	}
	/**
	 * @param preSet the preSet to set
	 */
	public void setPreSet(String preSet) {
		this.preSet = preSet;
	}
	/**
	 * @return the radioCheck
	 */
	public String getRadioCheck() {
		return radioCheck;
	}
	/**
	 * @param radioCheck the radioCheck to set
	 */
	public void setRadioCheck(String radioCheck) {
		this.radioCheck = radioCheck;
	}
	/**
	 * @return the indicator
	 */
	public String getIndicator() {
		return indicator;
	}
	/**
	 * @param indicator the indicator to set
	 */
	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}
	/**
	 * @return the preSetDisplayState
	 */
	public String getPreSetDisplayState() {
		return preSetDisplayState;
	}
	/**
	 * @param preSetDisplayState the preSetDisplayState to set
	 */
	public void setPreSetDisplayState(String preSetDisplayState) {
		this.preSetDisplayState = preSetDisplayState;
	}
	/**
	 * @return the preSetKeyValue
	 */
	public String getPreSetKeyValue() {
		return preSetKeyValue;
	}
	/**
	 * @param preSetKeyValue the preSetKeyValue to set
	 */
	public void setPreSetKeyValue(String preSetKeyValue) {
		this.preSetKeyValue = preSetKeyValue;
	}
	/**
	 * @return the preSetNoteM
	 */
	public String getPreSetNoteM() {
		return preSetNoteM;
	}
	/**
	 * @param preSetNoteM the preSetNoteM to set
	 */
	public void setPreSetNoteM(String preSetNoteM) {
		this.preSetNoteM = preSetNoteM;
	}
	/**
	 * @return the preSetNoteDescr
	 */
	public String getPreSetNoteDescr() {
		return preSetNoteDescr;
	}
	/**
	 * @param preSetNoteDescr the preSetNoteDescr to set
	 */
	public void setPreSetNoteDescr(String preSetNoteDescr) {
		this.preSetNoteDescr = preSetNoteDescr;
	}
	/**
	 * @return the preSetKey
	 */
	public String getPreSetKey() {
		return preSetKey;
	}
	/**
	 * @param preSetKey the preSetKey to set
	 */
	public void setPreSetKey(String preSetKey) {
		this.preSetKey = preSetKey;
	}
	/**
	 * @return the maxId
	 */
	public String getMaxId() {
		return maxId;
	}
	/**
	 * @param maxId the maxId to set
	 */
	public void setMaxId(String maxId) {
		this.maxId = maxId;
	}
	/**
 	 * preSetDisplayState : Holds the value of the display of the screen
 	 */
 	private String preSetDisplayState;
 	private String preSetKeyValue;
 	/**
 	 * preSetNote : Holds the new preset note
 	 */
 	private String preSetNoteM;
 	/**
 	 * preSetNoteDesc : Holds the new preset note description
 	 */
 	private String preSetNoteDescr;
 	/**
 	 * preSetKey : Holds the index of the selected preset note
 	 */
 	private String preSetKey;
    private String maxId;
    
    /**
     * Cambia_PRE-SET NOTES- End
     */
	// Search criteria
	/**
	 * @return Returns the searchShowAll.
	 */
	public String getSearchShowAll() {
		return searchShowAll;
	}
	/**
	 * @param searchShowAll The searchShowAll to set.
	 */
	public void setSearchShowAll(String searchShowAll) {
		this.searchShowAll = searchShowAll;
	}
	
	public String getSearchEffectiveMonth() {
		return searchEffectiveMonth;
	}
	public String getSearchEffectiveMonthFrmt() {
		return DateFormatter.reFormat(searchEffectiveMonth,DateFormatter.YYYYMM,DateFormatter.MM_YYYY);
	}
	public void setSearchEffectiveMonth(String searchEffectiveMonth) {
		this.searchEffectiveMonth = searchEffectiveMonth;
	}
	public void setSearchEffectiveMonthFrmt(String searchEffectiveMonth) {
		this.searchEffectiveMonth = DateFormatter.reFormat(searchEffectiveMonth,DateFormatter.MM_YYYY,DateFormatter.YYYYMM);
	}
	public String getSearchHicNo() {
		return searchHicNo;
	}
	public void setSearchHicNo(String searchHicNo) {
		this.searchHicNo = searchHicNo;
	}
	public String getSearchLastName() {
		return searchLastName;
	}
	public void setSearchLastName(String searchLastName) {
		this.searchLastName = searchLastName;
	}
	public String getSearchMemberId() {
		return searchMemberId;
	}
	public void setSearchMemberId(String searchMemberId) {
		this.searchMemberId = searchMemberId;
	}
	public String getSearchSSN() {
		return searchSSN;
	}
	public void setSearchSSN(String searchSSN) {
		this.searchSSN = searchSSN;
	}
	public String getSearchSupplementalId() {
		return searchSupplementalId;
	}
	public void setSearchSupplementalId(String searchSupplementalId) {
		this.searchSupplementalId = searchSupplementalId;
	}

	
	// Search results
	public List getListSearchResults() {
		return listSearchResults;
	}
	public void setListSearchResults(List listSearchResults) {
		this.listSearchResults = listSearchResults;
	}
	public int getSelectedSearchRow() {
		return selectedSearchRow;
	}
	public void setSelectedSearchRow(int selectedSearchRow) {
		this.selectedSearchRow = selectedSearchRow;
	}

	/**
	 * @return Returns the searchExpanded.
	 */
	public boolean isSearchExpanded() {
		return searchExpanded;
	}
	/**
	 * @param searchExpanded The searchExpanded to set.
	 */
	public void setSearchExpanded(boolean searchExpanded) {
		this.searchExpanded = searchExpanded;
	}
	/**
	 * @return Returns the selectedMemberTab.
	 */
	public String getSelectedMemberTab() {
		return selectedMemberTab;
	}
	/**
	 * @param selectedMemberTab The selectedMemberTab to set.
	 */
	public void setSelectedMemberTab(String selectedMemberTab) {
		this.selectedMemberTab = selectedMemberTab;
	}
	public String getTabPageMove() {
		return tabPageMove;
	}
	public void setTabPageMove(String tabPageMove) {
		this.tabPageMove = tabPageMove;
	}
	
	// Demographic tab
	public boolean isDemographicChanged() {
		return demographicChanged;
	}
	public void setDemographicChanged(boolean demographicChanged) {
		this.demographicChanged = demographicChanged;
	}
	public EmMbrDemographicVO getDisplayDemographic() {
		return displayDemographic;
	}
	public void setDisplayDemographic(EmMbrDemographicVO displayDemographic) {
		this.displayDemographic = displayDemographic;
	}
	public List getListDemographics() {
		return listDemographics;
	}
	public void setListDemographicsWithDisplay(List listDemographics) {
		this.listDemographics = listDemographics;
		if ((this.listDemographics != null) && (this.listDemographics.isEmpty() == false)) {
			this.displayDemographic = (EmMbrDemographicVO) this.listDemographics.get(0);
		}
		else {
			this.displayDemographic = new EmMbrDemographicVO();
		}
	}
	public void setListDemographics(List listDemographics) {
		this.listDemographics = listDemographics;
	}

	// Enrollment tab
	public EmMbrEnrollmentVO getDisplayEnrollment() {
		return displayEnrollment;
	}
	public void setDisplayEnrollment(EmMbrEnrollmentVO displayEnrollment) {
		this.displayEnrollment = displayEnrollment;
	}
	public boolean isEnrollmentChanged() {
		return enrollmentChanged;
	}
	public void setEnrollmentChanged(boolean enrollmentChanged) {
		this.enrollmentChanged = enrollmentChanged;
	}
	public List getListEnrollments() {
		return listEnrollments;
	}
	public void setListEnrollmentsWithDisplay(List listEnrollments) {
		this.listEnrollments = listEnrollments;
		if ((this.listEnrollments != null) && (this.listEnrollments.isEmpty() == false)) {
			this.displayEnrollment = (EmMbrEnrollmentVO) this.listEnrollments.get(selectedEnrollmentRow);
		}
		else {
			this.displayEnrollment = new EmMbrEnrollmentVO();
		}
	}
	public void setListEnrollments(List listEnrollments) {
		this.listEnrollments = listEnrollments;
	}
	public int getSelectedEnrollmentRow() {
		return selectedEnrollmentRow;
	}
	public int getTopDisplayEnrollmentRow() {
		return topDisplayEnrollmentRow;
	}
	public void setTopDisplayEnrollmentRow(int topDisplayEnrollmentRow) {
		this.topDisplayEnrollmentRow = topDisplayEnrollmentRow;
	}
	public void setSelectedEnrollmentRow(int selectedEnrollmentRow) {
		this.selectedEnrollmentRow = selectedEnrollmentRow;
	}
	public String getEnrollmentDisplayState() {
		return enrollmentDisplayState;
	}
	public void setEnrollmentDisplayState(String enrollmentDisplayState) {
		this.enrollmentDisplayState = enrollmentDisplayState;
	}
	
	// DSInfo tab
	public EmMbrDsInfoVO getDisplayDsInfo() {
		return displayDsInfo;
	}
	public void setDisplayDsInfo(EmMbrDsInfoVO displayDsInfo) {
		this.displayDsInfo = displayDsInfo;
	}
	public boolean isDsInfoChanged() {
		return dsInfoChanged;
	}
	public void setDsInfoChanged(boolean dsInfoChanged) {
		this.dsInfoChanged = dsInfoChanged;
	}
	public List getListDsInfos() {
		return listDsInfos;
	}
	public void setListDsInfosWithDisplay(List listDsInfos) {
		this.listDsInfos = listDsInfos;
		if ((this.listDsInfos != null) && (this.listDsInfos.isEmpty() == false)) {
			this.displayDsInfo = (EmMbrDsInfoVO) this.listDsInfos.get(selectedDsInfoRow);
		}
		else {
			this.displayDsInfo = new EmMbrDsInfoVO();
		}
	}
	public void setListDsInfos(List listDsInfos) {
		this.listDsInfos = listDsInfos;
	}
	public int getSelectedDsInfoRow() {
		return selectedDsInfoRow;
	}
	public void setSelectedDsInfoRow(int selectedDsInfoRow) {
		this.selectedDsInfoRow = selectedDsInfoRow;
	}
	public int getTopDisplayDsInfoRow() {
		return topDisplayDsInfoRow;
	}
	public void setTopDisplayDsInfoRow(int topDisplayDsInfoRow) {
		this.topDisplayDsInfoRow = topDisplayDsInfoRow;
	}
	public String getDsInfoDisplayState() {
		return dsInfoDisplayState;
	}
	public void setDsInfoDisplayState(String dsInfoDisplayState) {
		this.dsInfoDisplayState = dsInfoDisplayState;
	}
	
	// LisInfo tab
	public EmMbrLisInfoVO getDisplayLisInfo() {
		return displayLisInfo;
	}
	public void setDisplayLisInfo(EmMbrLisInfoVO displayLisInfo) {
		this.displayLisInfo = displayLisInfo;
	}
	public boolean isLisInfoChanged() {
		return lisInfoChanged;
	}
	public void setLisInfoChanged(boolean lisInfoChanged) {
		this.lisInfoChanged = lisInfoChanged;
	}
	public List getListLisInfos() {
		return listLisInfos;
	}
	public void setListLisInfosWithDisplay(List listLisInfos) {
		this.listLisInfos = listLisInfos;
		if ((this.listLisInfos != null) && (this.listLisInfos.isEmpty() == false)) {
			this.displayLisInfo = (EmMbrLisInfoVO) this.listLisInfos.get(selectedLisInfoRow);
		}
		else {
			this.displayLisInfo = new EmMbrLisInfoVO();
		}
	}
	public void setListLisInfos(List listLisInfos) {
		this.listLisInfos = listLisInfos;
	}
	public int getSelectedLisInfoRow() {
		return selectedLisInfoRow;
	}
	public void setSelectedLisInfoRow(int selectedLisInfoRow) {
		this.selectedLisInfoRow = selectedLisInfoRow;
	}
	public int getTopDisplayLisInfoRow() {
		return topDisplayLisInfoRow;
	}
	public void setTopDisplayLisInfoRow(int topDisplayLisInfoRow) {
		this.topDisplayLisInfoRow = topDisplayLisInfoRow;
	}
	public String getLisInfoDisplayState() {
		return lisInfoDisplayState;
	}
	public void setLisInfoDisplayState(String lisInfoDisplayState) {
		this.lisInfoDisplayState = lisInfoDisplayState;
	}
	
	// LepInfo tab
	public EmMbrLepInfoVO getDisplayLepInfo() {
		return displayLepInfo;
	}
	public void setDisplayLepInfo(EmMbrLepInfoVO displayLepInfo) {
		this.displayLepInfo = displayLepInfo;
	}
	public boolean isLepInfoChanged() {
		return lepInfoChanged;
	}
	public void setLepInfoChanged(boolean lepInfoChanged) {
		this.lepInfoChanged = lepInfoChanged;
	}
	public List getListLepInfos() {
		return listLepInfos;
	}
	public void setListLepInfosWithDisplay(List listLepInfos) {
		this.listLepInfos = listLepInfos;
		if ((this.listLepInfos != null) && (this.listLepInfos.isEmpty() == false)) {
			this.displayLepInfo = (EmMbrLepInfoVO) this.listLepInfos.get(selectedLepInfoRow);
		}
		else {
			this.displayLepInfo = new EmMbrLepInfoVO();
		}
	}
	public void setListLepInfos(List listLepInfos) {
		this.listLepInfos = listLepInfos;
	}
	public int getSelectedLepInfoRow() {
		return selectedLepInfoRow;
	}
	public void setSelectedLepInfoRow(int selectedLepInfoRow) {
		this.selectedLepInfoRow = selectedLepInfoRow;
	}
	public int getTopDisplayLepInfoRow() {
		return topDisplayLepInfoRow;
	}
	public void setTopDisplayLepInfoRow(int topDisplayLepInfoRow) {
		this.topDisplayLepInfoRow = topDisplayLepInfoRow;
	}
	public String getLepInfoDisplayState() {
		return lepInfoDisplayState;
	}
	public void setLepInfoDisplayState(String lepInfoDisplayState) {
		this.lepInfoDisplayState = lepInfoDisplayState;
	}
	
	// Address tab
	public boolean isAddressChanged() {
		return addressChanged;
	}
	public void setAddressChanged(boolean addressChanged) {
		this.addressChanged = addressChanged;
	}
	public EmMbrAddressVO getDisplayAddress() {
		return displayAddress;
	}
	public void setDisplayAddress(EmMbrAddressVO displayAddress) {
		this.displayAddress = displayAddress;
	}
	public List getListAddresses() {
		return listAddresses;
	}
	public void setListAddressesWithDisplay(List listAddresses) {
		this.listAddresses = listAddresses;
		if ((this.listAddresses != null) && (this.listAddresses.isEmpty() == false)) {
			this.displayAddress = (EmMbrAddressVO) this.listAddresses.get(selectedAddressRow);
		}
		else {
			this.displayAddress = new EmMbrAddressVO();
		}
	}
	public void setListAddresses(List listAddresses) {
		this.listAddresses = listAddresses;
	}
	public int getSelectedAddressRow() {
		return selectedAddressRow;
	}
	public void setSelectedAddressRow(int selectedAddressRow) {
		this.selectedAddressRow = selectedAddressRow;
	}
	public int getTopDisplayAddressRow() {
		return topDisplayAddressRow;
	}
	public void setTopDisplayAddressRow(int topDisplayAddressRow) {
		this.topDisplayAddressRow = topDisplayAddressRow;
	}
	public String getAddressDisplayState() {
		return addressDisplayState;
	}
	public void setAddressDisplayState(String addressDisplayState) {
		this.addressDisplayState = addressDisplayState;
	}
	
	// Letter tab
	public EmCorrMbrVO getDisplayLetter() {
		return displayLetter;
	}
	public void setDisplayLetter(EmCorrMbrVO displayLetter) {
		this.displayLetter = displayLetter;
	}
	public boolean isLetterChanged() {
		return letterChanged;
	}
	public void setLetterChanged(boolean letterChanged) {
		this.letterChanged = letterChanged;
	}
	public List getListLetters() {
		return listLetters;
	}
	public void setListLettersWithDisplay(List listLetters) {
		this.listLetters = listLetters;
		if ((this.listLetters != null) && (this.listLetters.isEmpty() == false)) {
			this.displayLetter = (EmCorrMbrVO) this.listLetters.get(selectedLetterRow);
		}
		else {
			this.displayLetter = new EmCorrMbrVO();
		}
	}
	public void setListLetters(List listLetters) {
		this.listLetters = listLetters;
	}
	public int getSelectedLetterRow() {
		return selectedLetterRow;
	}
	public void setSelectedLetterRow(int selectedLetterRow) {
		this.selectedLetterRow = selectedLetterRow;
	}
	public int getTopDisplayLetterRow() {
		return topDisplayLetterRow;
	}
	public void setTopDisplayLetterRow(int topDisplayLetterRow) {
		this.topDisplayLetterRow = topDisplayLetterRow;
	}
	public String getLetterDisplayState() {
		return letterDisplayState;
	}
	public void setLetterDisplayState(String letterDisplayState) {
		this.letterDisplayState = letterDisplayState;
	}
	public List getDisplayLetterVarData() {
		return displayLetterVarData;
	}
	public void setDisplayLetterVarData(List displayLetterVarData) {
		this.displayLetterVarData = displayLetterVarData;
	}
	
	// Comment tab
	public boolean isCommentChanged() {
		return commentChanged;
	}
	public void setCommentChanged(boolean commentChanged) {
		this.commentChanged = commentChanged;
	}
	public EmMbrCommentVO getDisplayComment() {
		return displayComment;
	}
	public void setDisplayComment(EmMbrCommentVO displayComment) {
		this.displayComment = displayComment;
	}
	public List getListComments() {
		return listComments;
	}
	public void setListCommentsWithDisplay(List listComments) {
		this.listComments = listComments;
		if ((this.listComments != null) && (this.listComments.isEmpty() == false)) {
			this.displayComment = (EmMbrCommentVO) this.listComments.get(selectedCommentRow);
		}
		else {
			this.displayComment = new EmMbrCommentVO();
		}
	}
	public void setListComments(List listComments) {
		this.listComments = listComments;
	}
	public int getSelectedCommentRow() {
		return selectedCommentRow;
	}
	public void setSelectedCommentRow(int selectedCommentRow) {
		this.selectedCommentRow = selectedCommentRow;
	}
	public int getTopDisplayCommentRow() {
		return topDisplayCommentRow;
	}
	public void setTopDisplayCommentRow(int topDisplayCommentRow) {
		this.topDisplayCommentRow = topDisplayCommentRow;
	}
	public String getCommentDisplayState() {
		return commentDisplayState;
	}
	public void setCommentDisplayState(String commentDisplayState) {
		this.commentDisplayState = commentDisplayState;
	}
	
	// errors tab
	public List getListErrors() {
		return listErrors;
	}
	public void setListErrorsWithDisplay(List listErrors) {
		this.listErrors = listErrors;
		if ((this.listErrors != null) && (this.listErrors.isEmpty() == false)) {
			this.displayError = (EmMbrErrorVO) this.listErrors.get(selectedErrorRow);
		}
		else {
			this.displayError = new EmMbrErrorVO();
		}
	}
	public void setListErrors(List listErrors) {
		this.listErrors = listErrors;
	}
	public int getSelectedErrorRow() {
		return selectedErrorRow;
	}
	public void setSelectedErrorRow(int selectedErrorRow) {
		this.selectedErrorRow = selectedErrorRow;
	}
	public int getTopDisplayErrorRow() {
		return topDisplayErrorRow;
	}
	public void setTopDisplayErrorRow(int topDisplayErrorRow) {
		this.topDisplayErrorRow = topDisplayErrorRow;
	}
	public EmMbrErrorVO getDisplayError() {
		return displayError;
	}
	public void setDisplayError(EmMbrErrorVO displayError) {
		this.displayError = displayError;
	}
	public boolean isErrorChanged() {
		return errorChanged;
	}
	public void setErrorChanged(boolean errorChanged) {
		this.errorChanged = errorChanged;
	}
	public String getErrorDisplayState() {
		return errorDisplayState;
	}
	public void setErrorDisplayState(String errorDisplayState) {
		this.errorDisplayState = errorDisplayState;
	}
	
	
	// trr tab
	public List getListTrrLogs() {
		return listTrrLogs;
	}
	public void setListTrrLogsWithDisplay(List listTrrLogs) {
		this.listTrrLogs = listTrrLogs;
		if ((this.listTrrLogs != null) && (this.listTrrLogs.isEmpty() == false)) {
			this.displayTrrLog = (EmMbrTrrLogVO) this.listTrrLogs.get(selectedTrrLogRow);
		}
		else {
			this.displayTrrLog = new EmMbrTrrLogVO();
		}
	}
	public void setListTrrLogs(List listTrrLogs) {
		this.listTrrLogs = listTrrLogs;
	}
	public int getSelectedTrrLogRow() {
		return selectedTrrLogRow;
	}
	public void setSelectedTrrLogRow(int selectedTrrLogRow) {
		this.selectedTrrLogRow = selectedTrrLogRow;
	}
	public int getTopDisplayTrrLogRow() {
		return topDisplayTrrLogRow;
	}
	public void setTopDisplayTrrLogRow(int topDisplayTrrLogRow) {
		this.topDisplayTrrLogRow = topDisplayTrrLogRow;
	}
	public EmMbrTrrLogVO getDisplayTrrLog() {
		return displayTrrLog;
	}
	public void setDisplayTrrLog(EmMbrTrrLogVO displayTrrLog) {
		this.displayTrrLog = displayTrrLog;
	}
	public boolean isTrrLogChanged() {
		return trrLogChanged;
	}
	public void setTrrLogChanged(boolean trrLogChanged) {
		this.trrLogChanged = trrLogChanged;
	}
	public String getTrrLogDisplayState() {
		return trrLogDisplayState;
	}
	public void setTrrLogDisplayState(String trrLogDisplayState) {
		this.trrLogDisplayState = trrLogDisplayState;
	}
	
	
	// Pcp tab
	public boolean isPcpInfoChanged() {
		return pcpInfoChanged;
	}
	public void setPcpInfoChanged(boolean pcpInfoChanged) {
		this.pcpInfoChanged = pcpInfoChanged;
	}
	public EMMbrPCPInfoVO getDisplayPcpInfo() {
		return displayPcpInfo;
	}
	public void setDisplayPcpInfo(EMMbrPCPInfoVO displayPcpInfo) {
		this.displayPcpInfo = displayPcpInfo;
	}
	public List getListPcpInfos() {
		return listPcpInfos;
	}
	public void setListPcpInfosWithDisplay(List listPcpInfos) {
		this.listPcpInfos = listPcpInfos;
		if ((this.listPcpInfos != null) && (this.listPcpInfos.isEmpty() == false)) {
			this.displayPcpInfo = (EMMbrPCPInfoVO) this.listPcpInfos.get(selectedPcpInfoRow);
		}
		else {
			this.displayPcpInfo = new EMMbrPCPInfoVO();
		}
	}
	public void setListPcpInfos(List listPcpInfos) {
		this.listPcpInfos = listPcpInfos;
	}
	public int getSelectedPcpInfoRow() {
		return selectedPcpInfoRow;
	}
	public void setSelectedPcpInfoRow(int selectedPcpInfoRow) {
		this.selectedPcpInfoRow = selectedPcpInfoRow;
	}
	public int getTopDisplayPcpInfoRow() {
		return topDisplayPcpInfoRow;
	}
	public void setTopDisplayPcpInfoRow(int topDisplayPcpInfoRow) {
		this.topDisplayPcpInfoRow = topDisplayPcpInfoRow;
	}
	public String getPcpInfoDisplayState() {
		return pcpInfoDisplayState;
	}
	public void setPcpInfoDisplayState(String pcpInfoDisplayState) {
		this.pcpInfoDisplayState = pcpInfoDisplayState;
	}
	
	// Validation lists
	public List getValidMemberStatus() {
		return validMemberStatus;
	}
	public void setValidMemberStatus(List validMemberStatus) {
		this.validMemberStatus = validMemberStatus;
	}	
	public List getValidAddressTypes() {
		return validAddressTypes;
	}
	public void setValidAddressTypes(List validAddressTypes) {
		this.validAddressTypes = validAddressTypes;
	}
	public List getValidAgentTypes() {
		return validAgentTypes;
	}
	public void setValidAgentTypes(List validAgentTypes) {
		this.validAgentTypes = validAgentTypes;
	}
	public List getValidDisenrollmentReasons() {
		return validDisenrollmentReasons;
	}
	public void setValidDisenrollmentReasons(List validDisenrollmentReasons) {
		this.validDisenrollmentReasons = validDisenrollmentReasons;
	}
	public List getValidElectionTypes() {
		return validElectionTypes;
	}
	public void setValidElectionTypes(List validElectionTypes) {
		this.validElectionTypes = validElectionTypes;
	}
	public List getValidEnrollStatusReasons() {
		return validEnrollStatusReasons;
	}
	public void setValidEnrollStatusReasons(List validEnrollStatusReasons) {
		this.validEnrollStatusReasons = validEnrollStatusReasons;
	}
	public List getValidEnrollReasons() {
		return validEnrollReasons;
	}
	public void setValidEnrollReasons(List validEnrollReasons) {
		this.validEnrollReasons = validEnrollReasons;
	}
	public List getValidEnrollSources() {
		return validEnrollSources;
	}
	public void setValidEnrollSources(List validEnrollSources) {
		this.validEnrollSources = validEnrollSources;
	}
	public List getValidEnrollStatuses() {
		return validEnrollStatuses;
	}
	public void setValidEnrollStatuses(List validEnrollStatuses) {
		this.validEnrollStatuses = validEnrollStatuses;
	}
	public List getValidGenderCodes() {
		return validGenderCodes;
	}
	public void setValidGenderCodes(List validGenderCodes) {
		this.validGenderCodes = validGenderCodes;
	}
	public List getValidLanguages() {
		return validLanguages;
	}
	public void setValidLanguages(List validLanguages) {
		this.validLanguages = validLanguages;
	}
	public List getValidMaritalStatuses() {
		return validMaritalStatuses;
	}
	public void setValidMaritalStatuses(List validMaritalStatuses) {
		this.validMaritalStatuses = validMaritalStatuses;
	}
	public List getValidPrefixes() {
		return validPrefixes;
	}
	public void setValidPrefixes(List validPrefixes) {
		this.validPrefixes = validPrefixes;
	}
	public List getValidRaceCodes() {
		return validRaceCodes;
	}
	public void setValidRaceCodes(List validRaceCodes) {
		this.validRaceCodes = validRaceCodes;
	}
	public List getValidRelations() {
		return validRelations;
	}
	public void setValidRelations(List validRelations) {
		this.validRelations = validRelations;
	}
	public List getValidSepExceptions() {
		return validSepExceptions;
	}
	public void setValidSepExceptions(List validSepExceptions) {
		this.validSepExceptions = validSepExceptions;
	}
	public List getValidStates() {
		return validStates;
	}
	public void setValidStates(List validStates) {
		this.validStates = validStates;
	}
	public ListBoxItem[] getArrYesNo() {
		return arrYesNo;
	}
	public void setArrYesNo(ListBoxItem[] arrYesNo) {
		this.arrYesNo = arrYesNo;
	}
	public List getValidDsCodes() {
		return validDsCodes;
	}
	public void setValidDsCodes(List validDsCodes) {
		this.validDsCodes = validDsCodes;
	}
	public List getValidLiCopays() {
		return validLiCopays;
	}
	public void setValidLiCopays(List validLiCopays) {
		this.validLiCopays = validLiCopays;
	}
	public List getValidLiPercents() {
		return validLiPercents;
	}
	public void setValidLiPercents(List validLiPercents) {
		this.validLiPercents = validLiPercents;
	}
	public List getValidCountry() {
		return validCountry;
	}
	public void setValidCountry(List validCountry) {
		this.validCountry = validCountry;
	}
	public List getValidSEPReasons() {
		return validSEPReasons;
	}
	public void setValidSEPReasons(List validSEPReasons) {
		this.validSEPReasons = validSEPReasons;
	}
	public List getValidSubsidySrce() {
		return validSubsidySrce;
	}
	public void setValidSubsidySrce(List validSubsidySrce) {
		this.validSubsidySrce = validSubsidySrce;
	}
	public EmMbrAgentVO getDisplayAgent() {
		return displayAgent;
	}
	public void setDisplayAgent(EmMbrAgentVO displayAgent) {
		this.displayAgent = displayAgent;
	}
	public List getListAgents() {
		return listAgents;
	}
	public void setListAgents(List listAgents) {
		this.listAgents = listAgents;
	}
	public void setListAgentsWithDisplay(List listAgents) {
		this.listAgents = listAgents;
		if ((this.listAgents != null) && (this.listAgents.isEmpty() == false)) {
			this.displayAgent = (EmMbrAgentVO) this.listAgents.get(selectedAgentRow);
		}
		else {
			this.displayAgent = new EmMbrAgentVO();
		}
	}
	public int getSelectedAgentRow() {
		return selectedAgentRow;
	}
	public void setSelectedAgentRow(int selectedAgentRow) {
		this.selectedAgentRow = selectedAgentRow;
	}
	public int getTopDisplayAgentRow() {
		return topDisplayAgentRow;
	}
	public void setTopDisplayAgentRow(int topDisplayAgentRow) {
		this.topDisplayAgentRow = topDisplayAgentRow;
	}
	public boolean isAgentChanged() {
		return agentChanged;
	}
	public void setAgentChanged(boolean agentChanged) {
		this.agentChanged = agentChanged;
	}
	public String getAgentDisplayState() {
		return agentDisplayState;
	}
	public void setAgentDisplayState(String agentDisplayState) {
		this.agentDisplayState = agentDisplayState;
	}
	public boolean isCobChanged() {
		return cobChanged;
	}
	public void setCobChanged(boolean cobChanged) {
		this.cobChanged = cobChanged;
	}
	public String getCobDisplayState() {
		return cobDisplayState;
	}
	public void setCobDisplayState(String cobDisplayState) {
		this.cobDisplayState = cobDisplayState;
	}
	public EmMbrCobVO getDisplayCob() {
		return displayCob;
	}
	public void setDisplayCob(EmMbrCobVO displayCob) {
		this.displayCob = displayCob;
	}
	public List getListCobs() {
		return listCobs;
	}
	public void setListCobs(List listCobs) {
		this.listCobs = listCobs;
	}
	public void setListCobsWithDisplay(List listCobs) {
		this.listCobs = listCobs;
		if ((this.listCobs != null) && (this.listCobs.isEmpty() == false)) {
			this.displayCob = (EmMbrCobVO) this.listCobs.get(selectedCobRow);
		}
		else {
			this.displayCob = new EmMbrCobVO();
		}
	}
	public int getSelectedCobRow() {
		return selectedCobRow;
	}
	public void setSelectedCobRow(int selectedCobRow) {
		this.selectedCobRow = selectedCobRow;
	}
	public int getTopDisplayCobRow() {
		return topDisplayCobRow;
	}
	public void setTopDisplayCobRow(int topDisplayCobRow) {
		this.topDisplayCobRow = topDisplayCobRow;
	}
	public List getValidCobTypes() {
		return validCobTypes;
	}
	public void setValidCobTypes(List validCobTypes) {
		this.validCobTypes = validCobTypes;
	}
	public List getValidOhiInd() {
		return validOhiInd;
	}
	public void setValidOhiInd(List validOhiInd) {
		this.validOhiInd = validOhiInd;
	}
	public boolean isBillingChanged() {
		return billingChanged;
	}
	public void setBillingChanged(boolean billingChanged) {
		this.billingChanged = billingChanged;
	}
	public String getBillingDisplayState() {
		return billingDisplayState;
	}
	public void setBillingDisplayState(String billingDisplayState) {
		this.billingDisplayState = billingDisplayState;
	}
	public EmMbrBillingVO getDisplayBilling() {
		return displayBilling;
	}
	public void setDisplayBilling(EmMbrBillingVO displayBilling) {
		this.displayBilling = displayBilling;
	}
	public List getListBilling() {
		return listBilling;
	}
	public void setListBilling(List listBilling) {
		this.listBilling = listBilling;
	}
	public void setListBillingWithDisplay(List listBilling) {
		this.listBilling = listBilling;
		if ((this.listBilling != null) && (this.listBilling.isEmpty() == false)) {
			this.displayBilling = (EmMbrBillingVO) this.listBilling.get(selectedCobRow);
		}
		else {
			this.displayBilling = new EmMbrBillingVO();
		}
	}
	public int getSelectedBillingRow() {
		return selectedBillingRow;
	}
	public void setSelectedBillingRow(int selectedBillingRow) {
		this.selectedBillingRow = selectedBillingRow;
	}
	public int getTopDisplayBillingRow() {
		return topDisplayBillingRow;
	}
	public void setTopDisplayBillingRow(int topDisplayBillingRow) {
		this.topDisplayBillingRow = topDisplayBillingRow;
	}
	public List getValidAccountType() {
		return validAccountType;
	}
	public void setValidAccountType(List validAccountType) {
		this.validAccountType = validAccountType;
	}
	public List getValidBillPayMethod() {
		return validBillPayMethod;
	}
	public void setValidBillPayMethod(List validBillPayMethod) {
		this.validBillPayMethod = validBillPayMethod;
	}
	public List getLstAgencies() {
		return lstAgencies;
	}
	public void setLstAgencies(List lstAgencies) {
		this.lstAgencies = lstAgencies;
	}
	public List getLstAgencyTypes() {
		return lstAgencyTypes;
	}
	public void setLstAgencyTypes(List lstAgencyTypes) {
		this.lstAgencyTypes = lstAgencyTypes;
	}
	public List getLstAgents() {
		return lstAgents;
	}
	public void setLstAgents(List lstAgents) {
		this.lstAgents = lstAgents;
	}
	public List getLstAgentTypes() {
		return lstAgentTypes;
	}
	public void setLstAgentTypes(List lstAgentTypes) {
		this.lstAgentTypes = lstAgentTypes;
	}
	public List getLstPlans() {
		return lstPlans;
	}
	public void setLstPlans(List lstPlans) {
		this.lstPlans = lstPlans;
	}
	public List getListOoaInfos() {
		return listOoaInfos;
	}
	public void setListOoaInfos(List listOoaInfos) {
		this.listOoaInfos = listOoaInfos;
	}
	public List getOoaReasonList() {
		return ooaReasonList;
	}
	public void setOoaReasonList(List ooaReasonList) {
		this.ooaReasonList = ooaReasonList;
	}
	public List getOoaSourceList() {
		return ooaSourceList;
	}
	public void setOoaSourceList(List ooaSourceList) {
		this.ooaSourceList = ooaSourceList;
	}
	public List getOoaDeReasonList() {
		return ooaDeReasonList;
	}
	public void setOoaDeReasonList(List ooaDeReasonList) {
		this.ooaDeReasonList = ooaDeReasonList;
	}
	public int getSelectedOoaInfoRow() {
		return selectedOoaInfoRow;
	}
	public void setSelectedOoaInfoRow(int selectedOoaInfoRow) {
		this.selectedOoaInfoRow = selectedOoaInfoRow;
	}
	public int getTopDisplayOoaInfoRow() {
		return topDisplayOoaInfoRow;
	}
	public void setTopDisplayOoaInfoRow(int topDisplayOoaInfoRow) {
		this.topDisplayOoaInfoRow = topDisplayOoaInfoRow;
	}
	public EmMbrOoaInfoVO getDisplayOoaInfo() {
		return displayOoaInfo;
	}
	public void setDisplayOoaInfo(EmMbrOoaInfoVO displayOoaInfo) {
		this.displayOoaInfo = displayOoaInfo;
	}
	public boolean isOoaChanged() {
		return OoaChanged;
	}
	public void setOoaChanged(boolean ooaChanged) {
		OoaChanged = ooaChanged;
	}
	public String getOoaInfoDisplayState() {
		return ooaInfoDisplayState;
	}
	public void setOoaInfoDisplayState(String ooaInfoDisplayState) {
		this.ooaInfoDisplayState = ooaInfoDisplayState;
	}
	public String getPlanDesignation() {
		return planDesignation;
	}
	public void setPlanDesignation(String planDesignation) {
		this.planDesignation = planDesignation;
	}
	public String getEnrollStatus() {
		return enrollStatus;
	}
	public void setEnrollStatus(String enrollStatus) {
		this.enrollStatus = enrollStatus;
	}
	public String getEnrollReason() {
		return enrollReason;
	}
	public void setEnrollReason(String enrollReason) {
		this.enrollReason = enrollReason;
	}
	/**
	 * @return the listAccretion
	 */
	public List getListAccretion() {
		return listAccretion;
	}
	/**
	 * @param listAccretion the listAccretion to set
	 */
	public void setListAccretion(List listAccretion) {
		this.listAccretion = listAccretion;
	}
	/**
	 * @return the selectedAccretionRow
	 */
	public int getSelectedAccretionRow() {
		return selectedAccretionRow;
	}
	/**
	 * @param selectedAccretionRow the selectedAccretionRow to set
	 */
	public void setSelectedAccretionRow(int selectedAccretionRow) {
		this.selectedAccretionRow = selectedAccretionRow;
	}
	/**
	 * @return the topDisplayAccretionRow
	 */
	public int getTopDisplayAccretionRow() {
		return topDisplayAccretionRow;
	}
	/**
	 * @param topDisplayAccretionRow the topDisplayAccretionRow to set
	 */
	public void setTopDisplayAccretionRow(int topDisplayAccretionRow) {
		this.topDisplayAccretionRow = topDisplayAccretionRow;
	}
	/**
	 * @return the displayAccretion
	 */
	public EmMbrAccretionVO getDisplayAccretion() {
		return displayAccretion;
	}
	/**
	 * @param displayAccretion the displayAccretion to set
	 */
	public void setDisplayAccretion(EmMbrAccretionVO displayAccretion) {
		this.displayAccretion = displayAccretion;
	}
	/**
	 * @return the accretionDisplayState
	 */
	public String getAccretionDisplayState() {
		return accretionDisplayState;
	}
	/**
	 * @param accretionDisplayState the accretionDisplayState to set
	 */
	public void setAccretionDisplayState(String accretionDisplayState) {
		this.accretionDisplayState = accretionDisplayState;
	}
	public void setListOoaWithDisplay(List listOoaInfos) {
		this.listOoaInfos = listOoaInfos;
		if ((this.listOoaInfos!= null) && (this.listOoaInfos.isEmpty() == false)) {
			this.displayOoaInfo = (EmMbrOoaInfoVO) this.listOoaInfos.get(selectedOoaInfoRow);
		}
		else {
			this.displayOoaInfo = new EmMbrOoaInfoVO();
		}
	}
	
	/**
	 * 
	 * @param listAccretion
	 */
	public void setListAccretionWithDisplay(List listAccretion) {
		this.listAccretion = listAccretion;
		if ((this.listAccretion!= null) && (this.listAccretion.isEmpty() == false)) {
			this.displayAccretion = (EmMbrAccretionVO) this.listAccretion.get(selectedAccretionRow);
		}
		
	}
	/**
     * 020_Highmark_SUC_UI_v1.03 (Accretion)  - End
     */
	/**
	 * @return the effDate
	 */
	public String getEffDate() {
		return effDate;
	}
	/**
	 * @param effDate the effDate to set
	 */
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	/**
	 * @return the oevDateCheck
	 */
	public boolean isOevDateCheck() {
		return oevDateCheck;
	}
	/**
	 * @param oevDateCheck the oevDateCheck to set
	 */
	public void setOevDateCheck(boolean oevDateCheck) {
		this.oevDateCheck = oevDateCheck;
	}
	/**
	 * @return the oevDateNext
	 */
	public boolean isOevDateNext() {
		return oevDateNext;
	}
	/**
	 * @param oevDateNext the oevDateNext to set
	 */
	public void setOevDateNext(boolean oevDateNext) {
		this.oevDateNext = oevDateNext;
	}
	/**
	 * @return the oevInfoChanged
	 */
	public boolean isOevInfoChanged() {
		return oevInfoChanged;
	}
	/**
	 * @param oevInfoChanged the oevInfoChanged to set
	 */
	public void setOevInfoChanged(boolean oevInfoChanged) {
		this.oevInfoChanged = oevInfoChanged;
	}
	/**
	 * @return the oevReturnInfoChanged
	 */
	public boolean isOevReturnInfoChanged() {
		return oevReturnInfoChanged;
	}
	/**
	 * @param oevReturnInfoChanged the oevReturnInfoChanged to set
	 */
	public void setOevReturnInfoChanged(boolean oevReturnInfoChanged) {
		this.oevReturnInfoChanged = oevReturnInfoChanged;
	}
	/**
	 * @return the oevInfo
	 */
	public EmMbrOevInfoVO getOevInfo() {
		return oevInfo;
	}
	/**
	 * @param oevInfo the oevInfo to set
	 */
	public void setOevInfo(EmMbrOevInfoVO oevInfo) {
		this.oevInfo = oevInfo;
	}
	/**
	 * @return the oevRetInfo
	 */
	public EmMbrOevInfoVO getOevRetInfo() {
		return oevRetInfo;
	}
	/**
	 * @param oevRetInfo the oevRetInfo to set
	 */
	public void setOevRetInfo(EmMbrOevInfoVO oevRetInfo) {
		this.oevRetInfo = oevRetInfo;
	}
	/**
	 * @return the oevCheck
	 */
	public boolean isOevCheck() {
		return oevCheck;
	}
	/**
	 * @param oevCheck the oevCheck to set
	 */
	public void setOevCheck(boolean oevCheck) {
		this.oevCheck = oevCheck;
	}
	/**
	 * @return the oevTimerCheck
	 */
	public String getOevTimerCheck() {
		return oevTimerCheck;
	}
	/**
	 * @param oevTimerCheck the oevTimerCheck to set
	 */
	public void setOevTimerCheck(String oevTimerCheck) {
		this.oevTimerCheck = oevTimerCheck;
	}
	/**
	 * @return the oev2TimerCheck
	 */
	public boolean isOev2TimerCheck() {
		return oev2TimerCheck;
	}
	/**
	 * @param oev2TimerCheck the oev2TimerCheck to set
	 */
	public void setOev2TimerCheck(boolean oev2TimerCheck) {
		this.oev2TimerCheck = oev2TimerCheck;
	}
	/**
	 * @return the oevButton
	 */
	public String getOevButton() {
		return oevButton;
	}
	/**
	 * @param oevButton the oevButton to set
	 */
	public void setOevButton(String oevButton) {
		this.oevButton = oevButton;
	}
	/**
	 * @return the applDate
	 */
	public String getApplDate() {
		return applDate;
	}
	/**
	 * @param applDate the applDate to set
	 */
	public void setApplDate(String applDate) {
		this.applDate = applDate;
	}
	/**
	 * @return the oevCallStatusDrop
	 */
	public List getOevCallStatusDrop() {
		return oevCallStatusDrop;
	}
	/**
	 * @param oevCallStatusDrop the oevCallStatusDrop to set
	 */
	public void setOevCallStatusDrop(List oevCallStatusDrop) {
		this.oevCallStatusDrop = oevCallStatusDrop;
	}
	/**
	 * @return the oevCallSubReasonDrop
	 */
	public List getOevCallSubReasonDrop() {
		return oevCallSubReasonDrop;
	}
	/**
	 * @param oevCallSubReasonDrop the oevCallSubReasonDrop to set
	 */
	public void setOevCallSubReasonDrop(List oevCallSubReasonDrop) {
		this.oevCallSubReasonDrop = oevCallSubReasonDrop;
	}
	/**
	 * @return the oevCallAttempts
	 */
	public List getOevCallAttempts() {
		return oevCallAttempts;
	}
	/**
	 * @param oevCallAttempts the oevCallAttempts to set
	 */
	public void setOevCallAttempts(List oevCallAttempts) {
		this.oevCallAttempts = oevCallAttempts;
	}
	/**
	 * @return the oevCallStatus
	 */
	public List getOevCallStatus() {
		return oevCallStatus;
	}
	/**
	 * @param oevCallStatus the oevCallStatus to set
	 */
	public void setOevCallStatus(List oevCallStatus) {
		this.oevCallStatus = oevCallStatus;
	}
	/**
	 * @return the oevCallStatusSaved
	 */
	public List getOevCallStatusSaved() {
		return oevCallStatusSaved;
	}
	/**
	 * @param oevCallStatusSaved the oevCallStatusSaved to set
	 */
	public void setOevCallStatusSaved(List oevCallStatusSaved) {
		this.oevCallStatusSaved = oevCallStatusSaved;
	}
	/**
	 * @return the oevRetStatus
	 */
	public List getOevRetStatus() {
		return oevRetStatus;
	}
	/**
	 * @param oevRetStatus the oevRetStatus to set
	 */
	public void setOevRetStatus(List oevRetStatus) {
		this.oevRetStatus = oevRetStatus;
	}
	/**
	 * @return the oevRetStatusSaved
	 */
	public List getOevRetStatusSaved() {
		return oevRetStatusSaved;
	}
	/**
	 * @param oevRetStatusSaved the oevRetStatusSaved to set
	 */
	public void setOevRetStatusSaved(List oevRetStatusSaved) {
		this.oevRetStatusSaved = oevRetStatusSaved;
	}
	/**
	 * @return the returnCalls
	 */
	public List getReturnCalls() {
		return returnCalls;
	}
	/**
	 * @param returnCalls the returnCalls to set
	 */
	public void setReturnCalls(List returnCalls) {
		this.returnCalls = returnCalls;
	}
	/**
	 * @return the oevUpdtdate
	 */
	public String getOevUpdtdate() {
		return oevUpdtdate;
	}
	/**
	 * @param oevUpdtdate the oevUpdtdate to set
	 */
	public void setOevUpdtdate(String oevUpdtdate) {
		this.oevUpdtdate = oevUpdtdate;
	}
	/**
	 * @return the premium
	 */
	public String getPremium() {
		return premium;
	}
	/**
	 * @param premium the premium to set
	 */
	public void setPremium(String premium) {
		this.premium = premium;
	}
	/**
	 * @return the primCoPay
	 */
	public String getPrimCoPay() {
		return primCoPay;
	}
	/**
	 * @param primCoPay the primCoPay to set
	 */
	public void setPrimCoPay(String primCoPay) {
		this.primCoPay = primCoPay;
	}
	/**
	 * @return the spclCoPay
	 */
	public String getSpclCoPay() {
		return spclCoPay;
	}
	/**
	 * @param spclCoPay the spclCoPay to set
	 */
	public void setSpclCoPay(String spclCoPay) {
		this.spclCoPay = spclCoPay;
	}
	/**
	 * @return the tier1
	 */
	public String getTier1() {
		return tier1;
	}
	/**
	 * @param tier1 the tier1 to set
	 */
	public void setTier1(String tier1) {
		this.tier1 = tier1;
	}
	/**
	 * @return the brandTier
	 */
	public String getBrandTier() {
		return brandTier;
	}
	/**
	 * @param brandTier the brandTier to set
	 */
	public void setBrandTier(String brandTier) {
		this.brandTier = brandTier;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the operId
	 */
	public String getOperId() {
		return operId;
	}
	/**
	 * @param operId the operId to set
	 */
	public void setOperId(String operId) {
		this.operId = operId;
	}
	/**
	 * @return the genderCd
	 */
	public String getGenderCd() {
		return genderCd;
	}
	/**
	 * @param genderCd the genderCd to set
	 */
	public void setGenderCd(String genderCd) {
		this.genderCd = genderCd;
	}
	/**
	 * @return the planId
	 */
	public String getPlanId() {
		return planId;
	}
	/**
	 * @param planId the planId to set
	 */
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	/**
	 * @return the selectedRowInMemberLetters
	 */
	public String getSelectedRowInMemberLetters() {
		return selectedRowInMemberLetters;
	}
	/**
	 * @param selectedRowInMemberLetters the selectedRowInMemberLetters to set
	 */
	public void setSelectedRowInMemberLetters(String selectedRowInMemberLetters) {
		this.selectedRowInMemberLetters = selectedRowInMemberLetters;
	}
	/**
	 * @return the fedralConrtStmt
	 */
	public String getFedralConrtStmt() {
		return fedralConrtStmt;
	}
	/**
	 * @param fedralConrtStmt the fedralConrtStmt to set
	 */
	public void setFedralConrtStmt(String fedralConrtStmt) {
		this.fedralConrtStmt = fedralConrtStmt;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the approvalCode
	 */
	public String getApprovalCode() {
		return approvalCode;
	}
	/**
	 * @param approvalCode the approvalCode to set
	 */
	public void setApprovalCode(String approvalCode) {
		this.approvalCode = approvalCode;
	}
	/**
	 * @return the oevplanName
	 */
	public String getOevplanName() {
		return oevplanName;
	}
	/**
	 * @param oevplanName the oevplanName to set
	 */
	public void setOevplanName(String oevplanName) {
		this.oevplanName = oevplanName;
	}
	 
    public List getEnrollCancelReasons() {
		return enrollCancelReasons;
	}
	public void setEnrollCancelReasons(List lstEnrollCancelReasons) {		
		this.enrollCancelReasons = lstEnrollCancelReasons;
	}
	/**
	 * @return the currEnrlStatus
	 */
	public String getCurrEnrlStatus() {
		return currEnrlStatus;
	}
	/**
	 * @param currEnrlStatus the currEnrlStatus to set
	 */
	public void setCurrEnrlStatus(String currEnrlStatus) {
		this.currEnrlStatus = currEnrlStatus;
	}
	/**
	 * @return the currEnrlResCd
	 */
	public String getCurrEnrlResCd() {
		return currEnrlResCd;
	}
	/**
	 * @param currEnrlResCd the currEnrlResCd to set
	 */
	public void setCurrEnrlResCd(String currEnrlResCd) {
		this.currEnrlResCd = currEnrlResCd;
	}

	/**
	 * Cambia_OevProcess-Start
	 */
	/**
	 * @param oevCallStatusSaved
	 */
	public void setDisplaySavedOev(List oevCallStatusSaved) {
		this.oevCallStatusSaved = oevCallStatusSaved;
		if ((this.oevCallStatusSaved != null) && (this.oevCallStatusSaved.isEmpty() == false)) {
			this.oevInfo = (EmMbrOevInfoVO) this.oevCallStatusSaved.get(oevCallStatusSaved.size()-1);
		}
		else {
			this.oevInfo = new EmMbrOevInfoVO();
		}
	}
	/**
	 * @param oevRetStatusSaved
	 */
	public void setDisplaySavedRetOev(List oevRetStatusSaved) {
		this.oevRetStatusSaved = oevRetStatusSaved;
		if ((this.oevRetStatusSaved != null) && (this.oevRetStatusSaved.isEmpty() == false)) {
			this.oevRetInfo = (EmMbrOevInfoVO) this.oevRetStatusSaved.get(oevRetStatusSaved.size()-1);
		}
		else {
			this.oevRetInfo = new EmMbrOevInfoVO();
		}
	}
	/**
	 * Cambia_OevProcess-End
	 */
	public String getSearchAgencyId() {
		return searchAgencyId;
	}
	public void setSearchAgencyId(String searchAgencyId) {
		this.searchAgencyId = searchAgencyId;
	}
	public String getSearchAgencyName() {
		return searchAgencyName;
	}
	public void setSearchAgencyName(String searchAgencyName) {
		this.searchAgencyName = searchAgencyName;
	}
	public List getLstSearchAgencies() {
		return lstSearchAgencies;
	}
	public void setLstSearchAgencies(List lstSearchAgencies) {
		this.lstSearchAgencies = lstSearchAgencies;
	}
	public String getWfScreenMsg() {
		return wfScreenMsg;
	}
	public void setWfScreenMsg(String wfScreenMsg) {
		this.wfScreenMsg = wfScreenMsg;
	}
	/**
	 * UseCaseName 024_Cambia_SUC_UI_LEP - Start 1
	 */
	// LepAttestation tab
	private String statusCd;
	private String incStatusCd;
	private String incompAttestLetRecDate;
	private String brkInCoverage;
	private String credRXCoverage;
	private String fromDate;
	private String toDate;
	private List lepAttestationInfo;
	private EmMbrLepAttestInfoVO displayLepAttestInfo = new EmMbrLepAttestInfoVO();
	public String dmsID;
	private int selectedLepAttestInfoRow;
	private boolean attestMemberInfoChanged;	

	private String selectedLepMemberSubTab;
	//Iteration2 UAT-start
		private String obc1TimerCheck;
		private String obc2TimerCheck;
		private String le21TimerCheck;
		private String obc3TimerCheck;
		//Iteration 2 UAT end
	private boolean lepNunCmoInfoChanged;
	private boolean lepSummaryInfoChanged;
	private boolean lepAttestInfoChanged;
	
	/**
	 * UseCaseName 024_Cambia_SUC_UI_LEP - End 1
	 */
	
	//LEP TAB
		/**
		 * UseCaseName 024_Cambia_SUC_UI_LEP - Start 2
		 */
		private String credibleRXCoverage;
		private String typeLep;	
		private List validStatus;

		
		//- LEP - NUNCMO73 TR	
		private String[] outInitAttestAttempt;
		private String[] outInitAttestDate;
		private String[] outInitAttestStatus;
		private String[] outInitAttestUserID;
		private String[] outInitAttestChange;
		private String[] outInitAttestCreateTime;
		
		private String[] inInitAttestAttempt;
		private String[] inInitAttestDate;
		private String[] inInitAttestStatus;
		private String[] inInitAttestUserID;
		private String[] inInitAttestChange;
		private String[] inInitAttestCreateTime;
		
		private String[] outIncAttestAttempt;
		private String[] outIncAttestDate;
		private String[] outIncAttestStatus;
		private String[] outIncAttestUserID;
		private String[] outIncAttestChange;
		private String[] outIncAttestCreateTime;
		
		private String[] inIncAttestAttempt;
		private String[] inIncAttestDate;
		private String[] inIncAttestStatus;
		private String[] inIncAttestUserID;
		private String[] inIncAttestChange;
		private String[] inIncAttestCreateTime;
		
		private String[] inLateAttestAttempt;
		private String[] inLateoInitAttestDate;
		private String[] inLateAttestStatus;
		private String[] inLateAttestUserID;
		private String[] inLateAttestChange;
		private String[] inLateAttestCreateTime;
		
		List inInitAttests;
		List outIncAttests;
		List inIncAttests;
		List inLateAttests;
		
		List lepNunCmoStstus;
		//- END - LEP - NUNCMO73 TR	
		/**
		 * UseCaseName 024_Cambia_SUC_UI_LEP - End 2
		 */
		
		/**
		 * UseCaseName 024_Cambia_SUC_UI_LEP - Start 3
		 */
		
		private String checkLep;
		private String credCovInfo;
		private String lepAdjInfo;
		private String rowCount;
		private String credcovTimer;
		
		private List maxReconTypes;
		private String comptRespRecDate;
		private String attestationRecDate;
		private String attestationRecChannel;
		private String notifiedMemberAppeal;
		private List recvdChannel;
		private List memberAppeal;
		private List brkInCoverageType;
		
	/**
	 * UseCaseName 024_Cambia_SUC_UI_LEP - End 3
	 */
		
		/**
		 * UseCaseName 024_Cambia_SUC_UI_LEP - Start 4
		 */
		public String getSelectedLepMemberSubTab() {
			return selectedLepMemberSubTab;
		}
		public void setSelectedLepMemberSubTab(String selectedLepMemberSubTab) {
			this.selectedLepMemberSubTab = selectedLepMemberSubTab;
		}
		
		public boolean isLepNunCmoInfoChanged() {
			return lepNunCmoInfoChanged;
		}
		public void setLepNunCmoInfoChanged(boolean lepNunCmoInfoChanged) {
			this.lepNunCmoInfoChanged = lepNunCmoInfoChanged;
		}
		public boolean isLepSummaryInfoChanged() {
			return lepSummaryInfoChanged;
		}
		public void setLepSummaryInfoChanged(boolean lepSummaryInfoChanged) {
			this.lepSummaryInfoChanged = lepSummaryInfoChanged;
		}
		public boolean isLepAttestInfoChanged() {
			return lepAttestInfoChanged;
		}
		public void setLepAttestInfoChanged(boolean lepAttestInfoChanged) {
			this.lepAttestInfoChanged = lepAttestInfoChanged;
		}
		
		public List getLepAttestationInfo() {
			return lepAttestationInfo;
		}
		public void setListLepAttestInfosWithDisplay(List lepAttestationInfo) {
			this.lepAttestationInfo = lepAttestationInfo;
			if ((this.lepAttestationInfo != null) && (this.lepAttestationInfo.isEmpty() == false)) {
				this.displayLepAttestInfo = (EmMbrLepAttestInfoVO) this.lepAttestationInfo.get(selectedLepAttestInfoRow);
			}
			else {
				this.displayLepAttestInfo = new EmMbrLepAttestInfoVO();
			}
		}
		public void setLepAttestationInfo(List lepAttestationInfo) {
			this.lepAttestationInfo = lepAttestationInfo;
		}

		public String getStatusCd() {
			return statusCd;
		}
		public void setStatusCd(String statusCd) {
			this.statusCd = statusCd;
		}

		public List getValidStatus() {
			return validStatus;
		}
		public void setValidStatus(List validStatus) {
			this.validStatus = validStatus;
		}
		/**
		 * @return the lepAttestInfoChanged
		 */
			
		/**
		 * @return the selectedLepAttestInfoRow
		 */
		public int getSelectedLepAttestInfoRow() {
			return selectedLepAttestInfoRow;
		}
		/**
		 * @param selectedLepAttestInfoRow the selectedLepAttestInfoRow to set
		 */
		public void setSelectedLepAttestInfoRow(int selectedLepAttestInfoRow) {
			this.selectedLepAttestInfoRow = selectedLepAttestInfoRow;
		}
		/**
		 * @return the displayLepAttestInfo
		 */
		public EmMbrLepAttestInfoVO getDisplayLepAttestInfo() {
			return displayLepAttestInfo;
		}
		/**
		 * @param displayLepAttestInfo the displayLepAttestInfo to set
		 */
		public void setDisplayLepAttestInfo(EmMbrLepAttestInfoVO displayLepAttestInfo) {
			this.displayLepAttestInfo = displayLepAttestInfo;
		}
		/**
		 * @return the incStatusCd
		 */
		public String getIncStatusCd() {
			return incStatusCd;
		}
		/**
		 * @param incStatusCd the incStatusCd to set
		 */
		public void setIncStatusCd(String incStatusCd) {
			this.incStatusCd = incStatusCd;
		}
		/**
		 * @return the incompAttestLetRecDate
		 */
		public String getIncompAttestLetRecDate() {
			return incompAttestLetRecDate;
		}
		/**
		 * @param incompAttestLetRecDate the incompAttestLetRecDate to set
		 */
		public void setIncompAttestLetRecDate(String incompAttestLetRecDate) {
			this.incompAttestLetRecDate = incompAttestLetRecDate;
		}
		/**
		 * @return the brkInCoverage
		 */
		public String getBrkInCoverage() {
			return brkInCoverage;
		}
		/**
		 * @param brkInCoverage the brkInCoverage to set
		 */
		public void setBrkInCoverage(String brkInCoverage) {
			this.brkInCoverage = brkInCoverage;
		}
		/**
		 * @return the credRXCoverage
		 */
		public String getCredRXCoverage() {
			return credRXCoverage;
		}
		/**
		 * @param credRXCoverage the credRXCoverage to set
		 */
		public void setCredRXCoverage(String credRXCoverage) {
			this.credRXCoverage = credRXCoverage;
		}
		/**
		 * @return the fromDate
		 */
		public String getFromDate() {
			return fromDate;
		}
		/**
		 * @param fromDate the fromDate to set
		 */
		public void setFromDate(String fromDate) {
			this.fromDate = fromDate;
		}
		/**
		 * @return the toDate
		 */
		public String getToDate() {
			return toDate;
		}
		/**
		 * @param toDate the toDate to set
		 */
		public void setToDate(String toDate) {
			this.toDate = toDate;
		}
		
		/**
		 * @return the attestMemberInfoChanged
		 */
		public boolean isAttestMemberInfoChanged() {
			return attestMemberInfoChanged;
		}
		/**
		 * @param attestMemberInfoChanged the attestMemberInfoChanged to set
		 */
		public void setAttestMemberInfoChanged(boolean attestMemberInfoChanged) {
			this.attestMemberInfoChanged = attestMemberInfoChanged;
		}
		/**
		 * @return the dmsID
		 */
		public String getDmsID() {
			return dmsID;
		}
		/**
		 * @param dmsID the dmsID to set
		 */
		public void setDmsID(String dmsID) {
			this.dmsID = dmsID;
		}

		
		/**
		 * UseCaseName 024_Cambia_SUC_UI_LEP - End 4
		 */
		
		/**
		 * UseCaseName 024_Cambia_SUC_UI_LEP - Start 5
		 */
		
		public String getCredCovInfo() {
			return credCovInfo;
		}
		public void setCredCovInfo(String credCovInfo) {
			this.credCovInfo = credCovInfo;
		}
		public String getLepAdjInfo() {
			return lepAdjInfo;
		}
		public void setLepAdjInfo(String lepAdjInfo) {
			this.lepAdjInfo = lepAdjInfo;
		}
		public String getCheckLep() {
			return checkLep;
		}
		public void setCheckLep(String checkLep) {
			this.checkLep = checkLep;
		}
		public String getRowCount() {
			return rowCount;
		}
		public void setRowCount(String rowCount) {
			this.rowCount = rowCount;
		}
		/**
		 * @return the credcovTimer
		 */
		public String getCredcovTimer() {
			return credcovTimer;
		}
		/**
		 * @param credcovTimer the credcovTimer to set
		 */
		public void setCredcovTimer(String credcovTimer) {
			this.credcovTimer = credcovTimer;
		}
		
		/**
		 * UseCaseName 024_Cambia_SUC_UI_LEP - End 5
		 */
		
		/**
		 * UseCaseName 024_Cambia_SUC_UI_LEP - Start 6
		 */
		List outInitAttests;
		public List getOutInitAttests() {
			return outInitAttests;
		}
		public void setOutInitAttests(List outInitAttests) {
			this.outInitAttests = outInitAttests;
		}
		
		public List getInInitAttests() {
			return inInitAttests;
		}
		public void setInInitAttests(List inInitAttests) {
			this.inInitAttests = inInitAttests;
		}
		public List getOutIncAttests() {
			return outIncAttests;
		}
		public void setOutIncAttests(List outIncAttests) {
			this.outIncAttests = outIncAttests;
		}
		public List getInIncAttests() {
			return inIncAttests;
		}
		public void setInIncAttests(List inIncAttests) {
			this.inIncAttests = inIncAttests;
		}
		public List getInLateAttests() {
			return inLateAttests;
		}
		public void setInLateAttests(List inLateAttests) {
			this.inLateAttests = inLateAttests;
		}
		//lep type added by harika	
			private List validLEPType;
			public List getValidLEPType() {
				return validLEPType;
			}
			public void setValidLEPType(List validLEPType) {
				this.validLEPType = validLEPType;
			}
			
			public List getLepNunCmoStstus() {
				return lepNunCmoStstus;
			}
			public void setLepNunCmoStstus(List lepNunCmoStstus) {
				this.lepNunCmoStstus = lepNunCmoStstus;
			}
			public String getObc1TimerCheck() {
				return obc1TimerCheck;
			}
			public void setObc1TimerCheck(String obc1TimerCheck) {
				this.obc1TimerCheck = obc1TimerCheck;
			}
			public String getObc2TimerCheck() {
				return obc2TimerCheck;
			}
			public void setObc2TimerCheck(String obc2TimerCheck) {
				this.obc2TimerCheck = obc2TimerCheck;
			}
			public String getLe21TimerCheck() {
				return le21TimerCheck;
			}
			public void setLe21TimerCheck(String le21TimerCheck) {
				this.le21TimerCheck = le21TimerCheck;
			}
			public String getObc3TimerCheck() {
				return obc3TimerCheck;
			}
			public void setObc3TimerCheck(String obc3TimerCheck) {
				this.obc3TimerCheck = obc3TimerCheck;
			}
			public String getCredibleRXCoverage() {
				return credibleRXCoverage;
			}
			public void setCredibleRXCoverage(String credibleRXCoverage) {
				this.credibleRXCoverage = credibleRXCoverage;
			}
			public String getTypeLep() {
				return typeLep;
			}
			public void setTypeLep(String typeLep) {
				this.typeLep = typeLep;
			}
			public String[] getOutInitAttestAttempt() {
				return outInitAttestAttempt;
			}
			public void setOutInitAttestAttempt(String[] outInitAttestAttempt) {
				this.outInitAttestAttempt = outInitAttestAttempt;
			}
			public String[] getOutInitAttestDate() {
				return outInitAttestDate;
			}
			public void setOutInitAttestDate(String[] outInitAttestDate) {
				this.outInitAttestDate = outInitAttestDate;
			}
			public String[] getOutInitAttestStatus() {
				return outInitAttestStatus;
			}
			public void setOutInitAttestStatus(String[] outInitAttestStatus) {
				this.outInitAttestStatus = outInitAttestStatus;
			}
			public String[] getOutInitAttestUserID() {
				return outInitAttestUserID;
			}
			public void setOutInitAttestUserID(String[] outInitAttestUserID) {
				this.outInitAttestUserID = outInitAttestUserID;
			}
			public String[] getOutInitAttestChange() {
				return outInitAttestChange;
			}
			public void setOutInitAttestChange(String[] outInitAttestChange) {
				this.outInitAttestChange = outInitAttestChange;
			}
			public String[] getOutInitAttestCreateTime() {
				return outInitAttestCreateTime;
			}
			public void setOutInitAttestCreateTime(String[] outInitAttestCreateTime) {
				this.outInitAttestCreateTime = outInitAttestCreateTime;
			}
			public String[] getInInitAttestAttempt() {
				return inInitAttestAttempt;
			}
			public void setInInitAttestAttempt(String[] inInitAttestAttempt) {
				this.inInitAttestAttempt = inInitAttestAttempt;
			}
			public String[] getInInitAttestDate() {
				return inInitAttestDate;
			}
			public void setInInitAttestDate(String[] inInitAttestDate) {
				this.inInitAttestDate = inInitAttestDate;
			}
			public String[] getInInitAttestStatus() {
				return inInitAttestStatus;
			}
			public void setInInitAttestStatus(String[] inInitAttestStatus) {
				this.inInitAttestStatus = inInitAttestStatus;
			}
			public String[] getInInitAttestUserID() {
				return inInitAttestUserID;
			}
			public void setInInitAttestUserID(String[] inInitAttestUserID) {
				this.inInitAttestUserID = inInitAttestUserID;
			}
			public String[] getInInitAttestChange() {
				return inInitAttestChange;
			}
			public void setInInitAttestChange(String[] inInitAttestChange) {
				this.inInitAttestChange = inInitAttestChange;
			}
			public String[] getInInitAttestCreateTime() {
				return inInitAttestCreateTime;
			}
			public void setInInitAttestCreateTime(String[] inInitAttestCreateTime) {
				this.inInitAttestCreateTime = inInitAttestCreateTime;
			}
			public String[] getOutIncAttestAttempt() {
				return outIncAttestAttempt;
			}
			public void setOutIncAttestAttempt(String[] outIncAttestAttempt) {
				this.outIncAttestAttempt = outIncAttestAttempt;
			}
			public String[] getOutIncAttestDate() {
				return outIncAttestDate;
			}
			public void setOutIncAttestDate(String[] outIncAttestDate) {
				this.outIncAttestDate = outIncAttestDate;
			}
			public String[] getOutIncAttestStatus() {
				return outIncAttestStatus;
			}
			public void setOutIncAttestStatus(String[] outIncAttestStatus) {
				this.outIncAttestStatus = outIncAttestStatus;
			}
			public String[] getOutIncAttestUserID() {
				return outIncAttestUserID;
			}
			public void setOutIncAttestUserID(String[] outIncAttestUserID) {
				this.outIncAttestUserID = outIncAttestUserID;
			}
			public String[] getOutIncAttestChange() {
				return outIncAttestChange;
			}
			public void setOutIncAttestChange(String[] outIncAttestChange) {
				this.outIncAttestChange = outIncAttestChange;
			}
			public String[] getOutIncAttestCreateTime() {
				return outIncAttestCreateTime;
			}
			public void setOutIncAttestCreateTime(String[] outIncAttestCreateTime) {
				this.outIncAttestCreateTime = outIncAttestCreateTime;
			}
			public String[] getInIncAttestAttempt() {
				return inIncAttestAttempt;
			}
			public void setInIncAttestAttempt(String[] inIncAttestAttempt) {
				this.inIncAttestAttempt = inIncAttestAttempt;
			}
			public String[] getInIncAttestDate() {
				return inIncAttestDate;
			}
			public void setInIncAttestDate(String[] inIncAttestDate) {
				this.inIncAttestDate = inIncAttestDate;
			}
			public String[] getInIncAttestStatus() {
				return inIncAttestStatus;
			}
			public void setInIncAttestStatus(String[] inIncAttestStatus) {
				this.inIncAttestStatus = inIncAttestStatus;
			}
			public String[] getInIncAttestUserID() {
				return inIncAttestUserID;
			}
			public void setInIncAttestUserID(String[] inIncAttestUserID) {
				this.inIncAttestUserID = inIncAttestUserID;
			}
			public String[] getInIncAttestChange() {
				return inIncAttestChange;
			}
			public void setInIncAttestChange(String[] inIncAttestChange) {
				this.inIncAttestChange = inIncAttestChange;
			}
			public String[] getInIncAttestCreateTime() {
				return inIncAttestCreateTime;
			}
			public void setInIncAttestCreateTime(String[] inIncAttestCreateTime) {
				this.inIncAttestCreateTime = inIncAttestCreateTime;
			}
			public String[] getInLateAttestAttempt() {
				return inLateAttestAttempt;
			}
			public void setInLateAttestAttempt(String[] inLateAttestAttempt) {
				this.inLateAttestAttempt = inLateAttestAttempt;
			}
			public String[] getInLateoInitAttestDate() {
				return inLateoInitAttestDate;
			}
			public void setInLateoInitAttestDate(String[] inLateoInitAttestDate) {
				this.inLateoInitAttestDate = inLateoInitAttestDate;
			}
			public String[] getInLateAttestStatus() {
				return inLateAttestStatus;
			}
			public void setInLateAttestStatus(String[] inLateAttestStatus) {
				this.inLateAttestStatus = inLateAttestStatus;
			}
			public String[] getInLateAttestUserID() {
				return inLateAttestUserID;
			}
			public void setInLateAttestUserID(String[] inLateAttestUserID) {
				this.inLateAttestUserID = inLateAttestUserID;
			}
			public String[] getInLateAttestChange() {
				return inLateAttestChange;
			}
			public void setInLateAttestChange(String[] inLateAttestChange) {
				this.inLateAttestChange = inLateAttestChange;
			}
			public String[] getInLateAttestCreateTime() {
				return inLateAttestCreateTime;
			}
			public void setInLateAttestCreateTime(String[] inLateAttestCreateTime) {
				this.inLateAttestCreateTime = inLateAttestCreateTime;
			}
			public List getMaxReconTypes() {
				return maxReconTypes;
			}
			public void setMaxReconTypes(List maxReconTypes) {
				this.maxReconTypes = maxReconTypes;
			}
			public String getComptRespRecDate() {
				return comptRespRecDate;
			}
			public void setComptRespRecDate(String comptRespRecDate) {
				this.comptRespRecDate = comptRespRecDate;
			}
			public String getAttestationRecDate() {
				return attestationRecDate;
			}
			public void setAttestationRecDate(String attestationRecDate) {
				this.attestationRecDate = attestationRecDate;
			}
			public String getAttestationRecChannel() {
				return attestationRecChannel;
			}
			public void setAttestationRecChannel(String attestationRecChannel) {
				this.attestationRecChannel = attestationRecChannel;
			}
			public String getNotifiedMemberAppeal() {
				return notifiedMemberAppeal;
			}
			public void setNotifiedMemberAppeal(String notifiedMemberAppeal) {
				this.notifiedMemberAppeal = notifiedMemberAppeal;
			}
			public List getRecvdChannel() {
				return recvdChannel;
			}
			public void setRecvdChannel(List recvdChannel) {
				this.recvdChannel = recvdChannel;
			}
			public List getMemberAppeal() {
				return memberAppeal;
			}
			public void setMemberAppeal(List memberAppeal) {
				this.memberAppeal = memberAppeal;
			}
			public List getBrkInCoverageType() {
				return brkInCoverageType;
			}
			public void setBrkInCoverageType(List brkInCoverageType) {
				this.brkInCoverageType = brkInCoverageType;
			}
			/**
			 * UseCaseName 024_Cambia_SUC_UI_LEP - End 6
			 */
		public List getValidBillFrequency() {
			return validBillFrequency;
		}
		public void setValidBillFrequency(List validBillFrequency) {
			this.validBillFrequency = validBillFrequency;
		}
		/**
		 * @return the agencySrchPageNbr
		 */
		public int getAgencySrchPageNbr() {
			return agencySrchPageNbr;
		}
		/**
		 * @param agencySrchPageNbr the agencySrchPageNbr to set
		 */
		public void setAgencySrchPageNbr(int agencySrchPageNbr) {
			this.agencySrchPageNbr = agencySrchPageNbr;
		}
		/**
		 * @return the agencySrchPageType
		 */
		public String getAgencySrchPageType() {
			return agencySrchPageType;
		}
		/**
		 * @param agencySrchPageType the agencySrchPageType to set
		 */
		public void setAgencySrchPageType(String agencySrchPageType) {
			this.agencySrchPageType = agencySrchPageType;
		}
		/**
		 * @return the agencySrchMove
		 */
		public String getAgencySrchMove() {
			return agencySrchMove;
		}
		/**
		 * @param agencySrchMove the agencySrchMove to set
		 */
		public void setAgencySrchMove(String agencySrchMove) {
			this.agencySrchMove = agencySrchMove;
		}
	
}
