/*
 * $Id: RapsForm.java,v 1.1 2014/06/26 07:55:48 praveen Exp $
 */
package com.ps.mss.web.forms;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 * @author indrapradja.adriana
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class RapsForm extends ActionForm {
	private String planId;
	private String hicNbr;
	
//SSNRI CHANGES
	private String mbi;
	private String custSentMbiInd;
//SSNRI CHANGES	
	private String claimId;
	private String status;
	private String errorStatus;
    private String fromLastUpdate;
    private String toLastUpdate;
    private List lstErrorStatus;
	
    private String pageType = "";
    private String pageName;

	private String planName ;
	private String diagCd;
	private String fromDate;
	private String toDate;
	private String searchType;
	private Object[] resultArray; //holds the array for dashboard kind of informations.
	private String method; //the new function that the customer click. e.g. PaymentSummary, DiscrepancySummary
	private String menuName; //e.g. "pde", "plan", "raps"
	private String uiContext;
	private boolean detailPage;
	private Object pageInfo; //holds page info, e.g. the whole thing on RAPS Details pages.
	private String patientControlNo;
	private String comments;
	private String providerType;
	private String actDel;
	private String hcc;
	private String sortBy = "date";
	
	/**
	 * @return Returns the detailPage.
	 */
	public boolean isDetailPage() {
		return detailPage;
	}
	/**
	 * @param detailPage The detailPage to set.
	 */
	public void setDetailPage(boolean detailPage) {
		this.detailPage = detailPage;
	}
 
 
    /**
     * @return Returns the actionType.
    public String getActionType() {
        return actionType;
    }
     */
    /**
     * @param actionType The actionType to set.
    public void setActionType(String actionType) {
        this.actionType = actionType;
    }
       */
    /**
     * @return Returns the fromDate.
     */
    public String getFromDate() {
        return fromDate;
    }
    /**
     * @param fromDate The fromDate to set.
     */
    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }
    /**
     * @return Returns the hicNbr.
     */
    public String getHicNbr() {
    	if(hicNbr != null )
    		return hicNbr.toUpperCase() ;
    	
        return hicNbr;
    }
    /**
     * @param hicNbr The hicNbr to set.
     */
    public void setHicNbr(String hicNbr) {
        this.hicNbr = hicNbr;
    }
    
    
    public String getMbi() {
    	if(mbi != null )
    		return mbi.toUpperCase() ;
		return mbi;
	}
	public void setMbi(String mbi) {
		this.mbi = mbi;
	}
	
	public String getCustSentMbiInd() {
		return custSentMbiInd;
	}
	public void setCustSentMbiInd(String custSentMbiInd) {
		this.custSentMbiInd = custSentMbiInd;
	}
	
//MBI Implementation for Search MBI/HIC
	// securedHicNbr
		public String getSecuredHicNbr() {
			if ("M".equalsIgnoreCase(custSentMbiInd)) {
				return mbi;
			} else {
				return hicNbr;
			}
		}
		
		public String getCustmFlag() {
			return custSentMbiInd;
		}

		public void setCustmFlag(String CustSentMbiInd) {
			this.custSentMbiInd = CustSentMbiInd;
		}
	
	/**
     * @return Returns the planName.
     */
    public String getPlanName() {
        return planName;
    }
    /**
     * @param planName The planName to set.
     */
    public void setPlanName(String planName) {
        this.planName = planName;
    }
    /**
     * @return Returns the searchType.
     */
    public String getSearchType() {
        return searchType;
    }
    /**
     * @param searchType The searchType to set.
     */
    public void setSearchType(String searchType) {
        this.searchType = searchType;
    }
    /**
     * @return Returns the toDate.
     */
    public String getToDate() {
        return toDate;
    }
    /**
     * @param toDate The toDate to set.
     */
    public void setToDate(String toDate) {
        this.toDate = toDate;
    }
       	
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		planName = null;
		fromDate = null;
		toDate = null;
		searchType = null;
		resultArray = null;
		pageType = "";
	}
	
	/**
	 * @return Returns the pageType.
	 */
	public String getPageType() {
		return pageType;
	}
	/**
	 * @param pageType The pageType to set.
	 */
	public void setPageType(String pageType) {
		this.pageType = pageType;
	}
	
	
	/**
	 * @return Returns the menuName.
	 */
	public String getMenuName() {
		return menuName;
	}
	/**
	 * @param menuName The menuName to set.
	 */
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	/**
	 * @return Returns the method.
	 */
	public String getMethod() {
		return method;
	}
	/**
	 * @param method The method to set.
	 */
	public void setMethod(String method) {
		this.method = method;
	}
	/**
	 * @return Returns the uiContext.
	 */
	public String getUiContext() {
		return uiContext;
	}
	/**
	 * @param uiContext The uiContext to set.
	 */
	public void setUiContext(String uiContext) {
		this.uiContext = uiContext;
	}
	/**
	 * @return Returns the pageName.
	 */
	public String getPageName() {
		return pageName;
	}
	/**
	 * @param pageName The pageName to set.
	 */
	public void setPageName(String pageName) {
		this.pageName = pageName;
	}
	/**
	 * @return Returns the claimId.
	 */
	public String getClaimId() {
		return claimId;
	}
	/**
	 * @param claimId The claimId to set.
	 */
	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}
	/**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return Returns the resultArray.
	 */
	public Object[] getResultArray() {
		return resultArray;
	}
	/**
	 * @param resultArray The resultArray to set.
	 */
	public void setResultArray(Object[] resultArray) {
		this.resultArray = resultArray;
	}
	/**
	 * @return Returns the pageInfo.
	 */
	public Object getPageInfo() {
		return pageInfo;
	}
	/**
	 * @param pageInfo The pageInfo to set.
	 */
	public void setPageInfo(Object pageInfo) {
		this.pageInfo = pageInfo;
	}
	/**
	 * @return Returns the fromLastUpdate.
	 */
	public String getFromLastUpdate() {
		return fromLastUpdate;
	}
	/**
	 * @param fromLastUpdate The fromLastUpdate to set.
	 */
	public void setFromLastUpdate(String fromLastUpdate) {
		this.fromLastUpdate = fromLastUpdate;
	}
	/**
	 * @return Returns the planId.
	 */
	public String getPlanId() {
		return planId;
	}
	/**
	 * @param planId The planId to set.
	 */
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	/**
	 * @return Returns the toLastUpdate.
	 */
	public String getToLastUpdate() {
		return toLastUpdate;
	}
	/**
	 * @param toLastUpdate The toLastUpdate to set.
	 */
	public void setToLastUpdate(String toLastUpdate) {
		this.toLastUpdate = toLastUpdate;
	}
	/**
	 * @return Returns the comments.
	 */
	public String getComments() {
		return comments;
	}
	/**
	 * @param comments The comments to set.
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
	/**
	 * @return Returns the patientControlNo.
	 */
	public String getPatientControlNo() {
		return patientControlNo;
	}
	/**
	 * @param patientControlNo The patientControlNo to set.
	 */
	public void setPatientControlNo(String patientControlNo) {
		this.patientControlNo = patientControlNo;
	}
	/**
	 * @return Returns the providerType.
	 */
	public String getProviderType() {
		return providerType;
	}
	/**
	 * @param providerType The providerType to set.
	 */
	public void setProviderType(String providerType) {
		this.providerType = providerType;
	}
	/**
	 * @return Returns the actDel.
	 */
	public String getActDel() {
		return actDel;
	}
	/**
	 * @param actDel The actDel to set.
	 */
	public void setActDel(String actDel) {
		this.actDel = actDel;
	}
	/**
	 * @return Returns the diagCd.
	 */
	public String getDiagCd() {
		return diagCd;
	}
	/**
	 * @param diagCd The diagCd to set.
	 */
	public void setDiagCd(String diagCd) {
		this.diagCd = diagCd;
	}
	/**
	 * @return Returns the hcc.
	 */
	public String getHcc() {
		return hcc;
	}
	/**
	 * @param hcc The hcc to set.
	 */
	public void setHcc(String hcc) {
		this.hcc = hcc;
	}
	/**
	 * @return Returns the sortBy.
	 */
	public String getSortBy() {
		return sortBy;
	}
	/**
	 * @param sortBy The sortBy to set.
	 */
	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}
	/**
	 * @return Returns the errorStatus.
	 */
	public String getErrorStatus() {
		return errorStatus;
	}
	/**
	 * @param errorStatus The errorStatus to set.
	 */
	public void setErrorStatus(String errorStatus) {
		this.errorStatus = errorStatus;
	}
	/**
	 * @return Returns the lstErrorStatus.
	 */
	public List getLstErrorStatus() {
		return lstErrorStatus;
	}
	/**
	 * @param lstErrorStatus The lstErrorStatus to set.
	 */
	public void setLstErrorStatus(List lstErrorStatus) {
		this.lstErrorStatus = lstErrorStatus;
	}
}
