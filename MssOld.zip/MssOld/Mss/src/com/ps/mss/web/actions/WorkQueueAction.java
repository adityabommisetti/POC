/*
 * $Id: DiscrepancyDetailAction.java,v 1.1 2014/06/26 07:56:39 praveen Exp $
*/
package com.ps.mss.web.actions;

import java.awt.Menu;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.CodeCacheService;
import com.ps.mss.framework.Constants;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.manager.DiscrepancyManager;
import com.ps.mss.manager.MasterManager;
import com.ps.mss.manager.WorkQueueManager;
import com.ps.mss.model.DiscrepancyDetailVO;
import com.ps.mss.model.DiscrepancyDetailVOList;
import com.ps.mss.model.DiscrepancyListVO;
import com.ps.mss.model.FilterVO;
import com.ps.mss.web.forms.DiscrepancyDetailForm;
import com.ps.mss.web.forms.WorkQueueForm;
import com.ps.mss.web.helper.DispatchActionHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.util.NameValuePair;
import com.ps.util.StringUtil;

/**
 * This action is execute by client(UI) for discrepancy detail.
 * @version 	1.0
 * @author
 */
public class WorkQueueAction extends Action {
	private static Logger logger=LoggerFactory.getLogger(WorkQueueAction.class);
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		String target = "error";
		String method = request.getParameter("method");
		SessionHelper sessionHelper = new SessionHelper(request);
		
		WorkQueueForm discrpDetailForm = (WorkQueueForm) form;
		if(method !=null){
			discrpDetailForm.setMenuName(Constants.WORK_QUEUE_MENU);
		}
		discrpDetailForm.init(request);
		discrpDetailForm.setUpdateMessage("");
		List uiContext = null;
		FilterVO filterVO = null;
		Map discrpMap = null ;
		String actiontype = null;
		
		actiontype = discrpDetailForm.getActionType();
		String move = null;
	
		try{
			
		if(Constants.WORK_QUEUE_MENU.equals(discrpDetailForm.getMenuName()))
				discrpMap = (Map)sessionHelper.getAttribute(Constants.SESSION_WORK_QUEUE_MAP);
		
			//Setting Search parameters in session
			CodeCacheService codeCache=new CodeCacheService();
			Integer maxExportCount=codeCache.getDiscMaxRecordCount();
			int selectedRowNo = 0;
			if(discrpMap != null) {
				Integer temp = ((Integer)discrpMap.get(Constants.PAGE_SELECTED_LINE));
				if(temp != null)
					selectedRowNo = temp.intValue() ; 
			}
			Map detailmap = null;
		
	 if(Constants.WORK_QUEUE_MENU.equals(discrpDetailForm.getMenuName())||discrpDetailForm.getMenuName().startsWith(Constants.WORK_QUEUE_MENU)){
				
				discrpDetailForm.setMenuName(Constants.WORK_QUEUE_MENU);
				filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_WORK_QUEUE_FILTERVO);

				List usrList = WorkQueueManager.getUsersList(sessionHelper.getMfId(),sessionHelper.getActiveDataBaseName(),sessionHelper.getPlanForParts());
				discrpDetailForm.setAssignedByList(usrList);
				discrpDetailForm.setAssignedToList(usrList);
				//Getting list from session
				List totalList = (List) sessionHelper.getAttribute("totalWorkQueuLst");
				if((actiontype== null || (!actiontype.equals("search") && !actiontype.equals("updateAssign"))) && totalList==null){
					discrpDetailForm.setWqassignedTo(sessionHelper.getUserId());
					discrpDetailForm.setDiscrepancyType("NotClosed");
				}
				if(StringUtil.nonNullTrim(discrpDetailForm.getPartName()).equals(""))
					discrpDetailForm.setPartName("Both");
				if((actiontype!= null  && actiontype.equals("workqueue") && totalList!=null)){
					 setForm(discrpDetailForm, filterVO);
				}
				filterVO = setFilterVO(discrpDetailForm,filterVO);
				sessionHelper.setAttribute(Constants.SESSION_WORK_QUEUE_FILTERVO, filterVO);
				target = "workqueue";
				discrpDetailForm.setSubWorkMenu("");
				DispatchActionHelper.setTabAndFormName(request, Constants.WORK_QUEUE_MENU, "WorkQueueForm");
				
			}
			 
			//Recon Demo-WorkQueue
			else { // when request is for discrepancy detail.
				filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_WORK_QUEUE_FILTERVO);
				sessionHelper.setAttribute(Constants.SESSION_WORK_QUEUE_FILTERVO, filterVO);
				uiContext = (List)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_STATUS);
				target = "success";
				DispatchActionHelper.setTabAndFormName(request, Constants.DISCREPANCY_MENU, "DiscrepancyDetailForm");
			}
				
		String uiContextRange = StringUtil.nonNullTrim(request.getParameter("uiContextRange"));
		//Integer maxRecordCount = MasterManager.getMaxRecordCount();
		Integer maxRecordCount = 25;// increased for workqueue
		if(actiontype.equals("search"))
			move = "first";
		else
			move = "current";
		request.setAttribute("uiContextRange",uiContextRange);
		if(Constants.CONSTANTS_ALL.equals(uiContextRange)){ 
			move = "first";
			if(discrpMap!= null){
					detailmap =  discrpMap != null ?(Map)discrpMap.get(Constants.PARTC_DISCRP_DETAIL_MAP) : null ;
					request.setAttribute("showDiscrepancyListC",Constants.PARTC);
			
				}
				if(detailmap != null){
					detailmap.put(Constants.SESSION_MAX_RECORD_COUNT,maxRecordCount);
					detailmap.put(Constants.UI_CONTEXT_RANGE,Constants.CONSTANTS_ALL);
				}
			}	
		
		if(filterVO != null ) { //This condition is true when use click first time on discrepancy detail tab
			Map planMap = sessionHelper.getPlanForParts();
			filterVO.setSearchType(sessionHelper.evaluteSearchType(filterVO));
			
			if(Constants.BOTH_PARTS.equals(filterVO.getPartName()))
				filterVO.setPartName(sessionHelper.getServicesToAccess());
			
			boolean hasWriteOffService = sessionHelper.hasWriteOffPermission();
			//Getting list from session
			List totalList = (List) sessionHelper.getAttribute("totalWorkQueuLst");
			boolean hasBothDiscPermission = sessionHelper.hasBothDiscAccessPermission();
			if(actiontype.equals("updateAssign")){
				move = "currentPage";
				int count=WorkQueueManager.updateAssignTask(totalList,planMap, filterVO,  sessionHelper.getActiveDataBaseName(),
						discrpDetailForm.getSelectedIndexes(),discrpMap, discrpDetailForm.getReassignedTo(),sessionHelper.getUserId(),
						discrpDetailForm.getReassignComment(),hasBothDiscPermission);
			    if(count > 0){
			    	discrpDetailForm.setUpdateMessage(" Discrepancy Assigned Successfully" );
			    	discrpDetailForm.setReassignedTo("");
			    	discrpDetailForm.setReassignComment("");
			    }
			    else
			    	discrpDetailForm.setUpdateMessage(filterVO.getUpdateMessage());
			
			}
			
			DiscrepancyDetailVOList discrepancyDetailVOList =WorkQueueManager.getDiscrepancyList(maxExportCount,totalList,filterVO,discrpMap,move, 
					sessionHelper.getActiveDataBaseName(),planMap,filterVO.getSearchType(),discrpDetailForm.getMenuName(), 
					hasWriteOffService);
            // Add updated complete list to session
			int totalRecords = 0;
			int noOfPages = 0;
			
			if(discrepancyDetailVOList != null && discrepancyDetailVOList.getPartCDiscrpDetailVO().getDiscrepancyListVO().length > 0){
				 List listData = Arrays.asList(discrepancyDetailVOList.getPartCDiscrpDetailVO().getDiscrepancyListVO()); 
				sessionHelper.setAttribute("totalWorkQueuLst",listData);
				totalRecords = WorkQueueManager.getDiscrepancyListCount(totalList, filterVO, discrpMap, move, 
						 sessionHelper.getActiveDataBaseName(),planMap,filterVO.getSearchType(),discrpDetailForm.getMenuName(), 
							hasWriteOffService);
				 noOfPages = (int) Math.ceil(totalRecords * 1.0 / 25);
	            if(noOfPages == 0) {
	           	 noOfPages = 1;
	            }
	            if(noOfPages == discrepancyDetailVOList.getPartCDiscrpDetailVO().getPageNumber()){
	            	discrepancyDetailVOList.getPartCDiscrpDetailVO().setCurrentPage("last");
	            }
	            sessionHelper.setAttribute("WRKQTotalRec",totalRecords);
	            sessionHelper.setAttribute("WRKQTotalPages",noOfPages);
			}
			else{
				sessionHelper.setAttribute("WRKQTotalRec",0);
	            sessionHelper.setAttribute("WRKQTotalPages",0);
			}
				
		
            discrpDetailForm.setWRKQTotalRec(totalRecords);
            discrpDetailForm.setWRKQTotalPages(noOfPages);
			if(detailmap != null){
				detailmap.put(Constants.SESSION_MAX_RECORD_COUNT,new Integer(25));
				detailmap.remove(Constants.UI_CONTEXT_RANGE);
			}
			
			if(discrepancyDetailVOList != null){
				discrpDetailForm.setDiscrepancyDetailVOList(discrepancyDetailVOList);
				DiscrepancyDetailVO partC =discrepancyDetailVOList.getPartCDiscrpDetailVO();
				DiscrepancyListVO[] partCObjArr = partC!=null?partC.getDiscrepancyListVO():null;
				if(partCObjArr != null){
					int selectedRow = discrepancyDetailVOList.getSelectedLine();
					String  selCommnt = partCObjArr[selectedRow].getComment();
					discrpDetailForm.setDefaultComment(selCommnt);
				}
				
				if( Constants.EXPORT_NO_DATA_FOUND.equals("TRUE") && Constants.CONSTANTS_ALL.equals(StringUtil.nonNullTrim(request.getParameter("uiContextRange")))){
					DiscrepancyDetailVO discListPartC =discrepancyDetailVOList.getPartCDiscrpDetailVO();
					DiscrepancyListVO[] discListPartCObjArr = discListPartC!=null?discListPartC.getDiscrepancyListVO():null;
					/*if(discListPartCObjArr == null && discListPartDObjArr == null){
						if(Constants.PARTC.equals(discInd)|| Constants.BOTH_PARTS.equals(discInd))
							request.setAttribute("showDiscrepancyListC",Constants.PARTC);
						if(Constants.PARTD.equals(discInd)|| Constants.BOTH_PARTS.equals(discInd))
							request.setAttribute("showDiscrepancyListD",Constants.PARTD);
					}*/
				}
				
					setDetailMap(discrpMap,discrepancyDetailVOList, sessionHelper, discrpDetailForm.getMenuName(), filterVO.getPartName(),discrpDetailForm.getPageType());
			
			}
		}	
		
			//this call for set ui context into form
			setUiContext(uiContext,discrpDetailForm);
			setForm(discrpDetailForm , filterVO);	//this set discrepancy detail form using filtervo		
			setpartName(discrpDetailForm);
			logger.info(LoggerConstants.methodEndLevel());
			
	}
	catch(Exception e){
		e.printStackTrace();
	}
		return mapping.findForward(target);
	}
	
	/**
	 * @param discrpDetailForm
	 */
	private void setpartName(WorkQueueForm discrpDetailForm) {
		logger.info(LoggerConstants.methodStartLevel());
		NameValuePair[] planIdArr = discrpDetailForm.getPlanNameList();
		if( StringUtil.trimToNull(discrpDetailForm.getHicNbr()) == null && StringUtil.trimToNull(discrpDetailForm.getFromDate()) == null && StringUtil.trimToNull(discrpDetailForm.getToDate()) == null)
				discrpDetailForm.setCriteriaAvailable("false");
		if(planIdArr != null && planIdArr.length == 1) {
			discrpDetailForm.setPlanName(planIdArr[0].getName());
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	
	/**
	 * This set form bean value using filter vo
	 * @param baseForm
	 * @param filterVO
	 */
	private void setForm(WorkQueueForm discrpDetailForm, FilterVO filterVO) {
		logger.info(LoggerConstants.methodStartLevel());
		discrpDetailForm.setPlanName(StringUtil.nonNullTrim(filterVO.getPlanName()));
		discrpDetailForm.setFromDate(filterVO.getStartDate());
		discrpDetailForm.setToDate(filterVO.getEndDate());
		discrpDetailForm.setHicNbr(filterVO.getHicNumber());
		discrpDetailForm.setWqupdateDateFrom(filterVO.getUpdateDateFrom());
		discrpDetailForm.setWqupdateDateTo(filterVO.getUpdateDateTo());
		discrpDetailForm.setWqupdateId(filterVO.getUpdateId());

		/*if(! Constants.BOTH_PARTS.equals(discrpDetailForm.getActiveService()) && Constants.BOTH_PARTS.equals(filterVO.getPartName()) )
			discrpDetailForm.setPartName(discrpDetailForm.getActiveService());
		else*/
			discrpDetailForm.setPartName(filterVO.getPartName());

		discrpDetailForm.setSearchType(filterVO.getSearchType());
		
		discrpDetailForm.setDiscCd(StringUtil.trimToNull(filterVO.getDiscrpCd()));
		discrpDetailForm.setDiscrepancyType(StringUtil.trimToNull(filterVO.getDiscrpStatus()));
		discrpDetailForm.setWqassignedBy(StringUtil.nonNullTrim(filterVO.getAssignedBy()));
		discrpDetailForm.setAssignedByList(filterVO.getAssignedByList());
		discrpDetailForm.setWqassignedTo(StringUtil.nonNullTrim(filterVO.getAssignedTo()));
		discrpDetailForm.setAssignedToList(filterVO.getAssignedToList());
		discrpDetailForm.setWqfromAssignDate(StringUtil.nonNullTrim(filterVO.getFromAssignDate()));
		discrpDetailForm.setWqtoAssignDate(StringUtil.nonNullTrim(filterVO.getToAssignDate()));
		discrpDetailForm.setSearchcomment(StringUtil.nonNullTrim(filterVO.getSearchcomment()));
		
		logger.info(LoggerConstants.methodEndLevel());
	}

	/**
	 * This set detailMap which contain total number of page ,records , first and last record of discrpancyList 
	 * @param discrpMap
	 * @param discrepancyDetailVOList
	 * @param sessionHelper
	 * @param partName
	 * @param pageType
	 * @param string
	 */
	private void setDetailMap(Map discrpMap, DiscrepancyDetailVOList discDetailVOList, SessionHelper sessionHelper, String menuName, String partName, String pageType) {
		logger.info(LoggerConstants.methodStartLevel());
		if(discDetailVOList != null) {
			if(discrpMap == null )
				discrpMap = new HashMap ();
			discrpMap.put(Constants.PARTC_DISCRP_DETAIL_MAP,createMap(discDetailVOList.getPartCDiscrpDetailVO(), (Map)discrpMap.get(Constants.PARTC_DISCRP_DETAIL_MAP)));
			
			discrpMap.put(Constants.PAGE_SELECTED_LINE , new Integer(discDetailVOList.getSelectedLine()));
			
			discrpMap.remove(Constants.SESSION_MAX_RECORD_COUNT);
			discrpMap.remove(Constants.CONSTANTS_ALL);			

			sessionHelper.setAttribute(Constants.SESSION_WORK_QUEUE_MAP,discrpMap);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	/**
	 * 
	 * @param discrepancyDetailVO
	 * @param discrpMap
	 * @return
	 */
	private Map createMap(DiscrepancyDetailVO discrepancyDetailVO, Map discrpMap){
		logger.info(LoggerConstants.methodStartLevel());
		if(discrepancyDetailVO != null) {
			if(discrpMap == null)
			discrpMap = new HashMap ();
				DiscrepancyListVO [] discrepancyListVO = discrepancyDetailVO.getDiscrepancyListVO();
				if(discrepancyListVO != null ){
					discrpMap.put(Constants.FIRST_DETAIL_VO,discrepancyListVO[0]);
					discrpMap.put(Constants.LAST_DETAIL_VO,discrepancyListVO[discrepancyListVO.length-1]);
					discrpMap.put(Constants.CURRENT_PAGE,discrepancyDetailVO.getCurrentPage());
					discrpMap.put(Constants.PAGE_NUMBER , new Integer(discrepancyDetailVO.getPageNumber()));
					
				}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return discrpMap;
	}

	/**
	 *  This function reset filterVO using form Bean values when user change filter cretaria.
	 * @param discrepancyDetailForm
	 * @param filterVO
	 * @return
	 */
	private FilterVO setFilterVO(WorkQueueForm discrepancyDetailForm, FilterVO filterVO) {
		logger.info(LoggerConstants.methodStartLevel());
		String action = discrepancyDetailForm.getActionType();
		
		if (filterVO == null)
			filterVO = new FilterVO();
		//filterVO.setDiscrepancyIndicator(StringUtil.trimToNull(discrepancyDetailForm.getPartName()));
		
		
			//see if a different hic number is entered.
			String baseHic = StringUtil.nonNullTrim(discrepancyDetailForm.getHicNbr());
			String filterHic = StringUtil.nonNullTrim(filterVO.getHicNumber());
			if (!filterHic.equals(baseHic)) { //a new one is entered, clear memberId and HicNumberList.
				filterVO.setMemberId(null);
				filterVO.setHicNumberList(null);		
			}
			filterVO.setSearchType(discrepancyDetailForm.getSearchType());
			filterVO.setPlanName(StringUtil.trimToNull(discrepancyDetailForm.getPlanName()));
			filterVO.setStartDate(StringUtil.trimToNull(discrepancyDetailForm.getFromDate()));
			filterVO.setEndDate(StringUtil.trimToNull(discrepancyDetailForm.getToDate()));
			filterVO.setDateType("E");
			filterVO.setDiscrpCd(StringUtil.trimToNull(discrepancyDetailForm.getDiscCd()));
			filterVO.setDiscrpStatus(StringUtil.trimToNull(discrepancyDetailForm.getDiscrepancyType()));
			filterVO.setHicNumber(StringUtil.trimToNull(discrepancyDetailForm.getHicNbr()));
			filterVO.setUpdateDateFrom(StringUtil.trimToNull(discrepancyDetailForm.getWqupdateDateFrom()));
			filterVO.setUpdateDateTo(StringUtil.trimToNull(discrepancyDetailForm.getWqupdateDateTo()));
			filterVO.setUpdateId(StringUtil.trimToNull(discrepancyDetailForm.getWqupdateId()));
			filterVO.setPageHeaderMsg("");
			String indicator = StringUtil.trimToNull(discrepancyDetailForm.getPartName());
			filterVO.setAssignedBy(StringUtil.nonNullTrim(discrepancyDetailForm.getWqassignedBy()));
			filterVO.setAssignedByList(discrepancyDetailForm.getAssignedByList());
			filterVO.setAssignedTo(StringUtil.nonNullTrim(discrepancyDetailForm.getWqassignedTo()));
			filterVO.setAssignedToList(discrepancyDetailForm.getAssignedToList());
			filterVO.setPartName(indicator); 
			filterVO.setFromAssignDate(StringUtil.nonNullTrim(discrepancyDetailForm.getWqfromAssignDate()));
			filterVO.setToAssignDate(StringUtil.nonNullTrim(discrepancyDetailForm.getWqtoAssignDate()));
			filterVO.setSearchcomment(StringUtil.nonNullTrim(discrepancyDetailForm.getSearchcomment()));
			filterVO.setReassignedTo(StringUtil.nonNullTrim(discrepancyDetailForm.getReassignedTo()));
			filterVO.setReassignComment(StringUtil.nonNullTrim(discrepancyDetailForm.getReassignComment()));
			filterVO.setSelectedIndexes(StringUtil.nonNullTrim(discrepancyDetailForm.getSelectedIndexes()));
			filterVO.setUpdateMessage(StringUtil.nonNullTrim(discrepancyDetailForm.getUpdateMessage()));
			filterVO.setSelectedPageNo(discrepancyDetailForm.getSelectedPageNo());
			
		
		logger.info(LoggerConstants.methodEndLevel());
		return filterVO;
	}
	
	/**
	 * This setUIContext for discrepancy detail
	 * @param uiContext
	 * @param baseForm
	 */
	private void setUiContext(List uiContext, WorkQueueForm discrepancyDetailForm) {
		logger.info(LoggerConstants.methodStartLevel());
		if(uiContext != null) {
			String contextString = null;
			Iterator it = uiContext.iterator();
			while(it.hasNext()) {
				contextString = (String) it.next();
				if(Constants.DISCRP_LIST.equals(contextString)) {
					discrepancyDetailForm.setShowDiscrpList(contextString);
				} else if(Constants.DISCRP_DETAIL.equals(contextString)) {
					discrepancyDetailForm.setShowDiscrpDetail(contextString);
				} else if(Constants.DISCRP_HISTORY.equals(contextString)) {
					discrepancyDetailForm.setShowDiscrpHistory(contextString);
				} else if(Constants.DEMOGRAPHIC_INFO.equals(contextString)) {
					discrepancyDetailForm.setShowDemoGrpInfo(contextString);
				} else if(Constants.PARTD_DISCRP_LIST.equals(contextString)) {
					discrepancyDetailForm.setShowPartDDiscrpList(contextString);
				}
			}
		} else { // This is for default context because in defult detail  must be open
			discrepancyDetailForm.setShowDiscrpList(Constants.DISCRP_LIST);
			discrepancyDetailForm.setShowDiscrpDetail(Constants.DISCRP_DETAIL);
			discrepancyDetailForm.setShowDiscrpHistory(Constants.DISCRP_HISTORY);
			discrepancyDetailForm.setShowPartDDiscrpList(Constants.PARTD_DISCRP_LIST);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
}
