/*
 * $Id: HPEFileTrackHelper.java,v 1.3 2015/11/27 12:10:54 praveen Exp $
 */
package com.ps.mss.web.helper;

import java.text.DateFormatSymbols;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.model.HPEFTDailyFileProcessingDO;
import com.ps.mss.dao.model.HPEFTDailyFileProcessingVO;
import com.ps.mss.dao.model.HPEFTEDPSFileDshbMngtDO;
import com.ps.mss.dao.model.HPEFTEDPSFileDshbMngtVO;
import com.ps.mss.dao.model.HPEFTFailedFileListDO;
import com.ps.mss.dao.model.HPEFTFailedFileListVO;
import com.ps.mss.dao.model.HPEFTMonEncDetailsDO;
import com.ps.mss.dao.model.HPEFTMonEncDetailsVO;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.web.forms.HPEFileTrackingForm;

/**
 * This Class is used to assign values from DO to VO.
 * 
 * @author bsanthos.
 *
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class HPEFileTrackHelper {
	/**
	 * logger.
	 */
	//private static ModuleLog log = new ModuleLog("HPEFileTrackHelper");
	private static Logger logger=LoggerFactory.getLogger(HPEFileTrackHelper.class);

	/**
	 * This method is used to copy the searchResults from
	 * HPEFTEDPSFileDshbMngtDO to HPEFTEDPSFileDshbMngtVO.
	 * 
	 * @param searchDOLst
	 *            List<HPEFTEDPSFileDshbMngtDO>
	 * @return sec1uiYrLst List
	 * @throws ApplicationException
	 */

	public List<HPEFTEDPSFileDshbMngtDO> copySearchToDisplay(List<HPEFTEDPSFileDshbMngtDO> searchDOLst)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		HPEFTEDPSFileDshbMngtVO uiDsbmngtvo = null;
		HPEFTEDPSFileDshbMngtVO uiYrDsbmngtvo = null;

		List sec1uiYrLst = new ArrayList();
		List sec1uiMonLst = null;

		String currYrMo = null;
		boolean init = false;

		try {
			Iterator itr = searchDOLst.iterator();
			while (itr.hasNext()) {

				HPEFTEDPSFileDshbMngtDO dsbmngtvo = (HPEFTEDPSFileDshbMngtDO) itr.next();

				if (init == false) {
					currYrMo = dsbmngtvo.getDateYrmo();
					uiDsbmngtvo = new HPEFTEDPSFileDshbMngtVO();
					sec1uiMonLst = new ArrayList();
					uiYrDsbmngtvo = new HPEFTEDPSFileDshbMngtVO();
					init = true;
				}

				if (!(dsbmngtvo.getDateYrmo().equals(currYrMo))) {
					uiDsbmngtvo.setProfTotal(
							uiDsbmngtvo.getProfCompl() + uiDsbmngtvo.getProfInProg() + uiDsbmngtvo.getProfFailed());
					uiDsbmngtvo.setInstTotal(
							uiDsbmngtvo.getInstCompl() + uiDsbmngtvo.getInstInProg() + uiDsbmngtvo.getInstFailed());
					uiDsbmngtvo.setDentTotal(
							uiDsbmngtvo.getDentCompl() + uiDsbmngtvo.getDentInProg() + uiDsbmngtvo.getDentFailed());
					uiDsbmngtvo.setDmeTotal(
							uiDsbmngtvo.getDmeCompl() + uiDsbmngtvo.getDmeInProg() + uiDsbmngtvo.getDmeFailed());
					uiDsbmngtvo.setAllTotal(uiDsbmngtvo.getProfTotal() + uiDsbmngtvo.getInstTotal()
							+ uiDsbmngtvo.getDentTotal() + uiDsbmngtvo.getDmeTotal());
					uiDsbmngtvo.setYrMo(getMonthName(currYrMo));

					uiYrDsbmngtvo.setProfCompl(uiYrDsbmngtvo.getProfCompl() + uiDsbmngtvo.getProfCompl());
					uiYrDsbmngtvo.setProfInProg(uiYrDsbmngtvo.getProfInProg() + uiDsbmngtvo.getProfInProg());
					uiYrDsbmngtvo.setProfFailed(uiYrDsbmngtvo.getProfFailed() + uiDsbmngtvo.getProfFailed());
					uiYrDsbmngtvo.setProfTotal(uiYrDsbmngtvo.getProfTotal() + uiDsbmngtvo.getProfTotal());
					uiYrDsbmngtvo.setInstCompl(uiYrDsbmngtvo.getInstCompl() + uiDsbmngtvo.getInstCompl());
					uiYrDsbmngtvo.setInstInProg(uiYrDsbmngtvo.getInstInProg() + uiDsbmngtvo.getInstInProg());
					uiYrDsbmngtvo.setInstFailed(uiYrDsbmngtvo.getInstFailed() + uiDsbmngtvo.getInstFailed());
					uiYrDsbmngtvo.setInstTotal(uiYrDsbmngtvo.getInstTotal() + uiDsbmngtvo.getInstTotal());
					uiYrDsbmngtvo.setDentCompl(uiYrDsbmngtvo.getDentCompl() + uiDsbmngtvo.getDentCompl());
					uiYrDsbmngtvo.setDentInProg(uiYrDsbmngtvo.getDentInProg() + uiDsbmngtvo.getDentInProg());
					uiYrDsbmngtvo.setDentFailed(uiYrDsbmngtvo.getDentFailed() + uiDsbmngtvo.getDentFailed());
					uiYrDsbmngtvo.setDentTotal(uiYrDsbmngtvo.getDentTotal() + uiDsbmngtvo.getDentTotal());
					uiYrDsbmngtvo.setDmeCompl(uiYrDsbmngtvo.getDmeCompl() + uiDsbmngtvo.getDmeCompl());
					uiYrDsbmngtvo.setDmeInProg(uiYrDsbmngtvo.getDmeInProg() + uiDsbmngtvo.getDmeInProg());
					uiYrDsbmngtvo.setDmeFailed(uiYrDsbmngtvo.getDmeFailed() + uiDsbmngtvo.getDmeFailed());
					uiYrDsbmngtvo.setDmeTotal(uiYrDsbmngtvo.getDmeTotal() + uiDsbmngtvo.getDmeTotal());
					uiYrDsbmngtvo.setAllTotal(uiYrDsbmngtvo.getAllTotal() + uiDsbmngtvo.getAllTotal());

					sec1uiMonLst.add(uiDsbmngtvo);
					uiDsbmngtvo = new HPEFTEDPSFileDshbMngtVO();

					if (!(dsbmngtvo.getDateYrmo().substring(0, 4)).equals(currYrMo.substring(0, 4))) { // yearChange(currYrMo)
																										// ){
						uiYrDsbmngtvo.setYrMo(currYrMo.trim().substring(0, 4));
						uiYrDsbmngtvo.setDataLst(sec1uiMonLst);
						sec1uiYrLst.add(uiYrDsbmngtvo);

						uiYrDsbmngtvo = new HPEFTEDPSFileDshbMngtVO();
						sec1uiMonLst = new ArrayList();
					}

					currYrMo = dsbmngtvo.getDateYrmo();
				}

				if ((dsbmngtvo.getDateYrmo().equals(currYrMo))) {

					if (dsbmngtvo.getEncType().equals("P")) {
						if (dsbmngtvo.getOriginalFileStatus().equals("10")) {
							uiDsbmngtvo.setProfCompl(uiDsbmngtvo.getProfCompl() + dsbmngtvo.getRecordCount());
							uiDsbmngtvo.setIntrchgRecvrId_P(dsbmngtvo.getIntrchg_recvr_id());
							uiDsbmngtvo.setCustSourceId_P(dsbmngtvo.getCust_source_id());
						}
						if (dsbmngtvo.getOriginalFileStatus().equals("20")) {
							uiDsbmngtvo.setProfInProg(uiDsbmngtvo.getProfInProg() + dsbmngtvo.getRecordCount());
							uiDsbmngtvo.setIntrchgRecvrId_P(dsbmngtvo.getIntrchg_recvr_id());
							uiDsbmngtvo.setCustSourceId_P(dsbmngtvo.getCust_source_id());
						}
						if (dsbmngtvo.getOriginalFileStatus().equals("30")) {
							uiDsbmngtvo.setProfFailed(uiDsbmngtvo.getProfFailed() + dsbmngtvo.getRecordCount());
							uiDsbmngtvo.setIntrchgRecvrId_P(dsbmngtvo.getIntrchg_recvr_id());
							uiDsbmngtvo.setCustSourceId_P(dsbmngtvo.getCust_source_id());
						}
					} // professional
					if (dsbmngtvo.getEncType().equals("I")) {
						if (dsbmngtvo.getOriginalFileStatus().equals("10")) {
							uiDsbmngtvo.setInstCompl(uiDsbmngtvo.getInstCompl() + dsbmngtvo.getRecordCount());
							uiDsbmngtvo.setIntrchgRecvrId_I(dsbmngtvo.getIntrchg_recvr_id());
							uiDsbmngtvo.setCustSourceId_I(dsbmngtvo.getCust_source_id());
						}
						if (dsbmngtvo.getOriginalFileStatus().equals("20")) {
							uiDsbmngtvo.setInstInProg(uiDsbmngtvo.getInstInProg() + dsbmngtvo.getRecordCount());
							uiDsbmngtvo.setIntrchgRecvrId_I(dsbmngtvo.getIntrchg_recvr_id());
							uiDsbmngtvo.setCustSourceId_I(dsbmngtvo.getCust_source_id());
						}
						if (dsbmngtvo.getOriginalFileStatus().equals("30")) {
							uiDsbmngtvo.setInstFailed(uiDsbmngtvo.getInstFailed() + dsbmngtvo.getRecordCount());
							uiDsbmngtvo.setIntrchgRecvrId_I(dsbmngtvo.getIntrchg_recvr_id());
							uiDsbmngtvo.setCustSourceId_I(dsbmngtvo.getCust_source_id());
						}
					} // Institutional
					if (dsbmngtvo.getEncType().equals("D")) {
						if (dsbmngtvo.getOriginalFileStatus().equals("10")) {
							uiDsbmngtvo.setDentCompl(uiDsbmngtvo.getDentCompl() + dsbmngtvo.getRecordCount());
							uiDsbmngtvo.setIntrchgRecvrId_D(dsbmngtvo.getIntrchg_recvr_id());
							uiDsbmngtvo.setCustSourceId_D(dsbmngtvo.getCust_source_id());
						}
						if (dsbmngtvo.getOriginalFileStatus().equals("20")) {
							uiDsbmngtvo.setDentInProg(uiDsbmngtvo.getDentInProg() + dsbmngtvo.getRecordCount());
							uiDsbmngtvo.setIntrchgRecvrId_D(dsbmngtvo.getIntrchg_recvr_id());
							uiDsbmngtvo.setCustSourceId_D(dsbmngtvo.getCust_source_id());
						}
						if (dsbmngtvo.getOriginalFileStatus().equals("30")) {
							uiDsbmngtvo.setDentFailed(uiDsbmngtvo.getDentFailed() + dsbmngtvo.getRecordCount());
							uiDsbmngtvo.setIntrchgRecvrId_D(dsbmngtvo.getIntrchg_recvr_id());
							uiDsbmngtvo.setCustSourceId_D(dsbmngtvo.getCust_source_id());
						}
					} // Dental
					if (dsbmngtvo.getEncType().equals("E")) {
						if (dsbmngtvo.getOriginalFileStatus().equals("10")) {
							uiDsbmngtvo.setDmeCompl(uiDsbmngtvo.getDmeCompl() + dsbmngtvo.getRecordCount());
							uiDsbmngtvo.setIntrchgRecvrId_E(dsbmngtvo.getIntrchg_recvr_id());
							uiDsbmngtvo.setCustSourceId_E(dsbmngtvo.getCust_source_id());
						}
						if (dsbmngtvo.getOriginalFileStatus().equals("20")) {
							uiDsbmngtvo.setDmeInProg(uiDsbmngtvo.getDmeInProg() + dsbmngtvo.getRecordCount());
							uiDsbmngtvo.setIntrchgRecvrId_E(dsbmngtvo.getIntrchg_recvr_id());
							uiDsbmngtvo.setCustSourceId_E(dsbmngtvo.getCust_source_id());
						}
						if (dsbmngtvo.getOriginalFileStatus().equals("30")) {
							uiDsbmngtvo.setDmeFailed(uiDsbmngtvo.getDmeFailed() + dsbmngtvo.getRecordCount());
							uiDsbmngtvo.setIntrchgRecvrId_E(dsbmngtvo.getIntrchg_recvr_id());
							uiDsbmngtvo.setCustSourceId_E(dsbmngtvo.getCust_source_id());
						}
					} // DME

				}
			} // while

			uiDsbmngtvo.setProfTotal(
					uiDsbmngtvo.getProfCompl() + uiDsbmngtvo.getProfInProg() + uiDsbmngtvo.getProfFailed());
			uiDsbmngtvo.setInstTotal(
					uiDsbmngtvo.getInstCompl() + uiDsbmngtvo.getInstInProg() + uiDsbmngtvo.getInstFailed());
			uiDsbmngtvo.setDentTotal(
					uiDsbmngtvo.getDentCompl() + uiDsbmngtvo.getDentInProg() + uiDsbmngtvo.getDentFailed());
			uiDsbmngtvo
					.setDmeTotal(uiDsbmngtvo.getDmeCompl() + uiDsbmngtvo.getDmeInProg() + uiDsbmngtvo.getDmeFailed());
			uiDsbmngtvo.setAllTotal(uiDsbmngtvo.getProfTotal() + uiDsbmngtvo.getInstTotal() + uiDsbmngtvo.getDentTotal()
					+ uiDsbmngtvo.getDmeTotal());
			uiDsbmngtvo.setYrMo(getMonthName(currYrMo));

			uiYrDsbmngtvo.setProfCompl(uiYrDsbmngtvo.getProfCompl() + uiDsbmngtvo.getProfCompl());
			uiYrDsbmngtvo.setProfInProg(uiYrDsbmngtvo.getProfInProg() + uiDsbmngtvo.getProfInProg());
			uiYrDsbmngtvo.setProfFailed(uiYrDsbmngtvo.getProfFailed() + uiDsbmngtvo.getProfFailed());
			uiYrDsbmngtvo.setProfTotal(uiYrDsbmngtvo.getProfTotal() + uiDsbmngtvo.getProfTotal());
			uiYrDsbmngtvo.setInstCompl(uiYrDsbmngtvo.getInstCompl() + uiDsbmngtvo.getInstCompl());
			uiYrDsbmngtvo.setInstInProg(uiYrDsbmngtvo.getInstInProg() + uiDsbmngtvo.getInstInProg());
			uiYrDsbmngtvo.setInstFailed(uiYrDsbmngtvo.getInstFailed() + uiDsbmngtvo.getInstFailed());
			uiYrDsbmngtvo.setInstTotal(uiYrDsbmngtvo.getInstTotal() + uiDsbmngtvo.getInstTotal());
			uiYrDsbmngtvo.setDentCompl(uiYrDsbmngtvo.getDentCompl() + uiDsbmngtvo.getDentCompl());
			uiYrDsbmngtvo.setDentInProg(uiYrDsbmngtvo.getDentInProg() + uiDsbmngtvo.getDentInProg());
			uiYrDsbmngtvo.setDentFailed(uiYrDsbmngtvo.getDentFailed() + uiDsbmngtvo.getDentFailed());
			uiYrDsbmngtvo.setDentTotal(uiYrDsbmngtvo.getDentTotal() + uiDsbmngtvo.getDentTotal());
			uiYrDsbmngtvo.setDmeCompl(uiYrDsbmngtvo.getDmeCompl() + uiDsbmngtvo.getDmeCompl());
			uiYrDsbmngtvo.setDmeInProg(uiYrDsbmngtvo.getDmeInProg() + uiDsbmngtvo.getDmeInProg());
			uiYrDsbmngtvo.setDmeFailed(uiYrDsbmngtvo.getDmeFailed() + uiDsbmngtvo.getDmeFailed());
			uiYrDsbmngtvo.setDmeTotal(uiYrDsbmngtvo.getDmeTotal() + uiDsbmngtvo.getDmeTotal());
			uiYrDsbmngtvo.setAllTotal(uiYrDsbmngtvo.getAllTotal() + uiDsbmngtvo.getAllTotal());

			sec1uiMonLst.add(uiDsbmngtvo);
			uiYrDsbmngtvo.setYrMo(currYrMo.trim().substring(0, 4));
			uiYrDsbmngtvo.setDataLst(sec1uiMonLst);
			sec1uiYrLst.add(uiYrDsbmngtvo);

		} catch (Exception ex) {
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			//logger.error(ex.getMessage());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return sec1uiYrLst;
	}// copySearchToDisplay

	/**
	 * This method is used to copy the search results from HPEFTMonEncDetailsDO
	 * to HPEFTMonEncDetailsVO.
	 * 
	 * @param searchVOLst
	 *            List<HPEFTMonEncDetailsDO>
	 * @return monEncDetailsVO HPEFTMonEncDetailsVO
	 * @throws ApplicationException
	 */

	public List<HPEFTMonEncDetailsDO> copySearchToMonEncDetailsDisplay(List<HPEFTMonEncDetailsDO> searchVOLst,
			HPEFileTrackingForm hpeftSearchForm) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("HPEFileTrackHelper.copySearchToMonEncDetailsDisplay() - START");
//		logger.info("HPEFileTrackHelper.copySearchToMonEncDetailsDisplay() - START");
		HPEFTMonEncDetailsVO monEncDetailsVO = null;
		List monEncDtlHelpLst = new ArrayList();
		try {
			Iterator itr = searchVOLst.iterator();

			while (itr.hasNext()) {
				monEncDetailsVO = new HPEFTMonEncDetailsVO();
				HPEFTMonEncDetailsDO hpeftmonEncDetailsVO = (HPEFTMonEncDetailsDO) itr.next();

				String yearMonthDay = hpeftmonEncDetailsVO.getSubmissionDate();
				String yearMonthTemp = yearMonthDay.substring(0, 6);
				String monthDayTemp = yearMonthDay.substring(4, 8);
				String yearMonth = getMonthYearName(yearMonthTemp);
				String monthDay = getMonthDayName(monthDayTemp);
				monEncDetailsVO.setMonYear(yearMonth);
				monEncDetailsVO.setMonDay(monthDay);
				monEncDetailsVO.setFiles(hpeftmonEncDetailsVO.getFiles());
				monEncDetailsVO.setEncInFile(hpeftmonEncDetailsVO.getEncInFile());
				monEncDetailsVO.setEncSentCMS(hpeftmonEncDetailsVO.getEncSenttoCMS());

				int rejCnt = hpeftmonEncDetailsVO.getWiproRej() + hpeftmonEncDetailsVO.getWiproResub();

				monEncDetailsVO.setWiproRej(rejCnt);
				monEncDetailsVO.setWiproResub(hpeftmonEncDetailsVO.getWiproResub());
				monEncDetailsVO.setCms_999_ACC(hpeftmonEncDetailsVO.getCms_999_ACC());

				int rej999Cnt = hpeftmonEncDetailsVO.getCms_999_Rej() + hpeftmonEncDetailsVO.getCms_999_Rej();

				monEncDetailsVO.setCms_999_Rej(rej999Cnt);
				monEncDetailsVO.setCms_999_Resub(hpeftmonEncDetailsVO.getCms_999_Rej());
				monEncDetailsVO.setCms_277CA_ACC(hpeftmonEncDetailsVO.getCms_277CA_ACC());
				monEncDetailsVO.setCms_277CA_Rej(hpeftmonEncDetailsVO.getCms_277CA_Rej());

				int accMAOcnt = hpeftmonEncDetailsVO.getCms_MAO002_ACC() + hpeftmonEncDetailsVO.getCms_MAO002_ACE();
				monEncDetailsVO.setCms_MAO002_ACC(accMAOcnt);
				monEncDetailsVO.setCms_MAO002_ACE(hpeftmonEncDetailsVO.getCms_MAO002_ACE());

				monEncDetailsVO.setCms_MAO002_Rej(hpeftmonEncDetailsVO.getCms_MAO002_Rej());

				monEncDtlHelpLst.add(monEncDetailsVO);

				monEncDetailsVO.setSubmissionDate(yearMonthDay);
				monEncDetailsVO.setEncType(hpeftSearchForm.getStatus().substring(0, 1));
				int dateYrmo = hpeftSearchForm.getDateYRMO() + 1;
				monEncDetailsVO.setDateYrMo(String.valueOf(dateYrmo));
				monEncDetailsVO.setIntrchg_recvr_id(hpeftSearchForm.getIntrchg_recvr_id());
				monEncDetailsVO.setCust_source_id(hpeftSearchForm.getCust_source_id());
				monEncDetailsVO.setSplitFileStatus(hpeftSearchForm.getSplitFileStatus());

			}

		} catch (Exception ex) {
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			//logger.error(ex.getMessage());
		}
		logger.debug("HPEFileTrackHelper.copySearchToMonEncDetailsDisplay()- END");
//		logger.error("HPEFileTrackHelper.copySearchToMonEncDetailsDisplay()- END");
		logger.info(LoggerConstants.methodEndLevel());
		return monEncDtlHelpLst;

	}

	/**
	 * This method is used to copy the search results from
	 * HPEFTDailyFileProcessingDO to HPEFTDailyFileProcessingVO.
	 * 
	 * @param searchVOLst
	 *            List<HPEFTDailyFileProcessingDO>
	 * @return dailyFileProcessingVO dailyFileProcessingVO
	 * @throws ApplicationException
	 */

	public List<HPEFTDailyFileProcessingDO> copySearchToDailyFileProcessingDisplay(
			List<HPEFTDailyFileProcessingDO> searchVOLst) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("HPEFileTrackHelper.copySearchToDailyFileProcessingDisplay() - START" + searchVOLst.size());
//		logger.info("HPEFileTrackHelper.copySearchToDailyFileProcessingDisplay() - START" + searchVOLst.size());
		HPEFTDailyFileProcessingVO dailyFileProcesVO = null;
		List dailyFileProHelpLst = null;
		try {
			Iterator itr = searchVOLst.iterator();
			dailyFileProHelpLst = new ArrayList();

			while (itr.hasNext()) {
				dailyFileProcesVO = new HPEFTDailyFileProcessingVO();
				HPEFTDailyFileProcessingDO hpeftDailyFileProcessingDO = (HPEFTDailyFileProcessingDO) itr.next();

				// logger.error("hpeftDailyFileProcessingDO.getCust_file_name() is from copySearchToDailyFileProcessingDisplay :"+hpeftDailyFileProcessingDO.getCust_file_name());

				dailyFileProcesVO.setCust_file_name(hpeftDailyFileProcessingDO.getCust_file_name());
				dailyFileProcesVO.setEncType(hpeftDailyFileProcessingDO.getEncType());
				dailyFileProcesVO.setClaimType(hpeftDailyFileProcessingDO.getClaimType());
				dailyFileProcesVO.setOrig_intrchg_ctrl_nbr(hpeftDailyFileProcessingDO.getOrig_intrchg_ctrl_nbr());
				dailyFileProcesVO.setCustFileId(hpeftDailyFileProcessingDO.getCustFileId());//IFOX-00416789 - Add customer ICN in File management

				dailyFileProcesVO.setEncInFile(hpeftDailyFileProcessingDO.getEncInFile());
				dailyFileProcesVO.setEncSentCMS(hpeftDailyFileProcessingDO.getEncSenttoCMS());

				int rejWip = hpeftDailyFileProcessingDO.getWiproRej() + hpeftDailyFileProcessingDO.getWiproResub();
				dailyFileProcesVO.setWiproRej(rejWip);
				dailyFileProcesVO.setWiproResub(hpeftDailyFileProcessingDO.getWiproResub());

				dailyFileProcesVO.setCms_999_ACC(hpeftDailyFileProcessingDO.getCms_999_ACC());

				int rej999 = hpeftDailyFileProcessingDO.getCms_999_Rej()
						+ hpeftDailyFileProcessingDO.getCms_999_Resub();
				dailyFileProcesVO.setCms_999_Rej(rej999);
				dailyFileProcesVO.setCms_999_Resub(hpeftDailyFileProcessingDO.getCms_999_Resub());

				dailyFileProcesVO.setCms_277CA_ACC(hpeftDailyFileProcessingDO.getCms_277CA_ACC());
				dailyFileProcesVO.setCms_277CA_Rej(hpeftDailyFileProcessingDO.getCms_277CA_Rej());

				int mao002Acc = hpeftDailyFileProcessingDO.getCms_MAO002_ACC()
						+ hpeftDailyFileProcessingDO.getCms_MAO002_ACE();

				dailyFileProcesVO.setCms_MAO002_ACC(mao002Acc);
				dailyFileProcesVO.setCms_MAO002_ACE(hpeftDailyFileProcessingDO.getCms_MAO002_ACE());
				dailyFileProcesVO.setCms_MAO002_Rej(hpeftDailyFileProcessingDO.getCms_MAO002_Rej());

				if (hpeftDailyFileProcessingDO.getCust_file_name() != null
						&& StringUtils.isNotEmpty(hpeftDailyFileProcessingDO.getCust_file_name()))
					dailyFileProHelpLst.add(dailyFileProcesVO);
				String submissionDateFormat = hpeftDailyFileProcessingDO.getSubmissionDate();
				if (submissionDateFormat != null && StringUtils.isNotEmpty(submissionDateFormat))
					dailyFileProcesVO.setSubmissionDate(getMonthDayYearName(submissionDateFormat));
				
				
				if(StringUtils.isNotEmpty(hpeftDailyFileProcessingDO.getSubs_hic_nbr())){
					String[] hicStatArr = hpeftDailyFileProcessingDO.getSubs_hic_nbr().split("-");
					dailyFileProcesVO.setSubs_hic_nbr(hicStatArr[0]);
					dailyFileProcesVO.setProcess_status(hicStatArr[1]);
					
				}
			}
		} catch (Exception ex) {
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			//logger.error(ex.getMessage());
		}
//		logger.error("HPEFileTrackHelper.copySearchToDailyFileProcessingDisplay()- END");
		logger.debug("HPEFileTrackHelper.copySearchToDailyFileProcessingDisplay()- END");
		logger.info(LoggerConstants.methodEndLevel());
		return dailyFileProHelpLst;
	}

	/**
	 * This method is used to copy Search results To Failed File List Grid.
	 * 
	 * @param searchVOLst
	 *            HPEFTFailedFileListDO
	 * @return failFileHelprLst List
	 * @throws ApplicationException
	 */

	public List<HPEFTFailedFileListDO> copySearchToFailedFileListDisplay(List<HPEFTFailedFileListDO> searchVOLst)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("HPEFileTrackHelper.copySearchToFailedFileListDisplay() - START" + searchVOLst.size());
//		logger.info("HPEFileTrackHelper.copySearchToFailedFileListDisplay() - START" + searchVOLst.size());
		HPEFTFailedFileListVO hpeftFailFleLstVO = null;
		List failFileHelprLst = null;
		try {
			Iterator itr = searchVOLst.iterator();
			failFileHelprLst = new ArrayList();

			while (itr.hasNext()) {
				hpeftFailFleLstVO = new HPEFTFailedFileListVO();
				HPEFTFailedFileListDO hpeftFailedFileListDO = (HPEFTFailedFileListDO) itr.next();

				hpeftFailFleLstVO.setCust_file_name(hpeftFailedFileListDO.getCust_file_name());
				logger.debug("cust file name is::" + hpeftFailFleLstVO.getCust_file_name());

				hpeftFailFleLstVO.setFileDate(getMonthDayYearName(hpeftFailedFileListDO.getFileDate()));
				logger.debug("file date is::" + hpeftFailFleLstVO.getFileDate());

				failFileHelprLst.add(hpeftFailFleLstVO);

			}
		} catch (Exception ex) {
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			//logger.error(ex.getMessage());
		}
//		logger.error("HPEFileTrackHelper.copySearchToFailedFileListDisplay()- END");
		logger.debug("HPEFileTrackHelper.copySearchToFailedFileListDisplay()- END");
		logger.info(LoggerConstants.methodEndLevel());
		return failFileHelprLst;

	}

	/**
	 * This method is used to get Month Name.
	 * 
	 * @param currYrMo
	 *            String
	 * @return months String[].
	 */
	public String getMonthName(String currYrMo) {
		logger.info(LoggerConstants.methodStartLevel());
		DateFormatSymbols dateFormatSymbols = new DateFormatSymbols();
		String[] months = dateFormatSymbols.getShortMonths();
		logger.info(LoggerConstants.methodEndLevel());
		return months[(new Integer(currYrMo.substring(4)).intValue() - 1)];
	}// getMonthName()

	/**
	 * This method is used to get Month Year Name.
	 * 
	 * @param currYrMo
	 *            String
	 * @return returnContent String.
	 */
	public String getMonthYearName(String currYrMo) {
		logger.info(LoggerConstants.methodStartLevel());
		String returnContent = null;
		String month = null;
		String year = currYrMo.substring(0, 4);
		int monthNum = Integer.valueOf(currYrMo.substring(4, 6));
		DateFormatSymbols dfs = new DateFormatSymbols();
		String[] months = dfs.getMonths();
		if (monthNum >= 0 && monthNum <= 12) {
			month = months[monthNum - 1];
		}
		returnContent = month + " " + year;
		logger.info(LoggerConstants.methodEndLevel());
		return returnContent;
	}// getMonthYearName()

	/**
	 * This method is used to get Month Day Name.
	 * 
	 * @param currYrMo
	 *            String
	 * @return returnContent String.
	 */
	public String getMonthDayName(String currMoDay) {
		logger.info(LoggerConstants.methodStartLevel());
		String returnContent = null;
		String month = null;
		String day = currMoDay.substring(2, 4);
		int monthNum = Integer.valueOf(currMoDay.substring(0, 2));
		DateFormatSymbols dfs = new DateFormatSymbols();
		String[] months = dfs.getMonths();
		if (monthNum >= 0 && monthNum <= 12) {
			month = months[monthNum - 1];
		}
		returnContent = month + " " + day;
		logger.info(LoggerConstants.methodEndLevel());
		return returnContent;
	}// getMonthDayName()

	/**
	 * This method is used to get Month Day Year Name.
	 * 
	 * @param currYrMo
	 *            String
	 * @return returnContent String.
	 */
	public String getMonthDayYearName(String yrMoDay) {
		logger.info(LoggerConstants.methodStartLevel());
		DateFormatSymbols dateFormatSymbols = new DateFormatSymbols();
		String returnContent = null;

		String year = yrMoDay.substring(0, 4);
		String tempmonth = yrMoDay.substring(4, 6);
		String day = yrMoDay.substring(6, 8);

		String[] months = dateFormatSymbols.getMonths();
		String month = months[(new Integer(tempmonth).intValue() - 1)];

		returnContent = month + " " + day + " " + year;
		logger.info(LoggerConstants.methodEndLevel());
		return returnContent;
	}// getMonthDayYearName()

}// class
