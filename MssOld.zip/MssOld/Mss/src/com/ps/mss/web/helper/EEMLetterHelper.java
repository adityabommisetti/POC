/*
 * $Id: EEMLetterHelper.java,v 1.3 2016/08/21 23:16:44 dinesh Exp $
 */
package com.ps.mss.web.helper;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.model.EEMLetterReviewQcVO;
import com.ps.mss.db.EEMCodeCache;
//Implementing DynaCache for performance :start
import com.ps.mss.dynaCache.EEMDynaCache;
//Implementing DynaCache for performance :end
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.EMLetterReqDisplayVO;
import com.ps.mss.model.EMLetterReqSearchResultVO;
import com.ps.mss.model.EMLetterVarDataVO;
import com.ps.mss.web.forms.EEMLetterReqForm;
import com.ps.mss.web.forms.EEMLetterReviewQCForm;
import com.ps.text.DateFormatter;

public class EEMLetterHelper {
	private static Logger logger=LoggerFactory.getLogger(EEMLetterHelper.class);
	public static void setFormLists(EEMLetterReqForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		//Implementing DynaCache for performance :start
		//EEMCodeCache objCache = EEMCodeCache.getInstance();
		EEMCodeCache objCache = EEMDynaCache.getDynaCacheMap();
		
		//Implementing DynaCache for performance :end
		
		form.setLstSearchStatus(objCache.getLstTriggerStatus());
		form.setArrSearchTypes(objCache.getArrSourceTypes());
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void copySearchToDisplay(EMLetterReqSearchResultVO searchVO, EMLetterReqDisplayVO dispVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMCodeCache objCache = EEMCodeCache.getInstance();

		dispVO.setCustomerId(searchVO.getCustomerId());
		dispVO.setSourceType(searchVO.getSourceType());
		dispVO.setSourceTypeDesc(searchVO.getSourceTypeDesc());
		dispVO.setPrimaryId(searchVO.getPrimaryId());
		//Excellus Adding Member firstName and LastName in Letter Request CR -Start
				dispVO.setMbrFName(searchVO.getMbrFName());
				dispVO.setMbrLName(searchVO.getMbrLName());
				//Excellus Adding Member firstName and LastName in Letter Request CR -End
		dispVO.setEffDate(searchVO.getEffDate());
		dispVO.setCreateTime(searchVO.getCreateTime());
		dispVO.setTriggerType(searchVO.getTriggerType());
		dispVO.setTriggerTypeDesc(searchVO.getTriggerTypeDesc());
		dispVO.setTriggerCode(searchVO.getTriggerCode());
		dispVO.setTriggerCodeDesc(searchVO.getTriggerCodeDesc());
		dispVO.setTriggerStatus(searchVO.getTriggerStatus());
		dispVO.setTriggerStatusDesc(objCache.getListBoxDesc(dispVO.getTriggerStatus(),objCache.getLstTriggerStatus()));
		dispVO.setCreateUserId(searchVO.getCreateUserId());
		dispVO.setLastUpdtTime(searchVO.getLastUpdtTime());
		dispVO.setLastUpdtUserId(searchVO.getLastUpdtUserId());
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static List getVarDataList(EMLetterReqDisplayVO dispVO) {
		logger.info(LoggerConstants.methodStartLevel());
		String [] varDataId = dispVO.getVarDataId();
		String [] varDataType = dispVO.getVarDataType();
		String [] varDataLen = dispVO.getVarDataLen();
		String [] varDataDesc = dispVO.getVarDataDesc();
		String [] varDataText = dispVO.getVarDataText();
		
		ArrayList lst = null;
		
		if (varDataId != null) {
			
			lst = new ArrayList();
			EMLetterVarDataVO varData = null;
			for (int i = 0; i < varDataId.length; i++) {
				varData = new EMLetterVarDataVO();
				varData.setSeqNbr(i);
				varData.setVarId(varDataId[i]);
				varData.setFieldType(varDataType[i]);
				varData.setFieldLength(varDataLen[i]);
				varData.setDescription(varDataDesc[i]);
				varData.setFieldValue(varDataText[i]);
				lst.add(varData);
			}		
		}
		logger.info(LoggerConstants.methodEndLevel());
		return lst;
	}
	
	public static void saveEEMForm(SessionHelper sessionHelper, EEMLetterReqForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		sessionHelper.setAttribute("SaveEEMLetterReqForm",form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	public static EEMLetterReqForm getEEMForm(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (EEMLetterReqForm)sessionHelper.getAttribute("SaveEEMLetterReqForm");
	}
	
	public static void clearForm(EEMLetterReqForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		form.setSearchType("");
		form.setSearchId("");
		form.setSearchCreateDate("");
		form.setSearchStatus("");
		form.setSearchExpanded(false);
		form.setSelectedSearchRow(0);
		
		form.setListSearchResults(null);
		form.setDisplayLetterReq(new EMLetterReqDisplayVO());
		
		clearFormData(form);
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void clearFormData(EEMLetterReqForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		
		form.setLstLetterName(null);
		logger.info(LoggerConstants.methodEndLevel());
	}
	/*	 Begin: Added for Letter Review QC */
	public static void copyVOToForm(EEMLetterReviewQcVO ltrQcVO, EEMLetterReviewQCForm lrtQcform) {
		logger.info(LoggerConstants.methodStartLevel());
		lrtQcform.setSearchReqFromDate(DateFormatter.reFormat(ltrQcVO.getSearchReqFromDate(),DateFormatter.DB2_TIMESTAMP,DateFormatter.MM_DD_YYYY));
		lrtQcform.setSearchReqToDate(DateFormatter.reFormat(ltrQcVO.getSearchReqToDate(),DateFormatter.DB2_TIMESTAMP,DateFormatter.MM_DD_YYYY));
		lrtQcform.setSearchBatchId(ltrQcVO.getSearchBatchId());
		//IFOX - 430896 LTr QC CR : start
		lrtQcform.setSearchType(ltrQcVO.getSearchType());
		lrtQcform.setSearchId(ltrQcVO.getSearchId());
		//IFOX - 430896 LTr QC CR : end
		lrtQcform.setSearchLetterName(ltrQcVO.getSearchLetterName());
		lrtQcform.setLstBatchId(ltrQcVO.getListBatchIdResults());
		lrtQcform.setLstLetterNames(ltrQcVO.getLstLetterNames());
		logger.info(LoggerConstants.methodEndLevel());
	}
	/*	 Begin: Added for Letter Review QC */
}
