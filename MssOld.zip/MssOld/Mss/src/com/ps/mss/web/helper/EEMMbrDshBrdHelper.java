/*
 * Created on Sep 26, 2011
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ps.mss.web.helper;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EEMMbrDshBrdService;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.EEMDshBrdDrillVO;
import com.ps.mss.model.EEMMbrDshBrdVO;
import com.ps.mss.web.forms.EEMMbrDshBrdForm;
import com.ps.util.StringUtil;

/**
 * @author Raghu Gorur
 *
 */
public class EEMMbrDshBrdHelper {
	
	private static Properties prop;
	private static Logger logger=LoggerFactory.getLogger(EEMMbrDshBrdHelper.class);
	public static String getProperty(String sKey) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String sValue = null;
		try {
			if (prop == null) {
				prop = new Properties();
				prop.load(new FileInputStream("EEMProperties.properties"));
			}

			sValue = prop.getProperty(sKey);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return sValue;
	}
	
	public static void saveEEMForm(SessionHelper sessionHelper, EEMMbrDshBrdForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		sessionHelper.setAttribute("SaveEEMMbrDshBrdForm",form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	public static EEMMbrDshBrdForm getEEMForm(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (EEMMbrDshBrdForm)sessionHelper.getAttribute("SaveEEMMbrDshBrdForm");
	}
	public static void saveDrillDown(SessionHelper sessionHelper, List lstDrill) {
		logger.info(LoggerConstants.methodStartLevel());
		sessionHelper.getSession().setAttribute("MbrDshBrdDrillDown",lstDrill);
		logger.info(LoggerConstants.methodEndLevel());
	}
	public static List getDrillDown(SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		return (List)sessionHelper.getSession().getAttribute("MbrDshBrdDrillDown");
	}
	public static void setFormToVO(EEMMbrDshBrdForm eemDshBrdForm,
			EEMMbrDshBrdVO filterVO, SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try{	
			BeanUtils.copyProperties(filterVO, eemDshBrdForm);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void setVOToForm(EEMMbrDshBrdVO filterVO,
			EEMMbrDshBrdForm eemDshBrdForm, SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try{	
			BeanUtils.copyProperties(eemDshBrdForm, filterVO);
		
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void setDshBrdFormList(EEMMbrDshBrdForm eemDshBrdForm,
			SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		eemDshBrdForm.setCustomerId(sessionHelper.getMfId());
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void getDashBoardList(EEMMbrDshBrdForm eemDshBrdForm,
			SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMMbrDshBrdVO filterVO = new EEMMbrDshBrdVO();
		setFormToVO(eemDshBrdForm, filterVO, sessionHelper);
		
		EEMMbrDshBrdService service = new EEMMbrDshBrdService();
		eemDshBrdForm.setLstDashBoard(service.getDashBoardList(filterVO));
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void getWorkloadList(EEMMbrDshBrdForm eemDshBrdForm,
			SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMMbrDshBrdVO filterVO = new EEMMbrDshBrdVO();
		setFormToVO(eemDshBrdForm, filterVO, sessionHelper);
		
		EEMMbrDshBrdService service = new EEMMbrDshBrdService();
		eemDshBrdForm.setLstWorkload(service.getWorkloadList(filterVO));
		logger.info(LoggerConstants.methodEndLevel());
	}

	public static void getDrillDownList(EEMMbrDshBrdForm eemDshBrdForm,
			SessionHelper sessionHelper) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		List lstTemp = new ArrayList();
		EEMDshBrdDrillVO objVO = null;
		
		if (StringUtil.nonNullTrim(eemDshBrdForm.getUser()).equals("HCHENG")) {
			objVO = new EEMDshBrdDrillVO();
			objVO.setSupplId("005120017");
			objVO.setHicNbr("999000338D6");
			objVO.setLastName("TEQIILLA");
			objVO.setFirstName("MAGNOLIA");
			objVO.setEnrollStatus("EPEND");
			objVO.setEnrollReason("CMSREJECT");
			objVO.setApplDate("09/04/2011");
			objVO.setCreateDate("09/10/2011");
			objVO.setDueDate("10/01/2011");
			objVO.setCurrOper("HCHENG");
			objVO.setAssignTo("CHARLIE");
			lstTemp.add(objVO);
			
			objVO = new EEMDshBrdDrillVO();
			objVO.setSupplId("005120018");
			objVO.setHicNbr("999000281A");
			objVO.setLastName("TESTORREST");
			objVO.setFirstName("ERNEST");
			objVO.setEnrollStatus("EPEND");
			objVO.setEnrollReason("CMSREJECT");
			objVO.setApplDate("09/04/2011");
			objVO.setCreateDate("09/10/2011");
			objVO.setDueDate("10/03/2011");
			objVO.setCurrOper("HCHENG");
			objVO.setAssignTo("CHARLIE");
			lstTemp.add(objVO);
		} else if (StringUtil.nonNullTrim(eemDshBrdForm.getUser()).equals("RNENNE")) {
			objVO = new EEMDshBrdDrillVO();
			objVO.setSupplId("000100001");
			objVO.setHicNbr("999901850A");
			objVO.setLastName("TIOOY");
			objVO.setFirstName("JOHN");
			objVO.setEnrollStatus("EPEND");
			objVO.setEnrollReason("CMSREJECT");
			objVO.setApplDate("09/19/2011");
			objVO.setCreateDate("09/20/2011");
			objVO.setDueDate("10/10/2011");
			objVO.setCurrOper("RNENNE");
			objVO.setAssignTo("TRAM");
			lstTemp.add(objVO);

			objVO = new EEMDshBrdDrillVO();
			objVO.setSupplId("100056");
			objVO.setHicNbr("999901869A");
			objVO.setLastName("TESTLAST");
			objVO.setFirstName("FRANCISCA");
			objVO.setEnrollStatus("EPEND");
			objVO.setEnrollReason("CMSREJECT");
			objVO.setApplDate("09/25/2011");
			objVO.setCreateDate("10/13/2011");
			objVO.setDueDate("11/03/2011");
			objVO.setCurrOper("RNENNE");
			objVO.setAssignTo("TRAM");
			lstTemp.add(objVO);
		} else {
			objVO = new EEMDshBrdDrillVO();
			objVO.setSupplId("005120017");
			objVO.setHicNbr("999000338D6");
			objVO.setLastName("TEQIILLA");
			objVO.setFirstName("MAGNOLIA");
			objVO.setEnrollStatus("EPEND");
			objVO.setEnrollReason("CMSREJECT");
			objVO.setApplDate("09/04/2011");
			objVO.setCreateDate("09/10/2011");
			objVO.setDueDate("10/01/2011");
			objVO.setCurrOper("HCHENG");
			objVO.setAssignTo("CHARLIE");
			lstTemp.add(objVO);
			
			objVO = new EEMDshBrdDrillVO();
			objVO.setSupplId("005120018");
			objVO.setHicNbr("999000281A");
			objVO.setLastName("TESTORREST");
			objVO.setFirstName("ERNEST");
			objVO.setEnrollStatus("EPEND");
			objVO.setEnrollReason("CMSREJECT");
			objVO.setApplDate("09/04/2011");
			objVO.setCreateDate("09/10/2011");
			objVO.setDueDate("10/03/2011");
			objVO.setCurrOper("HCHENG");
			objVO.setAssignTo("CHARLIE");
			lstTemp.add(objVO);
			
			objVO = new EEMDshBrdDrillVO();
			objVO.setSupplId("000100001");
			objVO.setHicNbr("999901850A");
			objVO.setLastName("TIOOY");
			objVO.setFirstName("JOHN");
			objVO.setEnrollStatus("EPEND");
			objVO.setEnrollReason("CMSREJECT");
			objVO.setApplDate("09/19/2011");
			objVO.setCreateDate("09/20/2011");
			objVO.setDueDate("10/10/2011");
			objVO.setCurrOper("RNENNE");
			objVO.setAssignTo("TRAM");
			lstTemp.add(objVO);

			objVO = new EEMDshBrdDrillVO();
			objVO.setSupplId("100056");
			objVO.setHicNbr("999901869A");
			objVO.setLastName("TESTLAST");
			objVO.setFirstName("FRANCISCA");
			objVO.setEnrollStatus("EPEND");
			objVO.setEnrollReason("CMSREJECT");
			objVO.setApplDate("09/25/2011");
			objVO.setCreateDate("10/13/2011");
			objVO.setDueDate("11/03/2011");
			objVO.setCurrOper("RNENNE");
			objVO.setAssignTo("TRAM");
			lstTemp.add(objVO);
		}

		eemDshBrdForm.setLstDshBrdDrill(lstTemp);
		
		// Save it to session
		saveDrillDown(sessionHelper, lstTemp);
		logger.info(LoggerConstants.methodEndLevel());
	}
}
