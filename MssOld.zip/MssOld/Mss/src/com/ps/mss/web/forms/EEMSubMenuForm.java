/*
 * $Id: EEMSubMenuForm.java,v 1.1 2014/06/26 07:55:48 praveen Exp $
 */
package com.ps.mss.web.forms;

public class EEMSubMenuForm extends EEMForm {

	private String selectedSubMenuTab;
	
	public String getSelectedSubMenuTab() {
		return selectedSubMenuTab;
	}
	public void setSelectedSubMenuTab(String selectedSubMenuTab) {
		this.selectedSubMenuTab = selectedSubMenuTab;
	}
}
