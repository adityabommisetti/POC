/*
 * Created on Apr 16, 2008
 * $Id: PdeTroopAction.java,v 1.1 2014/06/26 07:56:40 praveen Exp $
 *
 */
package com.ps.mss.web.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.model.PdeContext;
import com.ps.mss.web.forms.PdeTroopForm;
import com.ps.mss.web.helper.DispatchActionHelper;
import com.ps.mss.web.helper.PdeTroopDispatchActionHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.util.DateUtil;
import com.ps.util.StringUtil;

/**
 * @author deepak
 *
 */
public class PdeTroopAction extends org.apache.struts.actions.DispatchAction{
	private static Logger logger=LoggerFactory.getLogger(PdeTroopAction.class);
    /**
	 * This method of dispach Action is call to get troopDashBoard
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward troopDashBoard(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sesHelper = new SessionHelper(request);
		PdeTroopForm pdeTroopForm = (PdeTroopForm) form;
		String targetResult = "";
		PdeTroopDispatchActionHelper sessionHelper =  new PdeTroopDispatchActionHelper();
		sessionHelper.getTroopDashboard(request,pdeTroopForm);
		// checking response target
		if(request.getParameter("print") !=  null)
			targetResult = "printTroopDashBoard";
		else {
			targetResult = "troopDashBoard";
			DispatchActionHelper.setTabAndFormName(request, Constants.TROOP_MENU, "PdeTroopForm");
		}		
		pdeTroopForm.init(request);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(targetResult);
	}
	
	/**
	 * This method of dispach Action is call to get troopDetail
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward troopDetail(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sesHelper = new SessionHelper(request);
		PdeTroopForm pdeTroopForm = (PdeTroopForm) form;
		String targetResult = "";
		PdeTroopDispatchActionHelper sessionHelper =  new PdeTroopDispatchActionHelper();
//		Map detailMap = null;
//		String move = "current";
		if(request.getParameter("print") !=  null){
			/*String uiContextRange = StringUtil.nonNullTrim(request.getParameter("uiContextRange"));
			request.setAttribute("uiContextRange",uiContextRange);
			if(Constants.CONSTANTS_ALL.equals(uiContextRange)){
				 detailMap = (Map) sesHelper.getAttribute(Constants.SESSION_TROOP_DETAIL_MAP);
				 if(detailMap!=null){
				 	CodeCacheMasterService codeCache=new CodeCacheMasterService();
					Integer maxRecordCount=codeCache.getMaxRecordCount();
 					detailMap.put(Constants.SESSION_MAX_RECORD_COUNT,maxRecordCount);
//					move = "first";
				 }
			}*/
			targetResult = "printTroopDetail";
		}else {
			targetResult = "troopDetail";
			DispatchActionHelper.setTabAndFormName(request, Constants.TROOP_MENU, "PdeTroopForm");
		}
		sessionHelper.getTroopDetail(request,pdeTroopForm);
//		if(detailMap!=null)
//			detailMap.put(Constants.SESSION_MAX_RECORD_COUNT,new Integer(10));
		// checking response target
		
		
		
		pdeTroopForm.init(request);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(targetResult);
	}
	
	/**
	 * This method of dispach Action is call to get pdeDashBoard
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward pdeDashBoard(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sesHelper = new SessionHelper(request);
		PdeTroopForm pdeTroopForm = (PdeTroopForm) form;
		String targetResult = "";
		PdeTroopDispatchActionHelper sessionHelper =  new PdeTroopDispatchActionHelper();
		sessionHelper.getPdeDashboard(request,pdeTroopForm);
		// checking response target
		if(request.getParameter("print") !=  null)
			targetResult = "printPdeDashBoard";
		else {
			targetResult = "pdeDashBoard";
			DispatchActionHelper.setTabAndFormName(request, Constants.PDE_MENU, "PdeTroopForm");
		}
		
		pdeTroopForm.init(request);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(targetResult);
	}
	
	/**
	 * This method of dispach Action is call to get Pde Event Detail
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward pdeEventDetail(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sesHelper = new SessionHelper(request);
		PdeTroopForm pdeTroopForm = (PdeTroopForm) form;
		
		//  when we are comming from PDE Dashboard, we only have 'mm/yyyy' date, and PDE Event Detail needs 'mm/dd/yyyy' format.
		String fromDate = StringUtil.trimToNull(pdeTroopForm.getFromDate());
		String toDate = StringUtil.trimToNull(pdeTroopForm.getToDate());
		if(fromDate != null && fromDate.length() == 7){
			fromDate = DateUtil.getFirstOrLastDayOfMonth(fromDate, true);
			pdeTroopForm.setFromDate(fromDate);
		}
				
		if(toDate != null && toDate.length() == 7) {
			toDate = DateUtil.getFirstOrLastDayOfMonth(toDate, false);
			pdeTroopForm.setToDate(toDate);
		}
		
		
		String targetResult = "";
		PdeTroopDispatchActionHelper sessionHelper =  new PdeTroopDispatchActionHelper();
//		Map detailMap = null;
//		String move = "current";
		if(request.getParameter("print") !=  null){
			/*String uiContextRange = StringUtil.nonNullTrim(request.getParameter("uiContextRange"));
			request.setAttribute("uiContextRange",uiContextRange);
			if(Constants.CONSTANTS_ALL.equals(uiContextRange)){
				 detailMap = (Map) sesHelper.getAttribute(Constants.SESSION_PDE_EVENT_DETAIL_MAP);
				 if(detailMap!=null){
				 	CodeCacheMasterService codeCache=new CodeCacheMasterService();
					Integer maxRecordCount=codeCache.getMaxRecordCount();
					detailMap.put(Constants.SESSION_MAX_RECORD_COUNT,maxRecordCount);
//					move = "first";
				 }
			}*/
			targetResult = "printPdeEventDetail";
		}else{
			targetResult = "pdeEventDetail";
			DispatchActionHelper.setTabAndFormName(request, Constants.PDE_MENU, "PdeTroopForm");
		}
		
		
		sessionHelper.getPdeEventDetail(request,pdeTroopForm);
		/*if(detailMap!=null)
			detailMap.put(Constants.SESSION_MAX_RECORD_COUNT,new Integer(10));*/
		
		pdeTroopForm.init(request);
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(targetResult);
	}

	/**
	 * Action for PDE Error dashboard
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward pdeErrDB(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		PdeTroopForm pdeTroopForm = (PdeTroopForm) form;
        PdeContext context = (PdeContext)request.getSession().getAttribute(Constants.SESSION_PDE_CONTEXT);
        if (context == null) {
        	context = new PdeContext();
        	request.getSession().setAttribute(Constants.SESSION_PDE_CONTEXT, context);
        }
		PdeTroopDispatchActionHelper sessionHelper =  new PdeTroopDispatchActionHelper();
		sessionHelper.getPdeErrDashboard(request, context, pdeTroopForm);
		
		pdeTroopForm.init(request);
		String targetResult = Constants.PDE_ERR_DASHBOARD;
		if(request.getParameter("print") !=  null)
			targetResult = "print".concat(targetResult);
		else
			DispatchActionHelper.setTabAndFormName(request, Constants.PDE_MENU, "PdeTroopForm");
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(targetResult);
	}
	/**
	 * Display a page of error codes.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward pdeErrCodes(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		PdeTroopForm pdeTroopForm = (PdeTroopForm) form;
        PdeContext context = (PdeContext)request.getSession().getAttribute(Constants.SESSION_PDE_CONTEXT);
        if (context == null) {
        	context = new PdeContext();
        	request.getSession().setAttribute(Constants.SESSION_PDE_CONTEXT, context);
        }
		PdeTroopDispatchActionHelper sessionHelper =  new PdeTroopDispatchActionHelper();
		sessionHelper.pdeErrCodes(request, context, pdeTroopForm);
		
		pdeTroopForm.init(request);
		String targetResult = Constants.PDE_ERR_CODES;
		if(request.getParameter("print") !=  null)
			targetResult = "print".concat(targetResult);
		else
			DispatchActionHelper.setTabAndFormName(request, Constants.PDE_MENU, "PdeTroopForm");
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(targetResult);
	}
	
	public ActionForward pdeErrDetail(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		PdeTroopForm pdeTroopForm = (PdeTroopForm) form;
        PdeContext context = (PdeContext)request.getSession().getAttribute(Constants.SESSION_PDE_CONTEXT);

        //validate form
        if("search".equals(pdeTroopForm.getActionType())) {
			String temp = StringUtil.trimToNull(pdeTroopForm.getPdeStatus());
			if (temp != null && !"ALL".equals(temp) && !"INF".equals(temp) && !"REJ".equals(temp) && !"RES".equals(temp)) 
				throw new ApplicationException("Invalid Record Id " + temp);
			temp = pdeTroopForm.getErrorCode();
			if (temp != null && !StringUtil.isAlphaNumeric(temp)) 
				throw new ApplicationException("Invalid Error Code " + temp);
	
			//  when we are comming from PDE Dashboard, we only have 'mm/yyyy' date, and PDE Event Detail needs 'mm/dd/yyyy' format.
			String fromDate = StringUtil.trimToNull(pdeTroopForm.getFromDate());
			String toDate = StringUtil.trimToNull(pdeTroopForm.getToDate());
			if(fromDate != null && fromDate.length() == 7){
				fromDate = DateUtil.getFirstOrLastDayOfMonth(fromDate, true);
				pdeTroopForm.setFromDate(fromDate);
			}
					
			if(toDate != null && toDate.length() == 7) {
				toDate = DateUtil.getFirstOrLastDayOfMonth(toDate, false);
				pdeTroopForm.setToDate(toDate);
			}
        }
        
		PdeTroopDispatchActionHelper sessionHelper =  new PdeTroopDispatchActionHelper();
		sessionHelper.getPdeErrDetail(request, context, pdeTroopForm);	
		
		pdeTroopForm.init(request);
		String targetResult = Constants.PDE_ERR_DETAIL;
		if(request.getParameter("print") !=  null)
			targetResult = "print".concat(targetResult);
		else
			DispatchActionHelper.setTabAndFormName(request, Constants.PDE_MENU, "PdeTroopForm");
		logger.info(LoggerConstants.methodEndLevel());
		return mapping.findForward(targetResult);
	}
}
