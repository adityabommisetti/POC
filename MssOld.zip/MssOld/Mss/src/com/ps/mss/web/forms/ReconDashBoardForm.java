package com.ps.mss.web.forms;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.WorkAgedSummaryVO;
import com.ps.mss.model.PaymentSummaryVO;
import com.ps.mss.model.PaymentDashBoardVO;

/**
 * Form bean for a Struts application.
 * @version 	1.0
 * @author
 */
public class ReconDashBoardForm extends BaseForm {
	private PaymentDashBoardVO [] paymentDashBoardVO = null;
	private PaymentSummaryVO [] partCDetail = null;
	private PaymentSummaryVO [] partDDetail = null;
	private WorkAgedSummaryVO partCFinanceSummary = null;
	private PaymentSummaryVO partDFinanceSummary = null;
	
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		paymentDashBoardVO = null;
		partCDetail = null;
		partDDetail = null;
		partCFinanceSummary = null;
		partDFinanceSummary = null;
		
    }

    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {

        ActionErrors errors = new ActionErrors();
        // Validate the fields in your form, adding
        // adding each error to this.errors as found, e.g.

        // if ((field == null) || (field.length() == 0)) {
        //   errors.add("field", new org.apache.struts.action.ActionError("error.field.required"));
        // }
        return errors;

    }
	
	
	
	
	/**
	 * @return Returns the paymentDashBoardVO.
	 */
	public PaymentDashBoardVO[] getPaymentDashBoardVO() {
		return paymentDashBoardVO;
	}
	/**
	 * @param paymentDashBoardVO The paymentDashBoardVO to set.
	 */
	public void setPaymentDashBoardVO(PaymentDashBoardVO[] paymentDashBoardVO) {
		this.paymentDashBoardVO = paymentDashBoardVO;
	}
	/**
	 * @return Returns the partCDetail.
	 */
	public PaymentSummaryVO[] getPartCDetail() {
		return partCDetail;
	}
	/**
	 * @param partCDetail The partCDetail to set.
	 */
	public void setPartCDetail(PaymentSummaryVO[] partCDetail) {
		this.partCDetail = partCDetail;
	}
	/**
	 * @return Returns the partCFinanceSummaryVO.
	 */
	public WorkAgedSummaryVO getPartCFinanceSummary() {
		return partCFinanceSummary;
	}
	/**
	 * @param partCFinanceSummaryVO The partCFinanceSummaryVO to set.
	 */
	public void setPartCFinanceSummary(WorkAgedSummaryVO partCFinanceSummary) {
		this.partCFinanceSummary = partCFinanceSummary;
	}
	/**
	 * @return Returns the partDDetail.
	 */
	public PaymentSummaryVO[] getPartDDetail() {
		return partDDetail;
	}
	/**
	 * @param partDDetail The partDDetail to set.
	 */
	public void setPartDDetail(PaymentSummaryVO[] partDDetail) {
		this.partDDetail = partDDetail;
	}
	/**
	 * @return Returns the partDFinanceSummary.
	 */
	public PaymentSummaryVO getPartDFinanceSummary() {
		return partDFinanceSummary;
	}
	/**
	 * @param partDFinanceSummary The partDFinanceSummary to set.
	 */
	public void setPartDFinanceSummary(PaymentSummaryVO partDFinanceSummary) {
		this.partDFinanceSummary = partDFinanceSummary;
	}
	/**
	 * @param request
	 * @throws ApplicationException
	 */
	public void init(HttpServletRequest request) throws ApplicationException {
		super.init(request);
		
	}
	
}
