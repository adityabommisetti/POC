/*
 * $Id: BaseForm.java,v 1.1 2014/06/26 07:55:45 praveen Exp $
 */
package com.ps.mss.web.forms;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.model.BeneficiaryPymtDetailVOList;
import com.ps.mss.model.DiscrepancyDashBoardVO;
import com.ps.mss.model.DiscrepancySummaryVOList;
import com.ps.mss.model.DiseaseGroupVOList;
import com.ps.mss.model.PaymentDashBoardVO;
import com.ps.mss.model.PaymentSummaryVOList;
import com.ps.mss.model.PymtEffDateDetailVO;
import com.ps.mss.model.ReconciliationListVO;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.util.NameValuePair;

/**
 * Form bean for a Struts application.
 * @version 	1.0
 * @author
 */
public class BaseForm extends ActionForm {
	
	private String actionType;
	private String planName ;
	private String fromDate ;
	private String toDate;
	private String dateType;
	private String searchType;
	private NameValuePair [] planNameList;
	private String partName; //= Constants.BOTH_PARTS;
	private String discrepancyType;
	private String headerInfo;
	private String discCd;
	private String hicNbr;
	private String pageType="";
	private String pbpId;
	private boolean summarPage;
	private PaymentDashBoardVO [] paymentDashBoardVO = null;
	private PaymentSummaryVOList paymentSummaryVOList = null;
	private DiscrepancyDashBoardVO [] discrepancyDashBoardVO = null;
	private DiscrepancySummaryVOList discrepancySummaryVOList= null ;
	private BeneficiaryPymtDetailVOList benePymtDetailVOList = null ; //This list for payment Detail on beneficiary page
	private String partA;
	private String partB;
	private String partC;
	private String partD;
	private String partCPrem;// Change for Part C UI
	private String demoGrpInfo ;
	private String menuName; //This field is use to track the menu (example plan /beneficary ) to know then page.
	private DiseaseGroupVOList diseaseGroupVOList;
	private ReconciliationListVO reconciliationListVO; 
	private String activeService;
	private String memberId;
	private List hicNumberList;
	private Boolean notifyOtherHics; //used in beneficiary payment dashboard, if there's other hics
	
	/**
	 * @return Returns the notifyOtherHics.
	 */
	public Boolean getNotifyOtherHics() {
		return notifyOtherHics;
	}
	/**
	 * @param notifyOtherHics The notifyOtherHics to set.
	 */
	public void setNotifyOtherHics(Boolean notifyOtherHics) {
		this.notifyOtherHics = notifyOtherHics;
	}
    /**
     * @return Returns the reconciliationListVO.
     */
    public ReconciliationListVO getReconciliationListVO() {
        return reconciliationListVO;
    }
    /**
     * @param reconciliationListVO The reconciliationListVO to set.
     */
    public void setReconciliationListVO(
            ReconciliationListVO reconciliationListVO) {
        this.reconciliationListVO = reconciliationListVO;
    }
	/**
	 * @return Returns the diseaseGroupVOList.
	 */
	public DiseaseGroupVOList getDiseaseGroupVOList() {
		return diseaseGroupVOList;
	}
	/**
	 * @param diseaseGroupVOList The diseaseGroupVOList to set.
	 */
	public void setDiseaseGroupVOList(DiseaseGroupVOList diseaseGroupVOList) {
		this.diseaseGroupVOList = diseaseGroupVOList;
	}
	private PymtEffDateDetailVO pymtEffDateDetailVO = null ; //This list for payment Detail pop up on effective date on beneficiary page
	
	/**
	 * @return Returns the pymtEffDateDetailVO.
	 */
	public PymtEffDateDetailVO getPymtEffDateDetailVO() {
		return pymtEffDateDetailVO;
	}
	/**
	 * @param pymtEffDateDetailVO The pymtEffDateDetailVO to set.
	 */
	public void setPymtEffDateDetailVO(PymtEffDateDetailVO pymtEffDateDetailVO) {
		this.pymtEffDateDetailVO = pymtEffDateDetailVO;
	}
/**
	 * @return Returns the demoGrpInfo.
	 */
	public String getDemoGrpInfo() {
		return demoGrpInfo;
	}
	/**
	 * @param demoGrpInfo The demoGrpInfo to set.
	 */
	public void setDemoGrpInfo(String demoGrpInfo) {
		this.demoGrpInfo = demoGrpInfo;
	}
	/**
	 * @return Returns the hicNbr.
	 */
	public String getHicNbr() {
		return hicNbr;
	}
	/**
	 * @param hicNbr The hicNbr to set.
	 */
	public void setHicNbr(String hicNbr) {
		this.hicNbr = hicNbr;
	}
	/**
	 * @return Returns the benePymtDetailVOList.
	 */
	public BeneficiaryPymtDetailVOList getBenePymtDetailVOList() {
		return benePymtDetailVOList;
	}
	/**
	 * @param benePymtDetailVOList The benePymtDetailVOList to set.
	 */
	public void setBenePymtDetailVOList(
			BeneficiaryPymtDetailVOList benePymtDetailVOList) {
		this.benePymtDetailVOList = benePymtDetailVOList;
	}
	/**
	 * @return Returns the menuName.
	 */
	public String getMenuName() {
		return menuName;
	}
	/**
	 * @param menuName The menuName to set.
	 */
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	/**
	 * @return Returns the discrepancyDashBoardVO.
	 */
	public DiscrepancyDashBoardVO[] getDiscrepancyDashBoardVO() {
		return discrepancyDashBoardVO;
	}
	/**
	 * @param discrepancyDashBoardVO The discrepancyDashBoardVO to set.
	 */
	public void setDiscrepancyDashBoardVO(
			DiscrepancyDashBoardVO[] discrepancyDashBoardVO) {
		this.discrepancyDashBoardVO = discrepancyDashBoardVO;
	}
	/**
	 * @return Returns the discrepancySummaryVOList.
	 */
	public DiscrepancySummaryVOList getDiscrepancySummaryVOList() {
		return discrepancySummaryVOList;
	}
	/**
	 * @param discrepancySummaryVOList The discrepancySummaryVOList to set.
	 */
	public void setDiscrepancySummaryVOList(
			DiscrepancySummaryVOList discrepancySummaryVOList) {
		this.discrepancySummaryVOList = discrepancySummaryVOList;
	}
	/**
	 * @return Returns the paymentDashBoardVO.
	 */
	public PaymentDashBoardVO[] getPaymentDashBoardVO() {
		return paymentDashBoardVO;
	}
	/**
	 * @param paymentDashBoardVO The paymentDashBoardVO to set.
	 */
	public void setPaymentDashBoardVO(PaymentDashBoardVO[] paymentDashBoardVO) {
		this.paymentDashBoardVO = paymentDashBoardVO;
	}
	/**
	 * @return Returns the paymentSummaryVOList.
	 */
	public PaymentSummaryVOList getPaymentSummaryVOList() {
		return paymentSummaryVOList;
	}
	/**
	 * @param paymentSummaryVOList The paymentSummaryVOList to set.
	 */
	public void setPaymentSummaryVOList(
			PaymentSummaryVOList paymentSummaryVOList) {
		this.paymentSummaryVOList = paymentSummaryVOList;
	}
		
	/**
	 * @return Returns the summarPage.
	 */
	public boolean isSummarPage() {
		return summarPage;
	}
	/**
	 * @param summarPage The summarPage to set.
	 */
	public void setSummarPage(boolean summarPage) {
		this.summarPage = summarPage;
	}
	/**
	 * @return Returns the partA.
	 */
	public String getPartA() {
		return partA;
	}
	/**
	 * @param partA The partA to set.
	 */
	public void setPartA(String partA) {
		this.partA = partA;
	}
	/**
	 * @return Returns the partB.
	 */
	public String getPartB() {
		return partB;
	}
	/**
	 * @param partB The partB to set.
	 */
	public void setPartB(String partB) {
		this.partB = partB;
	}
	/**
	 * @return Returns the partC.
	 */
	public String getPartC() {
		return partC;
	}
	/**
	 * @param partC The partC to set.
	 */
	public void setPartC(String partC) {
		this.partC = partC;
	}
	/**
	 * @return Returns the partD.
	 */
	public String getPartD() {
		return partD;
	}
	/**
	 * @param partD The partD to set.
	 */
	public void setPartD(String partD) {
		this.partD = partD;
	}
	// Change for Part C UI - Start
		/**
		 * @return Returns the partCPrem.
		 */
		public String getPartCPrem() {
			return partCPrem;
		}
		/**
		 * @param partD The partD to set.
		 */
		public void setPartCPrem(String partCPrem) {
			this.partCPrem = partCPrem;
		}
		// Change for Part C UI - End
		
	/**
	 * @return Returns the paymentDashBoardVO.
	 */
	/*public PaymentDashBoardVO[] getPaymentDashBoardVO() {
		return paymentDashBoardVO;
	}
	*//**
	 * @param paymentDashBoardVO The paymentDashBoardVO to set.
	 *//*
	public void setPaymentDashBoardVO(PaymentDashBoardVO[] paymentDashBoardVO) {
		this.paymentDashBoardVO = paymentDashBoardVO;
	}*/
	

	/**
	 * @return Returns the paymentSummaryVOList.
	 */
	/*public PaymentSummaryVOList getPaymentSummaryVOList() {
		return paymentSummaryVOList;
	}
	*//**
	 * @param paymentSummaryVOList The paymentSummaryVOList to set.
	 *//*
	public void setPaymentSummaryVOList(
			PaymentSummaryVOList paymentSummaryVOList) {
		this.paymentSummaryVOList = paymentSummaryVOList;
	}*/
	/**
	 * @return Returns the discrepancyDashBoardVO.
	 */
	/*public DiscrepancyDashBoardVO[] getDiscrepancyDashBoardVO() {
		return discrepancyDashBoardVO;
	}
	*//**
	 * @param discrepancyDashBoardVO The discrepancyDashBoardVO to set.
	 *//*
	public void setDiscrepancyDashBoardVO(
			DiscrepancyDashBoardVO[] discrepancyDashBoardVO) {
		this.discrepancyDashBoardVO = discrepancyDashBoardVO;
	}*/
	/**
	 * @return Returns the discrepancySummaryVOList.
	 */
	/*public DiscrepancySummaryVOList getDiscrepancySummaryVOList() {
		return discrepancySummaryVOList;
	}
	*//**
	 * @param discrepancySummaryVOList The discrepancySummaryVOList to set.
	 *//*
	public void setDiscrepancySummaryVOList(
			DiscrepancySummaryVOList discrepancySummaryVOList) {
		this.discrepancySummaryVOList = discrepancySummaryVOList;
	}*/
	
	
	/**
	 * @return Returns the headerInfo.
	 */
	public String getHeaderInfo() {
		return headerInfo;
	}
	/**
	 * @param headerInfo The headerInfo to set.
	 */
	public void setHeaderInfo(String headerInfo) {
		this.headerInfo = headerInfo;
	}
	
	
	/**
	 * @return Returns the discrepancyType.
	 */
	public String getDiscrepancyType() {
		return discrepancyType;
	}
	/**
	 * @param discrepancyType The discrepancyType to set.
	 */
	public void setDiscrepancyType(String discrepancyType) {
		this.discrepancyType = discrepancyType;
	}
	
	/**
	 * @return Returns the discCd.
	 */
	public String getDiscCd() {
		return discCd;
	}
	/**
	 * @param discCd The discCd to set.
	 */
	public void setDiscCd(String discCd) {
		this.discCd = discCd;
	}
	/**
	 * @return Returns the partName.
	 */
	public String getPartName() {
		return partName;
	}
	/**
	 * @param partName The partName to set.
	 */
	public void setPartName(String partName) {
		this.partName = partName;
	}
	/**
	 * @return Returns the actionType.
	 */
	public String getActionType() {
		return actionType;
	}
	/**
	 * @param actionType The actionType to set.
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	/**
	 * @return Returns the dateType.
	 */
	public String getDateType() {
		return dateType;
	}
	/**
	 * @param dateType The dateType to set.
	 */
	public void setDateType(String dateType) {
		this.dateType = dateType;
	}
	/**
	 * @return Returns the fromDate.
	 */
	public String getFromDate() {
		return fromDate;
	}
	/**
	 * @param fromDate The fromDate to set.
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	/**
	 * @return Returns the planName.
	 */
	public String getPlanName() {
		return planName;
	}
	/**
	 * @param planName The planName to set.
	 */
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	
	/**
	 * @return Returns the searchType.
	 */
	public String getSearchType() {
		return searchType;
	}
	/**
	 * @param searchType The searchType to set.
	 */
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	/**
	 * @return Returns the toDate.
	 */
	public String getToDate() {
		return toDate;
	}
	/**
	 * @param toDate The toDate to set.
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	
	/**
	 * @return Returns the planNameList.
	 */
	public NameValuePair[] getPlanNameList() {
		return planNameList;
	}
	/**
	 * @param planNameList The planNameList to set.
	 */
	public void setPlanNameList(NameValuePair[] planNameList) {
		this.planNameList = planNameList;
	}
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		actionType = null;
		planName = null;
		fromDate = null;
		toDate = null;
		dateType = "E";
		searchType = null;
		planNameList = null;
		partName = null;
		paymentDashBoardVO = null;
		paymentSummaryVOList = null;
		discrepancyDashBoardVO = null;
		discrepancySummaryVOList= null ;
		partA="";
		partB="";
		partC="";
		partD="";
		partCPrem="";// Change for Part C UI
		demoGrpInfo = "";
		menuName = null;
		discrepancyType = "";
		discCd = "";
		memberId = null;
		hicNumberList = null;
	}

    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {

        ActionErrors errors = new ActionErrors();
          return errors;

    }
	/**
	 * @param request
	 * @throws ApplicationException
	 */
    public void init(HttpServletRequest request) throws ApplicationException {
    	SessionHelper sessionHelper = new SessionHelper(request);
    	
    	activeService = sessionHelper.getServicesToAccess();
    	if(Constants.BOTH_PARTS.equals(partName))
    		partName = activeService;

    	setPlanNameList(sessionHelper.getPlanIdArray());
    }
	/**
	 * @return Returns the pageType.
	 */
	public String getPageType() {
		return pageType;
	}
	/**
	 * @param pageType The pageType to set.
	 */
	public void setPageType(String pageType) {
		this.pageType = pageType;
	}
	/**
	 * @return Returns the pbpId.
	 */
	public String getPbpId() {
		return pbpId;
	}
	/**
	 * @param pbpId The pbpId to set.
	 */
	public void setPbpId(String pbpId) {
		this.pbpId = pbpId;
	}
	public String getActiveService() {
		return activeService;
	}
	public void setActiveService(String activeService) {
		this.activeService = activeService;
	}
	/**
	 * @return Returns the hicNumberList.
	 */
	public List getHicNumberList() {
		return hicNumberList;
	}
	/**
	 * @param hicNumberList The hicNumberList to set.
	 */
	public void setHicNumberList(List hicNumberList) {
		this.hicNumberList = hicNumberList;
	}
	/**
	 * @return Returns the memberId.
	 */
	public String getMemberId() {
		return memberId;
	}
	/**
	 * @param memberId The memberId to set.
	 */
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
}
