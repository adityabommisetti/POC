/*
 * Created on Aug 21, 2007
 * $Id: DiscrepancyFacadeManager.java,v 1.1 2014/06/26 07:56:58 praveen Exp $
 *
 */
package com.ps.mss.web.ajax;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.DiscrepancyService;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.manager.DiscrepancyManager;
import com.ps.mss.manager.MasterManager;
import com.ps.mss.manager.WorkQueueManager;
import com.ps.mss.model.DiscrepancyDashBoardVO;
import com.ps.mss.model.DiscrepancyDetailVO;
import com.ps.mss.model.DiscrepancyDetailVOList;
import com.ps.mss.model.DiscrepancyListVO;
import com.ps.mss.model.FilterVO;
import com.ps.mss.web.forms.GenericDisplayPageForm;
import com.ps.mss.web.helper.AjaxHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.util.NameValuePair;
/**
 * @author deepak
 *
 * DiscrepancyManager class intrect with UI layer.UI layer call DiscrepancyManager class method's through javaScript
 * and respose is send back to UI layer.
 */
public class DiscrepancyFacadeManager {
	private static Logger logger=LoggerFactory.getLogger(DiscrepancyFacadeManager.class);
	/**
	 * This method check that whether export request valid or not base on total no of records(Base of search criteria).
	 * @author hemant 
	 * @param menuName
	 * @param pageType
	 * @return "TRUE" or Max valid Number of records to show
	 * @throws ApplicationException
	 */
	public String isExportDiscDetailRequestValid(String menuName, String pageType)throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		AjaxHelper.validateUser();
		FilterVO filterVO = null;
		Map discrpVOMap = null;
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		
		if(Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(menuName)) { // for beneficiary disc detail 
			if(Constants.READ_ONLY.equals(pageType)) {//when request is from show discrepancy (which is read only screen)
				filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_FILTERVO);
				
				//	filterVO.setPartName(Constants.BOTH_PARTS);
				filterVO.setDiscrpStatus("NotClosed"); // Because we are considering "NotClosed" discrepancy only
				discrpVOMap = (Map) sessionHelper.getAttribute(Constants.SESSION_READ_ONLY_DISCRP_DETAIL_MAP);
			}else{
				filterVO = (FilterVO) sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DETAIL_FILTERVO);
				discrpVOMap = (Map) sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DISCRP_DETAIL_MAP);
			}
		}else {
			filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_FILTERVO);
			discrpVOMap = (Map)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_MAP);
		}
		
		if(Constants.BOTH_PARTS.equals(filterVO.getPartName()))
			filterVO.setPartName(sessionHelper.getServicesToAccess());
		
		Map planmap = sessionHelper.getPlanForParts(); //IFOX-00431034 :: All-Plans in Discrepancy Drop down
		
		logger.info(LoggerConstants.methodEndLevel());
		return DiscrepancyManager.isExportDiscDetailRequestValid(AjaxHelper.getActiveDataBaseName(),filterVO,discrpVOMap,planmap);	//IFOX-00431034 :: All-Plans in Discrepancy Drop down
	}
	
	/**
	 * The <code>getDiscrepancyList</code> returns list of all discrepancies based on search criteria
	 * @param move
	 * @param menuName
	 * @param partName
	 * @param pageType
	 * @return
	 * @throws Exception
	 */
	public DiscrepancyDetailVOList getDiscrepancyList(String move, String menuName, String partName, String pageType ) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		AjaxHelper.validateUser();
	    
	    FilterVO filterVO = null;
		Map discrpVOMap = null;
		
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		//Recon-Work Queue Changes : start
		//Getting list from session
		List totalList = (List) sessionHelper.getAttribute("totalWorkQueuLst");
		//Recon-Work Queue Changes : end
		if(Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(menuName)) { // for beneficiary disc details
			if(Constants.READ_ONLY.equals(pageType)){
				filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_FILTERVO);
				discrpVOMap = (Map) sessionHelper.getAttribute(Constants.SESSION_READ_ONLY_DISCRP_DETAIL_MAP);
			} else {
				filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DETAIL_FILTERVO);
				discrpVOMap = (Map) sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DISCRP_DETAIL_MAP);
			}
		}
		//Recon-Work Queue Changes : start
		else if(Constants.WORK_QUEUE_MENU.equals(menuName)) { 
			filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_WORK_QUEUE_FILTERVO);
			//System.out.println("filterO in facade--"+filterVO);
			discrpVOMap = (Map) sessionHelper.getAttribute(Constants.SESSION_WORK_QUEUE_MAP);
		}
		//Recon-Work Queue Changes : end
		else {
			filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_FILTERVO);
			discrpVOMap = (Map) sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_MAP);
		}
		Map discrpMap = null;
		// In case of previous we are generating key from PAGE_HIST and using these key we create discrepancyDetialVo and set it into discrpVOMap
		// so that we can find previous discrepancyList .
		if("previous".equals(move)){
			if(Constants.PARTC.equals(partName)) 
				discrpMap = (Map) discrpVOMap.get(Constants.PARTC_DISCRP_DETAIL_MAP);
			else if(Constants.PARTD.equals(partName)) 
				discrpMap = (Map) discrpVOMap.get(Constants.PARTD_DISCRP_DETAIL_MAP);
			// Work Queue Changes : start
			if(menuName.equals("workqueue"))
			{
				discrpMap = (Map) discrpVOMap.get(Constants.PARTC_DISCRP_DETAIL_MAP);
				discrpMap = (Map) discrpVOMap.get(Constants.PARTD_DISCRP_DETAIL_MAP);
			}
			DiscrepancyListVO discrepancyListVO ;
			if(!menuName.equals("workqueue")){
			 discrepancyListVO = getPrevDiscrpDetailVO(discrpMap);
			 discrpMap.put(Constants.FIRST_DETAIL_VO , discrepancyListVO);
			}
			// Work Queue Changes : end
		
		
		}
		Map planMap = getPlanForParts(); 
		String tempPartName = filterVO.getPartName();
		filterVO.setPartName(partName);
		boolean hasWriteOffService = sessionHelper.hasWriteOffPermission();
		//Recon-Work Queue Changes : start
		DiscrepancyDetailVOList	discrepancyDetailVOList = null;
		//Work Queue Changes : start
		if(menuName.equals("workqueue")){
		discrepancyDetailVOList =  WorkQueueManager.getDiscrepancyList(0,totalList,filterVO, discrpVOMap, move, AjaxHelper.getActiveDataBaseName(),planMap,filterVO.getSearchType(),menuName, hasWriteOffService);	
		if(discrepancyDetailVOList != null && discrepancyDetailVOList.getPartCDiscrpDetailVO().getDiscrepancyListVO().length > 0){
			 List listData = Arrays.asList(discrepancyDetailVOList.getPartCDiscrpDetailVO().getDiscrepancyListVO()); 
			sessionHelper.setAttribute("totalWorkQueuLst",listData);
		}
		}//Work Queue Changes : end
		else
		 discrepancyDetailVOList =  DiscrepancyManager.getDiscrepancyList(filterVO, discrpVOMap, move, AjaxHelper.getActiveDataBaseName(),planMap,filterVO.getSearchType(),menuName, hasWriteOffService);
		//Recon-Work Queue Changes : end
		setDetailMap(discrpVOMap, discrepancyDetailVOList,sessionHelper, menuName, partName, move);
		filterVO.setPartName(tempPartName); // re-set orignal partName as discrepancy Indicator.
		logger.info(LoggerConstants.methodEndLevel());
		return discrepancyDetailVOList;
	}
	
	/**
	  * This method generally called to get First Record Keys of Last Page.
	  * which is used by Query Helper to produce prev. records set.
	  * This method also updates pageHist attribute
	  * @param discrpMap
	  * @return DiscrepancyListVO : Cantains key for previous records.
	 */
	private DiscrepancyListVO getPrevDiscrpDetailVO(Map discrpMap) {
		logger.info(LoggerConstants.methodStartLevel());
		DiscrepancyListVO discrpDetailVO = null;
		String pageHist = (String) discrpMap.get(Constants.PAGE_HIST);
		if(pageHist != null){
			String discStr;
			if(pageHist.indexOf(",") == -1){
				discStr = pageHist;
			} else {
				String [] pageHistArr = pageHist.split("[,]");
				
				//	getting Last page PDE Event Detail VO
				discStr = pageHistArr[pageHistArr.length-1];
			}
			
			String [] descDetailArr = discStr.split("[|]");
			
			discrpDetailVO = new DiscrepancyListVO();
			discrpDetailVO.setPlanName(descDetailArr[0]); // plan Id
			discrpDetailVO.setHicNumber(descDetailArr[1]);	// hicNumber
			discrpDetailVO.setPbpId(descDetailArr[2]);	// Pbp Id
			discrpDetailVO.setPymtEffDate(descDetailArr[3]);// payment Effective Date 
			discrpDetailVO.setCreateDate(descDetailArr[4]);// Create time
			discrpDetailVO.setDiscrepancyCd(descDetailArr[5]);// Discrpancy Code
			discrpDetailVO.setDiscrepancyStatus(descDetailArr[6]);// Discrepancy status
		}
		logger.info(LoggerConstants.methodEndLevel());
		return discrpDetailVO;
	}
	/**
	 * The <code>getDiscrepancyDashBoard</code> is call by UI to get  values for DiscrepancyDashBoard.
	 * @param searchType : On the  basis of this value we decide search criteria. 
	 * @param filterVO : this Vo contain all the criteria to be use in searching.
	 * @return
	 * @throws ApplicationException
	 */
	public DiscrepancyDashBoardVO[] getDiscrepancyDashBoard(String searchType, FilterVO filterVO, String menuName) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		AjaxHelper.validateUser();
		FilterVO sessionFilterVO = null;
		Map planMap = getPlanForParts();
		
		if(Constants.BENEFICIARY_MENU.equals(menuName))
			sessionFilterVO = (FilterVO) AjaxHelper.getAttribute(Constants.SESSION_BENEFICIARY_DISC_DASHBOARD_FILTERVO);
		else
			sessionFilterVO = (FilterVO) AjaxHelper.getAttribute(Constants.SESSION_DISCREPANCY_DASHBOARD_FILTERVO);
		
		AjaxHelper.updateFilterVo(sessionFilterVO,filterVO,searchType);
		logger.info(LoggerConstants.methodEndLevel());
		return DiscrepancyManager.getDiscrepancyDashBoard(filterVO, planMap,searchType, null, menuName, AjaxHelper.getActiveDataBaseName());
	}
	
	
	/**
	 * <code>getPlanForParts</code> return Map of plan for part c/part D
	 * @return
	 * @throws ApplicationException
	 */
	private Map getPlanForParts() throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		Map planMap = sessionHelper.getPlanForParts();
		logger.info(LoggerConstants.methodEndLevel());
		return planMap;
	}
	
	/**
	 * This set detailMap which contain total number of page ,records , first and last record of discrpancyList 
	 * @param discrpMap
	 * @param discrepancyDetailVOList
	 * @param sessionHelper
	 * @param partName
	 * @param string
	 */
	private void setDetailMap(Map discrpMap, DiscrepancyDetailVOList discDetailVOList, SessionHelper sessionHelper, String menuName, String partName, String move) {
		logger.info(LoggerConstants.methodStartLevel());
		if(discDetailVOList != null) {
			if(discrpMap == null )
				discrpMap = new HashMap ();
			
			if(Constants.PARTC.equals(partName)) {
				discrpMap.put(Constants.PARTC_DISCRP_DETAIL_MAP,createMap(discDetailVOList.getPartCDiscrpDetailVO(), (Map)discrpMap.get(Constants.PARTC_DISCRP_DETAIL_MAP) , move));
			} else if(Constants.PARTD.equals(partName)) {
				discrpMap.put(Constants.PARTD_DISCRP_DETAIL_MAP,createMap(discDetailVOList.getPartDDiscrpDetailVO(), (Map)discrpMap.get(Constants.PARTD_DISCRP_DETAIL_MAP) , move));
			} else if(Constants.BOTH_PARTS.equals(partName)) {
				discrpMap.put(Constants.PARTC_DISCRP_DETAIL_MAP,createMap(discDetailVOList.getPartCDiscrpDetailVO(), (Map)discrpMap.get(Constants.PARTC_DISCRP_DETAIL_MAP) , move));
				discrpMap.put(Constants.PARTD_DISCRP_DETAIL_MAP,createMap(discDetailVOList.getPartDDiscrpDetailVO(), (Map)discrpMap.get(Constants.PARTD_DISCRP_DETAIL_MAP) , move));
			}
			if (discDetailVOList != null)
				discrpMap.put(Constants.PAGE_SELECTED_LINE , new Integer(discDetailVOList.getSelectedLine()));
			discrpMap.remove(Constants.SESSION_MAX_RECORD_COUNT);
			discrpMap.remove(Constants.CONSTANTS_ALL);			
			
			sessionHelper.setAttribute(Constants.SESSION_DISCREPANCY_DETAIL_MAP,discrpMap);	
			
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	/**
	 * <code>createMap</code> create map for discrepancy detail.
	 * @param discrepancyDetailVO
	 * @param move
	 * @param discrpMap
	 * @return
	 */
	private Map createMap(DiscrepancyDetailVO discrepancyDetailVO, Map discrpMap, String move){
		logger.info(LoggerConstants.methodStartLevel());
		if(discrepancyDetailVO != null) {
			if(discrpMap == null)
				discrpMap = new HashMap ();
			DiscrepancyListVO [] discrepancyListVO = discrepancyDetailVO.getDiscrepancyListVO();
			if(discrepancyListVO != null ) {
				/**************** START BLOCK FOR CALCULATING PAGE HIST ***************************
				 ADD : When user click on NEXT button (adding prev. page First VO
				 REMOVE : When user click on PREV button (remove top entry from List (it. current loading page)
				***********************************************************************************/
				
				String discPageHist = (String) discrpMap.get(Constants.PAGE_HIST);
                String newPageHist = (discPageHist != null) ? discPageHist : "";
                
                // updating Discrepancy Page Hist 
                if("previous".equals(move)) {
                	if(newPageHist.indexOf(",") != -1) {
	                	String []pageHistArr = discPageHist.split("[,]"); // spliting the list, remove last entry (CURRENT PAGE)
	                	newPageHist = pageHistArr[0];
	                	
	                	for(int i=1; i < pageHistArr.length-1; i++ ){
	                		newPageHist += "," + pageHistArr[i];
	                	}
                	} else 
                		newPageHist = "";
                	
        		} else if ("next".equals(move)) {  // adding current page Paging Key Set into PDE PAGE HIST
        			DiscrepancyListVO detailVO =  (DiscrepancyListVO) discrpMap.get(Constants.FIRST_DETAIL_VO);
        			if(detailVO != null) {
        				if(! "".equals(newPageHist))
            				newPageHist += ",";
        				
        				newPageHist += detailVO.getPagingKeySet();
        			}
            	}
        		
        		if(("previous".equals(move) && "".equals(newPageHist)) || "first".equals(move))
        			discrpMap.remove(Constants.PAGE_HIST);
        		else
        			discrpMap.put(Constants.PAGE_HIST, newPageHist);
        		/**************** END BLOCK FOR CALCULATING PAGE HIST ****************************/
				
				discrpMap.put(Constants.FIRST_DETAIL_VO,discrepancyListVO[0]);
				discrpMap.put(Constants.LAST_DETAIL_VO,discrepancyListVO[discrepancyListVO.length-1]);
				discrpMap.put(Constants.CURRENT_PAGE,discrepancyDetailVO.getCurrentPage());
				discrpMap.put(Constants.PAGE_NUMBER , new Integer(discrepancyDetailVO.getPageNumber()));
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return discrpMap;
	}
	
	public GenericDisplayPageForm getDiscrepancyDetails(DiscrepancyListVO discList, int rowId ,String menuName, String pageType, String partName) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		AjaxHelper.validateUser();
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		FilterVO filterVO = null;
		Map discrpVOMap = null;
		
		if(Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(menuName)) {
			if(Constants.READ_ONLY.equals(pageType)){
				filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_PYMT_SUMMARY_FILTERVO);
				discrpVOMap = (Map) sessionHelper.getAttribute(Constants.SESSION_READ_ONLY_DISCRP_DETAIL_MAP);
			} else {
				filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DETAIL_FILTERVO);
				discrpVOMap = (Map)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DISCRP_DETAIL_MAP);
			}
		} else {
			filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_FILTERVO);
			discrpVOMap = (Map)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_MAP);
		}
		
		if(discrpVOMap != null)
			discrpVOMap.put(Constants.PAGE_SELECTED_LINE , new Integer(rowId));
	
		boolean hasWriteOffService = sessionHelper.hasWriteOffPermission();
		Map discrpArrMap = MasterManager.getDiscrpArrMap();
		DiscrepancyService disc = new DiscrepancyService(AjaxHelper.getActiveDataBaseName());
		List details = disc.getDiscrepancyDetails(discList , filterVO, discrpArrMap, hasWriteOffService, partName);
		GenericDisplayPageForm page = new GenericDisplayPageForm();
		page.setListObject((List)details.get(0));
		page.setDetail(details.get(1));
		logger.info(LoggerConstants.methodEndLevel());
		return page;
	}
	
	/**
	 *  <code>getDiscrpType</code> Get discrepancy type for partC/partD/Both on seleting radio button.
	 * @param partName
	 * @return
	 * @throws ApplicationException
	 */
	public NameValuePair [] getDiscrpType(String partName) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		AjaxHelper.validateUser();
		logger.info(LoggerConstants.methodEndLevel());
		return MasterManager.getDiscrpArr(partName);
	}
	
	/**
	 * Function <code>updateDiscrepancyStatus</code> udpates the Discrepancy status.
	 * @param discrepancyVO
	 * @return
	 * @throws ApplicationException
	 */
	public GenericDisplayPageForm updateDiscrepancyStatus(DiscrepancyListVO discrepancyVO, String menuName, String selectRow) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		AjaxHelper.validateUser();
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		String userId = sessionHelper.getUserId();
		boolean hasBothDiscPermission = sessionHelper.hasBothDiscAccessPermission();
		//result: count. 
		int count = DiscrepancyManager.updateDiscrepancyStatus(discrepancyVO, userId, hasBothDiscPermission, AjaxHelper.getActiveDataBaseName());
		GenericDisplayPageForm page = new GenericDisplayPageForm();
		page.setCount(count);
		page.setDetail(discrepancyVO);
		
		if (count > 0) {
			//now get the latest detail information and history, since it's been updated by the update transaction.
			FilterVO filterVO = null;
			if(Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(menuName)) 
				filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_BENEFICIARY_DETAIL_FILTERVO);
			else 
				filterVO = (FilterVO)sessionHelper.getAttribute(Constants.SESSION_DISCREPANCY_DETAIL_FILTERVO);
			
			boolean hasWriteOffService = sessionHelper.hasWriteOffPermission();
			Map discrpArrMap = MasterManager.getDiscrpArrMap();
			DiscrepancyService disc = new DiscrepancyService(AjaxHelper.getActiveDataBaseName());
			//get discrepancy detail and history items.
			int row = Integer.parseInt(selectRow);
			String partName = Constants.PARTC;
			if (row >= 10)
				partName = Constants.PARTD;
			List details = disc.getDiscrepancyDetails(discrepancyVO , filterVO, discrpArrMap, hasWriteOffService, partName);
			page.setListObject((List)details.get(0)); //set history items
		}
		logger.info(LoggerConstants.methodEndLevel());
		return page;
	}
	
	/**
	 * Function <code>cancelWriteoffRequest</code> cancelled writeOff reqeust for Discrepancy.
	 * 
	 * @param discrepancyListVO
	 * @return
	 * @throws ApplicationException
	 */
	public int cancelWriteoffRequest(DiscrepancyListVO discrepancyListVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		AjaxHelper.validateUser();
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		String userId = sessionHelper.getUserId();
		logger.info(LoggerConstants.methodEndLevel());
		return DiscrepancyManager.cancelWriteoffRequest(discrepancyListVO, userId, AjaxHelper.getActiveDataBaseName());
	}
	
	/**
	 * Function <code>updateDiscWriteOff</code> updates writeOff reqeust for Discrepancy.
	 * @param discrepancyListVO
	 * @return
	 * @throws ApplicationException
	 */
	public int updateDiscWriteOff(DiscrepancyListVO discrepancyListVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		AjaxHelper.validateUser();
		SessionHelper sessionHelper = AjaxHelper.getSessionHelper();
		String userId = sessionHelper.getUserId();
		logger.info(LoggerConstants.methodEndLevel());
		return DiscrepancyManager.updateDiscrepancyWriteOff(discrepancyListVO, userId, AjaxHelper.getActiveDataBaseName());
	}
}
