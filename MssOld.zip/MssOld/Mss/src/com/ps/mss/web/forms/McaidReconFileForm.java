package com.ps.mss.web.forms;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import com.ps.mss.dao.model.DiscViewReconVO;
import com.ps.mss.dao.model.McaidAnomSummDetailDataVO;
import com.ps.mss.model.DiscrepancyDashBoardVO;
import com.ps.mss.model.DiscrepancySummaryVOList;

/**
 * Form bean for a Struts application.
 * @version 	1.0
 * @author
 */
public class McaidReconFileForm extends McaidReconBaseForm {
	
	private String searchTypeOfFile;
	private String searchCyclePeriod;
	private String searchPbp;
	private String searchFileStatus;
	private List typeOfFileList;
	private List cyclePeriodList;
	private List pbpList;
	private List fileStatusList;
	
	private String totalPayments;
	
	private String totalRecords;
	private String fileType;	
	private String cyclePeriod;
	private String pbp;
	private String fileStatus;
	private String paymentAmt;
	
	private String recordCount;
	private String fileDate ;
	private String fileFrequency;
	private String fileName;
			
	private List mcaidFilesLst;

	private int currentPageNbr;
	private String fileLstPageType;

	/**
	 * @return the searchTypeOfFile
	 */
	public String getSearchTypeOfFile() {
		return searchTypeOfFile;
	}

	/**
	 * @param searchTypeOfFile the searchTypeOfFile to set
	 */
	public void setSearchTypeOfFile(String searchTypeOfFile) {
		this.searchTypeOfFile = searchTypeOfFile;
	}

	/**
	 * @return the searchCyclePeriod
	 */
	public String getSearchCyclePeriod() {
		return searchCyclePeriod;
	}

	/**
	 * @param searchCyclePeriod the searchCyclePeriod to set
	 */
	public void setSearchCyclePeriod(String searchCyclePeriod) {
		this.searchCyclePeriod = searchCyclePeriod;
	}

	/**
	 * @return the searchPbp
	 */
	public String getSearchPbp() {
		return searchPbp;
	}

	/**
	 * @param searchPbp the searchPbp to set
	 */
	public void setSearchPbp(String searchPbp) {
		this.searchPbp = searchPbp;
	}

	/**
	 * @return the searchFileStatus
	 */
	public String getSearchFileStatus() {
		return searchFileStatus;
	}

	/**
	 * @param searchFileStatus the searchFileStatus to set
	 */
	public void setSearchFileStatus(String searchFileStatus) {
		this.searchFileStatus = searchFileStatus;
	}

	/**
	 * @return the totalPayments
	 */
	public String getTotalPayments() {
		return totalPayments;
	}

	/**
	 * @param totalPayments the totalPayments to set
	 */
	public void setTotalPayments(String totalPayments) {
		this.totalPayments = totalPayments;
	}

	/**
	 * @return the totalRecords
	 */
	public String getTotalRecords() {
		return totalRecords;
	}

	/**
	 * @param totalRecords the totalRecords to set
	 */
	public void setTotalRecords(String totalRecords) {
		this.totalRecords = totalRecords;
	}

	/**
	 * @return the fileType
	 */
	public String getFileType() {
		return fileType;
	}

	/**
	 * @param fileType the fileType to set
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	/**
	 * @return the cyclePeriod
	 */
	public String getCyclePeriod() {
		return cyclePeriod;
	}

	/**
	 * @param cyclePeriod the cyclePeriod to set
	 */
	public void setCyclePeriod(String cyclePeriod) {
		this.cyclePeriod = cyclePeriod;
	}

	/**
	 * @return the pbp
	 */
	public String getPbp() {
		return pbp;
	}

	/**
	 * @param pbp the pbp to set
	 */
	public void setPbp(String pbp) {
		this.pbp = pbp;
	}

	/**
	 * @return the fileStatus
	 */
	public String getFileStatus() {
		return fileStatus;
	}

	/**
	 * @param fileStatus the fileStatus to set
	 */
	public void setFileStatus(String fileStatus) {
		this.fileStatus = fileStatus;
	}

	/**
	 * @return the paymentAmt
	 */
	public String getPaymentAmt() {
		return paymentAmt;
	}

	/**
	 * @param paymentAmt the paymentAmt to set
	 */
	public void setPaymentAmt(String paymentAmt) {
		this.paymentAmt = paymentAmt;
	}

	/**
	 * @return the recordCount
	 */
	public String getRecordCount() {
		return recordCount;
	}

	/**
	 * @param recordCount the recordCount to set
	 */
	public void setRecordCount(String recordCount) {
		this.recordCount = recordCount;
	}

	/**
	 * @return the fileDate
	 */
	public String getFileDate() {
		return fileDate;
	}

	/**
	 * @param fileDate the fileDate to set
	 */
	public void setFileDate(String fileDate) {
		this.fileDate = fileDate;
	}

	/**
	 * @return the fileFrequency
	 */
	public String getFileFrequency() {
		return fileFrequency;
	}

	/**
	 * @param fileFrequency the fileFrequency to set
	 */
	public void setFileFrequency(String fileFrequency) {
		this.fileFrequency = fileFrequency;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return the mcaidFilesLst
	 */
	public List getMcaidFilesLst() {
		return mcaidFilesLst;
	}

	/**
	 * @param mcaidFilesLst the mcaidFilesLst to set
	 */
	public void setMcaidFilesLst(List mcaidFilesLst) {
		this.mcaidFilesLst = mcaidFilesLst;
	}

	
	/**
	 * @return the typeOfFileList
	 */
	public List getTypeOfFileList() {
		return typeOfFileList;
	}

	/**
	 * @param typeOfFileList the typeOfFileList to set
	 */
	public void setTypeOfFileList(List typeOfFileList) {
		this.typeOfFileList = typeOfFileList;
	}

	/**
	 * @return the cyclePeriodList
	 */
	public List getCyclePeriodList() {
		return cyclePeriodList;
	}

	/**
	 * @param cyclePeriodList the cyclePeriodList to set
	 */
	public void setCyclePeriodList(List cyclePeriodList) {
		this.cyclePeriodList = cyclePeriodList;
	}

	/**
	 * @return the pbpList
	 */
	public List getPbpList() {
		return pbpList;
	}

	/**
	 * @param pbpList the pbpList to set
	 */
	public void setPbpList(List pbpList) {
		this.pbpList = pbpList;
	}

	/**
	 * @return the fileStatusList
	 */
	public List getFileStatusList() {
		return fileStatusList;
	}

	/**
	 * @param fileStatusList the fileStatusList to set
	 */
	public void setFileStatusList(List fileStatusList) {
		this.fileStatusList = fileStatusList;
	}

	/**
	 * @return the currentPageNbr
	 */
	public int getCurrentPageNbr() {
		return currentPageNbr;
	}

	/**
	 * @param currentPageNbr the currentPageNbr to set
	 */
	public void setCurrentPageNbr(int currentPageNbr) {
		this.currentPageNbr = currentPageNbr;
	}

	/**
	 * @return the fileLstPageType
	 */
	public String getFileLstPageType() {
		return fileLstPageType;
	}

	/**
	 * @param fileLstPageType the fileLstPageType to set
	 */
	public void setFileLstPageType(String fileLstPageType) {
		this.fileLstPageType = fileLstPageType;
	}

	
	
	


}//class
