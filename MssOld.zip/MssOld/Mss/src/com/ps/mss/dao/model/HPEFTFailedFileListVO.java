package com.ps.mss.dao.model;

import java.util.LinkedHashMap;
import java.util.List;

/**
 * @author bsanthos
 *
 *         Value object for HPEForm class
 */
public class HPEFTFailedFileListVO {

	// EDPSFileDashboard Managment listVOs
	private String encType;
	private String intrchg_recvr_id;
	private String cust_source_id;
	private String dateYrMo;

	// Failed File listVOs

	private int mfId;
	private int submitterId;
	private String fileDate;
	private String cust_file_name;

	public class Month {
		private Integer month = new Integer(0);

		// Constructor
		public Month(Integer m) {
			month = m;
		}

		// Getters/Setters
		public Integer getMonth() {
			return month;
		}

	}

	public class Months extends LinkedHashMap {
		public Month addMonth(Integer m) {
			Month month = null;
			String key = m.toString();
			if (super.containsKey(key)) {
				month = (Month) super.get(key);
			} else {
				month = new Month(m);
				super.put(key, month);
			}
			return month;
		}

		public Month getMonth(Integer m) {
			String key = m.toString();
			return (Month) super.get(key);
		}
	}

	public class Year {
		private Integer year = new Integer(0);
		private Months months = new Months();

		// Constructor
		public Year(Integer y) {
			year = y;
		}

		// Getters/Setters
		public Integer getYear() {
			return year;
		}

		public Months getMonths() {
			return months;
		}

	}

	public class Years extends LinkedHashMap {
		public Year addYear(Integer y) {
			Year year = null;
			String key = y.toString();
			if (super.containsKey(key)) {
				year = (Year) super.get(key);
			} else {
				year = new Year(y);
				super.put(key, year);
			}
			return year;
		}

		public Year getYear(Integer y) {
			String key = y.toString();
			return (Year) super.get(key);
		}
	}

	private Years years = new Years();

	// Getters/Setters
	public Years getYears() {
		return years;
	}

	/**
	 * @return the intrchg_recvr_id
	 */
	public String getIntrchg_recvr_id() {
		return intrchg_recvr_id;
	}

	/**
	 * @param intrchg_recvr_id
	 *            the intrchg_recvr_id to set
	 */
	public void setIntrchg_recvr_id(String intrchg_recvr_id) {
		this.intrchg_recvr_id = intrchg_recvr_id;
	}

	/**
	 * @return the encType
	 */
	public String getEncType() {
		return encType;
	}

	/**
	 * @param encType
	 *            the encType to set
	 */
	public void setEncType(String encType) {
		this.encType = encType;
	}

	/**
	 * @return the cust_source_id
	 */
	public String getCust_source_id() {
		return cust_source_id;
	}

	/**
	 * @param cust_source_id
	 *            the cust_source_id to set
	 */
	public void setCust_source_id(String cust_source_id) {
		this.cust_source_id = cust_source_id;
	}

	/**
	 * @return the dateYrMo
	 */
	public String getDateYrMo() {
		return dateYrMo;
	}

	/**
	 * @param dateYrMo
	 *            the dateYrMo to set
	 */
	public void setDateYrMo(String dateYrMo) {
		this.dateYrMo = dateYrMo;
	}

	/**
	 * @return the mfId
	 */
	public int getMfId() {
		return mfId;
	}

	/**
	 * @param mfId
	 *            the mfId to set
	 */
	public void setMfId(int mfId) {
		this.mfId = mfId;
	}

	/**
	 * @return the submitterId
	 */
	public int getSubmitterId() {
		return submitterId;
	}

	/**
	 * @param submitterId
	 *            the submitterId to set
	 */
	public void setSubmitterId(int submitterId) {
		this.submitterId = submitterId;
	}

	/**
	 * @return the fileDate
	 */
	public String getFileDate() {
		return fileDate;
	}

	/**
	 * @param fileDate
	 *            the fileDate to set
	 */
	public void setFileDate(String fileDate) {
		this.fileDate = fileDate;
	}

	/**
	 * @return the cust_file_name
	 */
	public String getCust_file_name() {
		return cust_file_name;
	}

	/**
	 * @param cust_file_name
	 *            the cust_file_name to set
	 */
	public void setCust_file_name(String cust_file_name) {
		this.cust_file_name = cust_file_name;
	}

	/**
	 * @param years
	 *            the years to set
	 */
	public void setYears(Years years) {
		this.years = years;
	}

}
