/*
 * ReconDBUtil.java
 * $Id: ReconDBUtil.java,v 1.1 2014/06/26 07:57:02 praveen Exp $
 * Created on February 26, 2006, 5:36 PM
 */

package com.ps.mss.ScrnLib.recon;

import java.io.PrintStream;
import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.ps.util.StringUtil;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.SecuserSettingPersistence;

/**
 *
 * @author  BNenne
 */
public class ReconDBUtil {
  
    private PrintStream log;
    private boolean isQAAvailable = false;
    
    /** Creates a new instance of ReconDBUtil */
   /* public ReconDBUtil() {
        this(System.out);
    }
    public ReconDBUtil(PrintStream log) {
        this.log = log;
    }*/
    
    public void checkQAAvailable(String userId) {
        Connection conn = null;
        String val = null;
        try {
            conn = DbConn.getConnection();
            SecuserSettingPersistence sup = new SecuserSettingPersistence();
            val = sup.getValue(conn,userId,"RECONQA");
            if (StringUtil.nonNullTrim(val).equalsIgnoreCase("TRUE"))
                isQAAvailable = true;
        } catch(Exception e) {
            log.println(e.toString());
        } finally {
            try {
                if (conn != null) conn.close();
            } catch(Exception e) {
                log.println(e.toString());
            }
        }        
    }
    
    public String reconDbSelect() {

        StringBuffer sb = new StringBuffer();
        if (isQAAvailable) {
            sb.append("<table><tr><td><input type=\"radio\" name=\"reconDB\" checked value=\"");
            sb.append(DbConn.getDfltDb());
            sb.append("\"><font face=\"Arial\">PROD</font></td></tr>");
            sb.append("<tr><td><input type=\"radio\" name=\"reconDB\" value=\"");
            sb.append(DbConn.DB_QA);
            sb.append("\"><font face=\"Arial\">QA</font></td></tr></table>");
        } else {
            sb.append("<input type=\"hidden\" name=\"reconDB\" value=\"");
            sb.append(DbConn.getDfltDb());
            sb.append("\">");
        }
        
        return sb.toString();
    }
    
    public String reconQACheck(HttpServletRequest req) {

        String chk = "";
        if (StringUtil.nonNullTrim(req.getParameter("QA")).equals("Y"))
            chk = "checked";
            
        StringBuffer sb = new StringBuffer();
        if (isQAAvailable) {
            sb.append("<input type=\"checkbox\" name=\"QA\" value=\"Y\"");
            sb.append(chk);
            sb.append("><font face=\"Arial\">QA</font>");
        } else {
            sb.append("&nbsp;");
        }
        
        return sb.toString();
    }
 
    public String reconQAFunc() {

        if (isQAAvailable) {
            return "getChkValue(document.frmReconDemoMenu.QA)";
        }
        return "'N'";
    }
    
    public String getDb(String qaFlag) {
        if (qaFlag.equals("Y"))
            return DbConn.DB_QA;
        return DbConn.getDfltDb();
    }
    
    public String getDb(HttpSession session, String qaFlag) {
    	
        if (qaFlag.equals("Y"))
            return DbConn.DB_QA;

    	String reconDb = (String)session.getAttribute("ReconDB");
        if (reconDb != null)
            return reconDb;

        return DbConn.getDfltDb();
    }    

    public String displayDb(String qaFlag) {
        if (qaFlag.equals("Y")) {
            return "<font face=\"Arial\" size=\"4\" color=\"red\">QA</font>";
        }
        return "&nbsp;";
    }
}
