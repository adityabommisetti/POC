/*
 * Created on Sep 15, 2007
 *
 */
package com.ps.mss.manager;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.CodeCacheService;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.util.NameValuePair;

/**
  */
public class MasterManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(MasterManager.class);

	/**
	 * this method returns maximum no of records to show for 'ALL' option in Discrepancy Detail PDF and Print 
	 * @author Hemant
	 * @return 
	 * @throws ApplicationException
	 */
	public static Integer getMaxRecordCount() throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		CodeCacheService codeCache=new CodeCacheService();
		logger.info(LoggerConstants.methodEndLevel());
		return 	codeCache.getMaxRecordCount();
	}
	
	public static Map getPlanArr(String custNbr) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		CodeCacheService codeCache=new CodeCacheService();
		logger.info(LoggerConstants.methodEndLevel());
		return 	codeCache.getPlanList(custNbr);
	}

	public static NameValuePair [] getDiscrpArr(String discIndicator) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		NameValuePair [] nameValuePairs = null ;
		CodeCacheService codeCache=new CodeCacheService();
		Map temDiscrpMap = codeCache.getDiscrpArr();
		Map partMap = null;
		if(temDiscrpMap != null) {
			if(Constants.BOTH_PARTS.equals(discIndicator)) {
				Map partCMap = (Map) temDiscrpMap.get(Constants.PARTC_DISCRP_ARR);
				Map partDMap = (Map) temDiscrpMap.get(Constants.PARTD_DISCRP_ARR);
				partMap = new HashMap(partCMap);
				partMap.putAll(partDMap);		
			} else if(Constants.PARTD.equals(discIndicator) )
				partMap = (Map) temDiscrpMap.get(Constants.PARTD_DISCRP_ARR);
			else	
				partMap = (Map) temDiscrpMap.get(Constants.PARTC_DISCRP_ARR);
		}
		if(partMap != null) {
			nameValuePairs = (NameValuePair[]) (new TreeMap(partMap)).values().toArray(new NameValuePair[0]);;
		}
		logger.info(LoggerConstants.methodEndLevel());
		return nameValuePairs;		
	}
	public static NameValuePair [] getDiscrpArrWrkQ(String discIndicator) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		NameValuePair [] nameValuePairs = null ;
		CodeCacheService codeCache=new CodeCacheService();
		Map temDiscrpMap = codeCache.getDiscrpArr();
		Map partMap = null;
		if(temDiscrpMap != null) {
			if(Constants.BOTH_PARTS.equals(discIndicator)) {
				Map partCMap = (Map) temDiscrpMap.get(Constants.PARTC_DISCRP_ARR);
				Map partDMap = (Map) temDiscrpMap.get(Constants.PARTD_DISCRP_ARR);
				partMap = new HashMap(partCMap);
				partMap.putAll(partDMap);		
			} else if(Constants.PARTD.equals(discIndicator) )
				partMap = (Map) temDiscrpMap.get(Constants.PARTD_DISCRP_ARR);
			else	
				partMap = (Map) temDiscrpMap.get(Constants.PARTC_DISCRP_ARR);
		}
		partMap.remove("OOA");
		partMap.remove("OUTA");
		
		if(partMap != null) {
			nameValuePairs = (NameValuePair[]) (new TreeMap(partMap)).values().toArray(new NameValuePair[0]);;
		}
		logger.info(LoggerConstants.methodEndLevel());
		return nameValuePairs;		
	}
	/*
	 * return discrepancy Map witch contain discrepancyCdVO.
	 */
	public static Map getDiscrpArrMap () throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		CodeCacheService codeCache=new CodeCacheService();
		Map temDiscrpMap = codeCache.getDiscrpArrMap();
		logger.info(LoggerConstants.methodEndLevel());
		return temDiscrpMap;
	}
	
	public static NameValuePair [] getDiscrpStatusArr() throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		CodeCacheService codeCache=new CodeCacheService();
		logger.info(LoggerConstants.methodEndLevel());
		return 	codeCache.getDiscrpStatusArr();
	}
	public  static Map getAdjReasonMap() throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		CodeCacheService codeCache = new CodeCacheService();
		logger.info(LoggerConstants.methodEndLevel());
		return 	codeCache.getAdjReasonMap();
	}
	
	/**
	 * 
	 * @param partName
	 * @return
	 * @throws ApplicationException
	 */
	public static NameValuePair[] getProfileParmsArr(String partName) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		NameValuePair[] nameValuePairArr = null;
		
		CodeCacheService codeCacheMasterSvc = new CodeCacheService();
		Map profileParmsMap = codeCacheMasterSvc.getProfileParmsMap();
		
		if ( profileParmsMap != null){
			if ( Constants.PARTC.equals(partName)){
				nameValuePairArr = (NameValuePair[]) profileParmsMap.get(Constants.PARTC);
				
			}else if ( Constants.PARTD.equals(partName)){
				nameValuePairArr = (NameValuePair[]) profileParmsMap.get(Constants.PARTD);
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return nameValuePairArr;
	}
	
	
}
