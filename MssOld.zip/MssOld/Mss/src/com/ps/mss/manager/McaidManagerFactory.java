package com.ps.mss.manager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.framework.McaidReconConstants;

public class McaidManagerFactory {
	private static Logger logger=(Logger) LoggerFactory.getLogger(McaidManagerFactory.class);
	
	public static McaidReconAbsManager getReconStateManager(String id){
		logger.info(LoggerConstants.methodStartLevel());
		if(id == null || id.equals("")){
			logger.info(LoggerConstants.methodEndLevel());
			return null;			
		}
		
		if(id.equals(McaidReconConstants.ST_ILLINOIS)){
			logger.info(LoggerConstants.methodEndLevel());
			return new McaidILManager();			
		}else if(id.equals(McaidReconConstants.ST_TEXAS)){
			logger.info(LoggerConstants.methodEndLevel());
			return new McaidTXManager();
		}else if(id.equals(McaidReconConstants.ST_NEWMEXICO)){
			logger.info(LoggerConstants.methodEndLevel());
			return new McaidNMManager();
		}else if(id.equals(McaidReconConstants.ST_MONTANA)){
			logger.info(LoggerConstants.methodEndLevel());
			return new McaidMTManager();
		}
		else{
			logger.debug("MCAID-McaidManagerFactory : No Suitable Manager found");
			logger.info(LoggerConstants.methodEndLevel());
			return null;
		}
	}

}
