package com.ps.mss.manager;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.model.HPEFTDailyFileProcessingDO;
import com.ps.mss.dao.model.HPEFTEDPSFileDshbMngtDO;
import com.ps.mss.dao.model.HPEFTFailedFileListDO;
import com.ps.mss.dao.model.HPEFTMonEncDetailsDO;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.HPEConstants;
import com.ps.mss.model.HPEContext;
import com.ps.mss.model.HPEFileTrackingVO;
import com.ps.mss.web.forms.HPEFileTrackingForm;
import com.ps.mss.web.helper.HPEFileTrackHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.text.DateFormatter;

/**
 * 
 * @author bsanthos.
 *
 */
public class HPEFTManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(HPEFTManager.class);
	/**
	 * logger.
	 */
	private static ModuleLog log = new ModuleLog("HPEFTManager");

	/**
	 * This method is used to get EDPS SubmitterList.
	 * 
	 * @param conn
	 *            Connection
	 * @param context
	 *            HPEContext
	 * @param mfId
	 *            String
	 * @return searchList List<String>
	 * @throws ApplicationException
	 */
	public List<String> getEDPSSubmitterList(Connection conn, HPEContext context, String mfId)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		List<String> searchList = null;
		searchList = context.getFileTrackService().getEDPSSubmitterList(conn, mfId);
		logger.info(LoggerConstants.methodEndLevel());
		return searchList;
	}

	/**
	 * This method is invoked when user clicks on File tracking switch tab.
	 * 
	 * @param conn
	 *            Connection
	 * @param context
	 *            HPEContext
	 * @param sessionHelper 
	 * @param hpeftSearchForm
	 *            HPEFileTrackingForm
	 * @param hpeftSearchVO
	 *            HPEFileTrackingVO
	 * @return searchList List<HPEFTEDPSFileDshbMngtDO>.
	 */
	public List<HPEFTEDPSFileDshbMngtDO> fileTrackSwitchTab(Connection conn, HPEContext context,
			SessionHelper sessionHelper, HPEFileTrackingForm hpeFTForm, HPEFileTrackingVO hpeFTVO) {
		logger.info(LoggerConstants.methodStartLevel());
		List<HPEFTEDPSFileDshbMngtDO> searchList = null;
		HPEFileTrackHelper hpeFileTrackHelper = new HPEFileTrackHelper();
		try {
			
			String submitterId = hpeFTForm.getSearchSummarySubmitterId();
			String encType = hpeFTForm.getSearchSummaryType();
			
			hpeFTForm.setSec1uiLst(null);
			hpeFTVO.setSec1uiLst(null);
			hpeFTVO.setSearchSubmitterId(hpeFTForm.getSearchSummarySubmitterId());
			hpeFTVO.setSearchEncType(hpeFTForm.getSearchSummaryType());
			hpeFTVO.setLineOfBusiness(hpeFTForm.getLineOfbusiness());
			hpeFTVO.setTypeOfBusiness(hpeFTForm.getSearchSummaryType());

			searchList = context.getFileTrackService().searchFileTrackBySwitchTab(conn, hpeFTVO);
			if (!(searchList.isEmpty())) {
				List<HPEFTEDPSFileDshbMngtDO> temp = hpeFileTrackHelper.copySearchToDisplay(searchList);

				logger.debug("HPEFTManager.fileTrackSwitchTab():: temp is:: " + temp);
				hpeFTForm.setSec1uiLst(temp);
				hpeFTVO.setSec1uiLst(temp);
				
				logger.debug("HPEFTManager.fileTrackSwitchTab():: saving submitterId to Session is:: " + submitterId);
				logger.debug("HPEFTManager.fileTrackSwitchTab()::  saving encType to Session is:: " + encType);
				sessionHelper.setAttribute("edpsFileDashMngtBySearchCriteria", searchList);
				sessionHelper.setAttribute("submitterIdFileTrackSwitchTab", submitterId);
				sessionHelper.setAttribute("encTypeFileTrackSwitchTab", encType); 
			}
		} catch (ApplicationException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log.getStream());
		}

		logger.info(LoggerConstants.methodEndLevel());
		return searchList;
	}

	/**
	 * This method is used to fetch the data into "EDPS File Dash Board
	 * Management" section, when user enters particular Submitter Id, submission
	 * date or/and Source Id in Search Criteria.
	 * 
	 * @param conn
	 *            Connection
	 * @param context
	 *            HPEContext
	 * @param sessionHelper 
	 * @param request 
	 * @param hpeftSearchForm
	 *            HPEFileTrackingForm
	 * @param hpeftSearchVO
	 *            HPEFileTrackingVO
	 * @return searchList List<HPEFTEDPSFileDshbMngtDO>.
	 */
	public List<HPEFTEDPSFileDshbMngtDO> edpsFileDashMngtBySearchCriteria(Connection conn, HPEContext context,
			SessionHelper sessionHelper, HPEFileTrackingForm hpeFTForm, HPEFileTrackingVO hpeFTVO, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		List<HPEFTEDPSFileDshbMngtDO> searchList = null;
		HPEFileTrackHelper hpeFileTrackHelper = new HPEFileTrackHelper();
		nullInitilizer(hpeFTForm, hpeFTVO);

		String submitterId = hpeFTForm.getSearchSubmitterId();
		String sourceid = hpeFTForm.getSourceId();
		String encType = hpeFTForm.getSearchSummaryType();
		String fromDate = DateFormatter.reFormat(hpeFTForm.getSearchFromDate(), DateFormatter.MM_YYYY, DateFormatter.YYYYMM);
		String toDate = DateFormatter.reFormat(hpeFTForm.getSearchToDate(), DateFormatter.MM_YYYY, DateFormatter.YYYYMM);
		String lineOfBusiness = hpeFTForm.getLineOfbusiness();
		String typeOfBusiness = hpeFTForm.getSearchSummaryType();
		
		
		try {
			logger.debug("In HPEFileTrackManager: searchFileTrackBySearchCriteria: -START");

			hpeFTVO.setSearchSubmitterId(hpeFTForm.getSearchSubmitterId());
			hpeFTVO.setSourceId(hpeFTForm.getSourceId());
			hpeFTVO.setSearchEncType(hpeFTForm.getSearchSummaryType());

			hpeFTVO.setSearchFromDate(
					DateFormatter.reFormat(hpeFTForm.getSearchFromDate(), DateFormatter.MM_YYYY, DateFormatter.YYYYMM));
			hpeFTVO.setSearchToDate(
					DateFormatter.reFormat(hpeFTForm.getSearchToDate(), DateFormatter.MM_YYYY, DateFormatter.YYYYMM));

			hpeFTVO.setLineOfBusiness(hpeFTForm.getLineOfbusiness());
			hpeFTVO.setTypeOfBusiness(hpeFTForm.getSearchSummaryType());

			// hpeftSearchVO.setFileDsbMgmtHL(hpeftSearchForm.getFileDsbMgmtHL());
			// Search
			
			
			// Get it from Session and set it to Form - Start 
			
			String formSearch = request.getParameter("formSearch");
			logger.debug("formSearch is in edpsFileDashMngtBySearchCriteria :"+ formSearch);
			
			if(formSearch == null || !formSearch.equals("TRUE")) { 
				String submitterFromSession = (String)sessionHelper.getAttribute("submitterIdBySearchCriteria");
				if(submitterFromSession !=null ) {
					hpeFTVO.setSearchSubmitterId(submitterFromSession);
				}
				String sourceidFromSession = (String)sessionHelper.getAttribute("sourceIdBySearchCriteria");
				if(sourceidFromSession !=null ) {
					hpeFTVO.setSourceId(sourceidFromSession);
				}
				String encTypeFromSession = (String)sessionHelper.getAttribute("encTypeBySearchCriteria");
				if(encTypeFromSession !=null ) {
					hpeFTVO.setSearchEncType(encTypeFromSession);
				}
				String fromDateFromSession = (String)sessionHelper.getAttribute("fromDateBySearchCriteria");
				if(fromDateFromSession !=null ) {
					hpeFTVO.setSearchFromDate(fromDateFromSession);
				}
				String toDateFromSession = (String)sessionHelper.getAttribute("toDateBySearchCriteria");
				if(toDateFromSession !=null ) {
					hpeFTVO.setSearchToDate(toDateFromSession);
				}
				String lineOfBusinessFromSession = (String)sessionHelper.getAttribute("lineOfBusinessBySearchCriteria");
				if(lineOfBusinessFromSession !=null ) {
					hpeFTVO.setLineOfBusiness(lineOfBusinessFromSession);
				}
				String typeOfBusinessFromSession = (String)sessionHelper.getAttribute("typeOfBusinessBySearchCriteria");
				if(typeOfBusinessFromSession !=null ) {
					hpeFTVO.setTypeOfBusiness(typeOfBusinessFromSession); 
				}
			}
			// Get it from Session and set it to Form - End 
			
			searchList = context.getFileTrackService().searchFileTrackBySearchCriteria(conn, hpeFTVO);
			sessionHelper.removeAttribute("edpsFileDashMngtByFileNameSearchCriteria");
			
			logger.debug("HPEFileTrackManager.searchFileTrackBySearchCriteria():searchSummaryResults" + searchList);
			if (!(searchList.isEmpty())) {
				hpeFTVO.setFileDsbMgmtHL(null);
				hpeFTForm.setFileDsbMgmtHL(null);
				List<HPEFTEDPSFileDshbMngtDO> temp = hpeFileTrackHelper.copySearchToDisplay(searchList);
				hpeFTForm.setSec1uiLst(temp);
				hpeFTVO.setSec1uiLst(temp);  
				
				sessionHelper.setAttribute("edpsFileDashMngtBySearchCriteria", searchList);
				sessionHelper.setAttribute("submitterIdBySearchCriteria", submitterId);
				sessionHelper.setAttribute("sourceIdBySearchCriteria", sourceid);
				sessionHelper.setAttribute("encTypeBySearchCriteria", encType);
				sessionHelper.setAttribute("fromDateBySearchCriteria", fromDate);
				sessionHelper.setAttribute("toDateBySearchCriteria", toDate);
				sessionHelper.setAttribute("lineOfBusinessBySearchCriteria", lineOfBusiness);
				sessionHelper.setAttribute("typeOfBusinessBySearchCriteria", typeOfBusiness);
				
				//logger.debug("Saving edpsFileDashMngtBySearchCriteria() searchResults into SessionHelper Object :"+ temp);
				//sessionHelper.setAttribute("edpsFileDashMngtBySearchCriteria", temp);
			}

		} catch (ApplicationException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log.getStream());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return searchList;

	}// searchFileTrackBySearchCriteria

	/**
	 * This method is used to fetch the data when user enters particular
	 * FileName from Search Criteria of FileTracking tab it will display
	 * "Daily File Processing section if data is found".
	 * 
	 * @param conn
	 *            Connection
	 * @param context
	 *            HPEContext
	 * @param sessionHelper 
	 * @param hpeftSearchForm
	 *            HPEFileTrackingForm
	 * @param hpeftSearchVO
	 *            HPEFileTrackingVO
	 * @return searchList List<HPEFTDailyFileProcessingDO>
	 */
	public List<HPEFTDailyFileProcessingDO> edpsFileDashMngtByFileNameSearchCriteria(Connection conn,
			HPEContext context, HPEFileTrackingForm hpeFTForm, HPEFileTrackingVO hpeFTVO, SessionHelper sessionHelper, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("In HPEFileTrackManager: searchDailyFileProcesing: -START");
		List<HPEFTDailyFileProcessingDO> searchList = null;
		HPEFileTrackHelper hpeFileTrackHelper = new HPEFileTrackHelper();
		nullInitilizer(hpeFTForm, hpeFTVO);

		try {
			hpeFTVO.setSearchSubmitterId(hpeFTForm.getSearchSubmitterId());
			hpeFTVO.setFileName(hpeFTForm.getFileName());
			hpeFTVO.setSearchEncType(hpeFTForm.getSearchSummaryType());
			
			
			String submitterId = hpeFTForm.getSearchSubmitterId();
			String fileName = hpeFTForm.getFileName();
			String encType = hpeFTForm.getSearchSummaryType();
			
			searchList = context.getFileTrackService().fileTrackDashMgntByFileNameSearchCriteria(conn, hpeFTVO);
			
			sessionHelper.removeAttribute("edpsFileDashMngtBySearchCriteria");
			sessionHelper.removeAttribute("searchMonEncDetails");
			sessionHelper.removeAttribute("searchDailyFileProcesing");
			sessionHelper.removeAttribute("searchFailedFileListDetails");
			sessionHelper.removeAttribute("edpsFileDashMngtByFileIdSearchCriteria");
			
			if (!(searchList.isEmpty())) {
				List<HPEFTDailyFileProcessingDO> temp = hpeFileTrackHelper
						.copySearchToDailyFileProcessingDisplay(searchList);
				hpeFTForm.setDailyFileProcessingLst(temp);
				hpeFTVO.setDailyFileProcessingLst(temp);
				hpeFTForm.setDailyAcceptedFileProcessingLst(temp);
				hpeFTVO.setDailyAcceptedFileProcessingLst(temp);
			
				sessionHelper.setAttribute("edpsFileDashMngtByFileNameSearchCriteria", searchList);
				sessionHelper.setAttribute("submitterIdByFileNameSearchCriteria", submitterId);
				sessionHelper.setAttribute("fileNameByFileNameSearchCriteria", fileName);
				sessionHelper.setAttribute("encTypeByFileNameSearchCriteria", encType);
				
			}else{
				request.setAttribute(HPEConstants.FILETRACK_EMPTY_LIST_FLAG, "TRUE");
			}
		} catch (ApplicationException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log.getStream());
		}
		logger.debug("In HPEFileTrackManager: searchDailyFileProcesing: -END");
		logger.info(LoggerConstants.methodEndLevel());
		return searchList;

	}// fileTrackByFileNameSearchCriteria

	/**
	 * This method is used to fetch the data when user enters particular FileId
	 * from Search Criteria of FileTracking tab it will display
	 * "Daily File Processing section if data is found".
	 * 
	 * @param conn
	 *            Connection
	 * @param context
	 *            HPEContext
	 * @param sessionHelper 
	 * @param hpeftSearchForm
	 *            HPEFileTrackingForm
	 * @param hpeftSearchVO
	 *            HPEFileTrackingVO
	 * @return searchList List<HPEFTDailyFileProcessingDO>
	 */
	public List<HPEFTDailyFileProcessingDO> edpsFileDashMngtByFileIdSearchCriteria(Connection conn, HPEContext context,
			HPEFileTrackingForm hpeFTForm, HPEFileTrackingVO hpeFTVO, SessionHelper sessionHelper, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("In HPEFileTrackManager: searchDailyFileProcesing: -START");
		List<HPEFTDailyFileProcessingDO> searchList = null;
		HPEFileTrackHelper hpeFileTrackHelper = new HPEFileTrackHelper();
		nullInitilizer(hpeFTForm, hpeFTVO);

		try {
			hpeFTVO.setSearchSubmitterId(hpeFTForm.getSearchSubmitterId());
			hpeFTVO.setOrig_intrchg_ctrl_nbr(hpeFTForm.getOrig_intrchg_ctrl_nbr());
			hpeFTVO.setCustFileId(hpeFTForm.getCustFileId()); //IFOX-00416789 - Add customer ICN in File management
			hpeFTVO.setSearchEncType(hpeFTForm.getSearchSummaryType());
			
			String submitterId = hpeFTForm.getSearchSubmitterId();
			String origIntrchgNbr = hpeFTForm.getOrig_intrchg_ctrl_nbr();
			String encType = hpeFTForm.getSearchSummaryType();
			
			searchList = context.getFileTrackService().fileTrackDashMgntByFileIdSearchCriteria(conn, hpeFTVO);
			
			sessionHelper.removeAttribute("edpsFileDashMngtBySearchCriteria");
			
			sessionHelper.removeAttribute("searchMonEncDetails");
			sessionHelper.removeAttribute("searchDailyFileProcesing");
			sessionHelper.removeAttribute("searchFailedFileListDetails");
			sessionHelper.removeAttribute("edpsFileDashMngtByFileNameSearchCriteria");
			
			if (!(searchList.isEmpty())) {
				List<HPEFTDailyFileProcessingDO> temp = hpeFileTrackHelper
						.copySearchToDailyFileProcessingDisplay(searchList);
				hpeFTForm.setDailyFileProcessingLst(temp);
				hpeFTVO.setDailyFileProcessingLst(temp);
				hpeFTForm.setDailyAcceptedFileProcessingLst(temp);
				hpeFTVO.setDailyAcceptedFileProcessingLst(temp);
				
				sessionHelper.setAttribute("edpsFileDashMngtByFileIdSearchCriteria", searchList);
				sessionHelper.setAttribute("submitterIdByFileIdSearchCriteria", submitterId);
				sessionHelper.setAttribute("origIntrchgNbrByFileIdSearchCriteria", origIntrchgNbr);
				sessionHelper.setAttribute("encTypeByFileIdSearchCriteria", encType);
			}else{
				request.setAttribute(HPEConstants.FILETRACK_EMPTY_LIST_FLAG, "TRUE");
			}
		} catch (ApplicationException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log.getStream());
		}
		logger.debug("In HPEFileTrackManager: searchDailyFileProcesing: -END");
		logger.info(LoggerConstants.methodEndLevel());
		return searchList;

	}// fileTrackByFileIdSearchCriteria

	/**
	 * This method is used to fetch data into "Monthly Encounter Details". *
	 * 
	 * @param conn
	 *            Connection
	 * @param context
	 *            HPEContext
	 * @param hpeftSearcForm
	 *            HPEFileTrackingForm
	 * @param hpeftSearchVO
	 *            HPEFileTrackingVO
	 * @param sessionHelper 
	 * @param request 
	 * @return searchList List<HPEFTMonEncDetailsDO>.
	 */
	public List<HPEFTMonEncDetailsDO> searchMonEncDetails(Connection conn, HPEContext context,
			HPEFileTrackingForm hpeftSearchForm, HPEFileTrackingVO hpeftSearchVO, SessionHelper sessionHelper, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		List<HPEFTMonEncDetailsDO> searchList = null;
		hpeftSearchVO.setMoEncDetHL(null);
		hpeftSearchForm.setMoEncDetHL(null);
		nullInitilizer(hpeftSearchForm, hpeftSearchVO);
		final HPEFileTrackingForm hpeftSearchFormObject;
		
		String submitterId = hpeftSearchForm.getSearchSubmitterId();
		//String splitFileStatus = hpeftSearchForm.getSplitFileStatus();
		String dateYearMonth = String.valueOf(hpeftSearchForm.getDateYRMO() + 1);
		String intrChgRecvrId = hpeftSearchForm.getIntrchg_recvr_id();
		String sourceId = hpeftSearchForm.getSourceId();
		String fileDsbMgmtHL = hpeftSearchForm.getFileDsbMgmtHL();
		
		try {
			logger.debug("In HPEFileTrackManager: searchMonEncDetails: -START");

			HPEFileTrackHelper hpeFileTrackHelper = new HPEFileTrackHelper();
			
			// Get search details from Session Object and set it to Search Form - Start 
			
			
			logger.debug("submitterId is by search :"+ submitterId);
			logger.debug("dateYearMonth is by search :"+ dateYearMonth);
			logger.debug("intrChgRecvrId is by search :"+ intrChgRecvrId);
			logger.debug("sourceId is by search :"+ sourceId);
			logger.debug("fileDsbMgmtHL is by search :"+ fileDsbMgmtHL);
			
			// Search
			hpeftSearchVO.setSearchSubmitterId(hpeftSearchForm.getSearchSubmitterId());
			String encType = hpeftSearchForm.getStatus().substring(0, 1);
			String spltFleStatusTemp = hpeftSearchForm.getStatus().substring(1);
			logger.debug("enctype is:" + encType + " split file status is:: " + spltFleStatusTemp);
			hpeftSearchVO.setEncType(encType);
			hpeftSearchForm.setSplitFileStatus(splitFileStatusConvert(spltFleStatusTemp)); 
			hpeftSearchVO.setSplitFileStatus(hpeftSearchForm.getSplitFileStatus());
			logger.debug("split file status after convertion is:::: " + hpeftSearchVO.getSplitFileStatus());
			int dateYrmo = hpeftSearchForm.getDateYRMO() + 1;
			logger.debug("dateYrmo is:::" + dateYrmo);
			hpeftSearchVO.setDateYRMO(String.valueOf(dateYrmo));
			hpeftSearchVO.setIntrchg_recvr_id(hpeftSearchForm.getIntrchg_recvr_id());
			hpeftSearchVO.setSourceId(hpeftSearchForm.getSourceId());
						
			logger.debug("hpeftSearchVO is by search getSearchSubmitterId :"+ hpeftSearchVO.getSearchSubmitterId());
			logger.debug("hpeftSearchVO is by search getEncType :"+ hpeftSearchVO.getEncType());
			logger.debug("hpeftSearchVO is by search getIntrchg_recvr_id :"+ hpeftSearchVO.getIntrchg_recvr_id());
			logger.debug("hpeftSearchVO is by search getSplitFileStatus :"+ hpeftSearchVO.getSplitFileStatus());
			logger.debug("hpeftSearchVO is by search getSourceId :"+ hpeftSearchVO.getSourceId());
			
			searchList = context.getFileTrackService().searchMonEncDetails(conn, hpeftSearchVO);

			logger.debug("HPEFileTrackManager.searchMonEncDetails():searchSummaryResults" + searchList);

			hpeftSearchVO.setFileDsbMgmtHL(hpeftSearchForm.getFileDsbMgmtHL());
			hpeftSearchForm.setSec1uiLst(hpeftSearchVO.getSec1uiLst());
			hpeftSearchFormObject = hpeftSearchForm;
			hpeftSearchVO.setFileDsbMgmtHL(fileDsbMgmtHL);
			
			sessionHelper.removeAttribute("searchMonEncDetails");
			sessionHelper.removeAttribute("searchDailyFileProcesing");

			if (!(searchList.isEmpty())) {
				List<HPEFTMonEncDetailsDO> temp = hpeFileTrackHelper.copySearchToMonEncDetailsDisplay(searchList,
						hpeftSearchForm);
				hpeftSearchForm.setMonEncDetailsLst(temp);
				hpeftSearchVO.setMonEncDetailsLst(temp);
				
				final Map<HPEFileTrackingForm, List<HPEFTMonEncDetailsDO>> map = new HashMap<HPEFileTrackingForm, List<HPEFTMonEncDetailsDO>>();
				map.put(hpeftSearchFormObject, searchList);
				
				logger.debug("Saving searchMonEncDetails Object into sessionHelper object " + map);
				sessionHelper.setAttribute("searchMonEncDetails", map);
				
				sessionHelper.setAttribute("submitterIdSearchMonEncDetails", submitterId);
				sessionHelper.setAttribute("encTypeSearchMonEncDetails", encType); 
				sessionHelper.setAttribute("spltFleStatusTempSearchMonEncDetails", spltFleStatusTemp);
				sessionHelper.setAttribute("dateYearMonthSearchMonEncDetails", dateYearMonth);
				sessionHelper.setAttribute("intrChgRecvrIdSearchMonEncDetails", intrChgRecvrId);
				sessionHelper.setAttribute("sourceIdSearchMonEncDetails", sourceId);
				sessionHelper.setAttribute("fileDsbMgmtHLSearchMonEncDetails", fileDsbMgmtHL);
					
			}

		} catch (ApplicationException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log.getStream());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return searchList;
	}// searchMonEncDetails
	
	public List<HPEFTDailyFileProcessingDO> searchClaimTypeClaimNbrMethod(Connection conn, HPEContext context,
			HPEFileTrackingForm hpeFTForm, HPEFileTrackingVO hpeFTVO, SessionHelper sessionHelper,
			HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		List<HPEFTDailyFileProcessingDO> searchclmList = null;
		nullInitilizer(hpeFTForm, hpeFTVO);
		String submitterId = hpeFTForm.getSearchSubmitterId();
		String claimType = hpeFTForm.getSearchClaimType();
		String claimNumber = hpeFTForm.getSearchClmRefNbr();

		try {
			logger.debug("In HPEFileTrackManager: searchClaimTypeClaimNbrMethod: -START");

			HPEFileTrackHelper hpeFileTrackHelper = new HPEFileTrackHelper();
			// Get search details from Session Object and set it to Search Form
			// - Start
			logger.debug("submitterId is by search :" + submitterId);
			logger.debug("claimType is by search :" + claimType);
			logger.debug("claimNumber is by search :" + claimNumber);
			// Search
			hpeFTVO.setSearchSubmitterId(hpeFTForm.getSearchSubmitterId());
			// Added Claim type and claim number
			hpeFTVO.setClmType(hpeFTForm.getSearchClaimType());
			hpeFTVO.setClaimNumber(hpeFTForm.getSearchClmRefNbr());

			logger.debug("hpeftSearchVO is by search getSearchSubmitterId :" + hpeFTVO.getSearchSubmitterId());
			logger.debug("hpeftSearchVO is by search getClaimType :" + hpeFTVO.getClmType());
			logger.debug("hpeftSearchVO is by search getClaimNumber :" + hpeFTVO.getClaimNumber());
			// Added new method searchClaimDetails
			searchclmList = context.getFileTrackService().searchClaim(conn, hpeFTVO);

			logger.debug("HPEFileTrackManager.searchClaimTypeClaimNbrMethod():searchClaimTypeClaimNbrMethod"	+ searchclmList);

			if (!(searchclmList.isEmpty())) {
				List<HPEFTDailyFileProcessingDO> temp = hpeFileTrackHelper.copySearchToDailyFileProcessingDisplay(searchclmList);
				
                logger.debug("HPEFTManager.searchDailyFileProcesing()temp size:" + temp.size());
				
				logger.debug("Saving searchDailyFileProcesing Object by using claim number and claim type into sessionHelper object  START :" + temp);
				sessionHelper.setAttribute("searchDailyFileProcesing", temp);
				
				sessionHelper.setAttribute("submitterIdSearchDailyFP", submitterId);
				sessionHelper.setAttribute("searchClaimType", claimType); 
				sessionHelper.setAttribute("searchClmRefNbr", claimNumber);
				logger.debug("Saving searchDailyFileProcesing Object into sessionHelper object  END :");
				
                hpeFTForm.setDailyFileProcessingLst(temp);
                hpeFTVO.setDailyFileProcessingLst(temp);
                hpeFTForm.setDailyAcceptedFileProcessingLst(temp);
                hpeFTVO.setDailyAcceptedFileProcessingLst(temp);

			}

		} catch (ApplicationException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log.getStream());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return searchclmList;

	}// searchMonEncDetails

	/**
	 * This method is used to fetch data into "Daily File Processing".
	 * 
	 * @param conn
	 *            Connection
	 * @param context
	 *            HPEContext
	 * @param hpeftSearcForm
	 *            HPEFileTrackingForm
	 * @param hpeftSearchVO
	 *            HPEFileTrackingVO
	 * @param request 
	 * @return searchList List<HPEFTDailyFileProcessingDO>.
	 */
	public List<HPEFTDailyFileProcessingDO> searchDailyFileProcesing(Connection conn, HPEContext context, SessionHelper sessionHelper,
			HPEFileTrackingForm hpeftSearchForm, HPEFileTrackingVO hpeftSearchVO, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		List<HPEFTDailyFileProcessingDO> searchList = null;

		try {
			logger.debug("In HPEFileTrackManager: searchDailyFileProcesing: -START");

			HPEFileTrackHelper hpeFileTrackHelper = new HPEFileTrackHelper();

			String submitterId = hpeftSearchForm.getSearchSubmitterId();
			String encType = hpeftSearchForm.getEncType();
			String dateYearMonth = String.valueOf(hpeftSearchForm.getDateYRMO());
			String intrChgRecvrId = hpeftSearchForm.getIntrchg_recvr_id();
			String submissionDate = hpeftSearchForm.getSubmissionDate();
			String origIntrchgCtrlNbr = hpeftSearchForm.getOrig_intrchg_ctrl_nbr();
			String splitFileStatus = hpeftSearchForm.getSplitFileStatus();
			String  moEncDetHL = hpeftSearchForm.getMoEncDetHL();
			String  dailyDetHL = hpeftSearchForm.getDailyDetHL();
			
			hpeftSearchVO.setSearchSubmitterId(hpeftSearchForm.getSearchSubmitterId());
			hpeftSearchVO.setEncType(hpeftSearchForm.getEncType());
			hpeftSearchVO.setDateYRMO(String.valueOf(hpeftSearchForm.getDateYRMO()));
			hpeftSearchVO.setIntrchg_recvr_id(hpeftSearchForm.getIntrchg_recvr_id());
			hpeftSearchVO.setSubmissionDate(hpeftSearchForm.getSubmissionDate());
			hpeftSearchVO.setOrig_intrchg_ctrl_nbr(hpeftSearchForm.getOrig_intrchg_ctrl_nbr());
			hpeftSearchVO.setCustFileId(hpeftSearchForm.getCustFileId()); //IFOX-00416789 - Add customer ICN in File management
			hpeftSearchVO.setSplitFileStatus(hpeftSearchForm.getSplitFileStatus()); 
			logger.debug("HPEFileTrackManager :::SplitFileStatus:: " + hpeftSearchVO.getSplitFileStatus());
			//hpeftSearchVO.setSourceId(hpeftSearchForm.getSourceId());

			searchList = context.getFileTrackService().searchDailyFileProcessing(conn, hpeftSearchVO);

			logger.debug("HPEFileTrackManager.searchMonEncDetails():searchSummaryResults" + searchList);

			hpeftSearchVO.setFileDsbMgmtHL(hpeftSearchForm.getFileDsbMgmtHL());
			hpeftSearchVO.setMoEncDetHL(hpeftSearchForm.getMoEncDetHL());
			hpeftSearchVO.setDailyDetHL(hpeftSearchForm.getDailyDetHL());
			hpeftSearchForm.setSec1uiLst(hpeftSearchVO.getSec1uiLst());
			hpeftSearchForm.setMonEncDetailsLst(hpeftSearchVO.getMonEncDetailsLst());

			logger.debug("searchList size is before copying :"+ searchList.size());
			
			if (!(searchList.isEmpty())) {
				List<HPEFTDailyFileProcessingDO> temp = hpeFileTrackHelper
						.copySearchToDailyFileProcessingDisplay(searchList);
				logger.debug("HPEFTManager.searchDailyFileProcesing()temp size:" + temp.size());
				
				logger.debug("Saving searchDailyFileProcesing Object into sessionHelper object  START :" + temp);
				sessionHelper.setAttribute("searchDailyFileProcesing", temp);
				
				sessionHelper.setAttribute("submitterIdSearchDailyFP", submitterId);
				sessionHelper.setAttribute("encTypeSearchDailyFP", encType); 
				sessionHelper.setAttribute("dateYearMonthSearchDailyFP", dateYearMonth);
				sessionHelper.setAttribute("intrChgRecvrIdSearchDailyFP", intrChgRecvrId);
				sessionHelper.setAttribute("submissionDateSearchDailyFP", submissionDate);
				sessionHelper.setAttribute("origIntrchgCtrlNbrSearchDailyFP", origIntrchgCtrlNbr);
				sessionHelper.setAttribute("splitFileStatusSearchDailyFP", splitFileStatus);
				sessionHelper.setAttribute("moEncDetHLSearchDailyFP", moEncDetHL);
				sessionHelper.setAttribute("dailyDetHLSearchDailyFP", dailyDetHL);
				logger.debug("Saving searchDailyFileProcesing Object into sessionHelper object  END :");
				
				hpeftSearchForm.setDailyFileProcessingLst(temp);
				hpeftSearchVO.setDailyFileProcessingLst(temp);
				hpeftSearchForm.setDailyAcceptedFileProcessingLst(temp);
				hpeftSearchVO.setDailyFileProcessingLst(temp);
				hpeftSearchVO.setDailyAcceptedFileProcessingLst(temp);
			}
			logger.debug("In HPEFileTrackManager: searchDailyFileProcesing: -END");
		} catch (ApplicationException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log.getStream());
		}

		logger.info(LoggerConstants.methodEndLevel());
		return searchList;
	}// searchDailyFileProcesing

	/**
	 * This method is used to fetch Failed files list from "EDPS File Dash Board
	 * Management" section.
	 * 
	 * @param conn
	 *            Connection
	 * @param context
	 *            HPEContext
	 * @param hpeftSearchForm
	 *            HPEFileTrackingForm
	 * @param hpeftSearchVO
	 *            HPEFileTrackingVO
	 * @param sessionHelper 
	 * @return searchList List<HPEFTFailedFileListDO>.
	 */
	public List<HPEFTFailedFileListDO> searchFailedFileListDetails(Connection conn, HPEContext context,
			HPEFileTrackingForm hpeftSearchForm, HPEFileTrackingVO hpeftSearchVO, SessionHelper sessionHelper) {
		logger.info(LoggerConstants.methodStartLevel());
		List<HPEFTFailedFileListDO> searchList = null;

		try {
			logger.debug("In HPEFileTrackManager: searchFailedDailyFileProcesing: -START");

			HPEFileTrackHelper hpeFileTrackHelper = new HPEFileTrackHelper();
 
			
			hpeftSearchVO.setSearchSubmitterId(hpeftSearchForm.getSearchSubmitterId());
			hpeftSearchVO.setSourceId(hpeftSearchForm.getSourceId());
			String encType = hpeftSearchForm.getStatus().substring(0, 1);
			String spltFleStatusTemp = hpeftSearchForm.getStatus().substring(1);
			logger.debug("enctype is:" + encType + " split file status is:: " + spltFleStatusTemp);
			hpeftSearchVO.setEncType(encType);
			hpeftSearchForm.setSplitFileStatus(splitFileStatusConvert(spltFleStatusTemp));
			hpeftSearchVO.setSplitFileStatus(hpeftSearchForm.getSplitFileStatus());
			int dateYrmo = hpeftSearchForm.getDateYRMO() + 1;
			logger.debug("dateYrmo is:::" + dateYrmo);
			hpeftSearchVO.setDateYRMO(String.valueOf(dateYrmo));

			// This is to store value in session object - start 
			String submitterId = hpeftSearchForm.getSearchSubmitterId();
			String dateYearMonth = String.valueOf(dateYrmo);
			String sourceId = hpeftSearchForm.getSourceId();
			String  fileDsbMgmtHLFailed = hpeftSearchForm.getFileDsbMgmtHL();
			// This is to store value in session object - end 
			
			searchList = context.getFileTrackService().searchFailedListProcessing(conn, hpeftSearchVO);

			hpeftSearchVO.setFileDsbMgmtHL(hpeftSearchForm.getFileDsbMgmtHL());
			hpeftSearchForm.setSec1uiLst(hpeftSearchVO.getSec1uiLst());

			if (!(searchList.isEmpty())) {
				List<HPEFTFailedFileListDO> temp = hpeFileTrackHelper.copySearchToFailedFileListDisplay(searchList);
				logger.debug("HPEFTManager.searchDailyFileProcesing()temp size:" + temp.size());

				logger.debug("Saving searchFailedFileListDetails Object into sessionHelper object  START :" + temp);
				sessionHelper.setAttribute("searchFailedFileListDetails", temp);
				sessionHelper.setAttribute("submitterIdFailedFileSession", submitterId);
				sessionHelper.setAttribute("dateYearMonthFailedSession", dateYearMonth); 
				sessionHelper.setAttribute("sourceIdFailedSession", sourceId);
				sessionHelper.setAttribute("fileDsbMgmtHLFailedSession", fileDsbMgmtHLFailed);
				sessionHelper.setAttribute("encTypeFailedSession", encType);
				sessionHelper.setAttribute("spltFleStatusTempFailedSession", spltFleStatusTemp);
				logger.debug("Saving searchFailedFileListDetails Object into sessionHelper object  END :");
				
				hpeftSearchForm.setFailedFileLst(temp);
				hpeftSearchVO.setFailedFileLst(temp);

			}

			logger.debug("In HPEFileTrackManager: searchFailedDailyFileProcesing: -END");

		} catch (ApplicationException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log.getStream());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return searchList;
	}// searchFailedDailyFileProcesing

	/**
	 * This method is used to nullify Sec1uiLst, MonEncDetailsLst,
	 * DailyFileProcessingLst.
	 * 
	 * @param hpeftSearchForm
	 *            HPEFileTrackingForm
	 * @param hpeftSearchVO
	 *            HPEFileTrackingVO
	 */
	public void nullInitilizer(HPEFileTrackingForm hpeftSearchForm, HPEFileTrackingVO hpeftSearchVO) {
		logger.info(LoggerConstants.methodStartLevel());

		hpeftSearchForm.setSec1uiLst(null);
		// hpeftSearchVO.setSec1uiLst(null);

		hpeftSearchForm.setMonEncDetailsLst(null);
		// hpeftSearchVO.setMonEncDetailsLst(null);

		hpeftSearchForm.setDailyFileProcessingLst(null);
		// hpeftSearchVO.setDailyFileProcessingLst(null);
		logger.info(LoggerConstants.methodEndLevel());

	}// nullInitilizer

	/**
	 * 
	 * @param status
	 * @return statusValue.
	 */
	public String splitFileStatusConvert(String status) {
		logger.info(LoggerConstants.methodStartLevel());
		String statusValue = null;
		if ("I".equals(status)) {
			statusValue = Integer.toString(20);
		} else if ("C".equals(status)) {
			statusValue = Integer.toString(10);
		} else {
			statusValue = Integer.toString(30);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return statusValue;
	}// splitFileStatusConvert

	public String exportFileNames(Connection conn, HPEContext context,
			HPEFileTrackingForm hpeftSearchForm, HPEFileTrackingVO hpeftSearchVO, HttpServletResponse response) {
		logger.info(LoggerConstants.methodStartLevel());
		String csv = null;
		
		try {
			logger.debug("In HPEFileTrackManager: exportFileNames: -START");

			hpeftSearchVO.setSearchSubmitterId(hpeftSearchForm.getSearchSubmitterId());

			hpeftSearchVO.setFileName(hpeftSearchForm.getSearchText());
			hpeftSearchVO.setSearchFromDate(hpeftSearchForm.getSearchFromDate());
			hpeftSearchVO.setSearchToDate(hpeftSearchForm.getSearchToDate());
			hpeftSearchVO.setTypeOfBusiness(hpeftSearchForm.getSearchSummaryType());
			
			logger.debug("hpeftSearchForm.getSearchSubmitterId() is:"+ hpeftSearchForm.getSearchSubmitterId());
			logger.debug("hpeftSearchForm.getFileName() is:"+ hpeftSearchForm.getSearchText());
			logger.debug("hpeftSearchForm.getSearchFromDate() is:"+ hpeftSearchForm.getSearchFromDate());
			logger.debug("hpeftSearchForm.getSearchToDate() is:"+ hpeftSearchForm.getSearchToDate());
			logger.debug("hpeftSearchForm.getSearchSummaryType() is:"+ hpeftSearchForm.getSearchSummaryType());
			
			
			csv = context.getFileTrackService().exportFileNames(conn, hpeftSearchVO, response);

			logger.debug("In HPEFileTrackManager: exportFileNames: -END");

		} catch (ApplicationException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log.getStream());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return csv;

	}
	//This method is added to export dashboard files to csv
	public String exportFileDashBoardNames(Connection conn, HPEContext context,
			HPEFileTrackingForm hpeftSearchForm, HPEFileTrackingVO hpeftSearchVO, HttpServletResponse response) {
		logger.info(LoggerConstants.methodStartLevel());
		String csvFile = null;
		
		try {
			logger.debug("In HPEFileTrackManager: exportFileNames: -START");

			hpeftSearchVO.setSearchSubmitterId(hpeftSearchForm.getSearchSubmitterId());
            hpeftSearchForm.setOrig_intrchg_ctrl_nbr(hpeftSearchForm.getOrig_intrchg_ctrl_nbr());
            hpeftSearchForm.setCustFileId(hpeftSearchForm.getCustFileId()); //IFOX-00416789 - Add customer ICN in File management
			hpeftSearchVO.setFileName(hpeftSearchForm.getSearchText());
			hpeftSearchVO.setSearchFromDate(hpeftSearchForm.getSearchFromDate());
			hpeftSearchVO.setSearchToDate(hpeftSearchForm.getSearchToDate());
			hpeftSearchVO.setTypeOfBusiness(hpeftSearchForm.getSearchSummaryType());
			hpeftSearchVO.setClmType(hpeftSearchForm.getSearchClaimType());
			hpeftSearchVO.setClaimNumber(hpeftSearchForm.getSearchClmRefNbr());
			
			logger.debug("hpeftSearchForm.getSearchSubmitterId() is:"+ hpeftSearchForm.getSearchSubmitterId());
			logger.debug("hpeftSearchForm.getFileName() is:"+ hpeftSearchForm.getSearchText());
			logger.debug("hpeftSearchForm.getFileID() is:"+ hpeftSearchForm.getOrig_intrchg_ctrl_nbr());
			logger.debug("hpeftSearchForm.getSearchFromDate() is:"+ hpeftSearchForm.getSearchFromDate());
			logger.debug("hpeftSearchForm.getSearchToDate() is:"+ hpeftSearchForm.getSearchToDate());
			logger.debug("hpeftSearchForm.getSearchSummaryType() is:"+ hpeftSearchForm.getSearchSummaryType());
			logger.debug("hpeftSearchForm.getSearchClaimType is:"+ hpeftSearchForm.getSearchClaimType());
			logger.debug("hpeftSearchForm.getSearchClaimNumber is:"+ hpeftSearchForm.getSearchClmRefNbr());
			
			
			csvFile = context.getFileTrackService().exportFileDashboardListNames(conn, hpeftSearchVO, response);

			logger.debug("In HPEFileTrackManager: exportFileNames: -END");

		} catch (ApplicationException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log.getStream());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return csvFile;

	}
	
	
	
	public String updateRemarkSectionManger(Connection conn, HPEContext context,
			HPEFileTrackingForm hpeftSearchForm, HPEFileTrackingVO hpeftSearchVO, HttpServletResponse response) {
		logger.info(LoggerConstants.methodStartLevel());
		String csv = null;
		
		try {
			logger.debug("In HPEFileTrackManager: updateRemarkSectionManger: -START");

			hpeftSearchVO.setSearchSubmitterId(hpeftSearchForm.getSearchSubmitterId());

			hpeftSearchVO.setFileName(hpeftSearchForm.getSearchText());
			hpeftSearchVO.setSearchFromDate(hpeftSearchForm.getSearchFromDate());
			hpeftSearchVO.setSearchToDate(hpeftSearchForm.getSearchToDate());
			hpeftSearchVO.setTypeOfBusiness(hpeftSearchForm.getSearchSummaryType());
			
			hpeftSearchVO.setRemarks(hpeftSearchForm.getRemarks());
			hpeftSearchVO.setRemarksFileId(hpeftSearchForm.getRemarksFileId());
			hpeftSearchVO.setSearchSubmitterId(hpeftSearchForm.getSearchSubmitterId());
			
			logger.debug("hpeftSearchForm.getSearchSubmitterId() is:"+ hpeftSearchForm.getSearchSubmitterId());
			logger.debug("hpeftSearchForm.getSearchSummaryType() is:"+ hpeftSearchForm.getSearchSummaryType());
			
			
			csv = context.getFileTrackService().updateRemarkService(conn, hpeftSearchVO, response);

			logger.debug("In HPEFileTrackManager: updateRemarkSectionManger: -END");

		} catch (ApplicationException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log.getStream());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return csv;

	}
	
	
	
	public String retrieveRemarkSectionManger(Connection conn, HPEContext context,
			HPEFileTrackingForm hpeftSearchForm, HPEFileTrackingVO hpeftSearchVO, HttpServletResponse response) {
		logger.info(LoggerConstants.methodStartLevel());
		String csv = null;
		
		try {
			logger.debug("In HPEFileTrackManager: retrieveRemarkService: -START");

			hpeftSearchVO.setSearchSubmitterId(hpeftSearchForm.getSearchSubmitterId());

			hpeftSearchVO.setFileName(hpeftSearchForm.getSearchText());
			hpeftSearchVO.setSearchFromDate(hpeftSearchForm.getSearchFromDate());
			hpeftSearchVO.setSearchToDate(hpeftSearchForm.getSearchToDate());
			hpeftSearchVO.setTypeOfBusiness(hpeftSearchForm.getSearchSummaryType());
			
			hpeftSearchVO.setRemarks(hpeftSearchForm.getRemarks());
			hpeftSearchVO.setRemarksFileId(hpeftSearchForm.getRemarksFileId());
			hpeftSearchVO.setSearchSubmitterId(hpeftSearchForm.getSearchSubmitterId());
			
			logger.debug("hpeftSearchForm.getSearchSubmitterId() is:"+ hpeftSearchForm.getSearchSubmitterId());
			logger.debug("hpeftSearchForm.getSearchSummaryType() is:"+ hpeftSearchForm.getSearchSummaryType());
			
			
			csv = context.getFileTrackService().retrieveRemarkService(conn, hpeftSearchVO, response);

			logger.debug("In HPEFileTrackManager: retrieveRemarkService: -END");

		} catch (ApplicationException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log.getStream());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return csv;

	}

}
