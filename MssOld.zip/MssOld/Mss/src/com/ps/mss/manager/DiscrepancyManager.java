/*
 * Created on Sep 25, 2007
 * $Id: DiscrepancyManager.java,v 1.1 2014/06/26 07:54:57 praveen Exp $
 *
 */
package com.ps.mss.manager;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.DiscrepancyService;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.DiscrepancyDashBoardVO;
import com.ps.mss.model.DiscrepancyDetailVOList;
import com.ps.mss.model.DiscrepancyListVO;
import com.ps.mss.model.DiscrepancySummaryVOList;
import com.ps.mss.model.DiseaseGroupVOList;
import com.ps.mss.model.FilterVO;

/**
 * @author deepak
 *
 */
public class DiscrepancyManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(DiscrepancyManager.class);
	/**
	 * This method calls isExportDiscDetailRequestValid() of DiscrepancyService to get total number of records for export.
	 * @author hemant
	 * @param dbId
	 * @param filterVO
	 * @param discrpMap
	 * @return "TRUE" or Max valid Number of records to show  
	 * @throws ApplicationException
	 */
	public static String isExportDiscDetailRequestValid(String dbId, FilterVO filterVO, Map discrpMap, Map planmap)throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		DiscrepancyService disc = new DiscrepancyService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return disc.isExportDiscDetailRequestValid(filterVO,discrpMap,planmap);		//IFOX-00431034 :: All-Plans in Discrepancy Drop down
	}
	
	/**
	 * The <code>getDiscrepancyList</code> returns list (Ten or less then ten) of Discrepancies based on search criteria and move .
	 * @author Deepak
	 * 
	 * @param filterVO : Contains search criteria that apply on resulted records.
	 * @param discMap  : Contains DiscrepancyDetailVO corresponding to first and last row on ui.  
	 * @param move     : This contains first,last,next and previous .
	 * @param dbId     : Database Id.	 
	 * @param planMap  : This contains list of plan accessible to user	
	 * @param searchType : This contians plan,year and month use to show demographic info on beneficiary Detial.
	 * @param discrpArrMap : This contains Map for metadata.
	 * @return list of discrepancies : list of Ten or less then ten records.
	 * @throws Exception
	 */
	public static DiscrepancyDetailVOList getDiscrepancyList(FilterVO filterVO, Map discMap, String move, String dbId, Map planMap, String searchType,String menuName, boolean hasWriteOffService) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		DiscrepancyService disc = new DiscrepancyService(dbId);
		Map discrpArrMap = MasterManager.getDiscrpArrMap();
		Map adjReasonMap = MasterManager.getAdjReasonMap();
		logger.info(LoggerConstants.methodEndLevel());
		return disc.getDiscrepancyList(filterVO, discMap, move, planMap, searchType, discrpArrMap, menuName, adjReasonMap, hasWriteOffService);
	}
	
	/**
	 * Function getDiscrepancyDashBoard find discrepancy dashboard detail base on searchType and search criteria.
	 * @param filterVO
	 * @param custPlanMap
	 * @param searchType
	 * @param discrepancyDashBoardStatus
	 * @param menuName
	 * @param dbId
	 * @return
	 * @throws ApplicationException
	 */
	public static DiscrepancyDashBoardVO [] getDiscrepancyDashBoard(FilterVO filterVO, Map custPlanMap, String searchType, List discrepancyDashBoardStatus, String menuName , String dbId) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		DiscrepancyService disc = new DiscrepancyService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return disc.getDiscrepancyDashBoard(filterVO,custPlanMap,searchType,discrepancyDashBoardStatus,menuName);
	}
	
	/**
	 * Function getDiscrepancySummary find discrepancy Summary for partc/partD .
	 * @param filterVO
	 * @param searchType
	 * @param partName
	 * @param plansMap
	 * @param dbId
	 * @return
	 * @throws ApplicationException
	 */
	public static DiscrepancySummaryVOList getDiscrepancySummary(FilterVO filterVO, String searchType, String partName, Map plansMap, String dbId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		DiscrepancyService disc = new DiscrepancyService(dbId);
		Map discrpArrMap = MasterManager.getDiscrpArrMap();
		logger.info(LoggerConstants.methodEndLevel());
		return disc.getDiscrepancySummary(filterVO,searchType,partName ,plansMap,discrpArrMap);
	}
	
	/**
	 * Function diseaseGroupDetail find diseaseGroup Detail for partC/partD
	 * @param filterVO
	 * @param string
	 * @param planValue
	 * @param planMap
	 * @param activeDataBaseName
	 * @return
	 * @throws ApplicationException
	 */
	public static DiseaseGroupVOList diseaseGroupDetail(FilterVO filterVO, String cmsValue, String planValue, String dbId, Map planMap) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		DiscrepancyService service = new DiscrepancyService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return service.diseaseGroupDetail(filterVO, cmsValue, planValue,planMap);
	
	}
	/**
	 * 
	 * @author rakesh
	 * @param filterVO
	 * @param pageName
	 * @param menuName
	 * @param dbId
	 * @return
	 * @throws ApplicationException
	 */
	public static String getSearchCreiteriaHeader(FilterVO filterVO, String pageName, String menuName, String dbId) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		DiscrepancyService service = new DiscrepancyService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return service.getSearchCreiteriaHeader(filterVO, pageName, menuName);
	}
	
	public static int updateDiscrepancyStatus(DiscrepancyListVO discrepancyVO, String currentUserId, boolean hasBothDiscPermission, String dbId) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		DiscrepancyService service = new DiscrepancyService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return service.updateDiscrepancyStatus(discrepancyVO, currentUserId, hasBothDiscPermission);
	}
	
	public static int updateDiscrepancyWriteOff(DiscrepancyListVO discrepancyListVO, String currentUserId, String dbId) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		DiscrepancyService service = new DiscrepancyService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return service.updateDiscrepancyWriteOff(discrepancyListVO, currentUserId);
	}
	
	public static int cancelWriteoffRequest(DiscrepancyListVO writeOffVO, String currentUserId, String dbId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		DiscrepancyService service = new DiscrepancyService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return service.cancelWriteoffRequest(writeOffVO, currentUserId); 
	}
}
