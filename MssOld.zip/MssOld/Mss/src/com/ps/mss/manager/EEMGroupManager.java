/*
 * $Id: EEMGroupManager.java,v 1.1 2014/06/26 07:54:58 praveen Exp $
 */
package com.ps.mss.manager;

import java.io.PrintStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.EEMGrpSvcDao;
import com.ps.mss.dao.model.EMGrpAddressVO;
import com.ps.mss.dao.model.EMGrpNameVO;
import com.ps.mss.dao.model.EMGrpVO;
import com.ps.mss.model.EEMContext;
import com.ps.mss.model.EMGroupFilterVO;
import com.ps.mss.model.EMGrpSearchListVO;
import com.ps.mss.model.Pagination;
import com.ps.mss.web.forms.EEMGroupForm;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.web.helper.EEMGroupHelper;
import com.ps.util.DateUtil;
import com.ps.text.DateFormatter;

/**
 * @author nenne.robert
 */
public class EEMGroupManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(EEMGroupManager.class);

	PrintStream log;
	
	public EEMGroupManager() {
		this(System.out);
	}
	public EEMGroupManager(PrintStream log) {
		this.log = log;
	}
	
	public void groupSearch(Connection conn, SessionHelper sessionHelper,
			EEMContext context, EEMGroupForm form, Pagination pagination,
			String move) throws SQLException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
			
		EMGroupFilterVO filter = new EMGroupFilterVO();
		filter.setCustomerId(sessionHelper.getMfId());
		filter.setGrpId(form.getSearchGroupID());
		filter.setSupplGrpId(form.getSearchSupplGroupID());
		filter.setGrpStartDate(form.getSearchStartDate());
		
		EEMGroupHelper.clearForm(form);
		context.setGroupSearchResult(null);
		context.setGroupSearchAddrResult(null);
		
		EEMGrpSvcDao dao = new EEMGrpSvcDao();
		ArrayList lstGroup = dao.getPagedList(conn,filter,pagination, move);
		form.setSearchResults(lstGroup);
		form.setSearchItemSelected(-1);
		
		// Set pagination details
		EMGrpSearchListVO[] arr = new EMGrpSearchListVO[lstGroup.size()];
		arr = (EMGrpSearchListVO[])lstGroup.toArray(arr);		
		pagination.setPaginationResults(move,arr);
		
		if (lstGroup.size() > 0) {
			context.setGroupSearchResult(lstGroup);
			
			EMGrpSearchListVO item = (EMGrpSearchListVO)lstGroup.get(0);

			EMGrpVO grpDtl = dao.getGroupDetail(conn,sessionHelper.getMfId(),item.getGroupId());
			if (grpDtl == null) 
				throw new Exception("Group Lookup Failed " + item.getGroupId());
			
			form.setGroupId(grpDtl.getGrpId());
			form.setGrpStartDate(grpDtl.getGrpStartDate());
			form.setGrpEndDate(grpDtl.getGrpEndDate());
			form.setSupplGrpId(grpDtl.getSupplGrpId());
			form.setCreateTime(grpDtl.getCreateTime());
			form.setCreateUserId(grpDtl.getCreateUserid());
			form.setLastUpdtTime(grpDtl.getLastUpdtTime());
			form.setLastUpdtUserId(grpDtl.getLastUpdtUserid());
			form.setSearchItemSelected(0);

			EMGrpNameVO grpName = dao.getLatestGroupName(conn,sessionHelper.getMfId(),item.getGroupId());
			if (grpName == null) 
				throw new Exception("Group name Lookup Failed " + item.getGroupId());
			
			form.setPrevGrpName(grpName.getGroupName());
			form.setGrpName(grpName.getGroupName());
			form.setGrpNameStartDate(grpName.getGrpnameStartDate());
			form.setGrpNameEndDate(grpName.getGrpnameEndDate());
			form.setGrpNameLastUpdtTime(grpName.getLastUpdtTime());
			form.setGrpNameLastUpdtUserId(grpName.getLastUpdtUserid());
			
			form.setGrpAddrItemSelected(-1);
			ArrayList lstAddr = dao.getGrpAddrList(conn,sessionHelper.getMfId(),item.getGroupId());
			form.setLstGrpAddresses(lstAddr);
			
			if (lstAddr.size() > 0) {
				context.setGroupSearchAddrResult(lstAddr);
				
				EMGrpAddressVO addr = (EMGrpAddressVO)lstAddr.get(0);
				
				form.setAddrType(addr.getGrpAddressType());
				form.setAddrAttention(addr.getAttentionName());
				form.setAddrLine1(addr.getAddress1());
				form.setAddrLine2(addr.getAddress2());
				form.setAddrLine3(addr.getAddress3());
				form.setAddrCity(addr.getCity());
				form.setAddrState(addr.getStateCd());
				form.setAddrZip(addr.getZipCd());
				form.setAddrCountry(addr.getCountryCd());
				form.setOfficePhone(addr.getOfficePhoneNbr());
				form.setFaxNbr(addr.getFaxNbr());
				form.setAddrCreateTime(addr.getCreateTime());
				form.setAddrCreateUserId(addr.getCreateUserid());
				form.setAddrLastUpdtTime(addr.getLastUpdtTime());
				form.setAddrLastUpdtUserId(addr.getLastUpdtUserid());
				
				form.setGrpAddrItemSelected(0);
			}	
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void getGroupDetail(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMGroupForm form) throws SQLException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMGrpSvcDao dao = new EEMGrpSvcDao();
		
		int newItemIdx = form.getNewSelectedRow();
		ArrayList lstGroup = context.getGroupSearchResult(); 
		form.setSearchResults(lstGroup);
		
		EEMGroupHelper.clearGroup(form);
		
		if (newItemIdx < lstGroup.size()) {
			
			EMGrpSearchListVO item = (EMGrpSearchListVO)lstGroup.get(newItemIdx);

			EMGrpVO grpDtl = dao.getGroupDetail(conn,sessionHelper.getMfId(),item.getGroupId());
			if (grpDtl == null) 
				throw new Exception("Group Lookup Failed " + item.getGroupId());
			
			form.setGroupId(grpDtl.getGrpId());
			form.setGrpStartDate(grpDtl.getGrpStartDate());
			form.setGrpEndDate(grpDtl.getGrpEndDate());
			form.setSupplGrpId(grpDtl.getSupplGrpId());
			form.setCreateTime(grpDtl.getCreateTime());
			form.setCreateUserId(grpDtl.getCreateUserid());
			form.setLastUpdtTime(grpDtl.getLastUpdtTime());
			form.setLastUpdtUserId(grpDtl.getLastUpdtUserid());
			form.setSearchItemSelected(newItemIdx);

			EMGrpNameVO grpName = dao.getLatestGroupName(conn,sessionHelper.getMfId(),item.getGroupId());
			if (grpName == null) 
				throw new Exception("Group name Lookup Failed " + item.getGroupId());
			
			form.setPrevGrpName(grpName.getGroupName());
			form.setGrpName(grpName.getGroupName());
			form.setGrpNameStartDate(grpName.getGrpnameStartDate());
			form.setGrpNameEndDate(grpName.getGrpnameEndDate());
			form.setGrpNameLastUpdtTime(grpName.getLastUpdtTime());
			form.setGrpNameLastUpdtUserId(grpName.getLastUpdtUserid());
			
			form.setGrpAddrItemSelected(-1);
			context.setGroupSearchAddrResult(null);
			ArrayList lstAddr = dao.getGrpAddrList(conn,sessionHelper.getMfId(),item.getGroupId());
			form.setLstGrpAddresses(lstAddr);
			
			if (lstAddr.size() > 0) {
				context.setGroupSearchAddrResult(lstAddr);
				
				EMGrpAddressVO addr = (EMGrpAddressVO)lstAddr.get(0);
				
				form.setAddrType(addr.getGrpAddressType());
				form.setAddrAttention(addr.getAttentionName());
				form.setAddrLine1(addr.getAddress1());
				form.setAddrLine2(addr.getAddress2());
				form.setAddrLine3(addr.getAddress3());
				form.setAddrCity(addr.getCity());
				form.setAddrState(addr.getStateCd());
				form.setAddrZip(addr.getZipCd());
				form.setAddrCountry(addr.getCountryCd());
				form.setOfficePhone(addr.getOfficePhoneNbr());
				form.setFaxNbr(addr.getFaxNbr());
				form.setAddrCreateTime(addr.getCreateTime());
				form.setAddrCreateUserId(addr.getCreateUserid());
				form.setAddrLastUpdtTime(addr.getLastUpdtTime());
				form.setAddrLastUpdtUserId(addr.getLastUpdtUserid());
				
				form.setGrpAddrItemSelected(0);
			}	
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void getGroupAddrDetail(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMGroupForm form) throws SQLException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMGrpSvcDao dao = new EEMGrpSvcDao();
		
		ArrayList lstGroup = context.getGroupSearchResult(); 
		form.setSearchResults(lstGroup);
		
		int newItemIdx = form.getNewSelectedAddrRow();
		ArrayList lstGrpAddr = context.getGroupSearchAddrResult(); 
		form.setLstGrpAddresses(lstGrpAddr);
		
		if (newItemIdx < lstGrpAddr.size()) {
			
			EMGrpAddressVO addr = (EMGrpAddressVO)lstGrpAddr.get(newItemIdx);

			form.setAddrType(addr.getGrpAddressType());
			form.setAddrAttention(addr.getAttentionName());
			form.setAddrLine1(addr.getAddress1());
			form.setAddrLine2(addr.getAddress2());
			form.setAddrLine3(addr.getAddress3());
			form.setAddrCity(addr.getCity());
			form.setAddrState(addr.getStateCd());
			form.setAddrZip(addr.getZipCd());
			form.setAddrCountry(addr.getCountryCd());
			form.setOfficePhone(addr.getOfficePhoneNbr());
			form.setFaxNbr(addr.getFaxNbr());
			form.setAddrCreateTime(addr.getCreateTime());
			form.setAddrCreateUserId(addr.getCreateUserid());
			form.setAddrLastUpdtTime(addr.getLastUpdtTime());
			form.setAddrLastUpdtUserId(addr.getLastUpdtUserid());
			
			form.setGrpAddrItemSelected(newItemIdx);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void groupSave(Connection conn, SessionHelper sessionHelper, EEMGroupForm form) throws SQLException, Exception {
		logger.info(LoggerConstants.methodStartLevel());
		
		String userId = sessionHelper.getUserId();
		
		DateUtil du = new DateUtil();
		String dts = du.getDB2DTS();;
		
		boolean add = false;
		
		EMGrpVO grpDtl = new EMGrpVO();
		grpDtl.setCustomerId(sessionHelper.getMfId());
		grpDtl.setGrpId(form.getGroupId());
		grpDtl.setGrpStartDate(form.getGrpStartDate());
		grpDtl.setGrpEndDate(form.getGrpEndDate());
		grpDtl.setSupplGrpId(form.getSupplGrpId());
		grpDtl.setLastUpdtTime(dts);
		grpDtl.setLastUpdtUserid(userId);

		EMGrpNameVO grpName = new EMGrpNameVO();		
		grpName.setCustomerId(sessionHelper.getMfId());
		grpName.setGrpId(form.getGroupId());
		grpName.setGroupName(form.getGrpName());
		grpName.setLastUpdtTime(dts);
		grpName.setLastUpdtUserid(userId);
		
		if (form.getCreateTime().equals("")) {
			add = true;
			grpDtl.setCreateTime(dts);
			grpDtl.setCreateUserid(userId);
			
			grpName.setGrpnameStartDate(DateFormatter.reFormat(dts,DateFormatter.DB2_TIMESTAMP,DateFormatter.YYYYMMDD));
			grpName.setGrpnameEndDate("99999999");
		}
		
		
		boolean inTrans = false;
		boolean prevAutoCommit = conn.getAutoCommit();
		try {
			conn.setAutoCommit(false);
			inTrans = true;
			EEMGrpSvcDao dao = new EEMGrpSvcDao();
			if (add) {
				int sqlCnt = dao.insertGroupDetail(conn,grpDtl);
				if (sqlCnt != 1)
					throw new Exception("Error Adding Group");
				sqlCnt = dao.insertGroupName(conn,grpName);
				if (sqlCnt != 1)
					throw new Exception("Error Adding Group Name");
			}
			conn.commit();
			inTrans = false;
			
			if (add) {
				form.setCreateTime(grpDtl.getCreateTime());
				form.setCreateUserId(grpDtl.getCreateUserid());				
			}
			form.setLastUpdtTime(grpDtl.getLastUpdtTime());
			form.setLastUpdtUserId(grpDtl.getLastUpdtUserid());

			form.setPrevGrpName(grpName.getLastUpdtTime());
			form.setGrpNameStartDate(grpName.getGrpnameStartDate());
			form.setGrpNameEndDate(grpName.getGrpnameEndDate());
			form.setGrpNameLastUpdtTime(grpName.getLastUpdtTime());
			form.setGrpNameLastUpdtUserId(grpName.getLastUpdtUserid());
			
		} finally {
			if (inTrans) {
				try {
					conn.rollback();
				} catch(Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
				}
			}
			try {
				conn.setAutoCommit(prevAutoCommit);
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

}
