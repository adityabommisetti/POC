/*
 * Created on Sep 25, 2007
 * $Id: DiscrepancyManager.java,v 1.1 2014/06/26 07:54:57 praveen Exp $
 *
 */
package com.ps.mss.manager;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.DiscrepancyService;
import com.ps.mss.businesslogic.WorkQueueService;
import com.ps.mss.dao.impl.WorkQueueDaoImpl;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.DiscrepancyDetailVOList;
import com.ps.mss.model.FilterVO;


public class WorkQueueManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(WorkQueueManager.class);
	
	public static String isExportDiscDetailRequestValid(String dbId, FilterVO filterVO, Map discrpMap, Map planmap)throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		DiscrepancyService disc = new DiscrepancyService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return disc.isExportDiscDetailRequestValid(filterVO,discrpMap,planmap);		//IFOX-00431034 :: All-Plans in Discrepancy Drop down
	}
	public static List getUsersList(String custId, String dbId, Map planMap)throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		WorkQueueService disc = new WorkQueueService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return disc.getUsersList(custId,planMap);
	}
	
	
	public static DiscrepancyDetailVOList getDiscrepancyList(int maxExportCount,List discrepancyDetailVOList, FilterVO filterVO, Map discMap, String move, String dbId, Map planMap, String searchType,String menuName, boolean hasWriteOffService) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		WorkQueueService disc = new WorkQueueService(dbId);
		Map discrpArrMap = MasterManager.getDiscrpArrMap();
		Map adjReasonMap = MasterManager.getAdjReasonMap();
		logger.info(LoggerConstants.methodEndLevel());
		return disc.getDiscrepancyList(maxExportCount,discrepancyDetailVOList,filterVO, discMap, move, planMap, searchType, discrpArrMap, menuName, adjReasonMap, hasWriteOffService);
	}
	
	public static int getDiscrepancyListCount(List discrepancyDetailVOList, FilterVO filterVO, Map discMap, String move, String dbId, Map planMap, String searchType,String menuName, boolean hasWriteOffService) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		WorkQueueDaoImpl discDao = new WorkQueueDaoImpl(dbId);
		Map discrpArrMap = MasterManager.getDiscrpArrMap();
		Map adjReasonMap = MasterManager.getAdjReasonMap();
		logger.info(LoggerConstants.methodEndLevel());
		return discDao.getDiscrepancyListCount(discrepancyDetailVOList,filterVO, discMap, move, planMap, searchType, discrpArrMap, menuName, adjReasonMap, hasWriteOffService);
	}
	
	
	
	public static String getSearchCreiteriaHeader(FilterVO filterVO, String pageName, String menuName, String dbId) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		DiscrepancyService service = new DiscrepancyService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return service.getSearchCreiteriaHeader(filterVO, pageName, menuName);
	}
	
	
		public static int updateAssignTask(List discrepancyDetailVOList, Map planMap,FilterVO filterVO, String dbId, String selected,Map discMap,
			String reassign, String user, String comment, boolean hasBothDiscPermission) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		WorkQueueService disc = new WorkQueueService(dbId);
		Map discrpArrMap = MasterManager.getDiscrpArrMap();
		Map adjReasonMap = MasterManager.getAdjReasonMap();
		logger.info(LoggerConstants.methodEndLevel());
		return disc.assignTask(discrepancyDetailVOList,planMap,filterVO, discrpArrMap, adjReasonMap, selected,discMap,reassign,user,comment,hasBothDiscPermission);
	}
	
	
}
