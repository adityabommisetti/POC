/*
 * $Id: EEMManager.java,v 1.1 2014/06/26 07:54:57 praveen Exp $
 */
package com.ps.mss.manager;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.model.EEMContext;


public class EEMManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(EEMManager.class);
	
	static ModuleLog log = new ModuleLog("EEMManager");

	public static EEMContext getContext(HttpSession session) {
		logger.info(LoggerConstants.methodStartLevel());
		EEMContext context = (EEMContext)session.getAttribute(EEMConstants.EEM_CONTEXT);
		if (context == null) {
			context = new EEMContext();
			session.setAttribute(EEMConstants.EEM_CONTEXT,context);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return context;
	}
	
}
