/*
 * $Id: ChartManager.java,v 1.1 2014/08/20 17:13:58 jacob Exp $
 */
package com.ps.mss.manager;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;
import com.ps.mss.framework.ChartConstants;
import com.ps.mss.model.HPEContext;

public class ChartManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(ChartManager.class);
	
	static ModuleLog log = new ModuleLog("ChartManager");

	public static HPEContext getContext(HttpSession session) {
		logger.info(LoggerConstants.methodStartLevel());
		HPEContext context = (HPEContext)session.getAttribute(ChartConstants.HPE_CONTEXT);
		if (context == null) {
			context = new HPEContext();
			session.setAttribute(ChartConstants.HPE_CONTEXT,context);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return context;
	}
}
