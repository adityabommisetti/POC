/*
 * $Id: LettersManager.java,v 1.1 2014/06/26 07:55:00 praveen Exp $
 */
package com.ps.mss.manager;

import java.sql.Connection;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;
import com.ps.mss.model.LettersContext;
import com.ps.mss.model.LettersDashboardList;
import com.ps.mss.model.LettersItem;
import com.ps.mss.model.LettersListItem;
import com.ps.mss.model.LettersFilter;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.LettersConstants;
import com.ps.mss.businesslogic.LettersService;


/**
 * @author levin.alex
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class LettersManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(LettersManager.class);
	
	static ModuleLog log = new ModuleLog("LettersManager");

	public static LettersContext getContext(HttpSession session, String region) {
		logger.info(LoggerConstants.methodStartLevel());
		HashMap context = (HashMap)session.getAttribute(LettersConstants.LETTERS_CONTEXT);
		if (context == null) {
			context = new HashMap();
			session.setAttribute(LettersConstants.LETTERS_CONTEXT,context);
		}
		LettersContext lc = (LettersContext)context.get(region);
		if (lc == null) {
			lc = new LettersContext();
			context.put(region,lc);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return lc;
	}
	
    /**
 	 * TAB	 : 	Letter List
	 * SUBTAB:	Letter Details
	 * This will end up querying db to populate the following:
	 * 		+ Letter List - the 10 items on the list
	 *  	+ Letter Details portion 
	 *  	+ Letter Data portion 
     * @param filterVO
     * @param string
     * @param activeDataBaseName
     * @return
     * @throws ApplicationException
     */
    public static LettersDashboardList getLettersDashboardList(Connection conn,LettersContext context, LettersFilter filterVO, String move) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
        LettersService lettersService = new LettersService();
        logger.info(LoggerConstants.methodEndLevel());
		return lettersService.getLettersDashboardList(conn, context, filterVO, move);
    }
	
    /**
 	 * TAB	 : 	Letter List
	 * SUBTAB:	Letter Details
	 * This will end up querying db to populate the following:
	 * 		+ Letter List - the 10 items on the list
	 *  	+ Letter Details portion 
	 *  	+ Letter Data portion 
     * @param filterVO
     * @param string
     * @param activeDataBaseName
     * @return
     * @throws ApplicationException
     */
    public static LettersListItem getLettersListItem(Connection conn,LettersContext context, LettersFilter filterVO, String move) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
        LettersService lettersService = new LettersService();
        logger.info(LoggerConstants.methodEndLevel());
		return lettersService.getLettersListItem(conn, context, filterVO, move);
    }

    /**
     * Add method for just the letter data
  	 * Add methods for status updates
     */
    
    /**
  	 * TAB	 : 	Letter List
	 * SUBTAB:	Letter Details
	 * This will end up querying db to populate the following:
	 *  	+ Letters Data portion
	 * @param conn
     * @param context
     * @param lettersItem
     * @return LettersListItem
     * @throws ApplicationException
     */
    public static LettersListItem getLettersDataItem(Connection conn, LettersContext context, LettersItem lettersItem) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
        LettersService lettersService = new LettersService();
        logger.info(LoggerConstants.methodEndLevel());
		return lettersService.getLettersDataItem(conn, lettersItem);
    }

    public static boolean updateLettersStatus(Connection conn, LettersItem lettersItem, String updateUserId, String newStatus, String newDeleteInd) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
        LettersService lettersService = new LettersService();
        logger.info(LoggerConstants.methodEndLevel());
		return lettersService.updateLettersStatus(conn, lettersItem, updateUserId, newStatus, newDeleteInd);
    }

    public static int massUpdateLettersStatus(Connection conn, LettersFilter criteria, String updateUserId) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
        LettersService lettersService = new LettersService();
        logger.info(LoggerConstants.methodEndLevel());
		return lettersService.massUpdateLettersStatus(conn, criteria, updateUserId);
    }

    public static int lettersGenerateRequest(Connection conn, String mfId, String siteId, String region, String requestUserId) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
        LettersService lettersService = new LettersService();
        logger.info(LoggerConstants.methodEndLevel());
		return lettersService.lettersGenerateRequest(conn, mfId, siteId, region, requestUserId);
    }
    
}
