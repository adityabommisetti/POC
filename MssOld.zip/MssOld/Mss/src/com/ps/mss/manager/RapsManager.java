/*
 * $Id: RapsManager.java,v 1.1 2014/06/26 07:54:57 praveen Exp $
 */
package com.ps.mss.manager;

import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;

import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;
import com.ps.mss.model.RapsClusterForm;
import com.ps.mss.model.RapsContext;
import com.ps.mss.model.RapsDashBoard;
import com.ps.mss.model.RapsClaimDashBoard;
import com.ps.mss.model.RapsDetailPage;
import com.ps.mss.model.RapsClaimsDetailPage;
import com.ps.mss.model.RapsClaimDetailItem;
import com.ps.mss.model.RapsDetailItem;
import com.ps.mss.model.RapsErrorsHistoryItem;
import com.ps.mss.model.RapsStatisticItem;
import com.ps.mss.model.RapsWorkflowPage;
import com.ps.mss.model.RapsErrorsItem;
import com.ps.mss.model.RapsErrorsPage;
import com.ps.mss.model.RapsFilter;
import com.ps.mss.model.RapsDetailInfo;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.businesslogic.RapsService;
import com.ps.util.NameValuePair;
import com.ps.util.StringUtil;
import com.ps.mss.framework.RapsConstants;
import com.ps.util.DateUtil;


/**
 * @author indrapradja.adriana
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class RapsManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(RapsManager.class);
	static ModuleLog log = new ModuleLog("RapsManager");
    /**
	 * This function call the function of persistence layer
	 * @param filterVO : this Vo contain all the criteria to be use in searching.
	 * @param searchType : On the  basis of this value we decide search criteria.
	 * @param pdeDashBoardStatus
	 * @param dbId
	 * @return
	 * @throws ApplicationException
	 */
	public static RapsDashBoard[] getRapsDashBoard(Connection conn, RapsContext context, RapsFilter filterVO, List expandedList) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		RapsService rapsService = new RapsService(); 
		logger.info(LoggerConstants.methodEndLevel());
		return rapsService.getRapsDashBoard(conn, context, filterVO, expandedList);
	}

    /**
 	 * TAB	 : 	RAPS Summary
	 * SUBTAB:	RASP Details
	 * This will end up querying db to populate the following:
	 * 		+ RAPS List - the 10 items on the list
	 *  	+ RAPS Details portion 
	 *  	+ RAPS History portion 
     * @param filterVO
     * @param planMap
     * @param string
     * @param pdeEventDetailStatus
     * @param activeDataBaseName
     * @return
     * @throws ApplicationException
     */
    public static RapsDetailPage getRapsDetailPage(Connection conn,RapsContext context, RapsFilter filterVO, String move, Map planMap) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
        RapsService rapsService = new RapsService();
        logger.info(LoggerConstants.methodEndLevel());
		return rapsService.getRapsDetailPage(conn, context, filterVO, move);
    }

    /**
  	 * TAB	 : 	RAPS Summary
	 * SUBTAB:	RASP Details
	 * This will end up querying db to populate the following:
	 *  	+ RAPS Details portion 
	 *  	+ RAPS History portion 
    * @param filterVO
     * @param planMap
     * @param string
     * @param pdeEventDetailStatus
     * @param activeDataBaseName
     * @return
     * @throws ApplicationException
     */
    public static RapsDetailPage getRapsDetail(Connection conn, RapsContext context, RapsDetailItem rapsDetailItem) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
        RapsService rapsService = new RapsService();
        logger.info(LoggerConstants.methodEndLevel());
		return rapsService.getRapsDetail(conn, context, rapsDetailItem);
    }

    /**
  	 * TAB	 : 	RAPS Summary
	 * SUBTAB:	RASP Details
     * Called when delete button is pressed.
     * @param conn
     * @param rapsDetailItem
     * @param errMsg : error message to be displayed on screen, in case there's an error.
     * @return
     * @throws ApplicationException
     */
    public static boolean deleteRapsDetail(Connection conn, RapsClusterForm entry, RapsDetailInfo rapsdetailInfo, StringBuffer errMsg) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
        RapsService rapsService = new RapsService();
        logger.info(LoggerConstants.methodEndLevel());
		return rapsService.deleteRapsDetail(conn, entry, rapsdetailInfo, errMsg);
    }

    /**
   	 * TAB	 : 	Claims Summary
	 * SUBTAB:	Claim Details
	 * This is to get ALL of the informations for this page, including the Claims list
     * @param conn the database connection
     * @param context Raps context
     * @param filterVO filter for Claims Detail screen.
     * @param pdeEventDetailStatus
     * @param activeDataBaseName
     * @return RapsClaimsDetailPage that containts the Claims List, Claim Details, Additional Claim Information and Claim History
     * @throws ApplicationException
     */
    public static RapsClaimsDetailPage getClaimsDetailPage(Connection conn, RapsContext context, RapsFilter filterVO, String move, Map planMap) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
        RapsService rapsService = new RapsService();
        logger.info(LoggerConstants.methodEndLevel());
		return rapsService.getClaimsDetailPage(conn, context, filterVO, move);
    }

    /**
   	 * TAB	 : 	Claims Summary
	 * SUBTAB:	Claim Details
	 * This is to get detail informations for this page. It is NOT retrieving the Claims list
     * @param conn the database connection
     * @param context Raps context
     * @param rapsDetailItem RapsClaimDetailItem object of the selected row
     * @param isItPopup true if it's called to paint the claim detail popup screen.
     * @return RapsClaimsDetailPage that containts the Claim Details, Additional Claim Information and Claim History
     * @throws ApplicationException
     */
    public static RapsClaimsDetailPage getRapsClaimDetail(Connection conn, RapsContext context, RapsClaimDetailItem rapsDetailItem, boolean isItPopup) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
        RapsService rapsService = new RapsService();
        logger.info(LoggerConstants.methodEndLevel());
		return rapsService.getRapsClaimDetail(conn, context, rapsDetailItem, isItPopup);
    }
    /**
     * @param filterVO
     * @param planMap
     * @param string
     * @param pdeEventDetailStatus
     * @param activeDataBaseName
     * @return
     * @throws ApplicationException
     */
    public static RapsWorkflowPage getWorkflowPage(Connection conn, RapsContext context, RapsFilter filterVO, String searchType, String move, Map planMap, String custName) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
        RapsService rapsService = new RapsService();
        logger.info(LoggerConstants.methodEndLevel());
		return rapsService.getWorkflowPage(conn, context, filterVO, searchType, move);
    }
   
    /**
	 * This function call the function of persistence layer
	 * @param filterVO : this Vo contain all the criteria to be use in searching.
	 * @param searchType : On the  basis of this value we decide search criteria.
	 * @param pdeDashBoardStatus
	 * @param dbId
	 * @return
	 * @throws ApplicationException
	 */
	public static RapsClaimDashBoard[] getRapsClaimsDashBoard(Connection conn, RapsContext context, RapsFilter filterVO, List expandedItems) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		RapsService rapsService = new RapsService();
		logger.info(LoggerConstants.methodEndLevel());
		return rapsService.getRapsClaimsDashBoard(conn, context, filterVO, expandedItems);
	}

    /**
	 * This function call the function of persistence layer
	 * @param filterVO : this Vo contain all the criteria to be use in searching.
	 * @param searchType : On the  basis of this value we decide search criteria.
	 * @param pdeDashBoardStatus
	 * @param dbId
	 * @return
	 * @throws ApplicationException
	 */
	public static RapsStatisticItem[] getStatistics(Connection conn, RapsContext context, List expandedList ) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		RapsService rapsService = new RapsService(); 
		logger.info(LoggerConstants.methodEndLevel());
		return rapsService.getStatistics(conn, context, expandedList);
	}
	
	/**
 	 * TAB	 : 	RAPS Summary
	 * SUBTAB:	RAPS Errors
	 * This will end up querying db to populate the following:
	 * 		+ RAPS Errors List - the 10 items on the list
	 *  	+ RAPS Errors Details portion 
	 *  	+ RAPS Errors History portion 
     * @param Connection
     * @param RapsContext
     * @param RapsFilter
     * @param move
     * @param planMap
     * @return RapsErrorsPage
     * @throws ApplicationException
     */
    public static RapsErrorsPage getRapsErrorsPage(Connection conn, RapsContext context, RapsFilter filterVO, String move, Map planMap) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
        RapsService rapsService = new RapsService();
        logger.info(LoggerConstants.methodEndLevel());
		return rapsService.getRapsErrorsPage(conn, context, filterVO, move);
    }
    
    /**
  	 * TAB	 : 	RAPS Summary
	 * SUBTAB:	RAPS Errors
	 * This will end up querying db to populate the following:
	 *  	+ RAPS Error Details portion 
	 *  	+ RAPS Error History portion 
     * @param Connection
     * @param RapsContext
     * @param RapsErrorsItem
     * @return RapsErrorsPage
     * @throws ApplicationException
     */
    public static RapsErrorsPage getRapsErrorsDetail(Connection conn, RapsContext context, RapsErrorsItem rapsErrorsItem) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
        RapsService rapsService = new RapsService();
        logger.info(LoggerConstants.methodEndLevel());
		return rapsService.getRapsErrorsDetail(conn, context, rapsErrorsItem);
    }
    
    public static RapsErrorsHistoryItem[] updateRapsErrorsStatusComment (Connection conn, RapsErrorsItem rapsErrorsItem, String updateUserId, String newStatus, String newComment, boolean changeStatus) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
		RapsService rapsService = new RapsService();
		logger.info(LoggerConstants.methodEndLevel());
		return rapsService.updateRapsErrorsStatusComment(conn, rapsErrorsItem, updateUserId, newStatus, newComment, changeStatus);
	}

	/**
	 * This function returns the number of items for "export all" request for RAPS detail page
	 * @param conn
	 * @param rc
	 * @return
	 * @throws ApplicationException
	 */
	public static String isExportRequestValid(Connection conn, RapsContext rc, String pageName)throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		RapsService rapsService = new RapsService();
		logger.info(LoggerConstants.methodEndLevel());
		return rapsService.isExportRapsDetailRequestValid(conn, rc, pageName);
	}
	public static boolean validateCluster(Connection conn, RapsContext context, StringBuffer errorMsg) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		RapsClusterForm entry = context.getRapsEntry();
		RapsDetailInfo detail = context.getRapsDetailEntry();
		//Do required fields validation, and valid characters.
		String temp = StringUtil.trimToNull(entry.getPlanId());
		if (temp == null) {
			errorMsg.append("Plan ID is required");
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		NameValuePair [] planMap = context.getPlanNameList();
		int i ;
		for (i = 0; i<planMap.length; i++) {
			if (temp.equals(planMap[i].getName())) 
				break;
		}
		if (i == planMap.length) {//not found
			errorMsg.append("Invalid plan " + temp);
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		
		temp = StringUtil.trimToNull(entry.getHicNbr());
		if (temp == null) {
			errorMsg.append("Hic# is required");
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		if (temp != null && !StringUtil.isAlphaNumeric(temp)) {
			errorMsg.append("Invalid Hic# ");
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		
		temp = StringUtil.trimToNull(entry.getPatientControlNo());
		if (temp != null && !StringUtil.isValidString(temp)) {
			errorMsg.append("Invalid Patient Control # ");
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}

		temp = StringUtil.trimToNull(entry.getFromDate());
		if (temp != null && ! DateUtil.isGoodDate(temp)) {
			errorMsg.append("Invalid From Service Date " + temp);
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		temp = StringUtil.trimToNull(entry.getToDate());
		if (temp != null && ! DateUtil.isGoodDate(temp)) {
			errorMsg.append("Invalid Thru Service Date " + temp);
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		
		//validate provider type
		temp = StringUtil.trimToNull(entry.getProviderType());
		if (temp == null) {
			errorMsg.append("Provider type is required");
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		if (!RapsConstants.PROV_IN_PATIENT.equals(temp) && !RapsConstants.PROV_IN_PATIENT_OTHER.equals(temp) &&
			!RapsConstants.PROV_OUT_PATIENT.equals(temp) && !RapsConstants.PROV_PHYSICIAN.equals(temp)) {
			errorMsg.append("Invalid Provider Type " + temp);
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		
		temp = StringUtil.trimToNull(entry.getDiagCd());
		if (temp == null) {
			errorMsg.append("Diagnosis Code is required");
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		if (temp.length()<3) {
			errorMsg.append("Diagnosis Code has to be at least three characters");
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		if (temp != null && !StringUtil.isAlphaNumeric(temp)) {
			errorMsg.append("Invalid Diagnosis Code ");
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}		
		
		temp = StringUtil.trimToNull(entry.getComments());
		if (temp != null && temp.length() > 255) {
			errorMsg.append("Comment is too long. Maximum length is 255 characters");
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
			
		//Now check for stuff listed in functional spec.
		/* Date:
		 * - When Provider Type is In-Patient, both From and Thru dates must be present, and must not be equial 
		 *   (Out-Patient and Physician allow Thru to be blank, it will then be assumed to equal the From Service Date)
		 * - From is <= Thru (date ordering is correct) 
		 * - Thru is within 31 days of From (Time period is not excessive. Do not enforce for In-Patient.)
		 * - Thru is <= Submission Date (not future-dated)
		 * - From is >= start of the Collection Period (not too late to accept)
		 */
		String fromDate = entry.getFromDate();
		String toDate =entry.getToDate();
		if (fromDate == null) {
			errorMsg.append("Please enter a valid From service Date");
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		if (!DateUtil.isGoodDate(fromDate)) {
			errorMsg.append("Invalid date " + fromDate);
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		
		Calendar from = null; Calendar to = null;
		Calendar today = Calendar.getInstance();
		DateUtil dateUtil = new DateUtil();
		detail.setSubmissionDate(dateUtil.getTodaysDate("MM/dd/yyyy"));
		from = getCalendarDate(fromDate.substring(6,10), fromDate.substring(0,2), fromDate.substring(3,5));
		if (toDate != null) {
			if (!DateUtil.isGoodDate(toDate)) {
				errorMsg.append("Invalid date" + toDate);
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
			to = getCalendarDate(toDate.substring(6,10), toDate.substring(0,2), toDate.substring(3,5));
			//cannot be future dated.
			if (to.after(today)) { 
				errorMsg.append("Thru service date cannot be future dated");
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		}
		if (fromDate != null && toDate != null) {
			if (from.after(to)) {
				errorMsg.append(fromDate).append(" is after ").append(toDate);
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		}
		
		if (RapsConstants.PROV_IN_PATIENT.equals(entry.getProviderType()) ||
			RapsConstants.PROV_IN_PATIENT_OTHER.equals(entry.getProviderType())) {
			if (fromDate == null || toDate == null) {
				errorMsg.append("For In-Patient, you have to supply both From Service date and Thru Service Date");
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
			if (from.equals(to)) {
				errorMsg.append("For In-Patient, From Service Date cannot be equal with Thru Service Date");
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		}
		else {
			if (toDate == null) {
				toDate = fromDate;
				to = from;
			}
			Calendar anotherFrom = getCalendarDate(fromDate.substring(6,10), fromDate.substring(0,2), fromDate.substring(3,5));
			anotherFrom.add(Calendar.DAY_OF_MONTH, 31);
			if (to.after(anotherFrom)) {
				errorMsg.append("Thru Service Date must be within 31 days of From Service Date");
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		}
		RapsService rapsService = new RapsService(); 
		logger.info(LoggerConstants.methodEndLevel());
		return rapsService.validateCluster(conn, context, errorMsg);
	}
	
	public static boolean addCluster(Connection conn, RapsContext context, StringBuffer errorMsg) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		RapsService rapsService = new RapsService(); 
		logger.info(LoggerConstants.methodEndLevel());
		return rapsService.addCluster(conn, context, errorMsg); 
	}
	
	public static String getComment(Connection conn, RapsDetailItem item, int srce_seq_nbr) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		RapsService rapsService = new RapsService(); 
		logger.info(LoggerConstants.methodEndLevel());
		return rapsService.getComment(conn, item, srce_seq_nbr);
	}
	private static Calendar getCalendarDate(String yyyy, String mm, String dd) {
		logger.info(LoggerConstants.methodStartLevel());
		Calendar c = Calendar.getInstance();
		int year = Integer.valueOf(yyyy).intValue();
		int month = Integer.valueOf(mm).intValue()-1; //Calendar month is 0..11
		int day = Integer.valueOf(dd).intValue();
		c.set(year, month, day);
		logger.info(LoggerConstants.methodEndLevel());
		return c;
	}
	
}
