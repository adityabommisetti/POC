
package com.ps.mss.manager;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.framework.McaidReconConstants;
import com.ps.mss.model.EEMContext;
import com.ps.mss.model.McaidReconContext;


public class McaidReconManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(McaidReconManager.class);
	static ModuleLog log = new ModuleLog("MCaidReconManager");

	public static McaidReconContext getContext(HttpSession session) {
		logger.info(LoggerConstants.methodStartLevel());
		McaidReconContext context = (McaidReconContext)session.getAttribute(McaidReconConstants.MC_RECON_CONTEXT);
		if (context == null) {
			context = new McaidReconContext();
			session.setAttribute(McaidReconConstants.MC_RECON_CONTEXT,context);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return context;
	}//getContext()
	
}
