/*
 * Created on Apr 28, 2008
 */

/*$Id: ProfileManager.java,v 1.1 2014/06/26 07:54:57 praveen Exp $*/

package com.ps.mss.manager;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.ProfileService;
import com.ps.mss.businesslogic.WorkQueueService;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.FilterVO;
import com.ps.mss.model.ProfileSearchDetailVO;
import com.ps.mss.web.forms.SearchProfileForm;

/**
 * @author palat.pradeep
 */

public class ProfileManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(ProfileManager.class);
	/**
	 * @param filterVO
	 * @param discVO
	 * @param move
	 * @param dbId
	 * @param planMap
	 * @param searchType
	 * @param discrpArrMap
	 * @return list of discrepancies
	 * @throws ApplicationException
	 */
	public static ProfileSearchDetailVO getProfileSearchDetailVO(FilterVO filterVO, Map profileMap, String move, String dbId, Map planMap, String pdFetchList,String menuName, Map profileDateRangeMap) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		ProfileService profileService = new ProfileService(dbId);
		Map discrpArrMap = MasterManager.getDiscrpArrMap();
		logger.info(LoggerConstants.methodEndLevel());
		return profileService.getProfileSearchDetailVO(filterVO, profileMap, move,planMap,pdFetchList,discrpArrMap,menuName, profileDateRangeMap);
	}
	
	/**
	 * 
	 * @param planMap
	 * @param dbId
	 * @return
	 * @throws ApplicationException
	 */
	public static Map getProfileDateRange(Map planMap, String dbId) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		ProfileService profileService = new ProfileService(dbId);		
		logger.info(LoggerConstants.methodEndLevel());
		return profileService.getProfileDateRange(planMap);
	}	
	
	/**
	 * 
	 * @param planMap
	 * @param dbId
	 * @return
	 * @throws ApplicationException
	 */
	public static Map getPlanPbpSegMap(Map planMap, String dbId) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		ProfileService profileService = new ProfileService(dbId);		
		logger.info(LoggerConstants.methodEndLevel());
		return profileService.getPlanPbpSegMap(planMap);
	}
	
	/**
	 * This method is used to construt the search criteria string based on the filter conditions chosen by the user.
	 * @param filterVO
	 * @param pageName
	 * @param menuName
	 * @param dbId
	 * @return
	 * @throws ApplicationException
	 */
	public static String getSearchCriteriaHeader(FilterVO filterVO, String pageName, String menuName, String dbId) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		ProfileService service = new ProfileService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return service.getSearchCriteriaHeader(filterVO, pageName, menuName);
	}	
	//Recon Work Queue changes : start
	public static Map getAutoAssignMap(List users, String dbId) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		ProfileService profileService = new ProfileService(dbId);
		Map discrpArrMap = MasterManager.getDiscrpArrMap();
		logger.info(LoggerConstants.methodEndLevel());
		return profileService.getAutoAssignUsersMap(users);
	}
	public static int updateAutoAssignTask(Map planMap,String dbId, String selected,String reassign, String user, FilterVO filterVO) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
		ProfileService profileService = new ProfileService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return profileService.autoAssignTask(planMap, selected,reassign,user, filterVO);
	}
	//Recon Work Queue changes : end
}
