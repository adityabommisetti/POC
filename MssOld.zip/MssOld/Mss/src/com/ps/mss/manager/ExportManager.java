/*
 * $Id: ExportManager.java,v 1.1 2014/06/26 07:54:54 praveen Exp $
 */
package com.ps.mss.manager;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.CsvService;
import com.ps.mss.businesslogic.ExportService;
import com.ps.mss.businesslogic.PdfService;
import com.ps.mss.db.DbConnWeb;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.framework.HPEConstants;
import com.ps.mss.framework.RapsConstants;
import com.ps.mss.model.FilterVO;
import com.ps.mss.model.HPEContext;
import com.ps.mss.model.PdeContext;
import com.ps.mss.model.RapsContext;
import com.ps.mss.model.ReinsuranceContext;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.helper.AjaxHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.web.helper.Utility;
import com.ps.util.StringUtil;

/**
 * @author Hemant
 *
 */
public class ExportManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(ExportManager.class);
	/**
	 * this method is called from class 'DownloadAction' to perform export either in csv or in PDF, it further calls PDFService or CSVService
	 * @author hemant
	 * @param tableName
	 * @param filterVO
	 * @param planMap
	 * @param searchType
	 * @param planName
	 * @param pageStatus
	 * @param uiContextRange
	 * @param dbId
	 * @param detailMap
	 * @param exportType
	 * @param menuName
	 * @param custName
	 * @param userId
	 * @param cmsValue
	 * @param planValue
	 * @param seqNbr
	 * @param pymtType
	 * @param applyDate
	 * @param hasWriteOffSerivce
	 * @return
	 * @throws ApplicationException
	 * @throws Exception
	 */
	public static String createExport(String tableName, Object appContext, FilterVO filterVO, Map planMap, String searchType, String planName, 
		  List pageStatus, String uiContextRange, String dbId, Map detailMap, String exportType, String menuName, String custName, String userId, String cmsValue, String planValue, String seqNbr, String pymtType, String applyDate, boolean hasWriteOffSerivce) throws ApplicationException, Exception{
		logger.info(LoggerConstants.methodStartLevel());
		ExportService exportService = null;
		
		if(Constants.FILE_TYPE_PDF.equals(exportType))			
			exportService = new PdfService(dbId);
		else
			exportService = new CsvService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		if (Constants.PDE_ERR_DASHBOARD.equals(tableName)) 
			return exportService.createPdeErrDb(filterVO, planMap, (PdeContext)appContext);
		else if (Constants.PDE_ERR_CODES.equals(tableName)) 
			return exportService.createPdeErrCodes(filterVO, planMap, uiContextRange);
		else if (Constants.PDE_ERR_DETAIL.equals(tableName))
			return exportService.createPdeErrDetail(filterVO, planMap, (PdeContext) appContext, uiContextRange, custName);
		else if(Constants.POPUP_RECONCILATION.equals(tableName))//for 'Reconciliation popup' export
			return exportService.createPopupReconciliation(filterVO,planMap, pageStatus);
		else if(Constants.POPUP_PYMT_DETAIL.equals(tableName))//for 'Popup Pymt Detail Part A/B' export
			return exportService.createPopupPymtDetail(filterVO,planMap, pageStatus,seqNbr, pymtType, applyDate);
		else if(Constants.POPUP_DISEASE.equals(tableName))//for 'Disease group popup' export
			return exportService.createPopupDisease(filterVO,planMap, pageStatus,cmsValue, planValue);
		else if(Constants.PAYMENT_DASHBOARD.equals(tableName))//for 'Payment Dashboard' or 'Beneficiary Payment Dashboard' export
			return exportService.createPaymentDashBoard(filterVO, planMap, planName, pageStatus,menuName);
		else if(Constants.DISCREPANCY_DASHBOARD.equals(tableName))//for 'Discrepancy Dashboard' or 'Beneficiary Discrepancy Dashboard' export
			return exportService.createDiscrepancyDashBoard(filterVO,planMap,planName, pageStatus,menuName );
		else if(Constants.PAYMENT_SUMMARY.equals(tableName))//for 'Payment Summary' or 'Plan Show Payments' export 
			return exportService.createPaymentSummary(filterVO, planMap, searchType, planName, pageStatus, uiContextRange);
		else if(Constants.DISCREPANCY_SUMMARY.equals(tableName))//for 'Discrepancy Summary' or 'Plan Show Discrepancies' export
			return exportService.createDiscrepancySummary(filterVO,planMap,searchType, planName, pageStatus,uiContextRange,MasterManager.getDiscrpArrMap());
		else if(Constants.DISCREPANCY_DETAIL.equals(tableName)){//for 'Discrepancy Detail' or 'Beneficiary Discrepancy Detail' or 'Beneficiary Show Discrepancies' export
			return exportService.createDiscrepancyDetail(filterVO,planMap,searchType, planName, pageStatus,uiContextRange,detailMap, MasterManager.getDiscrpArrMap(),menuName,MasterManager.getAdjReasonMap(), hasWriteOffSerivce);
		}
		//Recon-Work Queue Changes : start
		else if(Constants.WORK_QUEUE_MENU.equals(tableName)){//for Work Queue Expert
			return exportService.createWorkQueue(filterVO,planMap,searchType, planName, pageStatus,uiContextRange,detailMap, MasterManager.getDiscrpArrMap(),menuName,MasterManager.getAdjReasonMap(), hasWriteOffSerivce);
		}
		//Recon-Work Queue Changes : end
		else if(Constants.PAGE_BENEFICIARY_PYMT_DETAILS.equals(tableName)) {//for 'Beneficiary Pymt Detail' or 'Beneficiary Show Payments' or 'Pymt Detail Popup' export
			return exportService.createBeneficiaryPaymentDetail(filterVO, planMap, searchType, planName, pageStatus,uiContextRange, menuName,MasterManager.getAdjReasonMap());
		}else if(Constants.TROOP_DASHBOARD.equals(tableName)){//for 'Troop dashboard' export
		    return exportService.createTroopDashBoard(filterVO, planMap, planName, pageStatus,menuName);
		}else if(Constants.PDE_DASHBOARD.equals(tableName)){//for 'PDE Dashboard' Export
		    return exportService.createPdeDashBoard(filterVO, planMap, planName, pageStatus,menuName);
		}else if(Constants.TROOP_DETAIL.equals(tableName)){//for 'Troop Detail' export
		    return exportService.createTroopDetail(filterVO, planMap, pageStatus, uiContextRange, detailMap, tableName,searchType, MasterManager.getAdjReasonMap(), custName);
		}else if(Constants.PDE_EVENT_DETAIL.equals(tableName)){//for 'PDE Event Detail' export
		    return exportService.createPdeEventDetail(filterVO, planMap, pageStatus, uiContextRange, detailMap, tableName,searchType, MasterManager.getAdjReasonMap(), custName);
		}else if(Constants.PROFILE_SEARCH.equals(tableName)){//for 'Profile' export	
			return exportService.createProfileDetail(filterVO, planMap, searchType, planName, pageStatus, uiContextRange, detailMap, MasterManager.getDiscrpArrMap(), menuName, ProfileManager.getProfileDateRange ( planMap, dbId), userId);
		}		
		return null;
	}
	
	/**
	 * 
	 * @param pageName
	 * @param context
	 * @param otherParam  reserved for later.
	 * @param exportType
	 * @param uiContextRange
	 * @param dbId
	 * @return
	 * @throws ApplicationException
	 * @throws Exception
	 */
	public static String createExport(String pageName,  Object context, Map otherParam, String exportType,
			  String uiContextRange, String dbId ) throws ApplicationException, Exception{
		logger.info(LoggerConstants.methodStartLevel());
   	Connection conn = null;
  	try {
		AjaxHelper.validateUser();
		if(StringUtil.isNullOrEmpty(dbId))
			conn = DbConnWeb.getConnection();
		else
			conn = DbConnWeb.getConnection(dbId);    
		ExportService exportService = null;
	
		if(Constants.FILE_TYPE_PDF.equals(exportType))			
			exportService = new PdfService(dbId);
		else
			exportService = new CsvService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		if(RapsConstants.RAPS_CLAIMS_DASHBOARD.equals(pageName))//for claim dashboard
			return exportService.createRapsClaimsDashBoard(conn, (RapsContext)context);
		else if (RapsConstants.RAPS_DASHBOARD.equals(pageName))
			return exportService.createRapsDashBoard(conn, (RapsContext)context);
		else if (RapsConstants.RAPS_STATISTIC.equals(pageName))
			return exportService.createRapsStatistics(conn, (RapsContext)context);
		else if (RapsConstants.RAPS_CLAIMS_DETAILS.equals(pageName))
			return exportService.createRapsClaimDetail(conn, (RapsContext)context, uiContextRange);
		else if (RapsConstants.RAPS_DETAIL.equals(pageName))
			return exportService.createRapsDetail(conn, (RapsContext)context, uiContextRange);
		else if (RapsConstants.RAPS_CLAIMS_DETAILS_POP.equals(pageName))
			return exportService.createClaimDetailPopup(conn, (RapsContext)context);
		else if (RapsConstants.RAPS_DETAIL_POP.equals(pageName))
			return exportService.createRapsDetailPopup(conn, (RapsContext)context);
		else if (Constants.PAGE_REINSURANCE.equals(pageName))
			return exportService.createReInsurance((ReinsuranceContext) context);	
		else if (Constants.PAGE_FORECASTSUM.equals(pageName) || Constants.PAGE_LICS_DETAIL.equals(pageName) ||
				Constants.PAGE_REIN_DETAIL.equals(pageName) || Constants.PAGE_RISK_DETAIL.equals(pageName)  ||
				Constants.PAGE_CGAP_DETAIL.equals(pageName))	//Added for CGAP Screen IFOX-00432723
			return exportService.createAnnualRecon((ReinsuranceContext) context, pageName);	
		else if (RapsConstants.RAPS_ERRORS.equals(pageName))
			return exportService.createRapsErrors(conn, (RapsContext)context, uiContextRange);
		/*else if(HPEConstants.OPTION_ENCOUNTER.equals(pageName)){//for 'Encounter' export			
			return exportService.createEncounterDetail(conn, uiContextRange, (HPEContext)context, exportType);
		else if(HPEConstants.OPTION_ENCOUNTER.equals(pageName)){//for 'Encounter' export			
			return exportService.createEncounterDetail(conn, uiContextRange, (HPEContext)context, exportType);
		}else if(HPEConstants.OPTION_DASHBOARD.equals(pageName)){//for 'Dashboard' export			
			return exportService.createDashboard(conn, uiContextRange, (HPEContext)context, exportType);
		}else if(HPEConstants.OPTION_REJECT_DASHBOARD.equals(pageName)){//for 'Reject Dashboard' export			
			return exportService.createRejectDashboard(conn, uiContextRange, (HPEContext)context, exportType);
		}else if(HPEConstants.OPTION_ERROR_DASHBOARD.equals(pageName)){//for 'Error Dashboard' export			
			return exportService.createErrorDashboard(conn, uiContextRange, (HPEContext)context, exportType);
		}else if(HPEConstants.OPTION_ENCOUNTER_LOG.equals(pageName)){//for 'Encounter Detail Log' export			
			return exportService.createEncounterDetailLog(conn, uiContextRange, (HPEContext)context);
		}*/
		return null;
	 	} catch(SQLException e) {
	 		logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException("Database Error",e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
			}
		}
	}
	
	/**
	 * 
	 * @param pageName
	 * @param context
	 * @param otherParam  reserved for later.
	 * @param exportType
	 * @param claimType
	 * @param uiContextRange
	 * @param dbId
	 * @return
	 * @throws ApplicationException
	 * @throws Exception
	 */
	public static String createExport(String pageName,  Object context, Map otherParam, String exportType,String claimType,boolean historyFlag,
			  String uiContextRange,  SessionHelper sessionHelper ) throws ApplicationException, Exception{
		logger.info(LoggerConstants.methodStartLevel());
   	Connection conn = null;
  	try {
  		String dbId=(String)sessionHelper.getAttribute(SessionManager.HPEDB);

		AjaxHelper.validateUser();
		if(StringUtil.isNullOrEmpty(dbId))
			conn = DbConnWeb.getConnection();
		else
			conn = DbConnWeb.getConnection(dbId);    
		ExportService exportService = null;
	
		if(Constants.FILE_TYPE_PDF.equals(exportType))			
			exportService = new PdfService(dbId);
		else
			exportService = new CsvService(dbId);
		if(HPEConstants.OPTION_ENCOUNTER.equals(pageName)){//for 'Encounter' export			
			logger.info(LoggerConstants.methodEndLevel());
			return exportService.createEncounterDetail(conn, uiContextRange, (HPEContext)context, exportType,claimType);
		}else if(HPEConstants.OPTION_DASHBOARD.equals(pageName)){//for 'Dashboard' export
			String mainTab=("EN".equalsIgnoreCase(claimType))?HPEConstants.EDPS_DSH_SEL_TAB_MAP:HPEConstants.CHART_MGMT_TAB;
			//DME_Dashboard_changes	IFOX-00398979
			String encType=Utility.getEncTypeFromSelectedTab(mainTab, AjaxHelper.getSessionHelper());
			logger.info(LoggerConstants.methodEndLevel());
			return exportService.createDashboard(conn, uiContextRange, (HPEContext)context, exportType,claimType,encType);
		}else if(HPEConstants.OPTION_REJECT_DASHBOARD.equals(pageName)){//for 'Reject Dashboard' export
			String mainTab=("EN".equalsIgnoreCase(claimType))?HPEConstants.REJECT_ANALYSIS_SUMMARY_TAB:HPEConstants.CHART_REJECT_ANALYSIS_TAB;
			//DME_Dashboard_changes	IFOX-00398979
			String encType=Utility.getEncTypeFromSelectedTab(mainTab, AjaxHelper.getSessionHelper());
			logger.info(LoggerConstants.methodEndLevel());
			return exportService.createRejectDashboard(conn, uiContextRange, (HPEContext)context, exportType,claimType,encType);
		}else if(HPEConstants.OPTION_ERROR_DASHBOARD.equals(pageName)){//for 'Error Dashboard' export			
			logger.info(LoggerConstants.methodEndLevel());
			return exportService.createErrorDashboard(conn, uiContextRange, (HPEContext)context, exportType,claimType);
		}else if(HPEConstants.OPTION_ENCOUNTER_LOG.equals(pageName)){//for 'Encounter Detail Log' export			
			logger.info(LoggerConstants.methodEndLevel());
			return exportService.createEncounterDetailLog(conn, uiContextRange, (HPEContext)context,claimType,historyFlag);
		}
		else if(HPEConstants.MENU_FILE_TRACK.equals(pageName)){//for 'File tracking search results' export			
			sessionHelper = AjaxHelper.getSessionHelper();
			String exportFlag = (String)sessionHelper.getAttribute(HPEConstants.FILETRACK_EXPORT_IND_FLAG);			
			if(!StringUtil.isNullOrEmpty(exportFlag) && "TRUE".equals(exportFlag)){
				logger.info(LoggerConstants.methodEndLevel());
				return exportService.createExportFileNames(conn, uiContextRange, (HPEContext)context, exportType, claimType);
				
			}else{			
				logger.info(LoggerConstants.methodEndLevel());
				return exportService.createFileTrackingExport(conn, uiContextRange, (HPEContext)context, exportType, claimType);
			}
			
		}
		logger.info(LoggerConstants.methodEndLevel());
		return null;
	 	} catch(SQLException e) {
	 		logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException("Database Error",e);
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
			}
		}
  	
	}

}
