/*
 * $Id: ContextManager.java,v 1.1 2014/06/26 07:54:57 praveen Exp $
 */
package com.ps.mss.manager;

import java.lang.reflect.InvocationTargetException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.commons.beanutils.PropertyUtils;

import com.ps.mss.framework.RapsConstants;
import com.ps.mss.model.RapsContext;
import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;


/**
 * @author indrapradja.adriana
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ContextManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(ContextManager.class);
    /** This method is finding a proper context object from the session. If it doesn't find it, it will
     * create one. Then it will copy properties from the form to the context.
     * @param request HttpServletRequest.
     * @param form ActionForm where the properties will be copied from.
     * @param contextName String session attribute name for the context to be searched.
     * @return context object.
     */
	public static Object getContextAndCopyProperties(HttpServletRequest request, ActionForm form, String contextName) {
		logger.info(LoggerConstants.methodStartLevel());
		ModuleLog log = new ModuleLog("ContextManager");
		Object context = getContext(request, contextName);
		try {
			PropertyUtils.copyProperties(context, form);  //copy from form to context
		}
		catch (IllegalAccessException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("IllegalAccessException"); 
			logger.info(LoggerConstants.methodEndLevel());
			return null;
		}
		catch (InvocationTargetException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("InvocationTargetException"); 
			logger.info(LoggerConstants.methodEndLevel());
			return null;
		}
		catch (NoSuchMethodException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("NoSuchMethodException"); 
			logger.info(LoggerConstants.methodEndLevel());
			return null;
		}
		request.getSession().setAttribute(RapsConstants.CONTEXT_NAME, contextName);
		logger.info(LoggerConstants.methodEndLevel());
		return context;
	}
	
	public static Object getContext(HttpServletRequest request, String contextName) {
		logger.info(LoggerConstants.methodStartLevel());
		logger.info(LoggerConstants.methodEndLevel());
		return getContext(request.getSession(), contextName);

	}
	public static Object getContext(HttpSession session, String contextName) {
		logger.info(LoggerConstants.methodStartLevel());
		Object context = session.getAttribute(contextName);
		if (context == null) {
			if (RapsConstants.RAPS_CONTEXT.equals(contextName)) {
				context = new RapsContext();
				session.setAttribute(RapsConstants.RAPS_CONTEXT, context);
			}
		}
//		session.setAttribute(Constants.CONTEXT_NAME, contextName);
		logger.info(LoggerConstants.methodEndLevel());
		return context;
	}
}
