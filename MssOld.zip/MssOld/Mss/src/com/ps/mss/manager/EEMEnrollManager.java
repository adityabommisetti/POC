/*
 * $Id: EEMEnrollManager.java,v 1.9 2016/07/08 01:22:00 dinesh Exp $
 */
package com.ps.mss.manager;

import java.io.PrintStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EEMEnrollOoaService;
import com.ps.mss.businesslogic.EEMEnrollService;
import com.ps.mss.businesslogic.EEMOevService;
import com.ps.mss.dao.EEMApplDao;
import com.ps.mss.dao.EEMDao;
import com.ps.mss.dao.EEMEnrollDao;
import com.ps.mss.dao.EEMEnrollOoaDao;
import com.ps.mss.dao.EEMOevDao;
/*LEP CR Changes End.*/
import com.ps.mss.dao.model.EMMbrTriggerVO;
import com.ps.mss.dao.model.EmCorrMbrVO;
import com.ps.mss.dao.model.EmMbrAddressVO;
import com.ps.mss.dao.model.EmMbrAgentVO;
import com.ps.mss.dao.model.EmMbrAsesVO;//Ases Tab Added
import com.ps.mss.dao.model.EmMbrBillingVO;
import com.ps.mss.dao.model.EmMbrCobVO;
import com.ps.mss.dao.model.EmMbrCommentVO;
import com.ps.mss.dao.model.EmMbrDemographicVO;
import com.ps.mss.dao.model.EmMbrDsInfoVO;
import com.ps.mss.dao.model.EmMbrEnrollmentVO;
import com.ps.mss.dao.model.EmMbrErrorVO;
import com.ps.mss.dao.model.EmMbrLepAttestInfoVO;
import com.ps.mss.dao.model.EmMbrLepInfoVO;
import com.ps.mss.dao.model.EmMbrLepNunCmoVO;
import com.ps.mss.dao.model.EmMbrLisInfoVO;
import com.ps.mss.dao.model.EmMbrOevInfoVO;
import com.ps.mss.dao.model.EmMbrOoaInfoVO;
import com.ps.mss.dao.model.EmMbrSearchResultVO;
import com.ps.mss.dao.model.EmMbrTrrLogVO;
import com.ps.mss.db.EEMCodeCache;
import com.ps.mss.db.EEMPersistence;
import com.ps.mss.db.EEMProfileSettings;
import com.ps.mss.db.SecPlanPersistence;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.exception.DaoException;
import com.ps.mss.framework.Constants;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.model.EEMContext;
import com.ps.mss.model.EEMEnrollVO;
import com.ps.mss.model.EMGroupProductSearchVO;
import com.ps.mss.model.EMLtcSearchVO;
import com.ps.mss.model.EMMbrLTCInfoVO;
import com.ps.mss.model.EMMbrPCPInfoVO;
import com.ps.mss.model.EMPcpSearchVO;
import com.ps.mss.model.EMTrrDataSearchVO;
import com.ps.mss.model.EmMbrPosEditVO;
import com.ps.mss.model.Pagination;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.forms.EEMEnrollForm;
import com.ps.mss.web.forms.EEMEnrollGPSearchForm;
import com.ps.mss.web.forms.EEMEnrollLtcSearchForm;
import com.ps.mss.web.forms.EEMEnrollPcpSearchForm;
import com.ps.mss.web.forms.EEMTrrDataForm;
import com.ps.mss.web.helper.EEMEnrollHelper;
import com.ps.mss.web.helper.EEMHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.text.DateFormatter;
import com.ps.text.NumberFormatter;
import com.ps.util.DateUtil;
import com.ps.util.ListBoxItem;
import com.ps.util.StringUtil;

public class EEMEnrollManager {
	PrintStream log;
	private static Logger logger = LoggerFactory.getLogger(EEMEnrollManager.class);
	
	public EEMEnrollManager() {
		this(System.out);
	}
	public EEMEnrollManager(PrintStream log) {
		this.log = log;
	}
	//SSNRI 2017 :Start
	public void memberSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form,String flag) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
    //SSNRI 2017 :End
		EEMEnrollVO enrollVO = context.getEnrollVO();
		// Copy the search criteria to the VO
		enrollVO.setMfId(sessionHelper.getMfId());
		enrollVO.setMcCustNbr(sessionHelper.getCustomerNumber());
		enrollVO.setSearchMemberId(form.getSearchMemberId());
		enrollVO.setSearchHicNo(form.getSearchHicNo());
		enrollVO.setSearchSSN(form.getSearchSSN());
		enrollVO.setSearchSupplementalId(form.getSearchSupplementalId());
		enrollVO.setSearchLastName(form.getSearchLastName());
		enrollVO.setSearchEffectiveMonth(form.getSearchEffectiveMonth());
		enrollVO.setSearchShowAll(form.getSearchShowAll());
		//IFOX-00424860 - New member search fields :start
		enrollVO.setSearchFirstName(form.getSearchFirstName());
		enrollVO.setSearchDob(form.getSearchDob());
		//IFOX-00424860 - New member search fields :end
		//New LEP changes - Start
		enrollVO.setPotentialShowAll(form.getPotentialShowAll());
		//New LEP changes - End
		//SSNRI 2017 :Start
		enrollVO.setIsHicOrMbi(flag);
		//SSNRI 2017 : End
		form.setSearchExpanded(true);
		form.setSelectedMemberTab(EEMConstants.EEM_MBR_TAB_DEMOGRAPHIC);
		//SSNRI 2017 :Start
		memberSearchPage(conn,sessionHelper,context,form,"first",flag);
		//SSNRI 2017 :End
		logger.info(LoggerConstants.methodEndLevel());
	}
	//SSNRI 2017 :Start
	public void memberSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form, String move,String flag) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
	//SSNRI 2017 :End
		EEMEnrollVO enrollVO = context.getEnrollVO(); // use the last search criteriia even if its changed on the form
		Pagination pagination = context.getEnrollPagination();
		
		EEMEnrollHelper.clearFormDisplay(form);
		EEMEnrollHelper.clearContextDisplay(enrollVO);

		EEMEnrollDao enrlDao = new EEMEnrollDao();
		try {
			//SSNRI 2017 : start
			enrollVO.setIsHicOrMbi(flag);
			//SSNRI 2017 : end
			List searchResults = enrlDao.getMbrSearchResults(conn,enrollVO,pagination,move);
			
			EmMbrSearchResultVO [] arr = new EmMbrSearchResultVO[searchResults.size()];
			arr = (EmMbrSearchResultVO[])searchResults.toArray(arr);		

			pagination.setPaginationResults(move,arr);
			enrollVO.setSearchResults(searchResults);

			if (searchResults.size() > 0) {
				form.setListSearchResults(searchResults);
				form.setSelectedSearchRow(0);
			
				memberSelect(conn,sessionHelper,context,form);
			}
			
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception : " + e.getMessage());
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void memberSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());

		EEMEnrollService service = new EEMEnrollService();
		EEMEnrollVO enrollVO = context.getEnrollVO();
		String showAll = enrollVO.getSearchShowAll();
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		EEMOevDao oevDao = new EEMOevDao();
		boolean rslt = false;
		try{
		List searchResults = enrollVO.getSearchResults();
		int selectedSearchRow = form.getSelectedSearchRow();
		EmMbrSearchResultVO emMbrSearchResultVO = (EmMbrSearchResultVO) searchResults.get(selectedSearchRow);
		//new LEP changes -- start
		sessionHelper.setAttribute("memberId", emMbrSearchResultVO.getMemberId());
		String ltrDesDisp = (String)sessionHelper.getAttribute(EEMProfileSettings.LTR_DES_DISP);
		//new LEP changes -- end
		rslt = service.mbrSelect(conn,emMbrSearchResultVO, enrollVO, ltrDesDisp);
		//Bypass PCP Start Date Validation Changes bcbsaz : start
		form.setPcpDateParm(enrollVO.getPcpDateParm());
		//Bypass PCP Start Date Validation Changes bcbsaz : end
		setFieldNames(enrollVO.getErrors());
		//Start IFOX-00389053 
		form.setLineOfBusiness(enrollVO.getLineOfBusiness());
		//End IFOX-00389053
		/*Access health PCP CR- Start */
		String npiInd = (String) sessionHelper.getAttribute("NPIIND");
		if(null == npiInd || npiInd.trim().equals(""))
		{
			npiInd = EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(), "NPIIND");
			sessionHelper.setAttribute("NPIIND", npiInd);
		}
		/*Access health PCP CR- End */
		

		/*
		 * 024_Cambia_SUC_LEP - Start 1
		 */ 
		
		//Iteration 2 UAT change for LEp Changes-start
				try{
				//	System.out.println(" before oev call for check trigger "+oevDao+conn);
				EMMbrTriggerVO trig1 = oevDao.checkMbrTrigger(conn, emMbrSearchResultVO.getCustomerId(), 
						emMbrSearchResultVO.getMemberId(),
						EEMConstants.TRIGGER_TYPE_FOLLOWUP_MEMB, "LE21");
				if(trig1!=null){
					//System.out.println(" value of le21"+trig1.getTriggerStatus());
					if(trig1.getTriggerStatus().equals(EEMConstants.TRIGGER_STATUS_OPEN)) 
						form.setLe21TimerCheck("true"); //LE21 timer open 
					 else
						form.setLe21TimerCheck("closed");//LE21 timer closed
			
				}
				else 
					form.setLe21TimerCheck("false");
				//System.out.println(" value of timer"+form.getLe21TimerCheck());
				logger.debug(" value of Le21 timer check"+form.getLe21TimerCheck());
				
				EMMbrTriggerVO trig2 = oevDao.checkMbrTrigger(conn, emMbrSearchResultVO.getCustomerId(), 
						emMbrSearchResultVO.getMemberId(),
						EEMConstants.TRIGGER_TYPE_FOLLOWUP_MEMB, "OBC3");
				if(trig2!=null){
					
					if(trig2.getTriggerStatus().equals(EEMConstants.TRIGGER_STATUS_OPEN)) 
						form.setObc3TimerCheck("true"); //LE21 timer open 
					 else
						form.setObc3TimerCheck("closed");//LE21 timer closed
			
				}
				else 
					form.setObc3TimerCheck("false");
				//System.out.println(" value of timer"+form.getObc3TimerCheck());
				logger.debug(" value of obc3 timer check"+form.getObc3TimerCheck());
				
				
				EMMbrTriggerVO trig3 = oevDao.checkMbrTrigger(conn, emMbrSearchResultVO.getCustomerId(), 
						emMbrSearchResultVO.getMemberId(),
						EEMConstants.TRIGGER_TYPE_FOLLOWUP_MEMB, "OBC1");
				if(trig3!=null){
					
					if(trig3.getTriggerStatus().equals(EEMConstants.TRIGGER_STATUS_OPEN)) 
						form.setObc1TimerCheck("true"); //LE21 timer open 
					 else
						form.setObc1TimerCheck("closed");//LE21 timer closed
			
				}
				else 
					form.setObc1TimerCheck("false");
				//System.out.println(" value of timer"+form.getObc1TimerCheck());
				logger.debug(" value of Obc1 timer check"+form.getObc1TimerCheck());
				
				
				EMMbrTriggerVO trig4 = oevDao.checkMbrTrigger(conn, emMbrSearchResultVO.getCustomerId(), 
						emMbrSearchResultVO.getMemberId(),
						EEMConstants.TRIGGER_TYPE_FOLLOWUP_MEMB, "OBC2");
				if(trig4!=null){
					
					if(trig4.getTriggerStatus().equals(EEMConstants.TRIGGER_STATUS_OPEN)) 
						form.setObc2TimerCheck("true"); //LE21 timer open 
					 else
						form.setObc2TimerCheck("closed");//LE21 timer closed
			
				}
				else 
					form.setObc2TimerCheck("false");
				//System.out.println(" value of timer"+form.getObc2TimerCheck());
				logger.debug(" value of Obc2 timer check"+form.getObc2TimerCheck());
				
				}catch(Exception e){
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug(" Getting  Timer status: "+e.getMessage());
				}
				//Iteration 2 UAT change for LEp Changes-end
		/**
		* 024_Highmark_SUC_LEP -NUNCMOTr- Start
		*/
		form.setOutInitAttests(enrollVO.getOutInitAttests());
		form.setInInitAttests(enrollVO.getInInitAttests());
		form.setOutIncAttests(enrollVO.getOutIncAttests());
		form.setInIncAttests(enrollVO.getInIncAttests());
		form.setInLateAttests(enrollVO.getInLateAttests());
		//System.out.println(" values in manager"+form.getInLateAttests().size());
		/**
		* 024_Highmark_SUC_LEP -NUNCMOTr- End
		*/
		
		/*
		 * 024_Cambia_SUC_LEP - End 1
		 */ 
		
		form.setListSearchResults(searchResults);
		form.setListDemographicsWithDisplay(enrollVO.getDemographics());
		form.setDemographicChanged(false);

		Pagination pagination = null;
		
		form.setSelectedEnrollmentRow(0);
		form.setListEnrollmentsWithDisplay(enrollVO.getEnrollments());
		form.setEnrollmentChanged(false);
		form.setEnrollmentDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setTopDisplayEnrollmentRow(0);
		pagination = context.getEnrollEnrollPagination();
		pagination.setListPaginationResults("first",enrollVO.getEnrollments());

		EEMCodeCache cc = EEMCodeCache.getInstance();
		form.setValidEnrollReasons(cc.getEnrollReasonFor(form.getDisplayEnrollment().getEnrollStatus()));
		
		form.setSelectedDsInfoRow(0);		
		form.setListDsInfosWithDisplay(enrollVO.getDsInfos());
		
		/**
		 * Cambia-PWO-Start
		 */
		form.setEffDate(enrollVO.getEffDate());
		/**
		 * Cambia-PWO-End
		 */
		form.setDsInfoChanged(false);
		form.setDsInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setTopDisplayDsInfoRow(0);
		pagination = context.getEnrollDsInfoPagination();
		pagination.setListPaginationResults("first",enrollVO.getDsInfos());
		
		form.setSelectedLisInfoRow(0);		
		form.setListLisInfosWithDisplay(enrollVO.getLisInfos());
		form.setLisInfoChanged(false);
		form.setLisInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setTopDisplayLisInfoRow(0);
		pagination = context.getEnrollLisInfoPagination();
		pagination.setListPaginationResults("first",enrollVO.getLisInfos());
		
		form.setSelectedLepInfoRow(0);		
		form.setListLepInfosWithDisplay(enrollVO.getLepInfos());
		//0427630-OPEN : TSA Supress LEP process Platino Members - start
		form.setSuppLepPlatino(enrollVO.getSuppLepPlatino());
		//0427630-OPEN : TSA Supress LEP process Platino Members - end
		//New LEP changes - Start
				form.setSelectedLepPotentialRow(0);
				form.setTotalPlepMonths(enrollVO.getTotalPlepMonths());
				form.setListLepPotentialWithDisplay(enrollVO.getLepPotential());
				form.setTopDisplayLepPotentialRow(0);
				pagination = context.getEnrollLepPotentialPagination();
				pagination.setListPaginationResults("first",enrollVO.getLepPotential());
				form.setSelectedLepCcfRow(0);
				form.setListLepAttestCcfWithDisplay(enrollVO.getLepAttestationCcf());
				form.setTopDisplayCcfRow(0);
				pagination = context.getEnrollLepCcfPagination();
				pagination.setListPaginationResults("first",enrollVO.getLepAttestationCcf());
				//New LEP changes - End
		/*
		 * 024_Cambia_SUC_LEP - Start 2
		 */ 
		
		//024 -LEP Attestation - Start
		form.setListLepAttestInfosWithDisplay(enrollVO.getLepAttestInfo());
		//024 -LEP Attestation - End
		
		form.setCheckLep(enrollVO.getCheckLep());
		form.setCredCovInfo(enrollVO.getCredCovInfo());
		form.setLepAdjInfo(enrollVO.getLepAdjInfo());
		form.setCredcovTimer(enrollVO.getCredcovTimer());
		/*
		 * 024_Cambia_SUC_LEP - End 2
		 */ 
		form.setLepInfoChanged(false);
		form.setLepInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setTopDisplayLepInfoRow(0);
		pagination = context.getEnrollLepInfoPagination();
		pagination.setListPaginationResults("first",enrollVO.getLepInfos());
		
		form.setSelectedAddressRow(0);
		form.setListAddressesWithDisplay(enrollVO.getAddresses());
		form.setAddressChanged(false);
		form.setAddressDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setTopDisplayAddressRow(0);
		pagination = context.getEnrollAddressPagination();
		pagination.setListPaginationResults("first",enrollVO.getAddresses());
		
		////IFOX-00426356: Attachment CR
		form.setAttachmentsWithDisplay(enrollVO.getAttachments());
		
		form.setSelectedLetterRow(0);
		form.setListLettersWithDisplay(enrollVO.getLetters());
		form.setLetterChanged(false);
		form.setLetterDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setDisplayLetterVarData(enrollVO.getLetterData());
		form.setTopDisplayLetterRow(0);
		pagination = context.getEnrollLetterPagination();
		pagination.setListPaginationResults("first",enrollVO.getLetters());

		form.setSelectedPcpInfoRow(0);
		form.setListPcpInfosWithDisplay(enrollVO.getPcpInfos());		
		form.setPcpInfoChanged(false);
		form.setPcpInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setTopDisplayPcpInfoRow(0);
		pagination = context.getEnrollPcpInfoPagination();
		pagination.setListPaginationResults("first",enrollVO.getPcpInfos());
		
		//IFOX-00399921 LTC Tab. START
		form.setSelectedLtcInfoRow(0);
		form.setListLtcInfosWithDisplay(enrollVO.getLtcInfos());		
		form.setLtcInfoChanged(false);
		form.setLtcInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setTopDisplayLtcInfoRow(0);
		pagination = context.getEnrollLtcInfoPagination();
		pagination.setListPaginationResults("first",enrollVO.getLtcInfos());
		//IFOX-00399921 LTC Tab. END
		
		form.setSelectedCommentRow(0);
		form.setListCommentsWithDisplay(enrollVO.getComments());		
		form.setCommentChanged(false);
		form.setCommentDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setTopDisplayCommentRow(0);
		pagination = context.getEnrollCommentPagination();
		pagination.setListPaginationResults("first",enrollVO.getComments());
		
		form.setSelectedErrorRow(0);
		form.setListErrorsWithDisplay(enrollVO.getErrors());
		form.setErrorChanged(false);
		form.setErrorDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setTopDisplayErrorRow(0);
		pagination = context.getEnrollErrorPagination();
		pagination.setListPaginationResults("first",enrollVO.getErrors());

		form.setSelectedTrrLogRow(0);
		form.setListTrrLogsWithDisplay(enrollVO.getTrrLogs());
		form.setTrrLogChanged(false);
		
		/*IFOX-00427238 June 2020 CMS changes - Start*/
		form.setTrrVarDataPresent(new EEMDao().getTrrDataFlag1(conn, emMbrSearchResultVO.getCustomerId(), emMbrSearchResultVO.getMemberId(),form.getDisplayTrrLog().getTransReplyCd()));
		/*IFOX-00427238 June 2020 CMS changes - end*/
		form.setTrrLogDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setTopDisplayTrrLogRow(0);
		pagination = context.getEnrollTrrLogPagination();
		pagination.setListPaginationResults("first",enrollVO.getTrrLogs());
		
		form.setSelectedAgentRow(0);
		form.setListAgentsWithDisplay(enrollVO.getListAgents());
		form.setAgentChanged(false);
		form.setAgentDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setTopDisplayAgentRow(0);
		pagination = context.getEnrollAgentsPagination();
		pagination.setListPaginationResults("first", enrollVO.getListAgents());
		setAgentsLookUp(conn, sessionHelper, form);
		
		form.setSelectedCobRow(0);
		form.setListCobsWithDisplay(enrollVO.getListCobs());
		form.setCobChanged(false);
		form.setCobDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setTopDisplayCobRow(0);
		pagination = context.getEnrollCobsPagination();
		pagination.setListPaginationResults("first", enrollVO.getListCobs());
		//EEMEnrollHelper.setValidOhiList(form);
		
		
/*		//ASES CR For TripleS -Start
		form.setSelectedAsesRow(0);		
		form.setListAsesWithDisplay(enrollVO.getListAses());
		form.setAsesChanged(false);
		form.setAsesDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setTopDisplayAsesRow(0);
		pagination = context.getEnrollAsesPagination();
		pagination.setListPaginationResults("first",enrollVO.getListAses());
		//ASES CR For TripleS -End
		*/
		form.setSelectedBillingRow(0);
		form.setListBillingWithDisplay(enrollVO.getListBilling());
		form.setBillingChanged(false);
		form.setBillingDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setTopDisplayBillingRow(0);
		pagination = context.getEnrollBillingPagination();
		pagination.setListPaginationResults("first", enrollVO.getListBilling());
		/*LEP CR Changes Start.*/
		form.setLepMaximusInfo(enrollVO.getLepMaximusInfo());
		/*LEP CR Changes End.*/
		/**
		 * Cambia POS start
		 */
		form.setSelectedPosEditRow(0);
		form.setListPosWithDisplay(enrollVO.getListPosEdit());
		form.setPoseditChanged(false);
		form.setPosEditDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setTopDisplayPosEditRow(0);
		pagination = context.getEnrollPosInfoPagination();
		pagination.setListPaginationResults("first", enrollVO.getListPosEdit());
		
		
		/**
		 * Cambia POS End
		 */
		
		/**
		 *Cambia_OEVprocess-start
		 */
		
		
			
		try {

			EMMbrTriggerVO trig = null;
			
			trig=oevDao.checkMbrTrigger(conn, emMbrSearchResultVO.getCustomerId(), 
					form.getDisplayEnrollment().getMemberId(),EEMConstants.TRIGGER_TYPE_FOLLOWUP_MEMB, "OEV1");

			if(trig!=null){
			
				form.setOevTimerCheck("true");
			
			} else {
				trig =oevDao.checkMbrTrigger(conn, emMbrSearchResultVO.getCustomerId(), 
						form.getDisplayEnrollment().getMemberId(),EEMConstants.TRIGGER_TYPE_FOLLOWUP_MEMB, "OEV2");

				if(trig!=null){
					
					form.setOevTimerCheck("true");
					
				}
				else{
			
				if(enrollVO.getOevCallAttempts().size()>0) {
					form.setOevTimerCheck("true");
				}else {
					form.setOevTimerCheck("false");
				}
				}
			
			}
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception : " + e.getMessage());
			throw new ApplicationException(e);
		}
		//System.out.println(" in manager oevtimercheck valye"+form.getOevTimerCheck());
		
		form.setOevCallAttempts(enrollVO.getOevCallAttempts());
		form.setDisplaySavedOev(enrollVO.getOevCallStatusSaved());
		form.setDisplaySavedRetOev(enrollVO.getOevRetStatusSaved());
		form.setReturnCalls(enrollVO.getReturnCalls());

		 if(form.getOevCallAttempts()!=null && form.getOevCallAttempts().size() >0 ){
		        EmMbrOevInfoVO latestCall =(EmMbrOevInfoVO)form.getOevCallAttempts().get(form.getOevCallAttempts().size()-1);
		    	if(latestCall.getCallComplete().equals("S")){

                    form.setOevButton("S");
		    	}
				if(latestCall.getStatus().equals("C")&& latestCall.getCallComplete().equals("F"))
					form.setOev2TimerCheck(true);
			
		        }
		        if(form.getReturnCalls() !=null &&  form.getReturnCalls().size() >0){
		        	EmMbrOevInfoVO latestRetCall =(EmMbrOevInfoVO)form.getReturnCalls().get(form.getReturnCalls().size()-1);
		        	if(latestRetCall.getCallComplete().equals("S")){

	                    form.setOevButton("S");
		        	}
				if(latestRetCall.getStatus().equals("C")&& latestRetCall.getCallComplete().equals("F"))
						form.setOev2TimerCheck(true);
				
			       
		        }
		    // UAT It3 -added to hide buttons on cancel status- end
		form.setOevCallStatusSaved(enrollVO.getOevCallStatusSaved());
		form.setOevCallStatus(enrollVO.getOevCallStatus());
		form.setOevRetStatusSaved(enrollVO.getOevRetStatusSaved());
		form.setOevRetStatus(enrollVO.getOevRetStatus());
		form.setOevInfoChanged(false);
		
		//System.out.println("form.getOevTimerCheck()===== "+form.getOevTimerCheck());
		/**
		 * Cambia_OEV-End
		 */
		
		/**
		 *  033_Highmark_OOA_SCC_UI-Start
		 */
		form.setSelectedOoaInfoRow(0);
		form.setListOoaWithDisplay(enrollVO.getOoaInfos());
		form.setOoaChanged(false);
		form.setOoaInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setTopDisplayOoaInfoRow(0);
		pagination = context.getEnrollOoaPagination();
		pagination.setListPaginationResults("first", enrollVO.getOoaInfos());
		form.setPlanDesignation(enrollVO.getPlanDesignation());
		form.setEnrollStatus(enrollVO.getEnrollStatus());
		form.setEnrollReason(enrollVO.getEnrollReason());
		
		
		/**
		 *  033_Highmark_OOA_SCC_UI-End
		 */
		/**
		 * Cambia(Accretion) - Start
		 */

		form.setSelectedAccretionRow(0);
		form.setAccretionDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setListAccretionWithDisplay(enrollVO.getListAccretion());
		form.setTopDisplayAccretionRow(0);
		pagination = context.getEnrollAccretPagination();
		pagination.setListPaginationResults("first",
				enrollVO.getListAccretion());
		/**
		 * Cambia(Accretion) - End
		 */
			/** Triple S BasePlus Migration START **/
			// ASES CR For TripleS -Start
			form.setSelectedAsesRow(0);
			form.setListAsesWithDisplay(enrollVO.getListAses());
			form.setAsesChanged(false);
			form.setAsesDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
			form.setTopDisplayAsesRow(0);
			pagination = context.getEnrollAsesPagination();
			pagination.setListPaginationResults("first", enrollVO.getListAses());
			// ASES CR For TripleS -End
			/** Triple S BasePlus Migration END **/
		}
		 catch (Exception e) {
			 logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
			log.println("Exception : " + e.getMessage());
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public void memberReSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());

		EEMEnrollVO enrollVO = context.getEnrollVO();
		enrollVO.setSearchShowAll(form.getSearchShowAll());
		memberSelect(conn,sessionHelper,context,form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	//New LEP changes - Start
	public void enrollPotentialShowAll(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollService service = new EEMEnrollService();
		EEMEnrollVO enrollVO = context.getEnrollVO();
		/** New LEP changes ShowAll Bug Fixing Start */
		EmMbrLepInfoVO emMbrLepInfoVO=null;
		List lst = enrollVO.getLepPotential();
		int selectedRow = form.getSelectedLepPotentialRow();
		if (lst != null && !lst.isEmpty()) { 
		 emMbrLepInfoVO = (EmMbrLepInfoVO) lst.get(selectedRow);
		}
		/** New LEP changes ShowAll Bug Fixing End */
		enrollVO.setPotentialShowAll(form.getPotentialShowAll());
		/** Fixed 388803 Start */
		EmMbrDemographicVO oldDemoVO = (EmMbrDemographicVO) enrollVO.getDemographics().get(0);
		enrollVO.setSearchMemberId(oldDemoVO.getMemberId());
		/** Fixed 388803 End */
		boolean result= service.potentialShowAll(conn,emMbrLepInfoVO,enrollVO);
		if (result) {
			List lepPotential = enrollVO.getLepPotential();
			if (selectedRow >= lepPotential.size()) {
				selectedRow = lepPotential.size() - 1;
			}
			if (lepPotential.size() <= 0) {
				form.setDisplayLepPotential(new EmMbrLepInfoVO());
				form.setSelectedLepPotentialRow(0);
			} else {
				form.setDisplayLepPotential((EmMbrLepInfoVO)lepPotential.get(selectedRow));
				form.setSelectedLepPotentialRow(selectedRow);
			}
			form.setTotalPlepMonths(enrollVO.getTotalPlepMonths());
			Pagination pagination = context.getEnrollLepPotentialPagination();
			pagination.setPageToDisplayRow(selectedRow,lepPotential);
			Integer topRow = (Integer)pagination.getFirstDetail();						
			form.setTopDisplayLepPotentialRow(topRow.intValue());
		} else {
			form.setMessage("LEP Potential show all Failed");
		}
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	public void EnrollCcfShowAll(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMEnrollService service = new EEMEnrollService();
		EEMEnrollVO enrollVO = context.getEnrollVO();
		List lst = enrollVO.getLepAttestationCcf();
		/** New LEP changes ShowAll Bug Fixing Start */
		EmMbrLepAttestInfoVO emMbrLepAttestInfoVO=null;
		int selectedRow = form.getSelectedLepCcfRow();
		if (lst != null && !lst.isEmpty()) { 
		emMbrLepAttestInfoVO = (EmMbrLepAttestInfoVO) lst.get(selectedRow);
		}
		/** Fixed 388803 Start */
		EmMbrDemographicVO oldDemoVO = (EmMbrDemographicVO) enrollVO.getDemographics().get(0);
		enrollVO.setSearchMemberId(oldDemoVO.getMemberId());
		/** Fixed 388803 End */
		/** New LEP changes ShowAll Bug Fixing End */
		enrollVO.setCcfShowAll(form.getCcfShowAll());
		boolean result= service.ccfShowAll(conn,emMbrLepAttestInfoVO,enrollVO);
		if (result) {
			List lepAttestationCcf = enrollVO.getLepAttestationCcf();
			if (selectedRow >= lepAttestationCcf.size()) {
				selectedRow = lepAttestationCcf.size() - 1;
			}
			if (lepAttestationCcf.size() <= 0) {
				form.setDisplayLepCcfAttestInfo(new EmMbrLepAttestInfoVO());
				form.setSelectedLepCcfRow(0);
			} else {
				form.setDisplayLepCcfAttestInfo((EmMbrLepAttestInfoVO)lepAttestationCcf.get(selectedRow));
				form.setSelectedLepCcfRow(selectedRow);
			}
			Pagination pagination = context.getEnrollLepCcfPagination();
			pagination.setPageToDisplayRow(selectedRow,lepAttestationCcf);
			Integer topRow = (Integer)pagination.getFirstDetail();						
			form.setTopDisplayCcfRow(topRow.intValue());
		} else {
			form.setMessage("LEP Potential show all Failed");
		}
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	//New LEP changes - End

	public void setFieldNames(List lstErrors) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
	
		if (lstErrors != null) {
			EmMbrErrorVO mbrError = null;
			Iterator it = lstErrors.iterator();
			EEMHelper helper = new EEMHelper();
			while (it.hasNext()) {
				mbrError = (EmMbrErrorVO)it.next();
				mbrError.setFieldDispName(helper.getBundleProperty(mbrError.getFieldNbr()));
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public void memberDelete(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		
		String userId = sessionHelper.getUserId();
		String mfId = sessionHelper.getMfId();
		
		String selectedTab = form.getSelectedMemberTab();
		//New LEP changes - Start
		String selectedPotentialTab = form.getSelectedPotentialTab();
		String selectedCcfTab = form.getSelectedCcfTab();
		//New LEP changes - end
		EEMEnrollVO enrollVO = context.getEnrollVO();
		String showAll = enrollVO.getSearchShowAll();
		/**AAH BasePlus Migration IFOX-00426351 Added LOB START*/
		enrollVO.setLineOfBusiness(form.getLineOfBusiness());
		/**AAH BasePlus Migration IFOX-00426351 Added LOB LOB*/
		
		EEMEnrollService service = new EEMEnrollService();
		EEMEnrollDao enrlDao = new EEMEnrollDao();
		/*List lstFields = service.getValidatingFormFields(
				EEMConstants.EEM_ENROLL_FORM, conn, sessionHelper.getMfId());*/
		boolean rslt = false;
		boolean lastAutoCommit = false;
		boolean inTrans = false;
		try {
			lastAutoCommit = conn.getAutoCommit();
			conn.setAutoCommit(false);
			inTrans = true;
			
			EmMbrDemographicVO oldDemoVO = (EmMbrDemographicVO) enrollVO.getDemographics().get(0);
			
			if (EEMConstants.EEM_MBR_TAB_ENROLLMENT.equals(selectedTab)) {

				List lst = enrollVO.getEnrollments();
				int selectedRow = form.getSelectedEnrollmentRow();
				if (lst.size() > 0) {
					EmMbrEnrollmentVO enrlVO = (EmMbrEnrollmentVO)lst.get(selectedRow);
					enrlVO.setCustomerId(oldDemoVO.getCustomerId());
					enrlVO.setMemberId(oldDemoVO.getMemberId());
	
					rslt = service.mbrEnrollmentDelete(conn,enrollVO,enrlVO,userId);
				}
				if (rslt) {
					List enrollments = enrollVO.getEnrollments();
					if (selectedRow >= enrollments.size()) {
						selectedRow = enrollments.size() - 1;
					}
					form.setDisplayEnrollment((EmMbrEnrollmentVO)enrollments.get(selectedRow));
					form.setSelectedEnrollmentRow(selectedRow);

					Pagination pagination = context.getEnrollEnrollPagination();
					pagination.setPageToDisplayRow(selectedRow,enrollments);
					Integer topRow = (Integer)pagination.getFirstDetail();						
					form.setTopDisplayEnrollmentRow(topRow.intValue());
				} else {
					form.setMessage("Enrollment Delete Failed");
				}
			}
			else
			if (EEMConstants.EEM_MBR_TAB_DSINFO.equals(selectedTab)) {

				List lst = enrollVO.getDsInfos();
				int selectedRow = form.getSelectedDsInfoRow();
				if (lst.size() > 0) {
					EmMbrDsInfoVO delVO = (EmMbrDsInfoVO)lst.get(selectedRow);
					delVO.setCustomerId(oldDemoVO.getCustomerId());
					delVO.setMemberId(oldDemoVO.getMemberId());
	
					if (!EEMEnrollHelper.isDsInfoEditable(delVO)) {
						form.setMessage(delVO.getDsCd() + " Can Not Be Deleted");
					} else {				
						rslt = service.mbrDsInfoDelete(conn,enrollVO,delVO,userId);
						if (rslt) {
							List dsInfos = enrollVO.getDsInfos();
							if (selectedRow >= dsInfos.size()) {
								selectedRow = dsInfos.size() - 1;
							}
							form.setDisplayDsInfo((EmMbrDsInfoVO)dsInfos.get(selectedRow));
							form.setSelectedDsInfoRow(selectedRow);
	
							Pagination pagination = context.getEnrollDsInfoPagination();
							pagination.setPageToDisplayRow(selectedRow,dsInfos);
							Integer topRow = (Integer)pagination.getFirstDetail();						
							form.setTopDisplayDsInfoRow(topRow.intValue());
						} else {
							form.setMessage("DS Info Delete Failed");
						}
					}
				} else {
					form.setMessage("DS Info Delete Failed");
				}
			}
			else
			if (EEMConstants.EEM_MBR_TAB_LIS.equals(selectedTab)) {

				List lst = enrollVO.getLisInfos();
				int selectedRow = form.getSelectedLisInfoRow();
				if (lst.size() > 0) {
					EmMbrLisInfoVO delVO = (EmMbrLisInfoVO)lst.get(selectedRow);
					delVO.setCustomerId(oldDemoVO.getCustomerId());
					delVO.setMemberId(oldDemoVO.getMemberId());
	
					rslt = service.mbrLisInfoDelete(conn,enrollVO,delVO,userId);
				}
				if (rslt) {
					List lisInfos = enrollVO.getLisInfos();
					if (selectedRow >= lisInfos.size()) {
						selectedRow = lisInfos.size() - 1;
					}
					if (lisInfos.size() <= 0) {
						form.setDisplayLisInfo(new EmMbrLisInfoVO());
						form.setSelectedLisInfoRow(0);
					} else {
						form.setDisplayLisInfo((EmMbrLisInfoVO)lisInfos.get(selectedRow));
						form.setSelectedLisInfoRow(selectedRow);
					}
					
					Pagination pagination = context.getEnrollLisInfoPagination();
					pagination.setPageToDisplayRow(selectedRow,lisInfos);
					Integer topRow = (Integer)pagination.getFirstDetail();						
					form.setTopDisplayLisInfoRow(topRow.intValue());
				} else {
					form.setMessage("LIS Delete Failed");
				}
			}
			//New LEP changes - Start
			else
				if ("lepCcf".equals(selectedCcfTab)) {
					
					List lst = enrollVO.getLepAttestationCcf();
					int selectedRow = form.getSelectedLepCcfRow();
					if (lst.size() > 0) {
						EmMbrLepAttestInfoVO delVO = (EmMbrLepAttestInfoVO)lst.get(selectedRow);
						delVO.setCustomerId(oldDemoVO.getCustomerId());
						delVO.setMemberId(oldDemoVO.getMemberId());
		
						rslt = service.mbrLepCcfDelete(conn,enrollVO,delVO,userId);
					}
					if (rslt) {
						List lepAttestationCcf = enrollVO.getLepAttestationCcf();
						if (selectedRow >= lepAttestationCcf.size()) {
							selectedRow = lepAttestationCcf.size() - 1;
						}
						if (lepAttestationCcf.size() <= 0) {
							form.setDisplayLepCcfAttestInfo(new EmMbrLepAttestInfoVO());
							form.setSelectedLepCcfRow(0); //IFOX-00390154
						} else {
							form.setDisplayLepCcfAttestInfo((EmMbrLepAttestInfoVO)lepAttestationCcf.get(selectedRow));
							form.setSelectedLepCcfRow(selectedRow); //IFOX-00390154
						}
						
						Pagination pagination = context.getEnrollLepCcfPagination();
						pagination.setPageToDisplayRow(selectedRow,lepAttestationCcf);
						Integer topRow = (Integer)pagination.getFirstDetail();						
						form.setTopDisplayCcfRow(topRow.intValue());
						form.setMessage("LEP Attestation Delete Success");
					} else {
						form.setMessage("LEP Attestation Delete Failed");
					}
				}
			else
				if ("leppotential".equals(selectedPotentialTab)) {

					List lst = enrollVO.getLepPotential();
					int selectedRow = form.getSelectedLepPotentialRow();
					if (lst.size() > 0) {
						EmMbrLepInfoVO delVO = (EmMbrLepInfoVO)lst.get(selectedRow);
						delVO.setCustomerId(oldDemoVO.getCustomerId());
						delVO.setMemberId(oldDemoVO.getMemberId());
		
						rslt = service.mbrLepPotentialDelete(conn,enrollVO,delVO,userId);
					}
					if (rslt) {
						List lepPotential = enrollVO.getLepPotential();
						form.setTotalPlepMonths(enrollVO.getTotalPlepMonths());
						if (selectedRow >= lepPotential.size()) {
							selectedRow = lepPotential.size() - 1;
						}
						if (lepPotential.size() <= 0) {
							form.setDisplayLepPotential(new EmMbrLepInfoVO());
							form.setSelectedLepPotentialRow(0);
						} else {
							form.setDisplayLepPotential((EmMbrLepInfoVO)lepPotential.get(selectedRow));
							form.setSelectedLepPotentialRow(selectedRow);
						}
						
						Pagination pagination = context.getEnrollLepPotentialPagination();
						pagination.setPageToDisplayRow(selectedRow,lepPotential);
						Integer topRow = (Integer)pagination.getFirstDetail();						
						form.setTopDisplayLepPotentialRow(topRow.intValue());
						form.setMessage("LEP Potential Delete Success");
					} else {
						form.setMessage("LEP Potential Delete Failed");
					}
				}
			else
				//New LEP changes - end
			if (EEMConstants.EEM_MBR_TAB_LEP.equals(selectedTab)) {

				List lst = enrollVO.getLepInfos();
				int selectedRow = form.getSelectedLepInfoRow();
				if (lst.size() > 0) {
					EmMbrLepInfoVO delVO = (EmMbrLepInfoVO)lst.get(selectedRow);
					delVO.setCustomerId(oldDemoVO.getCustomerId());
					delVO.setMemberId(oldDemoVO.getMemberId());
	
					rslt = service.mbrLepInfoDelete(conn,enrollVO,delVO,userId);
				}
				if (rslt) {
					List lepInfos = enrollVO.getLepInfos();
					if (selectedRow >= lepInfos.size()) {
						selectedRow = lepInfos.size() - 1;
					}
					if (lepInfos.size() <= 0) {
						form.setDisplayLepInfo(new EmMbrLepInfoVO());
						form.setSelectedLepInfoRow(0);
					} else {
						form.setDisplayLepInfo((EmMbrLepInfoVO)lepInfos.get(selectedRow));
						form.setSelectedLepInfoRow(selectedRow);
					}
					
					Pagination pagination = context.getEnrollLepInfoPagination();
					pagination.setPageToDisplayRow(selectedRow,lepInfos);
					Integer topRow = (Integer)pagination.getFirstDetail();						
					form.setTopDisplayLepInfoRow(topRow.intValue());
				} else {
					form.setMessage("LEP Delete Failed");
				}
			}
			else
			if (EEMConstants.EEM_MBR_TAB_ADDRESS.equals(selectedTab)) {

				List lst = enrollVO.getAddresses();
				int selectedRow = form.getSelectedAddressRow();
				if (lst.size() > 0) {
					EmMbrAddressVO delVO = (EmMbrAddressVO)lst.get(selectedRow);
					delVO.setCustomerId(oldDemoVO.getCustomerId());
					delVO.setMemberId(oldDemoVO.getMemberId());
	
					rslt = service.mbrAddressDelete(conn,enrollVO,delVO,userId);
				}
				if (rslt) {
					List addresses = enrollVO.getAddresses();
					if (selectedRow >= addresses.size()) {
						selectedRow = addresses.size() - 1;
					}
					form.setDisplayAddress((EmMbrAddressVO)addresses.get(selectedRow));
					form.setSelectedAddressRow(selectedRow);

					Pagination pagination = context.getEnrollAddressPagination();
					pagination.setPageToDisplayRow(selectedRow,addresses);
					Integer topRow = (Integer)pagination.getFirstDetail();						
					form.setTopDisplayAddressRow(topRow.intValue());
				} else {
					form.setMessage("Address Delete Failed");
				}
			}
			else
			if (EEMConstants.EEM_MBR_TAB_PCP.equals(selectedTab)) {

				List lst = enrollVO.getPcpInfos();
				int selectedRow = form.getSelectedPcpInfoRow();
				EmMbrEnrollmentVO enrollmentVO = form.getDisplayEnrollment();
				String groupId= enrollmentVO.getGrpId();
				String productId = enrollmentVO.getProductId();
				String plan = enrollmentVO.getPlanId();
				String requestScrn = "pcp";
				
				String fieldNbr = null;
				if (lst.size() > 0) {
					EMMbrPCPInfoVO delVO = (EMMbrPCPInfoVO)lst.get(selectedRow);
					delVO.setCustomerId(oldDemoVO.getCustomerId());
					delVO.setMemberId(oldDemoVO.getMemberId());
	
					rslt = service.mbrPcpInfoDelete(conn,enrollVO,delVO,userId);
				}
				if (rslt) {
					List pcpInfos = enrollVO.getPcpInfos();
					if (selectedRow >= pcpInfos.size()) {
						selectedRow = pcpInfos.size() - 1;
					}
					if (pcpInfos.size() <= 0) {
						form.setDisplayPcpInfo(new EMMbrPCPInfoVO());
						form.setSelectedPcpInfoRow(0);						
					} else {
						form.setDisplayPcpInfo((EMMbrPCPInfoVO)pcpInfos.get(selectedRow));
						form.setSelectedPcpInfoRow(selectedRow);
						EMMbrPCPInfoVO newVO = (EMMbrPCPInfoVO)pcpInfos.get(selectedRow);
						// I2 UAT Changes -- Start
					/*	List lstErrors = service.validateEnrolledPCP(conn,enrollVO,newVO,lstFields,userId,groupId,productId,plan);
						if(lstErrors != null && lstErrors.size() > 0){
							for(int i=0; i < 1; i++){
								EmMbrErrorVO objError = null;
								objError = (EmMbrErrorVO)lstErrors.get(i);
								fieldNbr = objError.getFieldNbr();
							}
							 service.setErrorDetails(conn,lstErrors,newVO.getCustomerId(),newVO.getMemberId(),userId,fieldNbr,requestScrn);
						}*/
					}
					
					Pagination pagination = context.getEnrollPcpInfoPagination();
					pagination.setPageToDisplayRow(selectedRow,pcpInfos);
					Integer topRow = (Integer)pagination.getFirstDetail();						
					form.setTopDisplayPcpInfoRow(topRow.intValue());

				} else {
					form.setMessage("PCP Delete Failed");
				}
			}
			//IFOX-00399921 LTC Tab. START
			else if (EEMConstants.EEM_MBR_TAB_LTC.equals(selectedTab)) {
				List lst = enrollVO.getLtcInfos();
				int selectedRow = form.getSelectedLtcInfoRow();
				EmMbrEnrollmentVO enrollmentVO = form.getDisplayEnrollment();
				
				if (lst.size() > 0) {
					EMMbrLTCInfoVO delVO = (EMMbrLTCInfoVO) lst.get(selectedRow);
					delVO.setCustomerId(oldDemoVO.getCustomerId());
					delVO.setMemberId(oldDemoVO.getMemberId());

					rslt = service.mbrLtcInfoDelete(conn, enrollVO, delVO, userId);
				}
				if (rslt) {
					List ltcInfos = enrollVO.getLtcInfos();
					if (selectedRow >= ltcInfos.size()) {
						selectedRow = ltcInfos.size() - 1;
					}
					if (ltcInfos.size() <= 0) {
						form.setDisplayLtcInfo(new EMMbrLTCInfoVO());
						form.setSelectedLtcInfoRow(0);
					} else {
						form.setDisplayLtcInfo((EMMbrLTCInfoVO) ltcInfos.get(selectedRow));
						form.setSelectedLtcInfoRow(selectedRow);
						EMMbrLTCInfoVO newVO = (EMMbrLTCInfoVO) ltcInfos.get(selectedRow);
				}

					Pagination pagination = context.getEnrollLtcInfoPagination();
					pagination.setPageToDisplayRow(selectedRow, ltcInfos);
					Integer topRow = (Integer) pagination.getFirstDetail();
					form.setTopDisplayLtcInfoRow(topRow.intValue());

				} else {
					form.setMessage("LTC Delete Failed");
				}
			}//IFOX-00399921 LTC Tab. END
			else if (EEMConstants.EEM_MBR_TAB_COB.equals(selectedTab)) {

				List lst = enrollVO.getListCobs();
				int selectedRow = form.getSelectedCobRow();
				if (lst.size() > 0) {
					EmMbrCobVO delVO = (EmMbrCobVO)lst.get(selectedRow);
					delVO.setCustomerId(oldDemoVO.getCustomerId());
					delVO.setMemberId(oldDemoVO.getMemberId());
	
					rslt = service.mbrCobDelete(conn,enrollVO,delVO,userId);
				}
				if (rslt) {
					List lstCob = enrollVO.getListCobs();
					if (selectedRow >= lstCob.size()) {
						selectedRow = lstCob.size() - 1;
					}
					if (lstCob.size() <= 0) {
						form.setDisplayCob(new EmMbrCobVO());
						form.setSelectedCobRow(0);						
					} else {
						form.setDisplayCob((EmMbrCobVO)lstCob.get(selectedRow));
						form.setSelectedCobRow(selectedRow);
					}
					
					Pagination pagination = context.getEnrollCobsPagination();
					pagination.setPageToDisplayRow(selectedRow,lstCob);
					Integer topRow = (Integer)pagination.getFirstDetail();						
					form.setTopDisplayCobRow(topRow.intValue());

				} else {
					form.setMessage("COB Delete Failed");
				}
			}
			else
			if (EEMConstants.EEM_MBR_TAB_BILLING.equals(selectedTab)) {

				List lst = enrollVO.getListBilling();
				int selectedRow = form.getSelectedBillingRow();
				
				if (lst.size() > 0) {	
					EmMbrBillingVO delVO = (EmMbrBillingVO)lst.get(selectedRow);
					delVO.setCustomerId(oldDemoVO.getCustomerId());
					delVO.setMemberId(oldDemoVO.getMemberId());
	
					rslt = service.mbrBillingDelete(conn,enrollVO,delVO,userId);
				}
				if (rslt) {
					List lstBilling = enrollVO.getListBilling();
					if (selectedRow >= lstBilling.size()) {
						selectedRow = lstBilling.size() - 1;
					}
					if (lstBilling.size() <= 0) {
						form.setDisplayBilling(new EmMbrBillingVO());
						form.setSelectedBillingRow(0);						
					} else {
						form.setDisplayBilling((EmMbrBillingVO)lstBilling.get(selectedRow));
						form.setSelectedBillingRow(selectedRow);
					}
					
					Pagination pagination = context.getEnrollBillingPagination();
					pagination.setPageToDisplayRow(selectedRow,lstBilling);
					Integer topRow = (Integer)pagination.getFirstDetail();						
					form.setTopDisplayBillingRow(topRow.intValue());

				} else {
					form.setMessage("Billing Delete Failed");
				}
			}
			else
			if (EEMConstants.EEM_MBR_TAB_AGENT.equals(selectedTab)) {

				List lst = enrollVO.getListAgents();
				int selectedRow = form.getSelectedAgentRow();
				String requestScrn="agent";
				if (lst.size() > 0) {	
					EmMbrAgentVO delVO = (EmMbrAgentVO)lst.get(selectedRow);
					delVO.setCustomerId(oldDemoVO.getCustomerId());
					delVO.setMemberId(oldDemoVO.getMemberId());
	
					rslt = service.mbrAgentDelete(conn,enrollVO,delVO,userId);
				}
				if (rslt) {
					List lstAgent = enrollVO.getListAgents();
					if (selectedRow >= lstAgent.size()) {
						selectedRow = lstAgent.size() - 1;
					}
					if (lstAgent.size() <= 0) {
						form.setDisplayAgent(new EmMbrAgentVO());
						form.setSelectedAgentRow(0);						
					} else {
						form.setDisplayAgent((EmMbrAgentVO)lstAgent.get(selectedRow));
						form.setSelectedAgentRow(selectedRow);
						EmMbrAgentVO newVO = (EmMbrAgentVO)lstAgent.get(selectedRow);
						// I2 UAT Changes -- Start
						String fieldNbr = null;
						/*List lstErrors = service.validateEnrolledAgent(conn,enrollVO,newVO,lstFields,userId);
						if(lstErrors != null && lstErrors.size() > 0){
							for(int i=0; i < 1; i++){
								EmMbrErrorVO objError = null;
								objError = (EmMbrErrorVO)lstErrors.get(i);
								fieldNbr = objError.getFieldNbr();
							}
							 service.setErrorDetails(conn,lstErrors,newVO.getCustomerId(),newVO.getMemberId(),userId,fieldNbr,requestScrn);
						}*/
					}
					
					Pagination pagination = context.getEnrollAgentsPagination();
					pagination.setPageToDisplayRow(selectedRow,lstAgent);
					Integer topRow = (Integer)pagination.getFirstDetail();						
					form.setTopDisplayAgentRow(topRow.intValue());

				} else {
					form.setMessage("Agent Delete Failed");
				}
			}
			
			/**
			 * cambia pos start
			 */
			else 
				if (EEMConstants.EEM_MBR_TAB_POS.equals(selectedTab)) {
			String posDeleteMsg = null;
			rslt = true;
			List lst = enrollVO.getListPosEdit();
			int selectedRow = form.getSelectedPosEditRow();
			if (lst.size() > 0) {
				EmMbrPosEditVO delVO = (EmMbrPosEditVO)lst.get(selectedRow);
				delVO.setCustomerId(oldDemoVO.getCustomerId());
				delVO.setMemberId(oldDemoVO.getMemberId());
				
				if(delVO.getTxnStatus()!= null && !((delVO.getTxnStatus().equalsIgnoreCase("Mcareerr"))
						|| (delVO.getTxnStatus().equalsIgnoreCase("CMSFAIL")|| 
								((delVO.getTxnStatus().equalsIgnoreCase("CMSREADY")))))){
					rslt = false;
					posDeleteMsg = " Only CMSFAIL/MCAREERR/CMSREADY status POS record can be deleted ";
				}
                if(rslt){
				rslt = service.mbrPosInfoDelete(conn,enrollVO,delVO,userId);
                }
			}
			if (rslt) {
				List posInfos = enrollVO.getListPosEdit();
				if (selectedRow >= posInfos.size()) {
					selectedRow = posInfos.size() - 1;
				}
				if (posInfos.size() <= 0) {
					form.setDisplayPosEdit(new EmMbrPosEditVO());
					form.setSelectedLisInfoRow(0);
				} else {
					form.setDisplayPosEdit((EmMbrPosEditVO)posInfos.get(selectedRow));
					form.setSelectedPosEditRow(selectedRow);
				}
				
				Pagination pagination = context.getEnrollPosInfoPagination();
				pagination.setPageToDisplayRow(selectedRow,posInfos);
				Integer topRow = (Integer)pagination.getFirstDetail();						
				form.setTopDisplayPosEditRow(topRow.intValue());
			} else {
				if(posDeleteMsg == null){
				form.setMessage("POS Delete Failed");
				}else{
					form.setMessage(posDeleteMsg);
				}
			}
		}
			/** Triple S BasePlus Migration START **/
			// ASES CR For TripleS - Start
			else if (EEMConstants.EEM_MBR_TAB_ASES.equals(selectedTab)) {
				List lst = enrollVO.getListAses();
				int selectedRow = form.getSelectedAsesRow();
				if (lst.size() > 0) {
					EmMbrAsesVO delVO = (EmMbrAsesVO) lst.get(selectedRow);
					delVO.setCustomerId(oldDemoVO.getCustomerId());
					delVO.setMemberId(oldDemoVO.getMemberId());

					rslt = service.mbrAsesDelete(conn, enrollVO, delVO, userId);
				}
				if (rslt) {
					List asesInfo = enrollVO.getListAses();
					if (selectedRow >= asesInfo.size()) {
						selectedRow = asesInfo.size() - 1;
					}
					if (asesInfo.size() <= 0) {
						form.setDisplayAses(new EmMbrAsesVO());
						form.setSelectedAsesRow(0);
					} else {
						form.setDisplayAses((EmMbrAsesVO) asesInfo.get(selectedRow));
						form.setSelectedAsesRow(selectedRow);
					}

					Pagination pagination = context.getEnrollAsesPagination();
					pagination.setPageToDisplayRow(selectedRow, asesInfo);
					Integer topRow = (Integer) pagination.getFirstDetail();
					form.setTopDisplayAsesRow(topRow.intValue());
				} else {
					form.setMessage("ASES Delete Failed");
				}
			}
			// ASES CR For TripleS - End
			/** Triple S BasePlus Migration END **/
			/**
			 * cambia pos end
			 */
			
			
			if (rslt) {
				conn.commit();
				inTrans = false;
			}
			if(rslt) {
				enrollVO.setErrors(enrlDao.getMbrErrors(conn, oldDemoVO.getCustomerId(), oldDemoVO.getMemberId()));
				setFieldNames(enrollVO.getErrors());
			}
			
		} catch (SQLException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception : " + e.getMessage());
			throw new DaoException(Constants.EXCEPTION_MSG, e);
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception : " + e.getMessage());
			throw new ApplicationException(e);
		}finally {
			if (inTrans) {
				try {
					conn.rollback();
				} catch(Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
				}
			}
			try {
				conn.setAutoCommit(lastAutoCommit);
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
			}
		}
		
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void memberUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form) throws ApplicationException  {
		logger.info(LoggerConstants.methodStartLevel());
	
		String userId = sessionHelper.getUserId();
		String mfId = sessionHelper.getMfId();
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		String mcCustNbr = sessionHelper.getCustomerNumber();
		//New LEP Changes - start
//		uncovStDate
		form.setEnroll_effStartDate(form.getDisplayLepInfo().getEnroll_effStartDate());
		//form.setEnroll_effStartDate(form.getDisplayLepInfo().getEnroll_effStartDate());
		//New LEP Changes - END
		String selectedTab = form.getSelectedMemberTab();

		EEMEnrollVO enrollVO = context.getEnrollVO();
		enrollVO.setDsInfosUpdated(false);
		//Start IFOX-00389053 
		enrollVO.setLineOfBusiness(form.getLineOfBusiness());
		//End IFOX-00389053

		
		List oldDsInfos = null;
		/**
		 * 033_Highmark_OAASCCprocess - Start
		 */
		EEMEnrollDao enrlDao = new EEMEnrollDao();
		EEMEnrollService service = new EEMEnrollService();
		EEMEnrollOoaService ooaService = new EEMEnrollOoaService();
		EEMEnrollOoaDao ooaDao = new EEMEnrollOoaDao();
		
		/**
		 * 033_Highmark_OAASCCprocess - End
		 */
		
		List lstFields = service.getValidatingFormFields(
				EEMConstants.EEM_ENROLL_FORM, conn, sessionHelper.getMfId());
		boolean rslt = false;
		boolean lastAutoCommit = false;
		boolean inTrans = false;
		try {
			//String val = EEMProfileSettings.getCalendarProfileItem(conn,mfId,EEMProfileSettings.SUPPLID);

			lastAutoCommit = conn.getAutoCommit();
			conn.setAutoCommit(false);
			inTrans = true;
			
			EmMbrDemographicVO oldDemoVO = (EmMbrDemographicVO) enrollVO.getDemographics().get(0);
			
			if (EEMConstants.EEM_MBR_TAB_DEMOGRAPHIC.equals(selectedTab)) {
				if (form.isDemographicChanged()) {

					EmMbrDemographicVO newVO = form.getDisplayDemographic();
					
					EmMbrDemographicVO wrkVO = (EmMbrDemographicVO)newVO.clone();
					
					//IFOX - 431608 : CMS Changes 2020 - start
					rslt = service.mbrDemoUpdate(conn,oldDemoVO,wrkVO,userId,enrollVO);
					//IFOX - 431608 : CMS Changes 2020 - end
					if (rslt) {
						//IFOX - 431608 : CMS Changes 2020 - start				
						EmMbrDemographicVO mbrDemo = enrlDao.getMbrDemographicForEffMth(conn, oldDemoVO.getCustomerId(),
								oldDemoVO.getMemberId(), oldDemoVO.getCmsEffMo());
						enrollVO.getDemographics().set(0, mbrDemo);
						//IFOX - 431608 : CMS Changes 2020 - end
						form.setDisplayDemographic((EmMbrDemographicVO)enrollVO.getDemographics().get(0));
						form.setDemographicChanged(false);
						//IFOX - 431608 : CMS Changes 2020 - start
						if(!StringUtil.nonNullTrim(enrollVO.getMessage()).equals(""))
							form.setMessage(enrollVO.getMessage());
					} else {
						//IFOX - 431608 : CMS Changes 2020 - start
						if(!StringUtil.nonNullTrim(enrollVO.getMessage()).equals(""))
							form.setMessage(enrollVO.getMessage());
						else
						form.setMessage("Demographic Update Failed");
						//IFOX - 431608 : CMS Changes 2020 - end
					}
				} else {
					form.setMessage("Data Not Changes");
				}
			}
			else
			if (EEMConstants.EEM_MBR_TAB_ENROLLMENT.equals(selectedTab)) {
				if (form.isEnrollmentChanged()) {
				
					EmMbrEnrollmentVO newVO = form.getDisplayEnrollment();
					newVO.setCustomerId(oldDemoVO.getCustomerId());
					newVO.setMemberId(oldDemoVO.getMemberId());
					newVO.setEditOverrideInd(StringUtil.YorBlank(newVO.getEditOverrideInd()));
					
					EmMbrEnrollmentVO wrkVO = (EmMbrEnrollmentVO)newVO.clone();
					wrkVO.setOverrideInd("N");
	
					rslt = service.mbrEnrollmentUpdate(conn,eemDb,enrollVO,oldDemoVO,wrkVO,userId,mcCustNbr);
					if (rslt) {
						// Performance Changes -Start
						EmMbrEnrollmentVO topEnrollSegment=(EmMbrEnrollmentVO)enrollVO.getEnrollments().get(0);
						enrollVO.setPlanDesignation(topEnrollSegment.getPlanDesignation());
						enrollVO.setEnrollStatus(topEnrollSegment.getEnrollStatus());
					    enrollVO.setEnrollReason(topEnrollSegment.getEnrollReasonCd());
					  //0427630-OPEN : TSA Supress LEP process Platino Members - start
						String lepPlatinoFlag = enrlDao.getLepPlatinoFlag(conn, newVO.getCustomerId(), newVO.getMemberId());
						enrollVO.setSuppLepPlatino(lepPlatinoFlag);
						form.setSuppLepPlatino(lepPlatinoFlag);
						//0427630-OPEN : TSA Supress LEP process Platino Members - end
						/*enrollVO.setPlanDesignation(ooaDao.getMbrPlan(conn, oldDemoVO.getCustomerId(), oldDemoVO.getMemberId()));
						String[] enrollDetails = new String[2];
						enrollDetails=ooaDao.getMbrStatus(conn, oldDemoVO.getCustomerId(), oldDemoVO.getMemberId());
						*//**
						 *  Cambia_OOASCCprocess - Start
						 *//*
					    if(enrollDetails!= null){
									    enrollVO.setEnrollStatus(enrollDetails[0]);
									    enrollVO.setEnrollReason(enrollDetails[1]);
						} else {
									    	enrollVO.setEnrollStatus("");
										    enrollVO.setEnrollReason("");
							 }*/
					 // Performance Changes -end
					    /**
						 *  Cambia_OOASCCprocess - End
						 */
						int seqNbr = service.findDatedSeqNbr(enrollVO.getEnrollments(),wrkVO);
						if (seqNbr == -1)
							seqNbr = 0;
						form.setDisplayEnrollment((EmMbrEnrollmentVO)enrollVO.getEnrollments().get(seqNbr));
						form.setSelectedEnrollmentRow(seqNbr);
						form.setEnrollmentChanged(false);
						form.setEnrollmentDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
						
						//Begin: Added for IFOX-00396582
						if(service.isPCPRemovalFlagEnabled(conn, newVO) && isForDisEnrollment(newVO))
						{
							this.updatePCPDetails(conn, service, enrollVO, oldDemoVO, wrkVO, userId);
							service.loadUpdatedPCPDetails(conn, newVO, enrollVO);
							form.setSelectedPcpInfoRow(0);
							form.setListPcpInfosWithDisplay(enrollVO.getPcpInfos());		
							form.setPcpInfoChanged(false);
							form.setPcpInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
							form.setTopDisplayPcpInfoRow(0);
							Pagination pagination = context.getEnrollPcpInfoPagination();
							pagination.setListPaginationResults("first",enrollVO.getPcpInfos());
						}
						//End: Added for IFOX-00396582
						/** Triple S BasePlus Migration START **/
						//Begin: Added for CR-IFOX-00389914 
						if(service.isAgentRemovalFlagEnabled(conn, newVO) && isForDisEnrollment(newVO))
						{
							this.updateAgentDetails(conn, service, enrollVO, oldDemoVO, wrkVO, userId);
							/**AAH BasePlus Migration IFOX-00426351 Added LOB START*/
							List agentInfos = new EEMEnrollDao().getMbrAgents(conn, oldDemoVO.getCustomerId(), oldDemoVO.getMemberId(), 
									enrollVO.getSearchShowAll(),enrollVO.getLineOfBusiness());	
							/**AAH BasePlus Migration IFOX-00426351 Added LOB END*/
							enrollVO.setListAgents(agentInfos);
							
							// Added for IFOX-00409714 :Start
							if(null != enrollVO.getListAgents() && enrollVO.getListAgents().size() > 0)
							{
							// Added for IFOX-00409714 :End
								int seqNbr1 = 0;
								form.setDisplayAgent((EmMbrAgentVO)enrollVO.getListAgents().get(seqNbr1));
								form.setSelectedAgentRow(seqNbr1);
								form.setAgentChanged(false);
								form.setAgentDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
	
								Pagination pagination = context.getEnrollAgentsPagination();
								pagination.setPageToDisplayRow(seqNbr1,enrollVO.getListAgents());
								Integer topRow = (Integer)pagination.getFirstDetail();						
								form.setTopDisplayAgentRow(topRow.intValue());
							}
						}
						//End
						/** Triple S BasePlus Migration END **/
						
						//Begin: Added for IFOX-00404244
						if(service.isBillingRemovalFlagEnabled(conn, newVO) && isForDisEnrollment(newVO))
						{
							this.updateBillingDetails(conn, service, enrollVO, oldDemoVO, wrkVO, userId);
							service.loadUpdatedBillingDetails(conn, newVO, enrollVO);
							
							form.setSelectedBillingRow(0);
							form.setListBillingWithDisplay(enrollVO.getListBilling());
							form.setBillingChanged(false);
							form.setBillingDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
							form.setTopDisplayBillingRow(0);
							Pagination pagination = context.getEnrollBillingPagination();
							pagination.setListPaginationResults("first",enrollVO.getListBilling());
							
						}
						//End: Added for IFOX-00404244
						
						Pagination pagination = context.getEnrollEnrollPagination();
						pagination.setPageToDisplayRow(seqNbr,enrollVO.getEnrollments());
						Integer topRow = (Integer)pagination.getFirstDetail();						
						form.setTopDisplayEnrollmentRow(topRow.intValue());
					} else {
						form.setMessage("Enrollment Update Failed");
						EEMCodeCache cc = EEMCodeCache.getInstance();
						form.setValidEnrollReasons(cc.getEnrollReasonFor(form.getDisplayEnrollment().getEnrollStatus()));
					}
				} else {
					form.setMessage("Data Not Changes");
					EEMCodeCache cc = EEMCodeCache.getInstance(); // just in case
					form.setValidEnrollReasons(cc.getEnrollReasonFor(form.getDisplayEnrollment().getEnrollStatus()));					
				}
			}
			else
			if (EEMConstants.EEM_MBR_TAB_DSINFO.equals(selectedTab)) {
				if (form.isDsInfoChanged()) {

					EmMbrDsInfoVO newVO = form.getDisplayDsInfo();
					newVO.setCustomerId(oldDemoVO.getCustomerId());
					newVO.setMemberId(oldDemoVO.getMemberId());
					//Super User changes - start
					newVO.setDsValue(StringUtil.nonNullTrim(newVO.getDsValue()));
					//Super User changes - end
					if (!EEMEnrollHelper.isDsInfoEditable(newVO)) {
						form.setMessage(newVO.getDsCd() + " Can Not Be Deleted");
					} else {										
						EmMbrDsInfoVO wrkVO = (EmMbrDsInfoVO)newVO.clone();
						wrkVO.setOverrideInd("N");
						
						rslt = service.mbrDsInfoUpdate(conn,eemDb,enrollVO,wrkVO,userId); //AllyALign Migration issue
						if (rslt) {
							int seqNbr = service.findDatedSeqNbr(enrollVO.getDsInfos(),wrkVO);
							if (seqNbr == -1)
								seqNbr = 0;
							form.setDisplayDsInfo((EmMbrDsInfoVO)enrollVO.getDsInfos().get(seqNbr));
							form.setSelectedDsInfoRow(seqNbr);
							form.setDsInfoChanged(false);
							form.setDsInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);

							Pagination pagination = context.getEnrollDsInfoPagination();
							pagination.setPageToDisplayRow(seqNbr,enrollVO.getDsInfos());
							Integer topRow = (Integer)pagination.getFirstDetail();						
							form.setTopDisplayDsInfoRow(topRow.intValue());
						} else {
							form.setMessage("DS Info Update Failed");
						}
					}
				} else {
					form.setMessage("Data Not Changes");
				}
			}
			else
			if (EEMConstants.EEM_MBR_TAB_LIS.equals(selectedTab)) {
				if (form.isLisInfoChanged()) {

					EmMbrLisInfoVO newVO = form.getDisplayLisInfo();
					newVO.setCustomerId(oldDemoVO.getCustomerId());
					newVO.setMemberId(oldDemoVO.getMemberId());
					// check boxes come in as null if not checked
					newVO.setLicBaeInd(StringUtil.YorN(newVO.getLicBaeInd()));
					newVO.setLisBaeInd(StringUtil.YorN(newVO.getLisBaeInd()));
					
					EmMbrLisInfoVO wrkVO = (EmMbrLisInfoVO)newVO.clone();
					wrkVO.setOverrideInd("N");
					wrkVO.setLisAmt(NumberFormatter.formatDecimal2Places(wrkVO.getLisAmt()));
					wrkVO.setSpapAmt(NumberFormatter.formatDecimal2Places(wrkVO.getSpapAmt()));
					
					rslt = service.mbrLisInfoUpdate(conn,enrollVO,wrkVO,userId);
					if (rslt) {
						int seqNbr = service.findDatedSeqNbr(enrollVO.getLisInfos(),wrkVO);
						if (seqNbr == -1)
							seqNbr = 0;
						form.setDisplayLisInfo((EmMbrLisInfoVO)enrollVO.getLisInfos().get(seqNbr));
						form.setSelectedLisInfoRow(seqNbr);
						form.setLisInfoChanged(false);
						form.setLisInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);

						Pagination pagination = context.getEnrollLisInfoPagination();
						pagination.setPageToDisplayRow(seqNbr,enrollVO.getLisInfos());
						Integer topRow = (Integer)pagination.getFirstDetail();						
						form.setTopDisplayLisInfoRow(topRow.intValue());
					} else {
						form.setMessage("LIS Update Failed");
					}
				} else {
					form.setMessage("Data Not Changes");
				}
			}
			/** @author Surya
			  * UseCaseName 024_Cambia_LEP - Start 3
			  */
			else
				if (EEMConstants.EEM_MBR_TAB_LEP.equals(selectedTab)) {
					//Iteration 2 UAT change for LEp Changes-start
					EmMbrLepAttestInfoVO newVO = form.getDisplayLepAttestInfo();						
					
					newVO.setCustomerId(oldDemoVO.getCustomerId());
					newVO.setMemberId(oldDemoVO.getMemberId());
					newVO.setEffEndDate("99999999");	
					newVO.setIncompAttestLetRecDate(form.getIncompAttestLetRecDate());
					newVO.setStatusCd(form.getStatusCd());
					newVO.setAttestStatus(form.getStatusCd());
					//New LEP Changes - Start
					newVO.setUncovStDate(form.getEnroll_effStartDate());	
					//New LEP Changes - END
					//newVO.setIncStatusCd(form.getIncStatusCd());
					  newVO.setAttestationRecDate(form.getAttestationRecDate());
					  newVO.setAttestationRecChannel(form.getAttestationRecChannel());
					  newVO.setNotifiedMemberAppeal(form.getNotifiedMemberAppeal());
					  newVO.setComptRespRecDate(form.getComptRespRecDate());
					//New LEP changes - Start
					  newVO.setRespType(form.getResp());
					//New LEP changes - end
					
					
					newVO.setBrkInCoverage(form.getBrkInCoverage());
					newVO.setCredRXCoverage(form.getCredRXCoverage());
					newVO.setFromDate(form.getFromDate());
					newVO.setToDate(form.getToDate());
					/*new LEP CR Changes Start.*/
					newVO.setSelectedLepMemberSubTab(form.getSelectedLepMemberSubTab());
					newVO.setSelectedAttnLepMemberSubTab(form.getSelectedAttnLepMemberSubTab());
					form.setLepInfoChanged(true);
					if (form.isLepInfoChanged()) {
						try {
							// setting LEP Maximus - LEP changes
							form.setLepMaximusInfo(service.getLepMaximusDetails(conn, mfId, newVO.getMemberId()));
						} catch (Exception e) {
							logger.error(LoggerConstants.exceptionMessage(e.toString()));
							logger.debug("Error in getting LEP Maximus");
							e.printStackTrace();
						}
						
						/*new LEP CR Changes End.*/
						form.setLepInfoChanged(false);
						if(form.getSelectedLepMemberSubTab().equalsIgnoreCase(EEMConstants.EEM_MBR_TAB_LEP_SUMM)){
							if(enrollVO.getLepInfos() != null && enrollVO.getLepInfos().size() > 0){
								EmMbrLepInfoVO chkVO = (EmMbrLepInfoVO) enrollVO.getLepInfos().get(0);
		                        if(StringUtil.nonNullTrim(chkVO.getEffStartDateFrmt()).equals("")){
		                              enrollVO.getLepInfos().clear();
		                        }
							}
							
							EmMbrLepInfoVO new1VO = form.getDisplayLepInfo();
							new1VO.setCustomerId(oldDemoVO.getCustomerId());
							new1VO.setMemberId(oldDemoVO.getMemberId());
							// Added for IFOX-00378733
							new1VO.setStatusCd(form.getStatusCd());
			
							EmMbrLepInfoVO wrkVO = (EmMbrLepInfoVO)new1VO.clone();
			
							
							wrkVO.setOverrideInd("N");
							wrkVO.setAttestStatus(newVO.getAttestStatus());		
							wrkVO.setIncompAttestLetRecDate(DateFormatter.reFormat(newVO.getIncompAttestLetRecDate(),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD));
							wrkVO.setLepAmt(NumberFormatter.formatDecimal2Places(wrkVO.getLepAmt()));
							wrkVO.setLepWaivedAmt(NumberFormatter.formatDecimal2Places(wrkVO.getLepWaivedAmt()));
							//modified below line for New Lep Changes
							rslt = service.mbrLepInfoUpdate(conn,enrollVO,wrkVO,userId,true);
							if (rslt) {
								int seqNbr = service.findDatedSeqNbr(enrollVO.getLepInfos(),wrkVO);
								if (seqNbr == -1)
									seqNbr = 0;
								if(enrollVO.getLepInfos().size() > 0)
								form.setDisplayLepInfo((EmMbrLepInfoVO)enrollVO.getLepInfos().get(seqNbr));
								
								// 024 - LEP To Display all the values of LEP Summary/Attestion/NunCMoTr 
								form.setListLepAttestInfosWithDisplay(enrollVO.getLepAttestInfo());
								form.setOutInitAttests(enrollVO.getOutInitAttests());
								form.setInInitAttests(enrollVO.getInInitAttests());
								form.setOutIncAttests(enrollVO.getOutIncAttests());
								form.setInIncAttests(enrollVO.getInIncAttests());
								form.setInLateAttests(enrollVO.getInLateAttests());
								
								form.setSelectedLepInfoRow(seqNbr);
								form.setLepInfoChanged(false);
								form.setLepInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		
								Pagination pagination = context.getEnrollLepInfoPagination();
								pagination.setPageToDisplayRow(seqNbr,enrollVO.getLepInfos());
								Integer topRow = (Integer)pagination.getFirstDetail();						
								form.setTopDisplayLepInfoRow(topRow.intValue());
								form.setMessage("LEP-Summary Update Success");
							} else {
								// 024 - LEP To Display all the values of LEP Summary/Attestion/NunCMoTr 
								form.setListLepAttestInfosWithDisplay(enrollVO.getLepAttestInfo());
								form.setOutInitAttests(enrollVO.getOutInitAttests());
								form.setInInitAttests(enrollVO.getInInitAttests());
								form.setOutIncAttests(enrollVO.getOutIncAttests());
								form.setInIncAttests(enrollVO.getInIncAttests());
								form.setInLateAttests(enrollVO.getInLateAttests());
								form.setMessage("LEP Update Failed");
								
							}
						}//Summary
						/**
						* 024_Highmark_SUC_LEP -NUNCMOTr- Start
						*/
						else if(form.getSelectedLepMemberSubTab().equalsIgnoreCase(EEMConstants.EEM_MBR_TAB_LEP_NUNCMO)){  
							if (form.isLepNunCmoInfoChanged()) {
								form.setLepNunCmoInfoChanged(false);
								List oiAttests = null;
								List iiAttests = null;
								List oIncAttests = null;
								List iIncAttests = null;
								List ilAttests = null;
								//Iteration 2 UAT-start
								DateUtil du = new DateUtil();
								String ts = du.getDB2DTS();
								//Iteration 2 UAT-end
								//-- Outbound Initial Attestation.
								if(form.getOutInitAttestDate() != null ){
									oiAttests = new ArrayList();
									EmMbrLepNunCmoVO cmot = null;
										for(int i=0; i<form.getOutInitAttestDate().length; i++){
											if( !(form.getOutInitAttestDate()[i].trim().equals("")) && !(form.getOutInitAttestStatus()[i].trim().equals(""))){
												cmot = new EmMbrLepNunCmoVO();
												cmot.setIndex(i+1);//(index);
												cmot.setAttempt( new Integer(i+1).toString() );//( new Integer(index).toString() );
												cmot.setDate(form.getOutInitAttestDate()[i]);
												cmot.setStatus(form.getOutInitAttestStatus()[i]);
												cmot.setUserID(form.getOutInitAttestUserID()[i]);
												cmot.setChange(form.getOutInitAttestChange()[i]);
												//Iteration 2 UAT-start
												cmot.setCreateTime(form.getOutInitAttestCreateTime()[i].trim().equals("") ? ts : form.getOutInitAttestCreateTime()[i]);
												//Iteration 2 UAT-end
												oiAttests.add(cmot);
											}//if
										}	
									//}//if
									form.setOutInitAttests(oiAttests);
									enrollVO.setOutInitAttests(oiAttests);
								}
															
								//-- Inbound Initial Attestation.
								if(form.getInInitAttestDate() != null){
									iiAttests = new ArrayList();
									EmMbrLepNunCmoVO cmoIIA = null;
										for(int i=0; i<form.getInInitAttestDate().length; i++){
											if( !(form.getInInitAttestDate()[i].trim().equals("")) && !(form.getInInitAttestStatus()[i].trim().equals(""))){
												cmoIIA = new EmMbrLepNunCmoVO();
												cmoIIA.setIndex(i+1);//(index);
												cmoIIA.setAttempt( new Integer(i+1).toString() );//( new Integer(index).toString() );
												cmoIIA.setDate(form.getInInitAttestDate()[i]);
												cmoIIA.setStatus(form.getInInitAttestStatus()[i]);
												cmoIIA.setUserID(form.getInInitAttestUserID()[i]);
												cmoIIA.setChange(form.getInInitAttestChange()[i]);
												//Iteration 2 UAT-start
												cmoIIA.setCreateTime(form.getInInitAttestCreateTime()[i].trim().equals("") ? ts : form.getInInitAttestCreateTime()[i]);
												//Iteration 2 UAT-end
												iiAttests.add(cmoIIA);
											}//if
										}	
									//}//if
									form.setInInitAttests(iiAttests);
									enrollVO.setInInitAttests(iiAttests);
								}
								
								//-- Outbound Incomplete Attestation.
								if(form.getOutIncAttestDate() != null){
									oIncAttests = new ArrayList();
									EmMbrLepNunCmoVO cmooIncAtt = null;
										for(int i=0; i<form.getOutIncAttestDate().length; i++){
											if( !(form.getOutIncAttestDate()[i].trim().equals("")) && !(form.getOutIncAttestStatus()[i].trim().equals(""))){
												cmooIncAtt = new EmMbrLepNunCmoVO();
												cmooIncAtt.setIndex(i+1);//(index);
												cmooIncAtt.setAttempt( new Integer(i+1).toString() );//( new Integer(index).toString() );
												cmooIncAtt.setDate(form.getOutIncAttestDate()[i]);
												cmooIncAtt.setStatus(form.getOutIncAttestStatus()[i]);
												cmooIncAtt.setUserID(form.getOutIncAttestUserID()[i]);
												cmooIncAtt.setChange(form.getOutIncAttestChange()[i]);
												//Iteration 2 UAT-start
												cmooIncAtt.setCreateTime(form.getOutIncAttestCreateTime()[i].trim().equals("") ? ts : form.getOutIncAttestCreateTime()[i]);
												//Iteration 2 UAT-end
												oIncAttests.add(cmooIncAtt);
											}//if
										}	
									//}//if
									form.setOutIncAttests(oIncAttests);
									enrollVO.setOutIncAttests(oIncAttests);
								}
								
								//-- Inbound Incomplete Attestation.
								if(form.getInIncAttestDate() != null){
									iIncAttests = new ArrayList();
									EmMbrLepNunCmoVO cmoIIncAttests = null;
										for(int i=0; i<form.getInIncAttestDate().length; i++){
											if( !(form.getInIncAttestDate()[i].trim().equals("")) && !(form.getInIncAttestStatus()[i].trim().equals(""))){
												cmoIIncAttests = new EmMbrLepNunCmoVO();
												cmoIIncAttests.setIndex(i+1);//(index);
												cmoIIncAttests.setAttempt( new Integer(i+1).toString() );//( new Integer(index).toString() );
												cmoIIncAttests.setDate(form.getInIncAttestDate()[i]);
												cmoIIncAttests.setStatus(form.getInIncAttestStatus()[i]);
												cmoIIncAttests.setUserID(form.getInIncAttestUserID()[i]);
												cmoIIncAttests.setChange(form.getInIncAttestChange()[i]);
												//Iteration 2 UAT-start
												cmoIIncAttests.setCreateTime(form.getInIncAttestCreateTime()[i].trim().equals("") ? ts : form.getInIncAttestCreateTime()[i]);
												//Iteration 2 UAT-end
												iIncAttests.add(cmoIIncAttests);
											}//if
										}	
									//}//if
									form.setInIncAttests(iIncAttests);
									enrollVO.setInIncAttests(iIncAttests);
								}
								
								//-- Inbound late Attestation.
								if(form.getInLateoInitAttestDate() != null){
									ilAttests = new ArrayList();
									EmMbrLepNunCmoVO cmoOLA = null;
										for(int i=0; i<form.getInLateoInitAttestDate().length; i++){
											if( !(form.getInLateoInitAttestDate()[i].trim().equals("")) && !(form.getInLateAttestStatus()[i].trim().equals(""))){
												cmoOLA = new EmMbrLepNunCmoVO();
												cmoOLA.setIndex(i+1);//(index);
												cmoOLA.setAttempt( new Integer(i+1).toString() );//( new Integer(index).toString() );
												cmoOLA.setDate(form.getInLateoInitAttestDate()[i]);
												cmoOLA.setStatus(form.getInLateAttestStatus()[i]);
												cmoOLA.setUserID(form.getInLateAttestUserID()[i]);
												cmoOLA.setChange(form.getInLateAttestChange()[i]);
												//Iteration 2 UAT-start
												cmoOLA.setCreateTime(form.getInLateAttestCreateTime()[i].trim().equals("") ? ts : form.getInLateAttestCreateTime()[i]);
												//Iteration 2 UAT-end
												ilAttests.add(cmoOLA);
											}//if										
										}	
									//}//if
									form.setInLateAttests(ilAttests);
									enrollVO.setInLateAttests(ilAttests);
								}
								
								//Iteration 2 UAT change for LEp Changes-start
								//Updating to DB using service class.	
								rslt = service.setMbrLepNunCmo(conn,userId, enrollVO, oldDemoVO.getCustomerId(), oldDemoVO.getMemberId(), oiAttests, iiAttests, oIncAttests, iIncAttests, ilAttests, newVO);
								if(!rslt ){
									form.setMessage("No Row(s) Updates");
								}	
							}else{
								form.setListLepAttestInfosWithDisplay(enrollVO.getLepAttestInfo());
								form.setMessage("Data Not Changes NunCmo");
							}
							//Iteration 2 UAT change for LEp Changes-end
							}
						/** 024_Highmark_SUC_LEP -NUNCMOTr- End
						 */
						//LEP - Attestation
						else if(form.getSelectedLepMemberSubTab().equalsIgnoreCase(EEMConstants.EEM_MBR_TAB_LEP_ATTEST)){
						  logger.debug("Entered Attest");
						  	//IFOX-00390415 fix.
						  	enrollVO.setPotentiallepEffDate(form.getPotentiallepEffDate());
						  	rslt = service.mbrLepAttestInfoUpdate(conn,enrollVO,newVO,userId,"");
							if (rslt) {								
								form.setListLepAttestInfosWithDisplay(enrollVO.getLepAttestInfo());
								form.setListLepPotential(enrollVO.getLepPotential());
								form.setListLepPotentialWithDisplay(enrollVO.getLepPotential());
								//New LEP changes - Start
								form.setListLepAttestCcfWithDisplay(enrollVO.getLepAttestationCcf());
								form.setComptRespRecDate(null);
								form.setCredRXCoverage(null);
								form.setBrkInCoverage(null);
								form.setFromDate(null);
								form.setToDate(null);
								form.setResp(null);
								//New LEP changes - end							
								form.setMessage("LEP Update Success");							
							} else {							
								form.setListLepAttestInfosWithDisplay(enrollVO.getLepAttestInfo());			
								//New LEP changes - Start
								form.setListLepAttestCcfWithDisplay(enrollVO.getLepAttestationCcf());
								//New LEP changes - end
								form.setMessage("LEP Update Failed");
							}			
							//024 -LEP Attestation - Start
						
						}
						//New LEP changes - Start
						else if(form.getSelectedPotentialTab().equalsIgnoreCase(EEMConstants.EEM_MBR_TAB_LEP_POTENTIAL)){
							EmMbrLepInfoVO insertVO = form.getDisplayLepPotential();
							enrollVO.setPotentiallepEffDate(form.getPotentiallepEffDate());
							enrollVO.setPtuncovMthStDt(form.getPtuncovMthStDt());
							enrollVO.setPtuncovMthEndDt(form.getPtuncovMthEndDt());
							
							insertVO.setCustomerId(oldDemoVO.getCustomerId());
							insertVO.setMemberId(oldDemoVO.getMemberId());
							//IFOX-00390415 START
							insertVO.setPotentiallepEffDate(form.getPotentiallepEffDate());
							insertVO.setPotentialuncovMthStDt(form.getPtuncovMthStDt());
							insertVO.setPotentialuncovMthEndDt(form.getPtuncovMthEndDt());
							insertVO.setPotentialCreateUserId(userId);
							//IFOX-00390415 START
							rslt = service.mbrLepPotentialInsert(conn, enrollVO, insertVO);
							if (rslt) {
								form.setListLepPotential(enrollVO.getLepPotential());
								form.setListLepPotentialWithDisplay(enrollVO.getLepPotential());
								form.setMessage("LEP Potential Insert Success");
							} else {
								form.setListLepPotential(enrollVO.getLepPotential());
								form.setListLepPotentialWithDisplay(enrollVO.getLepPotential());
								form.setMessage("LEP Potential Insert Failed");
							}
							List lepPotential = form.getListLepPotential();
							Pagination pagination = context.getEnrollLepPotentialPagination();
	
							pagination.setFirstDetail(new Integer(form.getTopDisplayLepPotentialRow()));
							pagination.setSelectedLine(form.getSelectedLepPotentialRow());
	
							pagination.setListPaginationResults("first", lepPotential);
	
							Integer newTop = (Integer) pagination.getFirstDetail();
							form.setTopDisplayLepPotentialRow(newTop.intValue());
							form.setSelectedLepPotentialRow(pagination.getSelectedLine());
							form.setPtuncovMthStDt(null);
							form.setPtuncovMthEndDt(null);
						}
						//New LEP changes - End		
					
					} else {
						form.setMessage("Data Not Changes LEP Summary");
					}
				//Iteration 2 UAT change for LEp Changes-start
				try{
					
					EEMOevDao oevDao = new EEMOevDao();
					EMMbrTriggerVO trig1 = oevDao.checkMbrTrigger(conn, oldDemoVO.getCustomerId(), 
						oldDemoVO.getMemberId(),
						EEMConstants.TRIGGER_TYPE_FOLLOWUP_MEMB, "LE21");
				if(trig1!=null){
					//System.out.println(" value of le21"+trig1.getTriggerStatus());
					if(trig1.getTriggerStatus().equals(EEMConstants.TRIGGER_STATUS_OPEN)) 
						form.setLe21TimerCheck("true"); //LE21 timer open 
					 else
						form.setLe21TimerCheck("closed");//LE21 timer closed
			
				}
				else 
					form.setLe21TimerCheck("false");
				//System.out.println(" value of timer"+form.getLe21TimerCheck());
				logger.debug(" value of Le21 timer check"+form.getLe21TimerCheck());
				
				EMMbrTriggerVO trig2 = oevDao.checkMbrTrigger(conn, oldDemoVO.getCustomerId(), 
						oldDemoVO.getMemberId(),
						EEMConstants.TRIGGER_TYPE_FOLLOWUP_MEMB, "OBC3");
				if(trig2!=null){
					
					if(trig2.getTriggerStatus().equals(EEMConstants.TRIGGER_STATUS_OPEN)) 
						form.setObc3TimerCheck("true"); //LE21 timer open 
					 else
						form.setObc3TimerCheck("closed");//LE21 timer closed
			
				}
				else 
					form.setObc3TimerCheck("false");
				//System.out.println(" value of timer"+form.getObc3TimerCheck());
				logger.debug(" value of obc3 timer check"+form.getObc3TimerCheck());
				
				
				EMMbrTriggerVO trig3 = oevDao.checkMbrTrigger(conn, oldDemoVO.getCustomerId(), 
						oldDemoVO.getMemberId(),
						EEMConstants.TRIGGER_TYPE_FOLLOWUP_MEMB, "OBC1");
				if(trig3!=null){
					
					if(trig3.getTriggerStatus().equals(EEMConstants.TRIGGER_STATUS_OPEN)) 
						form.setObc1TimerCheck("true"); //LE21 timer open 
					 else
						form.setObc1TimerCheck("closed");//LE21 timer closed
			
				}
				else 
					form.setObc1TimerCheck("false");
				//System.out.println(" value of timer"+form.getObc1TimerCheck());
				logger.debug(" value of Obc1 timer check"+form.getObc1TimerCheck());
				
				
				EMMbrTriggerVO trig4 = oevDao.checkMbrTrigger(conn, oldDemoVO.getCustomerId(), 
						oldDemoVO.getMemberId(),
						EEMConstants.TRIGGER_TYPE_FOLLOWUP_MEMB, "OBC2");
				if(trig4!=null){
					
					if(trig4.getTriggerStatus().equals(EEMConstants.TRIGGER_STATUS_OPEN)) 
						form.setObc2TimerCheck("true"); //LE21 timer open 
					 else
						form.setObc2TimerCheck("closed");//LE21 timer closed
			
				}
				else 
					form.setObc2TimerCheck("false");
				//System.out.println(" value of timer"+form.getObc2TimerCheck());
				logger.debug(" value of Obc2 timer check"+form.getObc2TimerCheck());
				
				}catch(Exception e){
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug(" Getting  Timer status: "+e.getMessage());
				}
			}
			//Iteration 2 UAT change for LEp Changes-end
					
					/** @author Surya
					  * UseCaseName 024_Cambia_LEP - End 3
					  */
			else
			if (EEMConstants.EEM_MBR_TAB_PCP.equals(selectedTab)) {
				if (form.isPcpInfoChanged()) {

					EMMbrPCPInfoVO newVO = form.getDisplayPcpInfo();
					EmMbrEnrollmentVO enrollmentVO = form.getDisplayEnrollment();
					newVO.setCustomerId(oldDemoVO.getCustomerId());
					newVO.setMemberId(oldDemoVO.getMemberId());
					// check boxes come in as null if not checked
					newVO.setCurrentPatientInd(StringUtil.YorN(newVO.getCurrentPatientInd()));
					String groupId= enrollmentVO.getGrpId();
					String productId = enrollmentVO.getProductId();
					String plan = enrollmentVO.getPlanId();
					String applDate = enrollmentVO.getApplicationDate();
					EMMbrPCPInfoVO wrkVO = (EMMbrPCPInfoVO)newVO.clone();
					//EMMbrPCPInfoVO wrkVO = (EMMbrPCPInfoVO)newVO.clone();
					wrkVO.setOverrideInd("N");
					//IFOX-00423161 PCP LOB Error : start
					EMMbrPCPInfoVO medOfficeVO = service.checkPcp(conn,wrkVO,form.getLobValidation());
					//IFOX-00423161 PCP LOB Error : end
					if (medOfficeVO == null) {
						form.setMessage("PCP Is Not Valid for the Effective Date");
					} else {
						rslt = service.mbrPcpInfoUpdate(conn,enrollVO,wrkVO,lstFields,userId,groupId,productId,plan,applDate);
						if (rslt) {
							int seqNbr = service.findDatedSeqNbr(enrollVO.getPcpInfos(),wrkVO);
							if (seqNbr == -1)
								seqNbr = 0;
							form.setDisplayPcpInfo((EMMbrPCPInfoVO)enrollVO.getPcpInfos().get(seqNbr));
							form.setSelectedPcpInfoRow(seqNbr);
							form.setPcpInfoChanged(false);
							form.setPcpInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);

							Pagination pagination = context.getEnrollPcpInfoPagination();
							pagination.setPageToDisplayRow(seqNbr,enrollVO.getPcpInfos());
							Integer topRow = (Integer)pagination.getFirstDetail();						
							form.setTopDisplayPcpInfoRow(topRow.intValue());
						
						} else {
							form.setMessage("Pcp Update Failed");
						}
					}
				} else {
					form.setMessage("Data Not Changes");
				}
			}//IFOX-00399921 LTC Tab. START
			else if (EEMConstants.EEM_MBR_TAB_LTC.equals(selectedTab)) {
				if (form.isLtcInfoChanged()) {
					EMMbrLTCInfoVO newVO = form.getDisplayLtcInfo();
					EmMbrEnrollmentVO enrollmentVO = form.getDisplayEnrollment();
					newVO.setCustomerId(oldDemoVO.getCustomerId());
					newVO.setMemberId(oldDemoVO.getMemberId());
					String groupId = enrollmentVO.getGrpId();
					String productId = enrollmentVO.getProductId();
					String plan = enrollmentVO.getPlanId();
					String applDate = enrollmentVO.getApplicationDate();
					EMMbrLTCInfoVO wrkVO = (EMMbrLTCInfoVO) newVO.clone();
					wrkVO.setOverrideInd("N");

					rslt = service.checkLtcFacility(conn, wrkVO);
					if (!rslt) {
						form.setMessage("LTC Is Not Valid for the Effective Date");
					} else {
						rslt = service.mbrLtcInfoUpdate(conn, enrollVO, wrkVO, lstFields, userId, groupId, productId,
								plan, applDate);
						if (rslt) {
							int seqNbr = service.findDatedSeqNbr(enrollVO.getLtcInfos(), wrkVO);
							if (seqNbr == -1)
								seqNbr = 0;
							form.setDisplayLtcInfo((EMMbrLTCInfoVO) enrollVO.getLtcInfos().get(seqNbr));
							form.setSelectedLtcInfoRow(seqNbr);
							form.setLtcInfoChanged(false);
							form.setLtcInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);

							Pagination pagination = context.getEnrollLtcInfoPagination();
							pagination.setPageToDisplayRow(seqNbr, enrollVO.getLtcInfos());
							Integer topRow = (Integer) pagination.getFirstDetail();
							form.setTopDisplayLtcInfoRow(topRow.intValue());

						} else {
							form.setMessage("LTC Update Failed");
						}
					}
				} else {
					form.setMessage("Data Not Changes");
				}
			}
			//IFOX-00399921 LTC Tab. END
			else if (EEMConstants.EEM_MBR_TAB_ADDRESS.equals(selectedTab)) {
				if (form.isAddressChanged()) {

					EmMbrAddressVO newVO = form.getDisplayAddress();
					
					//Triple-S Migration - Address tab - allow any day of the month - Start
					newVO.setAddressValidation((String)sessionHelper.getAttribute("ADRVAL"));
					//Triple-S Migration - Address tab - allow any day of the month - End
					
					newVO.setCustomerId(oldDemoVO.getCustomerId());
					newVO.setMemberId(oldDemoVO.getMemberId());
					
					EmMbrAddressVO wrkVO = (EmMbrAddressVO)newVO.clone();
					wrkVO.setOverrideInd("N");
					
					rslt = service.checkStateZip(conn,wrkVO);
					if (!rslt) {
						form.setMessage("State code of " + wrkVO.getStateAbbr() + " is not in Zip code");
					} else {
						oldDsInfos = enrollVO.getDsInfos();

						rslt = service.mbrAddressUpdate(conn,enrollVO,wrkVO,userId);
						if (rslt) {
							int seqNbr = service.findDatedSeqNbr(enrollVO.getAddresses(),wrkVO);
							if (seqNbr == -1)
								seqNbr = 0;
							form.setDisplayAddress((EmMbrAddressVO)enrollVO.getAddresses().get(seqNbr));
							form.setSelectedAddressRow(seqNbr);
							form.setAddressChanged(false);
							form.setAddressDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
							
							Pagination pagination = context.getEnrollPcpInfoPagination();
							pagination.setPageToDisplayRow(seqNbr,enrollVO.getPcpInfos());
							Integer topRow = (Integer)pagination.getFirstDetail();						
							form.setTopDisplayPcpInfoRow(topRow.intValue());
							
							if (!service.checkCityZip(conn, (EmMbrAddressVO)enrollVO.getAddresses().get(seqNbr), wrkVO.getZipCd5())) {
								form.setMessage("Save Complete\\n\\nWarning: City Name doesnot match with Zip Code");
							}
							
						} else {
							form.setMessage("Address Update Failed");
						}
					}
				} else {
					form.setMessage("Data Not Changes");
				}
			}
			else
			if (EEMConstants.EEM_MBR_TAB_COMMENTS.equals(selectedTab)) {
				if (form.isCommentChanged()) {
					/**
					 * Cambia_PRE-SET NOTES - Start
					 */ 
					EmMbrCommentVO newVO = form.getDisplayComment();
					newVO.setCustomerId(oldDemoVO.getCustomerId());
					newVO.setMemberId(oldDemoVO.getMemberId());
					 String presetnote = form.getPreSetNoteM(); 
					  String presetnoteDesc= form.getPreSetNoteDescr();
					  String indicator =form.getIndicator();
					  String radioCheck = form.getRadioCheck();
					 
					EmMbrCommentVO wrkVO = (EmMbrCommentVO)newVO.clone();

					   if(indicator.equals("C"))//C is indicator for Comments button
	                   {
						rslt = service.mbrCommentInsert(conn,enrollVO,wrkVO,userId);
						if (rslt) {
							form.setDisplayComment((EmMbrCommentVO)enrollVO.getComments().get(0));
							form.setSelectedCommentRow(0);
							form.setCommentChanged(false);
							form.setCommentDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);						

							form.setTopDisplayCommentRow(0);
							Pagination pagination = context.getEnrollCommentPagination();
							pagination.setListPaginationResults("first",enrollVO.getComments());
						
							try {
							EMMbrTriggerVO trig = null;
							EEMOevDao oevDao = new EEMOevDao();
							trig=oevDao.checkMbrTrigger(conn, oldDemoVO.getCustomerId(), 
									oldDemoVO.getMemberId(),EEMConstants.TRIGGER_TYPE_FOLLOWUP_MEMB, "OEV1");
						
							if(trig!=null){
							
								
								form.setOevTimerCheck("true");
								
						
							}
							else {
									trig =oevDao.checkMbrTrigger(conn, oldDemoVO.getCustomerId(), 
											oldDemoVO.getMemberId(),EEMConstants.TRIGGER_TYPE_FOLLOWUP_MEMB, "OEV2");
									
									if(trig!=null){
									
										
										form.setOevTimerCheck("true");
										
										
											
										
									}

									else
										form.setOevTimerCheck("false");
									
							} 
						
						} catch (Exception e) {
							logger.error(LoggerConstants.exceptionMessage(e.toString()));
						}
						EEMOevService oevSetvice = new EEMOevService(); 
						int applId = form.getDisplayEnrollment().getApplicationId();
						form.setOevCallAttempts(oevSetvice.getMbrOevInfo(conn, oldDemoVO.getCustomerId(), oldDemoVO.getMemberId(),applId,"O", enrollVO));
					    form.setReturnCalls(oevSetvice.getMbrOevInfo(conn, oldDemoVO.getCustomerId(), oldDemoVO.getMemberId(), applId,"R",enrollVO)); 
					
					    form.setDisplaySavedOev(enrollVO.getOevCallStatusSaved());
					    form.setDisplaySavedRetOev(enrollVO.getOevRetStatusSaved());
						form.setOevCallStatusSaved(enrollVO.getOevCallStatusSaved());
						form.setOevCallStatus(enrollVO.getOevCallStatus());
						form.setOevRetStatusSaved(enrollVO.getOevRetStatusSaved());
						form.setOevRetStatus(enrollVO.getOevRetStatus());
						//form.setOevButton(enrollVO.getOevButton());
						
						} else {
							form.setMessage("Comment Add Failed");
						}
					}
					else
						{
						EEMCodeCache cc = EEMCodeCache.getInstance();
						if(radioCheck.equals("A")){//A is indicator for adding preset note
						rslt = service.addPreSetNote(conn, presetnote, presetnoteDesc,oldDemoVO);
						form.setPreSetDisplayState((EEMConstants.EEM_MBR_SCREEN_EDIT));
						if(rslt){
							// Performance Changes -Start
							conn.commit();
							/*enrollVO.setMaxId(form.getMaxId());
					     	List mp = enrlDao.getPreSetNotes(conn,enrollVO, sessionHelper.getMfId());
					     	form.setPreSetNoteList(mp);*/
							EEMPersistence eemPer = new EEMPersistence();
							Map hmPreSetNotesTemp=eemPer.getPreSetNotes();
							cc.setHmPreSetNotes(hmPreSetNotesTemp);
							form.setPreSetNoteList(cc.getHmPreSetNotes(sessionHelper.getMfId()));
							// Performance Changes -end
							form.setMessage("Added successfully");
						}
						
					       }
						
						else if(radioCheck.equals("M"))//M is indicator for modifying preset note
						{
							String preSetKey = form.getPreSetKey();
							
						rslt = service.modifyPreSetNote(conn, presetnote, presetnoteDesc,preSetKey,oldDemoVO);
						//form.setPreSetDisplayState((EEMConstants.EEM_MBR_SCREEN_EDIT));	
	                  	 if(rslt){
	                  	// Performance Changes -Start
	                  		conn.commit();
                     		/*enrollVO.setMaxId(form.getMaxId());
							List mp = enrlDao.getPreSetNotes(conn,enrollVO,oldDemoVO.getCustomerId());
						
							form.setPreSetNoteList(mp);*/
	                  		EEMPersistence eemPer = new EEMPersistence();
							Map hmPreSetNotesTemp=eemPer.getPreSetNotes();
							cc.setHmPreSetNotes(hmPreSetNotesTemp);
							form.setPreSetNoteList(cc.getHmPreSetNotes(sessionHelper.getMfId()));
							// Performance Changes -end
								form.setMessage("Modified successfully");
							}
							
									
						}
						else if(radioCheck.equals("D"))//D is indicator for deleting preset note
						{
							
							rslt = service.deletePreSetNote(conn,presetnote,presetnoteDesc,oldDemoVO);
							//form.setPreSetDisplayState((EEMConstants.EEM_MBR_SCREEN_EDIT));	
							
							if(rslt){
								// Performance Changes -Start
								conn.commit();
								/*enrollVO.setMaxId(form.getMaxId());
								List mp = enrlDao.getPreSetNotes(conn,enrollVO,oldDemoVO.getCustomerId());
							   form.setPreSetNoteList(mp);*/
								EEMPersistence eemPer = new EEMPersistence();
								Map hmPreSetNotesTemp=eemPer.getPreSetNotes();
								cc.setHmPreSetNotes(hmPreSetNotesTemp);
								form.setPreSetNoteList(cc.getHmPreSetNotes(sessionHelper.getMfId()));
								// Performance Changes -End
							form.setMessage("Deleted successfully");
							} }
						
	                   }
				}
				/**
				 * Cambia_PRE-SET NOTES - End
				 */ else {
						form.setMessage("Data Not Changes");
					}
			}
			else
			if (EEMConstants.EEM_MBR_TAB_AGENT.equals(selectedTab)) {
				if (form.isAgentChanged()) {

					EmMbrAgentVO newVO = form.getDisplayAgent();
					EmMbrEnrollmentVO enrollmentVO = form.getDisplayEnrollment();
					String applDate = enrollmentVO.getApplicationDate();
					newVO.setCustomerId(oldDemoVO.getCustomerId());
					newVO.setMemberId(oldDemoVO.getMemberId());
					
					EmMbrAgentVO wrkVO = (EmMbrAgentVO)newVO.clone();
					wrkVO.setOverrideInd("N");
					
					rslt = service.mbrAgentUpdate(conn,enrollVO,wrkVO,userId,lstFields,applDate);
					if (rslt) {
						int seqNbr = service.findDatedSeqNbr(enrollVO.getListAgents(),wrkVO);
						if (seqNbr == -1)
							seqNbr = 0;
						form.setDisplayAgent((EmMbrAgentVO)enrollVO.getListAgents().get(seqNbr));
						form.setSelectedAgentRow(seqNbr);
						form.setAgentChanged(false);
						form.setAgentDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);

						Pagination pagination = context.getEnrollAgentsPagination();
						pagination.setPageToDisplayRow(seqNbr,enrollVO.getListAgents());
						Integer topRow = (Integer)pagination.getFirstDetail();						
						form.setTopDisplayAgentRow(topRow.intValue());
					
					} else {
						form.setMessage("Agent Update Failed");
					}
				} else {
					form.setMessage("Data Not Changes");
				}
			}
			else
			if (EEMConstants.EEM_MBR_TAB_COB.equals(selectedTab)) {
				if (form.isCobChanged()) {

					EmMbrCobVO newVO = form.getDisplayCob();
					newVO.setCustomerId(oldDemoVO.getCustomerId());
					newVO.setMemberId(oldDemoVO.getMemberId());
					
					EmMbrCobVO wrkVO = (EmMbrCobVO)newVO.clone();
					wrkVO.setOverrideInd("N");
					/** Triple S BasePlus Migration START **/
					/** CENTENE Changes for Ticket IFOX-00364733. START **/
					/** Bypass the start Date validation for CENETNE Customer **/
					enrollVO.setCobValidation((String) sessionHelper.getAttribute("BYPASSCOBDATE"));
					/** CENTENE Changes for Ticket IFOX-00364733. END **/
					/** Triple S BasePlus Migration END **/
					rslt = service.mbrCobUpdate(conn,enrollVO,wrkVO,userId);
					if (rslt) {
						int seqNbr = service.findDatedSeqNbr(enrollVO.getListCobs(),wrkVO);
						if (seqNbr == -1)
							seqNbr = 0;
						form.setDisplayCob((EmMbrCobVO)enrollVO.getListCobs().get(seqNbr));
						form.setSelectedCobRow(seqNbr);
						form.setCobChanged(false);
						form.setCobDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);

						Pagination pagination = context.getEnrollCobsPagination();
						pagination.setPageToDisplayRow(seqNbr,enrollVO.getListCobs());
						Integer topRow = (Integer)pagination.getFirstDetail();						
						form.setTopDisplayCobRow(topRow.intValue());
					
					} else {
						form.setMessage("COB Update Failed");
					}
				} else {
					form.setMessage("Data Not Changes");
				}
			}
			else
			if (EEMConstants.EEM_MBR_TAB_BILLING.equals(selectedTab)) {
				if (form.isBillingChanged()) {

					EmMbrBillingVO newVO = form.getDisplayBilling();
					newVO.setCustomerId(oldDemoVO.getCustomerId());
					newVO.setMemberId(oldDemoVO.getMemberId());
					
					EmMbrBillingVO wrkVO = (EmMbrBillingVO)newVO.clone();
					wrkVO.setOverrideInd("N");
					
					rslt = service.mbrBillingUpdate(conn,enrollVO,wrkVO,userId);
					if (rslt) {
						int seqNbr = service.findDatedSeqNbr(enrollVO.getListBilling(),wrkVO);
						if (seqNbr == -1)
							seqNbr = 0;
						form.setDisplayBilling((EmMbrBillingVO)enrollVO.getListBilling().get(seqNbr));
						form.setSelectedBillingRow(seqNbr);
						form.setBillingChanged(false);
						form.setBillingDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);

						Pagination pagination = context.getEnrollBillingPagination();
						pagination.setPageToDisplayRow(seqNbr,enrollVO.getListBilling());
						Integer topRow = (Integer)pagination.getFirstDetail();						
						form.setTopDisplayBillingRow(topRow.intValue());
					
					} else {
						form.setMessage("Billing Update Failed");
					}
				} else {
					form.setMessage("Data Not Changes");
				}
			}
			/**
			* Cambia_OEV � Start
			*/
			 else if(EEMConstants.EEM_MBR_TAB_OEV.equals(selectedTab)){
				 	
				 	
				 	
		             EEMOevService oevSetvice = new EEMOevService();
		        	 String button = form.getOevButton();
		        	 EmMbrOevInfoVO mbrOevVO =  form.getOevInfo();
		        	 EmMbrOevInfoVO mbrOevReturn = form.getOevRetInfo();
		        	 List oevCalAttempts = new ArrayList();
		        	 List returnCalls = new ArrayList();
		        	
		        	 //If oevinfo changed retrieve OEv data
		        	 if (form.isOevInfoChanged()) {
							form.setOevInfoChanged(false);
									if(mbrOevVO!=null){
											if(form.getOevButton().equals("F"))
											mbrOevVO.setCallComplete("F");
											else if(form.getOevButton().equals("S"))
											mbrOevVO.setCallComplete("S");
											mbrOevVO.setCallType("O");
											oevCalAttempts.add(mbrOevVO);
											form.setOevCallAttempts(oevCalAttempts);
											enrollVO.setOevCallAttempts(oevCalAttempts);
											
										}//if
		        	 }
		        	 //If return call infocanged, retrieve data 
		        	 if(form.isOevReturnInfoChanged()){
		        		   form.setOevReturnInfoChanged(false);
		        		  // System.out.println("mbr oevvo"+mbrOevReturn.getAttempt()+mbrOevReturn.getStatus()+form.isOevCheck());
									if(mbrOevReturn!=null && !(mbrOevReturn.getStatus().equals("")||mbrOevReturn.getStatus()==null)){
									
										if((mbrOevReturn.getAttempt()==null || mbrOevReturn.getAttempt().equals("")) && form.isOevCheck())
										mbrOevReturn.setAttempt(mbrOevVO.getAttempt());
										if(form.getOevButton().equals("F"))
										mbrOevReturn.setCallComplete("F");
										else if(form.getOevButton().equals("S"))
										mbrOevReturn.setCallComplete("S");
										
										mbrOevReturn.setCallType("R");
										returnCalls.add(mbrOevReturn);
										form.setReturnCalls(returnCalls);
										enrollVO.setReturnCalls(returnCalls);
										
									}//if
								
					}
				    
		        	 //getting applId
					int applId = form.getDisplayEnrollment().getApplicationId();
					//System.out.println("applId..."+applId);
					
					//Update service call
				    rslt = oevSetvice.setMbrOevUpdate(conn, oldDemoVO.getCustomerId(),enrollVO,oldDemoVO.getMemberId(),
						  mbrOevVO, mbrOevReturn,oevCalAttempts,returnCalls,button,oldDemoVO, applId);
						
				    if(rslt){ 
				    
				    	
				    	//If Oev data modified, check condition for highlighting comments tab
				    	if(mbrOevVO!=null){
				    		
				    		if(mbrOevVO.getStatus().equals("I")&& mbrOevVO.getSubsetReason().equals("O")&&StringUtil.nonNullTrim(mbrOevVO.getCallComplete()).equals("S")){
				    			 form.setSelectedMemberTab("comments");
				    			 form.setMessage("Please enter comments!");
				    		}
				    		
				    	    if(mbrOevVO.getStatus().equals("N")&& mbrOevVO.getSubsetReason().equals("O")&&StringUtil.nonNullTrim(mbrOevVO.getCallComplete()).equals("S")){
				    		 form.setSelectedMemberTab("comments");
				    		 form.setMessage("Please enter comments!");
				    	    
				    	    }
				    	} 
				    	//If Oev return data modified, check condition for highlighying comments tab
				    	if(mbrOevReturn!=null){
				    		
				    		if(mbrOevReturn.getStatus().equals("I")&& mbrOevReturn.getSubsetReason().equals("O")&&StringUtil.nonNullTrim(mbrOevReturn.getCallComplete()).equals("S")){
				    		 form.setSelectedMemberTab("comments");
				    		 form.setMessage("Please enter comments!");
				    		}
				    	    if(mbrOevReturn.getStatus().equals("N")&& mbrOevReturn.getSubsetReason().equals("O")&&StringUtil.nonNullTrim(mbrOevReturn.getCallComplete()).equals("S")){
				    		 form.setSelectedMemberTab("comments");
				    		 form.setMessage("Please enter comments!");
				    	    }
				    	}
				    	 
				   }
				    //In case of Failed update, setting error message
				   else
				 
				 
					try {

						EMMbrTriggerVO trig = null;
						EEMOevDao oevDao = new EEMOevDao();
						trig=oevDao.checkMbrTrigger(conn, oldDemoVO.getCustomerId(), 
								oldDemoVO.getMemberId(),EEMConstants.TRIGGER_TYPE_FOLLOWUP_MEMB, "OEV1");
						
						if(trig!=null){
						
							
							form.setOevTimerCheck("true");
													} else {
								trig =oevDao.checkMbrTrigger(conn, oldDemoVO.getCustomerId(), 
										oldDemoVO.getMemberId(),EEMConstants.TRIGGER_TYPE_FOLLOWUP_MEMB, "OEV2");
							

								if(trig!=null){
									
									form.setOevTimerCheck("true");
									
									
							}

								else
									form.setOevTimerCheck("false");
							} 
					
					} catch (Exception e) {
						logger.error(LoggerConstants.exceptionMessage(e.toString()));
						logger.debug("Exception : " + e.getMessage());
						throw new ApplicationException(e);
					}
					
				    form.setOevCallAttempts(oevSetvice.getMbrOevInfo(conn, oldDemoVO.getCustomerId(), oldDemoVO.getMemberId(),0,"O", enrollVO));
			        form.setReturnCalls(oevSetvice.getMbrOevInfo(conn, oldDemoVO.getCustomerId(), oldDemoVO.getMemberId(), 0,"R",enrollVO)); 
			     
			     
			        if(form.getOevCallAttempts()!=null && form.getOevCallAttempts().size() >0 ){
			        EmMbrOevInfoVO latestCall =(EmMbrOevInfoVO)form.getOevCallAttempts().get(form.getOevCallAttempts().size()-1);
			    	
			        if(latestCall.getCallComplete().equals("S")){

	                    form.setOevButton("S");
			        }
					if(latestCall.getStatus().equals("C")&&latestCall.getCallComplete().equals("F"))
						form.setOev2TimerCheck(true);
				
					
			        }
			        if(form.getReturnCalls() !=null &&  form.getReturnCalls().size() >0){
			        	
			        	EmMbrOevInfoVO latestRetCall =(EmMbrOevInfoVO)form.getReturnCalls().get(form.getReturnCalls().size()-1);
			        
			        	if(latestRetCall.getCallComplete().equals("S")){

		                    form.setOevButton("S");
			        	}
			        		
					if(latestRetCall.getStatus().equals("C")&&latestRetCall.getCallComplete().equals("F"))
							form.setOev2TimerCheck(true);
				
				      
			        }
			       
			        form.setDisplaySavedOev(enrollVO.getOevCallStatusSaved());
					form.setDisplaySavedRetOev(enrollVO.getOevRetStatusSaved());
					form.setOevCallStatusSaved(enrollVO.getOevCallStatusSaved());
					form.setOevCallStatus(enrollVO.getOevCallStatus());
					form.setOevRetStatusSaved(enrollVO.getOevRetStatusSaved());
					form.setOevRetStatus(enrollVO.getOevRetStatus());
					
					List comments = enrlDao.getMbrComments(conn, oldDemoVO.getCustomerId(), oldDemoVO.getMemberId());
					enrollVO.setComments(comments);
					if(enrollVO.getComments()!=null && enrollVO.getComments().size()>0){
					form.setDisplayComment((EmMbrCommentVO)enrollVO.getComments().get(0));
					
					form.setSelectedCommentRow(0);
					form.setCommentChanged(false);
					form.setCommentDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);	
					

					form.setTopDisplayCommentRow(0);
					Pagination pagination = context.getEnrollCommentPagination();
					pagination.setListPaginationResults("first",enrollVO.getComments());
					}
					List enrollments = enrlDao.getMbrEnrollments(conn, oldDemoVO.getCustomerId(), oldDemoVO.getMemberId(), "N");        
					enrollVO.setEnrollments(enrollments);
					form.setListEnrollmentsWithDisplay(enrollVO.getEnrollments());
					//System.out.println(" in the end");

					
					
		  }
							
			/**
			* UseCaseName 020_Highmark_SUC_OEV � End
			*/			
			
			/**
			 * 033_Highmark_OAASCCprocess - Start
			 */
			else if (EEMConstants.EEM_MBR_TAB_OOA.equals(selectedTab)) {
			
				if (form.isOoaChanged()) {
					
					EmMbrOoaInfoVO newVO = form.getDisplayOoaInfo();
					newVO.setCustomerId(oldDemoVO.getCustomerId());
					newVO.setMemberId(oldDemoVO.getMemberId());
					// IFOX-00404742 - Start
				//	newVO.setLeaveDate(newVO.getReceiveDate());
					// IFOX-00404742 - End
					EmMbrOoaInfoVO wrkVO = (EmMbrOoaInfoVO) newVO.clone();
					wrkVO.setOverrideInd("N");
					
				rslt = ooaService.mbrOoaInfoUpdate(conn, enrollVO, wrkVO,
						userId);
				
					if (rslt) {
						form.setOoaInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
						int seqNbr = service.findDatedSeqNbr(
								enrollVO.getOoaInfos(), wrkVO);
						if (seqNbr == -1)
							seqNbr = 0;
						if(enrollVO.getOoaInfos() != null && enrollVO.getOoaInfos().size() > 0){
							form.setDisplayOoaInfo((EmMbrOoaInfoVO) enrollVO
									.getOoaInfos().get(seqNbr));
	
							form.setSelectedOoaInfoRow(seqNbr);
							form.setOoaChanged(false);
							form.setOoaInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
	
							Pagination pagination = context
									.getEnrollOoaPagination();
							pagination.setPageToDisplayRow(seqNbr,
									enrollVO.getOoaInfos());
							Integer topRow = (Integer) pagination.getFirstDetail();
							form.setTopDisplayOoaInfoRow(topRow.intValue());
							List enrollments = enrlDao.getMbrEnrollments(conn, oldDemoVO.getCustomerId(), oldDemoVO.getMemberId(), "N");        
							enrollVO.setEnrollments(enrollments);
							form.setListEnrollmentsWithDisplay(enrollVO.getEnrollments());
						}
					} else {
						form.setMessage("OOA Update Failed");
					}
				} else {

					form.setMessage("Data Not Changes");
				}
			}

			/**
			 * 033_Highmark_OAASCCprocess - End
			 */
			

			/**
			 * cambia pos start
			 */
			else
				if (EEMConstants.EEM_MBR_TAB_POS.equals(selectedTab)) {
					
					if (form.isPoseditChanged()) {

						EmMbrPosEditVO newVO = form.getDisplayPosEdit();
						newVO.setPosEditOrDeleteOrModifyStatus(form.getPosEditOrDeleteOrModifyStatus());
						newVO.setCustomerId(oldDemoVO.getCustomerId());
						newVO.setMemberId(oldDemoVO.getMemberId());
	                    String message ="POS can be edited for CMSREADY status only";
						EmMbrPosEditVO wrkVO = (EmMbrPosEditVO) newVO.clone();
						rslt = true;
						if(wrkVO.getTxnStatus().equalsIgnoreCase("CMSREADY")){
							rslt =true;
						}else{
							rslt =false;			
						}
						if(rslt){
						wrkVO.setOverrideInd("N");
						rslt = service.checkPosEdit(conn, wrkVO);
						if (rslt) {
							
							if(form.getPosEditOrDeleteOrModifyStatus() != null && form.getPosEditOrDeleteOrModifyStatus().equalsIgnoreCase("ADD")){
							rslt = service.checkPosAddStatus(conn, wrkVO);
							}else{
								rslt =true;
							}
							if(rslt){
							rslt = service.mbrPosUpdate(conn, enrollVO, wrkVO,userId);
							if (rslt) {
								form.setPoseditChanged(false);
								form.setPosEditDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);

								Pagination pagination = context.getEnrollPosInfoPagination();
								//						pagination.setPageToDisplayRow(seqNbr,enrollVO.getListBilling());
								Integer topRow = (Integer) pagination.getFirstDetail();
								form.setTopDisplayPosEditRow(topRow.intValue());

							} else {
								form.setMessage("Pos Update Failed");
							}
							  } else{
							  	form.setMessage("Pos can not be added in CMSFAIL/MCAREERR/CMSAPRV  STATUS ");
							  }
						} else {
							form.setMessage(" Member is not in EAPRV Status for given Notification Date.  ");
						}
						
					}else{
						form.setMessage(" POS CAN BE EDITTED ONLY FOR CMSREADY STATUS.  ");
					}
					} else {
						form.setMessage("No Data changed in the form");
					}
			}
			/**
			 * cambia pos end
			 */
			/** Triple S BasePlus Migration START **/
			//ASES CR For TripleS -Start
				else
					if (EEMConstants.EEM_MBR_TAB_ASES.equals(selectedTab)) {
						if (form.isAsesChanged()) {

							EmMbrAsesVO newVO = form.getDisplayAses();
							newVO.setCustomerId(oldDemoVO.getCustomerId());
							newVO.setMemberId(oldDemoVO.getMemberId());
							
							
							EmMbrAsesVO wrkVO = (EmMbrAsesVO)newVO.clone();
							wrkVO.setOverrideInd("N");
							
							rslt = service.mbrAsesUpdate(conn,enrollVO,wrkVO,userId);
							if (rslt) {
								int seqNbr = service.findDatedSeqNbr(enrollVO.getListAses(),wrkVO);
								if (seqNbr == -1)
									seqNbr = 0;
								form.setDisplayAses((EmMbrAsesVO)enrollVO.getListAses().get(seqNbr));
								form.setSelectedLisInfoRow(seqNbr);
								form.setAsesChanged(false);
								form.setAsesDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);

								Pagination pagination = context.getEnrollAsesPagination();
								pagination.setPageToDisplayRow(seqNbr,enrollVO.getListAses());
								Integer topRow = (Integer)pagination.getFirstDetail();						
								form.setTopDisplayAsesRow(topRow.intValue());
							} else {
								form.setMessage("ASES Update Failed");
							}
						} else {
							form.setMessage("Data Not Changes");
						}
					}
				//ASES CR For TripleS -End
			/** Triple S BasePlus Migration START **/

			if (rslt) {
				conn.commit();
				inTrans = false;			
			}
			if(rslt){
				
				enrollVO.setErrors(enrlDao.getMbrErrors(conn, oldDemoVO.getCustomerId(), oldDemoVO.getMemberId()));
				setFieldNames(enrollVO.getErrors());
				
			}
		} catch (SQLException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception : " + e.getMessage());
			throw new DaoException(Constants.EXCEPTION_MSG, e);
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception : " + e.getMessage());
			throw new ApplicationException(e);
		}finally {
			if (inTrans) {
				try {
					conn.rollback();
				} catch(Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
				}
			}
			try {
				conn.setAutoCommit(lastAutoCommit);
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
			}
		}
		
		if (!rslt) {
			if (enrollVO.getDsInfosUpdated()) {
				enrollVO.setDsInfos(oldDsInfos);
			}
		}
		
		if (EEMConstants.EEM_MBR_SCREEN_EDIT.equals(form.getEnrollmentDisplayState())) {
			EEMCodeCache cc = EEMCodeCache.getInstance();
			form.setValidEnrollReasons(cc.getEnrollReasonFor(form.getDisplayEnrollment().getEnrollStatus()));			
		}

		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void memberLetterSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form)throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		
		String userId = sessionHelper.getUserId();
		String mfId = sessionHelper.getMfId();

		String selectedTab = form.getSelectedMemberTab();

		EEMEnrollVO enrollVO = context.getEnrollVO();
		String showAll = enrollVO.getSearchShowAll();

		EEMEnrollService service = new EEMEnrollService();
		
		try {
			
			EmMbrDemographicVO oldDemoVO = (EmMbrDemographicVO) enrollVO.getDemographics().get(0);
			List lst = enrollVO.getLetters();
			int selectedRow = form.getSelectedLetterRow();
			EmCorrMbrVO letterVO = (EmCorrMbrVO)lst.get(selectedRow);
			letterVO.setCustomerId(oldDemoVO.getCustomerId());
			letterVO.setPrimaryId(oldDemoVO.getMemberId());

			List lstData = service.getLetterVarData(conn,letterVO);
			enrollVO.setLetterData(lstData);
			
		}catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception : " + e.getMessage());
			throw new ApplicationException(e);
		}
		
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void memberGrpPrdSearch(Connection conn, SessionHelper sessionHelper, EEMEnrollGPSearchForm form) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMEnrollService service = new EEMEnrollService();

		String mcCustNbr = sessionHelper.getCustomerNumber();
		String customerId = sessionHelper.getMfId();
		form.setCustomerId(customerId);
		if (form.getOutOfArea() == null)
			form.setOutOfArea("N");
		
		EMGroupProductSearchVO gpSearch = new EMGroupProductSearchVO();
		EEMEnrollHelper.copyGPSearchFormToVO(form,gpSearch);
		gpSearch.setMcCustNbr(mcCustNbr);
		
		String zipCd5 = StringUtil.nonNullTrim(gpSearch.getZipCd5());
		if (zipCd5.equals("")) {
			service.getMbrPrimaryZipOn(conn,gpSearch);
			form.setZipCd5(gpSearch.getZipCd5());
			form.setZipCd4(gpSearch.getZipCd4());
		}
		if ("lookup".equals(form.getOutOfArea())) {
			service.getMbrOutOfAreaOn(conn,gpSearch);
			form.setOutOfArea(gpSearch.getOutOfArea());
		}
		
		List lstGrpPrdResults = service.getGrpPrdList(conn,gpSearch);
		form.setSearchResults(lstGrpPrdResults);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public void memberPcpSearch(Connection conn, SessionHelper sessionHelper, EEMEnrollPcpSearchForm form, String memberId) throws ApplicationException{ //Updated memberid param IFOX-414925 Network ID CR Changes
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMEnrollService service = new EEMEnrollService();

		String mcCustNbr = sessionHelper.getCustomerNumber();
		String customerId = sessionHelper.getMfId();
		form.setCustomerId(customerId);
		//IFOX-414925 Network ID CR Changes - Start
		EmMbrEnrollmentVO enrollVo = new EmMbrEnrollmentVO(); 
		EEMApplDao applDao = new EEMApplDao();
		//IFOX-414925 Network ID CR Changes - End
		EMPcpSearchVO pcpSearch = new EMPcpSearchVO();
		pcpSearch.setCustomerId(StringUtil.nonNullTrim(form.getCustomerId()));
		pcpSearch.setEffDate(DateFormatter.reFormat(form.getEffDate(),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD));
		pcpSearch.setPcpNbr(StringUtil.nonNullTrim(form.getPcpNbr()));
		/*Access health PCP CR- Start*/
		pcpSearch.setPcpNpi(StringUtil.nonNullTrim(form.getPcpNpi()));
		/*Access health PCP CR- End*/
		pcpSearch.setLocationId(StringUtil.nonNullTrim(form.getLocationId()));
		pcpSearch.setDoctorName(StringUtil.nonNullTrim(form.getDoctorName()));
		pcpSearch.setAcceptNewPatient(StringUtil.nonNullTrim(form.getAcceptNewPatientInd()));
		pcpSearch.setAddress(StringUtil.nonNullTrim(form.getDoctorAddress()));
		pcpSearch.setCity(StringUtil.nonNullTrim(form.getDoctorCity()));
		pcpSearch.setState(StringUtil.nonNullTrim(form.getDoctorState()));
		pcpSearch.setZip(StringUtil.nonNullTrim(form.getDoctorZip()));
		//IFOX-414925 Network ID CR Changes - Start
		pcpSearch.setMemberId(StringUtil.nonNullTrim(memberId)); //IFOX-414925 Network ID CR Changes
		String lobValidation	=	sessionHelper.getAttribute(EEMProfileSettings.LOB_VALD).toString();
		List lstPcpResults = null;
		String lob = null; //IFOX-414925 Network ID CR Changes
		if("Y".equalsIgnoreCase(lobValidation)){
			
			//IFOX-414925 Network ID CR Changes - Start
			//lstPcpResults = service.getPcpList(conn,pcpSearch,form.getLineOfBusiness()); //updated for  IFOX-00389053
			enrollVo = service.getMbrEnrl(conn,pcpSearch);
			String grpId = StringUtil.nonNullTrim(enrollVo.getGrpId());
			String prdId = StringUtil.nonNullTrim(enrollVo.getProductId());
			String planId = StringUtil.nonNullTrim( enrollVo.getPlanId());
			String pbpId = StringUtil.nonNullTrim(enrollVo.getPbpId());
			String segId = StringUtil.nonNullTrim(enrollVo.getPbpSegmentId());
			lob = applDao.getLineOfBusniess(conn, pcpSearch.getCustomerId(), grpId, pcpSearch.getEffDate(), prdId, planId, pbpId, segId);
			lstPcpResults = service.getPcpList(conn,pcpSearch,lob);
			//IFOX-414925 Network ID CR Changes - End
		}else{
			lstPcpResults = service.getPcpList(conn,pcpSearch,""); 
		}
		//IFOX-414925 Network ID CR Changes - End
		
		form.setSearchResults(lstPcpResults);
		logger.info(LoggerConstants.methodEndLevel());
	}
	//IFOX-00399921 LTC Tab. START
	public void memberLtcSearch(Connection conn, SessionHelper sessionHelper, EEMEnrollLtcSearchForm form)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());

		EEMEnrollService service = new EEMEnrollService();

		String mcCustNbr = sessionHelper.getCustomerNumber();
		String customerId = sessionHelper.getMfId();
		form.setCustomerId(customerId);

		EMLtcSearchVO ltcSearch = new EMLtcSearchVO();
		ltcSearch.setCustomerId(StringUtil.nonNullTrim(form.getCustomerId()));
		ltcSearch.setEffDate(
				DateFormatter.reFormat(form.getEffDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
		ltcSearch.setLtcFacId(StringUtil.nonNullTrim(form.getLtcFacId()));
		ltcSearch.setFacilityName(StringUtil.nonNullTrim(form.getFacilityName()));
		ltcSearch.setFacilityAddress(StringUtil.nonNullTrim(form.getFacilityAddress()));
		ltcSearch.setFacilityCity(StringUtil.nonNullTrim(form.getFacilityCity()));
		ltcSearch.setFacilityState(StringUtil.nonNullTrim(form.getFacilityState()));
		ltcSearch.setFacilityZipCode(StringUtil.nonNullTrim(form.getFacilityZipCode()));

		List lstPcpResults = service.getLtcList(conn, ltcSearch); 
		form.setSearchResults(lstPcpResults);
		logger.info(LoggerConstants.methodEndLevel());
	}
	//IFOX-00399921 LTC Tab. END
	public void memberTrrTabPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form, String move)throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());

		EEMEnrollVO enrollVO = context.getEnrollVO();
		List lstTrrLogs = enrollVO.getTrrLogs();
		Pagination pagination = context.getEnrollTrrLogPagination();

		pagination.setFirstDetail(new Integer(form.getTopDisplayTrrLogRow()));
		pagination.setSelectedLine(form.getSelectedTrrLogRow());
		
		pagination.setListPaginationResults(move,lstTrrLogs);
		
		Integer newTop = (Integer)pagination.getFirstDetail();
		form.setTopDisplayTrrLogRow(newTop.intValue());
		form.setSelectedTrrLogRow(pagination.getSelectedLine());
		
		/*IFOX-00427238 June 2020 CMS changes - Start*/
		try {
			EmMbrDemographicVO oldDemoVO = (EmMbrDemographicVO) enrollVO.getDemographics().get(0);
			List lst = enrollVO.getTrrLogs();
			int selectedRow = form.getSelectedLetterRow();
			EmMbrTrrLogVO trrLogVO = (EmMbrTrrLogVO)lst.get(selectedRow);
			trrLogVO.setCustomerId(oldDemoVO.getCustomerId());
			trrLogVO.setMemberId(oldDemoVO.getMemberId());
			
			form.setTrrVarDataPresent(new EEMDao().getTrrDataFlag1(conn, trrLogVO.getCustomerId(), trrLogVO.getMemberId(),trrLogVO.getTransReplyCd()));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		/*IFOX-00427238 June 2020 CMS changes - end*/
		
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void memberCommentTabPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form, String move) {
		logger.info(LoggerConstants.methodStartLevel());

		EEMEnrollVO enrollVO = context.getEnrollVO();
		List lstComments = enrollVO.getComments();
		Pagination pagination = context.getEnrollCommentPagination();

		pagination.setFirstDetail(new Integer(form.getTopDisplayCommentRow()));
		pagination.setSelectedLine(form.getSelectedCommentRow());
		
		pagination.setListPaginationResults(move,lstComments);
		
		Integer newTop = (Integer)pagination.getFirstDetail();
		form.setTopDisplayCommentRow(newTop.intValue());
		form.setSelectedCommentRow(pagination.getSelectedLine());
		
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void memberLetterTabPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form, String move) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());

		EEMEnrollVO enrollVO = context.getEnrollVO();
		List lstLetters = enrollVO.getLetters();
		Pagination pagination = context.getEnrollLetterPagination();

		pagination.setFirstDetail(new Integer(form.getTopDisplayLetterRow()));
		pagination.setSelectedLine(form.getSelectedLetterRow());
		
		pagination.setListPaginationResults(move,lstLetters);
		
		Integer newTop = (Integer)pagination.getFirstDetail();
		form.setTopDisplayLetterRow(newTop.intValue());
		form.setSelectedLetterRow(pagination.getSelectedLine());

		try {
			EmMbrDemographicVO oldDemoVO = (EmMbrDemographicVO) enrollVO.getDemographics().get(0);
			List lst = enrollVO.getLetters();
			int selectedRow = form.getSelectedLetterRow();
			EmCorrMbrVO letterVO = (EmCorrMbrVO)lst.get(selectedRow);
			letterVO.setCustomerId(oldDemoVO.getCustomerId());
			letterVO.setPrimaryId(oldDemoVO.getMemberId());
	
			EEMEnrollService service = new EEMEnrollService();
			List lstData = service.getLetterVarData(conn,letterVO);
			enrollVO.setLetterData(lstData);
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception : " + e.getMessage());
			throw new ApplicationException(e);
		}
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void memberPcpTabPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form, String move) {
		logger.info(LoggerConstants.methodStartLevel());

		EEMEnrollVO enrollVO = context.getEnrollVO();
		List lstPcpInfos = enrollVO.getPcpInfos();
		Pagination pagination = context.getEnrollPcpInfoPagination();

		pagination.setFirstDetail(new Integer(form.getTopDisplayPcpInfoRow()));
		pagination.setSelectedLine(form.getSelectedPcpInfoRow());
		
		pagination.setListPaginationResults(move,lstPcpInfos);
		
		Integer newTop = (Integer)pagination.getFirstDetail();
		form.setTopDisplayPcpInfoRow(newTop.intValue());
		form.setSelectedPcpInfoRow(pagination.getSelectedLine());
		
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void memberAddressTabPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form, String move) {
		logger.info(LoggerConstants.methodStartLevel());

		EEMEnrollVO enrollVO = context.getEnrollVO();
		List lstAddress = enrollVO.getAddresses();
		Pagination pagination = context.getEnrollAddressPagination();

		pagination.setFirstDetail(new Integer(form.getTopDisplayAddressRow()));
		pagination.setSelectedLine(form.getSelectedAddressRow());
		
		pagination.setListPaginationResults(move,lstAddress);
		
		Integer newTop = (Integer)pagination.getFirstDetail();
		form.setTopDisplayAddressRow(newTop.intValue());
		form.setSelectedAddressRow(pagination.getSelectedLine());
		
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public void memberLepInfoTabPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form, String move) {
		logger.info(LoggerConstants.methodStartLevel());

		EEMEnrollVO enrollVO = context.getEnrollVO();
		List lepInfos = enrollVO.getLepInfos();
		Pagination pagination = context.getEnrollLepInfoPagination();

		pagination.setFirstDetail(new Integer(form.getTopDisplayLepInfoRow()));
		pagination.setSelectedLine(form.getSelectedLepInfoRow());
		
		pagination.setListPaginationResults(move,lepInfos);
		
		Integer newTop = (Integer)pagination.getFirstDetail();
		form.setTopDisplayLepInfoRow(newTop.intValue());
		form.setSelectedLepInfoRow(pagination.getSelectedLine());
		
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	//New LEP changes - Start
		public void memberLepPotentialTabPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form, String move) {
			logger.info(LoggerConstants.methodStartLevel());
			List lst;
			int totalPlepMonths= 0;
			EEMEnrollVO enrollVO = context.getEnrollVO();
			List lepPotential = enrollVO.getLepPotential();
			
			Pagination pagination = context.getEnrollLepPotentialPagination();

			pagination.setFirstDetail(new Integer(form.getTopDisplayLepPotentialRow()));
			pagination.setSelectedLine(form.getSelectedLepPotentialRow());
			
			pagination.setListPaginationResults(move,lepPotential);
			
			Integer newTop = (Integer)pagination.getFirstDetail();
			form.setTopDisplayLepPotentialRow(newTop.intValue());
			form.setSelectedLepPotentialRow(pagination.getSelectedLine());
			
			EEMEnrollHelper.copyVOToForm(enrollVO,form);
			EEMEnrollHelper.setDisplayItems(enrollVO,form);
			logger.info(LoggerConstants.methodEndLevel());
		}
		public void memberLepCcfTabPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form, String move) {
			logger.info(LoggerConstants.methodStartLevel());
			List lst;
			EEMEnrollVO enrollVO = context.getEnrollVO();
			List lepAttestationCcf = enrollVO.getLepAttestationCcf();
			Pagination pagination = context.getEnrollLepCcfPagination();

			pagination.setFirstDetail(new Integer(form.getTopDisplayCcfRow()));
			pagination.setSelectedLine(form.getSelectedLepCcfRow());
			
			pagination.setListPaginationResults(move,lepAttestationCcf);
			
			Integer newTop = (Integer)pagination.getFirstDetail();
			form.setTopDisplayCcfRow(newTop.intValue());
			form.setSelectedLepCcfRow(pagination.getSelectedLine());
			
			EEMEnrollHelper.copyVOToForm(enrollVO,form);
			EEMEnrollHelper.setDisplayItems(enrollVO,form);
			logger.info(LoggerConstants.methodEndLevel());
		}
		//New LEP changes - End
	
	public void memberLisInfoTabPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form, String move) {
		logger.info(LoggerConstants.methodStartLevel());

		EEMEnrollVO enrollVO = context.getEnrollVO();
		List lisInfos = enrollVO.getLisInfos();
		Pagination pagination = context.getEnrollLisInfoPagination();

		pagination.setFirstDetail(new Integer(form.getTopDisplayLisInfoRow()));
		pagination.setSelectedLine(form.getSelectedLisInfoRow());
		
		pagination.setListPaginationResults(move,lisInfos);
		
		Integer newTop = (Integer)pagination.getFirstDetail();
		form.setTopDisplayLisInfoRow(newTop.intValue());
		form.setSelectedLisInfoRow(pagination.getSelectedLine());
		
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void memberAgentsTabPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form, String move) {
		logger.info(LoggerConstants.methodStartLevel());

		EEMEnrollVO enrollVO = context.getEnrollVO();
		List listAgents = enrollVO.getListAgents();
		Pagination pagination = context.getEnrollAgentsPagination();

		pagination.setFirstDetail(new Integer(form.getTopDisplayAgentRow()));
		pagination.setSelectedLine(form.getSelectedAgentRow());
		
		pagination.setListPaginationResults(move,listAgents);
		
		Integer newTop = (Integer)pagination.getFirstDetail();
		form.setTopDisplayAgentRow(newTop.intValue());
		form.setSelectedAgentRow(pagination.getSelectedLine());
		
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void memberCobTabPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form, String move) {
		logger.info(LoggerConstants.methodStartLevel());

		EEMEnrollVO enrollVO = context.getEnrollVO();
		List listCobs = enrollVO.getListCobs();
		Pagination pagination = context.getEnrollCobsPagination();

		pagination.setFirstDetail(new Integer(form.getTopDisplayCobRow()));
		pagination.setSelectedLine(form.getSelectedCobRow());
		
		pagination.setListPaginationResults(move,listCobs);
		
		Integer newTop = (Integer)pagination.getFirstDetail();
		form.setTopDisplayCobRow(newTop.intValue());
		form.setSelectedCobRow(pagination.getSelectedLine());
		
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public void memberBillingTabPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form, String move) {
		logger.info(LoggerConstants.methodStartLevel());

		EEMEnrollVO enrollVO = context.getEnrollVO();
		List listBilling = enrollVO.getListBilling();
		Pagination pagination = context.getEnrollBillingPagination();

		pagination.setFirstDetail(new Integer(form.getTopDisplayBillingRow()));
		pagination.setSelectedLine(form.getSelectedBillingRow());
		
		pagination.setListPaginationResults(move,listBilling);
		
		Integer newTop = (Integer)pagination.getFirstDetail();
		form.setTopDisplayBillingRow(newTop.intValue());
		form.setSelectedBillingRow(pagination.getSelectedLine());
		
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static void setAgentsLookUp(Connection conn, SessionHelper sessionHelper, EEMEnrollForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		if (form.getDisplayAgent() == null) {
			logger.info(LoggerConstants.methodEndLevel());
			return;
		}
		
		try {
			EmMbrAgentVO agentVO = form.getDisplayAgent();
			EEMCodeCache cache = EEMCodeCache.getInstance();
			form.setLstAgencyTypes(cache.getLstAgencyTypes());
			form.setLstAgentTypes(cache.getLstAgentTypes());
			
			String effDate = StringUtil.nonNullTrim(agentVO.getFrmtEffStartDate()); 
			if (!effDate.equals("")) {
				EEMApplDao eemDao = new EEMApplDao();
				form.setLstAgencies(eemDao.getLstAgencies(conn, sessionHelper.getMfId(), effDate, form.getLineOfBusiness()));//AAH BasePlus Migration IFOX-00426351 Changes 
				
				if (!StringUtil.nonNullTrim(agentVO.getAgencyId()).equals("") && 
						!StringUtil.nonNullTrim(agentVO.getAgentType()).equals("")) {
					form.setLstAgents(eemDao.getLstBrokAgents(conn, 
							sessionHelper.getMfId(), agentVO.getAgentType(),
							agentVO.getAgencyId(), effDate,form.getLineOfBusiness()));//AAH BasePlus Migration IFOX-00426351 Changes 
				}
			}

			//Set plans list
			form.setLstPlans(getValidPlansList(conn, sessionHelper));
		} catch (SQLException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace();
			logger.debug("Exception : " + e.getMessage());
			throw new DaoException(Constants.EXCEPTION_MSG, e);
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//.e.printStackTrace();
			logger.debug("Exception : " + e.getMessage());
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public static List getValidPlansList(Connection conn, SessionHelper sessionHelper) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		HttpSession session = sessionHelper.getSession();
		String[] arrPlans = (String []) session.getAttribute("Plans");
        if (arrPlans == null)
        {
            SecPlanPersistence spp = new SecPlanPersistence();
            arrPlans = spp.getCustPlans(conn, sessionHelper.getCustomerNumber());
            if (arrPlans != null)
                session.setAttribute("Plans", arrPlans);
        }

        if (arrPlans == null) {
        	logger.info(LoggerConstants.methodEndLevel());
			return null;
        }
        
        List lstPlans = new ArrayList();
        for (int i = 0; i < arrPlans.length; i++) {
        	lstPlans.add(new ListBoxItem(arrPlans[i], arrPlans[i]));
        }
        logger.info(LoggerConstants.methodEndLevel());
		return lstPlans;
	}
	
	public void memberDsInfoTabPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form, String move) {
		logger.info(LoggerConstants.methodStartLevel());

		EEMEnrollVO enrollVO = context.getEnrollVO();
		List dsInfos = enrollVO.getDsInfos();
		Pagination pagination = context.getEnrollDsInfoPagination();

		pagination.setFirstDetail(new Integer(form.getTopDisplayDsInfoRow()));
		pagination.setSelectedLine(form.getSelectedDsInfoRow());
		
		pagination.setListPaginationResults(move,dsInfos);
		
		Integer newTop = (Integer)pagination.getFirstDetail();
		form.setTopDisplayDsInfoRow(newTop.intValue());
		form.setSelectedDsInfoRow(pagination.getSelectedLine());
		
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void memberEnrollmentTabPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form, String move) {
		logger.info(LoggerConstants.methodStartLevel());

		EEMEnrollVO enrollVO = context.getEnrollVO();
		List enrollments = enrollVO.getEnrollments();
		Pagination pagination = context.getEnrollEnrollPagination();

		pagination.setFirstDetail(new Integer(form.getTopDisplayEnrollmentRow()));
		pagination.setSelectedLine(form.getSelectedEnrollmentRow());
		
		pagination.setListPaginationResults(move,enrollments);
		
		Integer newTop = (Integer)pagination.getFirstDetail();
		form.setTopDisplayEnrollmentRow(newTop.intValue());
		form.setSelectedEnrollmentRow(pagination.getSelectedLine());
		
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	/**
	 *Added:  033_Highmark_OOASCCprocess - Start
	 */
	/**
	 * @author Srishti Srivastava
	 * @param conn contains Connection
	 * @param sessionHelper contains Sessiojn
	 * @param context contains EEMContext
	 * @param form contains EEMEnrollForm
	 * @param move
	 */
	public void memberOoaTabPage(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			EEMEnrollForm form, String move) {
		logger.info(LoggerConstants.methodStartLevel());

		EEMEnrollVO enrollVO = context.getEnrollVO();
		List ooaInfos = enrollVO.getOoaInfos();
		Pagination pagination = context.getEnrollOoaPagination();

		pagination.setFirstDetail(new Integer(form.getTopDisplayOoaInfoRow()));
		pagination.setSelectedLine(form.getSelectedOoaInfoRow());

		pagination.setListPaginationResults(move, ooaInfos);

		Integer newTop = (Integer) pagination.getFirstDetail();
		form.setTopDisplayOoaInfoRow(newTop.intValue());

		form.setSelectedOoaInfoRow(pagination.getSelectedLine());

		EEMEnrollHelper.copyVOToForm(enrollVO, form);
		EEMEnrollHelper.setDisplayItems(enrollVO, form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	/**
	 * 020_Highmark_SUC_UI_v1.03 (Accretion) - Start
	 */
	/**
	 * @author Srishti Srivastava
	 * @param conn contains Connection
	 * @param sessionHelper contains Session
	 * @param context contains EEMContext
	 * @param form contains EEMEnroll
	 * @param move contains String
	 */
	public void memberAccretionTabPage(Connection conn,
			SessionHelper sessionHelper, EEMContext context,
			EEMEnrollForm form, String move) {
		logger.info(LoggerConstants.methodStartLevel());

		EEMEnrollVO enrollVO = context.getEnrollVO();
		List accretion = enrollVO.getListAccretion();
		Pagination pagination = context.getEnrollAccretPagination();

		pagination.setFirstDetail(new Integer(form
				.getTopDisplayAccretionRow()));
		pagination.setSelectedLine(form.getSelectedAccretionRow());

		pagination.setListPaginationResults(move, accretion);

		Integer newTop = (Integer) pagination.getFirstDetail();
		form.setTopDisplayAccretionRow(newTop.intValue());
		form.setSelectedAccretionRow(pagination.getSelectedLine());

		EEMEnrollHelper.copyVOToForm(enrollVO, form);
		EEMEnrollHelper.setDisplayItems(enrollVO, form);
		logger.info(LoggerConstants.methodEndLevel());
	}

	/**
	 * 020_Highmark_SUC_UI_v1.03 (Accretion) - End
	 */

	/**
	 * Cambia_OEVProcess-Start
	 */
	/**
	 * 
	 * @param conn contains Connection
	 * @param sessionHelper contains Session
	 * @param plan contains Plan
	 * @param planDes contains plan designation
	 * @param context contains EEMContext
	 * @param form contains form
	 * @return integer
	 * @throws ApplicationException
	 */
	
	public int memberOevScript(Connection conn, SessionHelper sessionHelper, String plan, String planDes, EEMContext context, EEMEnrollForm form) throws ApplicationException  {
		logger.info(LoggerConstants.methodStartLevel());
		String userId = sessionHelper.getUserId();	
		EEMEnrollVO enrollVO = context.getEnrollVO();
		EmMbrDemographicVO demoVO = form.getDisplayDemographic();
		EmMbrEnrollmentVO enroVO = form.getDisplayEnrollment();
		EEMOevService service = new EEMOevService();
		EEMOevDao dao = new EEMOevDao();
		int script = 0;
		try{
	
		demoVO.setCustomerId(((EmMbrDemographicVO)enrollVO.getDemographics().get(0)).getCustomerId());
		
		String planName=enroVO.getProductName();
	//	System.out.println("planName"+planName);
		script = service.mbrOevScript(conn, plan, planDes,userId, enrollVO,demoVO,enroVO,planName);
		

		
		//System.out.println("script == "+script);
		form.setPremium(enrollVO.getPremium());
		form.setTier1(enrollVO.getTier1());
		form.setBrandTier(enrollVO.getBrandTier());
		form.setSpclCoPay(enrollVO.getSpclCoPay());
		form.setPrimCoPay(enrollVO.getPrimCoPay());
		form.setFirstName(demoVO.getFirstName());
		form.setLastName(demoVO.getLastName());
		form.setOperId(userId);
		form.setFedralConrtStmt(enrollVO.getFedralConrtStmt());
		form.setOevplanName(enrollVO.getOevplanName());
		form.setApprovalCode(enrollVO.getApprovalCode());
		form.setUserName(StringUtil.nonNullTrim(dao.getUserName(conn, userId)));
		if(demoVO.getGenderCd().equals("M"))
				form.setGenderCd("he");
		if(demoVO.getGenderCd().equals("F"))
			form.setGenderCd("she");	
		
		}
		 catch (Exception e) {
			 logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception : " + e.getMessage());
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return script;
		
		
	}
	/**
	 * Cambia_OEVProcess-End
	 */
	/**
	 * Start -- 014_Highmark_SUC_Letters_v1-- to Reprint Selected Letter 
	 */
	/**
	 * 
	 * @param conn contains Connection
	 * @param sessionHelper contains Session
	 * @param context contains EEMContext
	 * @param form contains EEMEnrollForm
	 * @throws ApplicationException 
	 */
	public void enrollReprintLetter(Connection conn,
			SessionHelper sessionHelper,EEMContext context, EEMEnrollForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
        //int 
		String mfId = sessionHelper.getMfId();
		String userId = sessionHelper.getUserId();
		EEMEnrollVO enrollVO = context.getEnrollVO();		
		EMMbrTriggerVO trig = new EMMbrTriggerVO();
		
		trig.setCustomerId(mfId);
		trig.setMemberId(form.getDisplayDemographic().getMemberId());
		trig.setTriggerType(EEMConstants.TRIGGER_TYPE_MANUAL_LTR);
		trig.setEffectiveDate("");
		trig.setTriggerCode(form.getDisplayLetter().getRePrintType());
		trig.setPlanId(form.getDisplayEnrollment().getPlanId());
		trig.setPbpId(form.getDisplayEnrollment().getPbpId());
		trig.setPlanDesignation(form.getDisplayEnrollment().getPlanDesignation());
		trig.setTriggerStatus(EEMConstants.TRIGGER_STATUS_OPEN);
		trig.setProcessSource(EEMConstants.PROCESS_SOURCE_MBR);
		trig.setOrigTriggerType(" ");
		trig.setOrigTriggerCode(" ");
		trig.setOrigEffectiveDate(" ");
		trig.setOrigTriggerCreateTime("");
		trig.setCreateUserid(userId);
		trig.setCreateTime("");
		trig.setLastUpdtUserid(userId);
		trig.setLastUpdtTime("");
		trig.setFileBatchId(form.getDisplayLetter().getFileBatchId());
		trig.setLetterName(form.getDisplayLetter().getLetterName());
		trig.setRecordType("M");
		EEMEnrollService service = new EEMEnrollService();
		String ltrDesDisp = (String)sessionHelper.getAttribute(EEMProfileSettings.LTR_DES_DISP);
		try {
			service.mbrReprintLetter(conn,enrollVO,trig,ltrDesDisp);
			
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception : " + e.getMessage());
			throw new ApplicationException(e);
		}
		
		EEMEnrollHelper.copyVOToForm(enrollVO, form);
		EEMEnrollHelper.setDisplayItems(enrollVO, form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	/**
	 * End -- 014_Highmark_SUC_Letters_v1-- to Reprint Selected Letter 
	 */
	
	
	public void eemEnrollAgencySearch(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMEnrollVO enrollVO = context.getEnrollVO();
		EEMEnrollService service = new EEMEnrollService();
		enrollVO.setMfId(sessionHelper.getMfId());
		enrollVO.setSearchAgencyId(form.getSearchAgencyId());
		enrollVO.setSearchAgencyName(form.getSearchAgencyName());
		enrollVO.setSearchAgentId(form.getSearchAgentId());
		enrollVO.setSearchAgentName(form.getSearchAgentName());
		enrollVO.setSearchAgencyType(form.getSearchAgencyType());
		enrollVO.setSearchAgentType(form.getSearchAgentType());
		enrollVO.setAgencySrchPageNbr(form.getAgencySrchPageNbr());
		enrollVO.setAgencySrchPageType(form.getAgencySrchPageType());
		enrollVO.setAgencySrchMove(form.getAgencySrchMove());
		
		try {	
			List lstData = service.getAgencySearchData(conn, enrollVO, form.getAgentEffDate(),form.getLineOfBusiness());
			enrollVO.setLstSearchAgencies(lstData);
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace(log);
			logger.debug("Exception : " + e.getMessage());
		}
		form.setLstSearchAgencies(enrollVO.getLstSearchAgencies());
		form.setAgencySrchPageNbr(enrollVO.getAgencySrchPageNbr());
		form.setAgencySrchPageType(enrollVO.getAgencySrchPageType());
		form.setAgencySrchMove(enrollVO.getAgencySrchMove());
		logger.info(LoggerConstants.methodEndLevel());
	}
	//IFOX- 415856 : New Agent Lookup CR -start
	public void eemEnrollAgencySearchNew(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form) {
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMEnrollVO enrollVO = context.getEnrollVO();
		EEMEnrollService service = new EEMEnrollService();
		enrollVO.setMfId(sessionHelper.getMfId());
		enrollVO.setSearchAgencyId(form.getSearchAgencyId());
		enrollVO.setSearchAgencyName(form.getSearchAgencyName());
		enrollVO.setSearchAgentId(form.getSearchAgentId());
		enrollVO.setSearchAgentName(form.getSearchAgentName());
		enrollVO.setSearchAgencyType(form.getSearchAgencyType());
		enrollVO.setSearchAgentType(form.getSearchAgentType());
		enrollVO.setAgencySrchPageNbr(form.getAgencySrchPageNbr());
		enrollVO.setAgencySrchPageType(form.getAgencySrchPageType());
		enrollVO.setAgencySrchMove(form.getAgencySrchMove());
		
		try {
			/**AAH BasePlus Migration IFOX-00426351 Added LOB START*/
			String lob = form.getLineOfBusiness();
			if (StringUtil.isNotNullNotEmptyNotWhiteSpace(lob)) {
				sessionHelper.getSession().setAttribute("lineOfBusiness", lob);
			}else {
				lob = (String) sessionHelper.getSession().getAttribute("lineOfBusiness");
				if (StringUtil.isNotNullNotEmptyNotWhiteSpace(lob)) 
					form.setLineOfBusiness(lob);
			}
			/**AAH BasePlus Migration IFOX-00426351 Added LOB END*/
			List lstData = service.getAgencySearchDataNew(conn, enrollVO, form.getAgentEffDate(),form.getLineOfBusiness());
			enrollVO.setLstSearchAgencies(lstData);
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace(log);
			logger.debug("Exception : " + e.getMessage());
		}
		form.setLstSearchAgencies(enrollVO.getLstSearchAgencies());
		form.setAgencySrchPageNbr(enrollVO.getAgencySrchPageNbr());
		form.setAgencySrchPageType(enrollVO.getAgencySrchPageType());
		form.setAgencySrchMove(enrollVO.getAgencySrchMove());
		logger.info(LoggerConstants.methodEndLevel());
	}
	//IFOX- 415856 : New Agent Lookup CR -end
	/**
	 * cambia pos start
	 */
	
	/**
	 * @author CH270335
	 * @param conn holds Connection object
	 * @param sessionHelper holds POS related objects
	 * @param context holds POS related objects
	 * @param form hold POS related objects
	 * @param string holds the move object
	 */
	public void memberPosInfoTabPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form, String move) {
		logger.info(LoggerConstants.methodStartLevel());

		EEMEnrollVO enrollVO = context.getEnrollVO();
		List listPosEdit = enrollVO.getListPosEdit();
		Pagination pagination = context.getEnrollPosInfoPagination();

		pagination.setFirstDetail(new Integer(form.getTopDisplayPosEditRow()));
		pagination.setSelectedLine(form.getSelectedPosEditRow());
		
		pagination.setListPaginationResults(move,listPosEdit);
		
		Integer newTop = (Integer)pagination.getFirstDetail();
		form.setTopDisplayPosEditRow(newTop.intValue());
		form.setSelectedPosEditRow(pagination.getSelectedLine());
		
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
	}	
	/**
	 * cambia pos end
	 */
	/** @author Surya
	  * UseCaseName 024_Cambia_LEP - Start 4
	  */
	
  /**
	 * 
	 * @param conn contains Connection
	 * @param sessionHelper  contains session
	 * @param context contains EEMContext
	 * @param form contains EEMEnrollForm
	 * @return integer
	 * @throws ApplicationException
	 * @throws SQLException
	 */
	
	public int mbrLEPCredLtrReq(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form) throws ApplicationException, SQLException {
		logger.info(LoggerConstants.methodStartLevel());
		int Count = 0;

		String userId = sessionHelper.getUserId();
		EEMEnrollService service = new EEMEnrollService();
		EEMEnrollVO enrollVO = context.getEnrollVO();
		EmMbrEnrollmentVO enrollmentVO = form.getDisplayEnrollment();
		service.mbrLEPCredLtrReq(conn,enrollmentVO,enrollVO,userId);
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);
		logger.info(LoggerConstants.methodEndLevel());
		return Count;
	}
	/**
	 * @author mchaitan
	 * @param conn contains Connection
	 * @param sessionHelper contains Session
	 * @param context contains EEMContext
	 * @param form contains EEMEnrollForm
	 * @return integer
	 * @throws ApplicationException
	 * @throws SQLException
	 */
	public int mgrLEPAdjLtrReq(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form) throws ApplicationException, SQLException {
		logger.info(LoggerConstants.methodStartLevel());
		int Count = 0;
		String userId = sessionHelper.getUserId();
		EEMEnrollVO enrollVO = context.getEnrollVO();
		EEMEnrollService service = new EEMEnrollService();
		EmMbrEnrollmentVO enrollmentVO = form.getDisplayEnrollment();
		service.mbrLEPAdjLtrReq(conn,enrollmentVO,enrollVO,userId);
		EEMEnrollHelper.copyVOToForm(enrollVO,form);
		EEMEnrollHelper.setDisplayItems(enrollVO,form);	
		logger.info(LoggerConstants.methodEndLevel());
		return Count;
	}
	
	/** @author Surya
	  * UseCaseName 024_Cambia_LEP - End 4
	  */
	
	//Begin: Added for IFOX-00396582
		private void updatePCPDetails(Connection conn, EEMEnrollService service, EEMEnrollVO enrollVO,
				EmMbrDemographicVO demoVO, EmMbrEnrollmentVO newVO, String userId)  throws ApplicationException
		{
			logger.info(LoggerConstants.methodStartLevel());
			EMMbrPCPInfoVO emMbrPCPInfoVO = new EMMbrPCPInfoVO();
			emMbrPCPInfoVO.setLastUpdtUserId(userId);
			service.populateOpenEndedPCPDetails(conn, newVO, emMbrPCPInfoVO);
			service.updatePCPDetails(conn, newVO, emMbrPCPInfoVO);
		}
		
		private boolean isForDisEnrollment(EmMbrEnrollmentVO newVO)
		{
			logger.info(LoggerConstants.methodStartLevel());
			logger.debug(" EEMEnrollManager : isForDisEnrollment : EnrollStatus [" + newVO.getEnrollStatus() + "], EnrollReasonCode [" + newVO.getEnrollReasonCd() + "]" );

			if(StringUtil.nonNullTrim(newVO.getEnrollStatus()).equals("DAPRV") && StringUtil.nonNullTrim(newVO.getEnrollReasonCd()).equals("CMSAPRV")) {
				logger.info(LoggerConstants.methodEndLevel());
				return true;
			}
			else {
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		}
		
		//End: Added for IFOX-00396582

		
		//ASES CR For TripleS -Start
		public void memberAsesTabPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMEnrollForm form, String move) {
			logger.info(LoggerConstants.methodStartLevel());

			EEMEnrollVO enrollVO = context.getEnrollVO();
			List listAses = enrollVO.getListAses();
			Pagination pagination = context.getEnrollAsesPagination();

			pagination.setFirstDetail(new Integer(form.getTopDisplayAsesRow()));
			pagination.setSelectedLine(form.getSelectedAsesRow());
			
			pagination.setListPaginationResults(move,listAses);
			
			Integer newTop = (Integer)pagination.getFirstDetail();
			form.setTopDisplayAsesRow(newTop.intValue());
			form.setSelectedAsesRow(pagination.getSelectedLine());
			
			EEMEnrollHelper.copyVOToForm(enrollVO,form);
			EEMEnrollHelper.setDisplayItems(enrollVO,form);
			logger.info(LoggerConstants.methodEndLevel());
		}
		//ASES CR For TripleS -End
	

		
		//Begin: Added for IFOX-00404244
		private void updateBillingDetails(Connection conn, EEMEnrollService service, EEMEnrollVO enrollVO,
				EmMbrDemographicVO demoVO, EmMbrEnrollmentVO newVO, String userId)  throws ApplicationException
		{
			logger.info(LoggerConstants.methodStartLevel());
			EmMbrBillingVO emMbrBillingVO = new EmMbrBillingVO();
			emMbrBillingVO.setLastUpdtUserId(userId);
			service.populateOpenEndedBillingDetails(conn, newVO, emMbrBillingVO);
			if(emMbrBillingVO.getBillingDataExists().equalsIgnoreCase("yes")){
				service.updateBillingDetails(conn, newVO, emMbrBillingVO);
			}
			logger.info(LoggerConstants.methodEndLevel());
		}
		//End: Added for IFOX-00404244
		
		//Begin: Added for CR-IFOX-00389914
		private void updateAgentDetails(Connection conn, EEMEnrollService service, EEMEnrollVO enrollVO,
				EmMbrDemographicVO demoVO, EmMbrEnrollmentVO newVO, String userId)  throws ApplicationException
		{
			logger.info(LoggerConstants.methodStartLevel());
			EmMbrAgentVO emMbrAgentVO = new EmMbrAgentVO();
			emMbrAgentVO.setLastUpdtUserId(userId);
			service.populateOpenEndedAgentDetails(conn, newVO, emMbrAgentVO);
			service.updateAgentDetails(conn, newVO, emMbrAgentVO);
			logger.info(LoggerConstants.methodEndLevel());
		}
		//End
		
		/*June 2020 CMS changes - start*/
		public void memberTrrDataSearch(Connection conn, SessionHelper sessionHelper, EEMTrrDataForm form)
				throws ApplicationException {
			logger.info(LoggerConstants.methodStartLevel());

			EEMEnrollService service = new EEMEnrollService();

			String mcCustNbr = sessionHelper.getCustomerNumber();
			String customerId = sessionHelper.getMfId();
			form.setCustomerId(customerId);

			EMTrrDataSearchVO trrDataSearch = new EMTrrDataSearchVO();
			trrDataSearch.setCustomerId(StringUtil.nonNullTrim(form.getCustomerId()));
			trrDataSearch.setEffDate(DateFormatter.reFormat(form.getEffDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			trrDataSearch.setMemberId(StringUtil.nonNullTrim(form.getMemberId()));
			trrDataSearch.setTrrReplyCd(StringUtil.nonNullTrim(form.getTrrReplyCd()));

			List lstTrrDataResults = service.getTrrDataList(conn, trrDataSearch); 
			form.setSearchResults(lstTrrDataResults);
			logger.info(LoggerConstants.methodEndLevel());
		}
		/*June 2020 CMS changes - end*/
	
}//class
