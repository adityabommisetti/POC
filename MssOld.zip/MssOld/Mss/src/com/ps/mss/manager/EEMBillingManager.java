/*
 * $Id: EEMBillingManager.java,v 1.6 2015/07/31 16:49:25 jacobr Exp $
 */
package com.ps.mss.manager;

import java.io.PrintStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.text.DateFormatter;
import com.ps.text.NumberFormatter;
import com.ps.util.DateUtil;
import com.ps.util.StringUtil;
import com.ps.db.SQLHelper;
import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.EEMBillDao;
import com.ps.mss.dao.model.EmBBBDraftDetailVO;
import com.ps.mss.dao.model.EmBBBDraftHeaderVO;
import com.ps.mss.dao.model.EmBBBFunctionCodeVO;
import com.ps.mss.dao.model.EmBBBInvoiceDetailVO;
import com.ps.mss.dao.model.EmBBBInvoiceHeaderVO;
import com.ps.mss.dao.model.EmBBBPaymentDtlInvoiceVO;
import com.ps.mss.dao.model.EmBBBPaymentsDetailVO;
import com.ps.mss.dao.model.EmBBBPaymentsHeaderVO;
import com.ps.mss.dao.model.EmMbrCommentVO;
import com.ps.mss.db.EEMCodeCache;
import com.ps.mss.db.EEMProfileSettings;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.model.EEMContext;
import com.ps.mss.model.EMBillDraftVO;
import com.ps.mss.model.EMBillFuncVO;
import com.ps.mss.model.EMBillInvoiceVO;
import com.ps.mss.model.EMBillMembPaymentsVO;
import com.ps.mss.model.EMBillPaymentsVO;
import com.ps.mss.model.EMMbrDraftSummaryVO;
import com.ps.mss.model.EMMbrInvoiceSummaryVO;
import com.ps.mss.model.Pagination;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.forms.EEMBillDraftForm;
import com.ps.mss.web.forms.EEMBillInvoiceForm;
import com.ps.mss.web.forms.EEMBillMembPaymentsForm;
import com.ps.mss.web.forms.EEMBillPaymentsForm;
import com.ps.mss.web.helper.SessionHelper;

public class EEMBillingManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(EEMBillingManager.class);

	PrintStream log;
	String noOfRecordsForTransfer = "0";
	
	public EEMBillingManager() {
		this(System.out);
	}
	public EEMBillingManager(PrintStream log) {
		this.log = log;
	}

	public void billInvoiceSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillInvoiceForm form, String flag) throws SQLException {
		logger.info(LoggerConstants.methodStartLevel());
		
		EMBillInvoiceVO billInvoiceVO = context.getBillInvoiceVO();
		// Copy the search criteria to the VO
		billInvoiceVO.setCustomerId(sessionHelper.getMfId());
		billInvoiceVO.setSearchInvoiceNbr(form.getSearchInvoiceNbr());
		billInvoiceVO.setSearchInvoiceId(form.getSearchInvoiceId());
		billInvoiceVO.setSearchInvoiceStatus(form.getSearchInvoiceStatus());
		billInvoiceVO.setSearchLastName(form.getSearchLastName());
		billInvoiceVO.setSearchHicNbr(form.getSearchHicNbr());
		billInvoiceVO.setSearchInvoiceGroup(form.getSearchInvoiceGroup());
		billInvoiceVO.setSearchInvoiceType(form.getSearchInvoiceType());
		billInvoiceVO.setSearchSupplId(form.getSearchSupplId());//IFOX-00402448
		
		// SSNRI 2017 :Start
		billInvoiceVO.setIsHicOrMbi(flag);
		// SSNRI 2017 : End

		form.setSearchExpanded(true);
		form.setCommentsExpanded(true);
		billInvoiceSearchPage(conn,sessionHelper,context,form,"first", flag);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public void billDraftSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillDraftForm form, String flag) throws SQLException {
		logger.info(LoggerConstants.methodStartLevel());
		
		EMBillDraftVO billDraftVO = context.getBillDraftVO();
		// Copy the search criteria to the VO
		billDraftVO.setCustomerId(sessionHelper.getMfId());
		billDraftVO.setSearchInvoiceNbr(form.getSearchInvoiceNbr());
		billDraftVO.setSearchInvoiceId(form.getSearchInvoiceId());
		billDraftVO.setSearchInvoiceStatus(form.getSearchDraftStatus());
		billDraftVO.setSearchLastName(form.getSearchLastName());
		billDraftVO.setSearchHicNbr(form.getSearchHicNbr());
		billDraftVO.setSearchSupplId(form.getSearchSupplId());
//		billInvoiceVO.setSearchInvoiceGroup(form.getSearchInvoiceGroup());
//		billInvoiceVO.setSearchInvoiceType(form.getSearchInvoiceType());

		// SSNRI 2017 :Start
		billDraftVO.setIsHicOrMbi(flag);
		// SSNRI 2017 : End
		
		form.setSearchExpanded(true);
//		form.setCommentsExpanded(true);
		billDraftSearchPage(conn,sessionHelper,context,form,"first",flag);
		logger.info(LoggerConstants.methodEndLevel());

	}	
	public void billPaymentsSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillPaymentsForm form) throws SQLException {
		logger.info(LoggerConstants.methodStartLevel());
		
		EMBillPaymentsVO billPaymentsVO = context.getBillPaymentsVO();
		// Copy the search criteria to the VO
		billPaymentsVO.setCustomerId(sessionHelper.getMfId());
		billPaymentsVO.setSearchPaySource(form.getSearchPaySource());
		billPaymentsVO.setSearchBatchDate(DateFormatter.reFormat(form.getSearchBatchDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
		billPaymentsVO.setSearchBatchSeqNbr(form.getSearchBatchSeqNbr());
		billPaymentsVO.setSearchBatchBalance(form.getSearchBatchBalance());
		billPaymentsVO.setSearchSupplId(form.getSearchSupplId());

		form.setSearchExpanded(true);
		//form.setCommentsExpanded(true);
		billPaymentsSearchPage(conn,sessionHelper,context,form,"first");
		logger.info(LoggerConstants.methodEndLevel());
	}
	public void billMembPaymentsSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillMembPaymentsForm form, String flag) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		
		EMBillMembPaymentsVO billMembVO = context.getBillMembPaymentsVO();
		// Copy the search criteria to the VO
		billMembVO.setCustomerId(sessionHelper.getMfId());
		billMembVO.setSearchPaySource(form.getSearchPaySource());
		billMembVO.setSearchInvoiceId(form.getSearchInvoiceId());
		billMembVO.setSearchCheckNbr(form.getSearchCheckNbr());
		billMembVO.setSearchLastName(form.getSearchLastName());
		billMembVO.setSearchHicNbr(form.getSearchHicNbr());
		billMembVO.setSearchSupplId(form.getSearchSupplId());//IFOX-00402448
		
		

		// SSNRI 2017 :Start
		billMembVO.setIsHicOrMbi(flag);
		// SSNRI 2017 : End
		
		form.setDetailListExpanded(true);
		billMembPaymentsSelect(conn,sessionHelper,context,form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public void billInvoiceSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillInvoiceForm form, String move, String flag) {
		logger.info(LoggerConstants.methodStartLevel());

		EMBillInvoiceVO billInvoiceVO = context.getBillInvoiceVO(); // use the last search criteriia even if its changed on the form
		Pagination pagination = context.getBillInvoicePagination();
		
		form.setSelectedSearchRow(0);
		form.setListSearchResults(null);
		form.setDisplayInvoiceSummary(new EMMbrInvoiceSummaryVO());
		form.setDisplayInvoiceHeader(new EmBBBInvoiceHeaderVO());
		//IFOX- 421763 Billing User Role : start
		form.setNsfAdjustVal(sessionHelper.getAttribute("BNSF").toString());
		System.out.println("NSF Adjust Value 1"+form.getNsfAdjustVal());
		//IFOX- 421763 Billing User Role : end
		billInvoiceVO.setSearchResults(null);

		form.setSelectedDetailRow(0);
		form.setListDetail(null);
		form.setDisplayInvoiceDetail(new EmBBBInvoiceDetailVO());

		billInvoiceVO.setListDetail(null);

		EEMBillDao billDao = new EEMBillDao();
		try {
			
			//SSNRI 2017 : start
			billInvoiceVO.setIsHicOrMbi(flag);
			//SSNRI 2017 : end
			List searchResults = billDao.getBillInvoiceSearchResults(conn,billInvoiceVO,pagination,move);
			EmBBBInvoiceHeaderVO [] arr = new EmBBBInvoiceHeaderVO[searchResults.size()];
			arr = (EmBBBInvoiceHeaderVO[])searchResults.toArray(arr);		

			pagination.setPaginationResults(move,arr);
			billInvoiceVO.setSearchResults(searchResults);

			if (searchResults != null && searchResults.size() > 0) {
				form.setListSearchResults(searchResults);
				form.setSelectedSearchRow(0);
			}
			form.setSelectedInvoiceGroup(StringUtil.nonNullTrim(billInvoiceVO.getSearchInvoiceGroup()));
			billInvoiceSelect(conn,sessionHelper,context,form);
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log);
		}
		logger.info(LoggerConstants.methodEndLevel());
		
	}
	
	
	public void billDraftSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillDraftForm form, String move, String flag) {
		logger.info(LoggerConstants.methodStartLevel());

		EMBillDraftVO billDraftVO = context.getBillDraftVO(); // use the last search criteriia even if its changed on the form
		Pagination pagination = context.getBillDraftPagination();
		
		form.setSelectedSearchRow(0);
		form.setListSearchResults(null);
		form.setDisplayDraftSummary(new EMMbrDraftSummaryVO());
		form.setDisplayInvoiceHeader(new EmBBBDraftHeaderVO());
		
		billDraftVO.setSearchResults(null);

		form.setSelectedDetailRow(0);
		form.setListDetail(null);
		form.setDisplayDraftDetail(new EmBBBDraftDetailVO());

		billDraftVO.setListDetail(null);

		EEMBillDao billDao = new EEMBillDao();
		try {
			//SSNRI 2017 : start
			billDraftVO.setIsHicOrMbi(flag);
			//SSNRI 2017 : end
			
			List searchResults = billDao.getBillDraftSearchResults(conn,billDraftVO,pagination,move);
			EmBBBDraftHeaderVO [] arr = new EmBBBDraftHeaderVO[searchResults.size()];
			arr = (EmBBBDraftHeaderVO[])searchResults.toArray(arr);		

			pagination.setPaginationResults(move,arr);
			billDraftVO.setSearchResults(searchResults);

			if (searchResults != null && searchResults.size() > 0) {
				form.setListSearchResults(searchResults);
				form.setSelectedSearchRow(0);
			}
			billDraftSelect(conn,sessionHelper,context,form);
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log);
		}
		logger.info(LoggerConstants.methodEndLevel());
		
	}
	
	public void billPaymentsSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillPaymentsForm form, String move) {
		logger.info(LoggerConstants.methodStartLevel());

		EMBillPaymentsVO billPaymentsVO = context.getBillPaymentsVO(); // use the last search criteriia even if its changed on the form
		Pagination pagination = context.getBillPaymentsPagination();
		
		form.setSelectedSearchRow(0);
		form.setListSearchResults(null);
		form.setDisplayPaymentsHeader(new EmBBBPaymentsHeaderVO());
		
		billPaymentsVO.setSearchResults(null);

		form.setSelectedDetailRow(0);
		form.setListDetail(null);
		form.setDisplayPaymentsDetail(new EmBBBPaymentsDetailVO());

		billPaymentsVO.setListDetail(null);

		EEMBillDao billDao = new EEMBillDao();
		try {
			List searchResults = billDao.getBillPaymentsSearchResults(conn,billPaymentsVO,pagination,move);
			EmBBBPaymentsHeaderVO [] arr = new EmBBBPaymentsHeaderVO[searchResults.size()];
			arr = (EmBBBPaymentsHeaderVO[])searchResults.toArray(arr);		

			pagination.setPaginationResults(move,arr);
			billPaymentsVO.setSearchResults(searchResults);

			if (searchResults != null && searchResults.size() > 0) {
				form.setListSearchResults(searchResults);
				form.setSelectedSearchRow(0);
				form.setHeaderDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
			}
			billPaymentsSelect(conn,sessionHelper,context,form);
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log);
		}
		logger.info(LoggerConstants.methodEndLevel());
		
	}
	public void billMembPaymentsSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillMembPaymentsForm form, String move, String flag) {
		logger.info(LoggerConstants.methodStartLevel());

		EMBillMembPaymentsVO membVO = context.getBillMembPaymentsVO(); // use the last search criteriia even if its changed on the form
		Pagination pagination = context.getBillMembPaymentsPagination();
		
		form.setSelectedDetailRow(0);
		form.setListDetail(null);
		form.setDisplayPaymentsDetail(new EmBBBPaymentsDetailVO());
		
		membVO.setListDetail(null);

		EEMBillDao billDao = new EEMBillDao();
		try {
			
			//SSNRI 2017 : start
			membVO.setIsHicOrMbi(flag);
			//SSNRI 2017 : end
			List searchResults = billDao.getBillMembPaymentsSearchDetail(conn,membVO,pagination,move);
			EmBBBPaymentsDetailVO [] arr = new EmBBBPaymentsDetailVO[searchResults.size()];
			arr = (EmBBBPaymentsDetailVO[])searchResults.toArray(arr);		

			pagination.setPaginationResults(move,arr);
			membVO.setListDetail(searchResults);

			if (searchResults != null && searchResults.size() > 0) {
				form.setListDetail(searchResults);
				form.setSelectedDetailRow(0);
				form.setDetailDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
				
				EmBBBPaymentsDetailVO dispDetail = (EmBBBPaymentsDetailVO)searchResults.get(0);
				
				form.setDisplayPaymentsDetail(dispDetail);
				dispDetail.setListPymntDtlInvc(billDao.getBillPaymentsDetailInvoice(conn, dispDetail));
			}
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log);
		}
		logger.info(LoggerConstants.methodEndLevel());
		
	}

	public void billInvoiceSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillInvoiceForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());

		EMBillInvoiceVO billInvoiceVO = context.getBillInvoiceVO();
		
		int selectedRow = form.getSelectedSearchRow();
		List searchResults = billInvoiceVO.getSearchResults();
		form.setListSearchResults(searchResults);
		if (searchResults != null && searchResults.size() > selectedRow) {
			EmBBBInvoiceHeaderVO dispInvHdr = (EmBBBInvoiceHeaderVO)searchResults.get(selectedRow);
			form.setDisplayInvoiceHeader(dispInvHdr);

			EEMBillDao billDao = new EEMBillDao();
			EMMbrInvoiceSummaryVO dispInvSum = billDao.getInvSummary(conn,dispInvHdr.getCustomerId(),dispInvHdr.getInvoiceId());
			dispInvSum.setMemberId(dispInvHdr.getInvoiceId());
			dispInvSum.setHicNbr(dispInvHdr.getHicNbr());
			dispInvSum.setLastName(dispInvHdr.getLastName());
			dispInvSum.setFirstName(dispInvHdr.getFirstName());
			form.setDisplayInvoiceSummary(dispInvSum);
			billInvoiceVO.setInvoiceSummary(dispInvSum);
			form.setSelectedMbrGrpInd(dispInvHdr.getMbrGrpInd());
			
			// Get Details
			Pagination pagination = context.getBillInvoiceDetailPagination();
			List invDetail = billDao.getBillInvoiceDetail(conn,dispInvHdr,pagination,"first");
			if (invDetail != null && invDetail.size() > 0) {
				form.setListDetail(invDetail);
				//form.setSelectedSearchRow(0);

				EmBBBInvoiceDetailVO [] arr = new EmBBBInvoiceDetailVO[invDetail.size()];
				arr = (EmBBBInvoiceDetailVO[])invDetail.toArray(arr);		

				pagination.setPaginationResults("first",arr);
				billInvoiceVO.setListDetail(invDetail);
				
				if (invDetail.size() > 0) {
					EmBBBInvoiceDetailVO dispDetail = (EmBBBInvoiceDetailVO)invDetail.get(0);
					String detBankCd = billDao.getbankAcctCd(conn, dispDetail.getMemberId(), dispDetail.getCustomerId(), dispDetail.getInvoiceNbr()); //415889 Refund Extract
					form.setSelectedDetailRow(0);
					form.setDisplayInvoiceDetail(dispDetail);
					form.setLstFunctionCode(billDao.getBillFuncList(conn, dispInvHdr.getCustomerId(),"U",detBankCd)); //415889 Refund Extract
					form.setLstRefReasonCode(billDao.getBillRefReasonList(conn)); //415889 Refund Extract
					form.setDetailDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
				}
			}
			
			// Get comments
			List lstComments = billDao.getBillInvoiceComments(conn, dispInvHdr.getCustomerId(), dispInvHdr.getInvoiceNbr());
			billInvoiceVO.setListComment(lstComments);
			form.setSelectedCommentRow(0);
			form.setListCommentsWithDisplay(lstComments);		
			form.setCommentChanged(false);
			form.setCommentDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
			form.setTopDisplayCommentRow(0);
			pagination = context.getBillInvoiceCommentPagination();
			pagination.setListPaginationResults("first",lstComments);
		}	
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void billDraftSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillDraftForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());

		EMBillDraftVO billDraftVO = context.getBillDraftVO();
		
		int selectedRow = form.getSelectedSearchRow();
		List searchResults = billDraftVO.getSearchResults();
		form.setListSearchResults(searchResults);
		if (searchResults != null && searchResults.size() > selectedRow) {
			EmBBBDraftHeaderVO dispInvHdr = (EmBBBDraftHeaderVO)searchResults.get(selectedRow);
			form.setDisplayInvoiceHeader(dispInvHdr);

			EEMBillDao billDao = new EEMBillDao();
			EMMbrDraftSummaryVO dispInvSum = billDao.getDraftSummary(conn,dispInvHdr.getCustomerId(),dispInvHdr.getInvoiceId(),dispInvHdr.getInvoiceNbr());
			dispInvSum.setMemberId(dispInvHdr.getInvoiceId());
			dispInvSum.setHicNbr(dispInvHdr.getHicNbr());
			dispInvSum.setLastName(dispInvHdr.getLastName());
			dispInvSum.setFirstName(dispInvHdr.getFirstName());
			
			form.setDisplayDraftSummary(dispInvSum);
			billDraftVO.setInvoiceSummary(dispInvSum);
			
						
			// Get Details
			Pagination pagination = context.getBillDraftDetailPagination();
			
			List invDetail = billDao.getBillDraftDetail(conn,dispInvHdr,pagination,"first");
			if (invDetail != null && invDetail.size() > 0) {
				form.setListDetail(invDetail);
				//form.setSelectedSearchRow(0);

				EmBBBDraftDetailVO [] arr = new EmBBBDraftDetailVO[invDetail.size()];
				arr = (EmBBBDraftDetailVO[])invDetail.toArray(arr);		

				pagination.setPaginationResults("first",arr);
				billDraftVO.setListDetail(invDetail);
				
				if (invDetail.size() > 0) {
					EmBBBDraftDetailVO dispDetail = (EmBBBDraftDetailVO)invDetail.get(0);
					//form.setSelectedDetailRow(0);
					form.setDisplayDraftDetail(dispDetail);
					form.setDetailDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
				}
			}
			
		}	
		logger.info(LoggerConstants.methodEndLevel());
	}


	public void billDraftSelectAfterUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillDraftForm form, EmBBBDraftDetailVO billDraftUpdated) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());

		EMBillDraftVO billDraftVO = context.getBillDraftVO();
		EEMCodeCache codeCache = EEMCodeCache.getInstance();
		
		int selectedRow = form.getSelectedSearchRow();
		List searchResults = billDraftVO.getSearchResults();
		form.setListSearchResults(searchResults);

		if (searchResults != null && searchResults.size() > selectedRow) {
			EmBBBDraftHeaderVO dispInvHdr = (EmBBBDraftHeaderVO)searchResults.get(selectedRow);
			form.setDisplayInvoiceHeader(dispInvHdr);
			
			EEMBillDao billDao = new EEMBillDao();
			EMMbrDraftSummaryVO dispInvSum = billDao.getDraftSummary(conn,billDraftUpdated.getCustomerId(),billDraftUpdated.getMemberId(),billDraftUpdated.getInvoiceNbr());
			dispInvSum.setMemberId(dispInvHdr.getInvoiceId());
			dispInvSum.setHicNbr(dispInvHdr.getHicNbr());
			dispInvSum.setLastName(dispInvHdr.getLastName());
			dispInvSum.setFirstName(dispInvHdr.getFirstName());
			
			form.setDisplayDraftSummary(dispInvSum);
			billDraftVO.setInvoiceSummary(dispInvSum);
			
						
			// Get Details
			Pagination pagination = context.getBillDraftDetailPagination();
			
			ArrayList list = new ArrayList();
			list.add(billDraftUpdated);
			
			List invDetail = list;
			
			if (invDetail != null && invDetail.size() > 0) {
				form.setListDetail(invDetail);
				//form.setSelectedSearchRow(0);

				EmBBBDraftDetailVO [] arr = new EmBBBDraftDetailVO[invDetail.size()];
				arr = (EmBBBDraftDetailVO[])invDetail.toArray(arr);		

				pagination.setPaginationResults("first",arr);
				billDraftVO.setListDetail(invDetail);
				
				if (invDetail.size() > 0) {
					EmBBBDraftDetailVO dispDetail = (EmBBBDraftDetailVO)invDetail.get(0);
					form.setSelectedDetailRow(0);
					dispDetail.setDraftStatus((String)codeCache.getDraftStatuses().get(dispDetail.getDraftStatus()));
					form.setDisplayDraftDetail(dispDetail);
					
					form.setDetailDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
				}
			}
			
		}	
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	
	
	public void billDraftSelectForMember(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillDraftForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());

		EMBillDraftVO billDraftVO = context.getBillDraftVO();
		
		int selectedRow = form.getSelectedSearchRow();
		List searchResults = billDraftVO.getSearchResults();
		form.setListSearchResults(searchResults);
		
		EmBBBDraftDetailVO dispInvDtl = form.getDisplayDraftDetail();
		
		if (searchResults != null && searchResults.size() > selectedRow) {
			EmBBBDraftHeaderVO dispInvHdr = (EmBBBDraftHeaderVO)searchResults.get(selectedRow);
			form.setDisplayInvoiceHeader(dispInvHdr);

			EEMBillDao billDao = new EEMBillDao();
						
			// Get Details
			Pagination pagination = context.getBillDraftDetailPagination();
			
			List invDetail = billDao.getBillDraftDetailForMember(conn,dispInvDtl,dispInvHdr);
			
			if (invDetail != null && invDetail.size() > 0) {
				logger.debug("Got New Member Details !!");
				form.setListDetail(invDetail);
//				//form.setSelectedSearchRow(0);

				EmBBBDraftDetailVO [] arr = new EmBBBDraftDetailVO[invDetail.size()];
				arr = (EmBBBDraftDetailVO[])invDetail.toArray(arr);		

				pagination.setPaginationResults("first",arr);
				billDraftVO.setListDetail(invDetail);
				
				if (invDetail.size() > 0) {
					EmBBBDraftDetailVO dispDetail = (EmBBBDraftDetailVO)invDetail.get(0);
					form.setSelectedDetailRow(0);
					form.setDisplayDraftDetailForMember(dispDetail);
					form.setDetailDisplayState(EEMConstants.EEM_MBR_SCREEN_NONE);
					form.setDetailDisplayStateForMember(EEMConstants.EEM_MBR_SCREEN_EDIT);
				}
			}
			
		}	
		logger.info(LoggerConstants.methodEndLevel());
	}	
	
	public void billPaymentsSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillPaymentsForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		form.setHeaderDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setDetailDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		
		EMBillPaymentsVO billPayemtnsVO = context.getBillPaymentsVO();
		
		int selectedRow = form.getSelectedSearchRow();
		List searchResults = billPayemtnsVO.getSearchResults();
		form.setListSearchResults(searchResults);
		if (searchResults != null && searchResults.size() > selectedRow) {
			EmBBBPaymentsHeaderVO dispPayHdr = (EmBBBPaymentsHeaderVO)searchResults.get(selectedRow);
			form.setDisplayPaymentsHeader(dispPayHdr);
			
			// Get Details
			Pagination pagination = context.getBillPaymentsDetailPagination();
			EEMBillDao billDao = new EEMBillDao();
			List payDetail = billDao.getBillPaymentsDetail(conn,dispPayHdr,pagination,"first");
			if (payDetail != null && payDetail.size() > 0) {
				form.setListDetail(payDetail);

				EmBBBPaymentsDetailVO [] arr = new EmBBBPaymentsDetailVO[payDetail.size()];
				arr = (EmBBBPaymentsDetailVO[])payDetail.toArray(arr);		

				pagination.setPaginationResults("first",arr);
				billPayemtnsVO.setListDetail(payDetail);
				
				if (payDetail.size() > 0) {
					EmBBBPaymentsDetailVO dispDetail = (EmBBBPaymentsDetailVO)payDetail.get(0);
					form.setSelectedDetailRow(0);
					form.setDisplayPaymentsDetail(dispDetail);
					
					// Payment Detail Invoice list
					dispDetail.setListPymntDtlInvc(billDao.getBillPaymentsDetailInvoice(conn, dispDetail));
				} 
			}

		}	
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	
	public void billPaymentsSubSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillPaymentsForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		form.setHeaderDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setDetailDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		
		EMBillPaymentsVO billPayemtnsVO = context.getBillPaymentsVO();
		
		int selectedRow = form.getSelectedSearchRow();
		List searchResults = billPayemtnsVO.getSearchResults();
		form.setListSearchResults(searchResults);
		if (searchResults != null && searchResults.size() > selectedRow) {
			EmBBBPaymentsHeaderVO dispPayHdr = (EmBBBPaymentsHeaderVO)searchResults.get(selectedRow);
			form.setDisplayPaymentsHeader(dispPayHdr);
			
			//TSA -CR-00383227-Begin
		    dispPayHdr.setItemNumber(form.getItemNumber());
		    dispPayHdr.setMemberId(form.getMemberId());
		    dispPayHdr.setPosted(form.getPosted());
		    //TSA -CR-00383227-End
			
			Pagination subSearchPagination = new Pagination(); 
			subSearchPagination.setAllPage(false);
			subSearchPagination.setMaxRecordCount(10);
			context.setBillPaymentsDetailPagination(subSearchPagination);
		    
			// Get Details
			subSearchPagination = context.getBillPaymentsDetailPagination();
			EEMBillDao billDao = new EEMBillDao();
			List payDetail = billDao.getBillPaymentsDetail(conn,dispPayHdr,subSearchPagination,"first");
			if (payDetail != null && payDetail.size() > 0) {
				form.setListDetail(payDetail);

				EmBBBPaymentsDetailVO [] arr = new EmBBBPaymentsDetailVO[payDetail.size()];
				arr = (EmBBBPaymentsDetailVO[])payDetail.toArray(arr);		

				subSearchPagination.setPaginationResults("first",arr);
				billPayemtnsVO.setListDetail(payDetail);
				
				if (payDetail.size() > 0) {
					EmBBBPaymentsDetailVO dispDetail = (EmBBBPaymentsDetailVO)payDetail.get(0);
					form.setSelectedDetailRow(0);
					form.setDisplayPaymentsDetail(dispDetail);
					
					// Payment Detail Invoice list
					dispDetail.setListPymntDtlInvc(billDao.getBillPaymentsDetailInvoice(conn, dispDetail));
				} 
			}

		}	
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public void billMembPaymentsSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillMembPaymentsForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		form.setDetailDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		
		EMBillMembPaymentsVO billMembVO = context.getBillMembPaymentsVO();
		
		// Get Details
		Pagination pagination = context.getBillMembPaymentsPagination();
		EEMBillDao billDao = new EEMBillDao();
		List payDetail = billDao.getBillMembPaymentsSearchDetail(conn,billMembVO,pagination,"first");
		if (payDetail != null && payDetail.size() > 0) {
			form.setListDetail(payDetail);

			EmBBBPaymentsDetailVO [] arr = new EmBBBPaymentsDetailVO[payDetail.size()];
			arr = (EmBBBPaymentsDetailVO[])payDetail.toArray(arr);		

			pagination.setPaginationResults("first",arr);
			billMembVO.setListDetail(payDetail);
			
			if (payDetail.size() > 0) {
				EmBBBPaymentsDetailVO dispDetail = (EmBBBPaymentsDetailVO)payDetail.get(0);
				form.setSelectedDetailRow(0);
				form.setDisplayPaymentsDetail(dispDetail);
				
				// Payment Detail Invoice list
				dispDetail.setListPymntDtlInvc(billDao.getBillPaymentsDetailInvoice(conn, dispDetail));
			} 
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	
	public void billInvoiceDetailPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillInvoiceForm form, String move) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EMBillInvoiceVO billInvoiceVO = context.getBillInvoiceVO();
		
		int selectedRow = form.getSelectedSearchRow();
		List searchResults = billInvoiceVO.getSearchResults();
		form.setListSearchResults(searchResults);
		
		if (searchResults != null && searchResults.size() > selectedRow) {
			EmBBBInvoiceHeaderVO dispInvHdr = (EmBBBInvoiceHeaderVO)searchResults.get(selectedRow);
			form.setDisplayInvoiceHeader(dispInvHdr);
			
			Pagination pagination = context.getBillInvoiceDetailPagination();
			EEMBillDao billDao = new EEMBillDao();
			List invDetail = billDao.getBillInvoiceDetail(conn,dispInvHdr,pagination,move);
			if (invDetail != null && invDetail.size() > 0) {
				form.setListDetail(invDetail);
				form.setSelectedDetailRow(0);
				
				EmBBBInvoiceDetailVO [] arr = new EmBBBInvoiceDetailVO[invDetail.size()];
				arr = (EmBBBInvoiceDetailVO[])invDetail.toArray(arr);		

				pagination.setPaginationResults(move,arr);
				billInvoiceVO.setListDetail(invDetail);
				
				if (invDetail.size() > 0) {
					EmBBBInvoiceDetailVO dispDetail = (EmBBBInvoiceDetailVO)invDetail.get(form.getSelectedDetailRow());
					String detBankCd = billDao.getbankAcctCd(conn, dispDetail.getMemberId(), dispDetail.getCustomerId(), dispDetail.getInvoiceNbr()); //415889 Refund Extract
					form.setDisplayInvoiceDetail(dispDetail);
					// IFOX-00388907 Begin
					form.setLstFunctionCode(billDao.getBillFuncList(conn, dispInvHdr.getCustomerId(),"U", detBankCd)); //415889 Refund Extract
					// End
					form.setLstRefReasonCode(billDao.getBillRefReasonList(conn)); //415889 Refund Extract
				}
			}
			
		}	
		logger.info(LoggerConstants.methodEndLevel());
		
	}
	public void billPaymentsDetailPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillPaymentsForm form, String move) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EMBillPaymentsVO billPaymentsVO = context.getBillPaymentsVO();
		
		int selectedRow = form.getSelectedSearchRow();
		List searchResults = billPaymentsVO.getSearchResults();
		form.setListSearchResults(searchResults);
		if (searchResults != null && searchResults.size() > selectedRow) {
			EmBBBPaymentsHeaderVO dispPayHdr = (EmBBBPaymentsHeaderVO)searchResults.get(selectedRow);
			form.setDisplayPaymentsHeader(dispPayHdr);
			
			Pagination pagination = context.getBillPaymentsDetailPagination();
			EEMBillDao billDao = new EEMBillDao();
			List payDetail = billDao.getBillPaymentsDetail(conn,dispPayHdr,pagination,move);
			form.setListDetail(payDetail);
			form.setSelectedDetailRow(0);

			EmBBBPaymentsDetailVO [] arr = new EmBBBPaymentsDetailVO[payDetail.size()];
			arr = (EmBBBPaymentsDetailVO[])payDetail.toArray(arr);		

			pagination.setPaginationResults(move,arr);
			billPaymentsVO.setListDetail(payDetail);
			if (payDetail.size() > 0) {
				EmBBBPaymentsDetailVO dispDetail = (EmBBBPaymentsDetailVO)payDetail.get(form.getSelectedDetailRow());
				form.setDisplayPaymentsDetail(dispDetail);
					
				// Payment Detail Invoice list
				dispDetail.setListPymntDtlInvc(billDao.getBillPaymentsDetailInvoice(conn, dispDetail));

			}
			
		}
		logger.info(LoggerConstants.methodEndLevel());
		
	}

	public void billInvoiceDetailSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillInvoiceForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EMBillInvoiceVO billInvoiceVO = context.getBillInvoiceVO();
		
		int selectedRow = form.getSelectedSearchRow();
		List searchResults = billInvoiceVO.getSearchResults();
		form.setListSearchResults(searchResults);
		if (searchResults != null && searchResults.size() > selectedRow) {
			EmBBBInvoiceHeaderVO dispInvHdr = (EmBBBInvoiceHeaderVO)searchResults.get(selectedRow);
			form.setDisplayInvoiceHeader(dispInvHdr);
			form.setDisplayInvoiceSummary(billInvoiceVO.getInvoiceSummary());
			
			// Set Details
			EEMBillDao billDao = new EEMBillDao();
			List invDetail = billInvoiceVO.getListDetail();
			if (invDetail != null && invDetail.size() > 0) {
				form.setListDetail(invDetail);
				EmBBBInvoiceDetailVO dispDetail = (EmBBBInvoiceDetailVO)invDetail.get(form.getSelectedDetailRow());
				String detBankCd = billDao.getbankAcctCd(conn, dispDetail.getMemberId(), dispDetail.getCustomerId(), dispDetail.getInvoiceNbr()); //415889 Refund Extract
				form.setDisplayInvoiceDetail(dispDetail);
				form.setLstFunctionCode(billDao.getBillFuncList(conn, dispInvHdr.getCustomerId(),"U",detBankCd)); //415889 Refund Extract
				form.setLstRefReasonCode(billDao.getBillRefReasonList(conn)); //415889 Refund Extract
			}
			
			// Set Comments
			List invComments = billInvoiceVO.getListComment();
			form.setListCommentsWithDisplay(invComments);
		}		
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	
	public void billDraftDetailSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillDraftForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EMBillDraftVO billInvoiceVO = context.getBillDraftVO();
		
		int selectedRow = form.getSelectedSearchRow();
		List searchResults = billInvoiceVO.getSearchResults();
		form.setListSearchResults(searchResults);
		if (searchResults != null && searchResults.size() > selectedRow) {
			EmBBBDraftHeaderVO dispInvHdr = (EmBBBDraftHeaderVO)searchResults.get(selectedRow);
			form.setDisplayInvoiceHeader(dispInvHdr);
			form.setDisplayDraftSummary(billInvoiceVO.getInvoiceSummary());
			
			// Set Details
			EEMBillDao billDao = new EEMBillDao();
			List invDetail = billInvoiceVO.getListDetail();
			if (invDetail != null && invDetail.size() > 0) {
				form.setListDetail(invDetail);
				EmBBBDraftDetailVO dispDetail = (EmBBBDraftDetailVO)invDetail.get(form.getSelectedDetailRow());
				String detBankCd = billDao.getbankAcctCd(conn, dispDetail.getMemberId(), dispDetail.getCustomerId(), dispDetail.getInvoiceNbr()); //415889 Refund Extract
				form.setDisplayDraftDetail(dispDetail);
				form.setLstFunctionCode(billDao.getBillFuncList(conn, dispInvHdr.getCustomerId(),"U", detBankCd)); //415889 Refund Extract
			}
			
			// Set Comments
//			List invComments = billInvoiceVO.getListComment();
//			form.setListCommentsWithDisplay(invComments);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	
	
	public void billPaymentsRefresh(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillPaymentsForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EMBillPaymentsVO billPaymentsVO = context.getBillPaymentsVO();
		List searchResults = billPaymentsVO.getSearchResults();
		int selectedRow = form.getSelectedSearchRow();
		if (searchResults != null && searchResults.size() > selectedRow) {
			EEMBillDao billDao = new EEMBillDao();
			EmBBBPaymentsHeaderVO dispPayHdr = (EmBBBPaymentsHeaderVO)searchResults.get(selectedRow);
			dispPayHdr = billDao.getBillPaymentHeader(conn,dispPayHdr.getCustomerId(),
					                                  dispPayHdr.getPaySourceType(),dispPayHdr.getBatchDate(),dispPayHdr.getBatchSeqNbr());
			 
			searchResults.set(selectedRow,dispPayHdr);
			form.setDisplayPaymentsHeader(dispPayHdr);
			
			List lstDetail = billPaymentsVO.getListDetail();
			int selectedDtlRow = form.getSelectedDetailRow();
			if (lstDetail != null && lstDetail.size() > selectedDtlRow) {
				EmBBBPaymentsDetailVO dispPayDtl = (EmBBBPaymentsDetailVO)lstDetail.get(selectedDtlRow);
				
				dispPayDtl = billDao.getBillMembPaymentDetail(conn, dispPayDtl.getCustomerId(), 
												dispPayDtl.getPaySourceType(), dispPayDtl.getBatchDate(), 
												dispPayDtl.getBatchSeqNbr(), dispPayDtl.getItemNbr());
				 
				lstDetail.set(selectedDtlRow,dispPayDtl);
				form.setDisplayPaymentsDetail(dispPayDtl);
				form.setDetailDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
			}
		}
		billPaymentsDetailSelect(conn,sessionHelper,context,form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public void billPaymentsNewRefresh(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillPaymentsForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EMBillPaymentsVO billPaymentsVO = context.getBillPaymentsVO();
		List searchResults = billPaymentsVO.getSearchResults();
		int selectedRow = form.getSelectedSearchRow();
		if (searchResults != null && searchResults.size() > selectedRow) {
			EEMBillDao billDao = new EEMBillDao();
			EmBBBPaymentsHeaderVO dispPayHdr = (EmBBBPaymentsHeaderVO)searchResults.get(selectedRow);
			dispPayHdr = billDao.getBillPaymentHeader(conn,dispPayHdr.getCustomerId(),
					                                  dispPayHdr.getPaySourceType(),dispPayHdr.getBatchDate(),dispPayHdr.getBatchSeqNbr());
			 
			searchResults.set(selectedRow,dispPayHdr);
			form.setDisplayPaymentsHeader(dispPayHdr);
		}
		billPaymentsSelect(conn,sessionHelper,context,form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	public void billMembPaymentsRefresh(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillMembPaymentsForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EMBillMembPaymentsVO billMembPaymentsVO = context.getBillMembPaymentsVO();
		List searchResults = billMembPaymentsVO.getListDetail();
		int selectedRow = form.getSelectedDetailRow();
		if (searchResults != null && searchResults.size() > selectedRow) {
			EEMBillDao billDao = new EEMBillDao();
			EmBBBPaymentsDetailVO dispPayDtl = (EmBBBPaymentsDetailVO)searchResults.get(selectedRow);
			
			dispPayDtl = billDao.getBillMembPaymentDetail(conn, dispPayDtl.getCustomerId(), 
											dispPayDtl.getPaySourceType(), dispPayDtl.getBatchDate(), 
											dispPayDtl.getBatchSeqNbr(), dispPayDtl.getItemNbr());
			 
			searchResults.set(selectedRow,dispPayDtl);
			form.setDisplayPaymentsDetail(dispPayDtl);			
		}
		form.setDetailDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		billMembPaymentsDetailSelect(conn,sessionHelper,context,form);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public void billPaymentsDetailSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillPaymentsForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EMBillPaymentsVO billPaymentsVO = context.getBillPaymentsVO();
		
		int selectedRow = form.getSelectedSearchRow();
		List searchResults = billPaymentsVO.getSearchResults();
		form.setListSearchResults(searchResults);
		if (searchResults != null && searchResults.size() > selectedRow) {
			EmBBBPaymentsHeaderVO dispPayHdr = (EmBBBPaymentsHeaderVO)searchResults.get(selectedRow);
			form.setDisplayPaymentsHeader(dispPayHdr);
			
			// Set Details
			EEMBillDao billDao = new EEMBillDao();
			List payDetail = billPaymentsVO.getListDetail();
			if (payDetail != null && payDetail.size() > 0) {
				form.setListDetail(payDetail);
				EmBBBPaymentsDetailVO dispDetail = (EmBBBPaymentsDetailVO)payDetail.get(form.getSelectedDetailRow());
				form.setDisplayPaymentsDetail(dispDetail);
				
				dispDetail.setListPymntDtlInvc(billDao.getBillPaymentsDetailInvoice(conn, dispDetail));
			}

		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	public void billMembPaymentsDetailSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillMembPaymentsForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMBillDao billDao = new EEMBillDao();
		EMBillMembPaymentsVO billMbrPaymentsVO = context.getBillMembPaymentsVO();
		
		int selectedRow = form.getSelectedDetailRow();
		List searchResults = billMbrPaymentsVO.getListDetail();
		form.setListDetail(searchResults);
		if (searchResults != null && searchResults.size() > selectedRow) {
			form.setListDetail(searchResults);
			EmBBBPaymentsDetailVO dispDetail = (EmBBBPaymentsDetailVO)searchResults.get(selectedRow);
			form.setDisplayPaymentsDetail(dispDetail);
			
			dispDetail.setListPymntDtlInvc(billDao.getBillPaymentsDetailInvoice(conn, dispDetail));
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public EmBBBPaymentDtlInvoiceVO[] getPaymentDetails(Connection conn, SessionHelper sessionHelper, int selectedRow) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMContext context = EEMManager.getContext(sessionHelper.getSession());
		
		EMBillPaymentsVO billPaymentsVO = context.getBillPaymentsVO();
		EEMBillDao billDao = new EEMBillDao();
		List payDetail = billPaymentsVO.getListDetail();
		if (payDetail != null && payDetail.size() > 0) {
			EmBBBPaymentsDetailVO dispDetail = (EmBBBPaymentsDetailVO)payDetail.get(selectedRow);
			
			List lstPayDtlInv = billDao.getBillPaymentsDetailInvoice(conn, dispDetail); 
			EmBBBPaymentDtlInvoiceVO[] arr = new EmBBBPaymentDtlInvoiceVO[lstPayDtlInv.size()];
			
			logger.info(LoggerConstants.methodEndLevel());
			return (EmBBBPaymentDtlInvoiceVO[])lstPayDtlInv.toArray(arr); 
		}
		
		logger.info(LoggerConstants.methodEndLevel());
		return null;
	}

	public EmBBBPaymentDtlInvoiceVO[] getMembPaymentDetails(Connection conn, SessionHelper sessionHelper, int selectedRow) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMContext context = EEMManager.getContext(sessionHelper.getSession());
		
		EMBillMembPaymentsVO billMembPaymentsVO = context.getBillMembPaymentsVO();
		EEMBillDao billDao = new EEMBillDao();
		List payDetail = billMembPaymentsVO.getListDetail();
		if (payDetail != null && payDetail.size() > 0) {
			EmBBBPaymentsDetailVO dispDetail = (EmBBBPaymentsDetailVO)payDetail.get(selectedRow);
			
			List lstPayDtlInv = billDao.getBillPaymentsDetailInvoice(conn, dispDetail); 
			EmBBBPaymentDtlInvoiceVO[] arr = new EmBBBPaymentDtlInvoiceVO[lstPayDtlInv.size()];
			
			logger.info(LoggerConstants.methodEndLevel());
			return (EmBBBPaymentDtlInvoiceVO[])lstPayDtlInv.toArray(arr); 
		}
		
		logger.info(LoggerConstants.methodEndLevel());
		return null;
	}
	
	public void saveBillInvoiceComment(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillInvoiceForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		
		if (form.isCommentChanged()) {

			EMBillInvoiceVO billInvoiceVO = context.getBillInvoiceVO();
			int selectedRow = form.getSelectedSearchRow();
			List searchResults = billInvoiceVO.getSearchResults();
			
			if (searchResults != null && searchResults.size() > selectedRow) {
				EmBBBInvoiceHeaderVO dispInvHdr = (EmBBBInvoiceHeaderVO)searchResults.get(selectedRow);
				EmMbrCommentVO newVO = form.getDisplayComment();
				newVO.setCustomerId(dispInvHdr.getCustomerId());
				newVO.setMemberId(dispInvHdr.getInvoiceNbr());
				
				EmMbrCommentVO wrkVO = (EmMbrCommentVO)newVO.clone();
				wrkVO.setCreateUserId(sessionHelper.getUserId());
				
				EEMBillDao billDao = new EEMBillDao();
				boolean finalRslt = false;
				boolean rslt = billDao.getNextMbrComment(conn,wrkVO);
				if (rslt) {
					int cnt = billDao.insertBillInvoiceComment(conn,wrkVO);
					if (cnt == 1) {
						List comments = billDao.getBillInvoiceComments(conn, wrkVO.getCustomerId(), wrkVO.getMemberId());
						billInvoiceVO.setListComment(comments);
						finalRslt = true;
					}
				}
				
				if (finalRslt) {
					form.setDisplayComment((EmMbrCommentVO)billInvoiceVO.getListComment().get(0));
					form.setSelectedCommentRow(0);
					form.setCommentChanged(false);
					form.setCommentDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);						

					form.setTopDisplayCommentRow(0);
					Pagination pagination = context.getBillInvoiceCommentPagination();
					pagination.setListPaginationResults("first",billInvoiceVO.getListComment());
					form.setMessage("Saved Successfully.");
				} else {
					form.setMessage("Comment Add Failed.");
				}
				
				// Set the lists and related details
				billInvoiceDetailSelect(conn, sessionHelper, context, form);
			}	
			
		} else {
			form.setMessage("Data Not Changes");
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	private boolean isEligibleToUpdate(EmBBBInvoiceHeaderVO headerVO, SessionHelper sessionHelper) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		
		String wipUser = StringUtil.nonNullTrim(headerVO.getWipUserId());
		if (!wipUser.equals("")) {
			if (!sessionHelper.isEEMSupervisor() && !sessionHelper.getUserId().equals(wipUser)) {
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return true;
	}
	
	private boolean isEligibleToUpdate(EmBBBDraftHeaderVO headerVO, SessionHelper sessionHelper) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		
		String wipUser = StringUtil.nonNullTrim(headerVO.getWipUserId());
		if (!wipUser.equals("")) {
			if (!sessionHelper.isEEMSupervisor() && !sessionHelper.getUserId().equals(wipUser)) {
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return true;
	}
	
	
	private String hasValidTransferInput(Connection conn, EEMBillInvoiceForm form, String customerId, String mbrGrpInd) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		
		String transGrpId = StringUtil.nonNullTrim(form.getTransGrpId());
		String transAmt = StringUtil.nonNullTrim(form.getTransAmt());
		if (transGrpId.equals("")) {
			logger.info(LoggerConstants.methodEndLevel());
			return "Invalid Member/Group Id";
		} else if (transAmt.equals("") || Double.parseDouble(transAmt) <= 0) {
			logger.info(LoggerConstants.methodEndLevel());
			return "Invalid transfer Amount";
		} else {
			List lstName = new EEMBillDao().getBillMbrGrpList(conn, customerId, transGrpId, "", "", mbrGrpInd);
			if (lstName.size() > 0) {
				form.setTransName(((EmBBBInvoiceDetailVO)lstName.get(0)).getGroupName());
			} else {
				logger.info(LoggerConstants.methodEndLevel());
				return "Invalid Member/Group Id";
			}
		}
		
		
		
		logger.info(LoggerConstants.methodEndLevel());
		return "";
	}
	public boolean billInvoiceTransfer(Connection conn, String eemDb, SessionHelper sessionHelper, EEMContext context, EEMBillInvoiceForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());

    	boolean inTrans = false;
    	boolean origAutoCommit = false;
    	boolean success = false;
    	boolean failure = false;
		try {
			origAutoCommit = conn.getAutoCommit();
			conn.setAutoCommit(false);
			inTrans = true;
			int cntRec = 0;
			EEMBillDao billDao = new EEMBillDao();
			DateUtil dtUtil = new DateUtil();
			
			int selectedHeaderRow = form.getSelectedSearchRow();
			int selectedDetailRow = form.getSelectedDetailRow();
			EmBBBInvoiceHeaderVO selHeader = (EmBBBInvoiceHeaderVO)context.getBillInvoiceVO().getSearchResults().get(selectedHeaderRow);
			EmBBBInvoiceDetailVO selDetail = (EmBBBInvoiceDetailVO)context.getBillInvoiceVO().getListDetail().get(selectedDetailRow);
			
			EmBBBInvoiceHeaderVO headerVO = new EmBBBInvoiceHeaderVO(); 
			EmBBBInvoiceDetailVO detailVO = new EmBBBInvoiceDetailVO();
			EmBBBInvoiceHeaderVO prevHeaderVO = new EmBBBInvoiceHeaderVO();
			EmBBBInvoiceDetailVO prevDetailVO = new EmBBBInvoiceDetailVO();
			
			BeanUtils.copyProperties(headerVO, selHeader);
			BeanUtils.copyProperties(prevHeaderVO, selHeader);
			BeanUtils.copyProperties(detailVO, selDetail);
			BeanUtils.copyProperties(prevDetailVO, selDetail);
		
			//IFOX- 366144 - Start
			boolean lineItemHistoryExists = checkExistingAdjustmentsForLineItem(conn,headerVO,detailVO);
			boolean isValidForTransfer = false;
			String adjustableAmount = "";
			
			adjustableAmount = new EEMBillDao().getEligibleLineAmount(conn,detailVO.getCustomerId(), headerVO.getInvoiceType() , headerVO.getInvoiceNbr(), String.valueOf(detailVO.getItemNbr()));

			if(lineItemHistoryExists){
				isValidForTransfer = validateAmountForTransferOrRefundWithHistory(adjustableAmount,form.getTransAmt());
			}else{
				isValidForTransfer = validateAmountForTransferOrRefundWithoutHistory(adjustableAmount,form.getTransAmt());
			}
			
			//IFOX- 366144 - End
			if(!isValidForTransfer){
				form.setMessage("Invalid Transfer Adjustment");
				logger.info(LoggerConstants.methodEndLevel());
				return failure;
			}
			// Check for input
			
			String inputStatus = hasValidTransferInput(conn, form, headerVO.getCustomerId(), headerVO.getMbrGrpInd());
			if (!inputStatus.equals("")) {
				form.setMessage(inputStatus);
				logger.info(LoggerConstants.methodEndLevel());
				return success;
			}
			
			// Insert Transfer To Invoice Header
//TSA Changes :Start
			/*if (headerVO.getMbrGrpInd().equals("M"))
				headerVO.setInvoiceType("UM");
			else
				headerVO.setInvoiceType("UG");*/
	
			headerVO.setInvoiceType("UM");
//TSA Changes:End
			headerVO.setInvoiceId(form.getTransGrpId());
			headerVO.setGlProcessedInd("N");
			headerVO.setInvoiceStatus("NL");
			headerVO.setInvoiceAmt("0");
			headerVO.setPaymentAmt(""+Double.parseDouble(form.getTransAmt()) * -1);
			headerVO.setAdjustmentAmt("0");
			headerVO.setLastItemNbr("1");
			headerVO.setWipTime("0001-01-01 00:00:00.000000");
			headerVO.setWipUserId("");
			
			headerVO.setCreateUserId(sessionHelper.getUserId());
			headerVO.setLastUpdtUserId(sessionHelper.getUserId());
			String ts = dtUtil.getDB2DTS();
			headerVO.setCreateTime(ts);
			headerVO.setLastUpdtTime(ts);
			
			cntRec = billDao.insertBillInvoiceHeader(conn, eemDb, headerVO);
			
			// Insert Transfer To Invoice Detail
			if (cntRec > 0) {
				detailVO.setInvoiceNbr(headerVO.getInvoiceNbr());
				detailVO.setItemNbr(1);
				detailVO.setAddNbr(0);
//TSA Changes :Start
				/*if (headerVO.getMbrGrpInd().equals("M")) {
					detailVO.setFunctionCd("TTM");
					detailVO.setMemberId(form.getTransGrpId());
					detailVO.setGrpId("");
				} else { 
					detailVO.setFunctionCd("TTG");
					detailVO.setMemberId("");
					detailVO.setGrpId(form.getTransGrpId());*/
				
					detailVO.setFunctionCd("TTM");
					detailVO.setMemberId(form.getTransGrpId());
					detailVO.setGrpId("");
				
//TSA Changes :End				
				EmBBBFunctionCodeVO funcVO = billDao.getFunctionCode(conn, detailVO.getCustomerId(), detailVO.getFunctionCd());
				if (funcVO != null)
					detailVO.setItemDesc(StringUtil.nonNullTrim(funcVO.getShortDesc()));
				detailVO.setDetailAmt(headerVO.getPaymentAmt());
				detailVO.setXrefInvoiceNbr(prevDetailVO.getInvoiceNbr());
				
				detailVO.setCreateUserId(sessionHelper.getUserId());
				detailVO.setLastUpdtUserId(sessionHelper.getUserId());
				ts = dtUtil.getDB2DTS();
				detailVO.setCreateTime(ts);
				detailVO.setLastUpdtTime(ts);
				
				cntRec = billDao.insertBillInvoiceDetail(conn, detailVO);
			}
			
			// Insert Transfer From Invoice Detail
			if (cntRec > 0) {
				prevDetailVO.setAddNbr(billDao.getNextAddNbr(conn, prevDetailVO.getCustomerId(), prevDetailVO.getInvoiceNbr(), prevDetailVO.getItemNbr()));
//TSA Changes :Start
				/*if (prevHeaderVO.getMbrGrpInd().equals("M"))
					prevDetailVO.setFunctionCd("TFM");
				else 
					prevDetailVO.setFunctionCd("TFG");*/
		
					prevDetailVO.setFunctionCd("TFM");
//TSA Changes :End				
				EmBBBFunctionCodeVO funcVO = billDao.getFunctionCode(conn, prevDetailVO.getCustomerId(), prevDetailVO.getFunctionCd());
				if (funcVO != null)
					prevDetailVO.setItemDesc(StringUtil.nonNullTrim(funcVO.getShortDesc()));
				prevDetailVO.setDetailAmt(form.getTransAmt());
				prevDetailVO.setXrefInvoiceNbr(headerVO.getInvoiceNbr());
				
				prevDetailVO.setCreateUserId(sessionHelper.getUserId());
				prevDetailVO.setLastUpdtUserId(sessionHelper.getUserId());
				ts = dtUtil.getDB2DTS();
				prevDetailVO.setCreateTime(ts);
				prevDetailVO.setLastUpdtTime(ts);
				
				cntRec = billDao.insertBillInvoiceDetail(conn, prevDetailVO);
			}
			
			// Update Transfer From Invoice Header
			if (cntRec > 0) {
				double pymtAmt = Double.parseDouble(prevHeaderVO.getPaymentAmt()) + Double.parseDouble(form.getTransAmt());
				prevHeaderVO.setPaymentAmt(""+pymtAmt);
				prevHeaderVO.setGlProcessedInd("N");
				
				prevHeaderVO.setLastUpdtUserId(sessionHelper.getUserId());
				ts = dtUtil.getDB2DTS();
				prevHeaderVO.setLastUpdtTime(ts);
				
				cntRec = billDao.updateBillInvoiceTransferHeader(conn, prevHeaderVO);
			}
			
			// Insert Transfer To Payment Detail Invoice
			if (cntRec > 0) {
				detailVO.setCreateUserId(sessionHelper.getUserId());
				detailVO.setLastUpdtUserId(sessionHelper.getUserId());
				ts = dtUtil.getDB2DTS();
				detailVO.setCreateTime(ts);
				detailVO.setLastUpdtTime(ts);
				
				cntRec = billDao.insertBillPaymentDtlInvoice(conn, detailVO);
			}
			
			// Insert Transfer From Payment Detail Invoice
			if (cntRec > 0) {
				prevDetailVO.setCreateUserId(sessionHelper.getUserId());
				prevDetailVO.setLastUpdtUserId(sessionHelper.getUserId());
				ts = dtUtil.getDB2DTS();
				prevDetailVO.setCreateTime(ts);
				prevDetailVO.setLastUpdtTime(ts);
				
				cntRec = billDao.insertBillPaymentDtlInvoice(conn, prevDetailVO);
			}
			
			if (cntRec > 0) {
				conn.commit();
				inTrans = false;

				form.setMessage("Transfer Successful.");
				success = true;
			} else {
				form.setMessage("Error During Transfer.");
			}
			
		} catch(Exception e) { 
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			form.setMessage("Error during Record Update.");
		}finally {
   			if (inTrans)
   				conn.rollback();
   			conn.setAutoCommit(origAutoCommit);
		}
		
		logger.info(LoggerConstants.methodEndLevel());
		return success;
	}
	
	
	public void updateBillInvoiceDetails(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillInvoiceForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		
		
		EMBillInvoiceVO billInvoiceVO = context.getBillInvoiceVO();
		int selectedRow = form.getSelectedSearchRow();
		List searchResults = billInvoiceVO.getSearchResults();
		EEMBillDao billDao = new EEMBillDao();
		form.setLstRefReasonCode(billDao.getBillRefReasonList(conn)); //415889 Refund Extract
		if (searchResults != null && searchResults.size() > selectedRow) {
			EmBBBInvoiceHeaderVO dispInvHdr = (EmBBBInvoiceHeaderVO)searchResults.get(selectedRow);
			EmBBBInvoiceDetailVO dispInvDtl = form.getDisplayInvoiceDetail();
			dispInvDtl.setCustomerId(dispInvHdr.getCustomerId());
			dispInvDtl.setInvoiceNbr(dispInvHdr.getInvoiceNbr());
			
			// Check for WIP User
			if (!isEligibleToUpdate(dispInvHdr, sessionHelper)) {
				form.setMessage("Can only be updated by " + dispInvHdr.getWipUserId() + " or a supervisor");
				form.setListSearchResults(searchResults);
				form.setDisplayInvoiceHeader(dispInvHdr);
				form.setListDetail(billInvoiceVO.getListDetail());
				form.setLstFunctionCode(billDao.getBillFuncList(conn, dispInvHdr.getCustomerId(),"U", dispInvDtl.getBankAcctCd())); //415889 Refund Extract
				form.setListComments(billInvoiceVO.getListComment());
				
				return;
			}
			
			DateUtil du = new DateUtil();
			
			String ts = du.getDB2DTS();
			
			EmBBBInvoiceDetailVO wrkInvDetail = (EmBBBInvoiceDetailVO)dispInvDtl.clone();
			wrkInvDetail.setCreateUserId(sessionHelper.getUserId());
			wrkInvDetail.setCreateTime(ts);
			wrkInvDetail.setLastUpdtUserId(sessionHelper.getUserId());
			wrkInvDetail.setLastUpdtTime(ts);

			boolean inTrans = false;
			boolean lastAutoCommit = false;
			
			//Ticket 366140 - Start
			
			boolean isValidNumberForProcessing = false;
			boolean isLisPaymentType = false;
			boolean isHistoryExists = false;
			String adjustableAmount = "";
			boolean isValidFunction = false;
			boolean isREFORNSF = false;
			boolean isNotValidAmountForRefundOrNSF = false;
					
			EmBBBInvoiceDetailVO comparisonInvDetail = (EmBBBInvoiceDetailVO) billInvoiceVO.getListDetail().get(form.getSelectedDetailRow());

			if(!"LSC".equalsIgnoreCase(wrkInvDetail.getSubProductId())){
				
				String paySourceType = comparisonInvDetail.getPaySourceType();
			
				if("NSF".equalsIgnoreCase(wrkInvDetail.getFunctionCd()) && !"W".equalsIgnoreCase(paySourceType) && !"".equals(paySourceType) && !"S".equalsIgnoreCase(paySourceType)) {
					adjustableAmount = new EEMBillDao().getEligibleLineAmount(conn,dispInvHdr.getCustomerId(), dispInvHdr.getInvoiceType() , dispInvHdr.getInvoiceNbr(), String.valueOf(dispInvDtl.getItemNbr()));
					isValidNumberForProcessing = validateAmountForTransferOrRefundWithHistory(adjustableAmount, form.getDisplayInvoiceDetail().getDetailAmt() );
					isValidFunction = true;
					isREFORNSF = true;
					double workInvoiceAmount = Double.parseDouble(form.getDisplayInvoiceDetail().getDetailAmt());
					if(workInvoiceAmount < 0 ){ 
						isNotValidAmountForRefundOrNSF = true;
					}
					
				}else if(("MCR".equalsIgnoreCase(wrkInvDetail.getFunctionCd()) || 
						  "MDR".equalsIgnoreCase(wrkInvDetail.getFunctionCd()) || 
						  "WTO".equalsIgnoreCase(wrkInvDetail.getFunctionCd())) && 
						  "".equalsIgnoreCase(paySourceType) || "M".equalsIgnoreCase(paySourceType) ||
						  "A".equalsIgnoreCase(paySourceType) || "L".equalsIgnoreCase(paySourceType) ||
						  "E".equalsIgnoreCase(paySourceType) || "C".equalsIgnoreCase(paySourceType)){ //BCBSAZ defect -00421115
					
					if("WTO".equalsIgnoreCase(wrkInvDetail.getFunctionCd())){
						adjustableAmount = new EEMBillDao().getEligibleLineAmount(conn,dispInvHdr.getCustomerId(), dispInvHdr.getInvoiceType() , dispInvHdr.getInvoiceNbr(), String.valueOf(dispInvDtl.getItemNbr()));
						isValidNumberForProcessing = validateAmountForTransferOrRefundWithHistory(adjustableAmount, form.getDisplayInvoiceDetail().getDetailAmt() );
					}else{
						isValidNumberForProcessing = validateNumberForDebitAndCreditAdjustment(form.getDisplayInvoiceDetail().getDetailAmt(), comparisonInvDetail.getDetailAmt(),wrkInvDetail.getFunctionCd());
					}
					isValidFunction = true;
					//Ticket 366141 - End
				}else if("REF".equalsIgnoreCase(wrkInvDetail.getFunctionCd()) && !"W".equalsIgnoreCase(paySourceType) && !"S".equalsIgnoreCase(paySourceType) && !"".equals(paySourceType)){
					adjustableAmount = new EEMBillDao().getEligibleLineAmount(conn,dispInvHdr.getCustomerId(), dispInvHdr.getInvoiceType() , dispInvHdr.getInvoiceNbr(), String.valueOf(dispInvDtl.getItemNbr()));
					isValidNumberForProcessing = validateAmountForTransferOrRefundWithHistory(adjustableAmount, form.getDisplayInvoiceDetail().getDetailAmt() );
					isValidFunction = true;
					isREFORNSF = true;
					double workInvoiceAmount = Double.parseDouble(form.getDisplayInvoiceDetail().getDetailAmt());
					if(workInvoiceAmount < 0 ){ 
						isNotValidAmountForRefundOrNSF = true;
					}
					//Ticket 366141 - End
				}else if("RER".equalsIgnoreCase(wrkInvDetail.getFunctionCd()) && "REF".equalsIgnoreCase(comparisonInvDetail.getFunctionCd())){
					isValidNumberForProcessing = validateNumberForOtherAdjustment(form.getDisplayInvoiceDetail().getDetailAmt(), comparisonInvDetail.getDetailAmt());
					isValidFunction = true;
				}else {
					isValidFunction = false;
				}
				
			}else{
				isLisPaymentType = true;
			}
			//Ticket 366140 - End

			
			try {
				lastAutoCommit = conn.getAutoCommit();
				EMBillFuncVO billFunc = billDao.getBillFunction(conn,wrkInvDetail.getCustomerId(),wrkInvDetail.getFunctionCd());
				if (billFunc == null) {
					form.setMessage("Billing Function Lookup Error");
					form.setFocusField("eemBillInvoiceForm['displayInvoiceDetail.functionCd']");
					//Ticket 366000 - Start
				} else if(!isValidFunction || !isValidNumberForProcessing || isNotValidAmountForRefundOrNSF || 
						(wrkInvDetail.getFunctionCd().equalsIgnoreCase("REF") && 
								((comparisonInvDetail.getPaySourceType().equalsIgnoreCase("S")) || 
										(comparisonInvDetail.getPaySourceType().equalsIgnoreCase(""))))){
					if(isLisPaymentType){
						form.setMessage("Adjustments are not allowed for LIS Payments");
					}else if (!isValidFunction){
						form.setMessage("Invalid Adjustment");
					}else if(!isValidNumberForProcessing){
						form.setMessage("Invalid Transaction amount for this line item");
						form.setFocusField("eemBillInvoiceForm['displayInvoiceDetail.detailAmt']");
					}else if(isREFORNSF && isNotValidAmountForRefundOrNSF) {
						form.setMessage("NSF and Refund adjustments value cannot be Negative");
					}/*else{
						form.setMessage("Invalid Payment Source Type For Refund");
					}*/
					//Ticket 366000 - End
					
				} else {
					//String paySourceType = billDao.validateBankAcctCd(conn,wrkInvDetail.getCustomerId(),wrkInvDetail.getBankAcctCd(),dispInvHdr.getBillThruDate());
					//if (paySourceType == null) {
					String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
					// IFOX-366886 - Start
					String fetchBCIndicator = EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(), EEMProfileSettings.BANKCDTB);
					// IFOX-366886 - End
					boolean rslt;
					
					if("Y".equalsIgnoreCase(fetchBCIndicator)){
						if("MCR".equalsIgnoreCase(wrkInvDetail.getFunctionCd()) || "MDR".equalsIgnoreCase(wrkInvDetail.getFunctionCd()) || "WTO".equalsIgnoreCase(wrkInvDetail.getFunctionCd())){
							rslt = true;
						}else{
							rslt = billDao.validateGlBankAcctCdForMMO(conn,wrkInvDetail.getCustomerId(),wrkInvDetail.getBankAcctCd(),dispInvHdr.getBillThruDate());
						}
					}else{
						// IFOX-415141 Billing Enhancements CR - Start

						String multiORG = sessionHelper.getAttribute(EEMProfileSettings.MULTIORG).toString();
						if("Y".equalsIgnoreCase(multiORG)){
							
							rslt = billDao.validateGlBankAcctCdForPlanID(conn,wrkInvDetail.getCustomerId(),billInvoiceVO.getInvoiceSummary().getMemberId(), wrkInvDetail.getBankAcctCd(),dispInvHdr.getBillThruDate());
						}else{
							rslt = billDao.validateGlBankAcctCd(conn,wrkInvDetail.getCustomerId(),wrkInvDetail.getBankAcctCd(),dispInvHdr.getBillThruDate());
						}
						
						// IFOX-415141 Billing Enhancements CR - End

					}

					if (!rslt) {
						form.setMessage("Invalid Bank Account Cd");
						form.setFocusField("eemBillInvoiceForm['displayInvoiceDetail.bankAcctCd']");
					} else {
						int itemNbr = -1;
						int nbr = -1;
						if (billFunc.getHdrDtlTranInd().equals("H")) {
							nbr = billDao.getNextItemNbr(conn,wrkInvDetail.getCustomerId(),wrkInvDetail.getInvoiceNbr());
							if (nbr == -1) {
								form.setMessage("Error Getting Item Number");
							} else {
								itemNbr = nbr;
								wrkInvDetail.setItemNbr(nbr);
								wrkInvDetail.setAddNbr(0);
							}
						} else {
							nbr = billDao.getNextAddNbr(conn,wrkInvDetail.getCustomerId(),wrkInvDetail.getInvoiceNbr(),wrkInvDetail.getItemNbr());
							if (nbr == -1) {
								form.setMessage("Error Getting Adjustment Number");
							} else {
								wrkInvDetail.setAddNbr(nbr);
							}
						}
						if (nbr != -1) {
							wrkInvDetail.setLineStatus("A");
							wrkInvDetail.setItemDesc(billFunc.getShortDesc());
							wrkInvDetail.setPayBatchDate("");
							wrkInvDetail.setPayBatchSeqNbr("");
							wrkInvDetail.setPayItemNbr("");
							
							conn.setAutoCommit(false);
							inTrans = true;
														
							// IFOX- 390543 Begin
							String strInvoiceDetails = form.getStrInvoiceDetails();
							if(!StringUtil.nonNullTrim(strInvoiceDetails).equals("") && !strInvoiceDetails.equals("%%%") && "PAY".equalsIgnoreCase(comparisonInvDetail.getFunctionCd())){
								String[] strInvoiceDetailsArr = strInvoiceDetails.split("%");
								wrkInvDetail.setPaySourceDesc(strInvoiceDetailsArr[0]);	
								wrkInvDetail.setPayBatchDate(strInvoiceDetailsArr[1]);
								wrkInvDetail.setPayBatchSeqNbr(strInvoiceDetailsArr[2]);
								wrkInvDetail.setPayItemNbr(strInvoiceDetailsArr[3]);
							}
							// IFOX- 390543 End
							conn.setAutoCommit(false);
							inTrans = true;
							
							int cnt = billDao.insertBillInvoiceDetail(conn, wrkInvDetail);
							// IFOX- 390543 Begin
							if("PAY".equalsIgnoreCase(comparisonInvDetail.getFunctionCd())){						
								if(cnt == 1)  {
									cnt = billDao.insertBillPaymentDtlInvoice(conn, wrkInvDetail);
								}
							}
							// IFOX- 390543 End
							if (cnt == 1) {
								cnt = billDao.updateBillInvoiceHeader(conn,wrkInvDetail, itemNbr, dispInvHdr.getInvoiceStatus());
					        
								if (cnt == 1) {
									// Insert comment
									saveBillInvoiceComment(conn, sessionHelper, context, form);
									
									conn.commit();
									inTrans = false;
									
									dispInvHdr = billDao.getBillInvoiceHeader(conn,wrkInvDetail.getCustomerId(),wrkInvDetail.getInvoiceNbr(), billInvoiceVO);
									searchResults.set(selectedRow,dispInvHdr);
									billInvoiceSelect(conn, sessionHelper, context, form);
									form.setMessage("Updated Successfully.");
									return;
								}
								form.setMessage("Invoice Header Update Failed.");
							} else {
								logger.debug(" Error in updateBillInvoiceDetails--count:: "+cnt);
								form.setMessage("Invoice Details Update Failed.");
								//form.setDetailDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
								//billInvoiceDetailSelect(conn, sessionHelper, context, form);
							}
						}
					}
				}
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				e.printStackTrace(log);
				logger.debug(" Error in updateBillInvoiceDetails--Exception message :: "+e.getMessage());
				form.setMessage("Invoice Details Update Failed.");
			} finally {
				if (inTrans) {
					try {
						conn.rollback();
					} catch(Exception e) {
						logger.error(LoggerConstants.exceptionMessage(e.toString()));
						e.printStackTrace(log);
					}
				}
				try {
					conn.setAutoCommit(lastAutoCommit);
				} catch(Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					e.printStackTrace(log);
				}
			}			
			form.setListSearchResults(searchResults);
			form.setDisplayInvoiceHeader(dispInvHdr);
			form.setListDetail(billInvoiceVO.getListDetail());
			form.setLstFunctionCode(billDao.getBillFuncList(conn, dispInvHdr.getCustomerId(),"U", dispInvDtl.getBankAcctCd())); //415889 Refund Extract
			form.setListComments(billInvoiceVO.getListComment());

		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	
	
	public void updateBillDraftDetails(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillDraftForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EMBillDraftVO billInvoiceVO = context.getBillDraftVO();
		int selectedRow = form.getSelectedSearchRow();
		List searchResults = billInvoiceVO.getSearchResults();
		EEMBillDao billDao = new EEMBillDao();
		boolean isValidForUpdate = false;
		boolean inTrans = false;
		boolean lastAutoCommit = false;
		EmBBBDraftDetailVO oldDetailVO = (EmBBBDraftDetailVO) billInvoiceVO.getListDetail().get(0);

		EmBBBDraftDetailVO newDetailVO = form.getDisplayDraftDetail(); 
		try {
			lastAutoCommit = conn.getAutoCommit();
	
			if (searchResults != null && searchResults.size() > selectedRow) {
				EmBBBDraftHeaderVO dispInvHdr = (EmBBBDraftHeaderVO)searchResults.get(selectedRow);
				EmBBBDraftDetailVO dispInvDtl = form.getDisplayDraftDetail();
				dispInvDtl.setCustomerId(dispInvHdr.getCustomerId());
				dispInvDtl.setInvoiceNbr(dispInvHdr.getInvoiceNbr());
				
				// Check for WIP User
				if (!isEligibleToUpdate(dispInvHdr, sessionHelper)) {
					form.setMessage("Can only be updated by " + dispInvHdr.getWipUserId() + " or a supervisor");
					form.setListSearchResults(searchResults);
					form.setDisplayDraftDetail(dispInvDtl);
					form.setListDetail(billInvoiceVO.getListDetail());
					//form.setLstFunctionCode(billDao.getBillFuncList(conn, dispInvHdr.getCustomerId(),"U"));
					//form.setListComments(billInvoiceVO.getListComment());
					
				}

				conn.setAutoCommit(false);
				inTrans = true;

				isValidForUpdate = validateDraftDetails(conn,dispInvDtl,dispInvHdr);
				
				if(isValidForUpdate){
					dispInvDtl.setLastUpdtUserId(sessionHelper.getUserId());
					int result = billDao.updateBillDraftDetail(conn, dispInvDtl,dispInvHdr);
					if(result == 0){
						form.setMessage("Settlement Date is Not Valid : It cannot be greater than 60 Days !!");
						form.setListSearchResults(searchResults);
						//form.setDisplayDraftHeader(dispInvHdr);
						form.setListDetail(billInvoiceVO.getListDetail());
						//billDraftSelect(conn, sessionHelper, context, form);
						billDraftSelectAfterUpdate(conn, sessionHelper, context, form,newDetailVO);
						//form.setDetailDisplayState(EEMConstants.EEM_MBR_SCREEN_EDIT);
						//form.setFocusField("eemBillDraftForm['displayDraftDetail.settlementDateFrmt']");
						//dispInvDtl.setDraftStatus("N");
						logger.info(LoggerConstants.methodEndLevel());
						return;
					}else if(result == -1 ){
						form.setMessage("The Response Code is Not Valid - Please Update Again !!");
						form.setListSearchResults(searchResults);
						//form.setDisplayDraftHeader(dispInvHdr);
						form.setListDetail(billInvoiceVO.getListDetail());
						//billDraftSelect(conn, sessionHelper, context, form);
						billDraftSelectAfterUpdate(conn, sessionHelper, context, form,newDetailVO);
						//form.setDetailDisplayState(EEMConstants.EEM_MBR_SCREEN_EDIT);
						//form.setFocusField("eemBillDraftForm['displayDraftDetail.responseCode']");
						//dispInvDtl.setDraftStatus("X");
						logger.info(LoggerConstants.methodEndLevel());
						return;
					}else if(result == -2 ){
						form.setMessage("Invalid Operation For Draft Details Update - Please Update Again !!");
						form.setListSearchResults(searchResults);
						//form.setDisplayDraftHeader(dispInvHdr);
						form.setListDetail(billInvoiceVO.getListDetail());
						//billDraftSelect(conn, sessionHelper, context, form);
						billDraftSelectAfterUpdate(conn, sessionHelper, context, form,newDetailVO);
						//form.setDetailDisplayState(EEMConstants.EEM_MBR_SCREEN_EDIT);
						//form.setFocusField("eemBillDraftForm['displayDraftDetail.draftStatus']");
						//dispInvDtl.setDraftStatus("S");
						logger.info(LoggerConstants.methodEndLevel());
						return;
					}
					
				}
	
				
				form.setListSearchResults(searchResults);
				//form.setDisplayDraftHeader(dispInvHdr);
				form.setListDetail(billInvoiceVO.getListDetail());
				//billDraftSelectAfterUpdate(conn, sessionHelper, context, form,dispInvDtl);
				EMBillDraftVO emBillDraftVO = context.getBillDraftVO();
				
				emBillDraftVO.setCustomerId(newDetailVO.getCustomerId());
				emBillDraftVO.setSearchInvoiceId(newDetailVO.getMemberId());
				emBillDraftVO.setSearchInvoiceNbr(newDetailVO.getInvoiceNbr());
				emBillDraftVO.setSearchInvoiceStatus(newDetailVO.getDraftStatus());
				
				billDraftSearchPage(conn, sessionHelper, context, form,"first", null);
				conn.commit();
				inTrans = false;
				form.setMessage("Updated Successfully.");
				logger.info(LoggerConstants.methodEndLevel());
				return;
			}
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			form.setMessage("Draft Details Update Failed.");
		} finally {
			if (inTrans) {
				try {
					conn.rollback();
				} catch(Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					e.printStackTrace(log);
				}
			}
			try {
				conn.setAutoCommit(lastAutoCommit);
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				e.printStackTrace(log);
			}			
		}
		logger.info(LoggerConstants.methodEndLevel());
		}
		
	
	public void eemBillDraftGetMemberDetails(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillDraftForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EMBillDraftVO billInvoiceVO = context.getBillDraftVO();
		int selectedRow = form.getSelectedSearchRow();
		List searchResults = billInvoiceVO.getSearchResults();
		EEMBillDao billDao = new EEMBillDao();
		boolean isValidMember = false;

		try {
	
			if (searchResults != null && searchResults.size() > selectedRow) {
				EmBBBDraftHeaderVO dispInvHdr = (EmBBBDraftHeaderVO)searchResults.get(selectedRow);
				EmBBBDraftDetailVO dispInvDtl = form.getDisplayDraftDetail();
				dispInvDtl.setCustomerId(dispInvHdr.getCustomerId());
				logger.debug("New Member ID for retrieving the details :"+dispInvDtl.getMemberId());

				isValidMember = validateMemberDetails(conn,dispInvDtl);
				
				if(isValidMember){
					form.setListSearchResults(searchResults);
					//form.setDisplayDraftHeader(dispInvHdr);
					form.setListDetail(billInvoiceVO.getListDetail());
					billDraftSelectForMember(conn, sessionHelper, context, form);
					
				}else{
					form.setMessage("This Member Id does not exist - Please Add a valid member again !!");
					form.setListSearchResults(searchResults);
					//form.setDisplayDraftHeader(dispInvHdr);
					form.setListDetail(billInvoiceVO.getListDetail());
					billDraftSelect(conn, sessionHelper, context, form);
					//billDraftSearch(conn, sessionHelper, context, form);
					
				}
					
			}
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//form.setMessage("Draft Details Update Failed.");
			e.printStackTrace();
		} finally {
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
		
	
	
	public void insertBillDraftDetails(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillDraftForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());

		EMBillDraftVO billDraftVO = context.getBillDraftVO();
		int selectedRow = form.getSelectedSearchRow();
		List searchResults = billDraftVO.getSearchResults();
		EEMBillDao billDao = new EEMBillDao();
		boolean isValidForInsert = false;
		boolean inTrans = false;
		boolean lastAutoCommit = false;

		EmBBBDraftDetailVO oldDraftDetail = (EmBBBDraftDetailVO)billDraftVO.getListDetail().get(0);
		EmBBBDraftDetailVO newDraftDetail = form.getDisplayDraftDetail();
		
		try {
			lastAutoCommit = conn.getAutoCommit();
	
			if (searchResults != null && searchResults.size() > selectedRow) {
				EmBBBDraftHeaderVO dispInvHdr = (EmBBBDraftHeaderVO)searchResults.get(selectedRow);
				EmBBBDraftDetailVO dispInvDtl = form.getDisplayDraftDetail();
				dispInvDtl.setCustomerId(dispInvHdr.getCustomerId());
				
				// Check for WIP User
				if (!isEligibleToUpdate(dispInvHdr, sessionHelper)) {
					form.setMessage("Can only be updated by " + dispInvHdr.getWipUserId() + " or a supervisor");
					form.setListSearchResults(searchResults);
					form.setDisplayDraftDetail(dispInvDtl);
					form.setListDetail(billDraftVO.getListDetail());
				}

				conn.setAutoCommit(false);
				inTrans = true;

				isValidForInsert = validateMemberDetails(conn,dispInvDtl);
				
				if(isValidForInsert){
					dispInvDtl.setLastUpdtUserId(sessionHelper.getUserId());
					int result = billDao.insertBillDraftDetail(conn, dispInvDtl,false);
					if(result == 0){
						form.setMessage("Settlement Date is Not Valid - Please Add Draft again !!");
						form.setListSearchResults(searchResults);
						//form.setDisplayDraftHeader(dispInvHdr);
						form.setListDetail(billDraftVO.getListDetail());
						billDraftSelectAfterUpdate(conn, sessionHelper, context, form,newDraftDetail);
						//form.setDetailDisplayState(EEMConstants.EEM_MBR_SCREEN_EDIT);
						//billDraftSearch(conn, sessionHelper, context, form);
						logger.info(LoggerConstants.methodEndLevel());
						return;
					}
					
				}	
				
				form.setListSearchResults(searchResults);
				//form.setDisplayDraftHeader(dispInvHdr);
				form.setListDetail(billDraftVO.getListDetail());
				//billDraftSelect(conn, sessionHelper, context, form);
				billDraftVO.setCustomerId(dispInvDtl.getCustomerId());
				billDraftVO.setSearchInvoiceId(dispInvDtl.getMemberId());
				billDraftVO.setSearchInvoiceNbr(dispInvDtl.getInvoiceNbr());
				billDraftVO.setSearchInvoiceStatus(dispInvDtl.getDraftStatus());
				billDraftSearchPage(conn, sessionHelper, context, form,"first", null);
				conn.commit();
				inTrans = false;
				form.setMessage("New ACH Draft Created Successfully !!");
				logger.info(LoggerConstants.methodEndLevel());
				return;
			}
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			form.setMessage("Draft Details Insertion Failed.");
		} finally {
			if (inTrans) {
				try {
					conn.rollback();
				} catch(Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					e.printStackTrace(log);
				}
			}
			try {
				conn.setAutoCommit(lastAutoCommit);
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				e.printStackTrace(log);
			}			
		}
		logger.info(LoggerConstants.methodEndLevel());
		}
		
	
	public void insertBillDraftDetailsForMember(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillDraftForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());

		EMBillDraftVO billDraftVO = context.getBillDraftVO();
		int selectedRow = form.getSelectedSearchRow();
		List searchResults = billDraftVO.getSearchResults();
		EEMBillDao billDao = new EEMBillDao();
		boolean isValidForInsert = false;
		boolean inTrans = false;
		boolean lastAutoCommit = false;

		EmBBBDraftDetailVO oldDraftDetailForMember = (EmBBBDraftDetailVO) billDraftVO.getListDetail().get(0);
		EmBBBDraftDetailVO newDraftDetailForMember = form.getDisplayDraftDetailForMember();
		
		try {
			lastAutoCommit = conn.getAutoCommit();
	
			if (searchResults != null && searchResults.size() > selectedRow) {
				EmBBBDraftHeaderVO dispInvHdr = (EmBBBDraftHeaderVO)searchResults.get(selectedRow);
				EmBBBDraftDetailVO dispInvDtl = form.getDisplayDraftDetailForMember();
				dispInvDtl.setCustomerId(dispInvHdr.getCustomerId());
				
				// Check for WIP User
				if (!isEligibleToUpdate(dispInvHdr, sessionHelper)) {
					form.setMessage("Can only be updated by " + dispInvHdr.getWipUserId() + " or a supervisor");
					form.setListSearchResults(searchResults);
					form.setDisplayDraftDetail(dispInvDtl);
					form.setListDetail(billDraftVO.getListDetail());
				}

				conn.setAutoCommit(false);
				inTrans = true;

				isValidForInsert = validateMemberDetails(conn,dispInvDtl);
				
				if(isValidForInsert){
					dispInvDtl.setLastUpdtUserId(sessionHelper.getUserId());
					int result = billDao.insertBillDraftDetail(conn, dispInvDtl,true);
					if(result == 0){
						form.setMessage("Settlement Date is Not Valid - Please Add Draft again !!");
						form.setListSearchResults(searchResults);
						//form.setDisplayDraftHeader(dispInvHdr);
						form.setListDetail(billDraftVO.getListDetail());
						billDraftSelectAfterUpdate(conn, sessionHelper, context, form,newDraftDetailForMember);
						//form.setDetailDisplayState(EEMConstants.EEM_MBR_SCREEN_EDIT);
						//billDraftSearch(conn, sessionHelper, context, form);
						logger.info(LoggerConstants.methodEndLevel());
						return;
					}
					
				}	
				
				form.setListSearchResults(searchResults);
				//form.setDisplayDraftHeader(dispInvHdr);
				form.setListDetail(billDraftVO.getListDetail());
				//billDraftSelect(conn, sessionHelper, context, form);
				billDraftVO.setCustomerId(newDraftDetailForMember.getCustomerId());
				billDraftVO.setSearchInvoiceId(newDraftDetailForMember.getMemberId());
				billDraftVO.setSearchInvoiceNbr(newDraftDetailForMember.getInvoiceNbr());
				billDraftVO.setSearchInvoiceStatus(newDraftDetailForMember.getDraftStatus());				
				billDraftSearchPage(conn, sessionHelper, context, form,"first", null);
				conn.commit();
				inTrans = false;
				form.setMessage("New ACH Draft Created Successfully !!");
				logger.info(LoggerConstants.methodEndLevel());
				return;
			}
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			form.setMessage("Draft Details Insertion Failed.");
			e.printStackTrace();
		} finally {
			if (inTrans) {
				try {
					conn.rollback();
				} catch(Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					e.printStackTrace(log);
				}
			}
			try {
				conn.setAutoCommit(lastAutoCommit);
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				e.printStackTrace(log);
			}			
		}
		logger.info(LoggerConstants.methodEndLevel());
		
		}
		
	
	
	
	
	public void updateBillPaymentHeaderDetails(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillPaymentsForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		
		EMBillPaymentsVO billPaymentsVO = context.getBillPaymentsVO();
		int selectedRow = form.getSelectedSearchRow();
		List searchResults = billPaymentsVO.getSearchResults();
		
		if (searchResults != null && searchResults.size() > selectedRow) {
			EmBBBPaymentsHeaderVO dispPayHdr = (EmBBBPaymentsHeaderVO)searchResults.get(selectedRow);
			EmBBBPaymentsHeaderVO entryPayHdr = form.getDisplayPaymentsHeader();
			entryPayHdr.setCustomerId(dispPayHdr.getCustomerId());
			entryPayHdr.setPaySourceType(dispPayHdr.getPaySourceType());
			entryPayHdr.setBatchDate(dispPayHdr.getBatchDate());
			entryPayHdr.setBatchSeqNbr(dispPayHdr.getBatchSeqNbr());
			entryPayHdr.setLastUpdtTime(dispPayHdr.getLastUpdtTime());
			entryPayHdr.setLastUpdtUserId(sessionHelper.getUserId());
			entryPayHdr.setBatchBalanceAmt(NumberFormatter.formatDecimal2Places(entryPayHdr.getBatchBalanceAmt()));
			
			EEMBillDao billDao = new EEMBillDao();
			int cnt = billDao.updateBillPaymentHeaderDetails(conn, entryPayHdr);
			if (cnt == 1) {
				dispPayHdr = billDao.getBillPaymentHeader(conn,dispPayHdr.getCustomerId(),
						                                  dispPayHdr.getPaySourceType(),dispPayHdr.getBatchDate(),dispPayHdr.getBatchSeqNbr());
					 
				searchResults.set(selectedRow,dispPayHdr);
				form.setDisplayPaymentsHeader(dispPayHdr);
				billPaymentsDetailSelect(conn, sessionHelper, context, form);
				form.setHeaderDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
				form.setMessage("Updated Successfully.");
			} else {
				form.setHeaderDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
				billPaymentsDetailSelect(conn, sessionHelper, context, form);
				form.setMessage("Payment Header Details Update Failed.");
			} 
						
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	public void updateBillPaymentDetails(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillPaymentsForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		
		EMBillPaymentsVO billPaymentsVO = context.getBillPaymentsVO();
		int selectedRow = form.getSelectedDetailRow();
		List listDetail = billPaymentsVO.getListDetail();
		
		if (listDetail != null && listDetail.size() > selectedRow) {
			EmBBBPaymentsDetailVO dispPayDtl = (EmBBBPaymentsDetailVO)listDetail.get(selectedRow);
			EmBBBPaymentsDetailVO entryPayDtl = form.getDisplayPaymentsDetail();
			entryPayDtl.setCustomerId(dispPayDtl.getCustomerId());
			entryPayDtl.setPaySourceType(dispPayDtl.getPaySourceType());
			entryPayDtl.setBatchDate(dispPayDtl.getBatchDate());
			entryPayDtl.setBatchSeqNbr(dispPayDtl.getBatchSeqNbr());
			entryPayDtl.setItemNbr(dispPayDtl.getItemNbr());
			entryPayDtl.setLastUpdtTime(dispPayDtl.getLastUpdtTime());
			entryPayDtl.setLastUpdtUserId(sessionHelper.getUserId());
			
			EEMBillDao billDao = new EEMBillDao();
			// Check valid Invoice Id
			if (billDao.checkInvoiceId(conn, entryPayDtl.getCustomerId(), entryPayDtl.getInvoiceId())) {
				entryPayDtl.setInvoiceDueDate(DateFormatter.reFormat(entryPayDtl.getInvoiceDueDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
				entryPayDtl.setCheckDate(DateFormatter.reFormat(entryPayDtl.getCheckDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
				entryPayDtl.setPaymentAmt(NumberFormatter.formatDecimal2Places(entryPayDtl.getPaymentAmt()));
				
				EmBBBPaymentsHeaderVO dispPayHdr = (EmBBBPaymentsHeaderVO)billPaymentsVO.getSearchResults().get(form.getSelectedSearchRow());
				int cnt = billDao.updateBillPaymentDetails(conn, entryPayDtl, dispPayHdr);
				if (cnt == 1) {
					billPaymentsRefresh(conn, sessionHelper, context, form);
					form.setMessage("Updated Successfully.");
				} else {
					form.setHeaderDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
					form.setDetailDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
					billPaymentsDetailSelect(conn, sessionHelper, context, form);
					form.setMessage("Payment Details Update Failed.");
				} 				
			} else {
				billPaymentsDetailSelect(conn, sessionHelper, context, form);
				form.setMessage("Invalid Invoice Id in Payment Details Update.");
			}
									
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	public void updateBillMembPayment(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillMembPaymentsForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		
		EMBillMembPaymentsVO billMembPaymentsVO = context.getBillMembPaymentsVO();
		int selectedRow = form.getSelectedDetailRow();
		List listDetail = billMembPaymentsVO.getListDetail();
		
		if (listDetail != null && listDetail.size() > selectedRow) {
			EmBBBPaymentsDetailVO dispPayDtl = (EmBBBPaymentsDetailVO)listDetail.get(selectedRow);
			EmBBBPaymentsDetailVO entryPayDtl = form.getDisplayPaymentsDetail();
			entryPayDtl.setCustomerId(dispPayDtl.getCustomerId());
			entryPayDtl.setPaySourceType(dispPayDtl.getPaySourceType());
			entryPayDtl.setBatchDate(dispPayDtl.getBatchDate());
			entryPayDtl.setBatchSeqNbr(dispPayDtl.getBatchSeqNbr());
			entryPayDtl.setItemNbr(dispPayDtl.getItemNbr());
			entryPayDtl.setInvoiceId(dispPayDtl.getInvoiceId());
			entryPayDtl.setLastUpdtTime(dispPayDtl.getLastUpdtTime());
			entryPayDtl.setLastUpdtUserId(sessionHelper.getUserId());
			entryPayDtl.setCheckNbr(dispPayDtl.getCheckNbr());
			
			EEMBillDao billDao = new EEMBillDao();
			entryPayDtl.setInvoiceDueDate(DateFormatter.reFormat(entryPayDtl.getInvoiceDueDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			entryPayDtl.setCheckDate(DateFormatter.reFormat(entryPayDtl.getCheckDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
			entryPayDtl.setPaymentAmt(NumberFormatter.formatDecimal2Places(entryPayDtl.getPaymentAmt()));
			
			EmBBBPaymentsHeaderVO payHdrDtl = billDao.getBillPaymentHeader(conn, entryPayDtl.getCustomerId(), entryPayDtl.getPaySourceType(),
																						entryPayDtl.getBatchDate(), entryPayDtl.getBatchSeqNbr());
			if (payHdrDtl != null) {
				int cnt = billDao.updateBillPaymentDetails(conn, entryPayDtl, payHdrDtl);
				if (cnt == 1) {
					billMembPaymentsRefresh(conn, sessionHelper, context, form);
					form.setMessage("Updated Successfully.");
				} else {
					form.setDetailDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
					billMembPaymentsDetailSelect(conn, sessionHelper, context, form);
					form.setMessage("Payment Details Update Failed.");
				} 				
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public void newBillPaymentHeader(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillPaymentsForm form, EmBBBPaymentsHeaderVO headerVO) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMCodeCache cc = EEMCodeCache.getInstance();
		
		if (headerVO == null) {
			headerVO = new EmBBBPaymentsHeaderVO();
			headerVO.setCustomerId(sessionHelper.getMfId());
			headerVO.setPaySourceType(EEMConstants.BILL_PAYSOURCE_MANUAL);
			headerVO.setPaySourceDesc(cc.getDesc(headerVO.getPaySourceType(), cc.getLstPaySource()));
			headerVO.setBatchDate(new DateUtil().getTodaysDate());
			headerVO.setBatchBalanceInd(EEMConstants.VALUE_NO);
			headerVO.setBatchPostedInd(EEMConstants.VALUE_NO);
			
			EEMBillDao billDao = new EEMBillDao();
			String bankAcctCd=billDao.getBankAcctCd(conn,sessionHelper.getMfId(),EEMConstants.BILL_PAYSOURCE_MANUAL);
			headerVO.setBankAcctCd(bankAcctCd);
			
			/* commented as BankAcctCd should be pulled from BBB_ACCT_LOOKUP:BasePlus Hometown defect
			 * 
			 * // Ticket 365990 Fix - Start
			if(("HCF0319").equalsIgnoreCase(headerVO.getCustomerId())){
				headerVO.setBankAcctCd("PNC1");
			}else{
				//TSA Issue -Start
				headerVO.setBankAcctCd("5525");
				//TSA Issue -End
			}
			// Ticket 365990 Fix - End
			 * 
			 * 
			 */		
		}
		
		form.setDisplayPaymentsHeader(headerVO);
		form.setNewPaymentScreen(true);
		form.setNewHeaderDisplayState(EEMConstants.EEM_MBR_SCREEN_EDIT);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public void addBillPaymentDetails(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillPaymentsForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EMBillPaymentsVO billPaymentsVO = context.getBillPaymentsVO();
		int selectedRow = form.getSelectedSearchRow();
		form.setDisplayPaymentsHeader((EmBBBPaymentsHeaderVO)billPaymentsVO.getSearchResults().get(selectedRow));
		form.setNewPaymentScreen(true);
		form.setNewHeaderDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public boolean updateBillPaymentNew(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillPaymentsForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());

    	boolean inTrans = false;
    	boolean origAutoCommit = false;
    	boolean success = false;
		try {
			origAutoCommit = conn.getAutoCommit();
			conn.setAutoCommit(false);
			inTrans = true;
			String message = "";

			// Insert Payment Header
			if (insertPaymentHeader(conn, sessionHelper, context, form)) {
				// Insert Payment details
				if (!insertPaymentDetails(conn, sessionHelper, context, form)) {
					message = "Payment Details Insert Failed.";
					if (!StringUtil.nonNullTrim(form.getMessage()).equals(""))
						message = form.getMessage();
				}				
			} else {
				if (!StringUtil.nonNullTrim(form.getMessage()).equals(""))
					message = form.getMessage();
				else
					message = "Payment Header Insert Failed.";
			}
			
			if (message.equals("")) {
				conn.commit();
				inTrans = false;

				form.setMessage("Updated Successfully.");
				success = true;
			} else {
				form.setMessage(message);
			}
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			form.setMessage("Error during Record Update.");
		}finally {
   			if (inTrans)
   				conn.rollback();
   			conn.setAutoCommit(origAutoCommit);
		}
		
		logger.info(LoggerConstants.methodEndLevel());
		return success;
	}
	
	private boolean insertPaymentHeader(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillPaymentsForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		
		if (form.getNewHeaderDisplayState().equals(EEMConstants.EEM_MBR_SCREEN_VIEW)) {
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}
		
		EmBBBPaymentsHeaderVO headerVO = form.getDisplayPaymentsHeader();
		
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		
		// IFOX-366886 - Start
		String fetchBCIndicator = EEMProfileSettings.getCalendarProfileItem(eemDb, sessionHelper.getMfId(), EEMProfileSettings.BANKCDTB);
		//headerVO.setBankCodeLookupIndicator(fetchBCIndicator);
		// IFOX-366886 - End

		if (headerVO != null) {
			
			EEMBillDao billDao = new EEMBillDao();
			boolean rslt;
			
			if("Y".equalsIgnoreCase(fetchBCIndicator)){
				rslt = billDao.validateGlBankAcctCdForMMO(conn,headerVO.getCustomerId(),headerVO.getBankAcctCd(),headerVO.getBatchDate());
			}else{
				rslt = billDao.validateGlBankAcctCd(conn,headerVO.getCustomerId(),headerVO.getBankAcctCd(),headerVO.getBatchDate());
			}
			
			if (!rslt) {
				form.setMessage("Invalid Bank Account Cd");
				form.setFocusField("eemBillPaymentsForm['displayPaymentsHeader.bankAcctCd']");
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}

			// Insert the record
			headerVO.setCreateUserId(sessionHelper.getUserId());
			headerVO.setLastUpdtUserId(sessionHelper.getUserId());
			headerVO.setBatchBalanceAmt(NumberFormatter.formatDecimal2Places(headerVO.getBatchBalanceAmt()));
			if (billDao.insertBillPaymentHeader(conn, headerVO) == 1) {
				logger.info(LoggerConstants.methodEndLevel());
				return true;
			}
		}
		
		logger.info(LoggerConstants.methodEndLevel());
		return false;
	}
	
	private boolean insertPaymentDetails(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMBillPaymentsForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		
		List lstDetailRow = form.getLstDetailRows();
		if (lstDetailRow == null || lstDetailRow.size() == 0) {
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}
		
		EmBBBPaymentsHeaderVO headerVO = null;
		
		if (form.getNewHeaderDisplayState().equals(EEMConstants.EEM_MBR_SCREEN_VIEW)) {
			EMBillPaymentsVO billPaymentsVO = context.getBillPaymentsVO();
			int selectedRow = form.getSelectedSearchRow();
			headerVO = (EmBBBPaymentsHeaderVO)billPaymentsVO.getSearchResults().get(selectedRow);
		} else {
			headerVO = form.getDisplayPaymentsHeader();
		}
		
		EEMBillDao billDao = new EEMBillDao();
		for (int i = 0; i < lstDetailRow.size(); i++) {
			EmBBBPaymentsDetailVO detailVO = (EmBBBPaymentsDetailVO) lstDetailRow.get(i);
			String invoiceId = StringUtil.nonNullTrim(detailVO.getInvoiceId()); 
			if (!invoiceId.equals("")) {
				// Check Invoice Id
				if (!billDao.checkInvoiceId(conn, headerVO.getCustomerId(), invoiceId)) {
					form.setMessage("Invalid Invoice Id " + detailVO.getInvoiceId());
					break;
				}
				// Insert the record
				detailVO.setCreateUserId(sessionHelper.getUserId());
				detailVO.setLastUpdtUserId(sessionHelper.getUserId());
				detailVO.setCheckDate(DateFormatter.reFormat(detailVO.getCheckDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
				if (billDao.insertBillPaymentDetails(conn, headerVO, detailVO) != 1) {
					logger.info(LoggerConstants.methodEndLevel());
					return false;
				}
			}
		}
		
		// Update Header
		if (StringUtil.nonNullTrim(form.getMessage()).equals("") && 
				billDao.updateHeaderTotalAmount(conn, headerVO, sessionHelper.getUserId()) == 1) {
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}
		
		logger.info(LoggerConstants.methodEndLevel());
		return false;
	}
	

	private boolean validateNumberForDebitAndCreditAdjustment(String valueToBeCompared, String valueLimit,String functionCode){
		logger.info(LoggerConstants.methodStartLevel());
		
		double valueToBeComparedD = Double.parseDouble(valueToBeCompared);
		double valueLimitD = Double.parseDouble(valueLimit);
		
		if(functionCode.equalsIgnoreCase("MCR")){
			if(valueLimitD > 0 && Math.abs(valueToBeComparedD) <= valueLimitD){
				logger.info(LoggerConstants.methodEndLevel());
				return true;
			}else{
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		}else if(functionCode.equalsIgnoreCase("MDR")){
			if(valueLimitD < 0 && valueToBeComparedD <= Math.abs(valueLimitD)){
				logger.info(LoggerConstants.methodEndLevel());
				return true;
			}else{
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		}else{
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}
		
	}
	
	private boolean validateNumberForNSFAdjustment(String valueToBeCompared, String valueLimit){
		logger.info(LoggerConstants.methodStartLevel());
		
		double valueToBeComparedD = Double.parseDouble(valueToBeCompared);
		double valueLimitD = Double.parseDouble(valueLimit);
		if(valueToBeComparedD <= valueLimitD){
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}else{
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}		
	}

	private boolean validateNumberForOtherAdjustment(String valueToBeCompared, String valueLimit){
		logger.info(LoggerConstants.methodStartLevel());
		
		double valueToBeComparedD = Double.parseDouble(valueToBeCompared);
		double valueLimitD = Double.parseDouble(valueLimit);
		if(valueLimitD < 0){
			if(valueToBeComparedD < 0 ){
				if(Math.abs(valueToBeComparedD) <= valueLimitD){
					logger.info(LoggerConstants.methodEndLevel());
					return true;
				}else{
					logger.info(LoggerConstants.methodEndLevel());
					return false;
				}
			}else if(valueToBeComparedD <= Math.abs(valueLimitD)){
				logger.info(LoggerConstants.methodEndLevel());
				return true;
			}else{
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
			
		}else{
			if(valueToBeComparedD < 0){
				if(Math.abs(valueToBeComparedD) <= valueLimitD){
					logger.info(LoggerConstants.methodEndLevel());
					return true;
				}else{
					logger.info(LoggerConstants.methodEndLevel());
					return false;
				}
			}else {  
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
			
		}
		
	}

	private boolean checkExistingAdjustmentsForLineItem(Connection con, EmBBBInvoiceHeaderVO headerVO,EmBBBInvoiceDetailVO detailVO){
		logger.info(LoggerConstants.methodStartLevel());
		
		String invoiceType = headerVO.getInvoiceType();
		String invoiceNumber = headerVO.getInvoiceNbr();
		//String lastItemNumber = prevHeaderVO.getLastItemNbr();
		
		String itemNumber = String.valueOf(detailVO.getItemNbr());
		
		//String itemDescription = prevDetailVO.getItemDesc();
		int existingRecords = 0;
		
		//TBD on additional Number

		
		noOfRecordsForTransfer = new EEMBillDao().getRecordsCount(con,detailVO.getCustomerId(), invoiceNumber, itemNumber);
		
		existingRecords = Integer.parseInt(noOfRecordsForTransfer);
		
		if(existingRecords > 1){
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}else {
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		
/*		if(existingRecords > 1){
			adjustableAmount = new EEMBillDao().getEligibleLineAmount(con,detailVO.getCustomerId(), invoiceType , invoiceNumber, itemNumber);
			valueToBeCompared = Double.parseDouble(adjustableAmount);
		}else{
			adjustableAmount = detailVO.getDetailAmt(); 
			valueToBeCompared = Double.parseDouble(adjustableAmount);
		}
		
		if(existingRecords > 1 && valueToBeCompared > 0){
			return true;
		}else if(existingRecords > 1 && valueToBeCompared < 0){
			return false;
		}else{
			return true;
		}*/
		
	}

	private boolean validateDraftDetails(Connection connection, EmBBBDraftDetailVO draftDetail,EmBBBDraftHeaderVO dispDraftHdr){
		logger.info(LoggerConstants.methodStartLevel());
		boolean draftExists = false;
		String invoiceNumber = draftDetail.getInvoiceNbr();
		draftExists = new EEMBillDao().verifyDraftExists(connection, draftDetail,invoiceNumber);
		logger.info(LoggerConstants.methodEndLevel());
		return draftExists;
	}
	
	private boolean validateMemberDetails(Connection connection, EmBBBDraftDetailVO draftDetail){
		logger.info(LoggerConstants.methodStartLevel());
		boolean memberExists = false;
		String invoiceNumber = draftDetail.getInvoiceNbr();
		memberExists = new EEMBillDao().verifyMemberExists(connection, draftDetail,invoiceNumber);
		logger.info(LoggerConstants.methodEndLevel());
		return memberExists;
	}	
	
	private boolean validateAmountForTransferOrRefundWithHistory(String adjustableAmount, String transferAmount){
		logger.info(LoggerConstants.methodStartLevel());
		
		double adjAmount = Double.parseDouble(adjustableAmount);
		double transAmount = Double.parseDouble(transferAmount);
		
/*		if(adjAmount < 0){
			return false;
		}else if(adjAmount > 0 && transAmount <= adjAmount){
			return true;
		}else{
			return false;
		}
*/	
		boolean isValidAmount = false;

		isValidAmount = validateAmountsWithSigns(adjAmount,transAmount);
		
		if(isValidAmount){
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}else{
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		
	}
	
	private boolean validateAmountForTransferOrRefundWithoutHistory(String adjustableAmount, String transferAmount){
		logger.info(LoggerConstants.methodStartLevel());
		
		double adjAmount = Double.parseDouble(adjustableAmount);
		double transAmount = Double.parseDouble(transferAmount);
		boolean isValidAmount = false;

		isValidAmount = validateAmountsWithSigns(adjAmount,transAmount);
		
		if(isValidAmount){
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}else{
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}

	}
	
	
	private boolean validateAmountsWithSigns(double adjAmount, double transAmount){
		logger.info(LoggerConstants.methodStartLevel());
		
		if(adjAmount < 0 && Math.abs(transAmount) <= Math.abs(adjAmount)){
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}else{
			if(adjAmount > 0 && Math.abs(transAmount) <= adjAmount){
				logger.info(LoggerConstants.methodEndLevel());
				return true;
			}else{
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		}
	}
}

