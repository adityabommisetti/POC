/*
 * Created on Jun 24, 2008
 * 
 * $Id: UserManager.java,v 1.1 2014/06/26 07:54:57 praveen Exp $
 */
package com.ps.mss.manager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.UserService;
import com.ps.mss.exception.ApplicationException;

/**
 * @author rakesh
 *
 */
public class UserManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(UserManager.class);
	
	public static boolean validateSession(String userId, String sessionId, String dbId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		UserService userService = new UserService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return userService.validateSession(userId, sessionId);
	}
}
