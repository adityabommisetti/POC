/*
 * Created on Aug 22, 2007
 *
 */
package com.ps.mss.manager;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.BeneficiaryService;
import com.ps.mss.businesslogic.MCBeneficiaryService;
import com.ps.mss.businesslogic.MCPaymentService;
import com.ps.mss.businesslogic.PaymentService;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.BeneficiaryPymtDetailVO;
import com.ps.mss.model.BeneficiaryPymtDetailVOList;
import com.ps.mss.model.FilterVO;
import com.ps.mss.model.PaymentDashBoardVO;
import com.ps.mss.model.PaymentSummaryVOList;
import com.ps.mss.model.PymtEffDateDetailVO;
import com.ps.mss.model.ReconciliationListVO;

/**
 * 
 * @author deepak
 *
 *
 *This class interact between delegate(PaymentFacadeManager) and persistence layer.
 */
public class MCPaymentManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(MCPaymentManager.class);
	/**
	 * This function call the function of persistence layer
	 * @param searchType : it contains plan/year/month 
	 * @param filterVO : this Vo contain all the criteria to be use in searching.
	 * @param paymentDashBoardStatus
	 * @return
	 * @throws ApplicationException
	 */
	public static PaymentDashBoardVO[] getPlanDashBoard(FilterVO filterVO, Map custPlanMap , String searchType, List paymentDashBoardStatus, String menuName, String dbId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		PaymentService planService = new PaymentService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return planService.getPaymentDashBoard(filterVO, custPlanMap, searchType, paymentDashBoardStatus, menuName);
	}
		
	/**
	 * This method is for getting payment summary for plan/year/month.
	 * @param filterVO
	 * @param searchType
	 * @param custPlanMap
	 * @param dbId
	 * @return
	 * @throws ApplicationException
	 */
	public static PaymentSummaryVOList getPaymentSummary(FilterVO filterVO, String searchType, Map custPlanMap, String dbId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		MCPaymentService planService = new MCPaymentService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return planService.getPaymentSummary(filterVO,searchType,custPlanMap);
	}
	
	/**
	 * @author rakesh
	 * @param filterVO
	 * @param pageName
	 * @param menuName
	 * @param dbId
	 * @return
	 * @throws ApplicationException
	 */
	public static String getSearchCreiteriaHeader(FilterVO filterVO, String pageName, String menuName, String dbId) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		MCPaymentService service = new MCPaymentService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return service.getSearchCreiteriaHeader(filterVO, pageName, menuName);
	}
	
	/**
	 * Function find PaymentDetail for beneficiary base on search criteria.
	 * @param filterVO
	 * @param custPlanMap
	 * @param searchType
	 * @param dbId
	 * @param uiContext
	 * @return
	 * @throws ApplicationException
	 */
	public static BeneficiaryPymtDetailVOList getBeneficiaryPymtDetail(FilterVO filterVO, Map custPlanMap , String searchType, String dbId, List uiContext ) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		MCBeneficiaryService beneficiaryService = new MCBeneficiaryService(dbId);
		Map adjReasonMap = MasterManager.getAdjReasonMap();
		logger.info(LoggerConstants.methodEndLevel());
		return beneficiaryService.getBeneficiaryPymtDetail(filterVO, custPlanMap, searchType, adjReasonMap, uiContext);

	}

	/** 
	 * Function find beneficiary Payment Detail for effective date .
	 * @param filterVO
	 * @param planMap
	 * @param partName
	 * @param activeDataBaseName
	 * @return
	 * @throws ApplicationException
	 */
	public static BeneficiaryPymtDetailVOList getPymtDetail(FilterVO filterVO, Map planMap, String partName, List uiContext,String dbId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		MCBeneficiaryService beneficiaryService = new MCBeneficiaryService(dbId);
		Map adjReasonMap = MasterManager.getAdjReasonMap();
		logger.info(LoggerConstants.methodEndLevel());
		return beneficiaryService.getPymtDetail(filterVO,planMap,partName,adjReasonMap,uiContext);
	}

	/**
	 * <code>pymtEffDateDetail</code> find payment detail on effective Date.
	 * @param filterVO
	 * @param planMap
	 * @param seqNbr
	 * @param pymtType
	 * @param activeDataBaseName
	 * @return
	 * @throws ApplicationException
	 */
	public static PymtEffDateDetailVO getBenePymtDetailByParts(FilterVO filterVO, Map planMap, String dbId, String seqNbr, String pymtType) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		MCBeneficiaryService beneficiaryService = new MCBeneficiaryService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return beneficiaryService.getBenePymtDetailByParts(filterVO, planMap, seqNbr, pymtType);
	}
	
	/**
	 * <code>getReconcilationList</code> find reconciliation detail for beneficiary.
	 * @param filterVO
	 * @param custPlanMapp
	 * @param dbId
	 * @return
	 * @throws ApplicationException
	 */
	public static ReconciliationListVO getReconcilationList(FilterVO filterVO, Map custPlanMapp, String dbId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
	    MCBeneficiaryService service = new MCBeneficiaryService(dbId);
	    logger.info(LoggerConstants.methodEndLevel());
		return service.getReconcilationList(filterVO, custPlanMapp); 
	}

	/**
	 * @param filterVO
	 * @param paymentType
	 * @param searchType
	 * @param planMap
	 * @param activeDataBaseName
	 * @return
	 */
	public static BeneficiaryPymtDetailVO [] getPymtDetailOnEffDate(FilterVO filterVO, Map custPlanMap, String partName, String dbId, String paymentType) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		MCBeneficiaryService service = new MCBeneficiaryService(dbId);
		Map adjReasonMap = MasterManager.getAdjReasonMap();
		logger.info(LoggerConstants.methodEndLevel());
		return service.getPymtDetailOnEffDate(filterVO, custPlanMap, partName, adjReasonMap, paymentType); 
	}
	
}
