package com.ps.mss.manager;

import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ps.mss.model.McaidReconAnomVO;
import com.ps.mss.model.McaidReconContext;
import com.ps.mss.model.McaidReconPaymentVO;
import com.ps.mss.web.forms.McaidReconAnomForm;
import com.ps.mss.web.forms.McaidReconDiscForm;
//import com.ps.mss.web.forms.McaidReconFCLOForm;
import com.ps.mss.web.forms.McaidReconFileForm;
import com.ps.mss.web.forms.McaidReconPaymentForm;
import com.ps.mss.web.helper.SessionHelper;

public abstract class McaidReconAbsManager {
	
	//IFOX-00407694-FCLO/WRTO Changes: start
	public String fcloInitialization(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconDiscForm mcaidFcloForm, HttpServletRequest request){
		return null;
	}
	public String discFcloSearch(Connection conn, SessionHelper sessionHelper, McaidReconContext context,  McaidReconDiscForm mcaidDiscForm, HttpServletRequest request){
		return null;
	}
	//IFOX-00407694-FCLO/WRTO Changes: end
	public abstract String discInitialization(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconDiscForm mcaidDiscForm, HttpServletRequest request);
	public abstract String fileInitialization(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconFileForm mcaidFileForm, HttpServletRequest request);
	public abstract String paymentInitialization(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconPaymentForm mcaidPaymentForm, HttpServletRequest request);
	public abstract String anomalyInitialization(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconAnomForm mcaidAnomForm, HttpServletRequest request);
	public String getMcaidPaymentDashboardByPBP(Connection conn, String mfId, McaidReconPaymentForm mcaidPaymentForm, McaidReconContext context){ return null; }
	
	public String paymentDsbSubMenuSelect(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconPaymentForm mcaidPaymentForm, HttpServletRequest request){
		return null;}
	public String getpaymentSummData(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconPaymentForm mcaidPaymentForm){
		return null;}
	public String getpaymentSummDetails(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconPaymentForm mcaidPaymentForm){
		return null;}
	public String getpaymentSummMedicaids(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconPaymentForm mcaidPaymentForm, String move){
		return null;}	
	
	public String anomDsbSubMenuSelect(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconAnomForm mcaidAnomForm, HttpServletRequest request){
		return null;}
	public String getAnomSummListData(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconAnomForm mcaidAnomForm, String move, String from){
		return move;}
	public String getAnomSummDetailData(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconAnomForm mcaidAnomForm, int selectedRow){
		return null;}
	public String updateAnamolyStatus(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconAnomForm mcaidAnomForm){
		return null;}
	public String getAnomSummDetailsData(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconAnomForm mcaidAnomForm, String move, String from){
		return null;
	}
	
	public String setPaySummDataVOtoForm(McaidReconPaymentForm mcaidPaymentForm, McaidReconPaymentVO paymentVO, String custId){return null;}
	public String setAnomSummDataVOtoForm(McaidReconAnomForm mcaidAnomForm, McaidReconAnomVO anomVO,String custId){return null;}
	/*View Reconcilation - Strat */
	public String getViewReconciliation(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconDiscForm mcaidDiscForm){
		return null;}
	public String getViewReconciliation(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconAnomForm mcaidAnomForm){
		return null;}
	/*View Reconcilation - End */
	public String discDsbSubMenuSelect(Connection conn,SessionHelper sessionHelper, McaidReconContext context,McaidReconDiscForm mcaidDiscForm, HttpServletRequest request){
		return null;}
	public String discDashboardSearch(Connection conn, SessionHelper sessionHelper, McaidReconContext context,  McaidReconDiscForm mcaidDiscForm, HttpServletRequest request){
		return null;
	}
	public String discSummDetailSearch(Connection conn, SessionHelper sessionHelper, McaidReconContext context,  McaidReconDiscForm mcaidDiscForm, HttpServletRequest request){
		return null;
	}
	public String getDiscSummListData(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconDiscForm mcaidDiscForm, String move, String from){
		return move;}
	public String getDiscSummDetailData(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconAnomVO discVO, McaidReconDiscForm mcaidDiscForm, int selectedRow){
		return null;}
	public String getDiscSummDetailsData(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconDiscForm mcaidDiscForm, String move, String from){
		return null;}
	
	
	public String updateDiscStatus(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconDiscForm mcaidDiscForm){
		return null;}
	public String getViewPaymentDetails(Connection conn,SessionHelper sessionHelper, McaidReconContext context,McaidReconDiscForm mcaidDiscForm) {
		return null;}
	public String getViewPaymentDetailsForAnom(Connection conn,SessionHelper sessionHelper, McaidReconContext context,McaidReconAnomForm mcaidAnomForm) {
		return null;}
	public String setDiscAnomSummDataVOToForm(McaidReconAnomVO discAnomVO, McaidReconDiscForm mcaidDiscForm, String custId) { return null;}
	public String getpaymentSearch(Connection conn, SessionHelper sessionHelper,
			McaidReconContext context, McaidReconPaymentForm mcaidPaymentForm) {
				return null;
		// TODO Auto-generated method stub
		
	}
	public String getpaymentDashboardSearch(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconPaymentForm mcaidPaymentForm) { return null;}
	public String printMcaidDisc(Connection conn, SessionHelper sessionHelper, McaidReconContext context, HttpServletRequest request, HttpServletResponse response, McaidReconDiscForm mcaidDiscForm, String printOption, String printSubMenu, String pageRange){
		return null;
	}
	
	public String printMcaidPayment(Connection conn, SessionHelper sessionHelper, McaidReconContext context, HttpServletRequest request, HttpServletResponse response, McaidReconPaymentForm mcaidPaymentForm, String printOption, String printSubMenu, String pageRange){
		return null;
	}
	public String printMcaidAnom(Connection conn, SessionHelper sessionHelper, McaidReconContext context, HttpServletRequest request, HttpServletResponse response, McaidReconAnomForm mcaidAnomForm, String printOption, String printSubMenu, String pageRange){
		return null;
	}
	public String AnomDashboardSearch(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconAnomForm mcaidDiscForm, HttpServletRequest request){
		return null;
	}
	public String anomSummDetailSearch(Connection conn, SessionHelper sessionHelper, McaidReconContext context, McaidReconAnomForm mcaidAnomForm, HttpServletRequest request){
		return null;
	}
	/*public String getMcaidPaymentDashboardByYear(McaidReconPaymentForm mcaidPaymentForm, McaidReconContext context){ return null; } 
	public String getMcaidPaymentDashboardByQuarter(McaidReconPaymentForm mcaidPaymentForm, McaidReconContext context){ return null; } 
	 */
	public String getFileListSearch(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconFileForm mcaidFileForm, String move) {
		// TODO Auto-generated method stub
		return null;
	}
	public String printMcaidFile(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			HttpServletRequest request, HttpServletResponse response, McaidReconFileForm mcaidFileForm,
			String printOption, String printSubMenu, String pageRange) {
		// TODO Auto-generated method stub
		return null;
	}
	// Added for Extract All Records Changes : start
	public String extractAllRecords(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconDiscForm mcaidDiscForm, String string, Object object) {
		// TODO Auto-generated method stub
		return null;
	}
	public String extractAllAnomRecords(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconAnomForm mcaidAnomForm, String string, Object object) {
		// TODO Auto-generated method stub
		return null;
	}
	// Added for Extract All Records Changes : end 
	//IFOX-00407694-FCLO/WRTO Changes: start
	public String updateFcloStatus(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconDiscForm mcaidDiscForm) {
		// TODO Auto-generated method stub
		return null;
	}
	//IFOX-00407694-FCLO/WRTO Changes: end
}//class
