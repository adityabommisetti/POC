package com.ps.mss.manager;

import java.io.PrintStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EEMWorkFlowService;
import com.ps.mss.dao.EEMUserListDao;
import com.ps.mss.dao.model.EEMAssignActivityVO;
import com.ps.mss.dao.model.EEMAtRiskVO;
import com.ps.mss.dao.model.EEMQueCharVO;
import com.ps.mss.dao.model.EEMUserListVO;
import com.ps.mss.dao.model.EMWFSupervisorUserVO;
import com.ps.mss.dao.model.EMWFUsrAgreementVO;
import com.ps.mss.dao.model.EMWFUsrQueueVO;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.model.EEMContext;
import com.ps.mss.model.EEMWorkFLowVO;
import com.ps.mss.model.Pagination;
import com.ps.mss.web.forms.EEMWorkFlowForm;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.util.ListBoxItem;
/*******************************************************************************
 * Functionality Description : new Manager class created for new tab WORK FLOW screen
 * External Objects called :EEMWorkFlowProcess
 * Known Bugs : None * 
 * Modification Log 
 * Creation Date: Nov-2013        
 * Author: Praveen
 
 ******************************************************************************/

public class EEMWorkFlowManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(EEMWorkFlowManager.class);
	/**
	 * Holds PrintStream object
	 */
	PrintStream log;
	
	/**
	 * constructor
	 */
	public EEMWorkFlowManager() {
		this(System.out);
	}
	/** constructor
	 * @param log
	 */
	public EEMWorkFlowManager(PrintStream log) {
		this.log = log;
	}
	
	/**
	 * This method is used for init show user list screen
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void initUserWF(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMWorkFlowForm form){
		logger.info(LoggerConstants.methodStartLevel());
			
		EEMWorkFlowService wfService = new EEMWorkFlowService();
		EEMWorkFLowVO workFlowVO = context.getWorkFlowVO();
		searchOptsNullify(form, workFlowVO);
		workFlowVO.setCustomerID(sessionHelper.getMfId());
		workFlowVO.setUserID(sessionHelper.getUserId());
		//-
		wfService.getUserLevel(conn, workFlowVO);
		form.setUserLevel(workFlowVO.getUserLevel());
		//-
		if(workFlowVO.getUserLevel() != null && !(workFlowVO.getUserLevel().trim().equals(""))){
			if(new Integer(workFlowVO.getUserLevel().trim()).intValue() == 3){//USER
				List supUsrLstBoxLst = new ArrayList();
				ListBoxItem lbi = new ListBoxItem(workFlowVO.getUserID().trim(),workFlowVO.getUserID());
				supUsrLstBoxLst.add(lbi);
				workFlowVO.setUsrsUnderSupListBoxLst(supUsrLstBoxLst);
			}
			else if(new Integer(workFlowVO.getUserLevel().trim()).intValue() == 2){//SUPERVISOR
				wfService.getUsersOfSupervisor(conn, workFlowVO);//get Users of that supervisor.
			}
			else if(new Integer(workFlowVO.getUserLevel().trim()).intValue() == 1){//ADMIN
				wfService.getUsersOfAdmin(conn, workFlowVO);//get Users of that Administrator.
			}
		}else{
			form.setPopupMsg("You are not a WorkFlow user.");
			logger.info(LoggerConstants.methodEndLevel());
			return;
		} 
		form.setUsrsUnderSupListBoxLst(workFlowVO.getUsrsUnderSupListBoxLst());
		workFlowVO.setSuprSelectedUName(workFlowVO.getUserID());
		form.setSuprSelectedUName(workFlowVO.getUserID());
						
		//-
		setUserQueueLst(conn, form, workFlowVO, wfService, workFlowVO.getUserID());
		setUserPriorities(conn, wfService, workFlowVO, form, workFlowVO.getUserID());
		setUserAgreements(conn, wfService, workFlowVO.getUserID(), workFlowVO, form, "first");	
		
		workFlowVO.setUsrLoadedAgrmntsUsrOpt(EEMConstants.EEM_WF_USER_OPT_WFMENU);
		logger.info(LoggerConstants.methodEndLevel());
	}//initUserWF
	/**
	 * This method is used for setUserQueueLst
	 * @param conn holds Connection object
	 * @param form holds EEMWorkFlowForm Object
	 * @param workFlowVO holds EEMWorkFLowVO object
	 * @param wfService holds EEMWorkFlowService object
	 * @param userId holds userId value
	 */
	private void setUserQueueLst(Connection conn, EEMWorkFlowForm form, EEMWorkFLowVO workFlowVO, 
			EEMWorkFlowService wfService, String userId){	
		logger.info(LoggerConstants.methodStartLevel());
		
		wfService.getUserQueueList(conn, workFlowVO, userId);//for UI Queue dropdown box.
		form.setWfUserQLst(workFlowVO.getWfUserQLst());
		logger.info(LoggerConstants.methodEndLevel());
	}//getUsrWork()	
	/**
	 * This method is used for setUserPriorities
	 * @param conn holds Connection object
	 * @param form holds EEMWorkFlowForm Object
	 * @param workFlowVO holds EEMWorkFLowVO object
	 * @param wfService holds EEMWorkFlowService object
	 * @param userId holds userId value
	 */
	private void setUserPriorities(Connection conn, EEMWorkFlowService wfService, 
			EEMWorkFLowVO workFlowVO, EEMWorkFlowForm form, String usrId){
		logger.info(LoggerConstants.methodStartLevel());
		
		wfService.getUsrPriorityLst(conn, workFlowVO, usrId);
		form.setUsrQPrity0Lst(workFlowVO.getUsrQPrity0Lst());//Temp Priority
		form.setUsrQPrity1Lst(workFlowVO.getUsrQPrity1Lst());
		form.setUsrQPrity2Lst(workFlowVO.getUsrQPrity2Lst());
		form.setUsrQPrity3Lst(workFlowVO.getUsrQPrity3Lst());
		form.setUsrQPrity4Lst(workFlowVO.getUsrQPrity4Lst());
		form.setUsrQPrity5Lst(workFlowVO.getUsrQPrity5Lst());//Other / deallocated queues
		logger.info(LoggerConstants.methodEndLevel());
	}
	/**
	 * This method is used for setUserPriorities
	 * @param conn holds Connection object
	 * @param form holds EEMWorkFlowForm Object
	 * @param workFlowVO holds EEMWorkFLowVO object
	 * @param wfService holds EEMWorkFlowService object
	 * @param userId holds userId value
	 * @param move holds move value
	 */
	private void setUserAgreements(Connection conn, EEMWorkFlowService wfService, String usr, 
			EEMWorkFLowVO workFlowVO, EEMWorkFlowForm form, String move){
		logger.info(LoggerConstants.methodStartLevel());
		
		wfService.getUsrBasedAgrLst(conn, workFlowVO, usr, move);
		form.setUsrAgreementsLst(workFlowVO.getUsrAgreementsLst());
		form.setUsrAgrmntLstPageNbr(workFlowVO.getUsrAgrmntLstPageNbr());
		form.setUsrAgrLstCurrPageType(workFlowVO.getUsrAgrLstCurrPageType());
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	//executes when clicked on GO.
	/**
	 * This method is used for setUserPriorities
	 * @param context holds Connection EEMContext
	 * @param form holds EEMWorkFlowForm Object
	 * @param workFlowVO holds EEMWorkFLowVO object	 
	 * @param move holds move value
	 */
	public void getSuprSelUsrData(Connection conn, EEMContext context, EEMWorkFLowVO workFlowVO, 
			EEMWorkFlowForm form, String move){
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService wfService = new EEMWorkFlowService();
		workFlowVO.setSuprSelectedUName(form.getSuprSelectedUName());
				
		setUserQueueLst(conn, form, workFlowVO, wfService, workFlowVO.getSuprSelectedUName());
		setUserPriorities(conn, wfService, workFlowVO, form, workFlowVO.getSuprSelectedUName());
		setUserAgreements(conn, wfService, workFlowVO.getSuprSelectedUName(), workFlowVO, form, move);
		workFlowVO.setUsrLoadedAgrmntsUsrOpt(EEMConstants.EEM_WF_USER_OPT_GO);
		logger.info(LoggerConstants.methodEndLevel());
	}//getSuprSelUsrData()
			
	/**
	* This method is used to getUsrSubsetAgreements
	* @param conn holds Connection object	
	* @param context holds EEMContext object
	* @param form holds EEMWorkFlowForm object
	* @param move holds String value
	*/
	public void getUsrSubsetAgreements(Connection conn, EEMContext context, EEMWorkFlowForm form,
			String move){
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService wfService = new EEMWorkFlowService();
		EEMWorkFLowVO workFlowVO = context.getWorkFlowVO();
		workFlowVO.setSuprSelectedUName(form.getSuprSelectedUName());
		
		wfService.getSubSetActsAgrLst(conn, workFlowVO, form.getSuprSelectedUName(), move);		
		form.setUsrAgreementsLst(workFlowVO.getUsrAgreementsLst());
		form.setUsrAgrmntLstPageNbr(workFlowVO.getUsrAgrmntLstPageNbr());
		form.setUsrAgrLstCurrPageType(workFlowVO.getUsrAgrLstCurrPageType());		
		workFlowVO.setUsrLoadedAgrmntsUsrOpt(EEMConstants.EEM_WF_USER_OPT_SUBSETACTIVITIES);
		logger.info(LoggerConstants.methodEndLevel());
	}//getUsrSubsetActivities()
	/**
	* This method is used to getUserPrioritiesData
	* @param conn holds Connection object	
	* @param form holds EEMWorkFlowForm object
	* @param move holds String value
	*/
	public void getUserPrioritiesData(Connection conn, EEMWorkFlowForm form, EEMWorkFLowVO workFlowVO ){
		logger.info(LoggerConstants.methodStartLevel());
		EEMWorkFlowService wfService = new EEMWorkFlowService();
		setUserPriorities(conn, wfService, workFlowVO, form, workFlowVO.getSuprSelectedUName());	
		setUserQueueLst(conn, form, workFlowVO, wfService, workFlowVO.getSuprSelectedUName());
		logger.info(LoggerConstants.methodEndLevel());
	}//getUserPrioritiesData()
	
	/**
	* This method is used to getGWMenuAgrPagination
	* @param conn holds Connection object	
	* @param context holds EEMContext object
	* @param form holds EEMWorkFlowForm object
	* @param move holds String value
	*/
	public void getGWMenuAgrPagination(Connection conn, EEMContext context, EEMWorkFlowForm form, String move){
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService wfService = new EEMWorkFlowService();
		EEMWorkFLowVO workFlowVO = context.getWorkFlowVO();
		setUserAgreements(conn, wfService, workFlowVO.getUserID(), workFlowVO, form, move);
		logger.info(LoggerConstants.methodEndLevel());
	}//getGWMenuAgrPagination()
	
	/**
	* This method is used to getGWMenuAgrPagination
	* @param conn holds Connection object	
	* @param context holds EEMContext object
	* @param form holds EEMWorkFlowForm object
	* @param move holds String value
	*/
	
	public void getGoOptAgrPagination(Connection conn, EEMContext context, EEMWorkFlowForm form, String move){
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService wfService = new EEMWorkFlowService();
		EEMWorkFLowVO workFlowVO = context.getWorkFlowVO();	
		setUserAgreements(conn, wfService, workFlowVO.getUsrLoadedAgrmntsUName(), workFlowVO, form, move);
		logger.info(LoggerConstants.methodEndLevel());
	}//getGoOptAgrPagination()
	
	/**
	* This method is used to getGWMenuAgrPagination
	* @param conn holds Connection object	
	* @param context holds EEMContext object
	* @param form holds EEMWorkFlowForm object
	* @param move holds String value
	*/
	
	public void getSsActAgrPagination(Connection conn, EEMContext context, EEMWorkFlowForm form, String move){
		logger.info(LoggerConstants.methodStartLevel());
		EEMWorkFlowService wfService = new EEMWorkFlowService();
		EEMWorkFLowVO workFlowVO = context.getWorkFlowVO();
		
		wfService.getSubSetActsAgrLst(conn, workFlowVO, workFlowVO.getUsrLoadedAgrmntsUName(), move);		
		form.setUsrAgreementsLst(workFlowVO.getUsrAgreementsLst());
		form.setUsrAgrmntLstPageNbr(workFlowVO.getUsrAgrmntLstPageNbr());
		form.setUsrAgrLstCurrPageType(workFlowVO.getUsrAgrLstCurrPageType());
		logger.info(LoggerConstants.methodEndLevel());
	}//getSsActAgrPagination()
	
		
	/**
	 * This method is used to get user work
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @param move holds String value
	 */
	public void getUsrWork(Connection conn, SessionHelper sessionHelper, EEMContext context,
			EEMWorkFlowForm form, String move){
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService wfService = new EEMWorkFlowService();
		EEMWorkFLowVO workFlowVO = context.getWorkFlowVO();
		//--
		wfService.getUsrWorkAgreement(conn, workFlowVO, move);	//move=first
		workFlowVO.setUsrAgrmntLstPageNbr(1);
		workFlowVO.setUsrAgrLstCurrPageType("LAST");
		workFlowVO.setSuprSelectedUName(workFlowVO.getUserID());
		form.setUsrAgrmntLstPageNbr(workFlowVO.getUsrAgrmntLstPageNbr());
		form.setUsrAgrLstCurrPageType(workFlowVO.getUsrAgrLstCurrPageType());
		if(workFlowVO.getUsrAgreementsLst() == null || workFlowVO.getUsrAgreementsLst().size() == 0){
			form.setPopupMsg("No Activities to assign work, Please contact supervisor.");
		}else{
			form.setUsrAgreementsLst(workFlowVO.getUsrAgreementsLst());
		}	
		logger.info(LoggerConstants.methodEndLevel());
	}//getUsrWork()
	
	
	/**
	 * This method is used to get user queue based on search
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @param move holds String value
	 */
	public void getUserGWQueueSearch(Connection conn, SessionHelper sessionHelper, EEMContext context,
			EEMWorkFlowForm form, String move){
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService wfService = new EEMWorkFlowService();
		EEMWorkFLowVO workFlowVO = context.getWorkFlowVO();
		//--
		wfService.getUsrGWQueues(conn, workFlowVO, move);	//move=first	
		form.setUsrQueuesLst(workFlowVO.getUsrQueuesLst());
		setAgrmntSelectFromLst(workFlowVO);//To display Selected Agreement row in UI.
		logger.info(LoggerConstants.methodEndLevel());
	}//getUserGWQueueSearch()
	
	/**
	 * This method used to get selected agreement from list
	 * @param holds workFlowVO object
	 */
	@SuppressWarnings("rawtypes")
	private void setAgrmntSelectFromLst(EEMWorkFLowVO workFlowVO ){
		logger.info(LoggerConstants.methodStartLevel());
		List usrAgreementsLst = workFlowVO.getUsrAgreementsLst();
		Iterator iter = usrAgreementsLst.iterator();
		while(iter.hasNext()){
			EMWFUsrAgreementVO agreementVO = (EMWFUsrAgreementVO)iter.next();
			if(workFlowVO.getUserAgreementId() == agreementVO.getAgreementID()){
				agreementVO.setRowSelected("Y");
			}else{
				agreementVO.setRowSelected("");
			}
		}//while	
		logger.info(LoggerConstants.methodEndLevel());
	}//setAgrmntLstSelect()
	
	/**
	 * This method is used to get user activites based on search 
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @param move holds String value
	 */
	public void getUserGWActivitySearch(Connection conn, SessionHelper sessionHelper, EEMContext context,
			EEMWorkFlowForm form, String move){
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService wfService = new EEMWorkFlowService();
		EEMWorkFLowVO workFlowVO = context.getWorkFlowVO();
		//--
		wfService.getUsrGWActivities(conn, workFlowVO, move);	//move=first	
		form.setUsrActivitiesLst(workFlowVO.getUsrActivitiesLst());
		setQueueSelectFromLst(workFlowVO);
		logger.info(LoggerConstants.methodEndLevel());
	}//getUserGWQueueSearch()
	
	/**
	 * This method is used to get selected queue from list
	 * @param holds workFlowVO object
	 */
	@SuppressWarnings("rawtypes")
	private void setQueueSelectFromLst(EEMWorkFLowVO workFlowVO ){
		logger.info(LoggerConstants.methodStartLevel());
		List usrQueuesLst = workFlowVO.getUsrQueuesLst();
		Iterator iter = usrQueuesLst.iterator();
		while(iter.hasNext()){
			EMWFUsrQueueVO queVO = (EMWFUsrQueueVO)iter.next();
			if(workFlowVO.getUserQueueId() == queVO.getQueueID()){
				queVO.setRowSelected("Y");
			}else{
				queVO.setRowSelected("");
			}
		}//while
		logger.info(LoggerConstants.methodEndLevel());
	}//setAgrmntLstSelect()
	

	/**
	 * This method is used to clear the lists in form and VO
	 * @param form holds EEMWorkFlowForm object
	 * @param workFlowVO holds EEMWorkFLowVO object
	 */
	private void searchOptsNullify(EEMWorkFlowForm form, EEMWorkFLowVO workFlowVO){
		logger.info(LoggerConstants.methodStartLevel());
		form.setUsrGetWrkQName(null);
		form.setUsrGetWrkQPrty(null);
		form.setUsrGetWrkQSrc(null);
		form.setUsrGetWrkQStatus(null);
		workFlowVO.setUsrGetWrkQName(null);
		workFlowVO.setUsrGetWrkQPrty(null);
		workFlowVO.setUsrGetWrkQSrc(null);
		workFlowVO.setUsrGetWrkQStatus(null);	
		logger.info(LoggerConstants.methodEndLevel());
	}//searchOptsNullify
	/**
	* This method is used to getGWMenuAgrPagination
	* @param conn holds Connection object	
	* @param context holds EEMContext object
	* @param form holds EEMWorkFlowForm object
	* @param move holds String value
	*/
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void getAdminHistoryDetails(Connection conn, EEMWorkFlowForm eemWFForm, EEMWorkFLowVO workFlowVO,
			String move){
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService wfService = new EEMWorkFlowService();
		wfService.getAdminHistDetailsLst(conn, workFlowVO, move);	
		
		eemWFForm.setAdminHistDetailsPageNbr(workFlowVO.getAdminHistDetailsPageNbr());
		eemWFForm.setAdminHistDetailsCurrPageType(workFlowVO.getAdminHistDetailsCurrPageType());
		
		eemWFForm.setAdminHistDetailLst(workFlowVO.getAdminHistDetailLst());
			
		
		//--
		if(workFlowVO.getAdminHistSuprvs() != null && workFlowVO.getAdminHistUsrs() != null){
		List suprvLst = new ArrayList();
		List usrLst = new ArrayList();
		ListBoxItem lbi = null;
		String val = null;
		String[] valArray = null;
		
			Iterator itr = workFlowVO.getAdminHistSuprvs().iterator();		
		while(itr.hasNext()){
			val = itr.next().toString();
			valArray = val.split(":");
			lbi = new ListBoxItem(valArray[0], valArray[1]);
			suprvLst.add(lbi);
		}
			eemWFForm.setAdminHistSuprvs(suprvLst);
		
			itr = workFlowVO.getAdminHistUsrs().iterator();		
		while(itr.hasNext()){
			val = itr.next().toString();
			valArray = val.split(":");
			lbi = new ListBoxItem(valArray[0], valArray[1]);
			usrLst.add(lbi);
		}
			eemWFForm.setAdminHistUsrs(usrLst);
		}//if
		logger.info(LoggerConstants.methodEndLevel());
	}//getAdminHistoryDetails
	
	//----------------------
	
	
	/**
	 * 045_HighMark_Queue Characteristics Start
	 */
	
	/**
	 * This method used for que char init
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 */
	public void initQueChar(Connection conn, SessionHelper sessionHelper,
			EEMContext context, EEMWorkFlowForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();	
		EEMWorkFLowVO eemWorkFlowVO = context.getWorkFlowVO();
	    boolean rslt = false;
	   
	    Pagination pagination = null;
	    pagination = context.getEnrollEnrollPagination();
	    rslt = eemWorkFlowService.queCharSelect(conn, eemWorkFlowVO);	       
		form.setSelectedQueCharInfoRow(0);
		form.setListQueCharInfosWithDisplay(eemWorkFlowVO.getListQueCharInfos());		
		form.setQueCharChanged(false);
		form.setQueCharInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setQueSupervisorInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		form.setTopDisplayQueCharInfoRow(0);
		pagination = context.getQueCharPagination();		
		pagination.setListPaginationResults("first",eemWorkFlowVO.getListQueCharInfos());
		
		if(rslt){	
			EEMQueCharVO queCharVoObj = (EEMQueCharVO) eemWorkFlowVO.getListQueCharInfos().get(0);
			form.setDisplayQueCharInfo(queCharVoObj);
			form.setSelectedQueCharInfoRow(0);
			form.setQueCharChanged(false);
			form.setQueCharInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);

			pagination.setPageToDisplayRow(0,eemWorkFlowVO.getListQueCharInfos());
			Integer topRow = (Integer)pagination.getFirstDetail();						
			form.setTopDisplayQueCharInfoRow(topRow.intValue());
			form.setTopDisplayQueSupervisorInfoRow(topRow.intValue());
		}	
		logger.info(LoggerConstants.methodEndLevel());
	}	
	
	/**
	 * 045_HighMark_Queue Characteristics Start
	 */
	
	
	/* Highmark 045 Workflow Iteration-2 change ends   */
	
	/**
	 * This method is used get list of queues.
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 */
	public void getSuperviosrQueses(Connection conn, SessionHelper sessionHelper,
			EEMContext context, EEMWorkFlowForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();	
		EEMWorkFLowVO eemWorkFlowVO = context.getWorkFlowVO();
	    boolean rslt = false;
	  
	    Pagination pagination = null;
	    
	    rslt = eemWorkFlowService.getSupervisorQueues(conn, eemWorkFlowVO);	       
		form.setSelectedQueSupervisorInfoRow(0);	
		form.setTopDisplayQueSupervisorInfoRow(0);
		pagination = context.getQueSupervisorPagination();		
		pagination.setListPaginationResults("first",eemWorkFlowVO.getListSupervisorQueueInfos());
		
		if(rslt){	
			form.setSelectedQueSupervisorInfoRow(0);
			pagination.setPageToDisplayRow(0,eemWorkFlowVO.getListSupervisorQueueInfos());
			Integer topRow = (Integer)pagination.getFirstDetail();						
			form.setTopDisplayQueSupervisorInfoRow(topRow.intValue());
		}	
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	/**
	 * This method is used get list of queues.
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 */
	public void getAdminSupervisorQueses(Connection conn, SessionHelper sessionHelper,
			EEMContext context, EEMWorkFlowForm form, String userId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();	
		EEMWorkFLowVO eemWorkFlowVO = context.getWorkFlowVO();
	    boolean rslt = false;
	  
	    Pagination pagination = null;
	    
	    rslt = eemWorkFlowService.getAdminSupervisorQueues(conn, eemWorkFlowVO, userId);	       
		form.setSelectedQueSupervisorInfoRow(0);	
		form.setTopDisplayQueSupervisorInfoRow(0);
		pagination = context.getQueSupervisorPagination();		
		pagination.setListPaginationResults("first",eemWorkFlowVO.getListSupervisorQueueInfos());
		
		if(rslt){	
			form.setSelectedQueSupervisorInfoRow(0);
			pagination.setPageToDisplayRow(0,eemWorkFlowVO.getListSupervisorQueueInfos());
			Integer topRow = (Integer)pagination.getFirstDetail();						
			form.setTopDisplayQueSupervisorInfoRow(topRow.intValue());
		}	
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	
	/**
	 * This method is used get list of queues.
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 */
	public void getSuperviosrQuesesAndUpdateTotals(Connection conn, SessionHelper sessionHelper,
			EEMContext context, EEMWorkFlowForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();	
		EEMWorkFLowVO eemWorkFlowVO = context.getWorkFlowVO();
	    boolean rslt = false;
	  
	    Pagination pagination = null;
	    
	    rslt = eemWorkFlowService.getSuperviosrQuesesAndUpdateTotals(conn, eemWorkFlowVO);	       
		form.setSelectedQueSupervisorInfoRow(0);	
		form.setTopDisplayQueSupervisorInfoRow(0);
		pagination = context.getQueSupervisorPagination();		
		pagination.setListPaginationResults("first",eemWorkFlowVO.getListSupervisorQueueInfos());
		
		if(rslt){	
			form.setSelectedQueSupervisorInfoRow(0);
			pagination.setPageToDisplayRow(0,eemWorkFlowVO.getListSupervisorQueueInfos());
			Integer topRow = (Integer)pagination.getFirstDetail();						
			form.setTopDisplayQueSupervisorInfoRow(topRow.intValue());
		}	
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	
	/**
	 * This method is used get list of queues.
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 */
	public void getAdminSuperviosrQuesesAndUpdateTotals(Connection conn, SessionHelper sessionHelper,
			EEMContext context, EEMWorkFlowForm form, String userId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();	
		EEMWorkFLowVO eemWorkFlowVO = context.getWorkFlowVO();
	    boolean rslt = false;
	  
	    Pagination pagination = null;
	    
	    rslt = eemWorkFlowService.getAdminSuperviosrQuesesAndUpdateTotals(conn, eemWorkFlowVO, userId);	       
		form.setSelectedQueSupervisorInfoRow(0);	
		form.setTopDisplayQueSupervisorInfoRow(0);
		pagination = context.getQueSupervisorPagination();		
		pagination.setListPaginationResults("first",eemWorkFlowVO.getListSupervisorQueueInfos());
		
		if(rslt){	
			form.setSelectedQueSupervisorInfoRow(0);
			pagination.setPageToDisplayRow(0,eemWorkFlowVO.getListSupervisorQueueInfos());
			Integer topRow = (Integer)pagination.getFirstDetail();						
			form.setTopDisplayQueSupervisorInfoRow(topRow.intValue());
		}	
		logger.info(LoggerConstants.methodEndLevel());
	}	
	
	/**
	 * This method is used to get Users.
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 */
	public void getSuperviosrUsers(Connection conn, SessionHelper sessionHelper,
			EEMContext context, EEMWorkFlowForm form, String queueCode) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();	
		EEMWorkFLowVO eemWorkFlowVO = context.getWorkFlowVO();
		eemWorkFlowVO.setCustomerID(sessionHelper.getMfId());
		eemWorkFlowVO.setUserID(sessionHelper.getUserId());
	    boolean rslt = false;
	  
	    Pagination pagination = null;
	    
	    rslt = eemWorkFlowService.getSupervisorUsers(conn, eemWorkFlowVO, queueCode);	
	    form.setSelectedUsrSupervisorInfoRow(0);	
		form.setTopDisplayUsrSupervisorInfoRow(0);
	    form.setListSupervisorUserInfosWithDisplay(eemWorkFlowVO.getListSupervisorUserInfos());
		form.setSupervisorUserChanged(false);
		form.setUserSupervisorInfoDisplayState(EEMConstants.EEM_SCREEN_VIEW);
		pagination = context.getUserSupervisorPagination();		
		pagination.setListPaginationResults("first",eemWorkFlowVO.getListSupervisorUserInfos());
		
		if(rslt){	
			
			EMWFSupervisorUserVO supervisorUserVO = (EMWFSupervisorUserVO) eemWorkFlowVO.getListSupervisorUserInfos().get(0);
			form.setDisplaySupervisorUserInfo(supervisorUserVO);
			form.setSelectedUsrSupervisorInfoRow(0);
			form.setSupervisorUserChanged(false);
			form.setUserSupervisorInfoDisplayState(EEMConstants.EEM_SCREEN_VIEW);
			pagination.setPageToDisplayRow(0,eemWorkFlowVO.getListSupervisorUserInfos());
			Integer topRow = (Integer)pagination.getFirstDetail();						
			form.setTopDisplayUsrSupervisorInfoRow(topRow.intValue());
		}	
		logger.info(LoggerConstants.methodEndLevel());
	}	
	
	
	/**
	 * This method is used to get Users.
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 */
	public void getAdminSuperviosrUsers(Connection conn, SessionHelper sessionHelper,
			EEMContext context, EEMWorkFlowForm form, String queueCode, String userId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();	
		EEMWorkFLowVO eemWorkFlowVO = context.getWorkFlowVO();
		eemWorkFlowVO.setCustomerID(sessionHelper.getMfId());
		eemWorkFlowVO.setUserID(sessionHelper.getUserId());
	    boolean rslt = false;
	  
	    Pagination pagination = null;
	    
	    rslt = eemWorkFlowService.getAdminSupervisorUsers(conn, eemWorkFlowVO, queueCode, userId);	
	    
	    form.setTopDisplayUsrSupervisorInfoRow(0);
	    form.setSelectedUsrSupervisorInfoRow(0);
	    form.setListSupervisorUserInfosWithDisplay(eemWorkFlowVO.getListSupervisorUserInfos());
	   	
		
		form.setSupervisorUserChanged(false);
		form.setUserSupervisorInfoDisplayState(EEMConstants.EEM_SCREEN_VIEW);
		pagination = context.getUserSupervisorPagination();		
		pagination.setListPaginationResults("first",eemWorkFlowVO.getListSupervisorUserInfos());
		
		if(rslt){	
			
			EMWFSupervisorUserVO supervisorUserVO = (EMWFSupervisorUserVO) eemWorkFlowVO.getListSupervisorUserInfos().get(0);
			form.setDisplaySupervisorUserInfo(supervisorUserVO);
			form.setSelectedUsrSupervisorInfoRow(0);
			form.setSupervisorUserChanged(false);
			form.setUserSupervisorInfoDisplayState(EEMConstants.EEM_SCREEN_VIEW);
			pagination.setPageToDisplayRow(0,eemWorkFlowVO.getListSupervisorUserInfos());
			Integer topRow = (Integer)pagination.getFirstDetail();						
			form.setTopDisplayUsrSupervisorInfoRow(topRow.intValue());
		}	
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	/**
	 * This method is used to update user info.
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 */
	public void supervisorUserInfoUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, 
			EEMWorkFlowForm form, String queueCode) throws ApplicationException  {
		logger.info(LoggerConstants.methodStartLevel());
		
		String supervisorId = sessionHelper.getUserId();
		String customerId = sessionHelper.getMfId();
		EMWFSupervisorUserVO supervisorUserVO = form.getDisplaySupervisorUserInfo();
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();	
		boolean rslt = false;
		EEMWorkFLowVO eemWorkFlowVO = context.getWorkFlowVO();
		
		if(supervisorUserVO!=null){	

        	rslt = eemWorkFlowService.supervisorUserInfoUpdate(conn, eemWorkFlowVO, 
        			supervisorUserVO, supervisorId, customerId, queueCode);
		}
    	
		if(rslt){	

			
			form.setListSupervisorUserInfosWithDisplay(eemWorkFlowVO.getListSupervisorUserInfos());
			form.setMessage("Supervisor User Update Success");
		}
		if (rslt == false) {
			form.setListSupervisorUserInfosWithDisplay(eemWorkFlowVO.getListSupervisorUserInfos());
			form.setMessage("Supervisor User Update Success");
		}
		logger.info(LoggerConstants.methodEndLevel());
	 }	
	/**
	 * This method is used to update user info.
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 */
	public void adminSupervisorUserInfoUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, 
			EEMWorkFlowForm form, String queueCode, String userId) throws ApplicationException  {
		logger.info(LoggerConstants.methodStartLevel());
		
		
		String customerId = sessionHelper.getMfId();
		EMWFSupervisorUserVO supervisorUserVO = form.getDisplaySupervisorUserInfo();
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();	
		boolean rslt = false;
		EEMWorkFLowVO eemWorkFlowVO = context.getWorkFlowVO();
		
		if(supervisorUserVO!=null){	

        	rslt = eemWorkFlowService.supervisorUserInfoUpdate(conn, eemWorkFlowVO, 
        			supervisorUserVO, userId, customerId, queueCode);
		}
    	
		if(rslt){	

			
			form.setListSupervisorUserInfosWithDisplay(eemWorkFlowVO.getListSupervisorUserInfos());
			form.setMessage("Supervisor User Update Success");
		}
		if (rslt == false) {
			form.setListSupervisorUserInfosWithDisplay(eemWorkFlowVO.getListSupervisorUserInfos());
			form.setMessage("Supervisor User Update Success");
		}
		logger.info(LoggerConstants.methodEndLevel());
	 }	
	/**
	 * This method is used to update user info.
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 */
	public void addNewUser(Connection conn, SessionHelper sessionHelper, EEMContext context, 
			EEMWorkFlowForm form) throws ApplicationException  {
		logger.info(LoggerConstants.methodStartLevel());
		
		String adminId = sessionHelper.getUserId();
		String customerId = sessionHelper.getMfId();
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();	
		boolean rslt = false;
		
		if(form !=null && null != form.getAddType() && null != form.getSelectedUserId() && null != form.getSelectedManagerId()){	
			//Excellus Retro fix for workflow -Start
        	/*rslt = eemWorkFlowService.addNewUser(conn, form.getAddType(), 
        			form.getSelectedUserId(), form.getSelectedManagerId(),  adminId, customerId);*/
			try{
				if(form.getAddType().equalsIgnoreCase("supervisor")){
						rslt = eemWorkFlowService.addNewUser(conn, form.getAddType(), form.getSelectedUserId()[1], form.getSelectedManagerId()[1],  adminId, customerId);
				}else{
						rslt = eemWorkFlowService.addNewUser(conn, form.getAddType(), form.getSelectedUserId()[0], form.getSelectedManagerId()[0],  adminId, customerId);
				}
			}catch(Exception e){
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("Could be Array problem with SelectedUserId()[] and getSelectedManagerId()[]");
			}
			//Excellus Retro fix for workflow -End
		}
    	
		if(rslt){	
			form.setMessage("New User Update Success");
		}
		if (rslt == false) {
			
			form.setMessage("New User Update Failed");
		}
		logger.info(LoggerConstants.methodEndLevel());
	 }
	
	
	/**
	 * This method is used to reassignSupervisorUser
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 */
	public void reassignSupervisorUser(Connection conn, SessionHelper sessionHelper, EEMContext context, 
			EEMWorkFlowForm form, String queueCode) throws ApplicationException  {
		logger.info(LoggerConstants.methodStartLevel());
		
		String supervisorId = sessionHelper.getUserId();
		String customerId = sessionHelper.getMfId();
		EMWFSupervisorUserVO supervisorUserVO = form.getDisplaySupervisorUserInfo();
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();	
		boolean rslt = false;
		EEMWorkFLowVO eemWorkFlowVO = context.getWorkFlowVO();
		
		if(supervisorUserVO!=null){	

        	rslt = eemWorkFlowService.reassignSupervisorUser(conn, eemWorkFlowVO, 
        			supervisorUserVO, supervisorId, customerId, queueCode);
		}
    	
		if(rslt){	

			
			form.setListSupervisorUserInfosWithDisplay(eemWorkFlowVO.getListSupervisorUserInfos());
			form.setMessage("Supervisor User Update Success");
		}
		if (rslt == false) {
			form.setListSupervisorUserInfosWithDisplay(eemWorkFlowVO.getListSupervisorUserInfos());
			form.setMessage("Supervisor User Update Success");
		}
		logger.info(LoggerConstants.methodEndLevel());
	 }
	
	

	/**
	 * This method is used to reassignSupervisorUser
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 */
	public void reassignAdminSupervisorUser(Connection conn, SessionHelper sessionHelper, EEMContext context, 
			EEMWorkFlowForm form, String queueCode, String userId) throws ApplicationException  {
		logger.info(LoggerConstants.methodStartLevel());
		
		String customerId = sessionHelper.getMfId();
		EMWFSupervisorUserVO supervisorUserVO = form.getDisplaySupervisorUserInfo();
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();	
		boolean rslt = false;
		EEMWorkFLowVO eemWorkFlowVO = context.getWorkFlowVO();
		
		if(supervisorUserVO!=null){	

        	rslt = eemWorkFlowService.reassignSupervisorUser(conn, eemWorkFlowVO, 
        			supervisorUserVO, userId, customerId, queueCode);
		}
    	
		if(rslt){	

			
			form.setListSupervisorUserInfosWithDisplay(eemWorkFlowVO.getListSupervisorUserInfos());
			form.setMessage("Supervisor User Update Success");
		}
		/*if (rslt == false) {
			form.setListSupervisorUserInfosWithDisplay(eemWorkFlowVO.getListSupervisorUserInfos());
			form.setMessage("Supervisor User Update Success");
		}*/
		logger.info(LoggerConstants.methodEndLevel());
	 }
	
	/* Highmark 045 Workflow Iteration-2 change ends   */
	
	
	/**
	 * This method is used to update queue char info
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 */
	public void queCharUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, 
			EEMWorkFlowForm form) throws ApplicationException  {
		logger.info(LoggerConstants.methodStartLevel());
		
		String userId = sessionHelper.getUserId();
		
		EEMQueCharVO queCharVO = form.getDisplayQueCharInfo();
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();	
		boolean rslt = false;
		EEMWorkFLowVO eemWorkFlowVO = context.getWorkFlowVO();
		
		if(queCharVO!=null){	

        	rslt = eemWorkFlowService.queCharInfoUpdate(conn, eemWorkFlowVO, 
        			queCharVO, userId);
		}
    	
		if(rslt){			
			form.setListQueCharInfosWithDisplay(eemWorkFlowVO.getListQueCharInfos());			
			form.setPopupMsg("Update Success");
		}
		if (rslt == false) {
			form.setListQueCharInfosWithDisplay(eemWorkFlowVO.getListQueCharInfos());			
			form.setPopupMsg("Update Failed");
		}
		logger.info(LoggerConstants.methodEndLevel());
	 }
	/**
	 * 045_HighMark_Queue Characteristics End
	 */
	/**
	 * 045_UserList start
	 */
	/**
	 * This method used to init show user list
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 */
	public void initUserList(Connection conn, SessionHelper sessionHelper,
			EEMContext context, EEMWorkFlowForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();	
		 boolean rslt = false;		
		EEMWorkFLowVO eemWorkFlowVO = context.getWorkFlowVO();
		eemWorkFlowVO.setFirstName(form.getFirstName());
		eemWorkFlowVO.setLastName(form.getLastName());
		eemWorkFlowVO.setSupervisorId(form.getSupervisorId());
		//pagination starts
		Pagination pagination = null;
	    pagination = context.getEnrollEnrollPagination();
	    //pagination ends
	    rslt = eemWorkFlowService.userListSelect(conn, eemWorkFlowVO);	
  		form.setSelectedUserListInfoRow(0);
  		form.setListUserInfosWithDisplay(eemWorkFlowVO.getListUser());
  		form.setUserListChanged(false);
  		form.setUserListInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
  		form.setTopDisplayUserListInfoRow(0);  
  		 //pagination starts
  		pagination = context.getUserListPagination();		
		pagination.setListPaginationResults("first",eemWorkFlowVO.getListUser());
		//pagination ends  		
  		if(rslt){  			
  			
  		}
  		logger.info(LoggerConstants.methodEndLevel());
	}
	
	/**
	 * This method used to update show user list
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 * @throws SQLException 
	 */
	public void userListUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, 
			EEMWorkFlowForm form) throws ApplicationException, SQLException  {
		logger.info(LoggerConstants.methodStartLevel());
		
		String userId = sessionHelper.getUserId();
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();
		EEMWorkFLowVO eemWorkFlowVO = context.getWorkFlowVO();
		EEMUserListDao eemUserListDao = new EEMUserListDao(); 
		EEMUserListVO userListVO = form.getDisplayUserListInfo();
		boolean rslt = false;
		if(userListVO!=null){
        	rslt = eemWorkFlowService.userListInfoUpdate(conn, eemWorkFlowVO, 
        			userListVO, userId,sessionHelper.getMfId());
		}
		if(rslt){			
			List<EEMUserListVO> userList = eemUserListDao.getUserListInfo(conn, eemWorkFlowVO);
			//Excellus Retro fix for workflow -Start
			//form.setSelectedUserListInfoRow(0);
			//Excellus Retro fix for workflow -End
			form.setListUserInfosWithDisplay(userList);
//			eemWFForm.setListUser(userList);
			form.setUserListChanged(false);
			form.setUserListInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
			form.setTopDisplayUserListInfoRow(0);
			form.setPopupMsg("Update Success");
		}
		if (rslt == false) {			
			List<EEMUserListVO> userList = eemUserListDao.getUserListInfo(conn, eemWorkFlowVO);
			//Excellus Retro fix for workflow -Start
			//form.setSelectedUserListInfoRow(0);
			//Excellus Retro fix for workflow -End
			form.setListUserInfosWithDisplay(userList);
//			eemWFForm.setListUser(userList);
			form.setUserListChanged(false);
			form.setUserListInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
			form.setTopDisplayUserListInfoRow(0);
			form.setPopupMsg("Update Failed" + eemWorkFlowVO.getPopupMsg());
		}
		logger.info(LoggerConstants.methodEndLevel());
	 }
	/**
	 * 045_UserList end
	 */
	/**
	 * 045_AssignActivity start
	 */
	/**
	 * This method used to init change assign activity list
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 */
	public void initAssignActivityList(Connection conn, SessionHelper sessionHelper,
			EEMContext context, EEMWorkFlowForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();	
		 boolean rslt = false;		
		EEMWorkFLowVO eemWorkFlowVO = context.getWorkFlowVO();
		//Excellus Retro fix for workflow -Start
		//eemWorkFlowVO.setUserID(form.getUserId());
		//Excellus Retro fix for workflow -End
		eemWorkFlowVO.setHicNbr(form.getHicNbr());
		eemWorkFlowVO.setLastName(form.getLastName());
		eemWorkFlowVO.setSupervisorId(form.getSupervisorId());
		//pagination starts
		Pagination pagination = null;
	    pagination = context.getEnrollEnrollPagination();
	    //pagination ends
	    rslt = eemWorkFlowService.assignActivityListSelect(conn, eemWorkFlowVO);	
  		form.setSelectedActivityListInfoRow(0);
  		form.setListActivityInfosWithDisplay(eemWorkFlowVO.getListAssignActivity());
  		form.setActivityListChanged(false);
  		form.setActivityListInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);
  		form.setTopDisplayActListInfoRow(0);  
  	    //pagination starts
  		pagination = context.getAssignActivityPagination();		
		pagination.setListPaginationResults("first",eemWorkFlowVO.getListAssignActivity());
		//pagination ends
		//pagination starts		
		if(rslt){			
			EEMAssignActivityVO assignActivityVoObj = (EEMAssignActivityVO) eemWorkFlowVO.getListAssignActivity().get(0);
			form.setDisplayActivityListInfo(assignActivityVoObj);
			form.setSelectedActivityListInfoRow(0);
			form.setActivityListChanged(false);
			form.setActivityListInfoDisplayState(EEMConstants.EEM_MBR_SCREEN_VIEW);

			pagination.setPageToDisplayRow(0,eemWorkFlowVO.getListAssignActivity());
			Integer topRow = (Integer)pagination.getFirstDetail();						
			form.setTopDisplayActListInfoRow(topRow.intValue());
		}
		//pagination ends
		logger.info(LoggerConstants.methodEndLevel());
	}

	/**
	 * This method used to update change assign activity 
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 * @throws SQLException when sql failed to execute
	 */
	public void assignActivityUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, 
			EEMWorkFlowForm form) throws ApplicationException, SQLException  {
		logger.info(LoggerConstants.methodStartLevel());
		
		String userId = sessionHelper.getUserId();
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();
		EEMWorkFLowVO eemWorkFlowVO = context.getWorkFlowVO();		
		EEMAssignActivityVO assignActivityVO = form.getDisplayActivityListInfo();		
		boolean rslt = false;
		if(assignActivityVO!=null){				
        	rslt = eemWorkFlowService.assignActivityInfoUpdate(conn, eemWorkFlowVO, 
        			assignActivityVO, userId);        	
		}
		if(rslt){			
			form.setListActivityInfosWithDisplay(eemWorkFlowVO.getListAssignActivity());			
			form.setPopupMsg("Update Success");
		}
		if (rslt == false) {			
			form.setListActivityInfosWithDisplay(eemWorkFlowVO.getListAssignActivity());
			form.setPopupMsg("Update Failed");
		}
		logger.info(LoggerConstants.methodEndLevel());
	 }

	/**
	 * 045_AssignActivity end
	 */
	/**
	 * 045_AtRisk Changes start
	 */
	/**
	 * This method used to update change assign activity 
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 * @throws SQLException when sql failed to execute
	 */
	public void initAtRiskSummary(Connection conn, SessionHelper sessionHelper,
			EEMContext context, EEMWorkFlowForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();	
			
		EEMWorkFLowVO eemWorkFlowVO = context.getWorkFlowVO();	   
	    eemWorkFlowService.atRiskSummary(conn,eemWorkFlowVO);	
	    form.setListAtRiskSummary(eemWorkFlowVO.getListAtRiskSummary());
	    logger.info(LoggerConstants.methodEndLevel());
	}
	/**
	 * This method used to update change assign activity 
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @param form holds string value
	 * @throws ApplicationException when application failed to execute
	 * @throws SQLException when sql failed to execute
	 */
	public void getAtRiskDetails(Connection conn, SessionHelper sessionHelper, EEMContext context,
			EEMWorkFlowForm form, String move){
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService wfService = new EEMWorkFlowService();
		EEMWorkFLowVO workFlowVO = context.getWorkFlowVO();
		wfService.getAtRiskDetails(conn, workFlowVO, move);	//move=first
		form.setListAtRiskDetails(workFlowVO.getListAtRiskDetails());		
		form.setListAtRiskSummary(workFlowVO.getListAtRiskSummary());
		setAtRiskSelectFromLst(workFlowVO);
		logger.info(LoggerConstants.methodEndLevel());
	}
	/**
	 * This method is used to set the selected row in at risk summary screen
	 * @param workFlowVO holds EEMWorkFLowVO object
	 */
	@SuppressWarnings("rawtypes")
	private void setAtRiskSelectFromLst(EEMWorkFLowVO workFlowVO ){
		logger.info(LoggerConstants.methodStartLevel());
		List riskSummaryList = workFlowVO.getListAtRiskSummary();
		Iterator iter = riskSummaryList.iterator();
		while(iter.hasNext()){
			EEMAtRiskVO atRiskVO = (EEMAtRiskVO)iter.next();
			if(workFlowVO.getAtRiskRowCnt() == atRiskVO.getAtRiskRowCnt()){
				atRiskVO.setRowSelected("Y");
			}else{
				atRiskVO.setRowSelected("");
			}
		}//while	
		logger.info(LoggerConstants.methodEndLevel());
	}
	/**
	 * 045_AtRisk Changes end
	 */
	/**
	 * CloseAssignActivity starts
	 */
	/**
	 * This method used to closeQueActivities
	 * @param conn holds Connection object
	 * @param sessionHelper holds SessionHelper Object
	 * @param context holds EEMContext object
	 * @param form holds EEMWorkFlowForm object
	 * @throws ApplicationException when application failed to execute
	 * @throws SQLException when sql failed to execute
	 */
	public void closeQueActivities(Connection conn, SessionHelper sessionHelper, EEMContext context, 
			EEMWorkFlowForm form) throws ApplicationException, SQLException  {
		logger.info(LoggerConstants.methodStartLevel());
		
		String userId = sessionHelper.getUserId();
		EEMWorkFlowService eemWorkFlowService = new EEMWorkFlowService();
		EEMWorkFLowVO eemWorkFlowVO = context.getWorkFlowVO();		
		EEMAssignActivityVO assignActivityVO = form.getDisplayActivityListInfo();		
		boolean rslt = false;
		if(assignActivityVO!=null){				
        	rslt = eemWorkFlowService.closeQueActivities(conn, eemWorkFlowVO, 
        			assignActivityVO, userId);        	
		}		
		if(rslt){			
			form.setListActivityInfosWithDisplay(eemWorkFlowVO.getListAssignActivity());			
			form.setPopupMsg("Closing Queue Success");
		}
		if (rslt == false) {			
			form.setListActivityInfosWithDisplay(eemWorkFlowVO.getListAssignActivity());
			form.setPopupMsg("Can not close the selected Queue");
		}
		logger.info(LoggerConstants.methodEndLevel());
	 }
	/**
	 * CloseAssignActivity ends
	 */
	/* Fix for Pagination Last(>>) button CR # 00370553 - START */
	
	/**
	* This method is used to getTotalRecordsPagination
	* @param conn holds Connection object	
	* @param context holds EEMContext object
	* @param form holds EEMWorkFlowForm object
	* @param move holds String value
	*/
	public void getTotalRecordsPagination(Connection conn, EEMContext context, EEMWorkFlowForm form){
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMWorkFlowService wfService = new EEMWorkFlowService();
		EEMWorkFLowVO workFlowVO = context.getWorkFlowVO();
		 int totalCount = wfService.getTotalRecordsUsrBasedAgrLst(conn, workFlowVO, workFlowVO.getSuprSelectedUName());
				 context.getWorkFlowVO().setUsrAgrmntLstPageNbr(totalCount);	
				 logger.info(LoggerConstants.methodEndLevel());
//		form.setUsrAgreementsLst(workFlowVO.getUsrAgreementsLst());
//		form.setUsrAgrmntLstPageNbr(workFlowVO.getUsrAgrmntLstPageNbr());
//		form.setUsrAgrLstCurrPageType(workFlowVO.getUsrAgrLstCurrPageType());		 
	}//getTotalRecordsPagination()
	
	/* Fix for Pagination Last(>>) button CR # 00370553 - END */
}//class
