/*
 * $Id: EEMLetterReviewManager.java,v 1.1 2014/06/26 07:55:00 praveen Exp $
 */
package com.ps.mss.manager;

import java.io.PrintStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.text.DateFormatter;
import com.ps.util.StringUtil;
import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EEMLetterService;
import com.ps.mss.dao.EEMEnrollDao;
import com.ps.mss.dao.EEMLetterDao;
import com.ps.mss.dao.model.EEMLetterReviewQcVO;
import com.ps.mss.dao.model.EmCorrMbrVO;
import com.ps.mss.db.EEMProfileSettings;
import com.ps.mss.model.EEMContext;
import com.ps.mss.model.EEMLetterReviewAttachmentVO;
import com.ps.mss.model.EEMLetterReviewVO;
import com.ps.mss.model.Pagination;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.forms.EEMLetterReviewAttachmentForm;
import com.ps.mss.web.forms.EEMLetterReviewDetailForm;
import com.ps.mss.web.forms.EEMLetterReviewGenerateForm;
import com.ps.mss.web.forms.EEMLetterReviewQCForm;
import com.ps.mss.web.helper.EEMHelper;
import com.ps.mss.web.helper.EEMLetterHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.framework.Constants;
import com.ps.mss.framework.EEMConstants;

/**
 * @author nenne.robert
 */
public class EEMLetterReviewManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(EEMLetterReviewManager.class);

	PrintStream log;
	
	public EEMLetterReviewManager() {
		this(System.out);
	}
	public EEMLetterReviewManager(PrintStream log) {
		this.log = log;
	}
	
	public void letterReviewSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMLetterReviewDetailForm form) throws SQLException {
		logger.info(LoggerConstants.methodStartLevel());
	
		EEMLetterReviewVO letterReviewVO = context.getLetterReviewVO();
		
		// Copy the search criteria to the VO
		letterReviewVO.setCustomerId(sessionHelper.getMfId());
		letterReviewVO.setSearchType(form.getSearchType());
		letterReviewVO.setSearchId(form.getSearchId());
		letterReviewVO.setSearchReqFromDate(DateFormatter.reFormat(form.getSearchReqFromDate(),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD));
		letterReviewVO.setSearchReqToDate(DateFormatter.reFormat(form.getSearchReqToDate(),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD));
		letterReviewVO.setSearchStatus(form.getSearchStatus());
		letterReviewVO.setSearchBatchId(form.getSearchBatchId());
		letterReviewVO.setSearchLetterName(form.getSearchLetterName());
		letterReviewVO.setSearchDeleteInd(form.getSearchDeleteInd());

		Pagination pagination = context.getLetterReviewPagination();
		if (pagination == null) {
			pagination = new Pagination();
			pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
			context.setLetterReviewPagination(pagination);
		}
		
		form.setSearchExpanded(true);
		letterReviewSearchPage(conn,sessionHelper,context,form,"first");
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public void letterReviewSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMLetterReviewDetailForm form, String move) {
		logger.info(LoggerConstants.methodStartLevel());

		EEMLetterReviewVO letterReviewVO = context.getLetterReviewVO(); // use the last search criteriia even if its changed on the form
		Pagination pagination = context.getLetterReviewPagination();
		
		form.setSelectedSearchRow(0);
		form.setListSearchResults(null);
		form.setDisplayCorrMbr(new EmCorrMbrVO());
		
		letterReviewVO.setListSearchResults(null);

		EEMLetterDao ltrDao = new EEMLetterDao();
		String ltrDesDisp = (String)sessionHelper.getAttribute(EEMProfileSettings.LTR_DES_DISP);
		letterReviewVO.setAttachmentTabInd((String)sessionHelper.getAttribute(EEMConstants.EEM_ATTACHMENTS));
		try {
			List searchResults = ltrDao.getLetterReviewSearchResults(conn,letterReviewVO,pagination,move, ltrDesDisp);
			EmCorrMbrVO [] arr = new EmCorrMbrVO[searchResults.size()];
			arr = (EmCorrMbrVO[])searchResults.toArray(arr);		

			pagination.setPaginationResults(move,arr);
			letterReviewVO.setListSearchResults(searchResults);

			if (searchResults.size() > 0) {
				form.setListSearchResults(searchResults);
				form.setSelectedSearchRow(0);
			}
			letterReviewSelect(conn,sessionHelper,context,form,true);
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log);
		}
		
		if (form.getLstLetterNames() == null)
			form.setLstLetterNames(new ArrayList());
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public void letterReviewSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMLetterReviewDetailForm form, boolean setDisplay) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		
		String customerId = sessionHelper.getMfId();
		
		EEMLetterDao ltrDao = new EEMLetterDao();
		List ltrList = ltrDao.getAllLetterList(conn,customerId);
		form.setLstLetterNames(ltrList);
		
		EEMLetterReviewVO letterReviewVO = context.getLetterReviewVO();
		
		form.setDisplayLetterVarData(null);
		
		List searchResults = letterReviewVO.getListSearchResults();
		form.setListSearchResults(searchResults);
		int selectedSearchRow = form.getSelectedSearchRow();
		if (searchResults != null) {
			if (searchResults.size() > 0) {
				
				EmCorrMbrVO dispVO;
				if (setDisplay) {
					dispVO = (EmCorrMbrVO) searchResults.get(selectedSearchRow);
					form.setDisplayCorrMbr(dispVO);
				} else {
					dispVO = form.getDisplayCorrMbr();
				}
				
				EEMEnrollDao enrlDao = new EEMEnrollDao();
				List lst = enrlDao.getMbrLetterData(conn,customerId,dispVO.getFileBatchId(),dispVO.getRecordType(), dispVO.getPrimaryId(),dispVO.getLetterName());
				form.setDisplayLetterVarData(lst);
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void letterCorrMbrUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMLetterReviewDetailForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMLetterReviewVO letterReviewVO = context.getLetterReviewVO();
		letterReviewVO.setMessage(null);
		
		String customerId = sessionHelper.getMfId();
		String userId = sessionHelper.getUserId();

		List searchResults = letterReviewVO.getListSearchResults();
		int selectedSearchRow = form.getSelectedSearchRow();
		
		EmCorrMbrVO corrVO = (EmCorrMbrVO) searchResults.get(selectedSearchRow);
		
		EmCorrMbrVO dispVO = form.getDisplayCorrMbr();
		dispVO.setCustomerId(customerId);
		if (dispVO.getDeleteInd() == null)
			dispVO.setDeleteInd("");
		
		EmCorrMbrVO newVO = (EmCorrMbrVO)dispVO.clone();
		
		boolean resetDisplay = false;
		EEMLetterService service = new EEMLetterService();
		boolean rslt = service.corrMbrUpdate(conn,letterReviewVO,newVO,corrVO,userId);
		if (!rslt) {
			if (letterReviewVO.getMessage() != null)
				form.setMessage(letterReviewVO.getMessage());
			else
				form.setMessage("Update Failed");
		} else {
			resetDisplay = true;
			corrVO.setDeleteInd(newVO.getDeleteInd());
			corrVO.setRecordStatus(newVO.getRecordStatus());
			corrVO.setLastUpdtTime(newVO.getLastUpdtTime());
			corrVO.setLastUpdtUserId(newVO.getLastUpdtUserId());
			// Begin: Added for Letter Edit Fields
			boolean flag = service.updateLetterReviewFields(conn, dispVO);
			if (!flag) {
				letterReviewVO.setMessage("Error Updating Letter Fields");
			} else {
				resetDisplay = true;
				corrVO.setPrintRequestDate(dispVO.getPrintRequestDate());
				corrVO.setOrigMailDate(dispVO.getOrigMailDate());
				corrVO.setLastMailDate(dispVO.getLastMailDate());
				corrVO.setPrintDate(dispVO.getPrintDate());
				corrVO.setReprintDate(dispVO.getReprintDate());
				corrVO.setResponseDueDate(dispVO.getResponseDueDate());
				corrVO.setResponseDate(dispVO.getResponseDate());
				corrVO.setRequestDate(dispVO.getPrintRequestDate());
			}
			// End: Added for Letter Edit Fields
		}
		
		letterReviewSelect(conn,sessionHelper,context,form,resetDisplay);
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void letterGenerateRequest(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMLetterReviewGenerateForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		
		EEMLetterService service = new EEMLetterService();
		String customerId = sessionHelper.getMfId();
		String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
		String userId = sessionHelper.getUserId();
		String environment = EEMHelper.getRegion(eemDb);
		
		int rslt = service.generateLetterRequest(eemDb,customerId,environment,userId);
		if (rslt == 0) {
			form.setMessage("Letter Generation Request Submitted");
		}
		else
		if (rslt == 1) {
			form.setMessage("A request is currently processing - Please try again latter");
		} 
		else {
			form.setMessage("An Error has occured submitting the request");
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	//Begin: Added for Letter Review LetterQC
	/*public void letterReviewQCsearchbatchId(Connection conn, EEMContext context, EEMLetterReviewQCForm form) throws SQLException {*/

	public void letterReviewQCsearchbatchId(Connection conn, EEMContext context, EEMLetterReviewQCForm form,SessionHelper sessionHelper) throws SQLException {
		logger.info(LoggerConstants.methodStartLevel());
		String customerId = sessionHelper.getMfId();
		//logger.info(" EEMLetterReviewManager : letterReviewQCsearchbatchId : customerId [" + customerId + "] ");
		EEMLetterReviewQcVO letterReviewQcVO = context.getLetterReviewQcVO();
		letterReviewQcVO.setCustomerId(customerId);
		letterReviewQcVO.setSearchReqFromDate(DateFormatter.reFormat(form.getSearchReqFromDate(),DateFormatter.MM_DD_YYYY,DateFormatter.SQL_TIMESTAMP));
		letterReviewQcVO.setSearchReqToDate(DateFormatter.reFormat(form.getSearchReqToDate(),DateFormatter.MM_DD_YYYY,DateFormatter.SQL_TIMESTAMP));
		//IFOX - 430896 LTr QC CR : start
		letterReviewQcVO.setSearchType(StringUtil.nonNullTrim(form.getSearchType()));
		letterReviewQcVO.setSearchId(StringUtil.nonNullTrim(form.getSearchId()));
		//IFOX - 430896 LTr QC CR : end
		form.setSelectedSearchRow(0);
		form.setLstBatchId(null);

		letterReviewQcVO.setListBatchIdResults(null);
		EEMLetterDao ltrDao = new EEMLetterDao();
		try {
			List batchId = ltrDao.getLetterReviewQcBatchId(conn,letterReviewQcVO);
			letterReviewQcVO.setListBatchIdResults(batchId);
			form.setLstBatchId(batchId);
		 } catch(Exception e) {
			 logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace(log);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	/*public void letterReviewQCsearchDescription(Connection conn, EEMContext context, EEMLetterReviewQCForm form) throws SQLException {*/
	public void letterReviewQCsearchDescription(Connection conn, EEMContext context, EEMLetterReviewQCForm form,SessionHelper sessionHelper) throws SQLException {
		logger.info(LoggerConstants.methodStartLevel());
	//EEMLetterHelper ltrhelper = new EEMLetterHelper();
		String customerId = sessionHelper.getMfId();
		EEMLetterReviewQcVO letterReviewQcVO = context.getLetterReviewQcVO();
		letterReviewQcVO.setCustomerId(customerId);
		letterReviewQcVO.setSearchBatchId(form.getSearchBatchId());
		letterReviewQcVO.setSearchReqFromDate(DateFormatter.reFormat(form.getSearchReqFromDate(),DateFormatter.MM_DD_YYYY,DateFormatter.SQL_TIMESTAMP));
		letterReviewQcVO.setSearchReqToDate(DateFormatter.reFormat(form.getSearchReqToDate(),DateFormatter.MM_DD_YYYY,DateFormatter.SQL_TIMESTAMP));
		//IFOX - 430896 LTr QC CR : start
		letterReviewQcVO.setSearchType(StringUtil.nonNullTrim(form.getSearchType()));
		letterReviewQcVO.setSearchId(StringUtil.nonNullTrim(form.getSearchId()));
		//IFOX - 430896 LTr QC CR : end
		
		EEMLetterDao ltrDao = new EEMLetterDao();
		try {
			/*  CustomerId added for SummaCare  -Start */ 
			/*List description = ltrDao.getLetterReviewQcDescription(conn, form.getSearchBatchId());*/
			List description = ltrDao.getLetterReviewQcDescription(conn,letterReviewQcVO);
			List batchId = ltrDao.getLetterReviewQcBatchId(conn,letterReviewQcVO);
			/*  CustomerId added for SummaCare  -End */ 
			letterReviewQcVO.setListBatchIdResults(batchId);
			form.setLstBatchId(batchId);
			letterReviewQcVO.setLstLetterNames(description);
			form.setLstLetterNames(description);
			} catch(Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace(log);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
		//End  : Added for Letter Review LetterQC
	/*	 Begin: Added for Letter Review QC */
	public void letterReviewQCSearch(Connection conn,SessionHelper sessionHelper, EEMContext context,EEMLetterReviewQCForm letterReviewQCform, String ltrStatus) {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterReviewQcVO letterReviewQCVO = context.getLetterReviewQcVO();
		EEMLetterHelper ltrhelper = new EEMLetterHelper();
		
		letterReviewQCVO.setSearchReqFromDate(DateFormatter.reFormat(letterReviewQCform.getSearchReqFromDate(),DateFormatter.MM_DD_YYYY,DateFormatter.SQL_TIMESTAMP));
		letterReviewQCVO.setSearchReqToDate(DateFormatter.reFormat(letterReviewQCform.getSearchReqToDate(),DateFormatter.MM_DD_YYYY,DateFormatter.SQL_TIMESTAMP));
		letterReviewQCVO.setSearchBatchId(letterReviewQCform.getSearchBatchId());
		//IFOX - 430896 LTr QC CR : start
		letterReviewQCVO.setSearchType(StringUtil.nonNullTrim(letterReviewQCform.getSearchType()));
		letterReviewQCVO.setSearchId(StringUtil.nonNullTrim(letterReviewQCform.getSearchId()));
		//IFOX - 430896 LTr QC CR : end
		logger.debug("searchLetterName  "+letterReviewQCform.getSearchLetterName()+ " @@@@@ letterReviewQCform.getLetterName()-----"+letterReviewQCform.getLetterName());
		letterReviewQCVO.setSearchLetterName(letterReviewQCform.getSearchLetterName());
		letterReviewQCVO.setLstLetterNames(letterReviewQCform.getLstLetterNames());
		letterReviewQCVO.setListBatchIdResults(letterReviewQCform.getLstBatchId());
		String move = letterReviewQCform.getMove();
		Pagination pagination = context.getLetterReviewQCPagination();
		if (pagination == null) {
			pagination = new Pagination();
			pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
			context.setLetterReviewQCPagination(pagination);
		}
		
		List searchResults = letterReviewQCSearchPage(conn,sessionHelper,context,letterReviewQCform,move,ltrStatus);
		if (searchResults != null && searchResults.size() > 0) {
			pagination.setFirstDetail(new Integer(letterReviewQCform.getTopDisplay()));
	        pagination.setSelectedLine(letterReviewQCform.getSelectedSearchRow());
	        pagination.setListPaginationResults(move, searchResults);
			Integer newTop = (Integer) pagination.getFirstDetail();
			letterReviewQCform.setTopDisplay(newTop.intValue());
			letterReviewQCform.setSelectedSearchRow(pagination.getSelectedLine());
			}
		ltrhelper.copyVOToForm(letterReviewQCVO, letterReviewQCform);
		logger.info(LoggerConstants.methodEndLevel());
		}
	private List letterReviewQCSearchPage(Connection conn,SessionHelper sessionHelper, EEMContext context,EEMLetterReviewQCForm form, String move, String ltrStatus) {
		logger.info(LoggerConstants.methodStartLevel());

		EEMLetterReviewQcVO letterReviewQcVO = context.getLetterReviewQcVO(); // use the last search criteriia even if its changed on the form
		//IFOX - 430896 LTr QC CR : start
		Pagination pagination = context.getLetterReviewQCPagination();
		//IFOX - 430896 LTr QC CR : end
		String customerId = sessionHelper.getMfId();
		String userId = sessionHelper.getUserId();
		//logger.info(" EEMLetterReviewManager : letterReviewQCSearchPage : customerId [" + customerId + "], UserId [" + userId+ "]");
		
		form.setSelectedSearchRow(0);
		form.setListSearchResults(null);
		form.setDisplayCorrMbr(new EmCorrMbrVO());
		
		//letterReviewQcVO.setListSearchResults(null);
		
		EEMLetterDao ltrDao = new EEMLetterDao();
		List searchResults = null;
		logger.debug("1. in dao Vo = "+letterReviewQcVO);
		
		try {
			//IFOX - 430896 LTr QC CR : start
			//Profile Ind value and set to form 
			String eemDb = (String)sessionHelper.getAttribute(SessionManager.EEMDB);
			String indValue = EEMProfileSettings.getCalendarProfileText(eemDb, sessionHelper.getMfId(),
					"LTRQCIND");
			form.setQcProfileInd(StringUtil.nonNullTrim(indValue));
			
			if(ltrStatus.equals("APPROVED") || ltrStatus.equals("REJECTED")
					|| ltrStatus.equals("HOLD")){
				//IFOX - 430896 LTr QC CR : end
			logger.debug("2. in dao status = "+ltrStatus);
			int size =  letterReviewQcVO.getListSearchResults().size();
			logger.debug("****** list size to change = "+size+"------- "+letterReviewQcVO.getListSearchResults());
			//EEMLetterReviewQcVO[] lstVO= new  EEMLetterReviewQcVO[size];
			//lstVO = (EEMLetterReviewQcVO[]) letterReviewQcVO.getListSearchResults().toArray(lstVO);
			EmCorrMbrVO [] lstVO = new EmCorrMbrVO[size];
			lstVO = (EmCorrMbrVO[])letterReviewQcVO.getListSearchResults().toArray(lstVO);
			String frmDate = letterReviewQcVO.getSearchReqFromDate();
			String toDate = letterReviewQcVO.getSearchReqToDate();
			//IFOX - 430896 LTr QC CR : start
			
			int pageNumber = pagination.getPageNumber();
			int maxRecord = pagination.getMaxRecordCount();
				if(StringUtil.nonNullTrim(form.getQcProfileInd()).equals("Y")){
					for(int i=0;i<form.getLetterQCCheck().length; i++){
						int index = i+ ((pageNumber-1)*maxRecord );
						String  checkStatus= form.getLetterQCCheck()[i];
						
						if(checkStatus.equals("Y")){
					
							ltrDao.getLetterReviewQCUpdate(conn, lstVO[index], ltrStatus,
									frmDate, toDate, customerId, userId);
						}
					}
				}
				else{
					for(int i=0;i<size; i++){
						logger.debug("list"+i+"@@@@@"+lstVO[i]);
				/*ltrDao.getLetterReviewQCUpdate(conn, lstVO[i],ltrStatus,frmDate,toDate);*/
				ltrDao.getLetterReviewQCUpdate(conn, lstVO[i],ltrStatus,frmDate,toDate,customerId, userId);
					}
				
			//ltrDao.getLetterReviewQCUpdate(conn, letterReviewQcVO,ltrStatus);
				}
				//IFOX - 430896 LTr QC CR : end
		}
		/*  CustomerId added for SummaCare  -Start */
			searchResults = ltrDao.getLetterReviewQCSearchResults(conn,letterReviewQcVO,pagination,move,ltrStatus,customerId);
			/*  CustomerId added for SummaCare  -End */
			EmCorrMbrVO [] arr = new EmCorrMbrVO[searchResults.size()];
			arr = (EmCorrMbrVO[])searchResults.toArray(arr);		
			form.setSelectedSearchRow(0);
			letterReviewQcVO.setListSearchResults(searchResults);

			if (searchResults.size() > 0) {
				form.setListSearchResults(searchResults);
				form.setSelectedSearchRow(0);
			}
			form.setSearchExpanded(true);
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//e.printStackTrace(log);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return searchResults;
	}
	/*	End: Added for Letter Review QC */
	//Start: Added for Letter Review Upload
	public boolean validateSourceAndPrimaryId(Connection conn, String customerId, String primaryId, String recordType) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		logger.info(LoggerConstants.methodEndLevel());
		return new EEMLetterDao().validateSourceAndPrimaryId(conn, customerId, primaryId, recordType);
	}
	
	public void updateLetterReviewFields(Connection conn, Map fieldsMap) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		logger.info(LoggerConstants.methodEndLevel());
		new EEMLetterDao().updateLetterReviewFields(conn, fieldsMap);
	}
	//End: Added for Letter Review Upload
	//IFOX-00426356: Attachment CR:start
	public void letterAttachmentSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMLetterReviewAttachmentForm form) throws SQLException {
		logger.info(LoggerConstants.methodStartLevel());
	
		EEMLetterReviewAttachmentVO letterAttachmentVO = context.getLetterAttachmentVO();
		
		// Copy the search criteria to the VO
		letterAttachmentVO.setCustomerId(sessionHelper.getMfId());
		letterAttachmentVO.setSearchType(form.getSearchType());
		letterAttachmentVO.setSearchId(form.getSearchId());
		

		Pagination pagination = context.getLetterAttachmentPagination();
		if (pagination == null) {
			pagination = new Pagination();
			pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
			context.setLetterAttachmentPagination(pagination);
		}
		
		form.setSearchExpanded(true);
		letterAttachmentSearchPage(conn,sessionHelper,context,form,"first");
		logger.info(LoggerConstants.methodEndLevel());
	}
	public void letterAttachmentSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMLetterReviewAttachmentForm form, String move) {
		logger.info(LoggerConstants.methodStartLevel());

		EEMLetterReviewAttachmentVO letterAttachmentVO = context.getLetterAttachmentVO(); // use the last search criteriia even if its changed on the form
		Pagination pagination = context.getLetterAttachmentPagination();
		
		form.setSelectedSearchRow(0);
		form.setListSearchResults(null);
		form.setDisplayCorrMbr(new EmCorrMbrVO());
		
		letterAttachmentVO.setListSearchResults(null);

		EEMLetterDao ltrDao = new EEMLetterDao();
		try {
			List searchResults = ltrDao.getLetterAttachmentSearchResults(conn,letterAttachmentVO,pagination,move);
			EmCorrMbrVO [] arr = new EmCorrMbrVO[searchResults.size()];
			arr = (EmCorrMbrVO[])searchResults.toArray(arr);		

			pagination.setPaginationResults(move,arr);
			letterAttachmentVO.setListSearchResults(searchResults);

			if (searchResults.size() > 0) {
				form.setListSearchResults(searchResults);
				form.setSelectedSearchRow(0);
				form.setEnableUpload("Y");
				form.setName(letterAttachmentVO.getName());
				form.setMbi(letterAttachmentVO.getMbi());
			}
			letterAttachmentSelect(conn,sessionHelper,context,form,true);
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log);
		}
		
		if (form.getLstLetterNames() == null)
			form.setLstLetterNames(new ArrayList());
		logger.info(LoggerConstants.methodEndLevel());
	}
	public void letterAttachmentSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMLetterReviewAttachmentForm form, boolean setDisplay) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());

		EEMLetterReviewAttachmentVO letterReviewAttachmentVO = context.getLetterAttachmentVO();
		form.setEnableUpload("N");
		List searchResults = letterReviewAttachmentVO.getListSearchResults();
		form.setListSearchResults(searchResults);
		int selectedSearchRow = form.getSelectedSearchRow();
		if (searchResults != null) {
			if (searchResults.size() > 0) {
				form.setEnableUpload("Y");
				form.setName(letterReviewAttachmentVO.getName());
				form.setMbi(letterReviewAttachmentVO.getMbi());
				EmCorrMbrVO dispVO;
				if (setDisplay) {
					dispVO = (EmCorrMbrVO) searchResults.get(selectedSearchRow);
					form.setDisplayCorrMbr(dispVO);
				} else {
					dispVO = form.getDisplayCorrMbr();
				}
				
				
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	//IFOX-00426356: Attachment CR: end
	
}
