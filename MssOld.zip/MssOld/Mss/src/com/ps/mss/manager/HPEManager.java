/*
 * $Id: HPEManager.java,v 1.1 2014/06/26 07:54:57 praveen Exp $
 */
package com.ps.mss.manager;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;
import com.ps.mss.framework.HPEConstants;
import com.ps.mss.model.HPEContext;

public class HPEManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(HPEManager.class);
	
	static ModuleLog log = new ModuleLog("HPEManager");

	public static HPEContext getContext(HttpSession session) {
		logger.info(LoggerConstants.methodStartLevel());
		HPEContext context = (HPEContext)session.getAttribute(HPEConstants.HPE_CONTEXT);
		if (context == null) {
			context = new HPEContext();
			session.setAttribute(HPEConstants.HPE_CONTEXT,context);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return context;
	}
}
