/*
 * $Id: EEMLetterManager.java,v 1.4 2015/07/22 05:34:07 praveen Exp $
 */
package com.ps.mss.manager;

import java.io.PrintStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.text.DateFormatter;
import com.ps.util.DateUtil;
import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EEMLetterService;
import com.ps.mss.dao.EEMApplDao;
import com.ps.mss.dao.EEMEnrollDao;
import com.ps.mss.dao.EEMLetterDao;
import com.ps.mss.dao.model.EMApplTriggerLtrDataVO;
import com.ps.mss.dao.model.EMApplTriggerVO;
import com.ps.mss.dao.model.EMMbrTriggerLtrDataVO;
import com.ps.mss.dao.model.EMMbrTriggerVO;
import com.ps.mss.db.EEMCodeCache;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.EEMContext;
import com.ps.mss.model.EEMLetterReqVO;
import com.ps.mss.model.EMLetterReqDisplayVO;
import com.ps.mss.model.EMLetterReqSearchResultVO;
import com.ps.mss.model.EMLetterVarDataVO;
import com.ps.mss.model.Pagination;
import com.ps.mss.web.forms.EEMLetterReqForm;
import com.ps.mss.web.helper.EEMLetterHelper;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.framework.Constants;
import com.ps.mss.framework.EEMConstants;

/**
 * @author nenne.robert
 */
public class EEMLetterManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(EEMLetterManager.class);

	PrintStream log;
	
	public EEMLetterManager() {
		this(System.out);
	}
	public EEMLetterManager(PrintStream log) {
		this.log = log;
	}
	
	public void letterReqSearch(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMLetterReqForm form) throws SQLException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterReqVO letterReqVO = context.getLetterReqVO();
		// Copy the search criteria to the VO
		letterReqVO.setCustomerId(sessionHelper.getMfId());
		letterReqVO.setSearchType(form.getSearchType());
		letterReqVO.setSearchId(form.getSearchId());
		letterReqVO.setSearchCreateDate(DateFormatter.reFormat(form.getSearchCreateDate(),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD));
		letterReqVO.setSearchStatus(form.getSearchStatus());

		Pagination pagination = context.getLetterReqPagination();
		if (pagination == null) {
			pagination = new Pagination();
			pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
			context.setLetterReqPagination(pagination);
		}
		
		form.setSearchExpanded(true);
		letterReqSearchPage(conn,sessionHelper,context,form,"first");
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public void letterReqSearchPage(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMLetterReqForm form, String move) {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterReqVO letterReqVO = context.getLetterReqVO(); // use the last search criteriia even if its changed on the form
		Pagination pagination = context.getLetterReqPagination();
		
		form.setSelectedSearchRow(0);
		form.setListSearchResults(null);
		form.setDisplayLetterReq(new EMLetterReqDisplayVO());
		
		letterReqVO.setSearchResults(null);

		EEMLetterDao ltrDao = new EEMLetterDao();
		try {
			List searchResults = ltrDao.getLetterReqSearchResults(conn,letterReqVO,pagination,move);
			EMLetterReqSearchResultVO [] arr = new EMLetterReqSearchResultVO[searchResults.size()];
			arr = (EMLetterReqSearchResultVO[])searchResults.toArray(arr);		

			pagination.setPaginationResults(move,arr);
			letterReqVO.setSearchResults(searchResults);

			if (searchResults.size() > 0) {
				form.setListSearchResults(searchResults);
				form.setSelectedSearchRow(0);
			}
			letterReqSelect(conn,sessionHelper,context,form);
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace(log);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public void letterReqSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMLetterReqForm form) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterReqVO letterReqVO = context.getLetterReqVO();
		
		List searchResults = letterReqVO.getSearchResults();
		int selectedSearchRow = form.getSelectedSearchRow();
		form.setListSearchResults(searchResults);
		form.setEditState(EEMConstants.EEM_MBR_SCREEN_VIEW);
		
		EMLetterReqSearchResultVO searchVO = (EMLetterReqSearchResultVO) searchResults.get(selectedSearchRow);
		EMLetterReqDisplayVO dispVO = new EMLetterReqDisplayVO();
		EEMLetterHelper.copySearchToDisplay(searchVO,dispVO);
		
		String custNbr = sessionHelper.getCustomerNumber();
		
		EEMLetterService service = new EEMLetterService();
		if (!service.letterReqSelect(conn,custNbr,dispVO))
			form.setMessage("An Unexpected Error Has Occured");
		
		form.setDisplayLetterReq(dispVO);
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void letterReqLookup(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMLetterReqForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterReqVO letterReqVO = context.getLetterReqVO();		
		List searchResults = letterReqVO.getSearchResults();
		form.setListSearchResults(searchResults);
	
		String customerId = sessionHelper.getCustomerNumber();
		String mfId = sessionHelper.getMfId();
		
		form.setLstLetterName(null);
		context.setLstLetterNames(null);
		
		EMLetterReqDisplayVO dispVO = form.getDisplayLetterReq();
		EMLetterReqDisplayVO rslt = null;
		
		dispVO.setLetterName("");
		dispVO.setLstVarData(null);
		
		EEMLetterDao dao = new EEMLetterDao();
		
		if ("M".equals(dispVO.getSourceType())) {
			String mbrId = dispVO.getPrimaryId(); 
			rslt = dao.getMbrInfo(conn,customerId,mfId,mbrId);
			
			if (rslt == null) {
				form.setMessage("Member Not Found");
				return;
			}
			//Excellus Adding Member firstName and LastName in Letter Request CR -Start
			dispVO.setMbrFName(rslt.getMbrFName());
			dispVO.setMbrLName(rslt.getMbrLName());
			//Excellus Adding Member firstName and LastName in Letter Request CR -End
			dispVO.setPlanId(rslt.getPlanId());
			dispVO.setPbpId(rslt.getPbpId());
			dispVO.setPlanDesignation(rslt.getPlanDesignation());
			dispVO.setEffDate(rslt.getEffDate());
			dispVO.setOrgEffDate(rslt.getOrgEffDate());
			dispVO.setOrgPlanId(rslt.getOrgPlanId());
			dispVO.setOrgPbpid(rslt.getOrgPbpid());
			dispVO.setOrgDesc(rslt.getOrgDesc());
			logger.debug("orinal date"+dispVO.getOrgDesc());

		} 
		else
		if ("A".equals(dispVO.getSourceType())) {
			String applId = dispVO.getPrimaryId(); 
			rslt = dao.getApplInfo(conn,customerId,mfId,applId);
			
			if (rslt == null) {
				form.setMessage("Application Not Found");
				logger.info(LoggerConstants.methodEndLevel());
				return;
			}
			//Excellus Adding Member firstName and LastName in Letter Request CR -Start
			dispVO.setMbrFName(rslt.getMbrFName());
			dispVO.setMbrLName(rslt.getMbrLName());
			//Excellus Adding Member firstName and LastName in Letter Request CR -End
			dispVO.setPlanId(rslt.getPlanId());
			dispVO.setPbpId(rslt.getPbpId());
			dispVO.setPlanDesignation(rslt.getPlanDesignation());
			dispVO.setEffDate(rslt.getEffDate());
		}

		if (!dispVO.getPlanDesignation().equals("")) {
			List lst = dao.getLetterList(conn,mfId,dispVO.getPlanDesignation(),dispVO.getSourceType());
			if (lst.size() == 0) {
				form.setMessage("No Letters Found");
			}
			form.setLstLetterName(lst);
			context.setLstLetterNames(lst);
		} else {
			form.setMessage("Missing Required Product Information");
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void letterReqSelectLetter(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMLetterReqForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterReqVO letterReqVO = context.getLetterReqVO();		
		List searchResults = letterReqVO.getSearchResults();
		String mfId = sessionHelper.getMfId();
		EEMLetterDao dao = new EEMLetterDao();
		form.setListSearchResults(searchResults);
		
		List letlst = dao.getLetterList(conn,mfId,form.getDisplayLetterReq().getPlanDesignation(),form.getDisplayLetterReq().getSourceType());
		if (letlst.size() == 0) {
			form.setMessage("No Letters Found");
		}
		form.setLstLetterName(letlst);
		
		//String mfId = sessionHelper.getMfId();
		
		EMLetterReqDisplayVO dispVO = form.getDisplayLetterReq();
		//EEMLetterDao dao = new EEMLetterDao();
		List lst = dao.getLetterDataEntry(conn,mfId,dispVO.getLetterName());
		
		dispVO.setLstVarData(lst);
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void letterReqCreateLetter(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMLetterReqForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterReqVO letterReqVO = context.getLetterReqVO();		
		List searchResults = letterReqVO.getSearchResults();
		form.setListSearchResults(searchResults);
		List ltrNames = context.getLstLetterNames();
		form.setLstLetterName(ltrNames);
		
		EMLetterReqDisplayVO dispVO = form.getDisplayLetterReq();
		List lst = EEMLetterHelper.getVarDataList(dispVO);
		dispVO.setLstVarData(lst);
		
		if (filteredBinaryData(lst)) {
			form.setMessage("Carraige Returns and tabs have been removed Please Verify and resubmit");
			logger.info(LoggerConstants.methodEndLevel());
			return;
		}
		
		String mfId = sessionHelper.getMfId();
		String userId = sessionHelper.getUserId();
		
		EEMLetterDao lDao = new EEMLetterDao();
		String reasonCd = lDao.getReasonCode(conn,mfId,dispVO.getLetterName());
		if (reasonCd == null)
			throw new Exception("Reason Cd Not Found [" + dispVO.getLetterName() + "]");
					
		DateUtil du = new DateUtil();
		String ts = du.getDB2DTS();
		
		boolean lastAutoCommit = conn.getAutoCommit();
		boolean inTrans = false;
		int sqlCnt = 0;

		try {
			conn.setAutoCommit(false);
			
			if ("M".equals(dispVO.getSourceType())) {
				EEMEnrollDao enrlDao = new EEMEnrollDao();
				
				EMMbrTriggerVO trig = new EMMbrTriggerVO();
				
				trig.setCustomerId(mfId);
				trig.setMemberId(dispVO.getPrimaryId());
				trig.setTriggerType(EEMConstants.TRIGGER_TYPE_MANUAL_LTR);
				trig.setEffectiveDate(dispVO.getEffDate());
				trig.setTriggerCode(reasonCd);
				trig.setPlanId(dispVO.getPlanId());
				trig.setPbpId(dispVO.getPbpId());
				trig.setPlanDesignation(dispVO.getPlanDesignation());
				trig.setTriggerStatus(EEMConstants.TRIGGER_STATUS_OPEN);
				trig.setProcessSource(EEMConstants.PROCESS_SOURCE_MBR);
				trig.setOrigTriggerType("");
				trig.setOrigTriggerCode("");
				trig.setOrigEffectiveDate("");
				trig.setOrigTriggerCreateTime("");
				trig.setCreateUserid(userId);
				trig.setCreateTime(ts);
				trig.setLastUpdtUserid(userId);
				trig.setLastUpdtTime(ts);
				if(trig.getFileBatchId() == null)
				{
					trig.setFileBatchId("");
				}
				if(trig.getLetterName() == null)
				{
					trig.setLetterName("");
				}
				if(trig.getRecordType() == null)
				{
					trig.setRecordType("");
				}
				inTrans = true;
				sqlCnt = enrlDao.insertMbrTrigger(conn,trig);
				if (sqlCnt != 1)
					throw new Exception("Invalid SQL Update Count [" + sqlCnt + "]");
				
				if (lst != null) {
					if (lst.size() > 0) {
						EMMbrTriggerLtrDataVO trigData = new EMMbrTriggerLtrDataVO();
						trigData.setCustomerId(trig.getCustomerId());
						trigData.setMemberId(trig.getMemberId());
						trigData.setTriggerType(trig.getTriggerType());
						trigData.setEffectiveDate(trig.getEffectiveDate());
						trigData.setCreateTime(trig.getCreateTime());
						trigData.setLastUpdtUserid(trig.getCreateUserid());
						trigData.setLastUpdtTime(ts);
						
						EMLetterVarDataVO varData = null;
						
						Iterator it = lst.iterator();
						int seqNbr = 1;
						while (it.hasNext()) {
							varData = (EMLetterVarDataVO)it.next();
							trigData.setVariableSeqNbr(seqNbr);
							trigData.setVariableId(varData.getVarId());
							
							if (varData.getFieldType().equals("D")) {
								
								trigData.setContinueSeqNbr(1);
								trigData.setVariableData(DateFormatter.reFormat(varData.getFieldValue(),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD));
								
								sqlCnt = enrlDao.insertMbrTriggerLtrData(conn,trigData);
								if (sqlCnt != 1)
									throw new Exception("Invalid SQL Update Count [" + sqlCnt + "]");
							} else {
								String [] chunks = varData.getChunks();
								for (int i = 0; i < chunks.length; i++) {
									trigData.setContinueSeqNbr(i+1);
									trigData.setVariableData(chunks[i]);
									
									sqlCnt = enrlDao.insertMbrTriggerLtrData(conn,trigData);
									if (sqlCnt != 1)
										throw new Exception("Invalid SQL Update Count [" + sqlCnt + "]");
									
								}
							}
							seqNbr += 1;
						}
					}
				}
				conn.commit();
				inTrans = false;				
			} 
			else
			if ("A".equals(dispVO.getSourceType())) {
				EEMApplDao applDao = new EEMApplDao();
				
				EMApplTriggerVO trig = new EMApplTriggerVO();
				
				trig.setCustomerId(mfId);
				trig.setApplicationId(Integer.parseInt(dispVO.getPrimaryId()));
				trig.setTriggerType(EEMConstants.TRIGGER_TYPE_MANUAL_LTR);
				trig.setEffectiveDate(dispVO.getEffDate());
				trig.setTriggerStatus(EEMConstants.TRIGGER_STATUS_OPEN);
				trig.setTriggerCode(reasonCd);
				trig.setOrigTriggerType("");
				trig.setOrigTriggerCode("");
				trig.setOrigEffectiveDate("");
				trig.setOrigTriggerCreateTime("");
				trig.setCreateUserid(userId);
				trig.setCreateTime(ts);
				trig.setLastUpdtUserid(userId);
				trig.setLastUpdtTime(ts);
		
				inTrans = true;
				sqlCnt = applDao.insertApplTrigger(conn,trig);
				if (sqlCnt != 1)
					throw new Exception("Invalid SQL Update Count [" + sqlCnt + "]");
				
				if (lst != null) {
					if (lst.size() > 0) {
						EMApplTriggerLtrDataVO trigData = new EMApplTriggerLtrDataVO();
						trigData.setCustomerId(trig.getCustomerId());
						trigData.setApplicationId(trig.getApplicationId());
						trigData.setTriggerType(trig.getTriggerType());
						trigData.setEffectiveDate(trig.getEffectiveDate());
						trigData.setCreateTime(trig.getCreateTime());
						trigData.setLastUpdtUserid(trig.getCreateUserid());
						trigData.setLastUpdtTime(ts);
						
						EMLetterVarDataVO varData = null;

						
						Iterator it = lst.iterator();
						int seqNbr = 1;
						while (it.hasNext()) {
							varData = (EMLetterVarDataVO)it.next();
							trigData.setVariableSeqNbr(seqNbr);
							trigData.setVariableId(varData.getVarId());
							
							if (varData.getFieldType().equals("D")) {
								
								trigData.setContinueSeqNbr(1);
								trigData.setVariableData(DateFormatter.reFormat(varData.getFieldValue(),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD));
								
								sqlCnt = applDao.insertApplTriggerLtrData(conn,trigData);
								if (sqlCnt != 1)
									throw new Exception("Invalid SQL Update Count [" + sqlCnt + "]");
							} else {
								String [] chunks = varData.getChunks();
								for (int i = 0; i < chunks.length; i++) {
									trigData.setContinueSeqNbr(i+1);
									trigData.setVariableData(chunks[i]);
									
									sqlCnt = applDao.insertApplTriggerLtrData(conn,trigData);
									if (sqlCnt != 1)
										throw new Exception("Invalid SQL Update Count [" + sqlCnt + "]");
									
								}
							}							
							seqNbr += 1;
						}
					}
				}
				conn.commit();
				inTrans = false;
			} 
			form.setEditState(EEMConstants.EEM_MBR_SCREEN_VIEW);
			form.setMessage("Update Complete");

			EEMCodeCache cc = EEMCodeCache.getInstance();
			
			dispVO.setSourceTypeDesc(cc.getListBoxDesc(dispVO.getSourceType(),cc.getArrSourceTypes()));

			dispVO.setTriggerType(EEMConstants.TRIGGER_TYPE_MANUAL_LTR);
			dispVO.setTriggerTypeDesc(cc.getListBoxDesc(dispVO.getTriggerType(),cc.getLstTriggerType()));
		
			dispVO.setTriggerStatus(EEMConstants.TRIGGER_STATUS_OPEN);
			dispVO.setTriggerStatusDesc(cc.getListBoxDesc(dispVO.getTriggerStatus(),cc.getLstTriggerStatus()));
			
			String desc = cc.getDesc(dispVO.getLetterName(),ltrNames);
			if (desc == null) {
				desc = cc.getListBoxDesc(dispVO.getLetterName(),cc.getLstTriggerCodes());
				if (desc == null)
					desc = dispVO.getLetterName();
			}
			dispVO.setTriggerCode(dispVO.getLetterName());
			dispVO.setTriggerCodeDesc(desc);
			
			
			dispVO.setCreateTime(ts);
			dispVO.setCreateUserId(userId);
			dispVO.setLastUpdtTime(ts);
			dispVO.setLastUpdtUserId(userId);
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			form.setMessage("Update Failed");
		} finally {
			if (inTrans) {
				try {
					conn.rollback();
				} catch(Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug(e.toString());
				}
			}
			conn.setAutoCommit(lastAutoCommit);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public boolean filteredBinaryData(List lst) {
		logger.info(LoggerConstants.methodStartLevel());
		if (lst == null) {
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		
		EMLetterVarDataVO varData = null;
		
		boolean rslt = false;
		StringBuffer sb;
		String txt;
		int len;
		Iterator it = lst.iterator();
		int seqNbr = 0;
		while (it.hasNext()) {
			varData = (EMLetterVarDataVO)it.next();
			sb = new StringBuffer();
			txt = varData.getFieldValue();
			len = txt.length();
			char c;
			boolean thisRslt = false;
			for (int i = 0; i < len; i++) {
				c = txt.charAt(i);
				if (Character.isISOControl(c)) {
					sb.append(' ');
					thisRslt = true;
				} else
					sb.append(c);
			}
			if (thisRslt) {
				varData.setFieldValue(sb.toString());
				rslt = thisRslt;
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return rslt;
	}
	
	public void letterReqNewRequest(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMLetterReqForm form) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		EEMLetterReqVO letterReqVO = context.getLetterReqVO();		
		List searchResults = letterReqVO.getSearchResults();
		form.setListSearchResults(searchResults);
		
		form.setEditState(EEMConstants.EEM_MBR_SCREEN_EDIT);
		form.setDisplayLetterReq(new EMLetterReqDisplayVO());
		context.setLstLetterNames(null);
		form.setLstLetterName(null);
		logger.info(LoggerConstants.methodEndLevel());
	}

}
