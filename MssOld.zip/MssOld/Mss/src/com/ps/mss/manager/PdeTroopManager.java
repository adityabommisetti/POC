/*
 * $Id: PdeTroopManager.java,v 1.1 2014/06/26 07:54:57 praveen Exp $
 *
 */
package com.ps.mss.manager;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.PdeTroopService;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.FilterVO;
import com.ps.mss.model.PdeDashboardVO;
import com.ps.mss.model.PdeDetailVO;
import com.ps.mss.model.PdeEventDetailVoList;
import com.ps.mss.model.TroopDashBoardVOList;
import com.ps.mss.model.TroopDetailVOList;

/**
 * @author deepak
 *
 */
public class PdeTroopManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(PdeTroopManager.class);
	/**
	 * This method calls isExportPdeDetailRequestValid() of PdeTroopService to get total number of records for export.
	 * @author hemant
	 * @param dbId
	 * @param filterVO
	 * @param detailMap
	 * @return "TRUE" or Max valid Number of records to show  
	 * @throws ApplicationException
	 */
	public static String isExportPdeDetailRequestValid(String dbId, FilterVO filterVO, Map detailMap)throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		PdeTroopService service = new PdeTroopService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return service.isExportPdeDetailRequestValid(filterVO,detailMap);
	}
	/**
	 * This method calls isExportTroopDetailRequestValid() of PdeTroopService to get total number of records for export.
	 * @author hemant
	 * @param dbId
	 * @param filterVO
	 * @param planMap
	 * @return "TRUE" or Max valid Number of records to show  
	 * @throws ApplicationException
	 */
	public static String isExportTroopDetailRequestValid(String dbId, FilterVO filterVO, Map planMap)throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		PdeTroopService service = new PdeTroopService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return service.isExportTroopDetailRequestValid(filterVO,planMap);
	}
	/**
     * This function call the function of persistence layer
     * @param searchType : it contains plan/year/month 
     * @param filterVO : this Vo contain all the criteria to be use in searching.
     * @param troopDashBoardStatus
     * @return
     * @throws ApplicationException
     */
    public static TroopDashBoardVOList getTroopDashBoard(FilterVO filterVO, Map custPlanMap , String searchType, List troopDashBoardStatus, String dbId) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
        PdeTroopService pdeTroopService = new PdeTroopService(dbId);
        logger.info(LoggerConstants.methodEndLevel());
        return pdeTroopService.getTroopDashBoard(filterVO, custPlanMap, searchType, troopDashBoardStatus);
    }
    
    /**
     * The <code>getTroopDetail</code> returns list of all troop Details  based on search criteria.
     * @param filterVO
     * @param discVO
     * @param move
     * @param dbId
     * @param planMap
     * @param searchType
     * @param discrpArrMap
     * @return list of discrepancies
     * @throws ApplicationException
     */
    public static TroopDetailVOList getTroopDetail(FilterVO filterVO, Map discMap, String move, String dbId, Map planMap, String searchType, String custName) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
        PdeTroopService pdeTroopService = new PdeTroopService(dbId);
        Map discrpArrMap = MasterManager.getDiscrpArrMap();
        logger.info(LoggerConstants.methodEndLevel());
        return pdeTroopService.getTroopDetail(filterVO, discMap, move, planMap, searchType, discrpArrMap, custName);
    }
    
    /**
	 * This function call the function of persistence layer
	 * @param filterVO : this Vo contain all the criteria to be use in searching.
	 * @param searchType : On the  basis of this value we decide search criteria.
	 * @param pdeDashBoardStatus
	 * @param dbId
	 * @return
	 * @throws ApplicationException
	 */
	public static PdeDashboardVO[] getPdeDashBoard(FilterVO filterVO, Map plansMap, String searchType, List pdeDashBoardStatus, String dbId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		PdeTroopService pdeTroopService = new PdeTroopService(dbId);
		logger.info(LoggerConstants.methodEndLevel());
		return pdeTroopService.getPdeDashBoard(filterVO, plansMap, searchType, pdeDashBoardStatus);
	}

    /**
     * @param filterVO
     * @param planMap
     * @param string
     * @param pdeEventDetailStatus
     * @param activeDataBaseName
     * @return
     * @throws ApplicationException
     */
    public static PdeEventDetailVoList getPdeEventDetail(FilterVO filterVO, Map pdeEventMap, String searchType, String move, Map planMap, String custName, String dbId) throws ApplicationException {
    	logger.info(LoggerConstants.methodStartLevel());
        PdeTroopService pdeTroopService = new PdeTroopService(dbId);
        logger.info(LoggerConstants.methodEndLevel());
		return pdeTroopService.getPdeEventDetail(filterVO, pdeEventMap, searchType, move, planMap, custName);
    }
    
    /**
     * This function call the function of persistence layer
     * 
     * @param seqNumber
     * @param dbId
     * @return
     * @throws ApplicationException
     */
    public static PdeDetailVO getPdeDetail(String seqNumber, String custName, FilterVO filterVO, String dbId) throws ApplicationException{
    	logger.info(LoggerConstants.methodStartLevel());
        PdeTroopService pdeTroopService = new PdeTroopService(dbId);
        logger.info(LoggerConstants.methodEndLevel());
        return pdeTroopService.getPdeDetail(seqNumber, custName, filterVO);
    }	
}
