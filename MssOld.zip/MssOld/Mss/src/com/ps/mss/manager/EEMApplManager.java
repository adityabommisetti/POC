package com.ps.mss.manager;

import java.io.PrintStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.EEMApplService;
import com.ps.mss.dao.EEMApplDao;
import com.ps.mss.dao.model.EMApplTriggerVO;
import com.ps.mss.db.EEMProfileSettings;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.model.EEMApplicationVO;
import com.ps.mss.model.EEMContext;
import com.ps.mss.model.Pagination;
import com.ps.mss.web.forms.EEMApplForm;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.mss.security.SessionManager;
import com.ps.util.DateUtil;

/**
 * @author santokmr
 * EEMApplManager class
 */
/**
 * LEP-ApplicationEntrySide-Iteration1_LeftOverScope - Start
 */
public class EEMApplManager {

	PrintStream log;
	public EEMApplManager(){
		this(System.out);
	}
	public EEMApplManager(PrintStream log){
		this.log = log;
	}
	private static Logger logger = LoggerFactory.getLogger(EEMApplManager.class);
	
	/**
	* This method will check whether LEP data is available for the CustomerId & ApplicationId 
	* upon clicking LEP button in Application Entry screen
	* method name - checkLEPDataAvailability
	* @param - conn hold Connection object and customerId holds CustomerId of the Customer
	* @param - appId holds Application Id
	* @return -  checkLEPData of type boolean
	*/
	public boolean checkApplLEPData(Connection conn, String customerId,int appId)
			throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplService service = new EEMApplService();
		boolean chkLepDataFlag=false;
		
		chkLepDataFlag = service.chkLEPData(conn,customerId,appId);
		logger.info(LoggerConstants.methodEndLevel());
		return chkLepDataFlag;
	}
	
 /**
  * @author santokmr
  * This method will fetch the LEP details wrt Application side
  * upon clicking LEP Details button in Application Entry screen
  * @param conn holds Connection object
  * @param SessionHelper holds sessionHelper
  * @param form holds EEMApplForm
  * @param objVO holds EEMApplicationVO
  * @throws ApplicationException when any Exception occurs.
 */
	public void applSelect(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMApplForm form,EEMApplicationVO objVO)
	throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		boolean rslt;
		EEMApplService service = new EEMApplService();
		String beqCheck = "";
		try {
		String eemDb = (String) sessionHelper.getAttribute(SessionManager.EEMDB);
		//BEQ Check Ind
		beqCheck = EEMProfileSettings.getCalendarProfileItem(eemDb, form.getCustomerId(),
							EEMProfileSettings.BEQCHECK);
		}catch(Exception e) {
			throw new ApplicationException(e);
		}
		objVO.setCustomerId(form.getCustomerId());
		objVO.setApplicationId(form.getApplicationId());
		objVO.setMbrHicNbr(form.getMbrHicNbr());
		
		rslt = service.applLESPSelect(conn, objVO, beqCheck);
		//INTERNAL DEFECT - 4 AS PER BCBSAZ Tracker - Start
		if(rslt == false){
			return;
		}
		//INTERNAL DEFECT - 4 AS PER BCBSAZ Tracker - End
		
		form.setSelectedLepInfoRow(0);		
		form.setListAppLepInfosDisplay(objVO.getLepInfos());
		
		// new LEP changes -- start
				form.setPtnUnCvMntsAppLepInfosDisplay(objVO.getPotentialUnCovMthsList());
				form.setEmApplLepAttestInfolistDisplay(objVO
						.getEmApplLepAttestInfolist());
				form.setTotalPlepMonths(objVO.getTotalPlepMonths());
				//----
				String move= form.getMove();
				List lepPotential=objVO.getPotentialUnCovMthsList();
				Pagination pagination = context.getApplLepPotentialPagination();
				pagination.setFirstDetail(new Integer(form.getTopDisplayLepInfoRow()));
				pagination.setSelectedLine(form.getSelectedLepInfoRow());
				pagination.setListPaginationResults(move,lepPotential);
				Integer newTop = (Integer)pagination.getFirstDetail();
				form.setTopDisplayLepInfoRow(newTop.intValue());
				form.setTopDisplayLepInfoRow(pagination.getSelectedLine()); 
				// new LEP changes -- end

		this.setApplLEPTimers(form, form.getCustomerId(), form.getApplicationId(), conn);
		//ATTESTATION CALLS
		form.setOutInitAttests(objVO.getOutInitAttests());
		form.setInInitAttests(objVO.getInInitAttests());
		form.setOutIncAttests(objVO.getOutIncAttests());
		form.setInIncAttests(objVO.getInIncAttests());
		form.setInLateAttests(objVO.getInLateAttests());
		logger.info(LoggerConstants.methodEndLevel());
	}
	
/**
* @author santokmr  
* This method will update the LEP Attestaion and Attestation Calls values 
* wrt Application Side into Database based on the button clicked in the LEP Details popup window
* @param conn holds Connection object
* @param SessionHelper holds sessionHelper
* @param form holds EEMApplForm
* @param objVO holds EEMApplicationVO
* @throws SQLException  when any Exception occurs.
* @throws ApplicationException when any Exception occurs.
*/
	public void applLEPUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context, EEMApplForm form,EEMApplicationVO appVO) throws ApplicationException, SQLException  {
		logger.info(LoggerConstants.methodStartLevel());
		boolean result = false;

		EEMApplService service = new EEMApplService();

		if(form.getSelectedLepApplSubTab().equalsIgnoreCase(EEMConstants.EEM_APP_TAB_LEP_NUNCMO)){
			try{
				List oiAttests = null;
				List iiAttests = null;
				List oIncAttests = null;
				List iIncAttests = null;
				List ilAttests = null;
				DateUtil du = new DateUtil();
				String ts = du.getDB2DTS();
				//-- Outbound Initial Attestation.
				if(form.getOutInitAttestDate() != null ){
					oiAttests = new ArrayList();
					EEMApplicationVO cmot = null;
						for(int i=0; i<form.getOutInitAttestDate().length; i++){
							if( !(form.getOutInitAttestDate()[i].trim().equals("")) && !(form.getOutInitAttestStatus()[i].trim().equals(""))){
								cmot = new EEMApplicationVO();
								cmot.setIndex(i+1);//(index);
								cmot.setAttempt( new Integer(i+1).toString() );//( new Integer(index).toString() );
								cmot.setDate(form.getOutInitAttestDate()[i]);
								cmot.setStatus(form.getOutInitAttestStatus()[i]);
								cmot.setUserID(form.getOutInitAttestUserID()[i]);
								cmot.setChange(form.getOutInitAttestChange()[i]);
								//cmot.setCreateTime((form.getOutInitAttestCreateTime()[i].trim()).equals("") ? ts : form.getOutInitAttestCreateTime()[i]);
								oiAttests.add(cmot);
							}//if
						}	
					//}//if
					form.setOutInitAttests(oiAttests);
					appVO.setOutInitAttests(oiAttests);
				}
											
				//-- Inbound Initial Attestation.

				if(form.getInInitAttestDate()!= null){
					iiAttests = new ArrayList();
					EEMApplicationVO cmoIIA = null;
						for(int i=0; i<form.getInInitAttestDate().length; i++){
							if( !(form.getInInitAttestDate()[i].trim().equals("")) && !(form.getInInitAttestStatus()[i].trim().equals(""))){
								cmoIIA = new EEMApplicationVO();
								cmoIIA.setIndex(i+1);//(index);
								cmoIIA.setAttempt( new Integer(i+1).toString() );//( new Integer(index).toString() );
								cmoIIA.setDate(form.getInInitAttestDate()[i]);
								cmoIIA.setStatus(form.getInInitAttestStatus()[i]);
								cmoIIA.setUserID(form.getInInitAttestUserID()[i]);
								cmoIIA.setChange(form.getInInitAttestChange()[i]);
								//cmoIIA.setCreateTime(form.getInInitAttestCreateTime()[i].trim().equals("") ? ts : form.getInInitAttestCreateTime()[i]);
								iiAttests.add(cmoIIA);
							}//if
						}	
					//}//if
					this.setApplLEPTimers(form, form.getCustomerId(), form.getApplicationId(), conn);
					form.setInInitAttests(iiAttests);
					appVO.setInInitAttests(iiAttests);
				}
				
				//-- Outbound Incomplete Attestation.
				if(form.getOutIncAttestDate() != null){
					oIncAttests = new ArrayList();
					EEMApplicationVO cmooIncAtt = null;
						for(int i=0; i<form.getOutIncAttestDate().length; i++){
							if( !(form.getOutIncAttestDate()[i].trim().equals("")) && !(form.getOutIncAttestStatus()[i].trim().equals(""))){
								cmooIncAtt = new EEMApplicationVO();
								cmooIncAtt.setIndex(i+1);//(index);
								cmooIncAtt.setAttempt( new Integer(i+1).toString() );//( new Integer(index).toString() );
								cmooIncAtt.setDate(form.getOutIncAttestDate()[i]);
								cmooIncAtt.setStatus(form.getOutIncAttestStatus()[i]);
								cmooIncAtt.setUserID(form.getOutIncAttestUserID()[i]);
								cmooIncAtt.setChange(form.getOutIncAttestChange()[i]);
								//cmooIncAtt.setCreateTime(form.getOutIncAttestCreateTime()[i].trim().equals("") ? ts : form.getOutIncAttestCreateTime()[i]);
								oIncAttests.add(cmooIncAtt);
							}//if
						}	
					//}//if
					form.setOutIncAttests(oIncAttests);
					appVO.setOutIncAttests(oIncAttests);
				}
				
				//-- Inbound Incomplete Attestation.
				if(form.getInIncAttestDate() != null){
					iIncAttests = new ArrayList();
					EEMApplicationVO cmoIIncAttests = null;
						for(int i=0; i<form.getInIncAttestDate().length; i++){
							if( !(form.getInIncAttestDate()[i].trim().equals("")) && !(form.getInIncAttestStatus()[i].trim().equals(""))){
								cmoIIncAttests = new EEMApplicationVO();
								cmoIIncAttests.setIndex(i+1);//(index);
								cmoIIncAttests.setAttempt( new Integer(i+1).toString() );//( new Integer(index).toString() );
								cmoIIncAttests.setDate(form.getInIncAttestDate()[i]);
								cmoIIncAttests.setStatus(form.getInIncAttestStatus()[i]);
								cmoIIncAttests.setUserID(form.getInIncAttestUserID()[i]);
								cmoIIncAttests.setChange(form.getInIncAttestChange()[i]);
								//cmoIIncAttests.setCreateTime(form.getInIncAttestCreateTime()[i].trim().equals("") ? ts : form.getInIncAttestCreateTime()[i]);
								iIncAttests.add(cmoIIncAttests);
							}//if
						}	
					//}//if
					form.setInIncAttests(iIncAttests);
					appVO.setInIncAttests(iIncAttests);
				}
				
				//-- Inbound late Attestation.
				if(form.getInLateoInitAttestDate() != null){
					ilAttests = new ArrayList();
					EEMApplicationVO cmoOLA = null;
						for(int i=0; i<form.getInLateoInitAttestDate().length; i++){
							if( !(form.getInLateoInitAttestDate()[i].trim().equals("")) && !(form.getInLateAttestStatus()[i].trim().equals(""))){
								cmoOLA = new EEMApplicationVO();
								cmoOLA.setIndex(i+1);//(index);
								cmoOLA.setAttempt( new Integer(i+1).toString() );//( new Integer(index).toString() );
								cmoOLA.setDate(form.getInLateoInitAttestDate()[i]);
								cmoOLA.setStatus(form.getInLateAttestStatus()[i]);
								cmoOLA.setUserID(form.getInLateAttestUserID()[i]);
								cmoOLA.setChange(form.getInLateAttestChange()[i]);
								//cmoOLA.setCreateTime(form.getInLateAttestCreateTime()[i].trim().equals("") ? ts : form.getInLateAttestCreateTime()[i]);
								ilAttests.add(cmoOLA);
							}//if										
						}	
					//}//if
					form.setInLateAttests(ilAttests);
					appVO.setInLateAttests(ilAttests);
					
				}
			//Updating to DB using service class.							
			if(!service.setApplLepNunCmo(conn, form.getCustomerId(), form.getApplicationId(), oiAttests, iiAttests, oIncAttests, iIncAttests, ilAttests,appVO)){
				form.setMessage("No Row(s) Updates");
			}
			else{
				form.setMessage("LEP Attestation Calls Updated");
			}
		}catch(Exception e){
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("In applLEPUpdate-LEP NUNCMO MANAGER::"+ e.getMessage());
		}	
	}
		else if(form.getSelectedLepApplSubTab().equalsIgnoreCase(EEMConstants.EEM_APP_TAB_LEP_ATTEST) ){
			appVO.setCustomerId(form.getCustomerId());
			appVO.setApplicationId(form.getApplicationId());
			appVO.setMbrHicNbr(form.getMbrHicNbr());
			appVO.setNbrUnCMonths(form.getNbrUnCMonths());
			appVO.setAttestLetMailDate(form.getAttestLetMailDate());
			appVO.setAttestLetExpDate(form.getAttestLetExpDate());
			appVO.setStatusCd(form.getStatusCd());
			appVO.setAppIncAttRcDt(form.getAppIncAttRcDt());
			appVO.setAppIncAttLetExpDt(form.getAppIncAttLetExpDt());
			appVO.setComptRespRecDate(form.getComptRespRecDate());
			appVO.setBrkInCoverage(form.getBrkInCoverage());
			appVO.setCredRXCoverage(form.getCredRXCoverage());
			appVO.setFromDate(form.getFromDate());
			appVO.setToDate(form.getToDate());			
			appVO.setCreateTime(form.getCreateTime());
			//appVO.setCreateUserId(form.getCreateUserId());
			//appVO.setLastUpdtUserId(form.getLastUpdtUserId());
			appVO.setCreateUserId(form.getLoginUser());
			appVO.setLastUpdtUserId(form.getLoginUser());
			appVO.setLastUpdtTime(form.getLastUpdtTime());
			appVO.setUncovMnthStrtDt(form.getUncovMnthStrtDt());
			
			
			// new LEP changes -- start
						appVO.setSelectedLepApplAttnSubTab(form
								.getSelectedLepApplAttnSubTab());
						appVO.setUserID(sessionHelper.getUserId());
						// new LEP changes -- end
		
			result = service.applLepAttestInfoUpdate(conn,appVO);
					
			appVO.setComptRespRecDate(null);
			appVO.setBrkInCoverage(null);
			appVO.setCredRXCoverage(null);
			appVO.setFromDate(null);
			appVO.setToDate(null);
			if (result) {
				form.setMessage("LEP-Attestation Update Success");
			} else {							
				form.setMessage("LEP-Attestation Update Failed");
			}
			
		}
		logger.info(LoggerConstants.methodEndLevel());
		
	}
	
	// new LEP changes -- start
	public void applLEPCovPtnlMnthsUpdate(Connection conn, SessionHelper sessionHelper, EEMContext context,
			EEMApplForm form, EEMApplicationVO appVO) throws ApplicationException, SQLException, ParseException {
		logger.info(LoggerConstants.methodStartLevel());
		boolean result = false;
		boolean result1 = false;
		String userId = sessionHelper.getUserId();
		EEMApplService service = new EEMApplService();
		boolean flag = false;
		if (form.getSelectedLepApplSubTab().equalsIgnoreCase("PtnlUnCovMnths")) {
			appVO.setCustomerId(form.getCustomerId());
			appVO.setApplicationId(form.getApplicationId());
			appVO.setLepEffDate(form.getReqDtCov());
			appVO.setTxtUncovMthStDt(form.getTxtUncovMthStDt());
			appVO.setTxtUncovMthEndDt(form.getTxtUncovMthEndDt());

			appVO.setCreateUserId(userId);
			appVO.setLastUpdtUserId(userId);
			// New LEP CR Start
			result = service.applPtnlUnCovMnthsinfoUpdate(conn, appVO);
			appVO.setTxtUncovMthStDt(null);
			appVO.setTxtUncovMthEndDt(null);
			if (result) {
				form.setMessage("LEP-Attestation Update Success");
			} else {
				form.setMessage("LEP-Attestation Update Failed");
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	// new LEP changes -- end

	//new LEP changes -- start
	public void applLepCovPtnlMnthsDelete(Connection conn,
			SessionHelper sessionHelper, EEMContext context, EEMApplForm form,
			EEMApplicationVO objVO) throws ParseException {
		logger.info(LoggerConstants.methodStartLevel());

		objVO.setUserID(sessionHelper.getUserId());

		boolean result = false;
		EEMApplService service = new EEMApplService();

		result = service.applPtnlUnCovMnthsinfoDelete(conn, objVO);

		if (result) {
			form.setMessage("LEP-Attestation Update Success");
		} else {
			form.setMessage("LEP-Attestation Update Failed");
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	// new LEP changes -- end
	public void applAttnSelect(Connection conn, SessionHelper sessionHelper,
			EEMContext context, EEMApplForm form, EEMApplicationVO objVO) {
		logger.info(LoggerConstants.methodStartLevel());
		boolean rslt;
		EEMApplService service = new EEMApplService();
		objVO.setCustomerId(form.getCustomerId());
		objVO.setApplicationId(form.getApplicationId());
		objVO.setMbrHicNbr(form.getMbrHicNbr());
		rslt = service.applAttnSelect(conn, objVO);
		form.setSelectedLepInfoRow(0);
		form.setEmApplLepAttestInfolistDisplay(objVO
				.getEmApplLepAttestInfolist());
		this.setApplLEPTimers(form, form.getCustomerId(), form.getApplicationId(), conn);
		form.setOutInitAttests(objVO.getOutInitAttests());
		form.setInInitAttests(objVO.getInInitAttests());
		form.setOutIncAttests(objVO.getOutIncAttests());
		form.setInIncAttests(objVO.getInIncAttests());
		form.setInLateAttests(objVO.getInLateAttests());
		logger.info(LoggerConstants.methodEndLevel());
	}
	// new LEP changes -- start
		public void applAttnInfoDelete(Connection conn,
				SessionHelper sessionHelper, EEMContext context, EEMApplForm form,
				EEMApplicationVO objVO) {
			logger.info(LoggerConstants.methodStartLevel());
			objVO.setUserID(sessionHelper.getUserId());
			boolean result = false;
			EEMApplService service = new EEMApplService();
			result = service.applAttnInfoDelete(conn, objVO);

			if (result) {
				form.setMessage("LEP-Attestation Delete Success");
			} else {
				form.setMessage("LEP-Attestation Delete Failed");
			}
			logger.info(LoggerConstants.methodEndLevel());

			// new LEP changes -- end
	}
		
public void setApplLEPTimers(EEMApplForm form, String customerId, int applID, Connection conn) {
	logger.info(LoggerConstants.methodStartLevel());
	EEMApplDao applDao = new EEMApplDao();

	try {
		EMApplTriggerVO trig1 = applDao.getApplTrigger(conn, customerId, applID,
				EEMConstants.TRIGGER_TYPE_FOLLOW_UP, "LE21");
		if (trig1 != null) {
			// System.out.println(" value of
			// le21"+trig1.getTriggerStatus());
			if (trig1.getTriggerStatus().equals(EEMConstants.TRIGGER_STATUS_OPEN))
				form.setLe21TimerCheck("true"); // LE21 timer open
			else
				form.setLe21TimerCheck("closed");// LE21 timer closed

		} else
			form.setLe21TimerCheck("false");
		// System.out.println(" value of timer"+form.getLe21TimerCheck());
		logger.debug(" value of Le21 timer check" + form.getLe21TimerCheck());

		EMApplTriggerVO trig2 = applDao.getApplTrigger(conn, customerId, applID,
				EEMConstants.TRIGGER_TYPE_FOLLOW_UP, "OBC3");
		if (trig2 != null) {

			if (trig2.getTriggerStatus().equals(EEMConstants.TRIGGER_STATUS_OPEN))
				form.setObc3TimerCheck("true"); // LE21 timer open
			else
				form.setObc3TimerCheck("closed");// LE21 timer closed

		} else
			form.setObc3TimerCheck("false");
		// System.out.println(" value of timer"+form.getObc3TimerCheck());
		logger.debug(" value of obc3 timer check" + form.getObc3TimerCheck());

		EMApplTriggerVO trig3 = applDao.getApplTrigger(conn, customerId, applID,
				EEMConstants.TRIGGER_TYPE_FOLLOW_UP, "OBC1");
		if (trig3 != null) {

			if (trig3.getTriggerStatus().equals(EEMConstants.TRIGGER_STATUS_OPEN))
				form.setObc1TimerCheck("true"); // LE21 timer open
			else
				form.setObc1TimerCheck("closed");// LE21 timer closed

		} else
			form.setObc1TimerCheck("false");
		// System.out.println(" value of timer"+form.getObc1TimerCheck());
		logger.debug(" value of Obc1 timer check" + form.getObc1TimerCheck());

		EMApplTriggerVO trig4 = applDao.getApplTrigger(conn, customerId, applID,
				EEMConstants.TRIGGER_TYPE_FOLLOW_UP, "OBC2");
		if (trig4 != null) {

			if (trig4.getTriggerStatus().equals(EEMConstants.TRIGGER_STATUS_OPEN))
				form.setObc2TimerCheck("true"); // LE21 timer open
			else
				form.setObc2TimerCheck("closed");// LE21 timer closed

		} else
			form.setObc2TimerCheck("false");
		// System.out.println(" value of timer"+form.getObc2TimerCheck());
		logger.debug(" value of Obc2 timer check" + form.getObc2TimerCheck());

	} catch (Exception e) {
		logger.error(LoggerConstants.exceptionMessage(e.toString()));
		logger.debug(" Getting  Timer status: " + e.getMessage());
	}
	logger.info(LoggerConstants.methodEndLevel());

}

}
