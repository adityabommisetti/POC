package com.ps.mss.manager;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.businesslogic.CreateAnomExcelService;
import com.ps.mss.businesslogic.CreateAnomaliesPdfService;
import com.ps.mss.businesslogic.CreateDiscExcelService;
import com.ps.mss.businesslogic.CreateDiscPdfService;
import com.ps.mss.businesslogic.CreatePaymentExcelService;
import com.ps.mss.businesslogic.CreatePaymentPdfService;
import com.ps.mss.businesslogic.McaidILService;
import com.ps.mss.dao.McaidILDao;
import com.ps.mss.dao.model.McaidAnomSummDetailDataVO;
import com.ps.mss.dao.model.McaidAnomSummDetailVO;
import com.ps.mss.dao.model.McaidFcloDetailVO;
import com.ps.mss.db.MFUserPersistence;
import com.ps.mss.db.McaidReconCodeCache;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.McaidReconConstants;
import com.ps.mss.helper.McaidReconHelper;
import com.ps.mss.model.McaidReconAnomVO;
import com.ps.mss.model.McaidReconContext;
import com.ps.mss.model.McaidReconDiscVO;
import com.ps.mss.model.McaidReconFcloVO;
import com.ps.mss.model.McaidReconFileVO;
import com.ps.mss.model.McaidReconPaymentVO;
import com.ps.mss.security.SessionManager;
import com.ps.mss.web.forms.McaidReconAnomForm;
import com.ps.mss.web.forms.McaidReconDiscForm;
import com.ps.mss.web.forms.McaidReconFileForm;
import com.ps.mss.web.forms.McaidReconPaymentForm;
import com.ps.mss.web.helper.SessionHelper;
import com.ps.net.FTPClient;
import com.ps.util.DateUtil;
import com.ps.util.StringUtil;

public class McaidILManager extends McaidReconAbsManager {
	private static Logger logger=(Logger) LoggerFactory.getLogger(McaidILManager.class);
	
	public McaidILManager() {
	}

	public String discInitialization(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconDiscForm mcaidDiscForm, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";

		McaidReconDiscVO discVO = context.getDiscrepanciesVO();
		McaidILService ilService = new McaidILService();
		List<McaidReconDiscVO> mcaidDiscList = null;
		List li = new ArrayList();
		String mfId = sessionHelper.getMfId();
		try {
			// if( discVO.getMcaidDiscDsbPBPLst() == null ||
			// discVO.getMcaidDiscDsbPBPLst().isEmpty()){
			ilService.getILDiscDashBoardPBPs(conn, discVO, mfId);
			// }

			mcaidDiscForm.setMcaidDiscDsbPBPLst(discVO.getMcaidDiscDsbPBPLst());
			McaidReconCodeCache objCache = McaidReconCodeCache.getInstance(mfId);
			mcaidDiscForm.setSummSrchPbpLst(objCache.getLstPbp());
			mcaidDiscForm.setSummSrchStatusLst(objCache.getLstDiscrpStatus());
			mcaidDiscForm.setDescrepancyCategoryList(objCache.getDescrepancyCategoryList());

		} catch (ApplicationException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
		}

		mappingTarget = "ILmcaidDisc";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// discInitialization
	
	//IFOX-00407694-FCLO/WRTO Changes: start
	public String fcloInitialization(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconDiscForm mcaidFcloForm, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";

		//Fetch your VO
		McaidReconFcloVO fcloVO = context.getForceCloseVO();
	/*	McaidReconDiscVO discVO = context.getDiscrepanciesVO();
		//McaidILService ilService = new McaidILService();
		//List<McaidReconDiscVO> mcaidDiscList = null;
		//List li = new ArrayList();
		String mfId = sessionHelper.getMfId();
		//mcaidFcloForm.setMcaidDiscDsbPBPLst(discVO.getMcaidDiscDsbPBPLst());
		McaidReconCodeCache objCache = McaidReconCodeCache.getInstance(mfId);
		//set in disc form VO
		//set in your VO 
		mcaidFcloForm.setSummSrchPbpLst(objCache.getLstPbp());
		//mcaidFcloForm.setSummSrchStatusLst(objCache.getLstDiscrpStatus());
		//mcaidFcloForm.setDescrepancyCategoryList(objCache.getDescrepancyCategoryList());
*/
		String mfId = sessionHelper.getMfId();
		McaidReconCodeCache objCache = McaidReconCodeCache.getInstance(mfId);
		mcaidFcloForm.setSummSrchPbpLst(objCache.getLstPbp());
		mcaidFcloForm.setEffDate("");
		mcaidFcloForm.setUserId(sessionHelper.getUserId());
		
		mappingTarget = "ILmcaidDiscFCLO";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}
	//IFOX-00407694-FCLO/WRTO Changes: end
	public String fileInitialization(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconFileForm mcaidFileForm, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconFileVO fileVO = context.getFileVO();
		McaidILDao ilDao = new McaidILDao();
		String mfId = sessionHelper.getMfId();
		try {
			setFileSrchFormToVO(mcaidFileForm, fileVO);
			if(StringUtil.nonNullTrim(fileVO.getSearchCyclePeriod()).equals("") && StringUtil.nonNullTrim(fileVO.getSearchFileStatus()).equals("")&&
					StringUtil.nonNullTrim(fileVO.getSearchPbp()).equals("") && StringUtil.nonNullTrim(fileVO.getSearchTypeOfFile()).equals("")	
					)
				ilDao.getFileSearchLists(conn, mfId, fileVO);
			List files = ilDao.getFileLists(conn, mfId, fileVO, "first");
			fileVO.setMcaidFilesLst(files);
			setFileVOToForm(mcaidFileForm, fileVO);
			McaidReconCodeCache objCache = McaidReconCodeCache.getInstance(mfId);
			
			mcaidFileForm.setPbpList(objCache.getPbpLstIL());
			mcaidFileForm.setFileStatusList(objCache.getFileStatusIL());
			mcaidFileForm.setTypeOfFileList(objCache.getFileTypeIL());
			mcaidFileForm.setCyclePeriodList(objCache.getCyclePeriodIL());

		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
		}

		mappingTarget = "NMmcaidFileInventory";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// fileInitialization
	
	public String getFileListSearch(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconFileForm mcaidFileForm, String move) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconFileVO fileVO = context.getFileVO();
		McaidILDao ilDao = new McaidILDao();
		String mfId = sessionHelper.getMfId();
		try {
			setFileSrchFormToVO(mcaidFileForm, fileVO);
			List files = ilDao.getFileLists(conn, mfId, fileVO, move);
			fileVO.setMcaidFilesLst(files);
			setFileVOToForm(mcaidFileForm, fileVO);
			McaidReconCodeCache objCache = McaidReconCodeCache.getInstance(mfId);
			
			mcaidFileForm.setPbpList(objCache.getPbpLstIL());
			mcaidFileForm.setFileStatusList(objCache.getFileStatusIL());
			mcaidFileForm.setTypeOfFileList(objCache.getFileTypeIL());
			mcaidFileForm.setCyclePeriodList(objCache.getCyclePeriodIL());
			//fileInitialization(conn, sessionHelper, context, mcaidFileForm, null);
			
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
		}

		mappingTarget = "NMmcaidFileInventory";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// fileInitialization
	
	/*public String printMcaidFile(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			HttpServletRequest request, HttpServletResponse response, McaidReconFileForm mcaidFileForm,
			String printOption, String printSubMenu, String pageRange) {

		McaidReconFileVO fileVO = context.getFileVO();
		//McaidReconAnomVO discAnomVO = context.getDiscAnamolyVO();

		String mappingTarget = "NMmcaidFileInventory";

		if (printOption.equals("Print")) {
			mappingTarget = "filePrint";
			
				if (pageRange.equals("Current")) {
					//mcaidFileForm.setSummPageLabel1(fileVO.getSummPageLabel1());
					mcaidFileForm.set
					mcaidFileForm.setAnomSummDetailDataVo(fileVO.getAnomSummDetailDataVo());
				} else {// ALL Pages
					List listData = new McaidILService().getDiscSummListPrintData(conn, sessionHelper.getMfId(),
							discAnomVO);
					mcaidDiscForm.setSummAnomListLst(listData);
				}
			}
		else if (printOption.equals("CSV")) {
			try {
				HSSFWorkbook workbook = null;
				if (printSubMenu.equals(McaidReconConstants.SUBMENU_DISC_DASHBOARD)) {
					workbook = new CreateDiscExcelService().createDashboardWorkbook(discVO.getMcaidDiscDsbPBPLst());
				} else if (printSubMenu.equals(McaidReconConstants.SUBMENU_DISC_DASHBOARD_DETAIL)) {// Intermediate
																									// Summary
																									// Screen
					workbook = new CreateDiscExcelService()
							.createDashboardSummaryWorkbook(discAnomVO.getDiscrpDetailsLst());// New
																								// Method
																								// to
																								// written
																								// for
																								// detail
																								// screen
																								// csv
				}

				else {// SUMMARY
					if (pageRange.equals("Current")) {
						workbook = new CreateDiscExcelService().createSummaryWorkbook(discAnomVO.getSummAnomListLst());
					} else {// ALL Pages
						List listData = new McaidILService().getDiscSummListPrintData(conn, sessionHelper.getMfId(),
								discAnomVO);
						workbook = new CreateDiscExcelService().createSummaryWorkbook(listData);
					}
				} // SUMMARY-else
				response.setHeader("Content-Disposition", "attachment; filename=DiscrepancyExport.xls");
				ServletOutputStream out = response.getOutputStream();
				workbook.write(out);
				out.flush();
				out.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if (printOption.equals("PDF")) {/// PDF
			ByteArrayOutputStream report = null;
			try {
				 Payment Dash-board 
				if (printSubMenu.equals(McaidReconConstants.SUBMENU_DISC_DASHBOARD)) {
					report = new CreateDiscPdfService().createDashboardDescPDFReport(discVO.getMcaidDiscDsbPBPLst());
				}
				if (printSubMenu.equals(McaidReconConstants.SUBMENU_DISC_DASHBOARD_DETAIL)) {// Discrepancy
																								// Intermediate
																								// Summary
																								// Screen
					report = new CreateDiscPdfService().createDashboardSummaryPDFReport(
							discAnomVO.getDiscrpDetailsLst(), discAnomVO.getSummPageLabel1()); // write
																								// new
																								// method
				}

				 Payment Summary 
				else {
					if (pageRange.equals("Current")) {
						report = new CreateDiscPdfService().currentSummaryDescPDFReport(discAnomVO.getSummPageLabel1(),
								discAnomVO.getSummAnomListLst(), discAnomVO.getAnomSummDetailDataVo());
					} else {// ALL Pages

						List listData = new McaidILService().getDiscSummListPrintData(conn, sessionHelper.getMfId(),
								discAnomVO);
						report = new CreateDiscPdfService().createAllPagesSummaryDescPDFReport(listData);

					}
				}
				response.setContentType("application/pdf");
				response.setHeader("content-disposition", "attachment; filename=DiscExport.pdf");
				response.setContentLength(report.size());
				ServletOutputStream servletStream = null;
				servletStream = response.getOutputStream();
				report.writeTo(servletStream);
				servletStream.flush();
				servletStream.close();
				report.close();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
		return mappingTarget;
	}// printMcaidDisc()

	*/

	public String paymentInitialization(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconPaymentForm mcaidPaymentForm, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";

		McaidReconPaymentVO paymentVO = context.getPaymentVO();
		McaidILService ilService = new McaidILService();
		List<McaidReconPaymentVO> mcaidPymntList = null;
		List li = new ArrayList();
		String mfId = sessionHelper.getMfId();
		try {
			/*
			 * if( paymentVO.getMcaidPymntDsbPBPLst() == null ||
			 * paymentVO.getMcaidPymntDsbPBPLst().isEmpty()){
			 */
			paymentVO.setDateType(mcaidPaymentForm.getDateType());
			logger.debug("dateType==" + paymentVO.getDateType());
			ilService.getILPaymentDashBoardPBPs(conn, paymentVO, mfId, paymentVO.getDateType());
			/* } */
			mcaidPaymentForm.setMcaidPymntDsbPBPLst(paymentVO.getMcaidPymntDsbPBPLst());
			McaidReconCodeCache objCache = McaidReconCodeCache.getInstance(mfId);
			mcaidPaymentForm.setLstpbpIdPayment(objCache.getLstPbp());

		} catch (ApplicationException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
		}
		mappingTarget = "ILmcaidPayment";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// paymentInitialization

	public String anomalyInitialization(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconAnomForm mcaidAnomForm, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";

		McaidReconAnomVO anomVO = context.getAnamolyVO();
		McaidILService ilService = new McaidILService();
		String mfId = sessionHelper.getMfId();
		try {
			// if( anomVO.getMcaidAnomDsbPBPLst() == null ||
			// anomVO.getMcaidAnomDsbPBPLst().isEmpty()){
			ilService.getAnomDashBoardPBPs(conn, anomVO, mfId);
			// }
			mcaidAnomForm.setMcaidAnomDsbPBPLst(anomVO.getMcaidAnomDsbPBPLst());
			McaidReconCodeCache objCache = McaidReconCodeCache.getInstance(mfId);
			mcaidAnomForm.setSummSrchPbpLst(objCache.getLstPbp());
			mcaidAnomForm.setSummSrchStatusLst(objCache.getLstAnomStatus());
			mcaidAnomForm.setAnamolyCategoryList(objCache.getAnamolyCategoryList());

		} catch (ApplicationException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
		}

		mappingTarget = "ILmcaidAnom";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// anomalyInitialization

	public String paymentDsbSubMenuSelect(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconPaymentForm mcaidPaymentForm, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconPaymentVO paymentVO = context.getPaymentVO();
		String mfId = sessionHelper.getMfId();
		this.paymentInitialization(conn, sessionHelper, context, mcaidPaymentForm, request);
		// ZZZZZZZZ
		/*
		 * mcaidPaymentForm.setMcaidPymntDsbPBPLst(paymentVO.
		 * getMcaidPymntDsbPBPLst());
		 */paymentVO.setMcaidPymntSummMedicaidLst(null);
		mappingTarget = "ILmcaidPayment";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// paymentDsbSubMenuSelect

	public String getpaymentSummData(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconPaymentForm mcaidPaymentForm) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconPaymentVO paymentVO = context.getPaymentVO();
		String mfId = sessionHelper.getMfId();

		paymentVO.resetSummCmsPaidAndPlanExpectedValues();
		setpaymentSummInputDataToVO(mcaidPaymentForm, paymentVO);

		new McaidILService().getpaymentSummData(conn, mfId, paymentVO);
		/*
		 * mcaidPaymentForm.setMcaidPymntSummLst(paymentVO.getMcaidPymntSummLst(
		 * ));
		 * mcaidPaymentForm.setSummPageLabel1(paymentVO.getSummPageLabel1());
		 * mcaidPaymentForm.setSummDataCmsPaid(paymentVO.getSummDataCmsPaid());
		 * mcaidPaymentForm.setSummDataDiffrence(paymentVO.getSummDataDiffrence(
		 * )); mcaidPaymentForm.setSummDataPlanExpected(paymentVO.
		 * getSummDataPlanExpected());
		 */
		new McaidILService().getpaymentSummDetails(conn, mfId, paymentVO, "");
		/*
		 * mcaidPaymentForm.setMcaidPymntSummDetailLst(paymentVO.
		 * getMcaidPymntSummDetailLst());
		 * mcaidPaymentForm.setSummDetailCmsPaid(paymentVO.getSummDetailCmsPaid(
		 * )); mcaidPaymentForm.setSummDetailPlanExpected(paymentVO.
		 * getSummDetailPlanExpected());
		 * mcaidPaymentForm.setSummDetailDiffrence(paymentVO.
		 * getSummDetailDiffrence());
		 */
		setPaySummDataVOtoForm(mcaidPaymentForm, paymentVO, mfId);// this
																	// replaced
																	// above 2
																	// commented
																	// sections.
		mappingTarget = "ILmcaidPaymentSummary";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// getpaymentSummData()

	public String getpaymentSummDetails(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconPaymentForm mcaidPaymentForm) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconPaymentVO paymentVO = context.getPaymentVO();
		String mfId = sessionHelper.getMfId();
		paymentVO.setSummSrchPbp(mcaidPaymentForm.getSummSrchPbp());
		new McaidILService().getpaymentSummDetails(conn, mfId, paymentVO, "");
		mcaidPaymentForm.setMcaidPymntSummDetailLst(paymentVO.getMcaidPymntSummDetailLst());
		mcaidPaymentForm.setSummDetailCmsPaid(paymentVO.getSummDetailCmsPaid());
		mcaidPaymentForm.setSummDetailPlanExpected(paymentVO.getSummDetailPlanExpected());
		mcaidPaymentForm.setSummDetailDiffrence(paymentVO.getSummDetailDiffrence());
		mappingTarget = "ILmcaidPaymentSummary";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// getpaymentSummDetails()

	public String getpaymentSummMedicaids(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconPaymentForm mcaidPaymentForm, String move) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconPaymentVO paymentVO = context.getPaymentVO();
		String mfId = sessionHelper.getMfId();
		paymentVO.setSummSrchPaymentType(mcaidPaymentForm.getSummSrchPaymentType());
		new McaidILService().getpaymentSummMedicaids(conn, mfId, paymentVO, move);
		setPaySummDataVOtoForm(mcaidPaymentForm, paymentVO, mfId);
		mappingTarget = "ILmcaidPaymentSummary";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// getpaymentSummMedicaids()

	private void setpaymentSummInputDataToVO(McaidReconPaymentForm form, McaidReconPaymentVO vo) {
		logger.info(LoggerConstants.methodStartLevel());
		vo.setSummSrchPbp(form.getSummSrchPbp());
		vo.setSummSrchYear(form.getSummSrchYear());
		vo.setSummSrchQtr(form.getSummSrchQtr());
		vo.setSummSrchMonth(form.getSummSrchMonth());
		logger.info(LoggerConstants.methodEndLevel());
	}// setpaymentSummInputDataToVO()

	public String setPaySummDataVOtoForm(McaidReconPaymentForm mcaidPaymentForm, McaidReconPaymentVO paymentVO,
			String custId) {
		logger.info(LoggerConstants.methodStartLevel());

		mcaidPaymentForm.setMcaidPymntSummLst(paymentVO.getMcaidPymntSummLst());
		mcaidPaymentForm.setSummPageLabel1(paymentVO.getSummPageLabel1());
		mcaidPaymentForm.setSummDataCmsPaid(paymentVO.getSummDataCmsPaid());

		// Setting SummDataDiffrence value to 'null' so that it recalculates the
		// sum in payment summary dash board instead of pulling directly from
		// the form
		paymentVO.setSummDataDiffrence(null);

		mcaidPaymentForm.setSummDataDiffrence(paymentVO.getSummDataDiffrence());
		mcaidPaymentForm.setSummDataPlanExpected(paymentVO.getSummDataPlanExpected());

		mcaidPaymentForm.setMcaidPymntSummDetailLst(paymentVO.getMcaidPymntSummDetailLst());
		mcaidPaymentForm.setSummDetailCmsPaid(paymentVO.getSummDetailCmsPaid());
		mcaidPaymentForm.setSummDetailPlanExpected(paymentVO.getSummDetailPlanExpected());
		mcaidPaymentForm.setSummDetailDiffrence(paymentVO.getSummDetailDiffrence());

		mcaidPaymentForm.setMcaidPymntSummMedicaidLst(paymentVO.getMcaidPymntSummMedicaidLst());
		mcaidPaymentForm.setSummPageLabel2(paymentVO.getSummPageLabel2());
		mcaidPaymentForm.setSummMedicLstPageNbr(paymentVO.getSummMedicLstPageNbr());
		mcaidPaymentForm.setSummMedicLstPageType(paymentVO.getSummMedicLstPageType());
		McaidReconCodeCache objCache = McaidReconCodeCache.getInstance(custId);
		mcaidPaymentForm.setLstpbpIdPayment(objCache.getLstPbp());
		// For Payment Search labels :start
		mcaidPaymentForm.setPbpIdPayment(paymentVO.getSummSrchPbp());

		mcaidPaymentForm.setFromDate(paymentVO.getFromDate());
		mcaidPaymentForm.setToDate(paymentVO.getToDate());

		if (!StringUtil.nonNullTrim(paymentVO.getSummSrchMonth()).equals("")) {

			mcaidPaymentForm.setFromDate(paymentVO.getSummSrchMonth() + "/" + paymentVO.getSummSrchYear());
			mcaidPaymentForm.setToDate(paymentVO.getSummSrchMonth() + "/" + paymentVO.getSummSrchYear());

		} else {

			if (!StringUtil.nonNullTrim(paymentVO.getSummSrchQtr()).equals("")) {

				if (paymentVO.getSummSrchQtr().startsWith("1")) {
					mcaidPaymentForm.setFromDate("01" + "/" + paymentVO.getSummSrchYear());
					mcaidPaymentForm.setToDate("03" + "/" + paymentVO.getSummSrchYear());
				}
				if (paymentVO.getSummSrchQtr().startsWith("2")) {
					mcaidPaymentForm.setFromDate("04" + "/" + paymentVO.getSummSrchYear());
					mcaidPaymentForm.setToDate("06" + "/" + paymentVO.getSummSrchYear());
				}
				if (paymentVO.getSummSrchQtr().startsWith("3")) {
					mcaidPaymentForm.setFromDate("07" + "/" + paymentVO.getSummSrchYear());
					mcaidPaymentForm.setToDate("09" + "/" + paymentVO.getSummSrchYear());
				}
				if (paymentVO.getSummSrchQtr().startsWith("4")) {
					mcaidPaymentForm.setFromDate("10" + "/" + paymentVO.getSummSrchYear());
					mcaidPaymentForm.setToDate("12" + "/" + paymentVO.getSummSrchYear());
				}

			} else {
				if (!StringUtil.nonNullTrim(mcaidPaymentForm.getSummSrchYear()).equals("")) {
					mcaidPaymentForm.setFromDate("01" + "/" + mcaidPaymentForm.getSummSrchYear());
					mcaidPaymentForm.setToDate("12" + "/" + mcaidPaymentForm.getSummSrchYear());
				}
			}
		}
		// For Payment Search labels :end
		logger.info(LoggerConstants.methodEndLevel());
		return "ILmcaidPaymentSummary";

	}// setPaySummDataVOtoForm()

	// *********************ANOMALY-START*************************

	public String anomDsbSubMenuSelect(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconAnomForm mcaidAnomForm, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconAnomVO anomVO = context.getAnamolyVO();
		// String mfId = sessionHelper.getMfId();
		this.anomalyInitialization(conn, sessionHelper, context, mcaidAnomForm, request);
		// mcaidAnomForm.setMcaidAnomDsbPBPLst(anomVO.getMcaidAnomDsbPBPLst());
		mappingTarget = "ILmcaidAnom";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// anomDsbSubMenuSelect

	/*
	 * public String getAnomSummListData(Connection conn, SessionHelper
	 * sessionHelper, McaidReconContext context, McaidReconAnomForm
	 * mcaidAnomForm, String move){ String mappingTarget = "error";
	 * McaidReconAnomVO anomVO = context.getAnamolyVO(); String mfId =
	 * sessionHelper.getMfId();
	 * anomVO.setSummSrchPbp(mcaidAnomForm.getSummSrchPbp());
	 * anomVO.setSummSrchYear(mcaidAnomForm.getSummSrchYear());
	 * anomVO.setSummSrchQtr(mcaidAnomForm.getSummSrchQtr());
	 * anomVO.setSummSrchMonth(mcaidAnomForm.getSummSrchMonth());
	 * anomVO.setSummSrchStatus(mcaidAnomForm.getSummSrchStatus());
	 * 
	 * boolean isListDataEmpty = new McaidILService().getAnomSummListData(conn,
	 * mfId, anomVO, move); setAnomSummListDataVOtoForm(mcaidAnomForm, anomVO);
	 * 
	 * if(! isListDataEmpty){ getAnomSummDetailData(conn, sessionHelper,
	 * context, mcaidAnomForm, 1); } mappingTarget = "ILmcaidAnomSummary";
	 * return mappingTarget;
	 * 
	 * }//getAnomSummListData()
	 */
	public String getAnomSummListData(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconAnomForm mcaidAnomForm, String move, String from) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconAnomVO anomVO = context.getAnamolyVO();
		String mfId = sessionHelper.getMfId();
		if (from != null) {
			anomVO.setSummAnomLstOptFrom(from);
		}

		if (anomVO.getSummAnomLstOptFrom().equals("DASHBOARD")) {
			setAnomSummDsbSrchFormToVO(mcaidAnomForm, anomVO);
		} else {
			setAnomSummGoSrchFormToVO(mcaidAnomForm, anomVO);
		}

		boolean hasListData = new McaidILService().getAnomSummListData(conn, mfId, anomVO, move);
		setAnomSummListDataVOtoForm(mcaidAnomForm, anomVO);

		if (!hasListData) {
			getAnomSummDetailData(conn, sessionHelper, context, mcaidAnomForm, 1);
		}
		setAnomSrchSummContentVOToForm(mcaidAnomForm, anomVO, mfId);
		mappingTarget = "ILmcaidAnomSummary";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// getAnomSummListData()

	private void setAnomSrchSummContentVOToForm(McaidReconAnomForm form, McaidReconAnomVO anomVO, String custId) {
		logger.info(LoggerConstants.methodStartLevel());
		McaidReconCodeCache objCache = McaidReconCodeCache.getInstance(custId);
		logger.debug("McaidILManager.setAnomSrchSummContentVOToForm()" + objCache.getLstPbp().size());
		form.setSummSrchPbpLst(objCache.getLstPbp());
		form.setSummSrchStatusLst(objCache.getLstAnomStatus());
		form.setSummSrchTypeLst(objCache.getLstAnomType());

		// Details Status List
		form.setSummDetailStatusLst(objCache.getLstDetailAnomStatus());
		form.setSummDetailStatusChngLst(objCache.getLstDetailAnomStatusChng());
		// Details Status List

		form.setAnamolyCategoryList(objCache.getAnamolyCategoryList());

		// For Anaomalies Search Functionality :Start
		if (StringUtil.nonNullTrim(anomVO.getSummAnomLstOptFrom()).equals("")
				|| anomVO.getSummAnomLstOptFrom().equals("DETAILS")
				|| anomVO.getSummAnomLstOptFrom().equals("DASHBOARD")) {
			form.setSummSrchPbp(anomVO.getSummSrchPbp());
			form.setSummSrchGoPbp(anomVO.getSummSrchPbp());
			form.setSummSrchStatus(anomVO.getSummSrchStatus());
			form.setSummSrchGoStatus(anomVO.getSummSrchStatus());
			if (null != anomVO.getAnomSummDetailDataVo())
			form.setChangeStatus(anomVO.getAnomSummDetailDataVo().getStatus());
			if (!StringUtil.nonNullTrim(anomVO.getSummSrchMonth()).equals("")) {

				form.setSummSrchFromEffDate(anomVO.getSummSrchMonth() + "/" + anomVO.getSummSrchYear());
				form.setSummSrchToEffDate(anomVO.getSummSrchMonth() + "/" + anomVO.getSummSrchYear());

			} else {

				if (!StringUtil.nonNullTrim(anomVO.getSummSrchQtr()).equals("")) {

					if (anomVO.getSummSrchQtr().startsWith("1")) {
						form.setSummSrchFromEffDate("01" + "/" + anomVO.getSummSrchYear());
						form.setSummSrchToEffDate("03" + "/" + anomVO.getSummSrchYear());
					}
					if (anomVO.getSummSrchQtr().startsWith("2")) {
						form.setSummSrchFromEffDate("04" + "/" + anomVO.getSummSrchYear());
						form.setSummSrchToEffDate("06" + "/" + anomVO.getSummSrchYear());
					}
					if (anomVO.getSummSrchQtr().startsWith("3")) {
						form.setSummSrchFromEffDate("07" + "/" + anomVO.getSummSrchYear());
						form.setSummSrchToEffDate("09" + "/" + anomVO.getSummSrchYear());
					}
					if (anomVO.getSummSrchQtr().startsWith("4")) {
						form.setSummSrchFromEffDate("10" + "/" + anomVO.getSummSrchYear());
						form.setSummSrchToEffDate("12" + "/" + anomVO.getSummSrchYear());
					}

				} else {
					if (!StringUtil.nonNullTrim(anomVO.getSummSrchYear()).equals("")) {
						form.setSummSrchFromEffDate("01" + "/" + anomVO.getSummSrchYear());
						form.setSummSrchToEffDate("12" + "/" + anomVO.getSummSrchYear());
					}
				}
			}
			if (null != anomVO.getSummSrchDiscrpCd() && !anomVO.getSummSrchDiscrpCd().trim().equals(""))
				form.setAnamolyCategory(anomVO.getSummSrchDiscrpCd());
			else
				form.setAnamolyCategory(anomVO.getDiscrepancyCategory());

			form.setSummSrchMedicaidId(anomVO.getSummSrchMedicaidId());

		} else {
			form.setSummSrchPbp(anomVO.getSummSrchGoPbp());
			form.setSummSrchGoPbp(anomVO.getSummSrchGoPbp());
			form.setSummSrchStatus(anomVO.getSummSrchGoStatus());
			form.setSummSrchGoStatus(anomVO.getSummSrchGoStatus());
			form.setSummSrchMedicaidId(anomVO.getSummSrchMedicaidId());
			form.setSummSrchFromEffDate(anomVO.getSummSrchFromEffDate());
			form.setSummSrchToEffDate(anomVO.getSummSrchToEffDate());
			form.setSummSrchFromUpdtDate(anomVO.getSummSrchFromUpdtDate());
			form.setSummSrchToUpdtDate(anomVO.getSummSrchToUpdtDate());
			form.setSummSrchUpdtUserId(anomVO.getSummSrchUpdtUserId());
			//State and plan value addition: start
			form.setSummSrchStateValue(anomVO.getSummSrchStateValue());
			form.setSummSrchPlanValue(anomVO.getSummSrchPlanValue());
			//State and plan value addition: end
			form.setChangeStatus(anomVO.getAnomSummDetailDataVo().getStatus());
			if (null != anomVO.getAnomSummDetailDataVo())
				form.setChangeStatus(anomVO.getAnomSummDetailDataVo().getStatus());
			// form.setDiscrepancyCategory(discrpAnomVO.getSummSrchDiscrpCd());

			if (StringUtil.nonNullTrim(anomVO.getSummAnomLstOptFrom()).equals("DETAILS"))
				form.setAnamolyCategory(anomVO.getSummSrchDiscrpCd());
			else
				form.setAnamolyCategory(anomVO.getDiscrepancyCategory());
		}
		// For Anaomalies Search Functionality :end
		form.setSummSrchType(anomVO.getSummSrchType());
		form.setAnamolyCategory(anomVO.getAnamolyCategory());
		form.setSummSrchMedicaidId(anomVO.getSummSrchMedicaidId());

		form.setMethod("");
		logger.info(LoggerConstants.methodEndLevel());
	}// setAnomSrchSummContentVOToForm()

	private void setAnomSummDsbSrchFormToVO(McaidReconAnomForm mcaidAnomForm, McaidReconAnomVO anomVO) {
		logger.info(LoggerConstants.methodStartLevel());
		anomVO.setSummSrchPbp(mcaidAnomForm.getSummSrchPbp());
		//Setting correct PBP value to avoid blank PBP in details screen : start
		if(StringUtil.nonNullTrim(anomVO.getSummSrchPbp()).equals(""))
			anomVO.setSummSrchPbp(mcaidAnomForm.getSummSrchGoPbp());
		//Setting correct PBP value to avoid blank PBP in details screen : end
		anomVO.setSummSrchYear(mcaidAnomForm.getSummSrchYear());
		anomVO.setSummSrchQtr(mcaidAnomForm.getSummSrchQtr());
		anomVO.setSummSrchMonth(mcaidAnomForm.getSummSrchMonth());
		anomVO.setSummSrchStatus(mcaidAnomForm.getSummSrchStatus());
		anomVO.setSummSrchDiscrpCd(mcaidAnomForm.getSummSrchAnmlyCd());
		anomVO.setAnamolyCategory(mcaidAnomForm.getAnamolyCategory());
		//Fix for effective period search : start
		anomVO.setSummSrchFromEffDate(mcaidAnomForm.getSummSrchFromEffDate());
		anomVO.setSummSrchToEffDate(mcaidAnomForm.getSummSrchToEffDate());
		//Fix for effective period search : end 
		logger.info(LoggerConstants.methodEndLevel());
	}// setAnomSummDsbSrchFormToVO()

	private void setFileSrchFormToVO(McaidReconFileForm mcaidFileForm, McaidReconFileVO fileVO) {
		logger.info(LoggerConstants.methodStartLevel());
		fileVO.setSearchPbp(mcaidFileForm.getSearchPbp());
		fileVO.setSearchCyclePeriod(mcaidFileForm.getSearchCyclePeriod());
		fileVO.setSearchFileStatus(mcaidFileForm.getSearchFileStatus());
		fileVO.setSearchTypeOfFile(mcaidFileForm.getSearchTypeOfFile());
		fileVO.setCurrentPageNbr(mcaidFileForm.getCurrentPageNbr());
		fileVO.setFileLstPageType(mcaidFileForm.getFileLstPageType());
		logger.info(LoggerConstants.methodEndLevel());
	}
	//IFOX-00407694-FCLO/WRTO Changes: start
	private void setDiscFcloDataFormtoVO(McaidReconDiscForm mcaidDiscForm, McaidReconAnomVO anomVO) {
		logger.info(LoggerConstants.methodStartLevel());
		anomVO.setMedicaidId(mcaidDiscForm.getMedicaidId());
		anomVO.setEffDate(mcaidDiscForm.getEffDate());
		anomVO.setUserId(mcaidDiscForm.getUserId());
		anomVO.setDiscrpFcloLst(mcaidDiscForm.getDiscrpFcloLst());
		anomVO.setDefaultValue(mcaidDiscForm.getDefaultValue());
		anomVO.setReopenDates(mcaidDiscForm.getReopenDates());
		anomVO.setFcloStartDate(mcaidDiscForm.getFcloStartDate());
		anomVO.setFcloEndDate(mcaidDiscForm.getFcloEndDate());
		anomVO.setChangedComment(mcaidDiscForm.getChangedComment());
		logger.info(LoggerConstants.methodEndLevel());
	}
	//IFOX-00407694-FCLO/WRTO Changes: end
	private void setFileVOToForm(McaidReconFileForm mcaidFileForm, McaidReconFileVO fileVO) {
		logger.info(LoggerConstants.methodStartLevel());
		mcaidFileForm.setTotalPayments(fileVO.getTotalPayments());
		mcaidFileForm.setTotalRecords(fileVO.getTotalRecords());
		mcaidFileForm.setMcaidFilesLst(fileVO.getMcaidFilesLst());
		mcaidFileForm.setCurrentPageNbr(fileVO.getCurrentPageNbr());
		mcaidFileForm.setFileLstPageType(fileVO.getFileLstPageType());
		mcaidFileForm.setSearchCyclePeriod(fileVO.getSearchCyclePeriod());
		logger.info(LoggerConstants.methodEndLevel());
	}
	private void setAnomSummGoSrchFormToVO(McaidReconAnomForm mcaidAnomForm, McaidReconAnomVO anomVO) {
		logger.info(LoggerConstants.methodStartLevel());
		anomVO.setSummSrchGoPbp(mcaidAnomForm.getSummSrchGoPbp());
		anomVO.setSummSrchGoStatus(mcaidAnomForm.getSummSrchGoStatus());
		anomVO.setSummSrchType(mcaidAnomForm.getSummSrchType());
		anomVO.setSummSrchMedicaidId(mcaidAnomForm.getSummSrchMedicaidId());
		anomVO.setSummSrchFromEffDate(mcaidAnomForm.getSummSrchFromEffDate());
		anomVO.setSummSrchToEffDate(mcaidAnomForm.getSummSrchToEffDate());
		anomVO.setSummSrchFromUpdtDate(mcaidAnomForm.getSummSrchFromUpdtDate());
		anomVO.setSummSrchToUpdtDate(mcaidAnomForm.getSummSrchToUpdtDate());
		anomVO.setSummSrchUpdtUserId(mcaidAnomForm.getSummSrchUpdtUserId());
		//State and plan value addition: start
		anomVO.setSummSrchStateValue(mcaidAnomForm.getSummSrchStateValue());
		anomVO.setSummSrchPlanValue(mcaidAnomForm.getSummSrchPlanValue());
		//State and plan value addition: end
		anomVO.setAnamolyCategory(mcaidAnomForm.getAnamolyCategory());
		logger.info(LoggerConstants.methodEndLevel());
	}// setAnomSummGoSrchFormToVO()

	public void setAnomSummListDataVOtoForm(McaidReconAnomForm mcaidAnomForm, McaidReconAnomVO anomVO) {
		logger.info(LoggerConstants.methodStartLevel());
		mcaidAnomForm.setSummAnomListLst(anomVO.getSummAnomListLst());
		mcaidAnomForm.setSummPageLabel1(anomVO.getSummPageLabel1());
		mcaidAnomForm.setSummAnomListLst(anomVO.getSummAnomListLst());
		mcaidAnomForm.setSummAnomLstPageNbr(anomVO.getSummAnomLstPageNbr());
		mcaidAnomForm.setSummAnomLstPageType(anomVO.getSummAnomLstPageType());
		mcaidAnomForm.setAnamolyCategory(anomVO.getAnamolyCategory());
		mcaidAnomForm.setDiscrpDetailsLst(anomVO.getDiscrpDetailsLst());
		mcaidAnomForm.setCountOfRecords(anomVO.getCountOfRecords());
		mcaidAnomForm.setExtractQuery(anomVO.getExtractQuery());
		logger.info(LoggerConstants.methodEndLevel());
	}// setAnomSummListDataVOtoForm()

	public String getAnomSummDetailData(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconAnomForm mcaidAnomForm, int selectedRow) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconAnomVO anomVO = context.getAnamolyVO();
		String mfId = sessionHelper.getMfId();
		new McaidILService().getAnomSummDetailData(conn, mfId, anomVO, selectedRow);
		setAnomSummListDataVOtoForm(mcaidAnomForm, anomVO);
		mcaidAnomForm.setAnomSummDetailDataVo(anomVO.getAnomSummDetailDataVo());
		anomVO.setSummSrchListRowSelect(selectedRow);
		mcaidAnomForm.setSummSrchListRowSelect(anomVO.getSummSrchListRowSelect());
		mcaidAnomForm.setChangeStatus("");
		mcaidAnomForm.setChangeComment("");
		setAnomSrchSummContentVOToForm(mcaidAnomForm, anomVO, mfId);
		mappingTarget = "ILmcaidAnomSummary";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// getAnomSummDetailData()

	public String updateAnamolyStatus(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconAnomForm mcaidAnomForm) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconAnomVO anomVO = context.getAnamolyVO();
		String mfId = sessionHelper.getMfId();
		anomVO.setChangeStatus(mcaidAnomForm.getChangeStatus());
		anomVO.setChangeComment(mcaidAnomForm.getChangeComment());

		anomVO.setPopupMsg("");
		McaidAnomSummDetailVO mcaidAnomSummDetailVO = (McaidAnomSummDetailVO) anomVO.getSummAnomListLst()
				.get(mcaidAnomForm.getSummSrchListRowSelect() - 1);
		new McaidILService().updateAnamolyStatus(conn, mfId, anomVO, sessionHelper.getUserId(), mcaidAnomSummDetailVO);

		if (null != anomVO.getPopupMsg() && !anomVO.getPopupMsg().trim().equals("")) {
			setAnomDataVOtoForm(mcaidAnomForm, anomVO);
			mcaidAnomForm.setPopupMsg(anomVO.getPopupMsg());
			setAnomSrchSummContentVOToForm(mcaidAnomForm, anomVO, mfId);
			mappingTarget = "ILmcaidAnomSummary";
			logger.info(LoggerConstants.methodEndLevel());
			return mappingTarget;

		} else {
			anomVO.setSummAnomLstPageNbr(anomVO.getSummAnomLstPageNbr() + 1);
			// anomVO.setSummAnomLstOptFrom("DASHBOARD");

			if (anomVO.getSummAnomLstOptFrom().equals("DASHBOARD"))
				setAnomSummDsbSrchFormToVO(mcaidAnomForm, anomVO);
			else
				setAnomSummGoSrchFormToVO(mcaidAnomForm, anomVO);

			boolean hasListData = new McaidILService().getAnomSummListData(conn, mfId, anomVO, "update");
			setAnomSummListDataVOtoForm(mcaidAnomForm, anomVO);

			if (!hasListData)
				getAnomSummDetailData(conn, sessionHelper, context, mcaidAnomForm,
						mcaidAnomForm.getSummSrchListRowSelect());

			setAnomSrchSummContentVOToForm(mcaidAnomForm, anomVO, mfId);
			mappingTarget = "ILmcaidAnomSummary";
			logger.info(LoggerConstants.methodEndLevel());
			return mappingTarget;
		}

	}// updateAnamolyStatus()

	public String setAnomSummDataVOtoForm(McaidReconAnomForm mcaidAnomForm, McaidReconAnomVO anomVO, String custId) {
		logger.info(LoggerConstants.methodStartLevel());
		mcaidAnomForm.setSummPageLabel1(anomVO.getSummPageLabel1());
		mcaidAnomForm.setSummPageLabel2(anomVO.getSummPageLabel2());
		mcaidAnomForm.setSummSrchListRowSelect(anomVO.getSummSrchListRowSelect());
		mcaidAnomForm.setSummAnomListLst(anomVO.getSummAnomListLst());
		mcaidAnomForm.setSummAnomLstPageNbr(anomVO.getSummAnomLstPageNbr());
		mcaidAnomForm.setSummAnomLstPageType(anomVO.getSummAnomLstPageType());
		mcaidAnomForm.setAnomSummDetailDataVo(anomVO.getAnomSummDetailDataVo());
		mcaidAnomForm.setChangeStatus("");
		mcaidAnomForm.setChangeComment("");
		setAnomSrchSummContentVOToForm(mcaidAnomForm, anomVO, custId);
		logger.info(LoggerConstants.methodEndLevel());
		return "ILmcaidAnomSummary";

	}// setAnomSummDataVOtoForm()

	public void setAnomDataVOtoForm(McaidReconAnomForm mcaidAnomForm, McaidReconAnomVO anomVO) {
		logger.info(LoggerConstants.methodStartLevel());
		mcaidAnomForm.setSummPageLabel1(anomVO.getSummPageLabel1());
		mcaidAnomForm.setSummPageLabel2(anomVO.getSummPageLabel2());
		mcaidAnomForm.setSummSrchListRowSelect(anomVO.getSummSrchListRowSelect());
		mcaidAnomForm.setSummAnomListLst(anomVO.getSummAnomListLst());
		mcaidAnomForm.setSummAnomLstPageNbr(anomVO.getSummAnomLstPageNbr());
		mcaidAnomForm.setSummAnomLstPageType(anomVO.getSummAnomLstPageType());
		mcaidAnomForm.setAnomSummDetailDataVo(anomVO.getAnomSummDetailDataVo());
		logger.info(LoggerConstants.methodEndLevel());
	}// setAnomSummDataVOtoForm()

	// *********************ANOMALY-END*************************

	public String discDsbSubMenuSelect(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconDiscForm mcaidDiscForm, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconDiscVO discVO = context.getDiscrepanciesVO();
		String mfId = sessionHelper.getMfId();

		// if(null == discVO.getMcaidDiscDsbPBPLst() ||
		// discVO.getMcaidDiscDsbPBPLst().size() == 0)
		this.discInitialization(conn, sessionHelper, context, mcaidDiscForm, request); // ZZZZZZZZ
		// else
		// mcaidDiscForm.setMcaidDiscDsbPBPLst(discVO.getMcaidDiscDsbPBPLst());

		mappingTarget = "ILmcaidDisc";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;

	}

	public String discDashboardSearch(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconDiscForm mcaidDiscForm, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconDiscVO discVO = context.getDiscrepanciesVO();
		McaidReconAnomVO anomVO = context.getDiscAnamolyVO();
		String mfId = sessionHelper.getMfId();
		McaidILService ilService = new McaidILService();
		List<McaidReconDiscVO> mcaidDiscList = null;
		List li = new ArrayList();

		try {
			setDiscDashboardGoSrchFormToVO(mcaidDiscForm, discVO, anomVO);

			ilService.getILDiscDashBoardSearch(conn, discVO, mfId);

			mcaidDiscForm.setMcaidDiscDsbPBPLst(discVO.getMcaidDiscDsbPBPLst());
			McaidReconCodeCache objCache = McaidReconCodeCache.getInstance(mfId);
			mcaidDiscForm.setSummSrchPbpLst(objCache.getLstPbp());
			mcaidDiscForm.setSummSrchStatusLst(objCache.getLstDiscrpStatus());
			mcaidDiscForm.setDescrepancyCategoryList(objCache.getDescrepancyCategoryList());

		} catch (ApplicationException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
		}

		mappingTarget = "NMmcaidDisc";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;

	}

	public String AnomDashboardSearch(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconAnomForm mcaidDiscForm, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconAnomVO anomVO = context.getAnamolyVO();
		String mfId = sessionHelper.getMfId();
		McaidILService nmService = new McaidILService();
		List<McaidReconAnomVO> mcaidAnomList = null;
		List li = new ArrayList();

		try {
			setAnomDashboardGoSrchFormToVO(mcaidDiscForm, anomVO);

			nmService.getILAnomDashBoardSearch(conn, anomVO, mfId);

			mcaidDiscForm.setMcaidAnomDsbPBPLst(anomVO.getMcaidAnomDsbPBPLst());
			McaidReconCodeCache objCache = McaidReconCodeCache.getInstance(mfId);
			mcaidDiscForm.setSummSrchPbpLst(objCache.getLstPbp());
			mcaidDiscForm.setSummSrchStatusLst(objCache.getLstDiscrpStatus());
			mcaidDiscForm.setAnamolyCategoryList(objCache.getAnamolyCategoryList());

		} catch (ApplicationException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
		}

		mappingTarget = "NMmcaidAnom";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;

	}

	public String getDiscSummListData(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconDiscForm mcaidDiscForm, String move, String from) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconAnomVO anomVO = context.getDiscAnamolyVO();
		String mfId = sessionHelper.getMfId();
		if (from != null) {
			anomVO.setSummAnomLstOptFrom(from);
		}

		if (anomVO.getSummAnomLstOptFrom().equals("DASHBOARD")) {
			setDiscSummDsbSrchFormToVO(mcaidDiscForm, anomVO);
		} else {
			setDiscSummGoSrchFormToVO(mcaidDiscForm, anomVO);
		}

		anomVO.setPaymentSummaryMedicaidIdViewIndicator(
				context.getPaymentVO().getPaymentSummaryMedicaidIdViewIndicator());

		boolean hasListData = new McaidILService().getDiscSummListData(conn, mfId, anomVO, move);

		setDiscSummListDataVOtoForm(mcaidDiscForm, anomVO);

		if (!hasListData) {
			getDiscSummDetailData(conn, sessionHelper, context, anomVO, mcaidDiscForm, 1);
		}
		setDiscSrchSummContentVOToForm(mcaidDiscForm, anomVO, mfId);
		mappingTarget = "ILmcaidDiscSummary";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// getDiscSummListData()

	//IFOX-00407694-FCLO/WRTO Changes: start
	public String discFcloSearch(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconDiscForm mcaidDiscForm, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconFcloVO fcloVO = context.getForceCloseVO();
		McaidReconDiscVO discVO = context.getDiscrepanciesVO();
		String mfId = sessionHelper.getMfId();
		McaidILService ilService = new McaidILService();
		
		try{
			//setDiscDashboardGoSrchFormToVO(mcaidDiscForm, discVO, anomVO);
			setDiscFcloGoSrchFormToVO(mcaidDiscForm, fcloVO);
			
			List discrpFcloLst = ilService.getDiscFcloGoData(conn, mfId, fcloVO);
	
			fcloVO.setDiscrpFcloLst(discrpFcloLst);
			
			setDiscFcloDataVOToForm(mcaidDiscForm, fcloVO);
			mcaidDiscForm.setMcaidDiscDsbPBPLst(discVO.getMcaidDiscDsbPBPLst());
			McaidReconCodeCache objCache = McaidReconCodeCache.getInstance(mfId);
			mcaidDiscForm.setSummSrchPbpLst(objCache.getLstPbp());
			
			
		}catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
		}
		mappingTarget = "ILmcaidDiscFCLO";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}
	//IFOX-00407694-FCLO/WRTO Changes: end
	public String discSummDetailSearch(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconDiscForm mcaidDiscForm, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconDiscVO discVO = context.getDiscrepanciesVO();
		McaidReconAnomVO anomVO = context.getDiscAnamolyVO();
		String mfId = sessionHelper.getMfId();
		McaidILService ilService = new McaidILService();
		List<McaidReconDiscVO> mcaidDiscList = null;
		List li = new ArrayList();

		try {
			setDiscDashboardGoSrchFormToVO(mcaidDiscForm, discVO, anomVO);

			List discrpDetailsLst = ilService.getDiscSummaryGoData(conn, mfId, discVO);

			anomVO.setDiscrpDetailsLst(discrpDetailsLst);
			anomVO.setSummPageLabel1(discVO.getSummPageLabel1());
			// System.out.println("McaidNMManager.getDiscSummListData()"+hasListData);
			setDiscSummListDataVOtoForm(mcaidDiscForm, anomVO);
			mcaidDiscForm.setDiscrepancyCategory(discVO.getSummDiscType());
			mcaidDiscForm.setMcaidDiscDsbPBPLst(discVO.getMcaidDiscDsbPBPLst());
			McaidReconCodeCache objCache = McaidReconCodeCache.getInstance(mfId);
			mcaidDiscForm.setSummSrchPbpLst(objCache.getLstPbp());
			mcaidDiscForm.setSummSrchStatusLst(objCache.getLstDiscrpStatus());
			mcaidDiscForm.setDescrepancyCategoryList(objCache.getDescrepancyCategoryList());

		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
		}

		mappingTarget = "NMmcaidDiscDetail";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;

	}

	public String anomSummDetailSearch(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconAnomForm mcaidAnomForm, HttpServletRequest request) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconDiscVO discVO = context.getDiscrepanciesVO();
		McaidReconAnomVO anomVO = context.getDiscAnamolyVO();
		String mfId = sessionHelper.getMfId();
		McaidILService nmService = new McaidILService();
		List<McaidReconDiscVO> mcaidDiscList = null;
		List li = new ArrayList();

		try {
			setAnomDashboardGoSrchFormToVO(mcaidAnomForm, anomVO);

			List discrpDetailsLst = nmService.getAnomSummaryGoData(conn, mfId, anomVO);

			anomVO.setDiscrpDetailsLst(discrpDetailsLst);
			anomVO.setSummPageLabel1(discVO.getSummPageLabel1());
			// System.out.println("McaidNMManager.getDiscSummListData()"+hasListData);
			setAnomSummListDataVOtoForm(mcaidAnomForm, anomVO);

			mcaidAnomForm.setMcaidAnomDsbPBPLst(anomVO.getMcaidAnomDsbPBPLst());
			McaidReconCodeCache objCache = McaidReconCodeCache.getInstance(mfId);
			mcaidAnomForm.setSummSrchPbpLst(objCache.getLstPbp());
			mcaidAnomForm.setSummSrchStatusLst(objCache.getLstDiscrpStatus());
			mcaidAnomForm.setAnamolyCategoryList(objCache.getAnamolyCategoryList());

		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
		}

		mappingTarget = "ILmcaidDiscDetail";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;

	}

	public void setDiscSummListDataVOtoForm(McaidReconDiscForm mcaidDiscForm, McaidReconAnomVO anomVO) {
		logger.info(LoggerConstants.methodStartLevel());
		// System.out.println("McaidILManager.setDiscSummListDataVOtoForm()::size:::"+anomVO.getSummAnomListLst().size());
		mcaidDiscForm.setSummAnomListLst(anomVO.getSummAnomListLst());
		mcaidDiscForm.setSummAnomLstPageNbr(anomVO.getSummAnomLstPageNbr());
		mcaidDiscForm.setSummAnomLstPageType(anomVO.getSummAnomLstPageType());
		mcaidDiscForm.setSummPageLabel1(anomVO.getSummPageLabel1());
		mcaidDiscForm.setDiscrpDetailsLst(anomVO.getDiscrpDetailsLst());
		mcaidDiscForm.setCountOfRecords(anomVO.getCountOfRecords());
		mcaidDiscForm.setExtractQuery(anomVO.getExtractQuery());
		logger.info(LoggerConstants.methodEndLevel());
	}// setDiscSummListDataVOtoForm()

	//IFOX-00407694-FCLO/WRTO Changes: start
	public void setDiscFcloDataVOToForm(McaidReconDiscForm mcaidDiscForm, McaidReconFcloVO fcloVO){
		logger.info(LoggerConstants.methodStartLevel());
		mcaidDiscForm.setMedicaidId(fcloVO.getMedicaidId());
		mcaidDiscForm.setEffDate(fcloVO.getEffDate());
		mcaidDiscForm.setUserId(fcloVO.getUserId());
		//mcaidDiscForm.setDiscrepancyCategory(fcloVO.getDiscrepancyCategory());
		mcaidDiscForm.setDiscrpFcloLst(fcloVO.getDiscrpFcloLst());
		//mcaidDiscForm.setStatus(fcloVO.getStatus());
		logger.info(LoggerConstants.methodEndLevel());
	}
	//IFOX-00407694-FCLO/WRTO Changes: end
	public String getDiscSummDetailData(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconAnomVO anomVO, McaidReconDiscForm mcaidDiscForm, int selectedRow) {
		logger.info(LoggerConstants.methodStartLevel());
		// McaidReconAnomVO anomVO = context.getAnamolyVO();
		String mappingTarget = "error";
		// McaidReconAnomVO anomVO = context.getDiscAnamolyVO();
		String mfId = sessionHelper.getMfId();
		new McaidILService().getDiscSummDetailData(conn, mfId, anomVO, selectedRow);
		setDiscSummListDataVOtoForm(mcaidDiscForm, anomVO);
		//IFOX-00410283- Duplicate fix: start
		mcaidDiscForm.setRate(anomVO.getRate());
		mcaidDiscForm.setRegion(anomVO.getRegion());
		mcaidDiscForm.setStateRate(anomVO.getStateRate());
		mcaidDiscForm.setStateRegion(anomVO.getStateRegion());
		//IFOX-00410283- Duplicate fix: end
		mcaidDiscForm.setAnomSummDetailDataVo(anomVO.getAnomSummDetailDataVo());
		anomVO.setSummSrchListRowSelect(selectedRow);
		mcaidDiscForm.setSummSrchListRowSelect(anomVO.getSummSrchListRowSelect());
		mcaidDiscForm.setChangeStatus("");
		mcaidDiscForm.setChangeComment("");
		setDiscSrchSummContentVOToForm(mcaidDiscForm, anomVO, mfId);
		mappingTarget = "ILmcaidDiscSummary";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// getDiscSummDetailData()

	public String updateDiscStatus(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconDiscForm mcaidDiscForm) {
		logger.info(LoggerConstants.methodStartLevel());

		McaidILService mcaidILService = new McaidILService();

		// McaidReconAnomVO anomVO = context.getAnamolyVO();
		String mappingTarget = "error";
		McaidReconAnomVO anomVO = context.getDiscAnamolyVO();
		String mfId = sessionHelper.getMfId();
		anomVO.setChangeStatus(mcaidDiscForm.getChangeStatus());
		anomVO.setChangeComment(mcaidDiscForm.getChangeComment());

		anomVO.setPopupMsg("");
		McaidAnomSummDetailVO mcaidAnomSummDetailVO = null;
		
		if(anomVO.getSummAnomListLst() !=null && anomVO.getSummAnomListLst().size()>0){
		
			if(anomVO.getSummAnomListLst().size()>(mcaidDiscForm.getSummSrchListRowSelect()-1))
				mcaidAnomSummDetailVO = (McaidAnomSummDetailVO) anomVO.getSummAnomListLst().get(mcaidDiscForm.getSummSrchListRowSelect() - 1);
			else 
				mcaidAnomSummDetailVO = (McaidAnomSummDetailVO) anomVO.getSummAnomListLst().get(0);
		}
		if(mcaidAnomSummDetailVO !=null )
			//IFOX-00407694-FCLO/WRTO Changes: start
		mcaidILService.updateDiscStatus(conn, mfId, anomVO, sessionHelper.getUserId(), mcaidAnomSummDetailVO,"");
		//IFOX-00407694-FCLO/WRTO Changes: end
		if (null != anomVO.getPopupMsg() && !anomVO.getPopupMsg().trim().equals("")) {
			setDiscSummDataVOtoForm(mcaidDiscForm, anomVO);
			mcaidDiscForm.setPopupMsg(anomVO.getPopupMsg());
			setDiscSrchSummContentVOToForm(mcaidDiscForm, anomVO, mfId);
			mappingTarget = "ILmcaidDiscSummary";
			return mappingTarget;

		} else {
			anomVO.setSummAnomLstPageNbr(anomVO.getSummAnomLstPageNbr() + 1);
			// anomVO.setSummAnomLstOptFrom("DASHBOARD");

			if (anomVO.getSummAnomLstOptFrom().equals("DASHBOARD")) {
				setDiscSummDsbSrchFormToVO(mcaidDiscForm, anomVO);
			} else {
				setDiscSummGoSrchFormToVO(mcaidDiscForm, anomVO);
			}
			boolean hasListData = mcaidILService.getDiscSummListData(conn, mfId, anomVO, "update");
			setDiscSummListDataVOtoForm(mcaidDiscForm, anomVO);

			if (!hasListData) {
				getDiscSummDetailData(conn, sessionHelper, context, anomVO, mcaidDiscForm,
						mcaidDiscForm.getSummSrchListRowSelect());
			}
			setDiscSrchSummContentVOToForm(mcaidDiscForm, anomVO, mfId);
			mappingTarget = "ILmcaidDiscSummary";
			logger.info(LoggerConstants.methodEndLevel());
			return mappingTarget;
		}

	}// updateDiscStatus()

	//IFOX-00407694-FCLO/WRTO Changes: start
	public String updateFcloStatus(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconDiscForm mcaidDiscForm) {
		logger.info(LoggerConstants.methodStartLevel());

		McaidILService mcaidILService = new McaidILService();

		// McaidReconAnomVO anomVO = context.getAnamolyVO();
		String mappingTarget = "error";
		McaidReconAnomVO anomVO = context.getDiscAnamolyVO();
		anomVO.setWrtoInd(mcaidDiscForm.getWrtoInd());
		String mfId = sessionHelper.getMfId();
		String userID = sessionHelper.getUserId();
		//anomVO.setChangeStatus(mcaidDiscForm.getChangeStatus());
		//anomVO.setChangeComment(mcaidDiscForm.getChangeComment());
		McaidReconFcloVO fcloVO = new McaidReconFcloVO();
		fcloVO.setSummSrchGoPbp(mcaidDiscForm.getSummSrchGoPbp());
		fcloVO.setSummSrchMedicaidId(mcaidDiscForm.getSummSrchMedicaidId());
		fcloVO.setSummSrchFromEffDate((mcaidDiscForm.getSummSrchFromEffDate()));
		fcloVO.setSummSrchUpdtUserId(mcaidDiscForm.getSummSrchUpdtUserId());
		
		
			
		anomVO.setPopupMsg("");
		McaidAnomSummDetailVO mcaidAnomSummDetailVO = null;
		setDiscFcloDataFormtoVO(mcaidDiscForm, anomVO);
				
		//mcaidILService.updateDiscStatus(conn, mfId, anomVO, sessionHelper.getUserId(), mcaidAnomSummDetailVO, "fclo");
		anomVO.setChangeComment(StringUtil.nonNullTrim(anomVO.getChangedComment()));
		if(anomVO.getChangeComment().equalsIgnoreCase("") || anomVO.getChangeComment().length() <= 0)
		{
			anomVO.setPopupMsg("Comments field cannot be Blank. Please add your comments!");
		}
		else if(!anomVO.getChangeComment().equalsIgnoreCase("") && anomVO.getChangeComment().length()>250)
		{
			anomVO.setPopupMsg("Comments entered cannot be more than 250 character. Please enter valid comment!");
		}
		//Adding for Comments update CR
		else{
		//setting values to be updated
			if(mcaidAnomSummDetailVO ==null )
				mcaidAnomSummDetailVO = new McaidAnomSummDetailVO();
			mcaidAnomSummDetailVO.setPbpId(mcaidDiscForm.getSummSrchGoPbp());
			mcaidAnomSummDetailVO.setMedicaidId(mcaidDiscForm.getMedicaidId());
			mcaidAnomSummDetailVO.setEffDate(McaidReconHelper.getyyyymmFromUImmyyyy(mcaidDiscForm.getEffDate()));
			anomVO.setChangeComment(mcaidDiscForm.getChangedComment());
			mcaidAnomSummDetailVO.setStrPlanId("MIL01");
			anomVO.setUserId(sessionHelper.getUserId());
			List summDetailLst = new McaidILDao().getDiscFcloSearch(conn, mfId, fcloVO);
			//List selectedList = new ArrayList<McaidFcloDetailVO>();
			String[] selectedIndex = mcaidDiscForm.getSelect();
			for(int i=0;i<selectedIndex.length;i++){
				McaidFcloDetailVO fcloDetailVO = (McaidFcloDetailVO) summDetailLst.get(Integer.parseInt(selectedIndex[i]));
				//selectedList.add(fcloDetailVO);
			mcaidAnomSummDetailVO.setMedicaidId(fcloDetailVO.getMedicaidId());
			mcaidAnomSummDetailVO.setMemberId(fcloDetailVO.getMemeberid());
			mcaidAnomSummDetailVO.setStrApplyDate(fcloDetailVO.getApplyDate());
			mcaidAnomSummDetailVO.setAnomCd(fcloDetailVO.getDiscCd());
			mcaidAnomSummDetailVO.setCreateTime(fcloDetailVO.getCreate_time());
			//mcaidAnomSummDetailVO.setReconStatus(fcloDetailVO.getStatus());
			if(mcaidAnomSummDetailVO.getAnomCd().equals("TPAY")&& StringUtil.nonNullTrim(anomVO.getWrtoInd()).equals("Y"))
				anomVO.setChangeStatus("WRTO");
			else
				anomVO.setChangeStatus("FCLO");
			mcaidAnomSummDetailVO.setReconStatus(anomVO.getChangeStatus());
			mcaidAnomSummDetailVO.setLastUpdate(fcloDetailVO.getUserId());
			mcaidAnomSummDetailVO.setAnomType(fcloDetailVO.getDiscrpType());
			McaidAnomSummDetailDataVO sumDetailData = anomVO.getAnomSummDetailDataVo();
			sumDetailData.setEffDate(McaidReconHelper.getyyyymmFromUImmyyyy(mcaidDiscForm.getEffDate()));
			sumDetailData.setPlanId("MIL01");
			sumDetailData.setAnomCd(fcloDetailVO.getDiscCd());
			sumDetailData.setPbpId(mcaidDiscForm.getSummSrchGoPbp());
			sumDetailData.setStatus(fcloDetailVO.getStatus());
			sumDetailData.setApplyDate(fcloDetailVO.getApplyDate());
			if(!StringUtil.nonNullTrim(anomVO.getFcloStartDate()).equals(""))
			McaidReconHelper.getyyyymmFromUImmyyyy(StringUtil.nonNullTrim(anomVO.getFcloStartDate()));
			if(!StringUtil.nonNullTrim(anomVO.getFcloEndDate()).equals(""))
				McaidReconHelper.getyyyymmFromUImmyyyy(StringUtil.nonNullTrim(anomVO.getFcloEndDate()));
						
			McaidILDao anomDao = new McaidILDao();
			anomDao.updateDiscrepancyDetails(conn, mfId, anomVO, sessionHelper.getUserId(), mcaidAnomSummDetailVO,"fclo");
			}

		if (null != anomVO.getPopupMsg() && !anomVO.getPopupMsg().trim().equals("")) {
			setDiscSummDataVOtoForm(mcaidDiscForm, anomVO);
			mcaidDiscForm.setPopupMsg(anomVO.getPopupMsg());
			setDiscSrchSummContentVOToForm(mcaidDiscForm, anomVO, mfId);
			mappingTarget = "ILmcaidDiscFCLO";
			

		} else {
			anomVO.setSummAnomLstPageNbr(anomVO.getSummAnomLstPageNbr() + 1);
			// anomVO.setSummAnomLstOptFrom("DASHBOARD");

			if (anomVO.getSummAnomLstOptFrom().equals("DASHBOARD")) {
				setDiscSummDsbSrchFormToVO(mcaidDiscForm, anomVO);
			} else {
				setDiscSummGoSrchFormToVO(mcaidDiscForm, anomVO);
			}
			/*boolean hasListData = mcaidILService.getDiscSummListData(conn, mfId, anomVO, "update");
			setDiscSummListDataVOtoForm(mcaidDiscForm, anomVO);

			if (!hasListData) {
				getDiscSummDetailData(conn, sessionHelper, context, anomVO, mcaidDiscForm,
						mcaidDiscForm.getSummSrchListRowSelect());
			}*/
			setDiscSrchSummContentVOToForm(mcaidDiscForm, anomVO, mfId);
			mappingTarget = "ILmcaidDiscFCLO";
			//return mappingTarget;
		}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;

	}// updateDiscStatus()
	//IFOX-00407694-FCLO/WRTO Changes: end

	
	public void setDiscSummDataVOtoForm(McaidReconDiscForm mcaidDiscForm, McaidReconAnomVO anomVO) {
		logger.info(LoggerConstants.methodStartLevel());
		mcaidDiscForm.setSummPageLabel1(anomVO.getSummPageLabel1());
		mcaidDiscForm.setSummPageLabel2(anomVO.getSummPageLabel2());
		mcaidDiscForm.setSummSrchListRowSelect(anomVO.getSummSrchListRowSelect());
		mcaidDiscForm.setSummAnomListLst(anomVO.getSummAnomListLst());
		mcaidDiscForm.setSummAnomLstPageNbr(anomVO.getSummAnomLstPageNbr());
		mcaidDiscForm.setSummAnomLstPageType(anomVO.getSummAnomLstPageType());
		mcaidDiscForm.setAnomSummDetailDataVo(anomVO.getAnomSummDetailDataVo());
		logger.info(LoggerConstants.methodEndLevel());
	}// setAnomSummDataVOtoForm()

	public String setDiscAnomSummDataVOToForm(McaidReconAnomVO discAnomVO, McaidReconDiscForm mcaidDiscForm,
			String custId) {
		logger.info(LoggerConstants.methodStartLevel());
		mcaidDiscForm.setSummPageLabel1(discAnomVO.getSummPageLabel1());
		mcaidDiscForm.setSummSrchListRowSelect(discAnomVO.getSummSrchListRowSelect());
		mcaidDiscForm.setSummAnomListLst(discAnomVO.getSummAnomListLst());
		mcaidDiscForm.setSummAnomLstPageNbr(discAnomVO.getSummAnomLstPageNbr());
		mcaidDiscForm.setSummAnomLstPageType(discAnomVO.getSummAnomLstPageType());
		mcaidDiscForm.setAnomSummDetailDataVo(discAnomVO.getAnomSummDetailDataVo());
		mcaidDiscForm.setChangeStatus("");
		mcaidDiscForm.setChangeComment("");
		setDiscSrchSummContentVOToForm(mcaidDiscForm, discAnomVO, custId);
		logger.info(LoggerConstants.methodEndLevel());
		return "ILmcaidDiscSummary";
	}

	public String getViewPaymentDetails(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconDiscForm mcaidDiscForm) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconDiscVO discVO = context.getDiscrepanciesVO();
		// McaidReconAnomVO vo = context.getAnamolyVO();
		McaidReconAnomVO vo = context.getDiscAnamolyVO();
		String firstName = vo.getAnomSummDetailDataVo().getFirstName();
		String lastName = vo.getAnomSummDetailDataVo().getLastName();
		String medicaidId = vo.getAnomSummDetailDataVo().getMedicaidId();
		String suppIdEffDate = vo.getAnomSummDetailDataVo().getSuppIdEffDate();
		String planId = vo.getAnomSummDetailDataVo().getPlan();

		String mfId = sessionHelper.getMfId();
		// Set form to VO
		discVO.setPbpId(mcaidDiscForm.getPbpId());
		discVO.setEffDate(mcaidDiscForm.getEffDate());
		discVO.setMedicaidId(medicaidId);
		discVO.setPlanId(planId);
		new McaidILService().getViewPaymentDetails(conn, mfId, discVO);
		// Set VO to Form
		mcaidDiscForm.setMcaidViewPymntDetailLst(discVO.getMcaidViewPymntDetailLst());
		mcaidDiscForm.setMedicaidId(medicaidId);
		mcaidDiscForm.setFirstName(firstName);
		mcaidDiscForm.setLastName(lastName);
		mcaidDiscForm.setSuppIdEffDate(suppIdEffDate);
		mcaidDiscForm.setRecentSuppId(vo.getAnomSummDetailDataVo().getRecentSuppId());
		mcaidDiscForm.setSummCmsPaid(discVO.getSummCmsPaid());
		mcaidDiscForm.setSummDataDiffrence(discVO.getSummDataDiffrence());
		mcaidDiscForm.setSummPlanExpected(discVO.getSummPlanExpected());
		mcaidDiscForm.setDiffrence(discVO.getDiffrence());
		mcaidDiscForm.setViewPymtPageLabel(discVO.getViewPymtPageLabel());
		mappingTarget = "viewPaymentDetails";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// getViewPaymentDetails()

	public String getViewPaymentDetailsForAnom(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconAnomForm mcaidAnomForm) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconDiscVO discVO = context.getDiscrepanciesVO();
		McaidReconAnomVO vo = context.getAnamolyVO();
		String firstName = vo.getAnomSummDetailDataVo().getFirstName();
		String lastName = vo.getAnomSummDetailDataVo().getLastName();
		String medicaidId = vo.getAnomSummDetailDataVo().getMedicaidId();
		String suppIdEffDate = vo.getAnomSummDetailDataVo().getSuppIdEffDate();
		String planId = vo.getAnomSummDetailDataVo().getPlan();

		String mfId = sessionHelper.getMfId();
		// Set Form to VO
		discVO.setPbpId(mcaidAnomForm.getPbpId());
		discVO.setEffDate(mcaidAnomForm.getEffDate());
		discVO.setMedicaidId(medicaidId); // ZZZZZZ
		discVO.setPlanId(planId);
		new McaidILService().getViewPaymentDetails(conn, mfId, discVO);
		// Set VO to Form
		mcaidAnomForm.setMcaidViewPymntDetailLst(discVO.getMcaidViewPymntDetailLst());
		mcaidAnomForm.setMedicaidId(medicaidId);
		mcaidAnomForm.setFirstName(firstName);
		mcaidAnomForm.setLastName(lastName);
		mcaidAnomForm.setSuppIdEffDate(suppIdEffDate);
		mcaidAnomForm.setRecentSuppId(vo.getAnomSummDetailDataVo().getRecentSuppId());
		mcaidAnomForm.setSummCmsPaid(discVO.getSummCmsPaid());
		mcaidAnomForm.setSummDataDiffrence(discVO.getSummDataDiffrence());
		mcaidAnomForm.setSummPlanExpected(discVO.getSummPlanExpected());
		mcaidAnomForm.setDiffrence(discVO.getDiffrence());
		mcaidAnomForm.setViewPymtPageLabel(discVO.getViewPymtPageLabel());
		mappingTarget = "viewPaymentDetails";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// getViewPaymentDetailsForAnom()

	/* View Reconciliation - Start */
	public String getViewReconciliation(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconDiscForm mcaidDiscForm) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconAnomVO vo = context.getDiscAnamolyVO();
		McaidReconDiscVO discVO = context.getDiscrepanciesVO();
		String mfId = sessionHelper.getMfId();
		setDiscSummInputDataToVO(vo, discVO);
		new McaidILService().getViewReconcilation(conn, mfId, discVO);
		mcaidDiscForm.setMedicaidId(vo.getAnomSummDetailDataVo().getMedicaidId());
		mcaidDiscForm.setFirstName(vo.getAnomSummDetailDataVo().getFirstName());
		mcaidDiscForm.setFirstName(vo.getAnomSummDetailDataVo().getLastName());
		mcaidDiscForm.setRecentSuppId(vo.getAnomSummDetailDataVo().getRecentSuppId());
		mcaidDiscForm.setSuppIdEffDate(vo.getAnomSummDetailDataVo().getSuppIdEffDate());
		setDiscViewReconcilationVOtoForm(mcaidDiscForm, discVO);// this replaced
																// above 2
																// commented
																// sections.
		// For New Reconciliation screen : Start
		mappingTarget = "viewReconcilationIL";
		/* mappingTarget = "viewReconcilation"; */
		// For New Reconciliation screen : End
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// getViewReconciliation

	public String getViewReconciliation(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconAnomForm mcaidAnomForm) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconAnomVO vo = context.getAnamolyVO();
		McaidReconDiscVO discVO = context.getDiscrepanciesVO();
		String mfId = sessionHelper.getMfId();
		setAnomSummInputDataToVO(vo, discVO);
		logger.debug("dates===" + mcaidAnomForm.getAnomSummDetailDataVo().getEffDate() + " discVO date: "
				+ discVO.getEffDate());
		new McaidILService().getViewReconcilation(conn, mfId, discVO);
		mcaidAnomForm.setMedicaidId(vo.getAnomSummDetailDataVo().getMedicaidId());
		mcaidAnomForm.setFirstName(vo.getAnomSummDetailDataVo().getFirstName());
		mcaidAnomForm.setFirstName(vo.getAnomSummDetailDataVo().getLastName());
		mcaidAnomForm.setRecentSuppId(vo.getAnomSummDetailDataVo().getRecentSuppId());
		mcaidAnomForm.setSuppIdEffDate(vo.getAnomSummDetailDataVo().getSuppIdEffDate());
		setDiscViewReconcilationVOtoForm(mcaidAnomForm, discVO);// this replaced
																// above 2
																// commented
																// sections.
		// For New Reconciliation screen : Start
		mappingTarget = "viewReconcilationIL";
		/* mappingTarget = "viewReconcilation"; */
		// For New Reconciliation screen : End
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// getViewReconciliation

	public void setDiscViewReconcilationVOtoForm(McaidReconDiscForm mcaidDiscForm, McaidReconDiscVO discVO) {
		logger.info(LoggerConstants.methodStartLevel());
		mcaidDiscForm.setDiscviewPVO(discVO.getDiscviewPVO());
		mcaidDiscForm.setDiscviewSVO(discVO.getDiscviewSVO());
		logger.info(LoggerConstants.methodEndLevel());
	}// setDiscViewReconcilationVOtoForm

	public void setDiscViewReconcilationVOtoForm(McaidReconAnomForm mcaidAnomForm, McaidReconDiscVO discVO) {
		logger.info(LoggerConstants.methodStartLevel());
		mcaidAnomForm.setDiscviewPVO(discVO.getDiscviewPVO());
		mcaidAnomForm.setDiscviewSVO(discVO.getDiscviewSVO());
		logger.info(LoggerConstants.methodEndLevel());
	}// setDiscViewReconcilationVOtoForm

	private void setAnomSummInputDataToVO(McaidReconAnomVO form, McaidReconDiscVO vo) {
		logger.info(LoggerConstants.methodStartLevel());
		vo.setMedicaidId(form.getAnomSummDetailDataVo().getMedicaidId());
		vo.setEffDate(form.getAnomSummDetailDataVo().getEffDate());
		vo.setPlanId(form.getAnomSummDetailDataVo().getPlan());
		logger.info(LoggerConstants.methodEndLevel());
	}// setAnomSummInputDataToVO()

	private void setDiscSummInputDataToVO(McaidReconAnomVO form, McaidReconDiscVO vo) {
		logger.info(LoggerConstants.methodStartLevel());
		vo.setMedicaidId(form.getAnomSummDetailDataVo().getMedicaidId());
		vo.setEffDate(form.getAnomSummDetailDataVo().getEffDate());
		vo.setPlanId(form.getAnomSummDetailDataVo().getPlan());
		logger.info(LoggerConstants.methodEndLevel());
	}// setAnomSummInputDataToVO()
	/* View Reconciliation - End */

	private void setDiscSrchSummContentVOToForm(McaidReconDiscForm form, McaidReconAnomVO discrpAnomVO, String custId) {
		logger.info(LoggerConstants.methodStartLevel());
		McaidReconCodeCache objCache = McaidReconCodeCache.getInstance(custId);
		form.setSummSrchPbpLst(objCache.getLstPbp());
		form.setSummSrchStatusLst(objCache.getLstDiscrpStatus());
		form.setSummSrchTypeLst(objCache.getLstDiscrpType());
		// Details Status List
		form.setSummDetailStatusLst(objCache.getLstDetailDiscrpStatus());
		form.setSummDetailStatusChngLst(objCache.getLstDetailDiscrpStatusChng());
		// Details Status List

		form.setDescrepancyCategoryList(objCache.getDescrepancyCategoryList());

		// Search Functionality for Discrepancies Screen :Start
		if (StringUtil.nonNullTrim(discrpAnomVO.getSummAnomLstOptFrom()).equals("")
				|| discrpAnomVO.getSummAnomLstOptFrom().equals("DETAILS")
				|| discrpAnomVO.getSummAnomLstOptFrom().equals("DASHBOARD")) {
			form.setSummSrchPbp(discrpAnomVO.getSummSrchPbp());
			form.setSummSrchGoPbp(discrpAnomVO.getSummSrchPbp());
			form.setSummSrchStatus(discrpAnomVO.getSummSrchStatus());
			form.setSummSrchGoStatus(discrpAnomVO.getSummSrchStatus());
			if (null != discrpAnomVO.getAnomSummDetailDataVo())
				form.setChangeStatus(discrpAnomVO.getAnomSummDetailDataVo().getStatus());

			if (!StringUtil.nonNullTrim(discrpAnomVO.getSummSrchMonth()).equals("")) {

				form.setSummSrchFromEffDate(discrpAnomVO.getSummSrchMonth() + "/" + discrpAnomVO.getSummSrchYear());
				form.setSummSrchToEffDate(discrpAnomVO.getSummSrchMonth() + "/" + discrpAnomVO.getSummSrchYear());

			} else {

				if (!StringUtil.nonNullTrim(discrpAnomVO.getSummSrchQtr()).equals("")) {

					if (discrpAnomVO.getSummSrchQtr().startsWith("1")) {
						form.setSummSrchFromEffDate("01" + "/" + discrpAnomVO.getSummSrchYear());
						form.setSummSrchToEffDate("03" + "/" + discrpAnomVO.getSummSrchYear());
					}
					if (discrpAnomVO.getSummSrchQtr().startsWith("2")) {
						form.setSummSrchFromEffDate("04" + "/" + discrpAnomVO.getSummSrchYear());
						form.setSummSrchToEffDate("06" + "/" + discrpAnomVO.getSummSrchYear());
					}
					if (discrpAnomVO.getSummSrchQtr().startsWith("3")) {
						form.setSummSrchFromEffDate("07" + "/" + discrpAnomVO.getSummSrchYear());
						form.setSummSrchToEffDate("09" + "/" + discrpAnomVO.getSummSrchYear());
					}
					if (discrpAnomVO.getSummSrchQtr().startsWith("4")) {
						form.setSummSrchFromEffDate("10" + "/" + discrpAnomVO.getSummSrchYear());
						form.setSummSrchToEffDate("12" + "/" + discrpAnomVO.getSummSrchYear());
					}

				} else {
					if (!StringUtil.nonNullTrim(discrpAnomVO.getSummSrchYear()).equals("")) {
						form.setSummSrchFromEffDate("01" + "/" + discrpAnomVO.getSummSrchYear());
						form.setSummSrchToEffDate("12" + "/" + discrpAnomVO.getSummSrchYear());
					}
				}
			}

			if (null != discrpAnomVO.getSummSrchDiscrpCd() && !discrpAnomVO.getSummSrchDiscrpCd().trim().equals(""))
				form.setDiscrepancyCategory(discrpAnomVO.getSummSrchDiscrpCd());
			else
				form.setDiscrepancyCategory(discrpAnomVO.getDiscrepancyCategory());

			form.setSummSrchMedicaidId(discrpAnomVO.getSummSrchMedicaidId());
		} else {
			form.setSummSrchPbp(discrpAnomVO.getSummSrchGoPbp());
			form.setSummSrchGoPbp(discrpAnomVO.getSummSrchGoPbp());
			form.setSummSrchStatus(discrpAnomVO.getSummSrchGoStatus());
			form.setSummSrchGoStatus(discrpAnomVO.getSummSrchGoStatus());
			form.setSummSrchMedicaidId(discrpAnomVO.getSummSrchMedicaidId());
			form.setSummSrchFromEffDate(discrpAnomVO.getSummSrchFromEffDate());
			form.setSummSrchToEffDate(discrpAnomVO.getSummSrchToEffDate());
			form.setSummSrchFromUpdtDate(discrpAnomVO.getSummSrchFromUpdtDate());
			form.setSummSrchToUpdtDate(discrpAnomVO.getSummSrchToUpdtDate());
			form.setSummSrchUpdtUserId(discrpAnomVO.getSummSrchUpdtUserId());
			//State and plan value addition: start
			form.setSummSrchStateValue(discrpAnomVO.getSummSrchStateValue());
			form.setSummSrchPlanValue(discrpAnomVO.getSummSrchPlanValue());
			//State and plan value addition: end
			//IFOX-00408437 / 00408436 / 00408435:Region Search Addition: start
			form.setSummSrchRegion(discrpAnomVO.getSummSrchRegion());
			//IFOX-00408437 / 00408436 / 00408435:Region Search Addition: end
			if (null != discrpAnomVO.getAnomSummDetailDataVo())
				form.setChangeStatus(discrpAnomVO.getAnomSummDetailDataVo().getStatus());
			// form.setDiscrepancyCategory(discrpAnomVO.getSummSrchDiscrpCd());

			if (StringUtil.nonNullTrim(discrpAnomVO.getSummAnomLstOptFrom()).equals("DETAILS"))
				form.setDiscrepancyCategory(discrpAnomVO.getSummSrchDiscrpCd());
			else
				form.setDiscrepancyCategory(discrpAnomVO.getDiscrepancyCategory());
		}
		form.setSummSrchType(discrpAnomVO.getSummSrchType());
		// Search Functionality for Discrepancies Screen :End
		form.setMethod("");
		logger.info(LoggerConstants.methodEndLevel());
	}// setDiscSrchSummContentVOToForm()

	private void setDiscSummDsbSrchFormToVO(McaidReconDiscForm mcaidDiscForm, McaidReconAnomVO discrpAnomVO) {
		logger.info(LoggerConstants.methodStartLevel());
		discrpAnomVO.setSummSrchPbp(mcaidDiscForm.getSummSrchPbp());
		//Setting correct PBP value to avoid blank PBP in details screen : start
		if(StringUtil.nonNullTrim(discrpAnomVO.getSummSrchPbp()).equals(""))
			discrpAnomVO.setSummSrchPbp(mcaidDiscForm.getSummSrchGoPbp());
		//Setting correct PBP value to avoid blank PBP in details screen : end
		discrpAnomVO.setSummSrchYear(mcaidDiscForm.getSummSrchYear());
		discrpAnomVO.setSummSrchQtr(mcaidDiscForm.getSummSrchQtr());
		discrpAnomVO.setSummSrchMonth(mcaidDiscForm.getSummSrchMonth());
		discrpAnomVO.setSummSrchStatus(mcaidDiscForm.getSummSrchStatus());
		discrpAnomVO.setSummSrchDiscrpCd(mcaidDiscForm.getSummSrchDiscrpCd());
		discrpAnomVO.setDiscrepancyCategory(mcaidDiscForm.getDiscrepancyCategory());
		//Fix for effective period search : start
		discrpAnomVO.setSummSrchFromEffDate(mcaidDiscForm.getSummSrchFromEffDate());
		discrpAnomVO.setSummSrchToEffDate(mcaidDiscForm.getSummSrchToEffDate());
		logger.info(LoggerConstants.methodEndLevel());
		//Fix for effective period search : end
	}// setDiscSummDsbSrchFormToVO()

	//IFOX-00407694-FCLO/WRTO Changes: start
	private void setDiscFcloGoSrchFormToVO(McaidReconDiscForm mcaidDiscForm, McaidReconFcloVO fcloVO){
		logger.info(LoggerConstants.methodStartLevel());
		fcloVO.setSummSrchGoPbp(mcaidDiscForm.getSummSrchGoPbp());
		fcloVO.setSummSrchMedicaidId(mcaidDiscForm.getSummSrchMedicaidId());
		fcloVO.setSummSrchFromEffDate(mcaidDiscForm.getSummSrchFromEffDate());
		fcloVO.setSummSrchUpdtUserId(mcaidDiscForm.getSummSrchUpdtUserId());
		fcloVO.setSummSrchPbp(mcaidDiscForm.getSummSrchPbp());
		logger.info(LoggerConstants.methodEndLevel());
	}
	//IFOX-00407694-FCLO/WRTO Changes: end
	private void setDiscSummGoSrchFormToVO(McaidReconDiscForm mcaidDiscForm, McaidReconAnomVO discrpAnomVO) {
		logger.info(LoggerConstants.methodStartLevel());
		discrpAnomVO.setSummSrchGoPbp(mcaidDiscForm.getSummSrchGoPbp());
		discrpAnomVO.setSummSrchGoStatus(mcaidDiscForm.getSummSrchGoStatus());
		discrpAnomVO.setSummSrchType(mcaidDiscForm.getSummSrchType());
		discrpAnomVO.setSummSrchMedicaidId(mcaidDiscForm.getSummSrchMedicaidId());
		discrpAnomVO.setSummSrchFromEffDate(mcaidDiscForm.getSummSrchFromEffDate());
		discrpAnomVO.setSummSrchToEffDate(mcaidDiscForm.getSummSrchToEffDate());
		discrpAnomVO.setSummSrchFromUpdtDate(mcaidDiscForm.getSummSrchFromUpdtDate());
		discrpAnomVO.setSummSrchToUpdtDate(mcaidDiscForm.getSummSrchToUpdtDate());
		discrpAnomVO.setSummSrchUpdtUserId(mcaidDiscForm.getSummSrchUpdtUserId());
		//State and plan value addition: start
		discrpAnomVO.setSummSrchStateValue(mcaidDiscForm.getSummSrchStateValue());
		discrpAnomVO.setSummSrchPlanValue(mcaidDiscForm.getSummSrchPlanValue());
		//State and plan value addition: end
		//IFOX-00408437 / 00408436 / 00408435:Region Search Addition: start
		discrpAnomVO.setSummSrchRegion(mcaidDiscForm.getSummSrchRegion());
		//IFOX-00408437 / 00408436 / 00408435:Region Search Addition: end
		discrpAnomVO.setSummSrchDiscrpCd(mcaidDiscForm.getSummSrchDiscrpCd());
		discrpAnomVO.setDiscrepancyCategory(mcaidDiscForm.getDiscrepancyCategory());
		logger.info(LoggerConstants.methodEndLevel());
	}// setDiscSummGoSrchFormToVO()

	private void setDiscDashboardGoSrchFormToVO(McaidReconDiscForm mcaidDiscForm, McaidReconDiscVO discrpDiscVO, McaidReconAnomVO discrpAnomVO) {
		logger.info(LoggerConstants.methodStartLevel());
		discrpDiscVO.setSummDiscPbp(mcaidDiscForm.getSummSrchGoPbp());
		discrpDiscVO.setSummDiscStatus(mcaidDiscForm.getSummSrchGoStatus());
		discrpDiscVO.setSummDiscType(mcaidDiscForm.getSummSrchType());
		discrpDiscVO.setSummDiscFrmDate(mcaidDiscForm.getSummSrchFromEffDate());
		discrpDiscVO.setSummDiscToDate(mcaidDiscForm.getSummSrchToEffDate());
		discrpDiscVO.setSummDiscType(mcaidDiscForm.getDiscrepancyCategory());
		discrpAnomVO.setSummSrchGoPbp(mcaidDiscForm.getSummSrchGoPbp());
		discrpAnomVO.setSummSrchGoStatus(mcaidDiscForm.getSummSrchGoStatus());
		discrpAnomVO.setSummSrchPbp(mcaidDiscForm.getSummSrchGoPbp());
		discrpAnomVO.setSummSrchStatus(mcaidDiscForm.getSummSrchGoStatus());
		discrpAnomVO.setSummSrchType(mcaidDiscForm.getSummSrchType());
		discrpAnomVO.setSummSrchFromEffDate(mcaidDiscForm.getSummSrchFromEffDate());
		discrpAnomVO.setSummSrchToEffDate(mcaidDiscForm.getSummSrchToEffDate());
		discrpAnomVO.setSummSrchType(mcaidDiscForm.getDiscrepancyCategory());
		logger.info(LoggerConstants.methodEndLevel());
	}

	private void setAnomDashboardGoSrchFormToVO(McaidReconAnomForm mcaidAnomForm, McaidReconAnomVO discrpAnomVO) {
		logger.info(LoggerConstants.methodStartLevel());
		discrpAnomVO.setSummSrchGoPbp(mcaidAnomForm.getSummSrchGoPbp());
		discrpAnomVO.setSummSrchGoStatus(mcaidAnomForm.getSummSrchGoStatus());
		discrpAnomVO.setSummSrchType(mcaidAnomForm.getSummSrchType());
		discrpAnomVO.setSummSrchFromEffDate(mcaidAnomForm.getSummSrchFromEffDate());
		discrpAnomVO.setSummSrchToEffDate(mcaidAnomForm.getSummSrchToEffDate());
		discrpAnomVO.setSummSrchType(mcaidAnomForm.getAnamolyCategory());
		logger.info(LoggerConstants.methodEndLevel());
	}

	public String getpaymentSearch(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconPaymentForm mcaidPaymentForm) {
		logger.info(LoggerConstants.methodStartLevel());
		McaidReconPaymentVO paymentVO = context.getPaymentVO();
		String mfId = sessionHelper.getMfId();
		setpaymentSearchInputDataToVO(mcaidPaymentForm, paymentVO);
		// new McaidILService().getpaymentSummData(conn, mfId, paymentVO);
		new McaidILService().getpaymentSearch(conn, mfId, paymentVO);
		new McaidILService().getpaymentSummDetails(conn, mfId, paymentVO, "search");
		if (!StringUtil.nonNullTrim(paymentVO.getMedicaidId()).equals("")) {
			getpaymentSummMedicaids(conn, sessionHelper, context, mcaidPaymentForm, "go");
		}
		else
			paymentVO.setMcaidPymntSummMedicaidLst(null);
		setPaySummDataVOtoForm(mcaidPaymentForm, paymentVO, mfId);// this
																	// replaced
																	// above 2
																	// commented
																	// sections.
		logger.info(LoggerConstants.methodEndLevel());
		return "ILmcaidPaymentSummary";
	}// getpaymentSummData()

	public String getpaymentDashboardSearch(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconPaymentForm mcaidPaymentForm) {
		logger.info(LoggerConstants.methodStartLevel());
		McaidReconPaymentVO paymentVO = context.getPaymentVO();
		String mfId = sessionHelper.getMfId();
		setpaymentSearchInputDataToVO(mcaidPaymentForm, paymentVO);
		logger.debug("dateType ==" + mcaidPaymentForm.getDateType() + " " + paymentVO.getDateType());
		// new McaidNMService().getpaymentSummData(conn, mfId, paymentVO);
		new McaidILService().getpaymentDashboardSearch(conn, mfId, paymentVO);
		// new McaidNMService().getpaymentSummDetails(conn, mfId, paymentVO);
		mcaidPaymentForm.setMcaidPymntDsbPBPLst(paymentVO.getMcaidPymntDsbPBPLst());
		McaidReconCodeCache objCache = McaidReconCodeCache.getInstance(mfId);
		mcaidPaymentForm.setLstpbpIdPayment(objCache.getLstPbp());
		setPaySummDataVOtoForm(mcaidPaymentForm, paymentVO, mfId);// this
																	// replaced
																	// above 2
																	// commented
																	// sections.
		logger.info(LoggerConstants.methodEndLevel());
		return "ILmcaidPayment";
	}// getpaymentSummData()

	private void setpaymentSearchInputDataToVO(McaidReconPaymentForm form, McaidReconPaymentVO vo) {
		logger.info(LoggerConstants.methodStartLevel());
		vo.setSummSrchPbp(form.getPbpIdPayment());
		vo.setSummSrchYear(form.getSummSrchYear());
		vo.setSummSrchQtr(form.getSummSrchQtr());
		vo.setSummSrchMonth(form.getSummSrchMonth());
		vo.setPbpIdPayment(form.getPbpIdPayment());
		vo.setDateType(form.getDateType());
		vo.setFromDate(form.getFromDate());
		vo.setToDate(form.getToDate());
		vo.setMedicaidId(form.getMedicaidId());
		logger.info(LoggerConstants.methodEndLevel());
	}// setpaymentSearchInputDataToVO()

	/*
	 * public String setPaySummDataVOtoForm(McaidReconPaymentForm
	 * mcaidPaymentForm, McaidReconPaymentVO paymentVO){
	 * 
	 * mcaidPaymentForm.setMcaidPymntSummLst(paymentVO.getMcaidPymntSummLst());
	 * mcaidPaymentForm.setSummPageLabel1(paymentVO.getSummPageLabel1());
	 * mcaidPaymentForm.setSummDataCmsPaid(paymentVO.getSummDataCmsPaid());
	 * mcaidPaymentForm.setSummDataDiffrence(paymentVO.getSummDataDiffrence());
	 * mcaidPaymentForm.setSummDataPlanExpected(paymentVO.
	 * getSummDataPlanExpected());
	 * 
	 * mcaidPaymentForm.setMcaidPymntSummDetailLst(paymentVO.
	 * getMcaidPymntSummDetailLst());
	 * mcaidPaymentForm.setSummDetailCmsPaid(paymentVO.getSummDetailCmsPaid());
	 * mcaidPaymentForm.setSummDetailPlanExpected(paymentVO.
	 * getSummDetailPlanExpected());
	 * mcaidPaymentForm.setSummDetailDiffrence(paymentVO.getSummDetailDiffrence(
	 * ));
	 * 
	 * mcaidPaymentForm.setMcaidPymntSummMedicaidLst(paymentVO.
	 * getMcaidPymntSummMedicaidLst());
	 * mcaidPaymentForm.setSummPageLabel2(paymentVO.getSummPageLabel2());
	 * mcaidPaymentForm.setSummMedicLstPageNbr(paymentVO.getSummMedicLstPageNbr(
	 * )); mcaidPaymentForm.setSummMedicLstPageType(paymentVO.
	 * getSummMedicLstPageType());
	 * 
	 * return "ILmcaidPaymentSummary";
	 * 
	 * }//setPaySummDataVOtoForm()
	 */

	/*
	 * ********************* DISC EXPORT / PRINT ******************************
	 * START
	 */
	public String printMcaidDisc(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			HttpServletRequest request, HttpServletResponse response, McaidReconDiscForm mcaidDiscForm,
			String printOption, String printSubMenu, String pageRange) {
		logger.info(LoggerConstants.methodStartLevel());

		McaidReconDiscVO discVO = context.getDiscrepanciesVO();
		McaidReconAnomVO discAnomVO = context.getDiscAnamolyVO();

		String mappingTarget = printSubMenu.equals(McaidReconConstants.SUBMENU_DISC_DASHBOARD) ? "ILmcaidDisc"
				: printSubMenu.equals(McaidReconConstants.SUBMENU_DISC_DASHBOARD_DETAIL) ? "ILmcaidDiscDetail"
						: "ILmcaidDiscSummary";

		if (printOption.equals("Print")) {
			mappingTarget = "discPrint";
			if (printSubMenu.equals(McaidReconConstants.SUBMENU_DISC_DASHBOARD)) {
				McaidReconDiscVO vo = context.getDiscrepanciesVO();
				mcaidDiscForm.setMcaidDiscDsbPBPLst(vo.getMcaidDiscDsbPBPLst());

			} else if (printSubMenu.equals(McaidReconConstants.SUBMENU_DISC_DASHBOARD_DETAIL)) {// Intermediate
																								// Summary
																								// Screen
				McaidReconAnomVO vo = context.getDiscAnamolyVO();
				mcaidDiscForm.setSummPageLabel1(discAnomVO.getSummPageLabel1());
				mcaidDiscForm.setDiscrpDetailsLst(vo.getDiscrpDetailsLst());

			} else {// SUMMARY
				if (pageRange.equals("Current")) {
					mcaidDiscForm.setSummPageLabel1(discAnomVO.getSummPageLabel1());
					mcaidDiscForm.setSummAnomListLst(discAnomVO.getSummAnomListLst());
					mcaidDiscForm.setAnomSummDetailDataVo(discAnomVO.getAnomSummDetailDataVo());
				} else {// ALL Pages
					List listData = new McaidILService().getDiscSummListPrintData(conn, sessionHelper.getMfId(),
							discAnomVO);
					mcaidDiscForm.setSummAnomListLst(listData);
				}
			}
		} else if (printOption.equals("CSV")) {
			try {
				HSSFWorkbook workbook = null;
				if (printSubMenu.equals(McaidReconConstants.SUBMENU_DISC_DASHBOARD)) {
					workbook = new CreateDiscExcelService().createDashboardWorkbook(discVO.getMcaidDiscDsbPBPLst());
				} else if (printSubMenu.equals(McaidReconConstants.SUBMENU_DISC_DASHBOARD_DETAIL)) {// Intermediate
																									// Summary
																									// Screen
					workbook = new CreateDiscExcelService()
							.createDashboardSummaryWorkbook(discAnomVO.getDiscrpDetailsLst());// New
																								// Method
																								// to
																								// written
																								// for
																								// detail
																								// screen
																								// csv
				}

				else {// SUMMARY
					if (pageRange.equals("Current")) {
						//Newborn\Kick Export Change:start
						workbook = new CreateDiscExcelService().createSummaryWorkbook(discAnomVO.getSummAnomListLst(), discAnomVO);
					} else {// ALL Pages
						List listData = new McaidILService().getDiscSummListPrintData(conn, sessionHelper.getMfId(),
								discAnomVO);
						workbook = new CreateDiscExcelService().createSummaryWorkbook(listData, discAnomVO);
					}//Newborn\Kick Export Change:end
				} // SUMMARY-else
				response.setHeader("Content-Disposition", "attachment; filename=DiscrepancyExport.xls");
				ServletOutputStream out = response.getOutputStream();
				workbook.write(out);
				out.flush();
				out.close();
			} catch (Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				e.printStackTrace();
			}
		} else if (printOption.equals("PDF")) {/// PDF
			ByteArrayOutputStream report = null;
			try {
				/* Payment Dash-board */
				if (printSubMenu.equals(McaidReconConstants.SUBMENU_DISC_DASHBOARD)) {
					report = new CreateDiscPdfService().createDashboardDescPDFReport(discVO.getMcaidDiscDsbPBPLst());
				}
				else if (printSubMenu.equals(McaidReconConstants.SUBMENU_DISC_DASHBOARD_DETAIL)) {// Discrepancy
																								// Intermediate
																								// Summary
																								// Screen
					report = new CreateDiscPdfService().createDashboardSummaryPDFReport(
							discAnomVO.getDiscrpDetailsLst(), discAnomVO.getSummPageLabel1()); // write
																								// new
																								// method
				}

				/* Payment Summary */
				else {
					if (pageRange.equals("Current")) {
						report = new CreateDiscPdfService().currentSummaryDescPDFReport(discAnomVO.getSummPageLabel1(),
								discAnomVO.getSummAnomListLst(), discAnomVO.getAnomSummDetailDataVo());
					} else {// ALL Pages

						List listData = new McaidILService().getDiscSummListPrintData(conn, sessionHelper.getMfId(),
								discAnomVO);
						report = new CreateDiscPdfService().createAllPagesSummaryDescPDFReport(listData);

					}
				}
				response.setContentType("application/pdf");
				response.setHeader("content-disposition", "attachment; filename=DiscExport.pdf");
				response.setContentLength(report.size());
				ServletOutputStream servletStream = null;
				servletStream = response.getOutputStream();
				report.writeTo(servletStream);
				servletStream.flush();
				servletStream.close();
				report.close();
			} catch (Exception e1) {
				logger.error(LoggerConstants.exceptionMessage(e1.toString()));
				e1.printStackTrace();
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// printMcaidDisc()

	public String getDiscSummDetailsData(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconDiscForm mcaidDiscForm, String move, String from) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconAnomVO anomVO = context.getDiscAnamolyVO();
		String mfId = sessionHelper.getMfId();
		if (from != null) {
			anomVO.setSummAnomLstOptFrom(from);
		}
		if (anomVO.getSummAnomLstOptFrom().equals("DETAILS")) {
			setDiscSummDsbSrchFormToVO(mcaidDiscForm, anomVO);
		} else {
			setDiscSummGoSrchFormToVO(mcaidDiscForm, anomVO);
		}

		anomVO.setPaymentSummaryMedicaidIdViewIndicator(
				context.getPaymentVO().getPaymentSummaryMedicaidIdViewIndicator());

		List discrpDetailsLst = new McaidILService().getDiscDetailsData(conn, mfId, anomVO, move);
		anomVO.setDiscrpDetailsLst(discrpDetailsLst);
		// System.out.println("McaidNMManager.getDiscSummListData()"+hasListData);
		setDiscSummListDataVOtoForm(mcaidDiscForm, anomVO);

		setDiscSrchSummContentVOToForm(mcaidDiscForm, anomVO, mfId);
		mappingTarget = "NMmcaidDiscDetail";

		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// getDiscSummDetailsData
	/*
	 * ********************* DISC EXPORT / PRINT ******************************
	 * END
	 */
	/*
	 * ********************* PAYMENT EXPORT / PRINT
	 * ****************************** START
	 */

	public String printMcaidPayment(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			HttpServletRequest request, HttpServletResponse response, McaidReconPaymentForm mcaidPaymentForm,
			String printOption, String printSubMenu, String pageRange) {
		logger.info(LoggerConstants.methodStartLevel());

		McaidReconPaymentVO paymentVO = context.getPaymentVO();
		String mappingTarget = printSubMenu.equals(McaidReconConstants.SUBMENU_PAYMENT_DASHBOARD) ? "ILmcaidPayment"
				: "ILmcaidPaymentSummary";
		paymentVO.setPbpIdPayment(mcaidPaymentForm.getPbpIdPayment());
		if (printOption.equals("Print")) {
			mappingTarget = "paymentPrint";
			if (printSubMenu.equals(McaidReconConstants.SUBMENU_PAYMENT_DASHBOARD)) {
				mcaidPaymentForm.setMcaidPymntDsbPBPLst(paymentVO.getMcaidPymntDsbPBPLst());

			} else {// SUMMARY
				if (pageRange.equals("Current")) {

					mcaidPaymentForm.setMcaidPymntSummLst(paymentVO.getMcaidPymntSummLst());
					mcaidPaymentForm.setSummPageLabel1(paymentVO.getSummPageLabel1());
					mcaidPaymentForm.setSummDataCmsPaid(paymentVO.getSummDataCmsPaid());

					// Setting SummDataDiffrence value to 'null' so that it
					// recalculates the sum in payment summary dash board
					// instead of pulling directly from the form
					paymentVO.setSummDataDiffrence(null);

					mcaidPaymentForm.setSummDataDiffrence(paymentVO.getSummDataDiffrence());
					mcaidPaymentForm.setSummDataPlanExpected(paymentVO.getSummDataPlanExpected());

					mcaidPaymentForm.setMcaidPymntSummDetailLst(paymentVO.getMcaidPymntSummDetailLst());
					mcaidPaymentForm.setSummDetailCmsPaid(paymentVO.getSummDetailCmsPaid());
					mcaidPaymentForm.setSummDetailPlanExpected(paymentVO.getSummDetailPlanExpected());
					mcaidPaymentForm.setSummDetailDiffrence(paymentVO.getSummDetailDiffrence());

					mcaidPaymentForm.setMcaidPymntSummMedicaidLst(paymentVO.getMcaidPymntSummMedicaidLst());
					mcaidPaymentForm.setSummPageLabel2(paymentVO.getSummPageLabel2());
					mcaidPaymentForm.setSummMedicLstPageNbr(paymentVO.getSummMedicLstPageNbr());
					mcaidPaymentForm.setSummMedicLstPageType(paymentVO.getSummMedicLstPageType());

				} else {// ALL Pages
					List listData = new McaidILService().getMcaidPaymentDetailsData(conn, sessionHelper.getMfId(),
							paymentVO);
					mcaidPaymentForm.setSummPageLabel2(paymentVO.getSummPageLabel2());
					mcaidPaymentForm.setMcaidPymntSummMedicaidLst(listData);
				}
			}
		} else if (printOption.equals("CSV")) {
			try {
				HSSFWorkbook workbook = null;
				if (printSubMenu.equals(McaidReconConstants.SUBMENU_PAYMENT_DASHBOARD)) {
					workbook = new CreatePaymentExcelService()
							.createDashboardWorkbook(paymentVO.getMcaidPymntDsbPBPLst());
				} else {// SUMMARY
					if (pageRange.equals("Current")) {
						workbook = new CreatePaymentExcelService().createSummaryWorkbook(paymentVO,
								paymentVO.getMcaidPymntSummLst(),
								paymentVO.getMcaidPymntSummDetailLst() ,paymentVO.getMcaidPymntSummMedicaidLst()
																		);
					} else {// ALL Pages
						List listData = new McaidILService().getMcaidPaymentDetailsData(conn, sessionHelper.getMfId(),
								paymentVO);
						//System.out.println("McaidILManager.printMcaidPayment()======" + listData.size());
						workbook = new CreatePaymentExcelService()
								.createAllPymtSummaryWorkbook(paymentVO,
										paymentVO.getMcaidPymntSummLst(),paymentVO.getMcaidPymntSummDetailLst(), listData);
						// mappingTarget = "mcaidILPaymentSummary";
					}
				} // SUMMARY-else
				response.setHeader("Content-Disposition", "attachment; filename=PaymentExport.xls");
				ServletOutputStream out = response.getOutputStream();
				workbook.write(out);
				out.flush();
				out.close();
			} catch (Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				e.printStackTrace();
			}
		} else if (printOption.equals("PDF")) {/// PDF
			ByteArrayOutputStream report = null;
			try {
				/* Payment Dash-board */
				if (printSubMenu.equals(McaidReconConstants.SUBMENU_PAYMENT_DASHBOARD)) {
					report = new CreatePaymentPdfService().createDashboardPDFReport(paymentVO.getMcaidPymntDsbPBPLst());
				} /* Payment Summary */
				else {
					if (pageRange.equals("Current")) {
						report = new CreatePaymentPdfService().createSummaryPDFReport(paymentVO,
								paymentVO.getMcaidPymntSummLst(), paymentVO.getMcaidPymntSummDetailLst(),
								paymentVO.getMcaidPymntSummMedicaidLst());
					} else {// ALL Pages
						List listData = new McaidILService().getMcaidPaymentDetailsData(conn, sessionHelper.getMfId(),
								paymentVO);
						//System.out.println("McaidILManager.printMcaidPayment()======" + listData.size());
						report = new CreatePaymentPdfService().createAllPymtSummaryPDFReport(paymentVO,
								paymentVO.getMcaidPymntSummLst(), paymentVO.getMcaidPymntSummDetailLst(), listData);

					}
				}
				response.setContentType("application/pdf");
				response.setHeader("content-disposition", "attachment; filename=PaymentExport.pdf");
				response.setContentLength(report.size());
				ServletOutputStream servletStream = null;
				servletStream = response.getOutputStream();
				report.writeTo(servletStream);
				servletStream.flush();
				servletStream.close();
				report.close();
			} catch (Exception e1) {
				logger.error(LoggerConstants.exceptionMessage(e1.toString()));
				e1.printStackTrace();
			}

		}

		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// printMcaidDisc()

	public String getmcaidPaymentSummDetailsData(Connection conn, SessionHelper sessionHelper,
			McaidReconContext context, McaidReconPaymentForm mcaidPaymentForm, String move, String from) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconPaymentVO paymentVO = context.getPaymentVO();
		String mfId = sessionHelper.getMfId();
		paymentVO.setFromDate("DETAILS");
		if (paymentVO.getFromDate().equals("DETAILS")) {
			setpaymentSearchInputDataToVO(mcaidPaymentForm, paymentVO);
		} else {
			setpaymentSummInputDataToVO(mcaidPaymentForm, paymentVO);
		}

		paymentVO.setPaymentSummaryMedicaidIdViewIndicator(
				context.getPaymentVO().getPaymentSummaryMedicaidIdViewIndicator());

		List paymentSummDetailsLst = new McaidILService().getPaymentDetailsData(conn, mfId, paymentVO, move);
		paymentVO.setMcaidPymntSummDetailLst(paymentSummDetailsLst);
		setpaymentSearchInputDataToVO(mcaidPaymentForm, paymentVO);
		setPaySummDataVOtoForm(mcaidPaymentForm, paymentVO, mfId);
		mappingTarget = "NMmcaidPaymentDetail";

		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// getDiscSummDetailsData
	/*
	 * ********************* PAYMENT EXPORT / PRINT
	 * ****************************** END
	 */
	/*
	 * ********************* ANOM EXPORT / PRINT ******************************
	 * END
	 */

	public String printMcaidAnom(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			HttpServletRequest request, HttpServletResponse response, McaidReconAnomForm mcaidAnomForm,
			String printOption, String printSubMenu, String pageRange) {
		logger.info(LoggerConstants.methodStartLevel());

		McaidReconAnomVO discVO = context.getAnamolyVO();
		McaidReconAnomVO discAnomVO = context.getDiscAnamolyVO();

		String mappingTarget = printSubMenu.equals(McaidReconConstants.SUBMENU_ANOM_DASHBOARD) ? "ILmcaidAnom"
				: printSubMenu.equals(McaidReconConstants.SUBMENU_ANOM_DASHBOARD_DETAIL) ? "ILmcaidAnomDetail"
						: "ILmcaidAnomSummary";

		if (printOption.equals("Print")) {
			mappingTarget = "anomPrint";
			if (printSubMenu.equals(McaidReconConstants.SUBMENU_ANOM_DASHBOARD)) {
				McaidReconAnomVO vo = context.getAnamolyVO();
				mcaidAnomForm.setMcaidAnomDsbPBPLst(vo.getMcaidAnomDsbPBPLst());

			} else if (printSubMenu.equals(McaidReconConstants.SUBMENU_ANOM_DASHBOARD_DETAIL)) {// Intermediate
																								// Summary
																								// Screen
				McaidReconAnomVO vo = context.getAnamolyVO();
				mcaidAnomForm.setSummPageLabel1(discAnomVO.getSummPageLabel1());
				mcaidAnomForm.setDiscrpDetailsLst(vo.getDiscrpDetailsLst());

			} else {// SUMMARY
				if (pageRange.equals("Current")) {
					mcaidAnomForm.setSummPageLabel1(discVO.getSummPageLabel1());
					mcaidAnomForm.setSummAnomListLst(discVO.getSummAnomListLst());
					mcaidAnomForm.setAnomSummDetailDataVo(discVO.getAnomSummDetailDataVo());
				} else {// ALL Pages
					List listData = new McaidILService().getAnomSummListPrintData(conn, sessionHelper.getMfId(),
							discVO);
					mcaidAnomForm.setSummAnomListLst(listData);
				}
			}
		} else if (printOption.equals("CSV")) {
			try {
				HSSFWorkbook workbook = null;
				if (printSubMenu.equals(McaidReconConstants.SUBMENU_ANOM_DASHBOARD)) {
					workbook = new CreateAnomExcelService().createDashboardWorkbook(discVO.getMcaidAnomDsbPBPLst());
				} else if (printSubMenu.equals(McaidReconConstants.SUBMENU_ANOM_DASHBOARD_DETAIL)) {// Intermediate
																									// Summary
																									// Screen
					workbook = new CreateDiscExcelService().createAnomalySummaryWorkbook(discVO.getDiscrpDetailsLst());// New
																														// Method
																														// to
																														// written
																														// for
																														// detail
																														// screen
																														// csv
				} else {// SUMMARY
					if (pageRange.equals("Current")) {
						workbook = new CreateAnomExcelService()
								.createSummaryWorkbook(discVO.getSummPageLabel1(),
										discVO.getSummAnomListLst(),
										discVO.getAnomSummDetailDataVo());
					} else {// ALL Pages
						List listData = new McaidILService().getAnomSummListPrintData(conn, sessionHelper.getMfId(),
								discVO);
						workbook = new CreateAnomExcelService().createSummaryWorkbook(discVO.getSummPageLabel1(),
								listData,
								discVO.getAnomSummDetailDataVo());
					}
				} // SUMMARY-else
				response.setHeader("Content-Disposition", "attachment; filename=AnomalyExport.xls");
				ServletOutputStream out = response.getOutputStream();
				workbook.write(out);
				out.flush();
				out.close();
			} catch (Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				e.printStackTrace();
			}
		} else if (printOption.equals("PDF")) {/// PDF
			ByteArrayOutputStream report = null;
			try {
				/* Anomalies Dash-board */
				if (printSubMenu.equals(McaidReconConstants.SUBMENU_ANOM_DASHBOARD)) {
					report = new CreateAnomaliesPdfService().createDashboardPDFReport(discVO.getMcaidAnomDsbPBPLst());
				} /* Anomalies Summary */
				else if (printSubMenu.equals(McaidReconConstants.SUBMENU_ANOM_DASHBOARD_DETAIL)) {// Discrepancy
																								// Intermediate
																								// Summary
																								// Screen
					report = new CreateDiscPdfService().createAnomalySummaryPDFReport(discVO.getDiscrpDetailsLst(),
							discVO.getSummPageLabel1()); // write new method
				}

				else {
					if (pageRange.equals("Current")) {
						// report = new
						// CreateAnomaliesPdfService().createSummaryPDFReport(paymentVO,paymentVO.getMcaidPymntSummLst(),paymentVO.getMcaidPymntSummDetailLst());
						report = new CreateAnomaliesPdfService().createSummaryPDFReport(discVO.getSummPageLabel1(),
								discVO.getSummAnomListLst(),
								discVO.getAnomSummDetailDataVo()/*
																 * ,null ==
																 * discVO.
																 * getSummAnomListLst
																 * () ? new
																 * ArrayList() :
																 * discAnomVO.
																 * getSummAnomListLst
																 * ()
																 */);
					} else {// ALL Pages
						List listData = new McaidILService().getAnomSummListPrintData(conn, sessionHelper.getMfId(),
								discVO);
						report = new CreateAnomaliesPdfService()
								.createAllAnomSummaryPDFReport(discVO.getSummPageLabel1(), listData);

					}
				}
				response.setContentType("application/pdf");
				response.setHeader("content-disposition", "attachment; filename=AnomalyExport.pdf");
				response.setContentLength(report.size());
				ServletOutputStream servletStream = null;
				servletStream = response.getOutputStream();
				report.writeTo(servletStream);
				servletStream.flush();
				servletStream.close();
				report.close();
			} catch (Exception e1) {
				logger.error(LoggerConstants.exceptionMessage(e1.toString()));
				e1.printStackTrace();
			}

		}
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// printMcaidDisc()

	public String getAnomSummDetailsData(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconAnomForm mcaidAnomForm, String move, String from) {
		logger.info(LoggerConstants.methodStartLevel());
		String mappingTarget = "error";
		McaidReconAnomVO anomVO = context.getAnamolyVO();
		String mfId = sessionHelper.getMfId();
		if (from != null) {
			anomVO.setSummAnomLstOptFrom(from);
		}
		if (anomVO.getSummAnomLstOptFrom().equals("DETAILS")) {
			setAnomSummDsbSrchFormToVO(mcaidAnomForm, anomVO);
		} else {
			setAnomSummGoSrchFormToVO(mcaidAnomForm, anomVO);
		}

		anomVO.setPaymentSummaryMedicaidIdViewIndicator(
				context.getPaymentVO().getPaymentSummaryMedicaidIdViewIndicator());

		List discrpDetailsLst = new McaidILService().getAnomDetailsData(conn, mfId, anomVO, move);
		anomVO.setDiscrpDetailsLst(discrpDetailsLst);
		setAnomSummListDataVOtoForm(mcaidAnomForm, anomVO);

		setAnomSrchSummContentVOToForm(mcaidAnomForm, anomVO, mfId);
		mappingTarget = "NMmcaidDiscDetail";

		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// getDiscSummDetailsData
	/*
	 * ********************* ANOM EXPORT / PRINT ******************************
	 * END
	 */
	public String printMcaidFile(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			HttpServletRequest request, HttpServletResponse response, McaidReconFileForm mcaidFileForm,
			String printOption, String printSubMenu, String pageRange) {
		logger.info(LoggerConstants.methodStartLevel());

		McaidReconFileVO fileVO = context.getFileVO();
		//McaidReconAnomVO discAnomVO = conteRxt.getDiscAnamolyVO();
		String mfId = sessionHelper.getMfId();
		String mappingTarget = "NMmcaidFileInventory";

		if (printOption.equals("Print")) {
			mappingTarget = "filePrint";
			
				if (pageRange.equals("Current")) {
					mcaidFileForm.setMcaidFilesLst(fileVO.getMcaidFilesLst());
					setFileVOToForm(mcaidFileForm, fileVO);
					fileInitialization(conn, sessionHelper, context, mcaidFileForm, null);
				} else {// ALL Pages
					List listData = new McaidILDao().getPrintFileLists(conn, mfId, fileVO, "");
					mcaidFileForm.setMcaidFilesLst(listData);
					setFileVOToForm(mcaidFileForm, fileVO);
					fileInitialization(conn, sessionHelper, context, mcaidFileForm, null);
				}
			}
		else if (printOption.equals("CSV")) {
			try {
				HSSFWorkbook workbook = null;
				if (pageRange.equals("Current")) {
						workbook = new CreateDiscExcelService().createFileWorkbook(fileVO.getMcaidFilesLst());
					} else {// ALL Pages
						List listData = new McaidILDao().getPrintFileLists(conn, mfId, fileVO, "");
						workbook = new CreateDiscExcelService().createFileWorkbook(listData);
					}
			
				response.setHeader("Content-Disposition", "attachment; filename=FileInventoryExport.xls");
				ServletOutputStream out = response.getOutputStream();
				workbook.write(out);
				out.flush();
				out.close();
			} catch (Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				e.printStackTrace();
			}
		} else if (printOption.equals("PDF")) {/// PDF
			ByteArrayOutputStream report = null;
			try {
				 if (pageRange.equals("Current")) {
						report = new CreateDiscPdfService().currentFilesPDFReport(fileVO.getMcaidFilesLst(), fileVO);
					} else {// ALL Pages

						List listData = new McaidILDao().getPrintFileLists(conn, mfId, fileVO, "");
						report = new CreateDiscPdfService().createAllPagesFilesPDFReport(listData, fileVO);

					}
				
				response.setContentType("application/pdf");
				response.setHeader("content-disposition", "attachment; filename=FilesExport.pdf");
				response.setContentLength(report.size());
				ServletOutputStream servletStream = null;
				servletStream = response.getOutputStream();
				report.writeTo(servletStream);
				servletStream.flush();
				servletStream.close();
				report.close();
				
			} catch (Exception e1) {
				logger.error(LoggerConstants.exceptionMessage(e1.toString()));
				e1.printStackTrace();
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}// printMcaidDisc()
	
	//Added for Extract All Records: Start
	public String extractAllRecords(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconDiscForm mcaidDiscForm, String reqType, Object object) {
		logger.info(LoggerConstants.methodStartLevel());
		McaidReconAnomVO anomVO = context.getDiscAnamolyVO();
		//HttpSession session = this.getSession();
		FTPClient ftp = null;
		MFUserPersistence mfUsrP = new MFUserPersistence();
		//String mfId =(String)session.getAttribute("Mf_id");
		String mfId = sessionHelper.getMfId();
		//String UserId = Constants.SESSION_USER_ID;
		String indexFilePath = "";
		String queryFilePath = "";
		DateUtil du = new DateUtil();
		String logFileDts = null;
		sessionHelper.getActiveDataBaseName();
		String finalQuery = "";
		logFileDts = du.formatFileDTS(du.getDTS());
		String sbQuery = mcaidDiscForm.getExtractQuery();
		String regionStr = "";
		String DB =  sessionHelper.getSession().getAttribute(SessionManager.RECONDB).toString();
		if(DB.equals("DB2V")){
			 finalQuery = sbQuery.toUpperCase().replace("FROM ", "FROM MSSPROD.");
			 regionStr="PROD";
		}
		else {
			finalQuery = sbQuery.toUpperCase().replace("FROM ", "FROM MSSQUAL.");
			 regionStr="QA";
		}
	
		try{
			//Generating the Trigger File with file name information :start 
			//Path for local testing
			//FileWriter FW = new FileWriter("C:\\Users\\ssrivastava\\Workspace\\WAS 7 trunk-New\\Mss\\WebContent\\mss\\Trig\\UserIDTrigger.txt",false);
			//Actual server path 
			FileWriter FW = new FileWriter("C:\\Recon\\Trig\\UserIDTrigger.txt",false);
			String rptType = "";
			if(reqType.equalsIgnoreCase("disc"))
				rptType="DSCR";
			else
				rptType="ANMLY";
			String fileName = "HCF0325.IL."+rptType+"RPT."+sessionHelper.getUserId()+"."+logFileDts+".CSV";
			
			   try {
	            	BufferedWriter  writer = new BufferedWriter(FW);
	            	String data = "     \\"+mfId+"\\RECON\\"+fileName;
	              
	                writer.write(data);
	                writer.newLine();
	                data = "QUIT";
	                writer.append(data);
	                writer.newLine();
	                data = "/*";
	                writer.append(data);
	                writer.close();
	            } catch (IOException e) {
	            	logger.error(LoggerConstants.exceptionMessage(e.toString()));
	                e.printStackTrace();
	            }
			 //Generating the Trigger File with file name information :end
			 
			  // FTP the Trigger file to MF : start
			   String indexFileName = "MDRECON."+regionStr+"."+rptType+".TRIG";
			   String mfPwd = mfUsrP.getMfPwd(conn,mfId);
				ftp = new FTPClient();
				ftp.connect("171.74.161.27");
				ftp.login(mfId,mfPwd);
				ftp.ascii();
				ftp.quoteSite("UNIT=DISK");
				ftp.quoteSite("LRECL=80");
				ftp.quoteSite("BLKSIZE=0");
				ftp.quoteSite("SPACE=(5,5)");


				//Path for local testing 
								//indexFilePath = ("C:/Users/ssrivastava/Workspace/WAS 7 trunk-New/Mss/WebContent/mss/Trig/UserIDTrigger.txt");
								//Actual server path 
								indexFilePath = ("C:/Recon/Trig/UserIDTrigger.txt");
				 // FTP the Trigger file to MF : end 
				ftp.put(indexFilePath,indexFileName);
			// Generating the Query File : start 
				
				//Path for Local Testing
				//FileWriter FW1 = new FileWriter("C:\\Users\\ssrivastava\\Workspace\\WAS 7 trunk-New\\Mss\\WebContent\\mss\\Trig\\ProdDiscListQuery.txt");
				//Actual Path 
				FileWriter FW1 = new FileWriter("C:\\Recon\\Trig\\ProdDiscListQuery.txt");
				try {
						BufferedWriter  writer = new BufferedWriter(FW1);
		            	String str = finalQuery;
		            	String[] parts = str.split("(?=AND)");
		            	for(int i=0; i <parts.length;i++){
		            		  writer.newLine();
		            		  writer.write(parts[i]);
		            		 
		            	}
		            	//System.out.println(count); 
		                //String contents = finalQuery.toString()+" WITH UR;";
		                //writer.write(" FETCH FIRST 10 ROWS ONLY;");
		            	writer.write(" ;");
		                writer.close();
		            } catch (IOException e) {
		            	logger.error(LoggerConstants.exceptionMessage(e.toString()));
		                e.printStackTrace();
		            }
				// Generating the Query File : end
				
				 // FTP the Query file to MF : start
				String queryFileName = "";
				if(mcaidDiscForm.getDiscrepancyCategory().equals("KIPN"))
					 queryFileName = "MDRECON."+regionStr+"."+rptType+"KICK"+".QUERY1";
				else if (mcaidDiscForm.getDiscrepancyCategory().equals("KIUN"))
					queryFileName = "MDRECON."+regionStr+"."+rptType+"KICK"+".QUERY2";
				else
					queryFileName = "MDRECON."+regionStr+"."+rptType+"HIST"+".QUERY";
					ftp = new FTPClient();
					ftp.connect("171.74.161.27");
					ftp.login(mfId,mfPwd);
					ftp.ascii();
					ftp.quoteSite("UNIT=DISK");
					ftp.quoteSite("LRECL=80");
					ftp.quoteSite("BLKSIZE=27920");
					ftp.quoteSite("SPACE=(5,5)");

					//local testing path
					//queryFilePath = ("C:/Users/ssrivastava/Workspace/WAS 7 trunk-New/Mss/WebContent/mss/Trig/ProdDiscListQuery.txt");
					//Actual path 
					queryFilePath = ("C:/Recon/Trig/ProdDiscListQuery.txt");
					ftp.put(queryFilePath,queryFileName);
					// FTP the Trigger file to MF : end 
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
		}
		
		anomVO.setPopupMsg("Request for Report is submitted and will be available under File Transfer Tab!");
		setDiscSummDataVOtoForm(mcaidDiscForm, anomVO);
		mcaidDiscForm.setPopupMsg(anomVO.getPopupMsg());
		setDiscSrchSummContentVOToForm(mcaidDiscForm, anomVO, mfId);
		String mappingTarget = "ILmcaidDiscSummary";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}
	public String extractAllAnomRecords(Connection conn, SessionHelper sessionHelper, McaidReconContext context,
			McaidReconAnomForm mcaidAnomForm, String reqType, Object object) {
		logger.info(LoggerConstants.methodStartLevel());
		McaidReconAnomVO anomVO = context.getAnamolyVO();
		//HttpSession session = this.getSession();
		FTPClient ftp = null;
		MFUserPersistence mfUsrP = new MFUserPersistence();
		//String mfId =(String)session.getAttribute("Mf_id");
		String mfId = sessionHelper.getMfId();
		//String UserId = Constants.SESSION_USER_ID;
		String indexFilePath = "";
		String queryFilePath = "";
		DateUtil du = new DateUtil();
		String logFileDts = null;
		sessionHelper.getActiveDataBaseName();
		String finalQuery = "";
		logFileDts = du.formatFileDTS(du.getDTS());
		String sbQuery = mcaidAnomForm.getExtractQuery();
		String regionStr = "";
		String DB =  sessionHelper.getSession().getAttribute(SessionManager.RECONDB).toString();
		if(DB.equals("DB2V")){
			 finalQuery = sbQuery.toUpperCase().replace("FROM ", "FROM MSSPROD.");
			 regionStr="PROD";
		}
		else {
			finalQuery = sbQuery.toUpperCase().replace("FROM ", "FROM MSSQUAL.");
			 regionStr="QA";
		}
	
		try{
			//Generating the Trigger File with file name information :start 
			//Path for local testing
			//FileWriter FW = new FileWriter("C:\\Users\\ssrivastava\\Workspace\\WAS 7 trunk-New\\Mss\\WebContent\\mss\\Trig\\UserIDTrigger.txt",false);
			//Actual server path 
			FileWriter FW = new FileWriter("C:\\Recon\\Trig\\UserIDTrigger.txt",false);
			String rptType = "";
			if(reqType.equalsIgnoreCase("disc"))
				rptType="DSCR";
			else
				rptType="ANMLY";
			String fileName = "HCF0325.IL."+rptType+"RPT."+sessionHelper.getUserId()+"."+logFileDts+".CSV";
			
			   try {
	            	BufferedWriter  writer = new BufferedWriter(FW);
	            	String data = "     \\"+mfId+"\\RECON\\"+fileName;
	              
	                writer.write(data);
	                writer.newLine();
	                data = "QUIT";
	                writer.append(data);
	                writer.newLine();
	                data = "/*";
	                writer.append(data);
	                writer.close();
	            } catch (IOException e) {
	            	logger.error(LoggerConstants.exceptionMessage(e.toString()));
	                e.printStackTrace();
	            }
			 //Generating the Trigger File with file name information :end
			 
			  // FTP the Trigger file to MF : start
			   String indexFileName = "MDRECON."+regionStr+"."+rptType+".TRIG";
			   String mfPwd = mfUsrP.getMfPwd(conn,mfId);
				ftp = new FTPClient();
				ftp.connect("171.74.161.27");
				ftp.login(mfId,mfPwd);
				ftp.ascii();
				ftp.quoteSite("UNIT=DISK");
				ftp.quoteSite("LRECL=80");
				ftp.quoteSite("BLKSIZE=0");
				ftp.quoteSite("SPACE=(5,5)");
				//Path for local testing 
				//indexFilePath = ("C:/Users/ssrivastava/Workspace/WAS 7 trunk-New/Mss/WebContent/mss/Trig/UserIDTrigger.txt");
				//Actual server path 
				indexFilePath = ("C:/Recon/Trig/UserIDTrigger.txt");
				 // FTP the Trigger file to MF : end 
				ftp.put(indexFilePath,indexFileName);
			// Generating the Query File : start 
				//Path for Local Testing
				//FileWriter FW1 = new FileWriter("C:\\Users\\ssrivastava\\Workspace\\WAS 7 trunk-New\\Mss\\WebContent\\mss\\Trig\\ProdDiscListQuery.txt");
				//Actual Path 
				FileWriter FW1 = new FileWriter("C:\\Recon\\Trig\\ProdDiscListQuery.txt");
				try {
						BufferedWriter  writer = new BufferedWriter(FW1);
		            	String str = finalQuery;
		            	String[] parts = str.split("(?=AND)");
		            	for(int i=0; i <parts.length;i++){
		            		  writer.newLine();
		            		  writer.write(parts[i]);
		            		 
		            	}
		            	//System.out.println(count); 
		                //String contents = finalQuery.toString()+" WITH UR;";
		                //writer.write(" FETCH FIRST 10 ROWS ONLY;");
		            	writer.write(" ;");
		                writer.close();
		            } catch (IOException e) {
		            	logger.error(LoggerConstants.exceptionMessage(e.toString()));
		                e.printStackTrace();
		            }
				// Generating the Query File : end
				
				 // FTP the Query file to MF : start
					String queryFileName = "MDRECON."+regionStr+"."+rptType+"HST"+".QUERY";
					ftp = new FTPClient();
					ftp.connect("171.74.161.27");
					ftp.login(mfId,mfPwd);
					ftp.ascii();
					ftp.quoteSite("UNIT=DISK");
					ftp.quoteSite("LRECL=80");
					ftp.quoteSite("BLKSIZE=27920");
					ftp.quoteSite("SPACE=(5,5)");
					//local testing path
					//queryFilePath = ("C:/Users/ssrivastava/Workspace/WAS 7 trunk-New/Mss/WebContent/mss/Trig/ProdDiscListQuery.txt");
					//Actual path 
					queryFilePath = ("C:/Recon/Trig/ProdDiscListQuery.txt");
					ftp.put(queryFilePath,queryFileName);
					// FTP the Trigger file to MF : end 
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
		}
		
		anomVO.setPopupMsg("Request for Report is submitted and will be available under File Transfer Tab!");
		setAnomDataVOtoForm(mcaidAnomForm, anomVO);
		mcaidAnomForm.setPopupMsg(anomVO.getPopupMsg());
		setAnomSrchSummContentVOToForm(mcaidAnomForm, anomVO, mfId);
		String mappingTarget = "ILmcaidAnomSummary";
		logger.info(LoggerConstants.methodEndLevel());
		return mappingTarget;
	}
	//Added for Extract All Records: End
}// class
