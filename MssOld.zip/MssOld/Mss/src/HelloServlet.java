import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class HelloServlet extends HttpServlet {

public void service(HttpServletRequest request, HttpServletResponse response)
  throws ServletException, IOException
{
    PrintWriter pw = response.getWriter();
    pw.println("<html>");
    pw.println("<head>");
    pw.println("</head>");
    pw.println("<body bgcolor='#F8F8EE'>");
    pw.println("<center>");
    pw.println("<font face='Arial' size='6'>Hello<BR>&nbsp;<BR>" + request.getServerName() + "</font>");
    pw.println("</Center>");
    pw.println("</body>");
    pw.println("</html>");
  }

}
