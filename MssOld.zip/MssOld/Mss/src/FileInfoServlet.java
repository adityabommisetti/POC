/*
 * $Id: FileInfoServlet.java,v 1.2 2016/04/12 22:20:56 dinesh Exp $
 */

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import com.ps.mss.util.MssProperties;

public class FileInfoServlet extends HttpServlet {
	private static Logger logger=LoggerFactory.getLogger(FileInfoServlet.class);

    public void service(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        
        HttpSession session  = request.getSession(false);
        if (session == null)
        {
            logger.error("No Session");
            return;
        }

        String User_id = (String) session.getAttribute("User_id");
        if (User_id == null)
        {
            logger.error("Null User_id");
            return;
        }

        response.setContentType("text/html");
        
        PrintWriter out = null;
        ServletInputStream in = null;
       
        BufferedOutputStream bout = null;
        BufferedReader bin = null;
        
        try {

            in = request.getInputStream();
            
            URL receiveServlet = new URL("http://" + MssProperties.getFileAppURL() + "/servlet/SendInfoServlet");
            URLConnection uc = receiveServlet.openConnection();

            uc.setDoInput(true);
            uc.setDoOutput(true);
            uc.setUseCaches(false);
            uc.setRequestProperty("Content-type","text/html");
            
            bout = new BufferedOutputStream(uc.getOutputStream());
        
            int bufSize = 4196;
            byte[] data = new byte[bufSize];        
                                   
            int bytesRead = 0;
            int totalBytes = 0;
                      
            while (bytesRead >= 0)
            {
                bytesRead = in.read(data,0,bufSize);
                //logger.error("Read: " + bytesRead);
                if (bytesRead == -1) break;
                totalBytes += bytesRead;
                bout.write(data,0,bytesRead);
            }                           

            bout.flush();
            
            bin = new BufferedReader(new InputStreamReader(uc.getInputStream()));
            out = response.getWriter();
            
            boolean done = false;
            while (!done) {
                String line = bin.readLine();
                if (line == null)
                    done = true;
                else {
                    out.write(line);
                    out.write("\n");
                }
            }
            
        } catch(Exception e) {
            logger.error(e.getMessage());
        } finally {
            try {
                if (in != null) in.close();
            } catch(Exception e) {
                logger.error(e.getMessage());
            }
            try {
                if (bout != null) bout.close();
            } catch(Exception e) {
                logger.error(e.getMessage());
            }
            try {
                if (bin != null) bin.close();
            } catch(Exception e) {
                logger.error(e.getMessage());
            }            
            try {
                if (out != null) out.close();
            } catch(Exception e) {
                logger.error(e.getMessage());
            }
        }
        
        out.close();
        
        return;        
    }

}
