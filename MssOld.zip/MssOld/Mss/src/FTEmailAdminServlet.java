/*
 * Created on Nov 9, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author levin.alex
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import java.io.IOException;
import java.sql.Connection;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import com.ps.mss.util.MssProperties;
import com.ps.mss.db.AppLogPersistence;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.Message;
import com.ps.mss.db.Module;
import com.ps.mss.framework.Constants;

import com.ps.mss.db.FTEmailListPersistence;

public class FTEmailAdminServlet extends HttpServlet
{
	private static Logger logger=LoggerFactory.getLogger(FTEmailAdminServlet.class);

	public void init(ServletConfig conf) throws ServletException {
		super.init(conf);
	}
	
	public void service(HttpServletRequest request, HttpServletResponse response)
	  throws ServletException, IOException
	{
		
		String BaseUrl = MssProperties.getWebAppURL();
		
		//	 session login 
	    HttpSession session  = request.getSession(false);
	    if (session == null)
	    {
	        logger.error("No Session");
	        response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/ErrorPFJsp.jsp?Msg=Page+Expired"));
	        return;
	    }
	    
	    String userId = (String) session.getAttribute("User_id");
	    if (userId == null) {
	        logger.error("No User Id");
	        response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/ErrorPFJsp.jsp?Msg=Invalid+Session"));
	        return;
	    }
	    
	    String MF_id = (String) session.getAttribute("MF_id");   
	    if (MF_id == null)
	    {
	        response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/ErrorPFJsp.jsp?Msg=Invalid+Session"));
	        return;
	    }
		
		//Get the parameters data
	    String email_one = request.getParameter("emailOne");
	    String email_two = request.getParameter("emailTwo");
	    
	    String templateArray[] = request.getParameterValues("templateId");
	    
		Connection conn = null;
		
		boolean failed = true;
	
		// Is the Driver Available
		try {
			
			String comment = "";
			
			conn = DbConn.getConnection();
			conn.setAutoCommit(false);
			
			AppLogPersistence alp = new AppLogPersistence();
			
			FTEmailListPersistence emailListPst = new FTEmailListPersistence();
			
			if ( emailListPst.deleteEmailsForMfId(conn,MF_id) || emailListPst.getEmailsForMfId(conn,MF_id).size() == 0 ) {
				Date currentTime = new Date();
				
				if (templateArray != null)
				{
					for (int i = 0; i < templateArray.length; i++)
					{
						if (!email_one.equals("")) {
							emailListPst.insertFTEmailList(conn, MF_id, templateArray[i], 1, currentTime, userId, email_one);
							comment = comment + email_one + "|";
						}
						if (!email_two.equals("")) {
							emailListPst.insertFTEmailList(conn, MF_id, templateArray[i], 2, currentTime, userId, email_two);
							comment = comment + email_two + "|";
						}
						comment = comment + templateArray[i];
						alp.add(conn,userId,MF_id,comment,Module.FT_EMAIL_ADMIN_SERVLET,Message.FT_EMAIL_ADMIN_INFO_CHANGED,3);
						comment = "";
					}
				}
				
				conn.commit();
				failed = false;
		    	response.sendRedirect(response.encodeRedirectURL("https://"+BaseUrl+"/mss/jsp/config/FTEmailAdminJsp.jsp?Msg=Save+Successful"));
		        return;
			}
			response.sendRedirect(response.encodeRedirectURL("https://"+BaseUrl+"/mss/jsp/config/FTEmailAdminJsp.jsp?Msg=Save+Unsuccessful"));
	        
		} catch(Exception e) {
		    logger.error(e.getMessage());
		} finally {
			if (failed) {
				try {
					conn.rollback();
				} catch(Exception eSQL) {
					logger.error(eSQL.toString());
				}
			}
	    	try {
	    		if (conn != null) conn.close();
	    	} catch(Exception e) {
	    		logger.error(e.getMessage());
	    	}
	    }
	
	    response.sendRedirect((String)response.encodeRedirectURL(Constants.ERROR_PAGE + "?Msg=An+Unexpected+Response+Has+Occured"));
	}

}
