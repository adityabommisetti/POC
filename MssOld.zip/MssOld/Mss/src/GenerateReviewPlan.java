// $Id: GenerateReviewPlan.java,v 1.1 2014/06/26 07:56:03 praveen Exp $

import java.sql.Connection;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ps.io.ModuleLog;
import com.ps.mss.db.BeneficiaryPersistence;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.RAPlanFinancialReviewVO;
import com.ps.mss.db.view.BeneInfo;
import com.ps.mss.pdf.RAExpertReportPDFUtil;
import com.ps.mss.security.SessionManager;
import com.ps.mss.util.MssProperties;
import com.ps.pdf.PdfTable;
import com.ps.pdf.PdfUtil;

public class GenerateReviewPlan extends HttpServlet{
	private static Logger logger=LoggerFactory.getLogger(GenerateReviewPlan.class);

	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException{

		RAExpertReportPDFUtil raExpertPDFUtil = new RAExpertReportPDFUtil();
		
	    Connection conn = null;
	    
		try{
			
		    String BaseUrl = MssProperties.getWebAppURL();
		    String XferUrl = MssProperties.getFtpAppURL();
		    	       
		    String User_name = null; 
			String planId = request.getParameter("planId"); 
			String hicNumber = request.getParameter("hicNbr"); 
			int paymentYear = Integer.parseInt(request.getParameter("paymentYear"));
			HashMap payBaselineMapPrevYr = new HashMap();
			HashMap reconCMSMapPrevYr = new HashMap();						
			HashMap reconPlanMapPrevYr = new HashMap();						
			HashMap planRAPSMapPrevYr = new HashMap();						
			HashMap planHCCMODDMapPrevYr = new HashMap();						

			HashMap payBaselineMapRptYr = new HashMap();
			HashMap reconCMSMapRptYr = new HashMap();						
			HashMap reconPlanMapRptYr = new HashMap();						
			HashMap planRAPSMapRptYr = new HashMap();						
			HashMap planHCCMODDMapRptYr = new HashMap();			
			
			String prevYear = String.valueOf(paymentYear - 1);
			String thisYear = String.valueOf(paymentYear);
		 				
	        conn = DbConn.getConnection();

		    HttpSession session = SessionManager.getSession(request, conn);
		    if (session == null)
		    {
		        logger.error("No Session");
		        response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/RAExpertPDFLoadError.jsp"));
		        return;
		    }
		    String User_id = (String)session.getAttribute("User_id");
		    if (User_id == null)
		    {
		       logger.error("No User_id");
		       response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/RAExpertPDFLoadError.jsp"));
		       return;
		    }

			String reconDb = (String) session.getAttribute("ReconDB");
			conn = DbConn.reGetConnection(conn,reconDb);
			
			BeneficiaryPersistence beneficiaryPersistence = new BeneficiaryPersistence();
			BeneInfo beneInfo = beneficiaryPersistence.getBeneInfo(conn, planId, hicNumber);

			if ( beneInfo.isClaimValid()){
		        User_name =  beneInfo.getLastName() + " " + beneInfo.getFirstName();
	        }else{
	        	User_name = "Hic Number is not valid.";
	        }
		    
		    /***********************  Start Report generation *********************************************/
				    
		    response.setContentType("application/pdf");
		    
			//Fetch the Payment Information
			RAPlanFinancialReviewVO raPlanFinancialReviewVo = (RAPlanFinancialReviewVO) request.getAttribute("RAReportVO");
			
			//Fetch data for the previous years
			payBaselineMapPrevYr = raPlanFinancialReviewVo.getPayBaselineMapPrevYr();
			
			reconCMSMapPrevYr = raPlanFinancialReviewVo.getReconCMSMapPrevYr();
			
			reconPlanMapPrevYr = raPlanFinancialReviewVo.getReconPlanMapPrevYr();
			
			planRAPSMapPrevYr = raPlanFinancialReviewVo.getPlanRAPSMapPrevYr();
			
			planHCCMODDMapPrevYr = raPlanFinancialReviewVo.getPlanHCCMODDMapPrevYr();

			// Fetch data for the reporting Year
			payBaselineMapRptYr = raPlanFinancialReviewVo.getPayBaselineMapRptYr();
			
			reconCMSMapRptYr = raPlanFinancialReviewVo.getReconCMSMapRptYr();
			
			reconPlanMapRptYr = raPlanFinancialReviewVo.getReconPlanMapRptYr();
			
			planRAPSMapRptYr = raPlanFinancialReviewVo.getPlanRAPSMapRptYr();
			
			planHCCMODDMapRptYr = raPlanFinancialReviewVo.getPlanHCCMODDMapRptYr();
		    
		    
			PdfUtil pdfUtil = new PdfUtil("");
			pdfUtil.enableSilentPrint(true);
			pdfUtil.createPDF(response.getOutputStream());
	
			int rowIndex = 0;
	
			// Member Detail Table
			PdfTable memberDetailTable = new PdfTable(2);
			memberDetailTable.setFont(RAExpertReportPDFUtil.normalTextFont);
			memberDetailTable.setBorder(0);
			float[] memberDetailColWidths = {15f,85f};
			memberDetailTable.setColumnWidths(memberDetailColWidths);
	
	
			rowIndex = memberDetailTable.addRow();
			memberDetailTable.setText(rowIndex, 1, "Plan ID :");
			memberDetailTable.setFont(rowIndex, 1, RAExpertReportPDFUtil.title1BoldFont);
			memberDetailTable.setText(rowIndex, 2, planId);
			memberDetailTable.setFont(rowIndex, 2, RAExpertReportPDFUtil.title1NormalFont);
	
	
			// Define the numbers table
	
			int colSpan = 16;
			// Section 1
			PdfTable finReviewTableRptYr = new PdfTable(colSpan);
			finReviewTableRptYr.setWidthPercentage(100);
			finReviewTableRptYr.setBorder(0);
			finReviewTableRptYr.setFont(RAExpertReportPDFUtil.normalTextFont);
			finReviewTableRptYr.setAlignment(PdfTable.RIGHT);			
			float[] finReviewTableWidthsRptYr = {9f,.4f,18f,.4f,1f,18f,.4f,1f,18f,.4f,1f,18f,.4f,1f,18f,.1f};
			finReviewTableRptYr.setColumnWidths(finReviewTableWidthsRptYr);
			
			if (
					payBaselineMapRptYr.size() > 0 
					|| reconCMSMapRptYr.size() > 0
					|| reconPlanMapRptYr.size() > 0
					|| planRAPSMapRptYr.size() > 0
					|| planHCCMODDMapRptYr.size() > 0
				)
			{			
				raExpertPDFUtil.printPaymentTopHeader ( finReviewTableRptYr);
				raExpertPDFUtil.printPaymentSubHeader ( finReviewTableRptYr, payBaselineMapRptYr, null, reconCMSMapRptYr, null, reconPlanMapRptYr, null, planRAPSMapRptYr, null, planHCCMODDMapRptYr, null, null, null);
				raExpertPDFUtil.printPaymentContent ( finReviewTableRptYr, false, thisYear, payBaselineMapRptYr, null, reconCMSMapRptYr, null, reconPlanMapRptYr, null, planRAPSMapRptYr, null, planHCCMODDMapRptYr, null, null, null);
										
				rowIndex = finReviewTableRptYr.addSpacerLine(12); // New Row
			}
			
			// Section 2
			PdfTable finReviewTable = new PdfTable(colSpan);
			finReviewTable.setWidthPercentage(100);
			finReviewTable.setBorder(0);
			finReviewTable.setFont(RAExpertReportPDFUtil.normalTextFont);
			finReviewTable.setAlignment(PdfTable.RIGHT);
			float[] finReviewTableWidths = {9f,.4f,18f,.4f,1f,18f,.4f,1f,18f,.4f,1f,18f,.4f,1f,18f,.1f};
			finReviewTable.setColumnWidths(finReviewTableWidths);
			
			if (
				payBaselineMapPrevYr.size() > 0 
				|| reconCMSMapPrevYr.size() > 0
				|| reconPlanMapPrevYr.size() > 0
				|| planRAPSMapPrevYr.size() > 0
				|| planHCCMODDMapPrevYr.size() > 0
				)
			{
				raExpertPDFUtil.printPaymentTopHeader ( finReviewTable);
				raExpertPDFUtil.printPaymentSubHeader ( finReviewTable, payBaselineMapPrevYr, null, reconCMSMapPrevYr, null, reconPlanMapPrevYr, null, planRAPSMapPrevYr, null, planHCCMODDMapPrevYr, null, null, null);
				raExpertPDFUtil.printPaymentContent ( finReviewTable, false, prevYear,  payBaselineMapPrevYr, null, reconCMSMapPrevYr, null, reconPlanMapPrevYr, null, planRAPSMapPrevYr, null, planHCCMODDMapPrevYr, null, null, null);
			}				
			// MAIN TABLE
	
			PdfTable pdfTable = new PdfTable(1);
			pdfTable.setWidthPercentage(100);
			pdfTable.setBorder(0);
			pdfTable.setAlignment(PdfTable.CENTER);
			pdfTable.setFont(RAExpertReportPDFUtil.pageHeadingFont);
	
	
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "RA-Expert ");
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "Part C HCC Analysis  ");
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "Plan Financial Review by Month");
	
			rowIndex = pdfTable.addSpacerLine(12);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, memberDetailTable);
	
			rowIndex = pdfTable.addSpacerLine(12);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, finReviewTableRptYr);			
	
			rowIndex = pdfTable.addSpacerLine(12);
		
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, finReviewTable);

			pdfUtil.addTable(pdfTable);
	
			pdfUtil.close();

		}catch(Exception ex){
			logger.error("GenerateReviewPlan : service : Caught Exception " + ex);
			throw new ServletException(ex);
		} finally {
			try {
				if (conn != null) conn.close();
			} catch(Exception e) {
				logger.error(e.getMessage());
			}
		}

	}
}