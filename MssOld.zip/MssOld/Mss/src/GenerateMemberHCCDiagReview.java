// $Id: GenerateMemberHCCDiagReview.java,v 1.1 2014/06/26 07:56:06 praveen Exp $

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ps.mss.db.BeneficiaryPersistence;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.RAMemberDiagnosisReviewVO;
import com.ps.mss.db.view.BeneInfo;
import com.ps.mss.pdf.RAExpertReportPDFUtil;
import com.ps.mss.security.SessionManager;
import com.ps.mss.util.MssProperties;
import com.ps.pdf.PdfTable;
import com.ps.pdf.PdfUtil;

public class GenerateMemberHCCDiagReview extends HttpServlet{
	private static Logger logger=LoggerFactory.getLogger(GenerateMemberHCCDiagReview.class);

	RAExpertReportPDFUtil raExpertPDFUtil = new RAExpertReportPDFUtil();
	
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException{
		
	    String BaseUrl = MssProperties.getWebAppURL();
	    String XferUrl = MssProperties.getFtpAppURL();
	    	
	    Connection conn = null;       
	    String User_name = null; 
		String planId = request.getParameter("planId"); 
		String hicNumber = request.getParameter("hicNbr"); 
		int paymentYear = Integer.parseInt(request.getParameter("paymentYear"));
		
		String prevYear = String.valueOf(paymentYear - 1);
		String thisYear = String.valueOf(paymentYear);
		String nextYear = String.valueOf(paymentYear + 1);
		
		ArrayList rapsCurrYearList = null;		
		ArrayList baselineCurrList = null;
		ArrayList rapsNextYearList = null;		
		ArrayList baselineNextList = null;
		ArrayList outstandingDGList = null;		
		HashMap hccDiagnosticsMap = new HashMap();
		
		try{

	        conn = DbConn.getConnection();

		    HttpSession session = SessionManager.getSession(request, conn);
		    if (session == null)
		    {
		        logger.error("No Session");
		        response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/RAExpertPDFLoadError.jsp"));
		        return;
		    }
		    String User_id = (String)session.getAttribute("User_id");
		    if (User_id == null)
		    {
		       logger.error("No User_id");
		       response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/RAExpertPDFLoadError.jsp"));
		       return;
		    }
			
			String reconDb = (String) session.getAttribute("ReconDB");
			conn = DbConn.reGetConnection(conn,reconDb);
			
			BeneficiaryPersistence beneficiaryPersistence = new BeneficiaryPersistence();
			BeneInfo beneInfo = beneficiaryPersistence.getBeneInfo(conn, planId, hicNumber);

			if ( beneInfo.isClaimValid()){
		        User_name =  beneInfo.getLastName() + " " + beneInfo.getFirstName();
	        }else{
	        	User_name = "Hic Number is not valid.";
	        }
		    
		    /***********************  Start Report generation *********************************************/
				    
		    response.setContentType("application/pdf");
		    
			RAMemberDiagnosisReviewVO raMemberDiagnosisReviewVO = (RAMemberDiagnosisReviewVO) request.getAttribute("RAReportVO");
			
			// RAPS DATA for projected
			rapsCurrYearList = raMemberDiagnosisReviewVO.getRapsCurrYearList();
			rapsNextYearList = raMemberDiagnosisReviewVO.getRapsNextYearList();
			
			// BASELINE DATA
			baselineCurrList = raMemberDiagnosisReviewVO.getBaselineCurrList();
			baselineNextList = raMemberDiagnosisReviewVO.getBaselineNextList();
			
			outstandingDGList = raMemberDiagnosisReviewVO.getOutstandingDGList();
			
			hccDiagnosticsMap = raMemberDiagnosisReviewVO.getHccDiagnosticsMap();
			
			
			PdfUtil pdfUtil = new PdfUtil("");
			pdfUtil.enableSilentPrint(true);
			pdfUtil.createPDF(response.getOutputStream());
	
			int rowIndex = 0;
	
			// Member Detail Table
			PdfTable memberDetailTable = new PdfTable(4);
			memberDetailTable.setFont(RAExpertReportPDFUtil.normalTextFont);
			memberDetailTable.setBorder(0);
			float[] memberDetailColWidths = {15f,30f,20f,35f};
			memberDetailTable.setColumnWidths(memberDetailColWidths);
	
	
			rowIndex = memberDetailTable.addRow();
			memberDetailTable.setText(rowIndex, 1, "Plan ID :");
			memberDetailTable.setFont(rowIndex, 1, RAExpertReportPDFUtil.title1BoldFont);
			memberDetailTable.setText(rowIndex, 2, planId);
			memberDetailTable.setFont(rowIndex, 2, RAExpertReportPDFUtil.title1NormalFont);
	
			rowIndex = memberDetailTable.addRow();
			memberDetailTable.setText(rowIndex, 1, "Hic Nbr :");
			memberDetailTable.setFont(rowIndex, 1, RAExpertReportPDFUtil.title1BoldFont);
			memberDetailTable.setText(rowIndex, 2, hicNumber);
			memberDetailTable.setFont(rowIndex, 2, RAExpertReportPDFUtil.title1NormalFont);
	
			memberDetailTable.setText(rowIndex, 3, "Member Name : ");
			memberDetailTable.setFont(rowIndex, 3, RAExpertReportPDFUtil.title1BoldFont);
			memberDetailTable.setText(rowIndex, 4, User_name);
			memberDetailTable.setFont(rowIndex, 4, RAExpertReportPDFUtil.title1NormalFont);
	
	
			// NESTED TABLE
	
			PdfTable pdfTable1 = new PdfTable(87);
			pdfTable1.setBorder(0);
			pdfTable1.setFont(RAExpertReportPDFUtil.normalTextFont);
	
			float[] columnWidths = {9,5,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,5,5,8};
			pdfTable1.setColumnWidths(columnWidths);
	
			// Define the DISEASE GROUP Table
			raExpertPDFUtil.printDiseaseGroupHeader( pdfTable1);
				
			raExpertPDFUtil.printDiseaseGroupValues( pdfTable1, rapsCurrYearList);			
			raExpertPDFUtil.printDiseaseGroupValues( pdfTable1, baselineCurrList);
			raExpertPDFUtil.printDiseaseGroupValues( pdfTable1, baselineNextList);
			raExpertPDFUtil.printDiseaseGroupValues( pdfTable1, rapsNextYearList);
			
			raExpertPDFUtil.printDiseaseGroupFooter( pdfTable1);			
			
	
			// Define the numbers table
	
			PdfTable outstandingTable = new PdfTable(5);
			outstandingTable.setWidthPercentage(100);
			outstandingTable.setBorder(0);
			outstandingTable.setFont(RAExpertReportPDFUtil.normalTextFont);
			outstandingTable.setAlignment(PdfTable.LEFT);
			float[] outstandingTableWidths = {15,1,15,1,65};
			outstandingTable.setColumnWidths(outstandingTableWidths);
			
			raExpertPDFUtil.printOutstandingHCCHeader(outstandingTable);			
			raExpertPDFUtil.printOutstandingHccDiag(outstandingTable, outstandingDGList, true, hccDiagnosticsMap);
			
			
			// MAIN TABLE	
			PdfTable pdfTable = new PdfTable(1);
			pdfTable.setWidthPercentage(100);
			pdfTable.setBorder(0);
			pdfTable.setAlignment(PdfTable.CENTER);
			pdfTable.setFont(RAExpertReportPDFUtil.pageHeadingFont);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "RA-Expert ");
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "Part C HCC Analysis  ");
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "Member outstanding HCC-Diagnosis Review for Payment Year " + thisYear);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "Data Collection Dates 01/01/" + prevYear + " thru 12/31/" + prevYear);
			
			rowIndex = pdfTable.addSpacerLine(12);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, memberDetailTable);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, pdfTable1);
	
			rowIndex = pdfTable.addSpacerLine(12);
	
			pdfUtil.addTable(pdfTable);
			pdfUtil.addTable(outstandingTable);			
	
			pdfUtil.close();
	
		}catch(Exception ex){
			logger.error("GenerateMemberHCCDiagReview : service : Caught Exception " + ex);
			throw new ServletException(ex);
		} finally {
			try {
				if (conn != null) conn.close();
			} catch(Exception e) {
				logger.error(e.getMessage());
			}
		}
	}
}