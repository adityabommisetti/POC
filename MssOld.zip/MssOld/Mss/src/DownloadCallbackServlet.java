import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * $Id: DownloadCallbackServlet.java,v 1.1 2014/06/26 07:56:02 praveen Exp $
 */


public class DownloadCallbackServlet extends HttpServlet {
	private static Logger logger=LoggerFactory.getLogger(DownloadCallbackServlet.class);

    public void service(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
    	    	
    	String mfId = request.getParameter("mfid");
    	String fileName = request.getParameter("rpt");
    	String abort = request.getParameter("abort");
    	String cnt = request.getParameter("cnt");
    	String size = request.getParameter("size");
    	
    	logger.debug(mfId + " " + fileName + " " + abort + " " + cnt + " " + size);
    }

}
