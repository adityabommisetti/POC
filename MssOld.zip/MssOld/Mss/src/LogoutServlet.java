/*
 * $Id: LogoutServlet.java,v 1.1 2014/06/26 07:56:06 praveen Exp $
 */

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ps.mss.security.SessionManager;
import com.ps.mss.util.MssProperties;

public class LogoutServlet extends HttpServlet
{
	private static Logger logger=LoggerFactory.getLogger(LogoutServlet.class);

public void service(HttpServletRequest request, HttpServletResponse response)
  throws ServletException, IOException
{
    //ModuleLog log = new ModuleLog("LogoutServlet");

    String nav = request.getParameter("nav");
    if (nav == null)
        nav = "";
    
    // session login
    HttpSession session  = SessionManager.getSession(request);
    boolean SSO = false;
    boolean flag = false;
    if (session != null)
    {
    	//sso changes - start
        SSO = (Boolean) session.getAttribute("SSO");
        flag= true;
      //sso changes - end
    	Long tid = (Long) session.getAttribute("tid");
    	//log.writeMessage(moduleName,"[" + tid + "] Invalidating Session for " + User_id);

    	session.removeAttribute("LoginBindingListener");
    	session.removeAttribute("HII");
    	session.removeAttribute("Recon");
    	session.removeAttribute("RxRecon");
    	session.removeAttribute("RxReconDB");
    	session.removeAttribute("Enctr");
    	session.removeAttribute("FTS");
    	session.removeAttribute("OLP");
    	session.removeAttribute("QAT");
    	session.removeAttribute("MO");
    	session.removeAttribute("Plan_id");
    	session.removeAttribute("MF_id");
    	session.removeAttribute("Cust_type");
    	session.removeAttribute("Cust_nbr");
    	session.removeAttribute("User_id");
    	session.removeAttribute("User_pwd");
    	session.removeAttribute("tid");
    	session.removeAttribute("TESTCICS");
    	session.invalidate();
    	
    	//kill all cookies-added by offshore team
	  	Cookie cookie=new Cookie("JSESSIONID","");
	  	cookie.setPath("/");
	  	cookie.setMaxAge(0);
	  	response.addCookie(cookie);
    	//System.out.println("cookies are killed"); 
    	  	
    }
    
    if (nav.equals("1"))
    {
       response.sendRedirect((String)response.encodeRedirectURL("https://"+MssProperties.getWebAppURL()+"/mss/html/LogoutMessage.html"));
       return;
    }
  //sso changes - start
    if(!SSO && flag){
    response.sendRedirect((String)response.encodeRedirectURL("https://"+MssProperties.getWebAppURL()+"/mss/html/GoHome.html"));
    } else {
    	response.sendRedirect((String)response.encodeRedirectURL("https://"+MssProperties.getWebAppURL()+"/mss/html/LogoutJsp.jsp"));
    }
  //sso changes - end
}

}