/*
 * $Id: LogoutServlet.java,v 1.2 2015/09/28 06:05:10 sdash Exp $
 */
//Penetration Testing changes -start
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ps.mss.security.SessionManager;
/**
 * 
 * @author Praveen soni
 *
 */
public class LogoutSessionServlet extends HttpServlet {
	/**
	 * SERVICE METHOD
	 */
	private static Logger logger=LoggerFactory.getLogger(LogoutSessionServlet.class);

	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {

		//	ModuleLog log = new ModuleLog("LogoutSessionServlet");
			HttpSession session = SessionManager.getSession(request);
			
			if (session != null) {
				session.removeAttribute("Required");
				session.removeAttribute("Retry");
				session.removeAttribute("updatedemail");
			} 
			}

		catch (Exception ex) {
			logger.error(ex.getMessage());
		}
	}

	

}
//Penetration Testing changes -end