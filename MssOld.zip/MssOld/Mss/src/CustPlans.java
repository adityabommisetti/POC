// $Id: CustPlans.java,v 1.1 2014/06/26 07:56:05 praveen Exp $


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ps.mss.db.DbConn;


public class CustPlans
{
	private static Logger logger=LoggerFactory.getLogger(ChangePasswordServlet.class);

    public CustPlans()
    {
    }

    public String[] getPlans(String Cust_nbr)
    {
        String[] Plan = null;

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        String SQL = null;

        try {
       	
        	conn = DbConn.getConnection();
            stmt = conn.createStatement();

            SQL = "SELECT Plan_id FROM secplan WHERE Cust_nbr = '" + Cust_nbr + "' ORDER BY Plan_id";
            rs = stmt.executeQuery(SQL);

            Vector planID = new Vector();
            String Plan_id;

            while (rs.next())
            {
                Plan_id = rs.getString("Plan_id").trim();
                planID.add(Plan_id);
            }

            int cnt = planID.size();
            if (cnt > 0)
            {
                Plan = new String[cnt];
                planID.copyInto(Plan);
            }
            else
                logger.debug("No Plans Read for " + Cust_nbr);

        } catch(SQLException eSQL) {
            logger.error("SQL Exception: " + eSQL.getMessage());
        } catch(NullPointerException eNP){
            logger.error("NullPointer Exception: " + eNP.getMessage());
        } finally {

            try {
                if (rs != null)
                    rs.close();
            } catch (Exception e) {
                logger.error("Exception: " + e.getMessage());
            }

            try {
                if (stmt != null)
                    stmt.close();
            } catch (Exception e) {
                logger.error("Exception: " + e.getMessage());
            }

            try {
                conn.close();
            } catch (Exception e) {
                logger.error("Exception: " + e.getMessage());
            }

        }

        return Plan;
    }

}