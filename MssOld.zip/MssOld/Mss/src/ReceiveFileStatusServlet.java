// $Id: ReceiveFileStatusServlet.java,v 1.1 2014/06/26 07:56:03 praveen Exp $
import java.io.File;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
 * Created on Jan 2, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author ppalat
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ReceiveFileStatusServlet extends HttpServlet {
	public void service(HttpServletRequest request, HttpServletResponse response){
		
		String fileName = null;
		PrintWriter out = null;
		
		try{
						
			fileName = request.getParameter("fileName");
			
			out = new PrintWriter(response.getOutputStream());
			
			File file = new File(fileName);
			
			out.write(new Long(file.length()).toString());
			
		}catch(Exception e){
			
		}
	}
}
