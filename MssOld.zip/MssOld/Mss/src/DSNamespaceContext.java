/*
* Copyright (c) 2015 by wipro.com. All rights reserved.
*
* Oct 14, 2015
* 
* @author Ashish Shrivastava
*
*
*/


import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.xml.namespace.NamespaceContext;


/**
 * A NamespaceContext implementation for digital signatures.
 */
public class DSNamespaceContext implements NamespaceContext {

    /** The namespace map. */
    private Map<String, String> namespaceMap =
        new HashMap<String, String>();

    /**
     * Instantiates a new DS namespace context.
     */
    public DSNamespaceContext() {
        namespaceMap.put("ds", "http://www.w3.org/2000/09/xmldsig#");
    }

    /**
     * Instantiates a new DS namespace context.
     *
     * @param namespaces the namespaces
     */
    public DSNamespaceContext(Map<String, String> namespaces) {
        this();
        namespaceMap.putAll(namespaces);
    }

    /* (non-Javadoc)
     * @see javax.xml.namespace.NamespaceContext#getNamespaceURI(java.lang.String)
     */
    public String getNamespaceURI(String arg0) {
        return namespaceMap.get(arg0);
    }

    /**
     * Put prefix.
     *
     * @param prefix the prefix
     * @param namespace the namespace
     */
    public void putPrefix(String prefix, String namespace) {
        namespaceMap.put(prefix, namespace);
    }

    /* (non-Javadoc)
     * @see javax.xml.namespace.NamespaceContext#getPrefix(java.lang.String)
     */
    public String getPrefix(String arg0) {
        for (String key : namespaceMap.keySet()) {
            String value = namespaceMap.get(key);
            if (value.equals(arg0)) {
                return key;
            }
        }
        return null;
    }

    /* (non-Javadoc)
     * @see javax.xml.namespace.NamespaceContext#getPrefixes(java.lang.String)
     */
    public Iterator<String> getPrefixes(String arg0) {
        return namespaceMap.keySet().iterator();
    }
}