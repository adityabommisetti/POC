/*
 * $Id: SSLRPCRouter.java,v 1.1 2014/06/26 07:56:01 praveen Exp $
 */

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author rnenne
 */
public class SSLRPCRouter extends HttpServlet {
	
    public void service(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
	{
    	if (!request.isSecure()) {
    		response.sendError(404);
    		return;
    	}

    	RequestDispatcher rd = request.getRequestDispatcher("/servlet/SoapBackEndServlet");
        rd.forward(request,response);
    		
	}
}
