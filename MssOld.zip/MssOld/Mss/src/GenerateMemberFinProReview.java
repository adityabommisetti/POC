// $Id: GenerateMemberFinProReview.java,v 1.1 2014/06/26 07:56:01 praveen Exp $

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ps.mss.db.BeneficiaryPersistence;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.RAMemberFinancialProjectionVO;
import com.ps.mss.db.view.BeneInfo;
import com.ps.mss.pdf.RAExpertReportPDFUtil;
import com.ps.mss.security.SessionManager;
import com.ps.mss.util.MssProperties;
import com.ps.pdf.PdfTable;
import com.ps.pdf.PdfUtil;

public class GenerateMemberFinProReview extends HttpServlet{
	private static Logger logger=LoggerFactory.getLogger(GenerateMemberFinProReview.class);

	RAExpertReportPDFUtil raExpertPDFUtil = new RAExpertReportPDFUtil();
	
	
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException{
		
	    String BaseUrl = MssProperties.getWebAppURL();
	    String XferUrl = MssProperties.getFtpAppURL();
	    	
	    Connection conn = null;       
	    String User_name = null; 
		String planId = request.getParameter("planId"); 
		String hicNumber = request.getParameter("hicNbr"); 
		int paymentYear = Integer.parseInt(request.getParameter("paymentYear"));
		
		String prevYear = String.valueOf(paymentYear - 1);
		String thisYear = String.valueOf(paymentYear);
		
		
		ArrayList rapsCurrentList = null;
		ArrayList rapsProjectionList = null;
		ArrayList baselineList = null;
		ArrayList rapsLagList = null;
		
		HashMap payBaselineMapPrevYr = new HashMap();
		HashMap baselineRAFactorMapPrevYr = new HashMap();			
		HashMap reconCMSMapPrevYr = new HashMap();						
		HashMap reconCMSRAFactorMapPrevYr = new HashMap();		
		HashMap planRAPSLAGMapRptYr = new HashMap();
		HashMap planRAPSLAGRAFactorMapRptYr = new HashMap();
		HashMap reconPlanMapPrevYr = new HashMap();						
		HashMap reconPlanRAFactorMapPrevYr = new HashMap();						
		HashMap planRAPSMapPrevYr = new HashMap();						
		HashMap planRAPSRAFactorMapPrevYr = new HashMap();						
		HashMap planHCCMODDMapPrevYr = new HashMap();						
		HashMap planHCCMODDRAFactorMapPrevYr = new HashMap();		

		HashMap payBaselineMapRptYr = new HashMap();
		HashMap baselineRAFactorMapRptYr = new HashMap();			
		HashMap planRAPSMapRptYr = new HashMap();						
		HashMap planRAPSRAFactorMapRptYr = new HashMap();	
		
		try{
			
	        conn = DbConn.getConnection();

		    HttpSession session = SessionManager.getSession(request, conn);
		    if (session == null)
		    {
		        logger.error("No Session");
		        response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/RAExpertPDFLoadError.jsp"));
		        return;
		    }
		    String User_id = (String)session.getAttribute("User_id");
		    if (User_id == null)
		    {
		       logger.error("No User_id");
		       response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/RAExpertPDFLoadError.jsp"));
		       return;
		    }
			
			String reconDb = (String) session.getAttribute("ReconDB");
			conn = DbConn.reGetConnection(conn,reconDb);
			
			BeneficiaryPersistence beneficiaryPersistence = new BeneficiaryPersistence();
			BeneInfo beneInfo = beneficiaryPersistence.getBeneInfo(conn, planId, hicNumber);

			if ( beneInfo.isClaimValid()){
		        User_name =  beneInfo.getLastName() + " " + beneInfo.getFirstName();
	        }else{
	        	User_name = "Hic Number is not valid.";
	        }
			
		    /***********************  Start Report generation *********************************************/
			
		    response.setContentType("application/pdf");
		    
		    RAMemberFinancialProjectionVO raMemberFinancialProjectionVO = (RAMemberFinancialProjectionVO) request.getAttribute("RAReportVO");
		    
			//Fetch payment information for projection year
			payBaselineMapRptYr = raMemberFinancialProjectionVO.getPayBaselineMapRptYr();
			
			baselineRAFactorMapRptYr = raMemberFinancialProjectionVO.getBaselineRAFactorMapRptYr();
			
			planRAPSMapRptYr = raMemberFinancialProjectionVO.getPlanRAPSMapRptYr();
			
			planRAPSRAFactorMapRptYr = raMemberFinancialProjectionVO.getPlanRAPSRAFactorMapRptYr();
			
			planRAPSLAGMapRptYr = raMemberFinancialProjectionVO.getPlanRAPSLAGMapRptYr();
			
			planRAPSLAGRAFactorMapRptYr = raMemberFinancialProjectionVO.getPlanRAPSLAGRAFactorMapRptYr();

			//Fetch the Payment Information for current Year
			payBaselineMapPrevYr = raMemberFinancialProjectionVO.getPayBaselineMapPrevYr();

			baselineRAFactorMapPrevYr = raMemberFinancialProjectionVO.getBaselineRAFactorMapPrevYr();

			reconCMSMapPrevYr = raMemberFinancialProjectionVO.getReconCMSMapPrevYr( );
			
			reconCMSRAFactorMapPrevYr = raMemberFinancialProjectionVO.getReconCMSRAFactorMapPrevYr ( );
			
			reconPlanMapPrevYr = raMemberFinancialProjectionVO.getReconPlanMapPrevYr ( );
			
			reconPlanRAFactorMapPrevYr = raMemberFinancialProjectionVO.getReconPlanRAFactorMapPrevYr ( );
			
			planRAPSMapPrevYr = raMemberFinancialProjectionVO.getPlanRAPSMapPrevYr();
			
			planRAPSRAFactorMapPrevYr = raMemberFinancialProjectionVO.getPlanRAPSRAFactorMapPrevYr();
			
			planHCCMODDMapPrevYr = raMemberFinancialProjectionVO.getPlanHCCMODDMapPrevYr();
			
			planHCCMODDRAFactorMapPrevYr = raMemberFinancialProjectionVO.getPlanHCCMODDRAFactorMapPrevYr();
		    
			// RAPS DATA for current year
			rapsCurrentList = raMemberFinancialProjectionVO.getRapsCurrentList();

			// BASELINE DATA
			baselineList = raMemberFinancialProjectionVO.getBaselineList();

			// RAPS DATA for projected
			rapsProjectionList = raMemberFinancialProjectionVO.getRapsProjectionList();
			
			// RAPSLAG DATA
			rapsLagList = raMemberFinancialProjectionVO.getRapsLagList();
			
			
			PdfUtil pdfUtil = new PdfUtil("");
			pdfUtil.setLayout(PdfUtil.LANDSCAPE);
			pdfUtil.setLeftMargin(40);
			pdfUtil.setTopMargin(20);
			pdfUtil.enableSilentPrint(true);
			pdfUtil.createPDF(response.getOutputStream());
	
			int rowIndex = 0;
	
			// Member Detail Table
			PdfTable memberDetailTable = new PdfTable(4);
			memberDetailTable.setFont(RAExpertReportPDFUtil.normalTextFont);
			memberDetailTable.setBorder(0);
			float[] memberDetailColWidths = {10f,40f,15f,35f};
			memberDetailTable.setColumnWidths(memberDetailColWidths);
	
	
			rowIndex = memberDetailTable.addRow();
			memberDetailTable.setText(rowIndex, 1, "Plan ID :");
			memberDetailTable.setFont(rowIndex, 1, RAExpertReportPDFUtil.title1BoldFont);
			memberDetailTable.setText(rowIndex, 2, planId);
			memberDetailTable.setFont(rowIndex, 2, RAExpertReportPDFUtil.title1NormalFont);
	
			rowIndex = memberDetailTable.addRow();
			memberDetailTable.setText(rowIndex, 1, "Hic Nbr :");
			memberDetailTable.setFont(rowIndex, 1, RAExpertReportPDFUtil.title1BoldFont);
			memberDetailTable.setText(rowIndex, 2, hicNumber);
			memberDetailTable.setFont(rowIndex, 2, RAExpertReportPDFUtil.title1NormalFont);
	
			memberDetailTable.setText(rowIndex, 3, "Member Name : ");
			memberDetailTable.setFont(rowIndex, 3, RAExpertReportPDFUtil.title1BoldFont);
			memberDetailTable.setText(rowIndex, 4, User_name);
			memberDetailTable.setFont(rowIndex, 4, RAExpertReportPDFUtil.title1NormalFont);
	
	
			// NESTED TABLE
	
			PdfTable pdfTable1 = new PdfTable(87);
			pdfTable1.setBorder(0);
			pdfTable1.setFont(RAExpertReportPDFUtil.normalTextFont);
	
			float[] columnWidths = {7,4,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,.7f,6,6,8};
			pdfTable1.setColumnWidths(columnWidths);

			// Define the DISEASE GROUP Table
			raExpertPDFUtil.printDiseaseGroupHeader( pdfTable1);
				
			raExpertPDFUtil.printDiseaseGroupValues( pdfTable1, rapsCurrentList);			
			raExpertPDFUtil.printDiseaseGroupValues( pdfTable1, baselineList);
			raExpertPDFUtil.printDiseaseGroupValues( pdfTable1, rapsProjectionList);
			raExpertPDFUtil.printDiseaseGroupValues( pdfTable1, rapsLagList);
			
			raExpertPDFUtil.printDiseaseGroupFooter( pdfTable1);			
			
	
			PdfTable projectionTable = new PdfTable(16);
			projectionTable.setWidthPercentage(100);
			projectionTable.setBorder(0);
			projectionTable.setFont(RAExpertReportPDFUtil.normalTextFont);
			float[] projectionTableWidths = {5f,.1f,8f,8f,.1f,8f,8f,.1f,8f,8f,.1f,8f,8f,.1f,8f,8f};
			projectionTable.setColumnWidths(projectionTableWidths);
	
			rowIndex = projectionTable.addRow();		// New Row
			projectionTable.setColSpan(rowIndex, 1, 16);
			projectionTable.setText(rowIndex, 1, "************************************************** " + thisYear + " Earned to Date **************************************************");
			projectionTable.setAlignment(rowIndex, 1, PdfTable.CENTER);
	
			
			raExpertPDFUtil.printPaymentSubHeader(projectionTable, payBaselineMapRptYr, baselineRAFactorMapRptYr, null, null, null, null, planRAPSMapRptYr, planRAPSRAFactorMapRptYr, null, null, planRAPSLAGMapRptYr, planRAPSLAGRAFactorMapRptYr);			
			raExpertPDFUtil.printPaymentContent(projectionTable, true, thisYear,  payBaselineMapRptYr, baselineRAFactorMapRptYr, null, null, null, null, planRAPSMapRptYr, planRAPSRAFactorMapRptYr, null, null, planRAPSLAGMapRptYr, planRAPSLAGRAFactorMapRptYr);
	
	
			// Define the numbers table
			PdfTable reconPayTable = new PdfTable(16);
			reconPayTable.setWidthPercentage(100);
			reconPayTable.setBorder(0);
			reconPayTable.setFont(RAExpertReportPDFUtil.normalTextFont);
			reconPayTable.setAlignment(PdfTable.CENTER);
			float[] reconPayTableWidths = {5f,1f,8f,8f,1f,8f,8f,1f,8f,8f,1f,8f,8f,1f,8f,8f};
			reconPayTable.setColumnWidths(reconPayTableWidths);
	
			rowIndex = reconPayTable.addRow();		// New Row
			reconPayTable.setColSpan(rowIndex, 1, 16);
			reconPayTable.setText(rowIndex, 1, "****************************************************** " + prevYear + " Actuals ******************************************************");
	
			raExpertPDFUtil.printPaymentTopHeader(reconPayTable);
			raExpertPDFUtil.printPaymentSubHeader(reconPayTable, payBaselineMapPrevYr, baselineRAFactorMapPrevYr, reconCMSMapPrevYr, reconCMSRAFactorMapPrevYr, reconPlanMapPrevYr, reconPlanRAFactorMapPrevYr, planRAPSMapPrevYr, planRAPSRAFactorMapPrevYr, planHCCMODDMapPrevYr, planHCCMODDRAFactorMapPrevYr, null, null);			
			raExpertPDFUtil.printPaymentContent(reconPayTable, false, prevYear,  payBaselineMapPrevYr, baselineRAFactorMapPrevYr, reconCMSMapPrevYr, reconCMSRAFactorMapPrevYr, reconPlanMapPrevYr, reconPlanRAFactorMapPrevYr, planRAPSMapPrevYr, planRAPSRAFactorMapPrevYr, planHCCMODDMapPrevYr, planHCCMODDRAFactorMapPrevYr, null, null);
			
	
			// MAIN TABLE
	
			PdfTable pdfTable = new PdfTable(1);
			pdfTable.setWidthPercentage(100);
			pdfTable.setBorder(0);
			pdfTable.setAlignment(PdfTable.CENTER);
			pdfTable.setFont(RAExpertReportPDFUtil.pageHeadingFont);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "RA-Expert ");
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "Part C HCC Analysis  ");
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "Member Financial Projection for Payment Year " + thisYear);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setText(rowIndex, 1, "Data Collection Dates 01/01/" + prevYear + " thru 12/31/" + prevYear);
	
			rowIndex = pdfTable.addSpacerLine(12);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, memberDetailTable);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, pdfTable1);
	
			rowIndex = pdfTable.addSpacerLine(12);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, projectionTable);
	
			rowIndex = pdfTable.addSpacerLine(12);
	
			rowIndex = pdfTable.addRow();
			pdfTable.setTable(rowIndex, 1, reconPayTable);
	
			pdfUtil.addTable(pdfTable);
	
			pdfUtil.close();

		} catch(Exception ex){
			logger.error("GenerateMemberFinProReview : Exception " + ex);
			throw new ServletException(ex);
		} finally {
			try {
				if (conn != null) conn.close();
			} catch(Exception e) {
				logger.error(e.getMessage());
			}
		}
	}
}