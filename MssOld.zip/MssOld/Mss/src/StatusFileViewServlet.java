/**
 * $Id: StatusFileViewServlet.java,v 1.2 2016/04/12 22:20:57 dinesh Exp $
 * 
 *	StatusFileViewServlet
 *	This servlet is present on the front end server 
 *  and acts as the channel between the JSP and the
 *  StatusFileViewServlet on the File server
 */

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;

import com.ps.http.RequestHandler;
import org.slf4j.LoggerFactory;
import com.ps.http.HttpClientRequestHandler;
import com.ps.mss.util.MssProperties;

public class StatusFileViewServlet extends HttpServlet
{	private static Logger logger=LoggerFactory.getLogger(StatusFileViewServlet.class);

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	  throws ServletException, IOException
	{
		String fileAppURL = MssProperties.getFileAppURL();
    	
	    // session login
	    HttpSession session  = request.getSession(false);
	    if (session == null)
	    {
	       logger.error("No Session");
	        response.getWriter().write("<FONT FACE='VERDANA'>Error in displaying report. Unable to find Session</FONT>");
	        return;
	    }
	    
	    String User_id = (String) session.getAttribute("User_id");
	    if (User_id == null)
	    {
	       logger.error("Null User_id");
	        response.getWriter().write("<FONT FACE='VERDANA'>Error in displaying report. Unable to obtain User ID</FONT>");
	        return;
	    }

	    String rptName = request.getParameter("rpt");
	    
	    if (rptName.indexOf("..") != -1)
	    {
	       logger.error("Directory Change Attempted [" + rptName + "]");
	        response.getWriter().write("");
	        return;
	    }
	    
	    String serviceServletName = "http://" + fileAppURL + "/servlet/StatusFileViewServlet";
	    RequestHandler requestHandler = new HttpClientRequestHandler(serviceServletName);

	    try{
	    	requestHandler.processRequest(request, response, HttpClientRequestHandler.GET_METHOD);
	    }catch ( Exception ex){
	    	logger.error("StatusFileViewServlet : doGet : Exception when trying to processRequest using HttpClientRequestHandler");
	    	throw new ServletException(ex);
	    }
	}
}



