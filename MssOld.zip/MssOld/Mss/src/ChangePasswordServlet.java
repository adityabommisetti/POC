/*
 * $Id: ChangePasswordServlet.java,v 1.1 2014/06/26 07:56:05 praveen Exp $
 */

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;

import javax.mail.MessagingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.LoggerFactory;
import com.ps.db.SQLHelper;
import com.ps.util.StringUtil;
import com.ps.io.ModuleLog;
import com.ps.mss.util.MssProperties;
import com.ps.mss.security.CryptoDigest;
import com.ps.mss.security.SessionCrypt;
import com.ps.mss.security.SessionManager;
//IFOX-00412735 changes -start
/*import com.ps.mss.adapter.BusinessObjectsAdapter;
import com.ps.mss.adapter.BOAdmin;*/
//IFOX-00412735 changes -end
import com.ps.mss.db.AppLogPersistence;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.Message;
import com.ps.mss.db.Module;
//import com.ps.mss.db.ServicePersistence;
import com.ps.mss.framework.Constants;
import com.ps.mss.util.EmailNotification;
import com.ps.net.URLEncoder;
import org.slf4j.Logger;
//import com.ps.mss.db.SecuserSetting;
//import com.ps.mss.db.SecuserSettingPersistence;

public class ChangePasswordServlet extends HttpServlet
{
	private static Logger logger=LoggerFactory.getLogger(ChangePasswordServlet.class);

public void service(HttpServletRequest request, HttpServletResponse response)
  throws ServletException, IOException
{
    String BaseUrl = MssProperties.getWebAppURL();

    // session login
    HttpSession session  = SessionManager.getSession(request);
    if (session == null)
    {
        logger.debug("No Session");		
       // response.sendRedirect((String)response.encodeRedirectURL("https://" + BaseUrl + "/mss/jsp/ErrorPJsp.jsp?Msg=Page+Expired"));
      //20120606_ERRORPJSP_FIX
        response.sendRedirect((String)response.encodeRedirectURL("https://" + BaseUrl + "/mss/jsp/ErrorPJsp.jsp?MsgId=1"));
        return;
    }

    String User_id = (String) session.getAttribute("User_id");
    if (User_id == null)
    {
        logger.debug("Null User_id");
      //  response.sendRedirect((String)response.encodeRedirectURL("https://" + BaseUrl + "/mss/jsp/ErrorPJsp.jsp?Msg=Invalid+Session"));
        
        response.sendRedirect((String)response.encodeRedirectURL("https://" + BaseUrl + "/mss/jsp/ErrorPJsp.jsp?MsgId=2"));
        return;
    }

    //String QAM = StringUtil.nonNullTrim((String)session.getAttribute("QAM"));
    //String QAP = StringUtil.nonNullTrim((String)session.getAttribute("QAP"));
    //String QAS = StringUtil.nonNullTrim((String)session.getAttribute("QAS"));
    //boolean savePwd = false;
    //if (QAM.equals("TRUE") || QAP.equals("TRUE") || QAS.equals("TRUE"))
    //    savePwd = true;
    
    CryptoDigest crypt = new CryptoDigest();

    String Required = request.getParameter("Required");
    String Hint = StringUtil.nonNullTrim(request.getParameter("Hint"));
    String Hint2 = StringUtil.nonNullTrim(request.getParameter("Hint2"));
    String Hint3 = StringUtil.nonNullTrim(request.getParameter("Hint3"));
    String OldUserPwd = StringUtil.nonNullTrim(request.getParameter("OldUserPwd"));
    String NewUserPwd = StringUtil.nonNullTrim(request.getParameter("NewUserPwd"));
    boolean hasNewPasswd = false;
    if (NewUserPwd.length()> 0)
    	hasNewPasswd = true;
    String Hint_id1 = StringUtil.nonNullTrim(request.getParameter("Hint_id1"));
    String HintAnswer1 = StringUtil.nonNullTrim(request.getParameter("HintAnswer1"));
    HintAnswer1 = SQLHelper.fixDB2LikeQuery(HintAnswer1);
    String Hint_id2 = StringUtil.nonNullTrim(request.getParameter("Hint_id2"));
    String HintAnswer2 = StringUtil.nonNullTrim(request.getParameter("HintAnswer2"));
    HintAnswer2 = SQLHelper.fixDB2LikeQuery(HintAnswer2);
    String Hint_id3 = StringUtil.nonNullTrim(request.getParameter("Hint_id3"));
    String HintAnswer3 = StringUtil.nonNullTrim(request.getParameter("HintAnswer3"));
    HintAnswer3 = SQLHelper.fixDB2LikeQuery(HintAnswer3);
    String UpdatedPhone = StringUtil.nonNullTrim(request.getParameter("Phone"));
    String UpdatedEmail = StringUtil.nonNullTrim(request.getParameter("Email"));
    String CurPhone = null;
    String CurEmail = null;
    
   
    
    // Set up Parameter in case we call the ChangePasword JSP
    String Parm;
    if (Required == null)
    {
        Parm = "";
        Required = "0";
    }
    else {
  //Penetration Testing Changes -start
        Required = Required.trim();
        //Parm = "&Required=" + Required;
        Parm =  Required;
    }
    if (Hint.equals("1"))
    {    
    	session.setAttribute("Hint", Hint);
    	/*if (Parm.length() > 0)
            Parm = Parm + "&";
        Parm = Parm + "Hint=" + Hint;*/
    }
    if (Hint2.equals("1"))
    {    
       session.setAttribute("Hint2", Parm);
    	/*if (Parm.length() > 0)
            Parm = Parm + "&";
        Parm = Parm + "Hint2=" + Hint2;
*/    	}
    if (Hint3.equals("1"))
    {    
    	session.setAttribute("Hint3", Parm);
        /*if (Parm.length() > 0)
            Parm = Parm + "&";
        Parm = Parm + "Hint3=" + Hint3;*/
    }
    session.setAttribute("Required", Parm);
    if (OldUserPwd.equals("")) {
    	session.setAttribute("Retry", "1");
        logger.debug("Old Password Blank");
        //response.sendRedirect(response.encodeRedirectURL("/mss/home/ChangePasswordJsp.jsp?Retry=1"+Parm));
        response.sendRedirect(response.encodeRedirectURL("/mss/home/ChangePasswordJsp.jsp"));
        return;
    }
    if (Required.equals("1") && (NewUserPwd.length() <= 0))
    {
        logger.debug("No Password");
        //response.sendRedirect(response.encodeRedirectURL("/mss/home/ChangePasswordJsp.jsp?Retry=1"+Parm));
        response.sendRedirect(response.encodeRedirectURL("/mss/home/ChangePasswordJsp.jsp"));
        return;
    }

    // this is crashing my debugger - seen this before 
    if (
    		(Hint.equals("1") && ((HintAnswer1.length() <= 0) || (Hint_id1.length() <= 0)))
			||
			(Hint2.equals("1") && ((HintAnswer2.length() <= 0) || (Hint_id2.length() <= 0)))
			||
			(Hint3.equals("1") && ((HintAnswer3.length() <= 0) || (Hint_id3.length() <= 0)))
		)
    {
        logger.debug("No Hint");
        //response.sendRedirect(response.encodeRedirectURL("/mss/home/ChangePasswordJsp.jsp?Retry=3"+Parm));
        session.setAttribute("Retry", "3");
        response.sendRedirect(response.encodeRedirectURL("/mss/home/ChangePasswordJsp.jsp"));
        return;
    }
    //20120606_XSSP
    //check for valid email
    if (!UpdatedEmail.equals("")) {
    	if(!URLEncoder.isValidEmail(UpdatedEmail))
    	{
    		session.setAttribute("Retry", "5");
    		session.setAttribute("updatedemail", UpdatedEmail);
    		logger.debug("Invalid email");
    		response.sendRedirect(response.encodeRedirectURL("/mss/home/ChangePasswordJsp.jsp"));
    		return;
    	}
    }
    
    String ExMsg = null;
    int ExCode = 0;

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String SQL = null;

    try {
        
        conn = DbConn.getConnection();

        AppLogPersistence alp = new AppLogPersistence();
        
        String OldPwdDigest = crypt.digest(User_id, OldUserPwd);
            
        // Verify Current Password
        SQL = "SELECT * FROM secuser " +
              " WHERE User_id = ? AND user_pwd = ?";
        ps = conn.prepareStatement(SQL);
        ps.setString(1,User_id);
        ps.setString(2,OldPwdDigest);
        rs = ps.executeQuery();

        if (!rs.next())
        {   // bad password or user id
        	session.setAttribute("Retry", "1");
            alp.add(conn,User_id,User_id,OldPwdDigest,Module.CHANGE_PASSWORD_SERVLET,Message.FAILED_LOGIN_ATTEMPT,2);
        	response.sendRedirect(response.encodeRedirectURL("/mss/home/ChangePasswordJsp.jsp"));
            return;
        }

        String CurHintAnswer1 = StringUtil.nonNullTrim(rs.getString("HintAnswer"));
        String CurHintAnswer2 = StringUtil.nonNullTrim(rs.getString("Hint2_Answer"));
        String CurHintAnswer3 = StringUtil.nonNullTrim(rs.getString("Hint3_Answer"));
/*
        if (  (CurHintAnswer1.equals("") && (HintAnswer1.length() == 0)) ||
        	  (CurHintAnswer2.equals("") && (HintAnswer2.length() == 0)) ||
        	  (CurHintAnswer3.equals("") && (HintAnswer3.length() == 0))
			)
        {
*/
       if (!HintAnswer1.equals(""))
        	CurHintAnswer1 = HintAnswer1;
        if (!HintAnswer2.equals(""))
        	CurHintAnswer2 = HintAnswer2;
        if (!HintAnswer3.equals(""))
        	CurHintAnswer3 = HintAnswer3;
        if ( CurHintAnswer1.equals("") || CurHintAnswer2.equals("") || CurHintAnswer3.equals("") ) {
            logger.debug("No Hint");
            request.setAttribute("Retry", "3");
            response.sendRedirect(response.encodeRedirectURL("/mss/home/ChangePasswordJsp.jsp"));
            return;
        }
        
       if ( CurHintAnswer1.equalsIgnoreCase(CurHintAnswer2) ||
        	 CurHintAnswer1.equalsIgnoreCase(CurHintAnswer3) ||
			 CurHintAnswer2.equalsIgnoreCase(CurHintAnswer3) ) {
   		session.setAttribute("Retry", "4");
            response.sendRedirect(response.encodeRedirectURL("/mss/home/ChangePasswordJsp.jsp"));
            return;        	
        }
        if ( (CurHintAnswer1.length() < 3) ||
           	 (CurHintAnswer2.length() < 3) ||
   			 (CurHintAnswer3.length() < 3) ) {
        	session.setAttribute("Retry", "4");
               response.sendRedirect(response.encodeRedirectURL("/mss/home/ChangePasswordJsp.jsp"));
               return;        	
           }

   	    CurPhone = StringUtil.nonNullTrim(rs.getString("Phone"));
        CurEmail = StringUtil.nonNullTrim(rs.getString("Email"));
        
        String UpdSQL = "";
        ArrayList parameters = new ArrayList();
        
        //String lastQCareMPwd = null;
        //String lastQCareSPwd = null;
        //String lastQCarePPwd = null;
        //SecuserSettingPersistence sup = null;
        
        //if (savePwd) {
        //    sup = new SecuserSettingPersistence(log.getStream());
        //    lastQCareMPwd = sup.getValue(conn,User_id,SecuserSetting.QCARE_M_PWD);
        //    lastQCareSPwd = sup.getValue(conn,User_id,SecuserSetting.QCARE_S_PWD);
        //    lastQCarePPwd = sup.getValue(conn,User_id,SecuserSetting.QCARE_P_PWD);
        //}
        
        String NewPwdDigest = null;
        int logOperation = Message.USER_INFO_CHANGED;
        if (NewUserPwd.length() > 0)
        {
        	logOperation = Message.USER_PASSWORD_CHANGE;
        	
            NewPwdDigest = crypt.digest(User_id, NewUserPwd);
            // Check if new password is same as one of the old
            SQL = "SELECT * FROM secuser " +
                  " WHERE User_id = ?" +
                    " AND (user_pwd = ? OR" +
                         " oldpwd1 = ? OR" +
                         " oldpwd2 = ? OR" +
                         " oldpwd3 = ? OR" +
                         " oldpwd4 = ? OR" +
                         " oldpwd5 = ? OR" +
                         //Added new columns for TSA-IFOX-00406847 -start
                         " oldpwd6 = ? OR" +   
                         " oldpwd7= ? OR" +
                         " oldpwd8 = ? OR" +
                         " oldpwd9 = ? OR" +
                         " oldpwd10 = ? OR" +
                         " oldpwd11 = ? OR" +
                         " oldpwd12= ? OR" +
                         " oldpwd13= ? OR" +
                         " oldpwd14= ? OR" +
                         " oldpwd15= ?)";
            ps = conn.prepareStatement(SQL);
            ps.setString(1,User_id);
            ps.setString(2,NewPwdDigest);
            ps.setString(3,NewPwdDigest);
            ps.setString(4,NewPwdDigest);
            ps.setString(5,NewPwdDigest);
            ps.setString(6,NewPwdDigest);
            ps.setString(7,NewPwdDigest);
            ps.setString(8,NewPwdDigest);
            ps.setString(9,NewPwdDigest);
            ps.setString(10,NewPwdDigest);
            ps.setString(11,NewPwdDigest);
            ps.setString(12,NewPwdDigest);
            ps.setString(13,NewPwdDigest);
            ps.setString(14,NewPwdDigest);
            ps.setString(15,NewPwdDigest);
            ps.setString(16,NewPwdDigest);
            ps.setString(17,NewPwdDigest); //Added new columns for TSA-IFOX-00406847-end
            
            rs = ps.executeQuery();
            if (rs.next())
            {
            	alp.add(conn,User_id,User_id,OldPwdDigest,Module.CHANGE_PASSWORD_SERVLET,Message.PASWORD_REUSE,3);
            	session.setAttribute("Retry", "2");
                response.sendRedirect((String)response.encodeRedirectURL("/mss/home/ChangePasswordJsp.jsp"));
                return;
             }
            //Penetration Testing Changes -end

            // get number of days for password aging
            SQL = "SELECT pwdexpiredays FROM systemparms";
            ps = conn.prepareStatement(SQL);
            rs = ps.executeQuery();

            if (!rs.next())
            {
                logger.debug("Expire Days Query Error");
                response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/ErrorPJsp.jsp?MsgId=3"));
                return;
            }

            int ExpireDays = rs.getInt("PWDEXPIREDAYS");

            // Calculate new expiration date
            Calendar now = Calendar.getInstance();
            now.add(Calendar.DATE,ExpireDays);
            String NewExpireDate = String.valueOf(now.get(Calendar.YEAR)) + "-" +
                                   String.valueOf(now.get(Calendar.MONTH) + 1) + "-" +
                                   String.valueOf(now.get(Calendar.DAY_OF_MONTH)) + "-" +
                                   "00.00.00.000000";

            UpdSQL = " OldPwd15 = OldPwd14," +   //Added new columns for TSA-IFOX-00406847
            		" OldPwd14 = OldPwd13," +
            		" OldPwd13 = OldPwd12," +
            		" OldPwd12 = OldPwd11," +
            		" OldPwd11 = OldPwd10," +
            		" OldPwd10 = OldPwd9," +
            		" OldPwd9 = OldPwd8," +
            		" OldPwd8 = OldPwd7," +
            		" OldPwd7 = OldPwd6," +
            		" OldPwd6 = OldPwd5," +
            		" OldPwd5 = OldPwd4," +
                    " OldPwd4 = OldPwd3," +
                    " OldPwd3 = OldPwd2," +
                    " OldPwd2 = OldPwd1," +
                    " OldPwd1 = user_pwd," +
                    " user_pwd = ?," + 
					" pwdexpire_date = ?";
            parameters.add(NewPwdDigest);
            parameters.add(NewExpireDate);
        }

        if (HintAnswer1.length() > 0)
        {
            if (UpdSQL.length() > 0)
                UpdSQL = UpdSQL + ",";
            UpdSQL = UpdSQL + " Hint_id = ?, HintAnswer = ?";
            parameters.add(Hint_id1);
            parameters.add(HintAnswer1);
        }
        
        if (HintAnswer2.length() > 0)
        {
            if (UpdSQL.length() > 0)
                UpdSQL = UpdSQL + ",";
            UpdSQL = UpdSQL + " Hint2_id = ?, Hint2_Answer = ?";
            parameters.add(Hint_id2);
            parameters.add(HintAnswer2);
        }
        
        if (HintAnswer3.length() > 0)
        {
            if (UpdSQL.length() > 0)
                UpdSQL = UpdSQL + ",";
            UpdSQL = UpdSQL + " Hint3_id = ?, Hint3_Answer = ?";
            parameters.add(Hint_id3);
            parameters.add(HintAnswer3);
        }
        
        if(!UpdatedPhone.equals(CurPhone))
        {	
        	if (UpdSQL.length() > 0)
                UpdSQL = UpdSQL + ",";
            UpdSQL = UpdSQL + " Phone = ?";
            parameters.add(UpdatedPhone);
        }
        
        if(!UpdatedEmail.equals(CurEmail))
        {	
        	if (UpdSQL.length() > 0)
                UpdSQL = UpdSQL + ",";
            UpdSQL = UpdSQL + " Email = ?";
            parameters.add(UpdatedEmail);
        }

        if (UpdSQL.length() > 0)
        {
        	if (hasNewPasswd) {
	            /* If the user has BusinessObjects privileges and has changed the password, 
	             * reflect the change in BusinessObjects also*/
        		try {
        			String temp = (String)session.getAttribute(Constants.SESSION_SERVICE_BOR);
        			if ("TRUE".equalsIgnoreCase(temp)) {
        				//IFOX-00412735 changes -start
                		/*boolean boError = false;
                		StringBuffer errorMsg = new StringBuffer("");
                		BOAdmin boInfo = BusinessObjectsAdapter.getBOInformations(conn);
                		if (boInfo.getCmcUrl()==null || boInfo.getAdminId()==null || boInfo.getAdminPasswd() == null) {
                			boError = true;
                			errorMsg.append("BO SYS_PARMS Lookup Error");                			
                		} else {
                			int returnCode = BusinessObjectsAdapter.changePassword(boInfo.getCmcUrl(), boInfo.getAdminId(), boInfo.getAdminPasswd(), User_id, NewUserPwd, errorMsg);
                			switch (returnCode){
            					case BusinessObjectsAdapter.SUCCESSFUL_PASSWORD_CHANGE:
            						alp.add(conn, User_id, Module.CHANGE_PASSWORD_SERVLET, Message.BO_PASSWORD_CHANGED,5);
            						logger.info("Successfully changed the BusinessObjects password for user [" + User_id + "]");
            						break;	
            					case BusinessObjectsAdapter.USERID_NOT_FOUND:
            						boError = true;
            						logger.error("BusinessObjects cannot find this [" + User_id + "]");
            						errorMsg.append("BO User Not Found");
        							break;	
            					case BusinessObjectsAdapter.ADMINCANNOTLOGIN:
            						//This is serious error. Administrator cannot login
            						boError = true;
        							errorMsg.append("Administrator cannot login to Business Object");
        							break;
            				default:
            					boError = true;
                			}
                		}
                		if (boError) {
                			String msg = errorMsg.toString();
                			if (msg.length() > 255)
                				msg = msg.substring(0,255);
                			if (msg.length() == 0)
                				msg = "Unknown Error";
                			alp.add(conn, User_id, User_id, msg, Module.CHANGE_PASSWORD_SERVLET, Message.BO_PASSWD_FAILED,6);
                			sendBOProblemEmail(User_id, errorMsg.toString());
                			//logger.error("Error while trying to change password");
                			// String retryCodeParm = ( (boRetryCode > 0) ? ("?Retry=" + boRetryCode)  : "" );
                			//response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/ErrorPJsp.jsp?Msg=Unexpected+BusinessObjectError"));
                			//response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/ErrorPJsp.jsp?MsgId=4"));
                			//response.sendRedirect(response.encodeRedirectURL("/mss/home/ChangePasswordJsp.jsp"+retryCodeParm));
                			//return;
                		}*/
        				//IFOX-00412735 changes -end
                	}
               	} catch(Throwable t) {
               		logger.error(t.getMessage());
               	}
	        }
        	
            UpdSQL = "UPDATE secuser SET " + UpdSQL + " WHERE User_id = ?";
            parameters.add(User_id);
            ps = conn.prepareStatement(UpdSQL);
            int idx = 0;
            Iterator it = parameters.iterator();
            while (it.hasNext()) {
            	idx += 1;
            	ps.setString(idx,(String)it.next());
            }
            
            ps.executeUpdate();

            alp.add(conn,User_id,User_id,NewPwdDigest,Module.CHANGE_PASSWORD_SERVLET,logOperation,1);
            
            if (hasNewPasswd) {
            	
                String cryptUserPwd = null;
                if (true) {
                	SessionCrypt sCrypt = new SessionCrypt();
                	cryptUserPwd = sCrypt.encrypt(conn,NewUserPwd);                	
                }

            	session.setAttribute("User_pwd",cryptUserPwd);

            }
        
            //if (savePwd) {
            //    if (lastQCareMPwd == null) {
            //        sup.add(conn,User_id,SecuserSetting.QCARE_M_PWD,OldUserPwd);
            //    }
            //    if (lastQCareSPwd == null) {
            //        sup.add(conn,User_id,SecuserSetting.QCARE_S_PWD,OldUserPwd);
            //    }
            //    if (lastQCarePPwd == null) {
            //        sup.add(conn,User_id,SecuserSetting.QCARE_P_PWD,OldUserPwd);
            //    }
            //}
        } else {
            alp.add(conn,User_id,User_id,NewPwdDigest,Module.CHANGE_PASSWORD_SERVLET,Message.NO_UPDATE_REQUIRED,4);
        }

        /*
        if (Required.equals("1"))
            response.sendRedirect((String)response.encodeRedirectURL("https://" + BaseUrl + "/mss/jsp/MsgJsp.jsp?Msg=Password+Change+Sucessfull&CL=/mss/jsp/IntroSetupJsp.jsp"));
         else
         	response.sendRedirect((String)response.encodeRedirectURL("https://" + BaseUrl + "/mss/jsp/MsgJsp.jsp?Msg=Password+Change+Sucessfull&CL=/mss/html/MainMain.html"));
        */
        
        //To go to home page insted of MainMain.html        
   
        response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/Message.jsp?Msg=Password+Change+Successful&CL=/mss/jsp/Recon/jsp/index.jsp"));
   
        

    } catch (Exception e) {
        logger.error(e.getMessage());
        //response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/ErrorPJsp.jsp?Msg=Unexpected+Error"));
        response.sendRedirect((String)response.encodeRedirectURL("/mss/jsp/ErrorPJsp.jsp?MsgId=5"));
    } finally {
        try {
            if (rs != null)
                rs.close();
        } catch(Exception e) {
            logger.error(e.getMessage());
        }
        try {
            if (ps != null)
                ps.close();
        } catch(Exception e) {
            logger.error(e.getMessage());
        }
        try {
            if (conn != null)
                conn.close();
        } catch(Exception e) {
            logger.error(e.getMessage());
        }
    }
}
	private void sendBOProblemEmail(String userId, String errMsg ) throws UnsupportedEncodingException, MessagingException{

		EmailNotification note = new EmailNotification();
		
		Calendar now = Calendar.getInstance();
		String reg_date = String.valueOf(now.get(Calendar.MONTH)+1) + "/" + String.valueOf(now.get(Calendar.DAY_OF_MONTH)) + "/" + String.valueOf(now.get(Calendar.YEAR));

		StringBuffer msgBody = new StringBuffer("Request for change password failed for the following userId ").append(userId)
		.append(" on ").append(reg_date).append("\n")
		.append(" error = ").append(errMsg).append("\n");
				
		note.sendEmail("Change Busines Object Password Request Failure", msgBody.toString() );
		
	}
}