/*
 * PortalFrontEndServlet.java
 *
 * Created on July 2, 2006, 9:34 PM
 */

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import javax.servlet.RequestDispatcher;

import com.ps.io.ModuleLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ps.mss.security.SessionManager;


/**
 *
 * @author  rnenne
 */
public class PortalFrontEndServlet extends HttpServlet {
	private static Logger logger = (Logger) LoggerFactory.getLogger(PortalFrontEndServlet.class);

	private boolean check = true;
	
    /** Creates a new instance of PortalFrontEndServlet */
    public PortalFrontEndServlet() {
    }
    
    public void init() {
    	try {
    		// to bypass for the developer studio
    		String value = getServletConfig().getInitParameter("check");
    		if (value != null)
    			if (value.equals("FALSE"))
					check = false;
    	} catch(Exception e) {
    		
    	}
    }
    
    public void service(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException
    {
        
        if (check) {
        	if (!request.isSecure()) {
        		logger.error("No Session");
        		//response.sendRedirect("/mss/jsp/ErrorPJsp.jsp?Msg=Invalid+Page+Request");
        		//20120606_ERRORPJSP_FIX
        		response.sendRedirect("/mss/jsp/ErrorPJsp.jsp?MsgId=6");
        		return;            
        	}
        
        	HttpSession session = SessionManager.getSession(request);
        
        	if (session == null) {
        		logger.error("No Session");
        		//response.sendRedirect("/mss/jsp/ErrorPJsp.jsp?Msg=Page+Expired");
        		response.sendRedirect("/mss/jsp/ErrorPJsp.jsp?MsgId=1");
        		return;
        	}
        }
        
        //logger.error("Forwarding");
        RequestDispatcher rd = request.getRequestDispatcher("/servlet/PortalBackEndServlet");
        rd.forward(request,response);

    }
}
