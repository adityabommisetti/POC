/*
 * Created on Jun 18, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ps.mss.adapter;

/**
 * @author indrapradja.adriana
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class BOAdmin {
	private String CmcUrl;
	private String AdminId;
	private String AdminPasswd;
	
	/**
	 * @return Returns the adminId.
	 */
	public String getAdminId() {
		return AdminId;
	}
	/**
	 * @param adminId The adminId to set.
	 */
	public void setAdminId(String adminId) {
		AdminId = adminId;
	}
	/**
	 * @return Returns the adminPasswd.
	 */
	public String getAdminPasswd() {
		return AdminPasswd;
	}
	/**
	 * @param adminPasswd The adminPasswd to set.
	 */
	public void setAdminPasswd(String adminPasswd) {
		AdminPasswd = adminPasswd;
	}
	/**
	 * @return Returns the cmcUrl.
	 */
	public String getCmcUrl() {
		return CmcUrl;
	}
	/**
	 * @param cmcUrl The cmcUrl to set.
	 */
	public void setCmcUrl(String cmcUrl) {
		CmcUrl = cmcUrl;
	}
}
