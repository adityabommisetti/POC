//IFOX-00412735 changes -start
/*
 * Created on Apr 8, 2008
 * This class is the Adapter communicating between the MSS system and the BO system *
 
package com.ps.mss.adapter;

import java.sql.Connection;

import org.slf4j.Logger;

import com.crystaldecisions.sdk.exception.SDKException;
import com.crystaldecisions.sdk.framework.CrystalEnterprise;
import com.crystaldecisions.sdk.framework.IEnterpriseSession;
import com.crystaldecisions.sdk.framework.ISessionMgr;
import com.crystaldecisions.sdk.occa.infostore.IInfoObjects;
import com.crystaldecisions.sdk.occa.infostore.IInfoStore;
import com.crystaldecisions.sdk.plugin.desktop.user.IUser;
import org.slf4j.LoggerFactory;
import com.ps.mss.db.SysParmsPersistence;
import com.ps.mss.db.SysParms;
import com.ps.io.ModuleLog;

*//**
 * @author palat.pradeep
 *//*
*//**$Id: BusinessObjectsAdapter.java,v 1.1 2014/06/26 07:45:20 praveen Exp $*//*

public class BusinessObjectsAdapter {
	private static Logger logger=LoggerFactory.getLogger(BusinessObjectsAdapter.class);

	//private static ModuleLog log = new ModuleLog("BusinessObjectsAdapter");
	public static final String AUTH_TYPE_ENTERPRISE = "secEnterprise";
	public static final int SUCCESSFUL_PASSWORD_CHANGE = 0;		
	public static final int UNKNOWN_ERROR = 1;
	public static final int USERID_NOT_FOUND = 2;
	public static final int ADMINCANNOTLOGIN = 3;
	
	//Constants for business object preferences.
	public static final int SESSION_SIGN_OFF = 0;
	public static final int PREFERENCE_SIZE = SESSION_SIGN_OFF + 1;  
			
	public static int changePassword(String cms, String adminId,  String adminPasswd, String userId, String newPassword,StringBuffer errorMsg) throws Exception{
		ISessionMgr sessionMgr = null;
		IEnterpriseSession passwordMgr = null;
		boolean adminLogin = false;
		try{
			// Since BO users cannot change their password perform the action through the admin user.
			sessionMgr = CrystalEnterprise.getSessionMgr();
			passwordMgr = sessionMgr.logon(adminId, adminPasswd, cms, AUTH_TYPE_ENTERPRISE); //Constants.BO_PASSWORD_MANAGER_ID
			adminLogin = true;
			IInfoStore iStore = (IInfoStore)passwordMgr.getService("InfoStore");
			IInfoObjects users = iStore.query ("SELECT SI_ID,SI_NAME FROM CI_SYSTEMOBJECTS WHERE SI_KIND='USER' And SI_NAME='" + userId+"'");
			if (users.size()==0)
				return USERID_NOT_FOUND;
			IUser iUser = ((IUser)users.get(0)); 
			iUser.setNewPassword(newPassword);
			iStore.commit(users);
			
		}catch ( SDKException sdke){
			logger.error(sdke.getMessage());				
			errorMsg.append(sdke.getMessage());
			return (adminLogin? UNKNOWN_ERROR:ADMINCANNOTLOGIN) ;
		}catch ( Exception ex){
			logger.error(ex.getMessage());			
			errorMsg.append(ex.getMessage());				
			return (adminLogin? UNKNOWN_ERROR:ADMINCANNOTLOGIN) ;
		}
		finally{
			if (passwordMgr != null)
				passwordMgr.logoff();	
		}
		return SUCCESSFUL_PASSWORD_CHANGE;
	}	
	
	public static boolean login(String cmc, String userId, String password, StringBuffer errorMsg) {
		ISessionMgr sessionMgr = null;
		IEnterpriseSession passwordMgr = null;
		boolean result = false;
		try{
			// Since BO users cannot change their password perform the action through the admin user.
			sessionMgr = CrystalEnterprise.getSessionMgr();
			passwordMgr = sessionMgr.logon(userId, password, cmc, AUTH_TYPE_ENTERPRISE); 
			result = true;
			
		}catch ( SDKException sdke){
			logger.error(sdke.getMessage());		
			errorMsg.append(sdke.getMessage());
		}catch ( Exception ex){
			logger.error(ex.getMessage());			
			errorMsg.append(ex.getMessage());				
		}
		finally{
			if (passwordMgr != null)
				passwordMgr.logoff();	
		}
		return result;
	}	
	
	public static BOAdmin getBOInformations(Connection conn) {
		BOAdmin result = new BOAdmin();
	    try {
	        SysParmsPersistence sp = new SysParmsPersistence();
	    	result.setCmcUrl(sp.getSysParmsValue(conn,SysParms.BO_CMC_URL));
	    	result.setAdminId(sp.getSysParmsValue(conn,SysParms.BO_PWMGR_ID));
	    	result.setAdminPasswd(sp.getSysParmsValue(conn,SysParms.BO_PWMGR_PWD));
	    } catch(Exception e) {
			logger.error("BusinessObjectsAdapter :BOInformations : Caught Exception " + e.getMessage());	
	    } 
	    return result;
	}
}

*/
//IFOX-00412735 changes -end