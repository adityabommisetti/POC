/*

 * $Id: EEMApplService.java,v 1.67 2016/09/22 17:17:38 dinesh Exp $
 */
package com.ps.mss.businesslogic;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.StringTokenizer;
import java.util.TreeSet;

import org.apache.commons.lang.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.DaoFactory;
import com.ps.mss.dao.EEMApplDao;
import com.ps.mss.dao.EEMDao;
import com.ps.mss.dao.EEMEnrollDao;
import com.ps.mss.dao.EEMOevDao;
import com.ps.mss.dao.EEMWorkFlowDao;
import com.ps.mss.dao.model.EEMApplAddressVO;
import com.ps.mss.dao.model.EEMApplAttestationVO;
import com.ps.mss.dao.model.EEMApplCommentsVO;
import com.ps.mss.dao.model.EEMApplProductsVO;
import com.ps.mss.dao.model.EEMElectionVO;
import com.ps.mss.dao.model.EEMFieldErrorVO;
import com.ps.mss.dao.model.EMApplTriggerVO;
import com.ps.mss.dao.model.EMBeqVO;
import com.ps.mss.dao.model.ElectionResponse;
import com.ps.mss.dao.model.ElectionVO;
import com.ps.mss.dao.model.EmApplLepAttestInfoVO;
import com.ps.mss.dao.model.EmAttestationVO;
import com.ps.mss.dao.model.EmCorrMbrVO;
import com.ps.mss.dao.model.EmMbrOevInfoVO;
import com.ps.mss.dao.model.EmPreSetNoteVO;
import com.ps.mss.dao.model.LepPtnlUncovMthsVO;
import com.ps.mss.db.CARAHistoryDetails;
import com.ps.mss.db.EEMCodeCache;
import com.ps.mss.db.EEMProfileSettings;
import com.ps.mss.db.MBD;
import com.ps.mss.db.MBDHistoryPersistence;
import com.ps.mss.db.MBDPersistence;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.EEMConstants;
import com.ps.mss.helper.RESTClient;
import com.ps.mss.model.EEMAgreementQueueActivityVO;
import com.ps.mss.model.EEMApplEligibilityVO;
import com.ps.mss.model.EEMApplicationVO;
import com.ps.mss.model.EEMContext;
import com.ps.mss.model.EEMErrorVO;
import com.ps.mss.model.EEMOriginalApplicationVO;
import com.ps.mss.model.EEMProfileItem;
import com.ps.mss.model.EEMQueueActivityVO;
import com.ps.mss.model.PRTDHistoryVO;
import com.ps.mss.model.Pagination;
import com.ps.mss.model.RDSHistoryVO;
import com.ps.mss.security.CipherUtil;
import com.ps.mss.util.SecurityProperties;
import com.ps.text.DateFormatter;
import com.ps.text.NumberFormatter;
import com.ps.util.DateMath;
import com.ps.util.DateUtil;
import com.ps.util.NameValuePair;
import com.ps.util.StringUtil;
/**
 * @author Raghu Gorur
 *  
 * Business logic for new member application form.
 */
public class EEMApplService {

	private static Logger logger=LoggerFactory.getLogger(EEMApplService.class);
	
	private static final String FILLER_SPACE = " ";
	
	/**
	 * Gets array of Product name and id for given criteria.
	 * 
	 * @param conn
	 * @param objVO
	 * @return
	 * @throws ApplicationException
	 */
	public EEMApplicationVO getProducts(Connection conn, EEMApplicationVO objVO)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplicationVO products = null;
		try {
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			List lstProducts = eemDao.getProducts(conn, objVO);
			
			// Set the products Details
			if(lstProducts.size() > 0) {
				EEMApplProductsVO productVO = null;
				products = new EEMApplicationVO();
				
				productVO = (EEMApplProductsVO)lstProducts.get(0);
				String prodId = StringUtil.nonNullTrim(productVO.getProductId());
				String groupId = StringUtil.nonNullTrim(productVO.getGroupId());
				List newList = new ArrayList();
				newList.add(productVO);
				for (int i = 0; i < lstProducts.size(); i++) {
					productVO = (EEMApplProductsVO)lstProducts.get(i);
					// Set the Payment Amt
					double pymtAmt = 0;
					if (!"Y".equals(productVO.getSnpInd())) {
						String prtCAmt = StringUtil.nonNullTrim(productVO.getPrtCPremiumAmt());
						String prtDAmt = StringUtil.nonNullTrim(productVO.getPrtDPremiumAmt());
						String supplAmt = StringUtil.nonNullTrim(productVO.getSupplPremiumAmt());
						String premReducAmt = StringUtil.nonNullTrim(productVO.getPremiumReductionAmt());
						String dsrRebateAmt = StringUtil.nonNullTrim(productVO.getDsrRebateAmt());
						
						//prtCAmt = NumberFormatter.formatDecimal2Places(prtCAmt);
						//prtDAmt = NumberFormatter.formatDecimal2Places(prtDAmt);
						pymtAmt = Double.parseDouble(prtCAmt) + Double.parseDouble(prtDAmt) + Double.parseDouble(supplAmt)  
						         - Double.parseDouble(premReducAmt) - Double.parseDouble(dsrRebateAmt);
					}
					productVO.setPymtAmt(NumberFormatter.formatDecimal2Places(pymtAmt));

					// Check for more than one Group Id and Product Id combination
					String tmpProdId = StringUtil.nonNullTrim(productVO.getProductId());
					String tmpGroupId = StringUtil.nonNullTrim(productVO.getGroupId());
					if (i > 0) {
						if (!prodId.equals(tmpProdId) || !groupId.equals(tmpGroupId)) {
							newList.add(productVO);
							prodId = tmpProdId;
							groupId = tmpGroupId;
						}
					}
				}
				lstProducts = newList;
				
				// populate the values
				if(lstProducts.size() == 1) {
					productVO = (EEMApplProductsVO)lstProducts.get(0);
					products.setEnrollGroup(productVO.getGroupId());
					products.setEnrollGroupName(productVO.getGroupName());
						products.setEnrollProduct(productVO.getProductId());
					products.setEnrollProdName(productVO.getProductName());
					products.setPerZip5(productVO.getZipCode5());
					products.setPerZip4(productVO.getZipCode4());
					products.setEnrollPlan(productVO.getPlanId());
					products.setEnrollPbp(productVO.getPbpId());
					products.setEnrollSegment(productVO.getSegmentId());
					products.setPerCity(productVO.getArea());
					products.setPerState(productVO.getStateCd());
					products.setPerCounty(productVO.getCounty());
					products.setEnrollPlanDesgn(productVO.getPlanDesignation());
					products.setEnrollPymtAmt(productVO.getPymtAmt());
					/**AAH BasePlus Migration IFOX-00426351 START*/
					products.setEnrollLineOfBusiness(productVO.getLineOfBusiness());
					/**AAH BasePlus Migration IFOX-00426351 END*/
					products.setMultiProducts("N");
				} else if (lstProducts.size() > 1) {
					products.setMultiProducts("Y");
				}
				
				// Set odd rows
				for (int i = 1; i <= lstProducts.size(); i++) {
					productVO = (EEMApplProductsVO)lstProducts.get(i-1);
					if (i%2 != 0) {
						productVO.setEvenRow("N");
					} 
				}
				products.setProducts(lstProducts);
			} 
			
		} catch (Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			products = new EEMApplicationVO();
			products.setMessage("Error during Products Retrieval.");
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return products;
	}
	
	public List getCityNames(Connection conn, String zip5, String zip4) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		List lstCity = null;
		List city = null;
		try {
			EEMDao eemDao = new EEMDao();
			lstCity = eemDao.getCityNameswithCounty(conn, zip5, zip4);
			//System.out.println("size in service:::::::::::::::"+lstCity.size());
			
					
				/*tempVO.setPerCity(listVO.getPerCity());
				tempVO.setPerState(listVO.getPerState());
				tempVO.setPerZip5(listVO.getPerZip5());
				tempVO.setPerCounty(listVO.getPerCounty());*/
						/*tempVO.setPerCity(city.get(0));
						tempVO.setPerState(stk.nextToken());
						tempVO.setPerZip5(stk.nextToken());
						tempVO.setPerCounty(stk.nextToken());
						String tmpZip = stk.nextToken();
						if (!tmpZip.equals("0000"))
							tempVO.setPerZip4(tmpZip);*/
				
				
				//lstCity.add(tempVO);
				
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return lstCity;
	}
	public List getCityName(Connection conn, String zip5, String zip4) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		List lstCity = null;
		try {
			EEMDao eemDao = new EEMDao();
			String[] city = eemDao.getCityName(conn, zip5, zip4);
			
			if (city != null) {
				lstCity = new ArrayList();
				for (int i = 0; i < city.length; i++) {
					EEMApplicationVO tempVO = new EEMApplicationVO();
					StringTokenizer stk = new StringTokenizer(city[i], "|");
					if (stk.hasMoreTokens()) {
						tempVO.setPerCity(stk.nextToken());
						tempVO.setPerState(stk.nextToken());
						tempVO.setPerZip5(stk.nextToken());
						String tmpZip = stk.nextToken();
						if (!tmpZip.equals("0000"))
							tempVO.setPerZip4(tmpZip);
					}
					lstCity.add(tempVO);
				}
			}
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return lstCity;
	}

	public List getPcpNames(Connection conn, EEMApplicationVO objVO)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		List lstPcpNames = null;
		try {
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			String currPatient = StringUtil.nonNullTrim(objVO.getPcpCurrPatnt());
			if (currPatient.equals("")) {
				currPatient = "N";
			}
			lstPcpNames = eemDao.getLstPCPNames(conn, objVO.getCustomerId(),
					objVO.getReqDtCov(), objVO.getPcpName(), 
					objVO.getPcpOfficeCd(), currPatient, 
					objVO.getPcpLocationId(),
					objVO.getEnrollLineOfBusiness(), //AAH BasePlus Migration IFOX-00426351 Changes
					objVO.getPcpNpiId());// Added for Access Health Pcp CR

			
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return lstPcpNames;
	}

	public List getValidatingFormFields(String sFormName, Connection conn,
			String customerId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		List lstFields = null;
		try {

			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();

			lstFields = eemDao.getFormFieldErrors(conn, sFormName, customerId);

		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return lstFields;
	}

	public EMApplTriggerVO hasRFI(Connection conn, EEMApplicationVO objVO) throws SQLException, NumberFormatException, ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EMApplTriggerVO trig = null;
		
		if (!StringUtil.nonNullTrim(objVO.getApplId()).equals("")) {
			EEMApplDao applDao = new EEMApplDao();
			trig = applDao.getApplTriggerForFunc(conn,objVO.getCustomerId(),
					                                             Integer.parseInt(objVO.getApplId()),
															     EEMConstants.TRIGGER_FUNC_RFI_ENRL);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return trig;
		
	}
	public void validateFormFields(Connection conn, String eemDb, List lstFields, EEMApplicationVO objVO,
			String sFormClass) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			EMApplTriggerVO trig = hasRFI(conn,objVO); 
			String needsRFI = "";
			if (trig != null) {
				needsRFI = StringUtil.nonNullTrim(trig.getTriggerStatus());
			}
			
			List lstErrors = new ArrayList();
			Class objClass = Class.forName(sFormClass);
			for (int i = 0; i < lstFields.size(); i++) {
				EEMFieldErrorVO fieldVO = (EEMFieldErrorVO) lstFields.get(i);
				String sFormField = StringUtil.nonNullTrim(fieldVO.getFormField());
				if (sFormField == null || sFormField.trim().equals("")) {
					continue;
				}

				// Get the field value and type
				logger.debug(sFormField.trim());
				Field field = objClass.getDeclaredField(sFormField.trim());
				field.setAccessible(true);
				String retType = field.getType().toString();
				Object val = field.get(objVO);
				if (val == null) {
					continue;
				}

				// Check for String array
				if (retType.indexOf("[L") != -1) {
					String[] arr = (String[]) val;			
					//System.out.println(field.getName() + "-");

					for (int j = 0; j < arr.length; j++) {
						logger.debug(arr[j]);
					}
					continue;
				}

				//System.out.println(field.getName() + "-" + val);

				// Check for Required error
				if (retType.equals("class java.lang.String")) {
					EEMErrorVO objError = validateError(conn, eemDb, val.toString(), fieldVO, objVO, needsRFI);
					if (objError != null) {
						lstErrors.add(objError);	
					}
				}
			}

			// Set the error to the form
			if (lstErrors.size() > 0) {
				objVO.setLstErrors(lstErrors);
			} else {
				objVO.setLstErrors(null);
			}

		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	private EEMErrorVO validateError(Connection conn, String eemDb, String val, EEMFieldErrorVO fieldVO,
			EEMApplicationVO objVO, String needsRFI) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMErrorVO objError = null;
		
		try {
			String reqInd = StringUtil.nonNullTrim(fieldVO.getRequiredInd());

			if (reqInd.equals("")) {
				logger.info(LoggerConstants.methodEndLevel());
				return objError;
			}
			
			boolean isError = false;
			String status = "";
			// check for applDate is done in validateUpdateFields after setting of election type
			if (fieldVO.getFormField().equals("applDate")) {
				logger.info(LoggerConstants.methodEndLevel());
				return objError;
			}
			
			// check for signDate is done in validateUpdateFields after setting of election type
			/*if (fieldVO.getFormField().equals("signDt")) {
				return objError;
			}*/
			/**
			 * Cambia_INCRFIREQ-Start
			 */
			// IFOX-00400051 app will go to RFI status based on the DB config, no spl handling is required
//			if (fieldVO.getFormField().equals("signDt")) {
//				
//				if(StringUtil.nonNullTrim(objVO.getSignDt()).equals("")){
//				objError = getErrorVO(fieldVO, objVO, fieldVO.getErrorCd(), EEMConstants.APPL_STATUS_INCRFIREQ);
//				}
//				
//				return objError;
//			}
			/**
			 * Cambia_INCRFIREQ-End
			 */
			// Check for election Type
			if (fieldVO.getFormField().equals("electionType")) {
				logger.info(LoggerConstants.methodEndLevel());
				return objError;
			}
			
			// Check for RxId
			if (fieldVO.getFormField().equals("mbrRxId")) {
				if (!validateRxId(objVO)) {
					logger.info(LoggerConstants.methodEndLevel());
					return objError;
				}
				String rxIdInd = EEMProfileSettings.getCalendarProfileItem( 
									eemDb, objVO.getCustomerId(), EEMProfileSettings.RXID);
				if (rxIdInd != null && !rxIdInd.equals(EEMProfileSettings.RXID_CUST_SUPPLIED)) {
					logger.info(LoggerConstants.methodEndLevel());
					return objError;
				}
			}

			// Check for County
			if (fieldVO.getFormField().equals("perCounty") && 
					StringUtil.nonNullTrim(objVO.getPerCounty()).equals("")) {
				objVO.setPerCounty(new EEMApplDao().getCounty(conn, StringUtil
						.nonNullTrim(objVO.getPerZip5()), StringUtil
						.nonNullTrim(objVO.getPerZip4())));
				val = StringUtil.nonNullTrim(objVO.getPerCounty());
			}
			// Check for Application Nbr
			if (fieldVO.getFormField().equals("mbrApplNo")) {
				String applNbrInd = EEMProfileSettings.getCalendarProfileItem(
						eemDb, objVO.getCustomerId(), EEMProfileSettings.APPNBR);
				if (applNbrInd != null && applNbrInd.equals(EEMProfileSettings.APPNBR_DERIVED)) {
					logger.info(LoggerConstants.methodEndLevel());
					return objError;
				}
			}
			// Check for Supplemental Id
			if (fieldVO.getFormField().equals("altMbrId")) {
				String supplInd = EEMProfileSettings.getCalendarProfileItem(
												eemDb, objVO.getCustomerId(), EEMProfileSettings.SUPPLID);
				if (supplInd != null && !supplInd.equals(EEMProfileSettings.SUPPLID_CUST_SUPPLIED)) {
					logger.info(LoggerConstants.methodEndLevel());
					return objError;
				}
			}
			
			if (val.equals("")) {// Blank
				if (reqInd.equalsIgnoreCase("R")) {
					isError = true;
					if (needsRFI.equals(""))
						status = EEMConstants.APPL_STATUS_INCRFIREQ;
					else {// Check for Letter trigger status
						if (needsRFI.equals(EEMConstants.TRIGGER_STATUS_CLOSED))
							status = EEMConstants.APPL_STATUS_INCRFIGEN;
						else
							status = EEMConstants.APPL_STATUS_INCRFITRG;
					}
					objVO.setStatusRFI(status);
				} else if (reqInd.equalsIgnoreCase("C")) {
					isError = true;
					status = EEMConstants.APPL_STATUS_ERRORCRITL;
				} else if (reqInd.equalsIgnoreCase("Y")) {
					isError = true;
					status = EEMConstants.APPL_STATUS_ERROR;
				}
			} else if (!validateEditRule(conn, eemDb, val, fieldVO, objVO)) {// Edit rules
				isError = true;
				if (reqInd.equalsIgnoreCase("R"))
					status = EEMConstants.APPL_STATUS_INCRFIREQ;
				else if( reqInd.equalsIgnoreCase("C"))
					status = EEMConstants.APPL_STATUS_ERRORCRITL;
				else if(reqInd.equalsIgnoreCase("Y")) {
					status = EEMConstants.APPL_STATUS_ERRORCRITL;//IFOX-00400051
				} else if (reqInd.equalsIgnoreCase("W")) {
					status = EEMConstants.APPL_STATUS_ERROR;
				}
				/*if (reqInd.equalsIgnoreCase("R")
						|| reqInd.equalsIgnoreCase("C")
						|| reqInd.equalsIgnoreCase("Y")) {
					status = EEMConstants.APPL_STATUS_ERRORCRITL;
				} else if (reqInd.equalsIgnoreCase("W")) {
					status = EEMConstants.APPL_STATUS_ERROR;
				}*/
			} 

			// Check for Other drug covarage
			// IFOX-00381706 - COB Fix CR Summacare - Start
			String incmpltcob = EEMProfileSettings.getCalendarProfileItem(eemDb,objVO.getCustomerId(),EEMProfileSettings.INCMPLTCOB);
			//IFOX- 432573 - RX IND validation with other RX fields : start
			String rxValidate = EEMProfileSettings.getCalendarProfileItem(eemDb,objVO.getCustomerId(),EEMProfileSettings.RXINDVAL);
			//IFOX- 432573 - RX IND validation with other RX fields : end
			if (!StringUtil.nonNullTrim(incmpltcob).equals("Y")) {
				if (!checkOtherDrugCoverage(val, fieldVO, objVO)) {
					isError = true;
					//IFOX- 432573 - RX IND validation with other RX fields : start
					if(StringUtil.nonNullTrim(rxValidate).equals("Y"))
						status = EEMConstants.APPL_STATUS_ELGWARNING;
					else
						//IFOX- 432573 - RX IND validation with other RX fields : end
						status = EEMConstants.APPL_STATUS_ERRORCRITL;
				}
			}
			// IFOX-00381706 - COB Fix CR Summacare - End
			
			// Check for Valid City
			if (!isError && !checkValidCity(conn, val, fieldVO, objVO)) {
				isError = true;
				status = EEMConstants.APPL_STATUS_ELGWARNING;
			}

			// Check for Valid State
			if (!isError && !checkValidState(conn, val, fieldVO, objVO)) {
				isError = true;
				status = EEMConstants.APPL_STATUS_ELGWARNING;
			}

			if (isError) {
				objError = getErrorVO(fieldVO, objVO, fieldVO.getErrorCd(), status);
				objError.setValue(val.toString());
			}
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objError;
	}
	
	private boolean checkOtherDrugCoverage(String val, EEMFieldErrorVO fieldVO, EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String field = fieldVO.getFormField();
		if (field.equals("otherCov") || field.equals("covBin") || field.equals("covId") || field.equals("groupNo") || field.equals("covPcn"))
			if (objVO.getDrugCov().equals("Y") && val.equals("")) {
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		logger.info(LoggerConstants.methodEndLevel());
		return true;
	}
	
	/*IFOX-417544- start*/ 
/*	private boolean checkValidCity(Connection conn, String val, EEMFieldErrorVO fieldVO, EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String field = fieldVO.getFormField();
		String zip5 = null;
		String zip4 = null;
		try {
			if (field.equals("perCity")) {
				zip5 = StringUtil.nonNullTrim(objVO.getPerZip5());
				zip4 = StringUtil.nonNullTrim(objVO.getPerZip4());
			} else if (field.equals("mailCity")) {
				zip5 = StringUtil.nonNullTrim(objVO.getMailZip5());
				zip4 = StringUtil.nonNullTrim(objVO.getMailZip4());
			} else if (field.equals("authRepCity")) {
				zip5 = StringUtil.nonNullTrim(objVO.getAuthRepZip5());
				zip4 = StringUtil.nonNullTrim(objVO.getAuthRepZip4());
			} else {
				logger.info(LoggerConstants.methodEndLevel());
				return true;
			}
			
			String[] city = new EEMDao().getCityName(conn, zip5, zip4);
			if (city != null) {
				StringTokenizer stk = new StringTokenizer(city[0], "|");
				if (stk.hasMoreTokens()) {
					if (!val.equalsIgnoreCase(stk.nextToken())) {
						fieldVO.setErrorCd("AP199");
						logger.info(LoggerConstants.methodEndLevel());
						return false;
					}
				}
			} else if (!zip5.equals("")) {
				fieldVO.setErrorCd("AP199");
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return true;
	}*/
	
	/*IFOX- Ticket 417544*/ 
	private boolean checkValidCity(Connection conn, String val, EEMFieldErrorVO fieldVO, EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String field = fieldVO.getFormField();
		String zip5 = null;
		String zip4 = null;
		String altCity = null;
		boolean validCity = false;
		try {
			if (field.equals("perCity")) {
				zip5 = StringUtil.nonNullTrim(objVO.getPerZip5());
				zip4 = StringUtil.nonNullTrim(objVO.getPerZip4());
				altCity = StringUtil.nonNullTrim(objVO.getPerCity());
			} else if (field.equals("mailCity")) {
				zip5 = StringUtil.nonNullTrim(objVO.getMailZip5());
				zip4 = StringUtil.nonNullTrim(objVO.getMailZip4());
				altCity = StringUtil.nonNullTrim(objVO.getMailCity());
			} else if (field.equals("authRepCity")) {
				zip5 = StringUtil.nonNullTrim(objVO.getAuthRepZip5());
				zip4 = StringUtil.nonNullTrim(objVO.getAuthRepZip4());
				altCity = StringUtil.nonNullTrim(objVO.getAuthRepCity());
			} else {
				logger.info(LoggerConstants.methodEndLevel());
				return true;
			}
			
			String[] city = new EEMDao().getCityName(conn, zip5, zip4);
			if (city != null) {
				StringTokenizer stk = new StringTokenizer(city[0], "|");
				if (stk.hasMoreTokens()) {
					if (!altCity.equalsIgnoreCase(stk.nextToken())) {
						validCity = new EEMDao().getSecondaryCityName(conn, zip5, altCity);
						if(validCity){						
							logger.info(LoggerConstants.methodEndLevel());
							return true;
						}
						else {
							fieldVO.setErrorCd("AP199");
							logger.info(LoggerConstants.methodEndLevel());
							return false;
						}
					}
				}
			} else if (!zip5.equals("")) {
				fieldVO.setErrorCd("AP199");
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		} catch(Exception e) {
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return true;
	}
	
	/*IFOX-417544- end*/ 
	private boolean checkValidState(Connection conn, String val, EEMFieldErrorVO fieldVO, EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String field = fieldVO.getFormField();
		String zip5 = null;
		String zip4 = null;
		try {
			if (field.equals("perState")) {
				zip5 = StringUtil.nonNullTrim(objVO.getPerZip5());
				zip4 = StringUtil.nonNullTrim(objVO.getPerZip4());
			} else if (field.equals("mailState")) {
				zip5 = StringUtil.nonNullTrim(objVO.getMailZip5());
				zip4 = StringUtil.nonNullTrim(objVO.getMailZip4());
			} else if (field.equals("authRepState")) {
				zip5 = StringUtil.nonNullTrim(objVO.getAuthRepZip5());
				zip4 = StringUtil.nonNullTrim(objVO.getAuthRepZip4());
			} else {
				logger.info(LoggerConstants.methodEndLevel());
				return true;
			}
			
			String[] city = new EEMDao().getCityName(conn, zip5, zip4);
			if (city != null) {
				StringTokenizer stk = new StringTokenizer(city[0], "|");
				if (stk.hasMoreTokens()) {
					stk.nextToken();
					EEMCodeCache cache = EEMCodeCache.getInstance(); 
					if (!val.equalsIgnoreCase(cache.getCode(stk.nextToken(), cache.getLstStates()))) {
						fieldVO.setErrorCd("AP200");
						logger.info(LoggerConstants.methodEndLevel());
						return false;
					}
				}
			} else if (!zip5.equals("")) {
				fieldVO.setErrorCd("AP200");
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return true;
	}
	
	public boolean validateRxId(EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String planDesgn = StringUtil.nonNullTrim(objVO.getEnrollPlanDesgn());
		if (planDesgn.equals(EEMConstants.PLAN_DESGN_MAPD) || 
				planDesgn.equals(EEMConstants.PLAN_DESGN_COPD) || 
					planDesgn.equals(EEMConstants.PLAN_DESGN_PDP)) {
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}
		logger.info(LoggerConstants.methodEndLevel());
		return false;
	}
	
	public EEMErrorVO validateEligibility(Connection conn, String eemDb, EEMApplicationVO objVO, List lstFields)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		// Hic Nbr is not present
		if (objVO.getMbrHicNbr().equals("")) {
			return null;
		}
		
		EEMErrorVO objError = null;
		String status = "";
		String errorCode = "";
		EEMCodeCache cache = EEMCodeCache.getInstance();
		try {
			// If Supplimental Id is populated
			if (objVO.getAltMbrId() != null && !objVO.getAltMbrId().equals("")) {
				// Prior member check
			}

			MBD mbd = objVO.getMbd();
			/** Triple S BasePlus Migration START **/
			String beqCheck = EEMProfileSettings.getCalendarProfileItem(eemDb,
					objVO.getCustomerId(), EEMProfileSettings.BEQCHECK);
			/** Triple S BasePlus Migration END **/
			 /**
		   	 * Cambia_BEQ Validation_Online-Start
		   	 */
			objVO.setEligibilitySrcTable(mbd.getEligibilitySrcTable());
			 /**
		   	 * Cambia_BEQ Validation_Online-End
		   	 */
			//SSNRI 2017 Changes : start
			if ((StringUtil.nonNullTrim(mbd.getHicNbr()).equals("")) ||(StringUtil.nonNullTrim(objVO.getEligibilitySrcTable()).equalsIgnoreCase("")) ) { // no record
				mbd = verifyEligibility(conn, objVO.getMbrHicNbr(),
						objVO.getMbrLastName(), objVO.getMbrBirthDt(), eemDb,
						objVO.getCustomerNbr(),beqCheck,objVO.getIsHicOrMbi());
			//SSNRI 2017 Changes : end
				if (mbd != null) {
					objVO.setMbd(mbd);
					objVO.setDtLstChked(new DateUtil().getDB2DTS());
					objVO.setMbrXrefNbr(objVO.getMbd().getXrefClaimNbr()); // IFOX-00397126
					objVO.setNeedMBDUpdate("Y");
					 /**
				   	 * Cambia_BEQ Validation_Online-Start
				   	 */
					objVO.setEligibilitySrcTable(mbd.getEligibilitySrcTable());					

					 /**
				   	 * Cambia_BEQ Validation_Online-End
				   	 */
				}
			}
			
								
// Hic Nbr doesn't exist
			if (mbd == null) {
				//IFOX-00423084 - start
				if(objVO.getIsHicOrMbi().equalsIgnoreCase("hic")){
					errorCode = "AP357";
					status = EEMConstants.APPL_STATUS_ELGCRITICL;
				}
				else{
				errorCode = "AP062";
				status = EEMConstants.APPL_STATUS_ELGNOTFND;
				}
				//IFOX-00423084 - end
				/**
			   	 * Cambia_BEQ Validation_Online-Start
			   	 */
				objVO.setEligibilitySrcTable("");
				/**
			   	 * Cambia_BEQ Validation_Online-End
			   	 */
				// Customer preference BEQCHECK = 'Y'
				if (!StringUtil.nonNullTrim(objVO.getMbrBirthDt()).equals("")) {
					if (StringUtil.nonNullTrim(beqCheck).equals("Y")) {
						//IFOX-00423084 - start
						if(objVO.getIsHicOrMbi().equalsIgnoreCase("hic")){
							errorCode = "AP357";
							status = EEMConstants.APPL_STATUS_ELGCRITICL;
						}
						else{
						status = EEMConstants.APPL_STATUS_BEQPENDING;
						}
						//IFOX-00423084 - end
					}
				}
			} else { // Check for details
				String birthDt = DateUtil.changedDateFormatForMonth(
						            StringUtil.nonNullTrim(objVO.getMbrBirthDt()));
				mbd.setGenderCd(getMBDGender(mbd.getGenderCd()));
				List lstCounty = (List)cache.getHmpCounty().get(objVO.getPerState());
				if (lstCounty != null) {
					objVO.setCountyCd(cache.getPerCountyCode(objVO.getPerCounty(), lstCounty));
				}
				//BEQ Short term Solution --Start
				/*String prtAStDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtAEntitleDate()));
				String prtAEndDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtAEntitleEndDate()));
				String prtBStDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtBEntitleDate()));
				String prtBEndDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtBEntitleEndDate()));
				String reqDtCov = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getReqDtCov()));
				String deathDate = StringUtil.nonNullTrim(mbd.getDeathDate());
				String planDesig = StringUtil.nonNullTrim(objVO.getEnrollPlanDesgn());
				if (planDesig.equals("")) {
					if (objVO.getApplType().equals("NMA") || objVO.getApplType().equals("CMA")) {
						planDesig = "MAPD";
					} else {
						planDesig = "PDP";
					}
				}

				NameValuePair eligRslt = EEMElection.isEligible(reqDtCov,
						                                        prtAStDt,prtAEndDt,
														        prtBStDt,prtBEndDt,
														        deathDate,
														        planDesig);*/
				String prtAStDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getPartAEffDt()));
				String prtAEndDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtAEntitleEndDate()));
				String prtBStDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getPartBEffDt()));
				String prtBEndDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtBEntitleEndDate()));
				String reqDtCov = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getReqDtCov()));
				String deathDate = StringUtil.nonNullTrim(mbd.getDeathDate());
				String planDesig = StringUtil.nonNullTrim(objVO.getEnrollPlanDesgn());
				String prtAMbd = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtAEntitleDate()));
				String prtBMbd = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtBEntitleDate()));
				String prtDMbd = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtDEligibleDate()));
				String prtDDate = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getPartDEffDt()));
				objVO.setPartAEffEndDt(prtAEndDt);
				objVO.setPartBEffEndDt(prtBEndDt);
				if(!((StringUtil.nonNullTrim(prtAStDt).equalsIgnoreCase(StringUtil.nonNullTrim(prtAMbd))) &
						(StringUtil.nonNullTrim(prtBStDt).equalsIgnoreCase(StringUtil.nonNullTrim(prtBMbd))) &
						(StringUtil.nonNullTrim(prtDDate).equalsIgnoreCase(StringUtil.nonNullTrim(prtDMbd)))) && 
						!((StringUtil.nonNullTrim(prtAStDt).equals("")) & (StringUtil.nonNullTrim(prtBStDt).equals("")) & 
								(StringUtil.nonNullTrim(prtDDate).equals(""))) ){
					if(!StringUtil.nonNullTrim(prtAStDt).equalsIgnoreCase(StringUtil.nonNullTrim(prtAMbd))){						
						objVO.setPartAEffEndDt("99999999");
					}
					
					if(!StringUtil.nonNullTrim(prtBStDt).equalsIgnoreCase(StringUtil.nonNullTrim(prtBMbd))){						
						objVO.setPartBEffEndDt("99999999");						
					} 
						objVO.setEligOverrideInd("Y");
				}else{
					objVO.setEligOverrideInd("N");
					/** IFOX-00395878 : BEQ ISSUE fixed: START **/
					if (prtAStDt.trim().isEmpty())
						objVO.setPartAEffDt(DateUtil
								.formatMmDdYyyy(StringUtil.getZeroDateForNullOrEmpty(mbd.getPrtAEntitleDate())));
					if (prtBStDt.trim().isEmpty())
						objVO.setPartBEffDt(DateUtil
								.formatMmDdYyyy(StringUtil.getZeroDateForNullOrEmpty(mbd.getPrtBEntitleDate())));
					if (prtDDate.trim().isEmpty())
						objVO.setPartDEffDt(DateUtil
								.formatMmDdYyyy(StringUtil.getZeroDateForNullOrEmpty(mbd.getPrtDEligibleDate())));
					/** IFOX-00395878 : BEQ ISSUE fixed: END **/
				}
				if (planDesig.equals("")) {
					if (objVO.getApplType().equals("NMA") || objVO.getApplType().equals("CMA")) {
						planDesig = "MAPD";
					} else {
						planDesig = "PDP";
					}
				}
				NameValuePair eligRslt = null;
			
				 /*eligRslt = EEMElection.isEligible(reqDtCov,
						                               prtAMbd,objVO.getPartAEffEndDt(),
						                               prtBMbd,objVO.getPartBEffEndDt(),
														        deathDate,
														        planDesig);*/
				
				if (objVO.getEligOverrideInd().equals("N")) {
					eligRslt = EEMElection
							.isEligible(reqDtCov, prtAMbd, prtAEndDt, prtBMbd,
									prtBEndDt, deathDate, planDesig);
				} else {
					eligRslt = EEMElection.isEligible(reqDtCov, prtAStDt,
							prtAEndDt, prtBStDt, prtBEndDt, deathDate,
							planDesig);
				}
			
			//BEQ Short term Solution --End
				if (!eligRslt.getName().equals("000")) {
					if (eligRslt.getName().equals("002"))
						errorCode = "AP201";
					else
						errorCode = "AP064";
					status = EEMConstants.APPL_STATUS_ELGCRITICL;					
				}
				//CMS Changes Nov 2019 - IFOX : 00423084 start - if MBI format incorrect
				if(objVO.getIsHicOrMbi().equalsIgnoreCase("hic") && StringUtil.nonNullTrim(objVO.getMbiNbr()).equals("")){
					errorCode = "AP357";
					status = EEMConstants.APPL_STATUS_ELGCRITICL;
				}
				
				//CMS Changes Nov 2019 - IFOX : 00423084 end - if MBI format incorrect
				
				// Check for Mismatch errors
				if (errorCode.equals("")) {
					if (!objVO.getMbrLastName().equals(mbd.getLastName()) || 
							!birthDt.equals(DateUtil.changedDateFormatForMonth(mbd.getBirthDate()))) {
						errorCode = "AP063";
						status = EEMConstants.APPL_STATUS_ELGCRITICL;
					} else if (!mbd.getFirstName().equals(objVO.getMbrFirstName()) ||
							   !mbd.getGenderCd().equals(getMBDGender(objVO.getMbrGender())) ||
							   !mbd.getStateCd().equals(objVO.getPerState()) ||
							   !mbd.getCountyCd().equals(objVO.getCountyCd())) {
						errorCode = "AP063";
						status = EEMConstants.APPL_STATUS_ELGWARNING;
					}	
				}
				
				// IFOX-00380650: Code Fix -- Start
				/* 
				IFOX-00380045 MBD part A/B mismatch check retrofit from Base --START
				if(errorCode.equals("")){
					if(!(prtAStDt != null && prtAStDt.equals(mbd.getPrtAEntitleDate())  &&  prtAStDt != "") || 
							!(prtBStDt != null && prtBStDt.equals(mbd.getPrtBEntitleDate()) && prtBStDt != "" )){
						errorCode = "AP063";
						status = EEMConstants.APPL_STATUS_ELGCRITICL;
					}
				}
				IFOX-00380045 MBD part A/B mismatch check retrofit from Base --END
				*/
				// IFOX-00380650: Code Fix -- End
			}

			if (!errorCode.equals("")) {
				EEMFieldErrorVO field = getField("mbrHicNbr", lstFields);
				objError = getErrorVO(field, objVO, errorCode, status);
				//objError.setValue(objVO.getMbrHicNbr());
			}
		} catch (Exception e) {
			//e.printStackTrace();
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			objVO.setMessage("Error Validating Eligibility.");
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objError;
	}
	
	public static String getMBDGender(String code) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		if (code != null ) {
			if (code.equals("M")) {
				logger.info(LoggerConstants.methodEndLevel());
				return "1";
			} else if (code.equals("F")) {
				logger.info(LoggerConstants.methodEndLevel());
				return "2";
			}
		} else {
			code = "";
		}
		logger.info(LoggerConstants.methodEndLevel());
		return code;
	}
	
	public static String getApplGender(String code) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		if (code != null ) {
			if (code.equals("1")) {
				logger.info(LoggerConstants.methodEndLevel());
				return "M";
			} else if (code.equals("2")) {
				logger.info(LoggerConstants.methodEndLevel());
				return "F";
			}
		} else {
			code = "";
		}
		logger.info(LoggerConstants.methodEndLevel());
		return code;		
	}
	
	private EEMFieldErrorVO getField(String fieldName, List lstFields) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
	
		EEMFieldErrorVO field = null;
		boolean found = false;
		for (int i = 0; i < lstFields.size(); i++) {
			field = (EEMFieldErrorVO)lstFields.get(i);
			if (fieldName.equals(field.getFormField())) {
				found = true;
				break;
			}
		}
		
		if (!found) {
			field = null;
		}
		logger.info(LoggerConstants.methodEndLevel());
		return field;
	}
	//SSNRI 2017 Changes : start
	public MBD verifyEligibility(Connection conn, String hicNbr,
			String lastName, String birthDt, String eemDb, String custNbr,
			String beqCheck,String isHicOrMbi) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
	//SSNRI 2017 Changes : end
		MBDPersistence mp = new MBDPersistence();
		MBD mbd = null;
		try {
			if (!StringUtil.nonNullTrim(birthDt).equals("")) {
				birthDt = new DateFormatter().reFormatDate(birthDt, 
												DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
			}
			//SSNRI 2017 Changes : start
			mbd = mp.getHicMatch(conn, hicNbr, lastName, birthDt,
					mp.checkDemoAccount(custNbr), eemDb, custNbr, beqCheck,isHicOrMbi);
			//SSNRI 2017 Changes : end

		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mbd;
	}
	// IFOX-00382607: Retro Application CR - Start
	public boolean checkRetroApplication(Connection conn,
			EEMApplicationVO objVO, List lstFields) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		boolean retro = false;
		try {
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			
			EEMApplicationVO memberVO = new EEMApplicationVO();
			memberVO.setCustomerId(objVO.getCustomerId());
			memberVO.setMbrHicNbr(objVO.getMbrHicNbr());
			memberVO.setReqDtCov(objVO.getReqDtCov());
			//SSNRI 2017 Changes : start
			memberVO.setDisplayHic(objVO.getDisplayHic());
			memberVO.setMbiNbr(objVO.getMbiNbr());
			//SSNRI 2017 Changes : end
			/* Check for plan later */
			String plan = StringUtil.nonNullTrim(objVO.getEnrollPlanDesgn());
			if (eemDao.getMemberDetails(conn, memberVO, "")) {
				// Check for Retro application
				if (!StringUtil.nonNullTrim(memberVO.getEnrollEndDate()).equals(EEMConstants.EFF_END_DATE)) {
					if(objVO.getEnrollPlan() != null && objVO.getEnrollPlan().equalsIgnoreCase(memberVO.getCurrPlan()) && objVO.getEnrollPbp() != null && objVO.getEnrollPbp().equalsIgnoreCase(memberVO.getCurrPbp()))
						retro = true;
				}
			}
			
		} catch (Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			objVO.setMessage("Error during Retro Application check.");
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return retro;
	}
	// IFOX-00382607: Retro Application CR - End
	/* Deprecated */
	private boolean checkOldDuplicate(Connection conn, EEMApplDao eemDao,
			EEMApplicationVO objVO, List lstOrgPlan)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		boolean error = false;
		
		String[] currPlan = eemDao.getPlanType(conn, objVO);
		if (currPlan != null) {
			String currPlanDesgn = currPlan[1];
			String currPlanType = currPlan[0];
			
			for (int i = 0; i < lstOrgPlan.size(); i++) {
				String[] orgPlan = (String[])lstOrgPlan.get(i);
				
				if (orgPlan != null) {
					String orgPlanDesgn = StringUtil.nonNullTrim(orgPlan[1]);
					String orgPlanType = StringUtil.nonNullTrim(orgPlan[0]);
					
					if (orgPlanDesgn.equals(EEMConstants.PLAN_DESGN_PDP)) {
						if (currPlanDesgn.equals(EEMConstants.PLAN_DESGN_PDP)) {
							error = true;
						}
						else
						if (currPlanDesgn.equals(EEMConstants.PLAN_DESGN_MAPD)) {
							error = true;
						} 
						else 
						if (currPlanDesgn.equals(EEMConstants.PLAN_DESGN_MA) &&
								!currPlanType.equals(EEMConstants.PLAN_TYPE_PFFS)) {
							error = true;
						}
						
					} else if (orgPlanDesgn.equals(EEMConstants.PLAN_DESGN_MAPD)) {
						error = true;
						
					} else if (orgPlanDesgn.equals(EEMConstants.PLAN_DESGN_MA)) {
						if (orgPlanType.equals(EEMConstants.PLAN_TYPE_PFFS) &&
								!currPlanDesgn.equals(EEMConstants.PLAN_DESGN_PDP)) {
							error = true;
						}
						else
						if (!orgPlanType.equals(EEMConstants.PLAN_TYPE_PFFS) &&
								currPlanDesgn.equals(EEMConstants.PLAN_DESGN_PDP)) {
							error = true;
						}
						
					} else if (orgPlanDesgn.equals(EEMConstants.PLAN_TYPE_COST)) {
						if (!currPlanDesgn.equals(EEMConstants.PLAN_DESGN_PDP))
							error = true;
					}
				}
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return error;
	}
	
	private boolean checkDuplicate(Connection conn, EEMApplDao eemDao,
			EEMApplicationVO objVO, List lstOrgPlan)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		boolean error = true;
		
		String[] currPlan = objVO.getCurrentPlan();
		if (currPlan != null) {
			String currPlanDesgn = currPlan[1];
			String currPlanType = currPlan[0];
			
			if (lstOrgPlan.size() == 0)
				error = false;
			
			for (int i = 0; i < lstOrgPlan.size(); i++) {
				String[] orgPlan = (String[])lstOrgPlan.get(i);
				
				if (orgPlan != null) {
					String orgPlanDesgn = StringUtil.nonNullTrim(orgPlan[1]);
					String orgPlanType = StringUtil.nonNullTrim(orgPlan[0]);
					
					if (orgPlanDesgn.equals(EEMConstants.PLAN_DESGN_PDP)) {
						if (currPlanDesgn.equals(EEMConstants.PLAN_DESGN_MA) &&
								currPlanType.equals(EEMConstants.PLAN_TYPE_PFFS)) {
							error = false;
						}
						
					} else if (orgPlanDesgn.equals(EEMConstants.PLAN_DESGN_MA) && 
									orgPlanType.equals(EEMConstants.PLAN_TYPE_PFFS)) {
						if (currPlanDesgn.equals(EEMConstants.PLAN_DESGN_PDP)) {
							error = false;
						}
						
					} else if (orgPlanDesgn.equals(EEMConstants.PLAN_TYPE_COST)) { // To be validated for future 
						if (currPlanDesgn.equals(EEMConstants.PLAN_DESGN_PDP))
							error = false;
					}
				}
			}
			
			// check for plan and pbp - Commented for IFOX-00370049 - Start
		//	if (error && (objVO.getApplType().equals(EEMConstants.OPTION_CNTRCHG_MA) ||
		//					objVO.getApplType().equals(EEMConstants.OPTION_CNTRCHG_PD))) {
			/*	if (!objVO.getCurrPlan().equals(objVO.getEnrollPlan()) ||
						!objVO.getCurrPbp().equals(objVO.getEnrollPbp()))
						error = false;
				*/	
			
			// Fix for IFOX-00377758 -- Start
			
			//Added null check for SSNRI DUPLAPPL defect fix : Start	
			if(!StringUtil.nonNullTrim(objVO.getCurrPlan()).equals("") && !StringUtil.nonNullTrim(objVO.getCurrPbp()).equals("")){
				if ((!StringUtil.nonNullTrim(objVO.getCurrPlan()).equals(objVO.getEnrollPlan()) ||  !StringUtil.nonNullTrim(objVO.getCurrPbp()).equals(objVO.getEnrollPbp()))  )
					error = false;
			}
			//Added null check for SSNRI DUPLAPPL defect fix : End 

			if (error
					&& (objVO.getApplType()
							.equals(EEMConstants.OPTION_CNTRCHG_PD))) {
				if (!objVO.getCurrPlan().equals(objVO.getEnrollPlan())
						|| !objVO.getCurrPbp().equals(objVO.getEnrollPbp()))
					error = false;
			}
			
				/*if ((!StringUtil.nonNullTrim(objVO.getCurrPlan()).equals(objVO.getEnrollPlan()) ||  !StringUtil.nonNullTrim(objVO.getCurrPbp()).equals(objVO.getEnrollPbp()))  )
					error = false;*/
			
			// Fix for IFOX-00377758 -- Start
		//	}  - Commented for IFOX-00370049 - End
		}
		logger.info(LoggerConstants.methodEndLevel());
		return error;
	}

	public EEMErrorVO checkDuplcateApplication(Connection conn,
			EEMApplicationVO objVO, List lstFields) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMErrorVO objError = null;
		try {
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			
			List lstOrgPlan = eemDao.checkDuplicateApplication(conn, objVO);
			if (!"Y".equalsIgnoreCase(objVO.getAppDuplicateCheck())) {
				if (lstOrgPlan.size() > 0 && checkDuplicate(conn, eemDao, objVO, lstOrgPlan)) {
					EEMFieldErrorVO field = getField("mbrHicNbr", lstFields);
					objError = getErrorVO(field, objVO, "AP057", EEMConstants.APPL_STATUS_DUPLAPPL);
					//objError.setValue(objVO.getMbrHicNbr());
				}	
			}
			
			else {
				if (lstOrgPlan.size() > 0
						&& objVO.getApplType().equals(
								EEMConstants.OPTION_CNTRCHG_MA)) {
					int orgPlanSize = lstOrgPlan.size();
					String errorCode = "";
					boolean error = false;
					for (int i = 0; i < orgPlanSize; i++) {
						String[] orgPlan = (String[]) lstOrgPlan.get(i);
						String startDate = orgPlan[2];
						if (orgPlan[3] != null
								&& objVO.getEnrollPlan().equalsIgnoreCase(
										orgPlan[3])
								&& orgPlan[4] != null
								&& objVO.getEnrollPbp().equalsIgnoreCase(
										orgPlan[4])) {
							// errorCode = "AP193";
							errorCode = "AP057";
							error = true;
						}
					}

					if (error) {
						EEMFieldErrorVO field = getField("mbrHicNbr", lstFields);
						objError = getErrorVO(field, objVO, errorCode,
								EEMConstants.APPL_STATUS_DUPLAPPL);
					}
				}
			}
			
		} catch (Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			objVO.setMessage("Error during Duplicate Application check.");
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objError;
	}

	// IFOX-00382607: Retro Application CR - Start
	public EEMErrorVO checkRetroAppl(Connection conn,
			EEMApplicationVO objVO, List lstFields) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMErrorVO objError = null;
		try {

			if (this.checkRetroApplication(conn, objVO, lstFields)) {
					EEMFieldErrorVO field = getField("reqDtCov", lstFields);
					objError = getErrorVO(field, objVO, "AP191", EEMConstants.APPL_STATUS_RETROENRLR);		
					objError.setValue(objVO.getReqDtCov());
			}	
			
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
			objVO.setMessage("Error during Duplicate Application check.");
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objError;
	}
	// IFOX-00382607: Retro Application CR - End
	public EEMErrorVO checkDupilcateEnrollment(Connection conn,
			EEMApplicationVO objVO, List lstFields) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMErrorVO objError = null;
		try {
			
			// Duplicate Enrollment Issue Fix : Start
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();

			List lstOrgPlan = eemDao.checkDuplicateEnrollment(conn, objVO);
			/*if (lstOrgPlan.size() > 0) {
					String errorCode = "AP061";*/
			boolean error = false;
			String errorCode = "";
			if (lstOrgPlan.size() > 0) {
				String[] orgPlan = (String[]) lstOrgPlan.get(0);
				
				if(null != orgPlan && orgPlan.length > 4) { //Added to avoid ArrayIndexOutOfBoundsException
					String planId = orgPlan[3];
					String pbpId = orgPlan[4];
					//CR-IFOX-00408061. START
					String productId = orgPlan[5];
					String grpId = orgPlan[6];
					String pbpSegmentId = orgPlan[7];
					/*if (planId.equalsIgnoreCase(objVO.getEnrollPlan())
							&& pbpId.equalsIgnoreCase(objVO.getEnrollPbp())) {
						 errorCode = "AP061";
						 error = checkDuplicate(conn, eemDao, objVO, lstOrgPlan);
					}*/
					if (planId.equalsIgnoreCase(objVO.getEnrollPlan())
							&& pbpId.equalsIgnoreCase(objVO.getEnrollPbp())
								&& productId.equalsIgnoreCase(objVO.getEnrollProduct())
									&& grpId.equalsIgnoreCase(objVO.getEnrollGroup())
											&& pbpSegmentId.equalsIgnoreCase(objVO.getEnrollSegment())) {
						 errorCode = "AP061";
						 error = checkDuplicate(conn, eemDao, objVO, lstOrgPlan);
					}
					//CR-IFOX-00408061. END
					String reqDtCov = DateFormatter.reFormat(objVO.getReqDtCov(),
							DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
					//String[] orgPlan = (String[])lstOrgPlan.get(0);
					String startDate = orgPlan[2];
					if (error && DateMath.isLessThan(reqDtCov, startDate))
						errorCode = "AP193";
				}	
			}
			if (error) {
				EEMFieldErrorVO field = getField("mbrHicNbr", lstFields);
				objError = getErrorVO(field, objVO, errorCode, EEMConstants.APPL_STATUS_DUPLENRL);
				//objError.setValue(objVO.getMbrHicNbr());
			}
			// Duplicate Enrollment Issue Fix : End
		}
			
		 catch (Exception e) {
			 logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
			objVO.setMessage("Error during Duplicate Enrollment check.");
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objError;
	}
	//CR-IFOX-00408061. START Functionality not Approved
	/**
	 * Method to validate the input Product ID is Dental product or not.
	 * @param productId
	 * @return
	 */
	/*private boolean isDentalProduct(String productId) {
		if(StringUtil.isNotNullNotEmptyNotWhiteSpace(productId)){
			String productLastChar = ""+productId.charAt(productId.length()-1)+"";
			return productLastChar.equalsIgnoreCase(EEMConstants.DENTAL_PRODUCT_SUFIX);
		}
		return false;
	}*/
	//CR-IFOX-00408061. END
	
	public EEMErrorVO checkEnrollProduct(Connection conn, String eemDb, EEMApplicationVO objVO,
			List lstFields) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMErrorVO objError = null;
		EEMFieldErrorVO field = getField("enrollProduct", lstFields);
		if (field == null || !validateEditRule(conn, eemDb, objVO.getEnrollProdName(), field, objVO)) {
			logger.info(LoggerConstants.methodEndLevel());
			return objError;
		}
		try {
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			boolean error = false;
			String errorCode = "";
			String status = EEMConstants.APPL_STATUS_ERRORCRITL;
			
			// Check for valid plan, pbp and segment
			List prodListInGrp = eemDao.getProdInGroup(conn, objVO);
			if (prodListInGrp == null || prodListInGrp.size() == 0) {
				error = true;
				errorCode = "AP033";
			}/**IFOX-00421470: Updating Enrollment Premium Amount. START*/
			else {
				List prodList = eemDao.getProducts(conn, objVO);
				if (prodList != null && prodList.size() == 0) {
					error = true;
					errorCode = "AP032";
				} else {
					String enrollPymtAmt = calculateEnrollmentAmt((EEMApplProductsVO)prodList.get(0));
					objVO.setEnrollPymtAmt(enrollPymtAmt);
				}
			}
			/**IFOX-00421470: Updating Enrollment Premium Amount. END*/
				/*else if (!StringUtil.nonNullTrim(objVO.getOutOfArea()).equals("E")) {
			}
				for (int i = 0; i < lstProd.size(); i++) {
					EEMApplProductsVO prodVO = (EEMApplProductsVO)lstProd.get(i);
					// Validate product Id in Service Area
					String svcAreaId = eemDao.getProdInSvcArea(conn, prodVO, objVO.getReqDtCov());
					if (svcAreaId.equals("")) {
						error = true;
						errorCode = "AP032";
						break;
					} else if (!eemDao.getProdInSvcAreaZip(conn, objVO, svcAreaId)){ // Validate Zip code
						// County based 
						if (!eemDao.getProdInCountyZip(conn, objVO, svcAreaId, true)) {
							// State based 
							if (!eemDao.getProdInCountyZip(conn, objVO, svcAreaId, false)) {
								error = true;
								errorCode = "AP032";
								break;
							}
						}
					} 
					
					// NMA or NPD record type
					if (objVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_MA) || 
							objVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_PD)) {
						
						// Validate for continue area indicator
						if (!eemDao.getProdInContArea(conn, objVO, svcAreaId, "N")) {
							if (eemDao.getProdInContArea(conn, objVO, svcAreaId, "Y")) {
								error = true;
								errorCode = "AP027";
								break;
							} else {// unable to determine product service area
								error = true;
								errorCode = "AP183";
								break;
							}
						}
					}
					
				}
			}*/
			if (error) {
				objError = getErrorVO(field, objVO, errorCode, status);
				objError.setValue(objVO.getEnrollProdName());
			}
			
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Error Details: "+e.getMessage());
			objVO.setMessage("Error during Enrolled Product check.");
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objError;
	}
	/** IFOX-00421470
	 *  Calculate Enrollment Premium Amt Update. START**/
	private String calculateEnrollmentAmt(EEMApplProductsVO productVO) {
		double pymtAmt = 0;
		if (!"Y".equals(productVO.getSnpInd())) {
			String prtCAmt = StringUtil.nonNullTrim(productVO.getPrtCPremiumAmt());
			String prtDAmt = StringUtil.nonNullTrim(productVO.getPrtDPremiumAmt());
			String supplAmt = StringUtil.nonNullTrim(productVO.getSupplPremiumAmt());
			String premReducAmt = StringUtil.nonNullTrim(productVO.getPremiumReductionAmt());
			String dsrRebateAmt = StringUtil.nonNullTrim(productVO.getDsrRebateAmt());
	
			pymtAmt = Double.parseDouble(prtCAmt) + Double.parseDouble(prtDAmt) + Double.parseDouble(supplAmt)  
			         - Double.parseDouble(premReducAmt) - Double.parseDouble(dsrRebateAmt);
		}
		return NumberFormatter.formatDecimal2Places(pymtAmt);
	}
	/** IFOX-00421470. END**/
	
	public EEMErrorVO checkReqDtCov(Connection conn, String eemDb, EEMApplicationVO objVO,
			List lstFields) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMErrorVO objError = null;
		String reqDtCov = StringUtil.nonNullTrim(objVO.getReqDtCov());
		String customerId=objVO.getCustomerId();
		EEMFieldErrorVO field = getField("reqDtCov", lstFields);
		//CMS FEB 2016 Release - Start			
				MBD mbd = objVO.getMbd();
				int unLawPrsCnt = 0;
				int incarcerationCnt = 0;
				unLawPrsCnt = mbd.getUnLawfulPresCnt();
				incarcerationCnt = mbd.getIncarcerationCnt();
				String eghpId="";
		//CMS FEB 2016 Release - End
		if (reqDtCov.equals("") || field == null || 
				!validateEditRule(conn, eemDb, objVO.getReqDtCov(), field, objVO)) {
			logger.info(LoggerConstants.methodEndLevel());
			return objError;
		}
		try {
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			boolean error = false;
			String errorCode = "AP030";
			String status = EEMConstants.APPL_STATUS_ERRORCRITL;
			EEMApplProductsVO prodVO=null;
			// Requested Date of Coverage
			reqDtCov = DateUtil.changedDateFormatForMonth(reqDtCov);
			/*  CustomerId added for SummaCare  -Start */ 
			String ccmDate = getCCMDate(conn, customerId);
			/*  CustomerId added for SummaCare  -end */ 
			// Application Date
			String applDate = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getApplDate()));
			
			
			/* IFOX-00374947 / IFOX-00378975 to process Employer group applications with EGHP_ID=Y---Start*/
			
			List lstProd = eemDao.getProducts(conn, objVO);
			if (lstProd != null && lstProd.size() > 0) {
				 prodVO = (EEMApplProductsVO) lstProd.get(0);
				 eghpId=prodVO.getEghpInd();
				 if (objVO.getElectionType().equals("W")){
				 if(!eghpId.equals("") && eghpId.equals("Y")){
					applDate=DateMath.getFirstOfPreviousMonth(DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getReqDtCov())));
					}
				 }
			}
			
			else { // No product details	
				error = true;
				errorCode = "AP153";
			}
			
			/* IFOX-00374947 / IFOX-00378975 to process Employer group applications with EGHP_ID=Y---End*/
			/*IFOX-00403369-start*/
			/*if (DateMath.isLessThan(reqDtCov, applDate)) {*/
				if (DateMath.isLessThanorEqual(reqDtCov, applDate)) {
			/*IFOX-00403369-end*/
				error = true;
				errorCode = "AP203";
				
			} else if (checkRetroApplication(conn, objVO, lstFields)) { // Retro Application
				error = true;
				errorCode = "AP191";
				
			} else if (!DateMath.isFDOM(reqDtCov)) { // First day of month
				error = true;
				
			} else if (DateMath.monthsBetween(ccmDate, reqDtCov) > 3 ||
					DateMath.monthsBetween(ccmDate, reqDtCov) < -3) {// More than 3 months
				error = true;
				
			} else {
				
				/* IFOX-00374947 / IFOX-00378975 to process Employer group applications with EGHP_ID=Y---Start*/
				// Get Product details
				/*List lstProd = eemDao.getProducts(conn, objVO);
				if (lstProd != null && lstProd.size() > 0) {
					EEMApplProductsVO prodVO = (EEMApplProductsVO) lstProd.get(0);
					*/
					// Check for EGHP indicator
				if (!eghpId.equals("") && StringUtil.nonNullTrim(eghpId).equals("N")
							&& DateMath.monthsBetween(ccmDate, reqDtCov) < -1) {
						error = true;
					} else if (!eghpId.equals("") && StringUtil.nonNullTrim(eghpId).equals("Y")
							&& DateMath.monthsBetween(ccmDate, reqDtCov) < -3) {
						error = true;
					}
			} 
			//}
			/* IFOX-00374947 / IFOX-00378975 to process Employer group applications with EGHP_ID=Y---End*/
			
			//CMS FEB 2016 Release - Start
			if(unLawPrsCnt > 0){
				EEMApplDao eemApplDao = DaoFactory.getInstance().getEEMApplDao();
				boolean unLawPrsCntFlag = false;
				logger.debug("EEMApplService.checkReqDtCov()::srs****"+mbd.getEligibilitySrcTable());
				 //Modified for SSNRI 2017 : start
				/*unLawPrsCntFlag = eemApplDao.isUnlawfullyEligible(conn, reqDtCov, objVO.getMbrHicNbr());*/
				unLawPrsCntFlag = eemApplDao.isUnlawfullyEligible(conn, reqDtCov, objVO.getMbrHicNbr(),objVO.getMbiNbr());
				 //Modified for SSNRI 2017 : end
				
				if(unLawPrsCntFlag){
					error = true;
				 	errorCode = "AP337";
				}
			}
			if(incarcerationCnt > 0){
				logger.debug("EEMApplService.checkReqDtCov()::srs****"+mbd.getEligibilitySrcTable());
				EEMApplDao eemApplDao = DaoFactory.getInstance().getEEMApplDao();
				boolean incarcerationCntFlag = false;
				 //Modified for SSNRI 2017 : start
				//incarcerationCntFlag = eemApplDao.isIncarcerated(conn, reqDtCov, objVO.getMbrHicNbr());
				incarcerationCntFlag = eemApplDao.isIncarcerated(conn, reqDtCov, objVO.getMbrHicNbr(),objVO.getMbiNbr());
				 //Modified for SSNRI 2017 : end
				if(incarcerationCntFlag){
					error = true;
				 	errorCode = "AP338";
				}
			}
			//CMS FEB 2016 Release - End	
			if (error) {
				//CMS FEB 2016 Release - Start
				/*if(errorCode.equalsIgnoreCase("AP153")){
					status = EEMConstants.APPL_STATUS_PLANERROR;
				}else if(errorCode.equalsIgnoreCase("AP203") || errorCode.equalsIgnoreCase("AP191") ||
					//CMS FEB 2016 Release - Start
					errorCode.equalsIgnoreCase("AP240") || errorCode.equalsIgnoreCase("AP304") || errorCode.equalsIgnoreCase("AP305")){
					//CMS FEB 2016 Release - End	
					status = EEMConstants.APPL_STATUS_ERRORCRITL;
				} else*/ 
				if(errorCode.equalsIgnoreCase("AP337") || errorCode.equalsIgnoreCase("AP338")){
					status = EEMConstants.APPL_STATUS_ELGWARNING;
				} 
				//CMS FEB 2016 Release - End	
				objError = getErrorVO(field, objVO, errorCode, status);
				objError.setValue(objVO.getReqDtCov());
			}
			
		} catch (Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			objVO.setMessage("Error during Requested Date of Coverage check.");
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objError;
	}

	public EEMErrorVO checkSupplId(Connection conn, String eemDb, EEMApplicationVO objVO,
			List lstFields) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMErrorVO objError = null;
		EEMFieldErrorVO field = getField("altMbrId", lstFields);
		
		try {
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			String supplInd = EEMProfileSettings.getCalendarProfileItem(
									eemDb, objVO.getCustomerId(), EEMProfileSettings.SUPPLID);
			
			if (supplInd != null) {
				String supplId = StringUtil.nonNullTrim(objVO.getAltMbrId());
				if (supplInd.equals(EEMProfileSettings.SUPPLID_CUST_SUPPLIED)) {
					if (supplId.equals("")) {
						objError = getErrorVO(field, objVO, "AP146", EEMConstants.APPL_STATUS_ERRORCRITL);
						objError.setValue(objVO.getAltMbrId());
						logger.info(LoggerConstants.methodEndLevel());
						return objError;
					}
				}
			}
			
		} catch (Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			objVO.setMessage("Error during Supplemental Id check.");
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objError;
	}
	
	public EEMErrorVO checkDuplSupplId(Connection conn, String eemDb, EEMApplicationVO objVO,
			List lstFields) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMErrorVO objError = null;
		String supplId = StringUtil.nonNullTrim(objVO.getAltMbrId());
		EEMFieldErrorVO field = getField("altMbrId", lstFields);
		if (supplId.equals("") || field == null || 
				!validateEditRule(conn, eemDb, objVO.getAltMbrId(), field, objVO)) {
			logger.info(LoggerConstants.methodEndLevel());
			return objError;
		}
		try {
			EEMEnrollDao eemDao = new EEMEnrollDao();
			if (eemDao.checkDuplSupplId(conn, objVO.getCustomerId(), objVO.getAltMbrId(), objVO.getMbrId())) {
				if (StringUtil.nonNullTrim(objVO.getMbrId()).equals(""))
					objError = getErrorVO(field, objVO, "AP202", EEMConstants.APPL_STATUS_ELGWARNING);
				else 
					objError = getErrorVO(field, objVO, "AP202", EEMConstants.APPL_STATUS_ERRORCRITL);
				objError.setValue(objVO.getAltMbrId());
			}
			
		} catch (Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			objVO.setMessage("Error during Duplicate Supplemental Id check.");
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objError;
	}

	public EEMErrorVO checkRxId(Connection conn, String eemDb, EEMApplicationVO objVO,
			List lstFields) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMErrorVO objError = null;
		EEMFieldErrorVO field = getField("mbrRxId", lstFields);
		if (field == null) {
			logger.info(LoggerConstants.methodEndLevel());
			return objError;
		}
		try {
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			boolean error = false;
			String errorCode = "";
			String status = "";
			
			// Check for MA plan and value should be blank
			String planDesgn = StringUtil.nonNullTrim(objVO.getEnrollPlanDesgn());
			if (planDesgn.equals("MA") && !StringUtil.nonNullTrim(objVO.getMbrRxId()).equals("")) {
				error = true;
				errorCode = "AP184";
			} else if (!validateRxId(objVO)) {
				return objError;
			} else {
				// Get Profile value for RxId parameter
				String reqDtCov = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getReqDtCov()));
				if (reqDtCov.equals("")) {
					return null;
				}
				String rxIdInd = EEMProfileSettings.getCalendarProfileItem(eemDb, objVO.getCustomerId(), 
																		   EEMProfileSettings.RXID);
				//00414932 start
				String supplIdInd = EEMProfileSettings.getCalendarProfileItem(eemDb, objVO.getCustomerId(), 
						   EEMProfileSettings.SUPPLID);
				//00414932 end
				String rxId = StringUtil.nonNullTrim(objVO.getMbrRxId());
				String supplId = StringUtil.nonNullTrim(objVO.getAltMbrId());
				
				if (rxIdInd.equals(EEMProfileSettings.RXID_CUST_SUPPLIED)) {// Customer supplied
					if (rxId.equals("")) {
						error = true;
						errorCode = "AP034";
						status = EEMConstants.APPL_STATUS_ERRORCRITL;
					}
				} else if (rxIdInd.equals(EEMProfileSettings.RXID_DERIVED)) {// Derived
					if (!rxId.equals("")) {
						error = true;
						errorCode = "AP036";
					}
					//00414932 start
				//} else if (rxIdInd.equals(EEMProfileSettings.RXID_USE_SUPPLID)) {// Use Supplimental Id
				} else if (rxIdInd.equals(EEMProfileSettings.RXID_USE_SUPPLID) && !supplIdInd.equals(EEMProfileSettings.SUPPLID_GENERATED)) {// Use Supplimental Id
					//00414932 end
					if (!rxId.equals("") && supplId.equals("")) {
						error = true;
						errorCode = "AP036";
					}
					//SSNRI defect IFOX-00397367 
					if(!supplId.equals("")){
					objVO.setMbrRxId(supplId);
					}
				}
			}
			
			if (error) {
				objError = getErrorVO(field, objVO, errorCode, status);
				objError.setValue(objVO.getMbrRxId());
			}
			
		} catch (Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			objVO.setMessage("Error during RxID check.");
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objError;
	}

	/*public EEMErrorVO checkElectionType(Connection conn, String eemDb, EEMApplicationVO objVO,
			List lstFields) throws ApplicationException {
		EEMErrorVO objError = null;
		EEMFieldErrorVO field = getField("electionType", lstFields);
		if (field == null) {
			return objError;
		}
		try {
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			String status = "";
			String errorCode = "";
			String errorValue = "";
			MBD mbd = objVO.getMbd();
			int year = Calendar.getInstance().get(Calendar.YEAR);
			String jan1AEP = Integer.toString(year+1) + "0101";
			if (mbd != null && !StringUtil.nonNullTrim(mbd.getHicNbr()).equals("")) {
				*//**
				 * Cambia_Election Logic---Start
				 *//*

					errorCode = attestationValidate(conn,objVO);
				
				*//**
				 * Cambia_Election Logic---End
				 *//*
			
					String reqDtCov = DateFormatter.reFormat(StringUtil.nonNullTrim(objVO.getReqDtCov()), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
						if(objVO.getElectionType() != null && !objVO.getElectionType().equals("")){
							if (objVO.getElectionType().equalsIgnoreCase(EEMConstants.ELECTION_TYPE_AEP)) {
								if (!reqDtCov.equalsIgnoreCase(jan1AEP)) {
									errorCode = "AP192";
								}
							}
							else if (objVO.getElectionType().equalsIgnoreCase(EEMConstants.ELECTION_TYPE_MADP)) {
								if (!StringUtil.nonNullTrim(objVO.getEnrollPlanDesgn()).equalsIgnoreCase(EEMConstants.PLAN_DESGN_PDP)) {
									errorCode = "AP047";
								}
							}
							else if (objVO.getElectionType().equalsIgnoreCase(EEMConstants.ELECTION_TYPE_OEPI)) { 
								 if (StringUtil.nonNullTrim(objVO.getLongTerm()).equals("")) {
									errorCode = "AP053";
								}
							}
						}
					
					
					if(errorCode != null && !errorCode.equalsIgnoreCase("")){	
						if(errorCode.equalsIgnoreCase("AP052") || errorCode.equalsIgnoreCase("AP087")){	
							status = EEMConstants.APPL_STATUS_INCRFIELCT;
						}
						else if(errorCode.equalsIgnoreCase("AP047") || errorCode.equalsIgnoreCase("AP192")){
							status = EEMConstants.APPL_STATUS_ERRORCRITL;
						}
						else if(errorCode.equalsIgnoreCase("AP053")){
							status = EEMConstants.APPL_STATUS_READYAPPR;
						}
					}
				
					errorValue = objVO.getElectionType();
			}
			else if(StringUtil.nonNullTrim(mbd.getHicNbr()).equals("") &&
					objVO.getSepException().length > 0 &&
					!(objVO.getSepException()[0].equals(""))){
				
				errorCode = "AP052";
				errorValue = objVO.getElectionType();
			}
			if (!StringUtil.nonNullTrim(errorCode).equals("")) {
				objError = getErrorVO(field, objVO, errorCode, status);
				objError.setValue(errorValue);
			}
			
		} catch (Exception e) {
			e.printStackTrace(log.getStream());
			objVO.setMessage("Error during Election Type check.");
			throw new ApplicationException(e);
		}
		return objError;
	}
*/
	
	public EEMErrorVO checkElectionType(Connection conn, String eemDb, EEMApplicationVO objVO,
			List lstFields) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMErrorVO objError = null;
		EEMFieldErrorVO field = getField("electionType", lstFields);
		if (field == null) {
			logger.info(LoggerConstants.methodEndLevel());
			return objError;
		}
		try {
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			EEMEnrollDao enrollDao = DaoFactory.getInstance().getEEMEnrollDao();
			/** Triple S BasePlus Migration START **/
			//CMS Feb Release 2017 - New Seamless Election Type  : Start
			boolean seamlessInd = false;
			seamlessInd = eemDao.getSeamlessIndicator(conn, objVO);
			//CMS Feb Release 2017 - New Seamless Election Type  : End
			/** Triple S BasePlus Migration END **/
			String status = "";
			String errorCode = "";
			String errorValue = "";
			String planDesg = "";
			MBD mbd = objVO.getMbd();
			EEMElectionVO electionVO = new EEMElectionVO();
			String planID = StringUtil.nonNullTrim(mbd.getPlanId());
			String coPlanID = StringUtil.nonNullTrim(mbd.getCoPlanId());
			String	planEnrolLDt= StringUtil.nonNullTrim(mbd.getPlanEnrollDate());
			//IFOX-00382850: Election Type blank error changes - Start
			//if (mbd != null && !StringUtil.nonNullTrim(mbd.getHicNbr()).equals("")) {
			//IFOX-00382850: Election Type blank error changes - End	
				electionVO.setCustomerId(StringUtil.nonNullTrim(objVO.getCustomerId()));
				electionVO.setElectionType(StringUtil.nonNullTrim(objVO.getElectionType()));
				electionVO.setPlanDesgn(StringUtil.nonNullTrim(objVO.getEnrollPlanDesgn()));
				electionVO.setBirthDt(DateFormatter.reFormat(objVO.getMbrBirthDt(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
				electionVO.setApplicationDt(DateFormatter.reFormat(objVO.getApplDate(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
				electionVO.setReqDtCov(DateFormatter.reFormat(objVO.getReqDtCov(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
				electionVO.setLongTermFacId(StringUtil.nonNullTrim(objVO.getNameInstitute()));
				electionVO.setPartAEntlDt(DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getPartAEffDt())));
				electionVO.setPartBEntlDt(DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getPartBEffDt())));
				electionVO.setPartDElgDt(DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getPartDEffDt())));
				electionVO.setElcDerivedInd(objVO.getElcDerivedInd());
				electionVO.setApplType(StringUtil.nonNullTrim(objVO.getApplType())); //IFOX00397076
				/**CMS 2019 January Release- Requirement-2b: MA OEP - M. START**/
				electionVO.setMemberId(enrollDao.getEnrollMemberId(conn, objVO.getCustomerId(), objVO.getDisplayHic(), objVO.getMbiNbr()));
				electionVO.setMemberPresentInM360(StringUtil.isNullOrEmptyOrSpace(electionVO.getMemberId()) ? false : true);
				/**CMS 2019 January Release- Requirement-2b: MA OEP - M. END**/
				/**CMS 2019 January Release- Requirement-3 : DUAL/LIS SEP � L and U. START**/
				electionVO.setCaraHistoryDetails(getCaraHistory(conn,objVO));
				this.populateEEMElectionVO(objVO, electionVO);
				/**CMS 2019 January Release- Requirement-3 : DUAL/LIS SEP � L and U. END**/
				
				//CMS Changes 2019-MA OEP Additional Check :00411704 :start
				
				/* CMS Change for DEC-2019 release-Start-00423084 */
                /*424553- start*/
				
				
				if (StringUtil.isNotNullNotEmptyNotWhiteSpace(electionVO.getMemberId())) {
					planDesg = enrollDao.getPlanDesgination(conn, objVO.getCustomerId(), electionVO.getMemberId());// Enrollment
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(planDesg) && planDesg.equalsIgnoreCase("PDP"))
						electionVO.setPlanPDP(true);
				}
				
				if ((StringUtil.isNotNullNotEmptyNotWhiteSpace(planID) && StringUtil.isNotNullNotEmptyNotWhiteSpace(coPlanID))
						&& planID.toUpperCase().startsWith("S") && coPlanID.toUpperCase().startsWith("S")) 
					electionVO.setPlanPDP(true);
				else if ((StringUtil.isNotNullNotEmptyNotWhiteSpace(planID) && StringUtil.isNullOrEmpty(coPlanID)) && planID.toUpperCase().startsWith("S"))
					electionVO.setPlanPDP(true);
				else if (StringUtil.isNullOrEmpty(planID) && (StringUtil.isNullOrEmptyOrSpace(planEnrolLDt) || planEnrolLDt.equals("00000000")))
					electionVO.setPlanBlank(true);
				/*424553- end*/
				
				
				/*planID = StringUtil.nonNullTrim(mbd.getPlanId());
				if(planID.equals(""))
				electionVO.setPlanBlank(true);
				else if(planID.toUpperCase().startsWith("S"))
				electionVO.setPlanPDP(true);*/
				//CMS Changes 2018-MA OEP Additional Check :00411704 :end
				
				/* CMS Change for DEC-2019 release-End-00423084 */
				
				
				//CMS Changes for SEP Dual LIS -IFOX-00415122: start
				electionVO.setLastUsedSepDate(mbd.getLastUsedSepDate());
				//CMS Changes for SEP Dual LIS -IFOX-00415122: end
				
				// Derive election type
				/** Triple S BasePlus Migration START **/
				//String derivedType = EEMElection.validateElectionType(conn, eemDb, electionVO);
				String derivedType = EEMElection.validateElectionType(conn, eemDb, electionVO, seamlessInd);
				/** Triple S BasePlus Migration END **/
				objVO.setElcDerivedInd(electionVO.getElcDerivedInd());
				objVO.setElectionType(electionVO.getElectionType());
				electionVO.setApplType(StringUtil.nonNullTrim(objVO.getApplType()));//IFOX00397076 
				
				if (!StringUtil.nonNullTrim(derivedType).equals("")) {
					/** Triple S BasePlus Migration START **/
					//CMS Feb Release 2017 - New Seamless Election Type  : Start
					if( !(objVO.getElectionType().equals("J") && (derivedType.equals("I")|| derivedType.equals("E")))) {
					//CMS Feb Release 2017 - New Seamless Election Type  : End
					/** Triple S BasePlus Migration END **/
					errorCode = "AP189";
					status = "";
					errorValue = derivedType;
					/** Triple S BasePlus Migration START **/
					//CMS Feb Release 2017 - New Seamless Election Type  : Start
					} else if (objVO.getElectionType().equals("J") && !objVO.getEnrollSrceCd().equals("B")){
						errorCode = "AP233";
						status = EEMConstants.APPL_STATUS_ERRORCRITL; //CMS 2019 January Release- Requirement-2b: MA OEP - M. START
						errorValue = objVO.getEnrollSrceCd();
					}
					/** Triple S BasePlus Migration END **/
					//CMS 2019 January Release- Requirement-2b: MA OEP - M. START
					 else if(objVO.getElectionType().equals("M") && 
							(derivedType.equals("I") || derivedType.equals("F") || derivedType.equals("E"))){
						errorCode = electionVO.getErrorCode();
						status = EEMConstants.APPL_STATUS_ERRORCRITL;
						errorValue = objVO.getElectionType();
					} else if(objVO.getElectionType().equals("I") && 
							(derivedType.equals("F") || derivedType.equals("E"))){
						errorCode = electionVO.getErrorCode();
						status = EEMConstants.APPL_STATUS_ERRORCRITL;
						errorValue = objVO.getElectionType();
					}
					//CMS 2019 January Release- Requirement-2b: MA OEP - M. END
					//CMS Feb Release 2017 - New Seamless Election Type  : End
				} else {
					errorCode = electionVO.getErrorCode();
					//status = EEMConstants.APPL_STATUS_ERRORCRITL;
					status = EEMConstants.APPL_STATUS_ELGWARNING;
					errorValue = objVO.getElectionType();
				}
				//CMS 2019 January Release- Requirement-3 : DUAL/LIS SEP � L and U. START
				
				// IFOX-00423084 - BasePlus CMS Nov 2019 Changes : AP355 -> AP358 - Start 
				if(electionVO.getElectionType().equals(EEMConstants.ELECTION_TYPE_SEP_LIS)) {
					if(electionVO.getErrorCode().equals("AP351") || electionVO.getErrorCode().equals("AP352") || electionVO.getErrorCode().equals("AP052") || electionVO.getErrorCode().equals("AP355")){
						errorCode = electionVO.getErrorCode();
						status = EEMConstants.APPL_STATUS_ERRORCRITL;
						errorValue = objVO.getElectionType();
					}
					else if(electionVO.getErrorCode().equals("AP358")){
						errorCode = electionVO.getErrorCode();
						status = EEMConstants.APPL_STATUS_ELGWARNING;
						errorValue = objVO.getElectionType();
					}
				}
				
				/*if(electionVO.getElectionType().equals(EEMConstants.ELECTION_TYPE_SEP_LIS) &&
						(electionVO.getErrorCode().equals("AP351") || electionVO.getErrorCode().equals("AP352") || electionVO.getErrorCode().equals("AP052") || electionVO.getErrorCode().equals("AP355"))){
					errorCode = electionVO.getErrorCode();
					status = EEMConstants.APPL_STATUS_ERRORCRITL;
					errorValue = objVO.getElectionType();
				}*/
				// IFOX-00423084 - BasePlus CMS Nov 2019 Changes : AP355 -> AP358 - End
				
				//CMS 2019 January Release- Requirement-3 : DUAL/LIS SEP � L and U. END
				/*if(errorCode != null && !errorCode.equalsIgnoreCase("")){	
					if(errorCode.equalsIgnoreCase("AP052") || errorCode.equalsIgnoreCase("AP087") ||errorCode.equalsIgnoreCase("AP165")){	
						status = EEMConstants.APPL_STATUS_INCRFIELCT;
						// Summacare defect fix for AP192 Error Code - Start
					}else if(errorCode.equalsIgnoreCase("AP192")){
						status = EEMConstants.APPL_STATUS_ERRORCRITL;
					}
					// Summacare defect fix for AP192 Error Code - End
					
				}*/
				
				if(errorCode != null && !errorCode.equalsIgnoreCase("")){
					//CMS Changes 2019-MA OEP Additional Check for PDP apps :00411704 :start
					//if(errorCode.equalsIgnoreCase("AP087") ||errorCode.equalsIgnoreCase("AP165")){
					if(errorCode.equalsIgnoreCase("AP052") || errorCode.equalsIgnoreCase("AP087") || errorCode.equalsIgnoreCase("AP165") 
							|| errorCode.equalsIgnoreCase("AP353") || errorCode.equalsIgnoreCase("AP354")){	
					//CMS Changes 2018-MA OEP Additional Check for PDP apps :00411704 :end
						status = EEMConstants.APPL_STATUS_INCRFIELCT;
						// Summacare defect fix for AP192 Error Code - Start
					}else if(errorCode.equalsIgnoreCase("AP192") || errorCode.equalsIgnoreCase("AP052") ){
						status = EEMConstants.APPL_STATUS_ERRORCRITL;
					}
					// Summacare defect fix for AP192 Error Code - End
					
				}
			//IFOX-00382850: Election Type blank error changes - Start	
			//}
			//IFOX-00382850: Election Type blank error changes - End
			if (!StringUtil.nonNullTrim(errorCode).equals("")) {
				objError = getErrorVO(field, objVO, errorCode, status);
				objError.setValue(errorValue);
			}
			
		} catch (Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			objVO.setMessage("Error during Election Type check.");
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objError;
	}
	public EEMErrorVO checkApplDate(Connection conn, String eemDb, EEMApplicationVO objVO,
			List lstFields) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());

		EEMErrorVO objError = null;
		
		EEMFieldErrorVO field = getField("applDate", lstFields);
		if (field != null && !validateEditRule(conn, eemDb, objVO.getApplDate(), field, objVO)) {

			objError = getErrorVO(field, objVO, field.getErrorCd(), EEMConstants.APPL_STATUS_ERRORCRITL);
			objError.setValue(objVO.getApplDate());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objError;
	}
	// IFOX-00400051 app will go to RFI status based on the DB config, no spl handling is required
//	public EEMErrorVO checkSignatureDate(Connection conn, String eemDb, EEMApplicationVO objVO,
//			List lstFields) throws ApplicationException {
//
//		EEMErrorVO objError = null;
//		
//		EEMFieldErrorVO field = getField("signDt", lstFields);
//		//System.out.println("field"+field+validateEditRule(conn, eemDb, objVO.getSignDt(), field, objVO));
//		if (field != null && !validateEditRule(conn, eemDb, objVO.getSignDt(), field, objVO)) {
//
//			//objError = getErrorVO(field, objVO, field.getErrorCd(), EEMConstants.APPL_STATUS_ERRORCRITL);
//			objError = getErrorVO(field, objVO, field.getErrorCd(), EEMConstants.APPL_STATUS_INCRFIREQ);
//			objError.setValue(objVO.getSignDt());
//		}
//
//		return objError;
//	}
	
	public EEMErrorVO checkEsrdInd(Connection conn, String eemDb, EEMApplicationVO objVO,
			List lstFields, boolean validProduct) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMErrorVO objError = null;
		EEMFieldErrorVO field = getField("esrd", lstFields);
		if (field == null) {
			logger.info(LoggerConstants.methodEndLevel());
			return objError;
		}
		try {
			String status = "";
			String errorCode = "";
			String errorValue = StringUtil.nonNullTrim(objVO.getEsrd());
			MBD mbd = objVO.getMbd();
			
			if (!validProduct) {
				status = EEMConstants.APPL_STATUS_ERRORCRITL;
				errorCode = "AP154";
			} 
			else
			if (mbd != null) {
				String esrdInd = EEMProfileSettings.getCalendarProfileItem(
						eemDb, objVO.getCustomerId(), EEMProfileSettings.ELGESRD);
				if (!StringUtil.nonNullTrim(esrdInd).equals("")) {
					if (esrdInd.equals("D")) {
						if (StringUtil.nonNullTrim(objVO.getEsrd()).equals("Y") &&
								StringUtil.nonNullTrim(mbd.getEsrdInd()).equals("N")) {
							objVO.setEsrd(mbd.getEsrdInd());
						}
						
					} else if (esrdInd.equals("U")) {
						if (StringUtil.nonNullTrim(objVO.getEsrd()).equals("N") &&
								StringUtil.nonNullTrim(mbd.getEsrdInd()).equals("Y")) {
							objVO.setEsrd(mbd.getEsrdInd());
						}
						
					} else if (esrdInd.equals("Y")) {
						if (!StringUtil.nonNullTrim(objVO.getEsrd()).equals(
								StringUtil.nonNullTrim(mbd.getEsrdInd()))) {
							objVO.setEsrd(mbd.getEsrdInd());
						}
						//SSNRI Defect-98
						if (StringUtil.nonNullTrim(mbd.getEsrdInd()).equals("")){
							objVO.setEsrd("N");
						}
					}
					//IFOX - 431608 : CMS Changes 2020 - start - uncommented for ESRD fix
					//profile - N check
					else if (esrdInd.equals("N")) {
						if (!StringUtil.nonNullTrim(objVO.getEsrd()).equals(
								StringUtil.nonNullTrim(mbd.getEsrdInd()))) {
							objVO.setEsrd(mbd.getEsrdInd());
						}
						//SSNRI Defect-98
						if (StringUtil.nonNullTrim(mbd.getEsrdInd()).equals("")){
							objVO.setEsrd("N");
						}
					}
					//profile - N check
					//IFOX - 431608 : CMS Changes 2020 - end - uncommented for ESRD fix
					
				}
			}

			if (!StringUtil.nonNullTrim(errorCode).equals("")) {
				objError = getErrorVO(field, objVO, errorCode, status);
				objError.setValue(errorValue);
			}
		} catch (Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			objVO.setMessage("Error during ESRD Ind check.");
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objError;
	}

	public EEMErrorVO checkEsrdOverrideInd(Connection conn, EEMApplicationVO objVO,
			List lstFields) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMErrorVO objError = null;
		EEMFieldErrorVO field = getField("pcoInd", lstFields);
		if (field == null) {
			logger.info(LoggerConstants.methodEndLevel());
			return objError;
		}
		try {
			String status = "";
			String errorCode = "";
			String errorValue = StringUtil.nonNullTrim(objVO.getPcoInd());
			MBD mbd = objVO.getMbd();

			if (mbd != null) {
				String esrdInd = StringUtil.nonNullTrim(objVO.getEsrd());
				String esrdOvrInd = StringUtil.nonNullTrim(objVO.getPcoInd());
				if (esrdOvrInd.equals("")) {
					esrdOvrInd = "N";
					objVO.setPcoInd("N");
				}
				String mbdEsrdInd = StringUtil.nonNullTrim(mbd.getEsrdInd());
				
				if (esrdInd.equals("Y") && esrdOvrInd.equals("N") &&
						mbdEsrdInd.equals("Y")) { // Need to check for Grp_Product.SNP_Ind
					status = EEMConstants.APPL_STATUS_ELGCRITICL;
					errorCode = "AP066";
				} else if (esrdInd.equals("Y") && esrdOvrInd.equals("Y") &&
						mbdEsrdInd.equals("N")) {
					status = EEMConstants.APPL_STATUS_ELGCRITICL;
					errorCode = "AP065";
				} else if (esrdInd.equals("Y") && esrdOvrInd.equals("N") &&
						mbdEsrdInd.equals("N")) {
					status = EEMConstants.APPL_STATUS_ELGCRITICL;
					errorCode = "AP065";
				} else if (esrdInd.equals("N") && esrdOvrInd.equals("Y") &&
						mbdEsrdInd.equals("N")) {
					status = EEMConstants.APPL_STATUS_ERROR;
					errorCode = "AP066";
				} else if (esrdInd.equals("N") && esrdOvrInd.equals("Y") &&
						mbdEsrdInd.equals("Y")) {
					status = EEMConstants.APPL_STATUS_ELGCRITICL;
					errorCode = "AP066";
				} else if (esrdInd.equals("N") && esrdOvrInd.equals("N") &&
						mbdEsrdInd.equals("Y")) {
					status = EEMConstants.APPL_STATUS_ELGCRITICL;
					errorCode = "AP066";
				}  else if (esrdInd.equals("") && (esrdOvrInd.equals("N") || esrdOvrInd.equals("")) &&
						mbdEsrdInd.equals("Y")) {
					status = EEMConstants.APPL_STATUS_ELGCRITICL;
					errorCode = "AP066";
				}
			}

			if (!StringUtil.nonNullTrim(errorCode).equals("")) {
				objError = getErrorVO(field, objVO, errorCode, status);
				objError.setValue(errorValue);
			}
		} catch (Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			objVO.setMessage("Error during ESRD Override Ind check.");
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objError;
	}

	public EEMErrorVO checkElcReasonCd(Connection conn, EEMApplicationVO objVO,
			List lstFields) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMErrorVO objError = null;
		EEMFieldErrorVO field = getField("sepReason", lstFields);
		if (field == null) {
			return objError;
		}
		try {
			String status = "";
			String errorCode = "";
			String errorValue = StringUtil.nonNullTrim(objVO.getSepReason());

			if (StringUtil.nonNullTrim(objVO.getElectionType()).equals(EEMConstants.ELECTION_TYPE_SEP_ELP) &&
					StringUtil.nonNullTrim(objVO.getSepReason()).equals("")) {
				errorCode = "AP165";
				
				/**
				 * Cambia New Application Status -Start
				 */
				//status = EEMConstants.APPL_STATUS_ERROR;
				
				status = EEMConstants.APPL_STATUS_INCRFIELCT;
				/**
				 * Cambia New Application Status -End
				 */
			}

			if (!StringUtil.nonNullTrim(errorCode).equals("")) {
				objError = getErrorVO(field, objVO, errorCode, status);
				objError.setValue(errorValue);
			}
		} catch (Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception : " + e.getMessage());
			objVO.setMessage("Error during Election Reason check.");
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objError;
	}

	public EEMErrorVO checkLTCFacility(Connection conn, EEMApplicationVO objVO,
			List lstFields) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMErrorVO objError = null;
		EEMFieldErrorVO field = getField("nameInstitute", lstFields);
		if (field == null) {
			return objError;
		}
		try {
			String status = "";
			String errorCode = "";
			String errorValue = StringUtil.nonNullTrim(objVO.getNameInstitute());

			if (StringUtil.nonNullTrim(objVO.getElectionType()).equals(EEMConstants.ELECTION_TYPE_OEPI) &&
					StringUtil.nonNullTrim(objVO.getNameInstitute()).equals("")) {
				errorCode = "AP046";
				status = EEMConstants.APPL_STATUS_ERROR;
			}			

			if (!StringUtil.nonNullTrim(errorCode).equals("")) {
				objError = getErrorVO(field, objVO, errorCode, status);
				objError.setValue(errorValue);
			}
		} catch (Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			objVO.setMessage("Error during LTC Facility check.");
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objError;
	}

	// IFOX-00380952: Medicaid ID & ELGWARNING Apps to Suppend Fix -- Start
	public EEMErrorVO checkMedicaidId(Connection conn, EEMApplicationVO objVO,
			List lstFields) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMErrorVO objError = null;
		EEMFieldErrorVO field = getField("medicaidId", lstFields);
		if (field == null) {
			return objError;
		}
		try {
			String status = "";
			String errorCode = "";
			String errorValue = "";

			if (StringUtil.nonNullTrim(objVO.getStMedicaid()).equals("Y") && StringUtil.nonNullTrim(objVO.getMedicaidId()).equals("")
					|| !StringUtil.isNumeric(objVO.getMedicaidId())) { //IFOX- 00417029
				errorCode = "AP197";
				errorValue = objVO.getMedicaidId();
				status = EEMConstants.APPL_STATUS_ERROR;
			}			

			if (!StringUtil.nonNullTrim(errorCode).equals("")) {
				objError = getErrorVO(field, objVO, errorCode, status);
				objError.setValue(errorValue);
			}
		} catch (Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception : " + e.getMessage());
			objVO.setMessage("Error during Medicaid ID check.");
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objError;
	}
	// IFOX-00380952: Medicaid ID & ELGWARNING Apps to Suppend Fix -- End
	
	public void checkApplicationNbr(Connection conn, String eemDb, EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			String applNbrInd = EEMProfileSettings.getCalendarProfileItem(
					eemDb, objVO.getCustomerId(), EEMProfileSettings.APPNBR);
			//Generate the Application number, if and only if there Appl Number is Empty.
			if ((objVO.getMbrApplNo() == null || objVO.getMbrApplNo().trim().isEmpty())
					&& applNbrInd != null && applNbrInd.equals(EEMProfileSettings.APPNBR_DERIVED)) {
				// Get the Application Nbr from Application Id
				String applNbr = StringUtil.nonNullTrim(objVO.getApplId());

				// Format the Application Id
				if (!applNbr.equals("")) {
					EEMProfileItem item = EEMProfileSettings.getProfileObject(
							eemDb, objVO.getCustomerId(), EEMProfileSettings.APPNBRFRMT);
					String format = item.getProfileText();
					NumberFormat nf = new DecimalFormat(format);
					double dApplNbr = Double.valueOf(applNbr).doubleValue();

					objVO.setMbrApplNo(nf.format(dApplNbr));
				}
			}
			
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	private EEMErrorVO getErrorVO(EEMFieldErrorVO field,
			EEMApplicationVO objVO, String errorCode, String status)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMCodeCache cache = EEMCodeCache.getInstance();
		EEMErrorVO objError = new EEMErrorVO();
		objError.setCustomerId(objVO.getCustomerId());
		objError.setApplId(objVO.getApplId());
		objError.setFieldNbr(field.getFieldNbr());
		if (!StringUtil.nonNullTrim(field.getRequiredInd()).equals("N")) {
			objError.setRfiInd("Y");
		} else {
			objError.setRfiInd("N");
		}
		objError.setErrorCode(errorCode);
		objError.setErrorDesc(cache.getDesc(errorCode, cache.getLstErrorCodes()));
		objError.setFieldName(field.getFormField());
		objError.setLstUpdtUser(objVO.getOperId());
		objError.setStatus(status);
		logger.info(LoggerConstants.methodEndLevel());
		return objError;
	}

	private boolean validateEditRule(Connection conn, String eemDb, String val, EEMFieldErrorVO fieldVO,
			EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		boolean result = true;
		EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
		
		String editRuleId = fieldVO.getEditRuleId();
		String fieldName = fieldVO.getFormField();
		if (StringUtil.nonNullTrim(editRuleId).equals("") ||
				StringUtil.nonNullTrim(fieldName).equals("")) {
			logger.info(LoggerConstants.methodEndLevel());
			return result;
		}
		
		try {
			if (editRuleId.equals("ALPHAEMAIL")) {
				//result = val.matches("[a-zA-Z0-9#\\-_\\.@]*");
				// Added & in the filter for IFOX-00380200 -- Start
				result = val.matches("[a-zA-Z0-9#\\&\\-_\\.@]*");
				// Added & in the filter for IFOX-00380200 -- END
			} else if (editRuleId.equals("ALPHANUM")) {
				result = val.matches("[a-zA-Z0-9]*");
			} else if (editRuleId.equals("ALPHAONLY")) {
				result = val.matches("[a-zA-Z]*");
			} else if (editRuleId.equals("ALPHAPLUS")) {
				result = val.matches("[a-zA-Z, -\\._]*");
			} else if (editRuleId.equals("ALPHASUFFX")) {
				result = val.matches("[a-zA-Z\\.]*");
			} else if (editRuleId.equals("CENY")) {
				result = val.matches("(C|E|N|Y)");
			} else if (editRuleId.equals("CHARACTER")) {
				result = val.matches("[^|]*");
			} else if (editRuleId.equals("ENBLANK")) {
				result = val.matches("( |E|N)");
			} else if (editRuleId.equals("HDRTLR")) {
				result = val.matches("(HDR|TLR)");
			} else if (editRuleId.equals("NUMERIC")) {
				result = val.matches("[0-9\\.]*");
			} else if (editRuleId.equals("NUMERPLUS")) {
				result = val.matches("[0-9-]*");
			} else if (editRuleId.equals("VVVEXAMPLE")) {
				if (val.matches("[A-Z]{3}") && !val.matches("(BBB|CCC|DDD)"))
					result = true;
			} else if (editRuleId.equals("YESNO")) {
				result = val.matches("(Y|N)");
			} else if (editRuleId.equals("YESNOBLANK")) {
				result = val.matches("( |Y|N)");
			} else if (editRuleId.equals("DCLEZIP")) {
				if (!eemDao.checkZip(conn, val))
					result = false;
			} 
			
			DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
			//Date today = new Date();

			// Application Date
			if (result && fieldVO.getFormField().equals("applDate")) {
				NameValuePair nvp = EEMElection.validApplicationDate(eemDb,objVO.getCustomerId(),
						                                             DateFormatter.reFormat(val,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD),
																	 objVO.getElectionType()
																	 );
				if (!nvp.getName().equals("000"))
					result = false;
			}

			// Birth Date
			if (result && fieldVO.getFormField().equals("mbrBirthDt")) {
				Date birthDate = df.parse(val);
				if (!StringUtil.nonNullTrim(objVO.getApplDate()).equals("")) {
					Date applDate = df.parse(objVO.getApplDate().trim());
					if (birthDate.after(applDate)) {
						result = false;
					}
				}
			}
		
			// Signature Date
			if (result && fieldVO.getFormField().equals("signDt") && !StringUtil.nonNullTrim(objVO.getOvrrdSignDt()).equals("Y")) {
				result = EEMElection.validSignatureDate(DateFormatter.reFormat(val,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD), 
						                                DateFormatter.reFormat(objVO.getApplDate(),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD),
														objVO.getElectionType(), objVO.getEditOverride());
			}
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return result;
	}
	
	public String getCCMDate(Connection conn, String customerId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String ccmDate = "";
		try {
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			ccmDate = eemDao.getCCMDate(conn,customerId);
			
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return ccmDate;
	}
	
	public List getSearchList(Connection conn, EEMApplicationVO objVO, Pagination pagination, String move) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		List lstFields = null;
		try {

			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();

			lstFields = eemDao.getApplSearchDetails(conn, objVO, pagination, move);
			
			EEMApplicationVO [] arr = new EEMApplicationVO[lstFields.size()];
			arr = (EEMApplicationVO[])lstFields.toArray(arr);		

			pagination.setPaginationResults(move,arr);
			
			for (int i = 0; i < lstFields.size(); i++) {
				EEMApplicationVO tempVO = (EEMApplicationVO) lstFields.get(i);
				tempVO.setMbrBirthDt(DateUtil.formatMmDdYyyy(tempVO.getMbrBirthDt()));
				// Select the first record to display
				if (i == 0)
					tempVO.setRowSelected("Y");
			}
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return lstFields;
	}

// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - Start
	public EEMApplicationVO getApplDetails(Connection conn, String eemDb,
			EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - End
		EEMApplicationVO formVO = null;
		try {
			/** Triple S BasePlus Migration START **/
			// MMO ACH CR-Start
			String achValue = EEMProfileSettings.getCalendarProfileItem(eemDb, objVO.getCustomerId(),
					EEMProfileSettings.ACHIND);
			objVO.setAchIndicator(achValue);
			/** Triple S BasePlus Migration END **/
			/**Fetching BEQ Check Ind**/
			String beqCheck = EEMProfileSettings.getCalendarProfileItem(eemDb, objVO.getCustomerId(),
					EEMProfileSettings.BEQCHECK);
			// MMO ACH CR-End
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			// Get Master details
			formVO = eemDao.getMasterDetails(conn, objVO);
			
			formVO.setCustomerNbr(objVO.getCustomerNbr());

			// Get Address details
			getAddressDetails(eemDao, conn, formVO, true);
			
			// Get Product details
			getProductDetails(eemDao, conn, formVO);
			
			// Get Other coverage details
			getOtherCovDetails(eemDao, conn, formVO);
			
			// Get Attestation details
			getAttestDetails(eemDao, conn, formVO);
			
			// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - Start
			// Get Agency, Agent details
			getAgentDetails(eemDao, conn, eemDb, formVO);
			// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - End

			// Get Comment details
			getCommentDetails(eemDao, conn, formVO);
			
			// Get Eligibility details
			getEligDetails(eemDao, conn, formVO, beqCheck);
			
			// Get MBD details
			getMBDDetails(eemDao, conn, formVO, beqCheck);
			
			// Get Error details
			getErrorDetails(eemDao, conn, formVO);
			/**
			 * Cambia_OEVProcess-Start
			 */
			
			formVO = getOevDetails(conn, formVO);
					
			/**
			 * Cambia_OEVProcess-End
			 */
			/**
			 * Cambia LIS-Start
			 */
		getLisDetails(eemDao, conn, formVO);
			/**
			 * Cambia LIS-End
			 */		
		// set Elg Override Ind flag
		formVO.setEligOverrideInd(checkEligOverrideInd(formVO));
		
		} catch (Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			objVO.setMessage("Error during Record Retrieval.");
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return formVO;
	}
	// IFOX-00423084 - BasePlus CMS Nov 2019 Changes - Start
	/*private String isHicOrMbi(String medId) {
		logger.info(LoggerConstants.methodStartLevel());
		String flag = "mbi";
		if(medId.length() == 11){
			if(!Character.isDigit(medId.charAt(0)))
				flag = "hic";
			else if(!Character.isLetter(medId.charAt(1)))
				flag = "hic";
			else if(!Character.isLetterOrDigit(medId.charAt(2)))
				flag = "hic";
			else if(!Character.isDigit(medId.charAt(3)))
				flag = "hic";
			else if(!Character.isLetter(medId.charAt(4)))
				flag = "hic";
			else if(!Character.isLetterOrDigit(medId.charAt(5)))
				flag = "hic";
			else if(!Character.isDigit(medId.charAt(6)))
				flag = "hic";
			else if(!Character.isLetter(medId.charAt(7)))
				flag = "hic";
			else if(!Character.isLetter(medId.charAt(8)))
				flag = "hic";
			else if(!Character.isDigit(medId.charAt(9)))
				flag = "hic";
			else if(!Character.isDigit(medId.charAt(10)))
				flag = "hic";
				
		}
		else 
			flag = "hic";
		logger.info(LoggerConstants.methodEndLevel());
		return flag;
	}*/
	
	private String isHicOrMbi(String medId) {
		logger.info(LoggerConstants.methodStartLevel());
		String flag = "mbi";
		if(medId.length() == 11){
			if(!Character.isDigit(medId.charAt(0)))
				flag = "hic";
			else if(!(Character.isLetter(medId.charAt(1)) && !lookUpForExceptions(medId.charAt(1))))
				flag = "hic";
			else if(!(Character.isLetterOrDigit(medId.charAt(2)) && !lookUpForExceptions(medId.charAt(2))))
				flag = "hic";
			else if(!Character.isDigit(medId.charAt(3)))
				flag = "hic";
			else if(!(Character.isLetter(medId.charAt(4)) && !lookUpForExceptions(medId.charAt(4))))
				flag = "hic";
			else if(!(Character.isLetterOrDigit(medId.charAt(5)) && !lookUpForExceptions(medId.charAt(5))))
				flag = "hic";
			else if(!Character.isDigit(medId.charAt(6)))
				flag = "hic";
			else if(!(Character.isLetter(medId.charAt(7)) && !lookUpForExceptions(medId.charAt(7))))
				flag = "hic";
			else if(!(Character.isLetter(medId.charAt(8)) && !lookUpForExceptions(medId.charAt(8))))
				flag = "hic";
			else if(!Character.isDigit(medId.charAt(9)))
				flag = "hic";
			else if(!Character.isDigit(medId.charAt(10)))
				flag = "hic";
				
		}
		else 
			flag = "hic";
		logger.info(LoggerConstants.methodEndLevel());
		return flag;
	}

	
	private boolean lookUpForExceptions(char ch) {
		char[] exclusions = {'S', 'L', 'O', 'I', 'B', 'Z'};
		
		for(char c:exclusions){
			if(ch == c) {
				//System.out.println("Exclusion Char is Present: " + c);
				return true;
			}
				
		}
		return false;
		
	}
	// IFOX-00423084 - BasePlus CMS Nov 2019 Changes - End 
	public boolean setApplDetails(Connection conn, String eemDb,
			EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
    	boolean inTrans = false;
    	boolean origAutoCommit = false;
    	boolean success = false;
		try {
			origAutoCommit = conn.getAutoCommit();
			conn.setAutoCommit(false);
			inTrans = true;
			String message = "";

			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			// Set the application status
			List lstErrors = objVO.getLstErrors();
			String applStatus = StringUtil.nonNullTrim(objVO.getApplStatus());
			// IFOX-00369084 and IFOX-00372138 - Optimized FORCEDAPPR bypass
			String currStatus = StringUtil.nonNullTrim(objVO.getCurrStatus());
			if (!applStatus.equals(EEMConstants.APPL_STATUS_HOLD) &&
					!(applStatus.equals(EEMConstants.APPL_STATUS_FORCEDAPPR) && (currStatus.equals(EEMConstants.APPL_STATUS_ELGWARNING) || 
							currStatus.equals(EEMConstants.APPL_STATUS_ELGNOTFND)
					//Added as a fix to allow BEQPENDING to FORCEDAPPR status : start		
							||(currStatus.equals(EEMConstants.APPL_STATUS_BEQPENDING) &&
									objVO.getEligOverrideInd().equals("Y")))) &&
					//Added as a fix to allow BEQPENDING to FORCEDAPPR status : end
					!isCancelOrDenied(objVO) &&
					lstErrors != null && lstErrors.size() > 0) {
				String evalStatus = evalErrorStatus(lstErrors);
				if (!evalStatus.equals("")) {
					objVO.setApplStatus(evalStatus);	
				}
			}
			
			//DupAppl-start
			boolean bypassUpdateduplicate = false;
			if (objVO.getAppDuplicateCheck() != null
					&& objVO.getAppDuplicateCheck().equalsIgnoreCase("Y")
					&& applStatus.equals(EEMConstants.APPL_STATUS_HOLD)) {
				message = "Please select other Status for Override Duplicate Application. \n";
				objVO.setAppDuplicateCheck("N");
			} else {
				if (objVO.getAppDuplicateCheck() != null
						&& objVO.getAppDuplicateCheck().equalsIgnoreCase("Y")) {
					List lstOrgPlan = eemDao.checkDuplicateApplication(conn,
							objVO);
					// List lstOrgPlanExsisting =
					// eemDao.checkExsistingDuplicateApplication(conn, objVO);
					List lstOrgPlanExsisting = eemDao.checkDuplicateEnrollment(
							conn, objVO);
					if (lstOrgPlan.size() == 0) {
						message = "No Override Duplicate Application found. \n";
						objVO.setAppDuplicateCheck("N");
						bypassUpdateduplicate = true;
					}
					if (lstOrgPlanExsisting.size() > 0) {
						message = "";
						boolean error = false;
						int orgPlanSize = lstOrgPlanExsisting.size();
						// String errorCode ="";
						String reqDtCov = DateFormatter.reFormat(
								objVO.getReqDtCov(), DateFormatter.MM_DD_YYYY,
								DateFormatter.YYYYMMDD);
						for (int i = 0; i < orgPlanSize; i++) {
							String[] orgPlan = (String[]) lstOrgPlanExsisting
									.get(i);
							//CR-IFOX-00408061. START
							String planId = StringUtil.nonNullTrimSpace(orgPlan[3]);
							String pbpId = StringUtil.nonNullTrimSpace(orgPlan[4]);
							String productId = StringUtil.nonNullTrimSpace(orgPlan[5]);
							String grpId = StringUtil.nonNullTrimSpace(orgPlan[6]);
							String pbpSegmentId = StringUtil.nonNullTrimSpace(orgPlan[7]);
							String startDate = orgPlan[2];
							
							if (DateMath.isGreaterThanOrEqual(reqDtCov,startDate)
									&& objVO.getEnrollPlan().equalsIgnoreCase(planId)
									&& objVO.getEnrollPbp().equalsIgnoreCase(pbpId)
									&& objVO.getEnrollProduct().equalsIgnoreCase(productId)
									&& objVO.getEnrollGroup().equalsIgnoreCase(grpId)
									&& objVO.getEnrollSegment().equalsIgnoreCase(pbpSegmentId)) {
								// errorCode = "AP193";
								message = "Processed application found, can't override duplicate application. \n";
								logger.debug(message);
								objVO.setAppDuplicateCheck("N");
								bypassUpdateduplicate = true;
							}
							//Functionality Not Approved
							/*if(objVO.getDentalApplFlag().equalsIgnoreCase("Y")){
								if (objVO.getEnrollPlan().equalsIgnoreCase(planId)
										&& objVO.getEnrollPbp().equalsIgnoreCase(pbpId)
										&& objVO.getEnrollGroup().equalsIgnoreCase(grpId)
										&& objVO.getEnrollSegment().equalsIgnoreCase(pbpSegmentId)) {
									logger.debug("Validate, if member product is base and enrolled product is Dental or not"); 
									if(!isDentalProduct(productId) && isDentalProduct(objVO.getEnrollProduct())){
										String applDt = DateFormatter.reFormat(objVO.getApplDate(),
												DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
										String startDatePlus30 = DateMath.addDay(startDate, 30);
										logger.debug("Validate the dental application received date prior to 30 days from the member product effective date."); 
										if(DateMath.isGreaterThanOrEqual(applDt, startDatePlus30)){
											//TODO:Add Error Code to move the application to workflow queue.
										}
									}
								}
							}*/
							//CR-IFOX-00408061. END
						}
					}
					if (message.length() == 0
							&& lstOrgPlan.size() > 0
							&& ("CMA".equalsIgnoreCase(objVO.getApplType()) || checkDuplicate(
									conn, eemDao, objVO, lstOrgPlan))) {
						if (eemDao.updateOverrideData(conn, objVO) > 0) {
							eemDao.updateDuplicateAppError(conn, lstOrgPlan,
									objVO);
							eemDao.insertErrorApplError(conn, lstOrgPlan, objVO);
							message = "Override Duplicate Application Successful. \n";
							bypassUpdateduplicate = true;
							if ((lstErrors != null && lstErrors.size() == 0)
									|| lstErrors == null) {
								objVO.setApplStatus("READY");
							}
						}
					}
				}
			}
			//end
			// Set Master details
			if (!setMasterDetails(eemDao, conn, eemDb, objVO)) {
				message = "Application Master Update failed.\n";
			}

			// Set Address details
			EEMApplAddressVO origAddrVO = new EEMApplAddressVO();//for Original Application
		
			if (!setAddressDetails(eemDao, conn, objVO, origAddrVO)) {
				message += "Address Update failed.\n";
			}
			
			// Set Product deatails
			if (!setProductDetails(eemDao, conn, objVO)) {
				message += "Product details Update failed.\n";
			}
			
			// Set Other Coverage details
			if (!setOtherCovDetails(eemDao, conn, objVO)) {
				message += "Other Coverage Update failed.\n";
			}
			
			// Set Attestation details
			if (!setAttestDetails(eemDao, conn, objVO)) {
				message += "Attestation details Update failed.\n";
			} 
			
			// Set Agency, Agent details
			if (!setAgentDetails(eemDao, conn, objVO)) {
				message += "Agent details Update failed.\n";
			}   
			
			// Set Comment details
			// original application start
			//performance original application
			EEMApplCommentsVO origCommentVO  = new EEMApplCommentsVO();//for original application
			if (!setCommentDetails(eemDao, conn,eemDb,objVO,origCommentVO)) {
				message += "Comments Update failed.\n";
			} 
			//oriiginal application end
			
			// Set Eligibility details
			if (!setEligDetails(eemDao, conn, objVO)) {
				message += "Eligibility details Update failed.\n";
			}
			
			// Set BEQ details
			if (!setBEQDetails(eemDao, conn, objVO)) {
				message += "BEQ details Update failed.\n";
			}

			// Set Error Details
			if (!setErrorDetails(eemDao, conn, objVO)) {
				message += "Error details Update failed.\n";
			}

			// Fix for IFOX-00388790: Start
			/*LEP Uncovered Months Calculation -- START */
			// Set LEP Old Calculation
			/*if(!isCancelOrDenied(objVO)){
			if (!setLEPUncovMnthCalM(eemDao, conn, objVO)) {
				message += "Application Trigger Update failed.\n";
			}
			}*/
			boolean lepFlagCheck = false;
			if(objVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_MA) || objVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_PD))
				lepFlagCheck = true;
			else if(objVO.getApplType().equals(EEMConstants.OPTION_CNTRCHG_MA) && StringUtil.nonNullTrim(objVO.getCurrPlanDesgn()).equals(EEMConstants.PLAN_DESGN_MA)){ // Issue for sentara
			if(objVO.getEnrollPlanDesgn().equals(EEMConstants.PLAN_DESGN_MAPD) || objVO.getEnrollPlanDesgn().equals(EEMConstants.PLAN_DESGN_PDP))
				lepFlagCheck = true;
			}
			// Set LEP New Calculation
			// Added the if condition for IFOX-00377369 - LEP NUNCMO CR - SUPP ID Check
			if(!isCancelOrDenied(objVO) && lepFlagCheck){
			//	if (!StringUtil.nonNullTrim(objVO.getAltMbrId()).equalsIgnoreCase("")){
				if (!setLEPUncovMnthCalC(eemDao, conn, objVO)) {
					message += "Application Trigger Update failed.\n";
				}
			//}
			}
			/*LEP Uncovered Months Calculation -- END */
			// Fix for IFOX-00388790: End
			
			/**
			 *Cambia_OEVProcess-Start
			 */
			
			// IFOX-00372800: Commented to disable OEV letter/ timer -- Start
			/*if(!StringUtil.nonNullTrim(objVO.getCommAgencyId()).equalsIgnoreCase("") ){
				 
			//System.out.println("oevTImet"+setOevTimer(eemDao, conn, objVO));
				if(!setOevTimer(eemDao, conn, objVO)){
					message += "Inserting OEV timer failed. \n";
				}
				
				//objVO.setOevTimerCheck("true");
				String date = new DateUtil().getTodaysDate();
				if(!(StringUtil.nonNullTrim(objVO.getApplDate()).equals(""))){
					
					int diff = DateMath.calculateDiff(date, objVO.getApplDate());
				
					if(diff>8)
						objVO.setOevDateCheck(true);		
				}
			}*/
			// IFOX-00372800: Commented to disable OEV letter/ timer -- End
			/**
			 * Cambia_OEVProcess-End
			 */
		/**
			 * Cambia Lis -Start
			 */
			// Set Lisdetails
				if (!setLisDetails(eemDao, conn, objVO)) {
					message += "LIS Information Update failed.\n";
				}
			/**
			 * Cambia Lis -End
			 */
			 //original application start
			//performance original application
			if (objVO.getUpdateRec().equals("N")) {
			
			int rows =	eemDao.setOrigDetails(conn, eemDb,objVO,origAddrVO,origCommentVO);
			
			}
			//original application end
			if (message.equals("") || bypassUpdateduplicate) {
				conn.commit();
				inTrans = false;

				objVO.setUpdateRec("Y");
				objVO.setLstUpdtApplUser(objVO.getOperId());
				
				clearCommentDetailsFlag(objVO);
				
				//original application start
				Boolean checkOrig = checkOrigApplRecords(conn, objVO);
				if(checkOrig){
					objVO.setOrig(1);
				}
				
				//original application end
				
				if (bypassUpdateduplicate) {
					message += "Updated Successfully";
					objVO.setMessage(message);
				} else {
				objVO.setMessage("Updated Successfully");
				}
				success = true;
			} else {
				objVO.setMessage(message);
			}
			
		} catch (Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			objVO.setMessage("Invalid Application Details to Update.");
		} finally {
			try {
    			if (inTrans)
    				conn.rollback();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			throw new ApplicationException(e);
    		}
    		try {
    			conn.setAutoCommit(origAutoCommit);
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			throw new ApplicationException(e);
    		}	
		}
		logger.info(LoggerConstants.methodEndLevel());
		return success;
	}
	
	/*private boolean setLEPUncovMnthCalC(EEMApplDao eemDao, Connection conn, EEMApplicationVO objVO) {
		
         try {
        	 
        	  
 			 * Check whether this Application Id is having any row in EM_APPL_LEP table.
 			 * If row exists then skip the below LEP calculation logic
 			 
 			
                         MBD mbd = objVO.getMbd();
                         int rslt1,rslt2 = 0;
                         boolean lepCalFlag = false;
                         objVO = eemDao.getLepCalculationFlag(conn,objVO);
                         if(objVO.getLepCalcFlag()!=null && objVO.getLepCalcFlag().equalsIgnoreCase("C")){
                         if(objVO.getEnrollPlanDesgn().equalsIgnoreCase("MAPD") || objVO.getEnrollPlanDesgn().equalsIgnoreCase("PDP") ){
                        	 //======== LEP Date1 to Date6 logic========================= - START
                        	String date1="";
                 		    String date2="";
                 			String date3="";
                 			String date4="";
                 			String date5="";
                 			String date6="";
                 			Date reqDtCov = null;
                 			Date rdsSDate=null;
                 			Date prtdSDate=null;
                 			String reqDtCovinString="";
                 			
							PRTDHistoryVO prtDHistoryVO =new PRTDHistoryVO();
							RDSHistoryVO rdsHistoryVO=new RDSHistoryVO();
							
							//getting  PRTDHISTORY  Data from by  PRTDHISTORY
							 prtDHistoryVO.setHicNbr(mbd.getHicNbr());
							 prtDHistoryVO = eemDao.getPRTDHistoryData(conn,prtDHistoryVO);
							 
							//getting  RDSHISTORY  Data from by  PRTDHISTORY
							 
							 rdsHistoryVO.setHicNbr(mbd.getHicNbr());
							 rdsHistoryVO = eemDao.getRDSHistoryData(conn,rdsHistoryVO);
							 
							SimpleDateFormat dateformat = new SimpleDateFormat("yyyyMMdd");
							SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
							Date date = new Date();
							String sSysDate=dateformat.format(date);
							Date systemDate=dateformat.parse(sSysDate);
							System.out.println("sSysDate:::::::::: "+sSysDate);
							System.out.println("systemDate:::::::::: "+systemDate);
							System.out.println("objVO.getReqDtCov():::::::::: "+objVO.getReqDtCov());
							if(StringUtil.isNotNullNotEmptyNotWhiteSpace(objVO.getReqDtCov())){
							reqDtCov=formatter.parse(objVO.getReqDtCov());
							 reqDtCovinString=dateformat.format(reqDtCov); 
							}
							System.out.println("reqDtCov:::::::::: --> "+reqDtCov);
							System.out.println("reqDtCovinString:::::::::: --> "+reqDtCovinString);
							int copayLevelId1 = 0;
							if(StringUtil.isNotNullNotEmptyNotWhiteSpace(mbd.getCopayLevelId1())){
								copayLevelId1= Integer.parseInt(mbd.getCopayLevelId1());
							}
							
							// Fix for IFOX-00380178 -- Start
							// STOP LEP CALCULATIONS PartD
							if(StringUtil.isNotNullNotEmptyNotWhiteSpace(prtDHistoryVO.getPrtdEDate())){
							 //if(prtDHistoryVO.getPrtdEDate().equalsIgnoreCase("00000000") && dateformat.parse(prtDHistoryVO.getPrtdSDate()).compareTo(systemDate) < 0 ){
								if(prtDHistoryVO.getPrtdEDate().equalsIgnoreCase("00000000") && dateformat.parse(prtDHistoryVO.getPrtdSDate()).compareTo(reqDtCov) <= 0 ){
								//Stop LEP Calculation
							 		lepCalFlag = true;
							 }
							}
							// STOP LEP CALCULATIONS RDS
							// Changed the RDS Start Date to End Date -- Start
							if(StringUtil.isNotNullNotEmptyNotWhiteSpace(rdsHistoryVO.getRdsEDate())){
							 //if(rdsHistoryVO.getRdsSDate().equalsIgnoreCase("00000000") && dateformat.parse(rdsHistoryVO.getRdsSDate()).compareTo(systemDate) < 0 ){
								 if(rdsHistoryVO.getRdsEDate().equalsIgnoreCase("00000000") && dateformat.parse(rdsHistoryVO.getRdsEDate()).compareTo(reqDtCov) <= 0 ){
								  //Stop LEP Calculation
							 		lepCalFlag = true;
							 		
							 }
							}
							// Changed the RDS Start Date to End Date -- End
							// STOP LEP CALCULATIONS RDS
							// Fix for IFOX-00380178 -- End
							
							
							 //date1 deriving logic End
 							if(StringUtil.isNotNullNotEmptyNotWhiteSpace(mbd.getSubsidyEndDate1())){
							if((mbd.getSubsidyEndDate1().equalsIgnoreCase("00000000") || mbd.getSubsidyEndDate1().compareTo(reqDtCovinString)>0) && copayLevelId1 >0 )
							{
								//Stop LEP Calculation
						 		lepCalFlag = true;
						 		 
						
							} else if(mbd.getSubsidyEndDate1().compareTo(reqDtCovinString)<0 && copayLevelId1 >0) {
								if(!mbd.getSubsidyEndDate1().equalsIgnoreCase("00000000"))
								{
								 date1 = DateMath.addOneDay(mbd.getSubsidyEndDate1());
								}
							
							}else{
								 date1="00000000";
							}
							}
							 System.out.println("::::::::day --- date1--- :::::::: "+date1);
							 //date1 deriving logic End
							 
							 //date2 deriving logic start
							 if(StringUtil.isNotNullNotEmptyNotWhiteSpace(prtDHistoryVO.getPrtdEDate())){
//							 if(prtDHistoryVO.getPrtdEDate() != null && !prtDHistoryVO.getPrtdEDate().equals("")) {
								 if(!prtDHistoryVO.getPrtdEDate().equalsIgnoreCase("00000000")){
									 date2 = DateMath.addOneDay(prtDHistoryVO.getPrtdEDate());
								 }else {
									 if(StringUtil.isNotNullNotEmptyNotWhiteSpace(prtDHistoryVO.getPrtdSDate())){
									 prtdSDate = dateformat.parse(prtDHistoryVO.getPrtdSDate());
									 
									 //Fix for IFOX-00377647
									 // LEP NUNCMO Fix - Start
									 if(reqDtCov.compareTo(prtdSDate) >= 0) {
										 prtDHistoryVO = eemDao.getPRTDHistoryDataSeq(conn,prtDHistoryVO);
										 //if(prtDHistoryVO.getPrtdEDate().equalsIgnoreCase("") && prtDHistoryVO.getPrtdEDate() != null)
											 if(StringUtil.isNotNullNotEmptyNotWhiteSpace(prtDHistoryVO.getPrtdEDate()) && !prtDHistoryVO.getPrtdEDate().equalsIgnoreCase("00000000"))
											 date2 = DateMath.addOneDay(prtDHistoryVO.getPrtdEDate());
										 else 
											 date2 = "00000000";
											 
								 	}else {
									  //Stop LEP Calculation
								 		lepCalFlag = true;
									 }
									 }else{
										 date2="00000000";
									 }
								 	}
								 }else {
								 date2="00000000";
							 }
							 
							// LEP NUNCMO Fix - End
							 
							 System.out.println("::::::::day --- date2--- ::::::::"+date2 );
							  //date2 deriving logic end
							
							//date3 deriving logic start
							 if(StringUtil.isNotNullNotEmptyNotWhiteSpace(rdsHistoryVO.getRdsEDate())){
//							 if(rdsHistoryVO.getRdsEDate() != null && !rdsHistoryVO.getRdsEDate().equals("")) {
								 if(!rdsHistoryVO.getRdsEDate().equalsIgnoreCase("00000000")){
									 date3 = DateMath.addOneDay(rdsHistoryVO.getRdsEDate());
								 }else {
									 if(StringUtil.isNotNullNotEmptyNotWhiteSpace(rdsHistoryVO.getRdsSDate())){
									 rdsSDate = dateformat.parse(rdsHistoryVO.getRdsSDate());
									 
									 //Fix for IFOX-00377647
									 if(reqDtCov.compareTo(rdsSDate) > 0) {
										 rdsHistoryVO = eemDao.getRDSHistoryDataSeq(conn,rdsHistoryVO);
										 //if(prtDHistoryVO.getPrtdEDate().equalsIgnoreCase("") && rdsHistoryVO.getRdsEDate() != null)
											 if(StringUtil.isNotNullNotEmptyNotWhiteSpace(rdsHistoryVO.getRdsEDate())){
											 date3 = DateMath.addOneDay(rdsHistoryVO.getRdsEDate());
											 }
										 else 
											 date3 = "00000000";
								 	}else {
									  //Stop LEP Calculation
								 		lepCalFlag = true;
									 }
									 }else {
										 date3="00000000";
									 }
								 }
							 }else {
								 date3="00000000";
							 }
							 
							 System.out.println("::::::::day --- date3--- ::::::::"+date3 );
							  //date3 deriving logic end
							 
							 // date4 deriving  logic start
							 
							 String sdob780m= DateMath.addMonth(mbd.getBirthDate(),780);
							 Date ddob780m=dateformat.parse(sdob780m);
							 
							 String sdob783m= DateMath.addMonth(mbd.getBirthDate(),783);
							 Date ddob783m=dateformat.parse(sdob783m);
							
							 String sdob777m= DateMath.addMonth(mbd.getBirthDate(),777);
							 Date ddob777m=dateformat.parse(sdob777m);
							 
							
							
							 if(reqDtCov.compareTo(ddob777m)>=0 && reqDtCov.compareTo(ddob783m)<=0)
							 {
								 // Stop the LEP Calculation.
								 lepCalFlag = true;
								 
							 }else {
								 if (reqDtCov.compareTo(ddob780m) < 0){
									 date4 = "00000000";
								 } else {
									 Setting  date4 as first of the month -- start
										String tempDate4 = DateMath.addMonth(mbd.getBirthDate(), 784);
										date4 = DateMath.getFirstOfMonth(tempDate4);
										System.out.println("tempDate4 ->" + tempDate4);
										System.out.println("date4 ->" + date4);
										Setting  date4 as first of the month -- end
									 
								 }
							 }
							 System.out.println("::::::::day --- date4--- ::::::::"+date4 );
							 //date4  deriving  logic start
							 
							 //date5  deriving  logic start
							 
							 String sPrtDEligibleDate=mbd.getPrtDEligibleDate();
							 Date dPrtDEligibleDat=dateformat.parse(mbd.getPrtDEligibleDate());
							 if(reqDtCov.compareTo(dPrtDEligibleDat) > 0 ){
								 date5 = DateMath.addMonth(sPrtDEligibleDate, 4);
							 }else {
								 date5 = "00000000"; 
							 }
							 System.out.println("::::::::day --- date5--- ::::::::"+date5 );
							 //date5  deriving  logic End
							
							 //date6  deriving  logic Start
							 
							 
							 date6 = "20060601";
							 
							 System.out.println("::::::::day --- date6--- ::::::::"+date6 );
							 //date6  deriving  logic End
							 //======== LEP Date1 to Date6 logic========================= - END
							 
							 //Calculating Max date as maximum of all the above 6 Dates
						 if(!lepCalFlag) {
								 
							 SortedSet<Date> dateSet = new TreeSet<Date>();
							 if(StringUtil.isNotNullNotEmptyNotWhiteSpace(date1)){
							 dateSet.add(dateformat.parse(date1));
							 }
							 if(StringUtil.isNotNullNotEmptyNotWhiteSpace(date2)){
							 dateSet.add(dateformat.parse(date2));
							 }
							 if(StringUtil.isNotNullNotEmptyNotWhiteSpace(date3)){
							 dateSet.add(dateformat.parse(date3));
							 }
							 if (reqDtCov.compareTo(ddob780m) > 0) {
						     if(StringUtil.isNotNullNotEmptyNotWhiteSpace(date4)){
							 dateSet.add(dateformat.parse(date4));
							  }
							 }
							 if(StringUtil.isNotNullNotEmptyNotWhiteSpace(date5)){
							 dateSet.add(dateformat.parse(date5));
							 }
							 if(StringUtil.isNotNullNotEmptyNotWhiteSpace(date6)){
							 dateSet.add(dateformat.parse(date6));
							 }
							 // Step 2
							 Date maxDate = dateSet.last();
							 
//							System.out.println("maxDate----> "+maxDate);
							 
							 //Step3
							// Date reqDtCov1 = dateformat.parse(DateMath.minusOneDay(objVO.getReqDtCov()));
							  
							// Start uncovMonths 
							Date reqDtCov1=null;
							 // calculating uncovMonths logic start
							 if(StringUtil.isNotNullNotEmptyNotWhiteSpace(objVO.getReqDtCov())){
							 reqDtCov1=dateformat.parse(DateMath.minusOneDay(dateformat.format(formatter.parse(objVO.getReqDtCov()))));
//							 System.out.println("reqDtCov1 :::::: "+reqDtCov1);
							 }		
							     Calendar cal1 = Calendar.getInstance();
								 Calendar cal2 = Calendar.getInstance();
							     cal1.setTime(reqDtCov1);
							     cal2.setTime(maxDate);
//							     System.out.println(":::::maxDate :::::::::: "+maxDate );
//							     System.out.println(":::::cal1.getTime() reqDtCov-1:::::::::: "+cal1.getTime() );
//							     System.out.println(":::::cal2.getTime() max date :::::::::: "+cal2.getTime() );
							     
								int days = DateMath.daysBetween(cal1.getTime(), cal2.getTime());
								System.out.println(":::::day"+days );
								 
//								SimpleDateFormat sdFormat = new SimpleDateFormat("MM/dd/yyyy");
//								String unCovStDt = formatter.format(maxDate);
								Setting  unCovStDt as first of the month -- start
								String maxDateString = 	dateformat.format(maxDate);
								String firstMaxDate = DateMath.getFirstOfMonth(maxDateString);
								String unCovStDt = DateFormatter.reFormat(firstMaxDate, DateFormatter.YYYYMMDD, DateFormatter.MM_DD_YYYY);
								objVO.setUncovMnthStrtDt(unCovStDt);
								Setting  unCovStDt as first of the month -- end
							 double dMonths =  (days/30.4);
								//System.out.println("::double :dMonths"+dMonths );
								 
							 int numcmo =getRoundedLepMonths(dMonths);
							// System.out.println("::numcmo"+numcmo );
							// calculating uncovMonths logic End
							 boolean lepRecordFlag = false;
					 		lepRecordFlag = eemDao.verifyLEPRecord(conn,objVO.getCustomerId(),objVO.getApplId());
					 		//Fetch LEP Application Existing Values - AT STATUAS
					 		//	Fix for IFOX-00388790: Start
					 		int befNuncmo = objVO.getNbrUnCMonths();
							objVO = eemDao.getLepExistingVal(conn,objVO);
							int aftNuncmo = objVO.getNbrUnCMonths();
							 if(numcmo >= 3){
								 objVO.setNbrUnCMonths(numcmo);
                                 if(!lepRecordFlag) {
                                	 rslt2 = eemDao.insertLEPApplDetails(conn, objVO);
                                	// if (rslt2 != 1) return false;
     									System.out.println(rslt2+" Record(s) inserted");
                                 }else {
                                	 if(aftNuncmo != numcmo){
                                		rslt2 =  eemDao.updateLEPApplDetails(conn, objVO);
                                	//if (rslt2 != 1) return false;
                                	 	System.out.println(rslt2+" Record(s) Updated");
                                	 }
                             	}
                                // Fix for IFOX-00388790: End
                              	//Derive OBC1 Timer Interval Days From EM_PROFILE table
    	 						// and add the Interval to the Current Date    							
    	 						String noOfDays = eemDao.getInterval(conn,objVO.getCustomerId());
    	 						String OBC1Days = noOfDays.substring(0,2);
    	 						int val = Integer.parseInt(OBC1Days);
    	 						System.out.println("OBC1Days:" + val);
    	 						
    	 						//int val = 30;
    		 					Calendar calendar = new GregorianCalendar();
    		 					calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + val);
    		 					
    		 					String strMonth = String.valueOf(calendar.get(Calendar.MONTH)+1);
    		 					if(strMonth.length() == 1)
    		 						strMonth = "0" + strMonth;
    		
    		 					String strDate = String.valueOf(calendar.get(Calendar.DATE));
    		 					if(strDate.length() == 1)
    		 						strDate = "0" + strDate;
    		 					//Insert OBC1 trigger
    		 					rslt1 = eemDao.openLEPApplTrigger(conn, objVO
    		 							.getCustomerId(), objVO.getApplId(),objVO.getOperId(), calendar.get(Calendar.YEAR) + strMonth + strDate);
    		 					//if (rslt1 != 1) return false;
    		 					
    		 				// Letters triggering functionality for Cambia  - Start	
    		 						
    		 						//Letters Part - Start
    		 						//Derive PRTD & RDS Cnt values From MBD table
    		 						objVO = eemDao.getPrtdRdsCnt(conn,objVO);
    		 						String planDesgn = objVO.getEnrollPlanDesgn();
    		 						//System.out.println("planDesgn ::"+planDesgn);
    		 						 Letters triggering functionality NEW -------  END
    		 						if (Integer.parseInt(objVO.getPrtdCnt()) > 1 || Integer.parseInt(objVO.getRdsCnt()) > 1){
    		 							
    		 							if(planDesgn!=null && planDesgn.equalsIgnoreCase("MAPD")){
    		 								String trigCode = eemDao.getTriggerCode(conn, EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_1, objVO.getCustomerId(), objVO.getEnrollPlanDesgn());
//    		 								String trigCode ="0401AD";
    		 								if(trigCode != null)
    		 								{
    		 									objVO.setTrigger_Type(trigCode);
    		 									rslt1 = eemDao.createApplLEPLetter(conn, objVO);
    		 								}
    		 							}else{
    		 								String trigCode = eemDao.getTriggerCode(conn, EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_1, objVO.getCustomerId(), objVO.getEnrollPlanDesgn());
//    		 								String trigCode ="0401AP";
    		 								if(trigCode != null)
    		 								{
    		 									objVO.setTrigger_Type(trigCode);
    		 									rslt1 = eemDao.createApplLEPLetter(conn, objVO);
    		 								}
    		 							}
    		 							
    		 						}//close if >1
    		 						else if(Integer.parseInt(objVO.getPrtdCnt()) == 1 || Integer.parseInt(objVO.getRdsCnt()) == 1){
    		 							if(prtDHistoryVO.getPrtdEDate().equalsIgnoreCase("00000000") && (rdsHistoryVO.getRdsEDate().equalsIgnoreCase("00000000")) ){
    		 								if(planDesgn!=null && planDesgn.equalsIgnoreCase("MAPD")){
    		 									String trigCode = eemDao.getTriggerCode(conn, EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_2, objVO.getCustomerId(), objVO.getEnrollPlanDesgn());
//    		 									String trigCode ="0401BD";
    		 									if(trigCode != null)
        		 								{
        		 									objVO.setTrigger_Type(trigCode);
        		 									rslt1 = eemDao.createApplLEPLetter(conn, objVO);
        		 								}
    		 								}else{
    		 									String trigCode = eemDao.getTriggerCode(conn, EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_2, objVO.getCustomerId(), objVO.getEnrollPlanDesgn());
//    		 									String trigCode ="0401BP";
    		 									if(trigCode != null)
        		 								{
        		 									objVO.setTrigger_Type(trigCode);
        		 									rslt1 = eemDao.createApplLEPLetter(conn, objVO);
        		 								}
    		 								}
    		 							}else{
    		 								if(planDesgn!=null && planDesgn.equalsIgnoreCase("MAPD")){
    		 									String trigCode = eemDao.getTriggerCode(conn, EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_1, objVO.getCustomerId(), objVO.getEnrollPlanDesgn());
//    		 									String trigCode ="0401AD";
    		 									if(trigCode != null)
        		 								{
        		 									objVO.setTrigger_Type(trigCode);
        		 									rslt1 = eemDao.createApplLEPLetter(conn, objVO);
        		 								}
    		 								}else{
    		 									String trigCode = eemDao.getTriggerCode(conn, EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_1, objVO.getCustomerId(), objVO.getEnrollPlanDesgn());
//    		 									String trigCode ="0401AP";
    		 									if(trigCode != null)
        		 								{
        		 									objVO.setTrigger_Type(trigCode);
        		 									rslt1 = eemDao.createApplLEPLetter(conn, objVO);
        		 								}
    		 								}
    		 							}
    		 						}//close else if =1
    		 						else if(Integer.parseInt(objVO.getPrtdCnt()) == 0 || Integer.parseInt(objVO.getRdsCnt()) == 0){
    		 							if(planDesgn!=null && planDesgn.equalsIgnoreCase("MAPD")){
		 									String trigCode = eemDao.getTriggerCode(conn, EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_2, objVO.getCustomerId(), objVO.getEnrollPlanDesgn());
//		 									String trigCode ="0401BD";
		 									if(trigCode != null)
    		 								{
    		 									objVO.setTrigger_Type(trigCode);
    		 									rslt1 = eemDao.createApplLEPLetter(conn, objVO);
    		 								}
		 								}else{
		 									String trigCode = eemDao.getTriggerCode(conn, EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_2, objVO.getCustomerId(), objVO.getEnrollPlanDesgn());
//		 									String trigCode ="0401BP";
		 									if(trigCode != null)
    		 								{
    		 									objVO.setTrigger_Type(trigCode);
    		 									rslt1 = eemDao.createApplLEPLetter(conn, objVO);
    		 								}
		 								}
    		 						}
    		 						 Letters triggering functionality NEW -------  END
    		 	// Letters triggering functionality for Cambia - End
    							 
							 } else //If uncovmonths <=3 Delete LEP record from EM_APPL_LEP table, Close OBC1/Letters
								{
									System.out.println("uncovmonths <=3 Case");
									rslt2 = eemDao.deleteLEPApplDetails(conn, objVO.getCustomerId(), objVO.getApplId());// deleting the LEP Details
									rslt2 = eemDao.closeOBCLettersTrigger(conn, objVO.getCustomerId(), objVO.getApplId());
								}
//                               //Derive OBC1 Timer Interval Days From EM_PROFILE table
//    	 						 // and add the Interval to the Current Date
//    							//end of uncovMonths $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
//    	 						String days12 = eemDao.getInterval(conn,objVO.getCustomerId());
//    	 						Integer val = Integer.parseInt(days12);
//    		 					Calendar calendar = new GregorianCalendar();
//    		 					calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + val);
//    		 					
//    		 					String strMonth = String.valueOf(calendar.get(Calendar.MONTH)+1);
//    		 					if(strMonth.length() == 1)
//    		 						strMonth = "0" + strMonth;
//    		
//    		 					String strDate = String.valueOf(calendar.get(Calendar.DATE));
//    		 					if(strDate.length() == 1)
//    		 						strDate = "0" + strDate;
//    		 					//Insert OBC1 trigger
//    		 					rslt1 = eemDao.openLEPApplTrigger(conn, objVO
//    		 							.getCustomerId(), objVO.getApplId(),objVO.getOperId(), calendar.get(Calendar.YEAR) + strMonth + strDate);
//    		 					//if (rslt1 != 1) return false;
    							 }
                       }//"MAPD and PDP Check"
                 }//"C" -- Main check        
		         
         }catch(Exception e){
         e.printStackTrace();
         }
		
		return true;
	}

	*/// original application strat

	
	//new LEP changes -- start
	
	private boolean setLEPUncovMnthCalC(EEMApplDao eemDao, Connection conn, EEMApplicationVO objVO) {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			/**
			 * Check whether this Application Id is having any row in
			 * EM_APPL_LEP table. If row exists then skip the below LEP
			 * calculation logic
			 */
			MBD mbd = objVO.getMbd();
			int rslt1, rslt2 = 0;
			boolean lepCalFlag = false;
			/**If member is Deceased, return false and don't calculate LEP data**/
			if(mbd.getLivingStatus().equalsIgnoreCase("D")){
				return true;
			}
			/**If election Type is IEP2, LEP should not calculate also remove the Uncvered months from PLEP table (If data is present)**/
			if("F".equalsIgnoreCase(objVO.getElectionType())){
				/** Update the existing code with Override as Y,if data exists in PLEP table**/
				/** Override all existing lep record based on the application id **/
				eemDao.overridePLepApplDetails(conn, objVO,"WEBAPPL");
				/** close the OBC1 Timer **/
				rslt2 = eemDao.closeOBCTimer(conn, objVO.getCustomerId(), objVO.getApplId());
				return true;
			}
			objVO = eemDao.getLepCalculationFlag(conn, objVO);
			//updated for IFOX-00390315
			boolean isReqDtCovChanged = true;
			boolean isHicNbrChanged = true;
			if(!objVO.getUpdateRec().equals("N")) {
				isReqDtCovChanged = eemDao.validateReqDtCov(conn, objVO);
				isHicNbrChanged = eemDao.validateHicNbrChanged(conn, objVO);
			}
			//00427630-OPEN : TSA Supress LEP process Platino Members - start
			boolean lepTrgSkip = eemDao.getLepPlatinoFlag(conn, objVO);
			//00427630-OPEN : TSA Supress LEP process Platino Members - end
			//00427630-OPEN : TSA Supress LEP process Platino Members - start
			if ((isReqDtCovChanged || isHicNbrChanged) && objVO.getLepCalcFlag() != null && objVO.getLepCalcFlag().equalsIgnoreCase("C")
					&& !lepTrgSkip
					) {
				//00427630-OPEN : TSA Supress LEP process Platino Members - end
				/**
				 * Below code commented for IFOX-00389231 //
				 if (assesPotentialUnCoveredMonths(conn, eemDao, objVO, mbd)) {
				 */
				/** Modified for IFOX-00389231 NEW LEP CR**/
				if(objVO.getEnrollPlanDesgn().equalsIgnoreCase("MAPD") || objVO.getEnrollPlanDesgn().equalsIgnoreCase("PDP") ){
					/** ======== LEP Date1 to Date6 logic============ - START */
					String lisEDate1 = "";
					String partDCovDate2 = "";
					String rdsEDate3 = "";
					String birthDate4 = "";
					String partDEligibilityDate5 = "";
					String lepInceptionDate6 = "";
					Date reqDtCov = null;
					Date rdsSDate = null;
					Date prtdSDate = null;
					String reqDtCovinString = "";

					PRTDHistoryVO prtDHistoryVO = new PRTDHistoryVO();
					RDSHistoryVO rdsHistoryVO = new RDSHistoryVO();
						// SSNRI changes 2017 : start
						String mbi = mbd.getMbi();
						// SSNRI changes 2017 : end 
					/** Getting PRTDHISTORY Data from by PRTDHISTORY */
					prtDHistoryVO.setHicNbr(mbd.getHicNbr());
						 //Modified for SSNRI 2017 : start
						// prtDHistoryVO = eemDao.getPRTDHistoryData(conn,prtDHistoryVO);
						 prtDHistoryVO = eemDao.getPRTDHistoryData(conn, prtDHistoryVO, mbi, mbd.getEligibilitySrcTable());
						 //Modified for SSNRI 2017 : end 

					/** Getting RDSHISTORY Data from by PRTDHISTORY */
					rdsHistoryVO.setHicNbr(mbd.getHicNbr());
						 //Modified for SSNRI 2017 : start
						// rdsHistoryVO = eemDao.getRDSHistoryData(conn,rdsHistoryVO);
						 rdsHistoryVO = eemDao.getRDSHistoryData(conn, rdsHistoryVO, mbi, mbd.getEligibilitySrcTable());
						//Modified for SSNRI 2017 : end
						 
					SimpleDateFormat dateformat = new SimpleDateFormat("yyyyMMdd");
					SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
					Date date = new Date();
					// String sSysDate = dateformat.format(date);
					// Date systemDate = dateformat.parse(sSysDate);
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(objVO.getReqDtCov())) {
						reqDtCov = formatter.parse(objVO.getReqDtCov());
						reqDtCovinString = dateformat.format(reqDtCov);
					}

					int copayLevelId1 = 0;
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(mbd.getCopayLevelId1())) {
						copayLevelId1 = Integer.parseInt(mbd.getCopayLevelId1());
					}
					/**
					 * If latest PRTD End Date for member is ZEROS and PRTD
					 * Start Date is less than request date of coverage. STOP LEP calculation.
					 */
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(prtDHistoryVO.getPrtdEDate())) {
						if (prtDHistoryVO.getPrtdEDate().equalsIgnoreCase("00000000")
								&& dateformat.parse(prtDHistoryVO.getPrtdSDate()).compareTo(reqDtCov) < 0) {
							lepCalFlag = true;
						}
					}
					/**
					 * If latest RDS End Date for the member is ZEROS and PRTD
					 * Start Date is less than system date. STOP LEP calculation.
					 */
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(rdsHistoryVO.getRdsSDate())) {
						if (rdsHistoryVO.getRdsEDate().equalsIgnoreCase("00000000")
								&& dateformat.parse(rdsHistoryVO.getRdsSDate()).compareTo(reqDtCov) < 0) {
							lepCalFlag = true;
						}
					}
					/**
					 * If (either of the Member Subsidy end date Equal to zeroes
					 * OR Member Subsidy end date greater than Requested date of
					 * coverage) AND (LIS copay level greater than ZERO).
					 * STOP LEP calculation.
					 */
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(mbd.getSubsidyEndDate1())) {
						if ((mbd.getSubsidyEndDate1().equalsIgnoreCase("00000000")
								|| mbd.getSubsidyEndDate1().compareTo(reqDtCovinString) > 0) && copayLevelId1 > 0) {
							lepCalFlag = true;

						} else if (mbd.getSubsidyEndDate1().compareTo(reqDtCovinString) < 0 && copayLevelId1 > 0) {
							if (!mbd.getSubsidyEndDate1().equalsIgnoreCase("00000000")) {
								lisEDate1 = DateMath.addOneDay(mbd.getSubsidyEndDate1());
							}

						} else {
							lisEDate1 = "00000000";
						}
					}
					logger.debug("::::::::day --- date1--- :::::::: " + lisEDate1);
					/** LIS date1 deriving logic End **/

					/** Past Part D Coverage Date2 deriving logic start */
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(prtDHistoryVO.getPrtdEDate())) {
						if (!prtDHistoryVO.getPrtdEDate().equalsIgnoreCase("00000000")) {
							partDCovDate2 = DateMath.addOneDay(prtDHistoryVO.getPrtdEDate());
						} else {
							if (StringUtil.isNotNullNotEmptyNotWhiteSpace(prtDHistoryVO.getPrtdSDate())) {
								prtdSDate = dateformat.parse(prtDHistoryVO.getPrtdSDate());
								// Fix for IFOX-00377647
								if (reqDtCov.compareTo(prtdSDate) > 0) {
								//Modified for SSNRI 2017 : start	 
									/* prtDHistoryVO = eemDao.getPRTDHistoryDataSeq(conn,prtDHistoryVO);*/
									 prtDHistoryVO = eemDao.getPRTDHistoryDataSeq(conn,prtDHistoryVO,mbi);
								//Modified for SSNRI 2017 : End 
									if (StringUtil.isNotNullNotEmptyNotWhiteSpace(prtDHistoryVO.getPrtdEDate()))
										partDCovDate2 = DateMath.addOneDay(prtDHistoryVO.getPrtdEDate());
									else
										partDCovDate2 = "00000000";

								} else {
									lepCalFlag = true;
								}
							} else {
								partDCovDate2 = "00000000";
							}
						}
					} else {
						partDCovDate2 = "00000000";
					}

					logger.debug("::::::::day --- date2--- ::::::::" + partDCovDate2);
					/** Past Part D Coverage date2 deriving logic end */

					/** RDS date3 deriving logic start */
					if (StringUtil.isNotNullNotEmptyNotWhiteSpace(rdsHistoryVO.getRdsEDate())) {
						if (!rdsHistoryVO.getRdsEDate().equalsIgnoreCase("00000000")) {
							rdsEDate3 = DateMath.addOneDay(rdsHistoryVO.getRdsEDate());
						} else {
							if (StringUtil.isNotNullNotEmptyNotWhiteSpace(rdsHistoryVO.getRdsSDate())) {
								rdsSDate = dateformat.parse(rdsHistoryVO.getRdsSDate());
								// Fix for IFOX-00377647
								if (reqDtCov.compareTo(rdsSDate) > 0) {
									 //Modified for SSNRI 2017 : start
									 /*rdsHistoryVO = eemDao.getRDSHistoryDataSeq(conn,rdsHistoryVO);*/
									 rdsHistoryVO = eemDao.getRDSHistoryDataSeq(conn,rdsHistoryVO,mbi);
									 //Modified for SSNRI 2017 : end 
									 //if(prtDHistoryVO.getPrtdEDate().equalsIgnoreCase("") && rdsHistoryVO.getRdsEDate() != null)
									if (StringUtil.isNotNullNotEmptyNotWhiteSpace(rdsHistoryVO.getRdsEDate())) {
										rdsEDate3 = DateMath.addOneDay(rdsHistoryVO.getRdsEDate());
									} else
										rdsEDate3 = "00000000";
								} else {
									lepCalFlag = true;
								}
							} else {
								rdsEDate3 = "00000000";
							}
						}
					} else {
						rdsEDate3 = "00000000";
					}

					logger.debug("::::::::day --- date3--- ::::::::" + rdsEDate3);
					/** RDS date3 deriving logic end **/

					/** 65th birthday + 4 months date4 deriving logic start */
					String sdob780m = DateMath.addMonth(mbd.getBirthDate(), 780);
					Date ddob780m = dateformat.parse(sdob780m);

					String sdob783m = DateMath.addMonth(mbd.getBirthDate(), 783);
					Date ddob783m = dateformat.parse(sdob783m);

					String sdob777m = DateMath.addMonth(mbd.getBirthDate(), 777);
					Date ddob777m = dateformat.parse(sdob777m);

					if (reqDtCov.compareTo(ddob777m) >= 0 && reqDtCov.compareTo(ddob783m) <= 0) {
						lepCalFlag = true;
					} else {
						if (reqDtCov.compareTo(ddob780m) < 0) {
							birthDate4 = "00000000";
						} else {
							/** Setting date4 as first of the month -- start */
							String tempDate4 = DateMath.addMonth(mbd.getBirthDate(), 784);
							birthDate4 = DateMath.getFirstOfMonth(tempDate4);
							logger.debug("tempDate4 ->" + tempDate4);
							logger.debug("date4 ->" + birthDate4);
							/** Setting date4 as first of the month -- end */

						}
					}
					logger.debug("::::::::day --- date4--- ::::::::" + birthDate4);
					/** 65th birthday + 4 months date4 deriving logic End */

					/**
					 * D Eligibility Date + 4 months date5 deriving logic start
					 */
					String sPrtDEligibleDate = mbd.getPrtDEligibleDate();
					Date dPrtDEligibleDat = dateformat.parse(mbd.getPrtDEligibleDate());
					if (reqDtCov.compareTo(dPrtDEligibleDat) >= 0) { // added equals in the condition for 00395222
							partDEligibilityDate5 = DateMath.addMonth(sPrtDEligibleDate, 4);
						} else {
							partDEligibilityDate5 = "00000000";
						}
					logger.debug("::::::::day --- date5--- ::::::::" + partDEligibilityDate5);
					/**
					 * D Eligibility Date + 4 months date5 deriving logic End
					 */

					/** LEP inception date6 deriving logic Start */
					lepInceptionDate6 = "20060601";

					logger.debug("::::::::day --- date6--- ::::::::" + lepInceptionDate6);
					/** LEP inception date6 deriving logic End */
					/**
					 * LEP Date1 to Date6 logic END
					 */

					// Calculating Max date as maximum of all the above 6 Dates
					if (!lepCalFlag) {
						SortedSet<Date> dateSet = new TreeSet<Date>();
						if (StringUtil.isNotNullNotEmptyNotWhiteSpace(lisEDate1)) {
							dateSet.add(dateformat.parse(lisEDate1));
						}
						if (StringUtil.isNotNullNotEmptyNotWhiteSpace(partDCovDate2)) {
							dateSet.add(dateformat.parse(partDCovDate2));
						}
						if (StringUtil.isNotNullNotEmptyNotWhiteSpace(rdsEDate3)) {
							dateSet.add(dateformat.parse(rdsEDate3));
						}
						if (reqDtCov.compareTo(ddob780m) > 0) {
							if (StringUtil.isNotNullNotEmptyNotWhiteSpace(birthDate4)) {
								dateSet.add(dateformat.parse(birthDate4));
							}
						}
						if (StringUtil.isNotNullNotEmptyNotWhiteSpace(partDEligibilityDate5)) {
							dateSet.add(dateformat.parse(partDEligibilityDate5));
						}
						if (StringUtil.isNotNullNotEmptyNotWhiteSpace(lepInceptionDate6)) {
							dateSet.add(dateformat.parse(lepInceptionDate6));
						}
						Date maxDate = dateSet.last();
						// IFOX -00431356 : LEP calculation with Part A termination in consideration-start
						String priorPrtAEndDate = mbd.getPrtAEntitleEDate2();
						Date latestPartAEntitleDate = dateformat.parse(mbd.getPrtAEntitleDate());
						System.out.println("Part A End Date "+ priorPrtAEndDate);
						System.out.println("Part A Date Latest"+ latestPartAEntitleDate);
						System.out.println("Part D Elig Date  "+ dPrtDEligibleDat);
						logger.debug("Part A End date 2"+ priorPrtAEndDate);
						if (StringUtil.isNotNullNotEmptyNotWhiteSpace(priorPrtAEndDate) &&
								(!priorPrtAEndDate.equalsIgnoreCase("00000000")) &&
										latestPartAEntitleDate.compareTo(dPrtDEligibleDat) > 0){
						maxDate = latestPartAEntitleDate;
								
						}
						
							// IFOX -00431356 : LEP calculation with Part A termination in consideration-end
							
						
						Date reqDateCov = null;
						/** calculating uncovMonths logic start */
						if (StringUtil.isNotNullNotEmptyNotWhiteSpace(objVO.getReqDtCov())) {
							reqDateCov = dateformat.parse(
									DateMath.minusOneDay(dateformat.format(formatter.parse(objVO.getReqDtCov()))));
						}
						Calendar cal1 = Calendar.getInstance();
						Calendar cal2 = Calendar.getInstance();
						cal1.setTime(reqDateCov);
						cal2.setTime(maxDate);
						logger.debug(":::::maxDate :::::::::: " + maxDate);

						int days = DateMath.daysBetween(cal1.getTime(), cal2.getTime());
						/**
						 * Setting unCovStDt as first of the month Max Date of
						 * from 6 Dates -- start
						 */
						String maxDateString = dateformat.format(maxDate);
						String firstDayOfMaxDate = DateMath.getFirstOfMonth(maxDateString);
						String unCovStDt = DateFormatter.reFormat(firstDayOfMaxDate, DateFormatter.YYYYMMDD,
								DateFormatter.MM_DD_YYYY);
						objVO.setUncovMnthStrtDt(unCovStDt);
						double dMonths = (days / 30.4);

						int uncoverMnths = getRoundedLepMonths(dMonths);
						/** New LEP changes -- start */
						/** Calculating Uncovered Month End Date start */

						String firstDdayOfUnCovEndDt = DateMath.addMonth(firstDayOfMaxDate, uncoverMnths);
						String lastDayOfunCovEndDt = DateMath.minusOneDay(firstDdayOfUnCovEndDt);
						objVO.setUncovMthEndDt(lastDayOfunCovEndDt);

						/** Calculating Uncovered months End Date End */
						/** New LEP changes -- End */
						/** calculating uncovMonths logic start */

						boolean isLEPRecordExist = false;
						isLEPRecordExist = eemDao.verifyLEPRecord(conn, objVO.getCustomerId(), objVO.getApplId());
						/** Fetch LEP Application Existing Values - AT STATUAS**/
						objVO = eemDao.getLepExistingVal(conn, objVO);
						/** If Uncovered months are greater than 3, then generate LEP else override with N if it is present.**/
						if (uncoverMnths > 3) {
							objVO.setNbrUnCMonths(uncoverMnths);
							/**
							 * If PLEP contains any records update with override
							 * 'Y' (Soft detele) else insert the calculated
							 * uncovered months.
							 */
							if (isLEPRecordExist) {
								/** delete (Override Y) existing records from PLEP table*/
								int updatedrRows = eemDao.overridePLepApplDetails(conn, objVO,"WEBAPPL");
								logger.debug(updatedrRows + " Record(s) override with Y successfully");
							}
							/**
							* Inserting new record with unmonths into PLEP
							* table.
							*/
							rslt2 = eemDao.insertLEPApplDetails(conn, objVO);
							logger.debug(rslt2 + " Record(s) inserted");
							
							/**
							 * Derive OBC1 Timer Interval Days From EM_PROFILE
							 * table and add the Interval to the Current Date
							 * START
							 */
							String noOfDays = eemDao.getInterval(conn, objVO.getCustomerId());
							String OBC1Days = noOfDays.substring(0, 2);
							int val = Integer.parseInt(OBC1Days);
							logger.debug("OBC1Days:" + val);

							Calendar calendar = new GregorianCalendar();
							calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + val);

							String strMonth = String.valueOf(calendar.get(Calendar.MONTH) + 1);
							if (strMonth.length() == 1)
								strMonth = "0" + strMonth;

							String strDate = String.valueOf(calendar.get(Calendar.DATE));
							if (strDate.length() == 1)
								strDate = "0" + strDate;
							/** Trigger OBC1 */
							if(!isDenied(objVO)){
								rslt1 = eemDao.openLEPApplTrigger(conn, objVO
									.getCustomerId(), objVO.getApplId(),objVO.getOperId(), calendar.get(Calendar.YEAR) + strMonth + strDate);
								if (rslt1 != 1) {
									logger.info(LoggerConstants.methodEndLevel());
									return false;
								}
							}
							//if()
							// Letters triggering functionality for Cambia - Start
							// Letters Part - Start
							// Derive PRTD & RDS Cnt values From MBD table
							objVO = eemDao.getPrtdRdsCnt(conn, objVO, mbd);
							String planDesgn = objVO.getEnrollPlanDesgn();
							/**
							 * Letters triggering functionality NEW ------- END
							 */
							if (Integer.parseInt(objVO.getPrtdCnt()) > 1 || Integer.parseInt(objVO.getRdsCnt()) > 1) {
								if (planDesgn != null && planDesgn.equalsIgnoreCase("MAPD")) {
									String trigCode = eemDao.getTriggerCode(conn,
											EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_1, objVO.getCustomerId(),
											objVO.getEnrollPlanDesgn());
									// String trigCode ="0401AD";
									if (trigCode != null) {
										objVO.setTrigger_Type(trigCode);
										rslt1 = eemDao.createApplLEPLetter(conn, objVO);
									}
								} else {
									String trigCode = eemDao.getTriggerCode(conn,
											EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_1, objVO.getCustomerId(),
											objVO.getEnrollPlanDesgn());
									// String trigCode ="0401AP";
									if (trigCode != null) {
										objVO.setTrigger_Type(trigCode);
										rslt1 = eemDao.createApplLEPLetter(conn, objVO);
									}
								}

							} // close if >1
							else if (Integer.parseInt(objVO.getPrtdCnt()) == 1
									|| Integer.parseInt(objVO.getRdsCnt()) == 1) {
								if (StringUtil.nonNullTrim(prtDHistoryVO.getPrtdEDate()).equalsIgnoreCase("00000000") 
										&& (StringUtil.nonNullTrim(rdsHistoryVO.getRdsEDate()).equalsIgnoreCase("00000000"))) {
									if (planDesgn != null && planDesgn.equalsIgnoreCase("MAPD")) {
										String trigCode = eemDao.getTriggerCode(conn,
												EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_2, objVO.getCustomerId(),
												objVO.getEnrollPlanDesgn());
										// String trigCode ="0401BD";
										if (trigCode != null) {
											objVO.setTrigger_Type(trigCode);
											rslt1 = eemDao.createApplLEPLetter(conn, objVO);
										}
									} else {
										String trigCode = eemDao.getTriggerCode(conn,
												EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_2, objVO.getCustomerId(),
												objVO.getEnrollPlanDesgn());
										// String trigCode ="0401BP";
										if (trigCode != null) {
											objVO.setTrigger_Type(trigCode);
											rslt1 = eemDao.createApplLEPLetter(conn, objVO);
										}
									}
								} else {
									if (planDesgn != null && planDesgn.equalsIgnoreCase("MAPD")) {
										String trigCode = eemDao.getTriggerCode(conn,
												EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_1, objVO.getCustomerId(),
												objVO.getEnrollPlanDesgn());
										// String trigCode ="0401AD";
										if (trigCode != null) {
											objVO.setTrigger_Type(trigCode);
											rslt1 = eemDao.createApplLEPLetter(conn, objVO);
										}
									} else {
										String trigCode = eemDao.getTriggerCode(conn,
												EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_1, objVO.getCustomerId(),
												objVO.getEnrollPlanDesgn());
										// String trigCode ="0401AP";
										if (trigCode != null) {
											objVO.setTrigger_Type(trigCode);
											rslt1 = eemDao.createApplLEPLetter(conn, objVO);
										}
									}
								}
							} // close else if =1
							//else if (Integer.parseInt(objVO.getPrtdCnt()) == 0 || Integer.parseInt(objVO.getRdsCnt()) == 0) {
							//Set the default condition, same as MF logic.
							else {	
								if (planDesgn != null && planDesgn.equalsIgnoreCase("MAPD")) {
									String trigCode = eemDao.getTriggerCode(conn,
											EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_2, objVO.getCustomerId(),
											objVO.getEnrollPlanDesgn());
									// String trigCode ="0401BD";
									if (trigCode != null) {
										objVO.setTrigger_Type(trigCode);
										rslt1 = eemDao.createApplLEPLetter(conn, objVO);
									}
								} else {
									String trigCode = eemDao.getTriggerCode(conn,
											EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_2, objVO.getCustomerId(),
											objVO.getEnrollPlanDesgn());
									// String trigCode ="0401BP";
									if (trigCode != null) {
										objVO.setTrigger_Type(trigCode);
										rslt1 = eemDao.createApplLEPLetter(conn, objVO);
									}
								}
							}
							/**
							 * Letters triggering functionality NEW ------- END
							 */

						} /** If uncovmonths less than 3 Override with 'Y' LEP record from EM_APPL_PLEP table, Close OBC1/Letters*/
						else{
							logger.debug("uncovmonths greater than 3 Case");
							/** Override all existing lep record based on the application id **/
							eemDao.overridePLepApplDetails(conn, objVO,"WEBAPPL");
							/** close the OBC1 Timer **/
							rslt2 = eemDao.closeOBCTimer(conn, objVO.getCustomerId(), objVO.getApplId());
						}
					}else if(isHicNbrChanged || isReqDtCovChanged){ // Retro-fitted from Excellus defects 395392 and 395393 
						logger.debug("New Hic Number has not uncovered months.");
						/** Override all existing lep record based on the application id **/
						eemDao.overridePLepApplDetails(conn, objVO,"WEBAPPL");
						/** close the OBC1 Timer **/
						rslt2 = eemDao.closeOBCTimer(conn, objVO.getCustomerId(), objVO.getApplId());
					}
				} // "MAPD and PDP Check"
			} // "C" -- Main check

		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Error Details: " + e.getMessage());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return true;
	}
	//new LEP changes -- end


	
	public Boolean checkOrigApplRecords(Connection conn, EEMApplicationVO objVO) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		boolean check=false;
		try{
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
		    check = eemDao.getOrigAppl(conn, objVO.getApplId(), objVO.getCustomerId());
		}
		catch(Exception e){
			//e.printStackTrace();
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Checking records :Error "+ e.getMessage());
			throw new ApplicationException(e);
		}
		logger.debug("Check whether original records : End");
		logger.info(LoggerConstants.methodEndLevel());
		return check;
		
	}
	//original application end

	public boolean isCancelOrDenied(EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String applStatus = StringUtil.nonNullTrim(objVO.getApplStatus());
		if (applStatus.equals(EEMConstants.APPL_STATUS_CANCELED) || 
				applStatus.equals(EEMConstants.APPL_STATUS_DENIEDELG) ||
				applStatus.equals(EEMConstants.APPL_STATUS_DENIEDETYP) ||
				applStatus.equals(EEMConstants.APPL_STATUS_DENIEDOTHR)) {
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}
		logger.info(LoggerConstants.methodEndLevel());
		return false;
	}
	
	public String getLockInd(Connection conn, String applStatus) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
		logger.info(LoggerConstants.methodEndLevel());
		return eemDao.getLockInd(conn, applStatus);
	}
	
	public boolean checkLISStatus(Connection conn, EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
		logger.info(LoggerConstants.methodEndLevel());
		return eemDao.checkLISStatus(conn, objVO);
	}	
	
	public boolean checkMember(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			if (objVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_MA) || 
					objVO.getApplType().equals(EEMConstants.OPTION_CNTRCHG_MA)) {
				return eemDao.checkMAPDMember(conn, objVO);
			} else if (objVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_PD) || 
					objVO.getApplType().equals(EEMConstants.OPTION_CNTRCHG_PD)) {
				return eemDao.checkPDPMember(conn, objVO);
			}
		} catch(Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			objVO.setMessage("Error during Member Check.");
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		logger.info(LoggerConstants.methodEndLevel());
		return false;
	}
	
	public boolean getMemberDetails(Connection conn, String eemDb, EEMApplicationVO objVO, boolean isUpdate)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		boolean check = false;
		String beqCheck = null;
		try {
			beqCheck = EEMProfileSettings.getCalendarProfileItem(eemDb,
					objVO.getCustomerId(), EEMProfileSettings.BEQCHECK);
			logger.debug("MBDPersistence.get()::beqCheck:::" + beqCheck);
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			// Eligibility Check
			String elgOveride = EEMProfileSettings.getCalendarProfileItem(
					eemDb, objVO.getCustomerId(), EEMProfileSettings.ELGOVERIDE);
			objVO.setEligOverrideInd(checkEligOverrideInd(objVO));
			//Duplicate Application Fix-Start
			String value = objVO.getUpdateRec();
			//Duplicate Application Fix-End
			if (elgOveride.equals("Y")) {
				//SSNRI 2017 Changes : start
				MBD mbd = verifyEligibility(conn, objVO.getMbrHicNbr(),
						objVO.getMbrLastName(), objVO.getMbrBirthDt(), eemDb,
						objVO.getCustomerNbr(), beqCheck,objVO.getIsHicOrMbi());
				//SSNRI 2017 Changes : end
				// Set the member details
				if (mbd != null) {
					 // BEQ Short term solution --Start
					String prtAStDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getPartAEffDt()));
					String prtBStDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getPartBEffDt()));
					String prtDDate = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getPartDEffDt()));
									
					String prtAMbd = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtAEntitleDate()));
					String prtBMbd = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtBEntitleDate()));
					String prtDMbd = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtDEligibleDate()));
					
					if(!((StringUtil.nonNullTrim(prtAStDt).equalsIgnoreCase(StringUtil.nonNullTrim(prtAMbd))) &
										(StringUtil.nonNullTrim(prtBStDt).equalsIgnoreCase(StringUtil.nonNullTrim(prtBMbd))) &
										(StringUtil.nonNullTrim(prtDDate).equalsIgnoreCase(StringUtil.nonNullTrim(prtDMbd)))) && 
										!((StringUtil.nonNullTrim(prtAStDt).equals("")) & (StringUtil.nonNullTrim(prtBStDt).equals("")) & 
												(StringUtil.nonNullTrim(prtDDate).equals(""))) ){
						objVO.setEligOverrideInd("Y");
					}else{
						objVO.setEligOverrideInd("N");
					}
					  // BEQ Short term solution --End
					objVO.setMbd(mbd);
					objVO.setDtLstChked(new DateUtil().getDB2DTS());
					if(!isUpdate){
						setMBDValues(mbd, objVO); //IFOX-409315
					}
					objVO.setMbrXrefNbr(objVO.getMbd().getXrefClaimNbr()); // IFOX-00397126
					objVO.setNeedMBDUpdate("Y");
				} else {
					// SSNRI defect tracker 108.
					//String xrefNbr = eemDao.getxrefnbr(conn,objVO.getMbrHicNbr()); // IFOX-00397126
					//objVO.setMbrXrefNbr(xrefNbr); // IFOX-00397126
					objVO.setMbrXrefNbr("");
					objVO.setDisplayHic(objVO.getMbrHicNbr());// SSNRI defect tracker 108.
					objVO.setMbd(new MBD());
					objVO.setDtLstChked("00/00/0000");
					if (!isUpdate) {
						resetMBDValues(objVO);	
					}
					objVO.setNeedMBDUpdate("N");
					objVO.setMessage("Eligibility not found.");
					check = true;
					// Customer preference BEQCHECK = 'Y'
					//String beqCheck = EEMProfileSettings.getCalendarProfileItem(conn, objVO
					//		.getCustomerId(), EEMProfileSettings.BEQCHECK);
					//if (StringUtil.nonNullTrim(beqCheck).equals("Y")) {
					//	objVO.setMessage("BEQ Check Pending.");
					//}
				}
			}
			
			// Prior member check
			EEMApplicationVO memberVO = new EEMApplicationVO();
			memberVO.setCustomerId(objVO.getCustomerId());
			memberVO.setMbrHicNbr(objVO.getMbrHicNbr());
			//SSNRI 2017 changes : start
			memberVO.setMbiNbr(objVO.getMbiNbr());
			memberVO.setDisplayHic(objVO.getDisplayHic());
			//SSNRI 2017 changes : end
			memberVO.setReqDtCov(objVO.getReqDtCov());

			// Constructor sets these values
			// set to null to prevent copy unless they are read
			memberVO.setElcDerivedInd(null);
			memberVO.setPcpCurrPatnt(null);
			memberVO.setEsrd(null);
			memberVO.setDialysis(null);
			memberVO.setDrugCov(null);
			memberVO.setLongTerm(null);
			memberVO.setStMedicaid(null);
			memberVO.setSpouseWork(null);
			memberVO.setSignOnFile(null);
			memberVO.setDoYouWork(null);  /* IFOX-00431133 -CMS Changes Start*/  
			
			String plan = "";
			
	//IFOX-00377758 included the below if condition - Start
	// IFOX-00382607: Retro Application CR - Start
			boolean isNewApp = true;		
		//if(!isUpdate){
	// IFOX-00382607: Retro Application CR - End
			if (eemDao.getMemberDetails(conn, memberVO, plan)) {
				// Check for Retro application
				// IFOX-00382607: Retro Application CR - Start
				/*if (!StringUtil.nonNullTrim(memberVO.getEnrollEndDate()).equals(EEMConstants.EFF_END_DATE)) {
					objVO.setMessage("Retro Application Detected.");
				} else {
					
									
					if (!StringUtil.nonNullTrim(objVO.getMbrId()).equals(StringUtil.nonNullTrim(memberVO.getMbrId()))) {*/
				if(objVO.getEnrollPlan() == null || objVO.getEnrollPlan().equals("") || objVO.getEnrollPlan().equalsIgnoreCase(memberVO.getCurrPlan())){
					isNewApp = false;
				}
				// IFOX-00382607: Retro Application CR - End
					// Previous Member Override indicator from Profile
				//Added as fix for IFOX:  00386712 :start
				if (StringUtil.nonNullTrim(objVO.getMbrId()).equals("") &&
						!StringUtil.nonNullTrim(objVO.getMbrId()).equals(StringUtil.nonNullTrim(memberVO.getMbrId()))) {
					//Added as fix for IFOX:  00386712 :end
					String membOvr = EEMProfileSettings.getCalendarProfileItem(
							eemDb, objVO.getCustomerId(), EEMProfileSettings.PREVMBROVR);
					// Set the product Name
					memberVO.setCurrProdName(eemDao.getProductName(conn,
							memberVO.getCustomerId(),
							memberVO.getCurrProduct(), objVO.getReqDtCov()));

					// Set the Group Name
					memberVO.setCurrGroupName(eemDao.getGroupName(conn, 
							memberVO.getCustomerId(), 
							memberVO.getCurrGroup(), objVO.getReqDtCov()));
					
					if (StringUtil.nonNullTrim(membOvr).equals("Y")) {
						// Get Agent details
						eemDao.getMbrAgentDetails(conn, memberVO);
						getAddressDetails(eemDao, conn, memberVO, false);
						setPriorMembValues(memberVO, objVO, false);
						
					} else if (StringUtil.nonNullTrim(membOvr).equals("N")) {
						// Set Group product details
						objVO.setCurrGroup(memberVO.getCurrGroup());
							objVO.setCurrGroupName(memberVO.getCurrGroupName());
						objVO.setCurrPbp(memberVO.getCurrPbp());
						objVO.setCurrPlan(memberVO.getCurrPlan());
						objVO.setCurrPlanDesgn(memberVO.getCurrPlanDesgn());
						objVO.setCurrProdName(memberVO.getCurrProdName());
						objVO.setCurrProduct(memberVO.getCurrProduct());
						objVO.setCurrPymtAmt(memberVO.getCurrPymtAmt());
						objVO.setCurrSegment(memberVO.getCurrSegment());
						}
				}
					// Set the Application Type
					String planDesgn = memberVO.getCurrPlanDesgn();
					
					if (planDesgn != null) {
						if (planDesgn.equals("PDP")) {
							objVO.setApplType(EEMConstants.OPTION_CNTRCHG_PD);
						} else {
							objVO.setApplType(EEMConstants.OPTION_CNTRCHG_MA);
						}
					}
					
					//Added as fix for IFOX:  00386712 :start
					String enrollplanDesgn = objVO.getEnrollPlanDesgn();
					if(enrollplanDesgn != null && !enrollplanDesgn.equals("")){
						if(planDesgn != enrollplanDesgn){
							if (enrollplanDesgn.equals("PDP")) {
								objVO.setApplType(EEMConstants.OPTION_CNTRCHG_PD);
							} else {
								objVO.setApplType(EEMConstants.OPTION_CNTRCHG_MA);
							}
						}
					}
					//Added as fix for IFOX:  00386712 - end
			// IFOX-00382607: Retro Application CR - Start
				//}
				
			//} else {// Member doesn't exist
		}
			 if(isNewApp) {// Member doesn't exist
			// IFOX-00382607: Retro Application CR - End
				if (objVO.getApplType().equals(EEMConstants.OPTION_CNTRCHG_MA)) {
					objVO.setApplType(EEMConstants.OPTION_APPLNEWMBR_MA);
				} else if (objVO.getApplType().equals(EEMConstants.OPTION_CNTRCHG_PD)) {
					objVO.setApplType(EEMConstants.OPTION_APPLNEWMBR_PD);
				}
				
				
				if (eemDao.getPriorMemberDetails(conn, memberVO, plan)) {
					// Previous Member Override indicator from Profile
					String membOvr = EEMProfileSettings.getCalendarProfileItem(
							eemDb, objVO.getCustomerId(), EEMProfileSettings.PREVMBROVR);
					
					// Check for member Id mismatch
					if (!StringUtil.nonNullTrim(objVO.getMbrId()).equals(StringUtil.nonNullTrim(memberVO.getMbrId()))) {
					// IFOX-00382128: To Disable Termed Member Info populated in the App Entry Page - Start					
					objVO.setAltMbrId(memberVO.getAltMbrId());
					objVO.setMbrRxId(memberVO.getMbrRxId());
					objVO.setMbrId(memberVO.getMbrId());
					/*if (StringUtil.nonNullTrim(membOvr).equals("Y")) {
						getAddressDetails(eemDao, conn, memberVO, false);
							setPriorMembValues(memberVO, objVO, false);
						}*/
					// IFOX-00382128: To Disable Termed Member Info populated in the App Entry Page - End
					}
				} else {
					// Check both member ids are blank.
					if (!StringUtil.nonNullTrim(objVO.getMbrId()).equals(StringUtil.nonNullTrim(memberVO.getMbrId()))) {
						resetAddressValues(objVO);
						resetPriorMembValues(objVO);
					}
				}				
				
			}
	// IFOX-00382607: Retro Application CR - Start
		//}
	// IFOX-00382607: Retro Application CR - End
		//IFOX-00377758 included the below if condition - END
			// No errors
			if (StringUtil.nonNullTrim(objVO.getMessage()).equals("")) {
				check = true;
				objVO.setMessage("Member Check done.");
			}
			objVO.setIsChanged("Y");
	//Duplicate Application Fix-Start
			objVO.setUpdateRec(value);
			//Duplicate Application Fix-End
		} catch(Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			objVO.setMessage("Error during Member Retrieval.");
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return check;
	}
	
	private void resetPriorMembValues(EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		objVO.setMbrId("");
		objVO.setAltMbrId("");
		objVO.setMbrLastName("");
		objVO.setMbrFirstName("");
		objVO.setMbrMiddleName("");
		objVO.setMbrPrefix("");
		objVO.setMailLastName("");
		objVO.setMailFirstName("");
		objVO.setMailMiddleName("");
		objVO.setInsCardName("");
		objVO.setMbrSsn("");
		objVO.setMbrBirthDt(DateUtil.formatMmDdYyyy(""));
		objVO.setMbrGender("");
		objVO.setMbrEmail("");
		objVO.setAuthRepFirstName("");
		objVO.setAuthRepMidName("");
		objVO.setAuthRepLastName("");
		objVO.setAuthRepRelation("");
		objVO.setEmergName("");
		objVO.setEmergPhone("");
		objVO.setEmergRelation("");
		objVO.setEmail("");
		objVO.setLanguage("");
		objVO.setSpouseWork("");
		objVO.setDoYouWork("");  /* IFOX-00431133 -CMS Changes Start*/  
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	private void resetAddressValues(EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		objVO.setPerAdd1("");
		objVO.setPerAdd2("");
		objVO.setPerAdd3("");
		objVO.setPerCity("");
		objVO.setPerState("");
		objVO.setPerZip5("");
		objVO.setPerZip4("");
		objVO.setPerCounty("");
		objVO.setPerPhone("");
		objVO.setPerCell("");
		objVO.setPerWorkPhone("");
		objVO.setPerFax("");
		
		objVO.setMailAdd1("");
		objVO.setMailAdd2("");
		objVO.setMailAdd3("");
		objVO.setMailCity("");
		objVO.setMailState("");
		objVO.setMailZip5("");
		objVO.setMailZip4("");
		objVO.setMailCountry("");
		
		objVO.setAuthRepStreet("");
		objVO.setAuthRepCity("");
		objVO.setAuthRepState("");
		objVO.setAuthRepZip5("");
		objVO.setAuthRepZip4("");
		objVO.setAuthRepPhone("");
		objVO.setLstUpdtAuthAddr("");
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	private void setMBDValues(MBD mbd, EEMApplicationVO objVO)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		  // BEQ Short term solution --Start
		//SSNRI 2017 changes : start
		
		
		if(!StringUtil.nonNullTrim(mbd.getMbi()).isEmpty()){
			objVO.setMbrHicNbr(StringUtil.nonNullTrim(mbd.getMbi()));
			objVO.setMbiNbr(StringUtil.nonNullTrim(mbd.getMbi()));
		}
		objVO.setDisplayHic(StringUtil.nonNullTrim(mbd.getHicNbr()));
		if(StringUtil.nonNullTrim(objVO.getIsHicOrMbi()).isEmpty()){
			objVO.setMbrHicNbr(StringUtil.nonNullTrim(mbd.getHicNbr()));
		}
		//SSNRI 2017 changes : end 
		if(objVO.getEligOverrideInd().equalsIgnoreCase("N")){
			objVO.setPartAEffDt(DateFormatter.reFormat(mbd.getPrtAEntitleDate(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
		objVO.setPartBEffDt(DateFormatter.reFormat(mbd.getPrtBEntitleDate(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
		objVO.setPartDEffDt(DateFormatter.reFormat(mbd.getPrtDEligibleDate(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
	}
		 

		/*objVO.setPartAEffDt("");
		if (mbd.getPrtAEntitleEndDate().equals("00000000"))
			if (!mbd.getPrtAEntitleDate().equals("00000000"))
				objVO.setPartAEffDt(DateFormatter.reFormat(mbd.getPrtAEntitleDate(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));

		objVO.setPartBEffDt("");
		if (mbd.getPrtBEntitleEndDate().equals("00000000"))
			if (!mbd.getPrtBEntitleDate().equals("00000000"))
				objVO.setPartBEffDt(DateFormatter.reFormat(mbd.getPrtBEntitleDate(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));

		objVO.setPartDEffDt("");
		if (!mbd.getPrtDEligibleDate().equals("00000000"))
			objVO.setPartDEffDt(DateFormatter.reFormat(mbd.getPrtDEligibleDate(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
	*/ 
		// BEQ Short term solution --End
		if (StringUtil.nonNullTrim(objVO.getMbrFirstName()).equals(""))
			objVO.setMbrFirstName(mbd.getFirstName());

		if (StringUtil.nonNullTrim(objVO.getMbrLastName()).equals(""))
			objVO.setMbrLastName(mbd.getLastName());
			
		if (StringUtil.nonNullTrim(objVO.getMbrMiddleName()).equals(""))
			objVO.setMbrMiddleName(mbd.getMiddleInit());
		// Start IFOX-00397126
		if(mbd.isIshicxref() == true){
		if (StringUtil.nonNullTrim(objVO.getMbrXrefNbr()).equals(""))
			objVO.setMbrXrefNbr(mbd.getXrefClaimNbr());
		
			objVO.setMbrHicNbr(mbd.getHicNbr());
		}else{
			if (StringUtil.nonNullTrim(objVO.getMbrXrefNbr()).equals(""))
				objVO.setMbrXrefNbr(mbd.getXrefClaimNbr());
		}
		// Start IFOX-00397126

		if (StringUtil.nonNullTrim(objVO.getMbrBirthDt()).equals(""))
			objVO.setMbrBirthDt(DateFormatter.reFormat(mbd.getBirthDate(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
		
		if (StringUtil.nonNullTrim(objVO.getMbrGender()).equals(""))
			objVO.setMbrGender(getApplGender(mbd.getGenderCd()));

		//if (StringUtil.nonNullTrim(objVO.getPerState()).equals(""))
			//objVO.setPerState(mbd.getStateCd());
		
		// ESRD
		if (StringUtil.nonNullTrim(objVO.getEsrdChange()).equals("")) {
			objVO.setEsrd(getInd(mbd.getEsrdInd()));
		}
		if (StringUtil.nonNullTrim(objVO.getEsrd()).equals("Y")) {
			objVO.setEsrdStDt(DateFormatter.reFormat(mbd.getEsrdStartDate(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
			objVO.setEsrdEndDt(DateFormatter.reFormat(mbd.getEsrdEndDate(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));	
		} else {
			objVO.setPcoInd("N");
			objVO.setEsrdStDt("");
			objVO.setEsrdEndDt("");
		}
		
		// Institutional
		if (StringUtil.nonNullTrim(objVO.getLongTermChange()).equals("")) {
			objVO.setLongTerm(getInd(mbd.getInstInd()));
		}
		if (StringUtil.nonNullTrim(objVO.getLongTerm()).equals("Y")) {
			objVO.setLongTermStDt(DateFormatter.reFormat(mbd.getInstStartDate(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
			objVO.setLongTermEndDt(DateFormatter.reFormat(mbd.getInstEndDate(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
		} else {
			objVO.setNameInstitute("");
			objVO.setInstStreet("");
			objVO.setInstPhoneNo("");
			objVO.setLongTermStDt("");
			objVO.setLongTermEndDt("");
		}
		
		// Medicaid
		if (StringUtil.nonNullTrim(objVO.getMedicaidChange()).equals("")) {
			objVO.setStMedicaid(getInd(mbd.getMedicInd()));
		}
		if (StringUtil.nonNullTrim(objVO.getStMedicaid()).equals("Y")) {
			objVO.setMedicaidStDt(DateFormatter.reFormat(mbd.getMedicStartDate(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
			objVO.setMedicaidEndDt(DateFormatter.reFormat(mbd.getMedicEndDate(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
		} else {
			objVO.setMedicaidStDt("");
			objVO.setMedicaidEndDt("");
			objVO.setMedicaidId("");
		}
		//IFOX-409315 - Start
		//Cambia Lis -Start
		//if (StringUtil.nonNullTrim(objVO.getApplId()).equals("")){// inserts values only at elig..check.
			
				if(  (!(StringUtil.nonNullTrim(mbd.getSubsidyStartDate1()).equals("00000000")))   &&  
						 DateMath.isBetween(
								 DateFormatter.reFormat((objVO.getReqDtCov()),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD), 
								 StringUtil.nonNullTrim(mbd.getSubsidyStartDate1()), 
								 StringUtil.nonNullTrim(mbd.getSubsidyEndDate1()).equals("00000000") ? "99999999" : StringUtil.nonNullTrim(mbd.getSubsidyEndDate1())) 
				){//LIS starte date as �00000000� , we assume that is no LIS.

/*						if (!StringUtil.nonNullTrim(objVO.getLisEffStartDate()).equals("")) {
							objVO.setLisEffStartDate(DateFormatter.reFormat(
									mbd.getSubsidyStartDate1(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
						}
						if (!StringUtil.nonNullTrim(objVO.getLisEffEndDate()).equals("")) {
										objVO.setLisEffEndDate(StringUtil.nonNullTrim(mbd.getSubsidyEndDate1()).equals("00000000") ? "99/99/9999" : DateFormatter.reFormat(
									mbd.getSubsidyEndDate1(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));//LIS End date as Ѱ00000000Ҡ, we assume this as open ended 
								//objVO.setLisEffEndDate(DateFormatter.reFormat(mbd.getSubsidyEndDate1(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
						}
						if (!StringUtil.nonNullTrim(objVO.getLiCoPayCd()).equals("")) {
							objVO.setLiCoPayCd(mbd.getCopayLevelId1());
						}                
						if (!StringUtil.nonNullTrim(objVO.getLisPctCd()).equals("")) {
							objVO.setLisPctCd(mbd.getPartDPremsubsPct1());
						}*/
						
						objVO.setLisEffStartDate(DateFormatter.reFormat(mbd.getSubsidyStartDate1(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
						objVO.setLisEffEndDate(StringUtil.nonNullTrim(mbd.getSubsidyEndDate1()).equals("00000000") ? "99/99/9999" : DateFormatter.reFormat(mbd.getSubsidyEndDate1(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));//LIS End date as Ѱ00000000Ҡ, we assume this as open ended 
						objVO.setLiCoPayCd(mbd.getCopayLevelId1());
						objVO.setLisPctCd(mbd.getPartDPremsubsPct1());
				}
				else if(  (!(StringUtil.nonNullTrim(mbd.getSubsidyStartDate2()).equals("00000000")))   &&  
						DateMath.isBetween(DateFormatter.reFormat((objVO.getReqDtCov()),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD), StringUtil.nonNullTrim(mbd.getSubsidyStartDate2()), StringUtil.nonNullTrim(mbd.getSubsidyEndDate2()).equals("00000000") ? "99999999" : StringUtil.nonNullTrim(mbd.getSubsidyEndDate2()))  ){//LIS starte date as �00000000� , we assume that is no LIS.
             

/*						if (!StringUtil.nonNullTrim(objVO.getLisEffStartDate()).equals("")) {
							objVO.setLisEffStartDate(DateFormatter.reFormat(mbd.getSubsidyStartDate2(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
						}
						if (!StringUtil.nonNullTrim(objVO.getLisEffEndDate()).equals("")) {
							objVO.setLisEffEndDate(StringUtil.nonNullTrim(mbd.getSubsidyEndDate2()).equals("00000000") ? "99/99/9999" : DateFormatter.reFormat(mbd.getSubsidyEndDate2(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));//LIS End date as Ѱ00000000Ҡ, we assume this as open ended 
						}
						if (!StringUtil.nonNullTrim(objVO.getLiCoPayCd()).equals("")) {
							objVO.setLiCoPayCd(mbd.getCopayLevelId2());
						}
						if (!StringUtil.nonNullTrim(objVO.getLisPctCd()).equals("")) {
							objVO.setLisPctCd(mbd.getPartDPremsubsPct2());
						}*/
						
						objVO.setLisEffStartDate(DateFormatter.reFormat(mbd.getSubsidyStartDate2(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
						objVO.setLisEffEndDate(StringUtil.nonNullTrim(mbd.getSubsidyEndDate2()).equals("00000000") ? "99/99/9999" : DateFormatter.reFormat(mbd.getSubsidyEndDate2(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));//LIS End date as Ѱ00000000Ҡ, we assume this as open ended
						objVO.setLiCoPayCd(mbd.getCopayLevelId2());
						objVO.setLisPctCd(mbd.getPartDPremsubsPct2());
				}//else if
				else{
					objVO.setLisEffStartDate("");
					objVO.setLisEffEndDate("");
					objVO.setLiCoPayCd("");
					objVO.setLisPctCd("");
				}
				logger.info(LoggerConstants.methodEndLevel());
				//IFOX-409315 - End
			
				//else
		//}//if (StringUtil.nonNullTrim(objVO.getApplId()).equals("")){
		//Cambia Lis -End

	}
	
	private void resetMBDValues(EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		objVO.setPartAEffDt("");
		objVO.setPartBEffDt("");
		objVO.setPartDEffDt("");
		//objVO.setMbrGender("");
		//objVO.setPerState("");
		//objVO.setEsrd("N");
		//objVO.setLongTerm("N");
		//objVO.setStMedicaid("N");
		objVO.setEsrdStDt("");
		objVO.setEsrdEndDt("");
		objVO.setLongTermStDt("");
		objVO.setLongTermEndDt("");
		objVO.setMedicaidStDt("");
		objVO.setMedicaidEndDt("");
		objVO.setLisEffStartDate("");
		objVO.setLisEffEndDate("");
		objVO.setLiCoPayCd("");
		objVO.setLisPctCd("");
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	private String getInd(String value) {
		logger.info(LoggerConstants.methodStartLevel());
		if (StringUtil.nonNullTrim(value).equals("") || StringUtil.nonNullTrim(value).equals("1")) {
			logger.info(LoggerConstants.methodEndLevel());
			return "N";
		}
		logger.info(LoggerConstants.methodEndLevel());
		//IFOX - 431608 : CMS Changes 2020- ESRD Fix
		//return "Y";
		return value;
		//IFOX - 431608 : CMS Changes 2020- ESRD Fix
	}
	
	private void setPriorMembValues(EEMApplicationVO memberVO,
			EEMApplicationVO objVO, boolean checkBlank) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			Class objClass = Class.forName(EEMConstants.EEM_APPL_FILTER);
			Object srcVal = null;
			Object dstVal = null;
			Field field = null;

			// Get the declared variables array
			Field[] fld = objClass.getDeclaredFields();
			for (int i = 0; i < fld.length; i++) {
				String name = fld[i].getName();
				
				// Check for RxId
				if (name.equals("mbrRxId") && 
						StringUtil.nonNullTrim(objVO.getEnrollPlanDesgn()).equals(EEMConstants.PLAN_DESGN_MA)) {
					continue;
				}
				// Check for electionType
				if (name.equals("electionType"))
					continue;
				// Check for DtLstChked
				if (name.equals("dtLstChked"))
					continue;
				
				field = objClass.getDeclaredField(name);
				
				// Check for String variables
				if (field.getType().toString().equals("class java.lang.String")) {
					field.setAccessible(true);
					srcVal = field.get(objVO);
					dstVal = field.get(memberVO);
					
					// Check for blank values 
					if (checkBlank) {
					if (srcVal == null || srcVal.toString().trim().equals("")) {
						if (dstVal != null && !dstVal.toString().trim().equals("")) {
							field.set(objVO, dstVal);
						}
					}
					} else {
						if (dstVal != null && !dstVal.toString().trim().equals("")) {
							field.set(objVO, dstVal);	
						}
					}
					
				}
			}

		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		
	}
	
	private void getAddressDetails(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO, boolean isNew) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMCodeCache cache = EEMCodeCache.getInstance();
		List lstAddr = null;
		if (isNew) {
			lstAddr = eemDao.getAddressDetails(conn, objVO);
		} else {
			lstAddr = eemDao.getMbrAddressDetails(conn, objVO);
		}
		
		for (int i = 0; i < lstAddr.size(); i++) {
			EEMApplAddressVO addrVO = (EEMApplAddressVO) lstAddr.get(i);
			if (addrVO.getAddressType().equals(EEMConstants.EEM_ADDRTYPE_PRIMARY)) {
				objVO.setPerAdd1(addrVO.getAddress1());
				objVO.setPerAdd2(addrVO.getAddress2());
				objVO.setPerAdd3(addrVO.getAddress3());
				objVO.setPerCity(addrVO.getCity());
				objVO.setPerState(cache.getCode(addrVO.getStateCd(), cache.getLstStates()));
				String zip = addrVO.getZipCd();
				if (zip.length() == 9) {
					objVO.setPerZip5(zip.substring(0,5));
					objVO.setPerZip4(zip.substring(5,9));
				} else if (zip.length() == 5) {
					objVO.setPerZip5(zip);
					objVO.setPerZip4("");
				}
				//Lumeris County code issue395887 
//				List lstCounty = (List)cache.getHmpCounty().get(objVO.getPerState());
//				if (lstCounty != null) {
//					objVO.setPerCounty(cache.getDesc(addrVO.getCountyCd(), lstCounty));
//				}
				objVO.setPerCounty(addrVO.getCountyCd());
				objVO.setPerPhone(addrVO.getHomePhoneNbr());
				objVO.setPerCell(addrVO.getCellPhoneNbr());
				objVO.setPerWorkPhone(addrVO.getWorkPhoneNbr());
				objVO.setPerFax(addrVO.getFaxNbr());
				objVO.setLstUpdtPrimAddr(addrVO.getLastUpdtTime());
			} else if (addrVO.getAddressType().equals(EEMConstants.EEM_ADDRTYPE_MAIL)) {
				objVO.setMailAdd1(addrVO.getAddress1());
				objVO.setMailAdd2(addrVO.getAddress2());
				objVO.setMailAdd3(addrVO.getAddress3());
				objVO.setMailCity(addrVO.getCity());
				objVO.setMailState(cache.getCode(addrVO.getStateCd(), cache.getLstStates()));
				String zip = addrVO.getZipCd();
				if (zip.length() == 9) {
					objVO.setMailZip5(zip.substring(0,5));
					objVO.setMailZip4(zip.substring(5,9));
				} else if (zip.length() == 5) {
					objVO.setMailZip5(zip);
					objVO.setMailZip4(""); //Ticket - IFOX-00409498
				}
				objVO.setMailCountry(addrVO.getCountryCd());
				objVO.setLstUpdtMailAddr(addrVO.getLastUpdtTime());
			} else if (addrVO.getAddressType().equals(EEMConstants.EEM_ADDRTYPE_AUTH)) {
				objVO.setAuthRepStreet(addrVO.getAddress1());
				objVO.setAuthRepCity(addrVO.getCity());
				objVO.setAuthRepState(cache.getCode(addrVO.getStateCd(), cache.getLstStates()));
				String zip = addrVO.getZipCd();
				if (zip.length() == 9) {
					objVO.setAuthRepZip5(zip.substring(0,5));
					objVO.setAuthRepZip4(zip.substring(5,9));
				} else if (zip.length() == 5) {
					objVO.setAuthRepZip5(zip);
					objVO.setAuthRepZip4(""); //Ticket - IFOX-00409498
				}
				objVO.setAuthRepPhone(addrVO.getWorkPhoneNbr());
				objVO.setLstUpdtAuthAddr(addrVO.getLastUpdtTime());
			} /*else if (addrVO.getAddressType().equals(EEMConstants.EEM_ADDRTYPE_INST)) {
				objVO.setInstStreet(addrVO.getAddress1());
				objVO.setInstPhoneNo(addrVO.getWorkPhoneNbr());
			}*/
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	private void getProductDetails(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		// Get Enroll product details
		eemDao.getPlanDetails(conn, objVO);
		/**AAH BasePlus Migration IFOX-00426351 START*/ 
		String lob = eemDao.getLineOfBusniess(conn, objVO.getCustomerId(), objVO.getEnrollGroup(),
					objVO.getReqDtCov(), objVO.getEnrollProduct(), objVO.getEnrollPlan(), objVO.getEnrollPbp(), objVO.getEnrollSegment());
		objVO.setEnrollLineOfBusiness(lob);
		/**AAH BasePlus Migration IFOX-00426351 END*/
		// Get PCP details
		eemDao.getPCPDetails(conn, objVO);
		objVO.setPcpName(eemDao.getPCPName(conn, objVO));
		
		// Plan Designation
		String[] planType = eemDao.getPlanType(conn, objVO);
		if (planType != null) {
			objVO.setEnrollPlanDesgn(planType[1]);
		}
		// Current group name
		if (!StringUtil.nonNullTrim(objVO.getCurrGroup()).equals("")) {
			objVO.setCurrGroupName(eemDao.getGroupName(conn, objVO.getCustomerId(), objVO.getCurrGroup(), 
					objVO.getReqDtCov()));
		}
		// Current product name
		if (!StringUtil.nonNullTrim(objVO.getCurrProduct()).equals("")) {
			objVO.setCurrProdName(eemDao.getProductName(conn, objVO.getCustomerId(), objVO.getCurrProduct(), 
					objVO.getReqDtCov()));
		}
		// Enroll group name
		if (!StringUtil.nonNullTrim(objVO.getEnrollGroup()).equals("")) {
			objVO.setEnrollGroupName(eemDao.getGroupName(conn, objVO.getCustomerId(), objVO.getEnrollGroup(), 
					objVO.getReqDtCov()));
		}
		// Enroll product name
		if (!StringUtil.nonNullTrim(objVO.getEnrollProduct()).equals("")) {
			objVO.setEnrollProdName(eemDao.getProductName(conn, objVO.getCustomerId(), objVO.getEnrollProduct(), 
					objVO.getReqDtCov()));
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	private void getOtherCovDetails(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		eemDao.getOtherCovDetails(conn, objVO);
		objVO.setEsrdChange(objVO.getEsrd());
		objVO.setLongTermChange(objVO.getLongTerm());
		objVO.setMedicaidChange(objVO.getStMedicaid());
		
		objVO.setLstInstitutes(eemDao.getInstLookUp(conn, objVO
				.getCustomerId(), objVO.getReqDtCov(),objVO.getEnrollLineOfBusiness()));//AAH BasePlus Migration IFOX-00426351 Changes
		logger.info(LoggerConstants.methodEndLevel());
	}

	private void getAttestDetails(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		eemDao.getAttestationDetails(conn, objVO);
		List lstAttest = objVO.getLstAttestation();
		List lstTemp = new ArrayList();
		int index = 0;
		for (int i = 0; i < lstAttest.size(); i++) {
			EEMApplAttestationVO attestVO = (EEMApplAttestationVO) lstAttest.get(i);
			if (!attestVO.getDeleteInd().equals("Y")) {
				logger.info(LoggerConstants.methodStartLevel());
				attestVO.setIndex("" + index++);
				String exception = attestVO.getSepException();
				if (requireDtForException(exception)) {
					attestVO.setSepException(exception + "Y");
				} else {
					attestVO.setSepException(exception + "N");
				}
				lstTemp.add(attestVO);
			}
		}
		objVO.setLstAttestation(lstTemp);
		logger.info(LoggerConstants.methodEndLevel());
	}

	public boolean requireDtForException(String exception) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		List lstException = EEMCodeCache.getInstance().getLstSepExceptions();
		for (int i = 0; i < lstException.size(); i++) {
			EmAttestationVO attVO = (EmAttestationVO)lstException.get(i);
			if (attVO.getAttestInd().equals(exception)) {
				if (attVO.getDateRequiredInd().equals("Y")) {
					logger.info(LoggerConstants.methodEndLevel());
					return true;
				}
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return false;
	}
	
	// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - Start
	private void getAgentDetails(EEMApplDao eemDao, Connection conn,
			String eemDb, EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		// Get Agent Details
		eemDao.getAgentDetails(conn, objVO);
		String effDate = objVO.getSignDt();
		// get em profile
		try {
			EEMProfileItem item = EEMProfileSettings.getProfileObject(eemDb,
					objVO.getCustomerId(), EEMProfileSettings.AGENTDT);
			if ("R".equalsIgnoreCase(item.getProfileValue())) {
				effDate = objVO.getReqDtCov();
			}
		} catch (Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
		}

		// Set Agency Ids
		objVO.setLstAgencyIds(eemDao.getLstAgencies(conn,
				objVO.getCustomerId(), effDate ,objVO.getEnrollLineOfBusiness()));//AAH BasePlus Migration IFOX-00426351 Changes
		// Set Agent Ids
		objVO.setLstBrokAgentIds(eemDao.getLstBrokAgents(conn,
				objVO.getCustomerId(), objVO.getBrokerType(),
				objVO.getCommAgencyId(), effDate ,objVO.getEnrollLineOfBusiness()));//AAH BasePlus Migration IFOX-00426351 Changes
		logger.info(LoggerConstants.methodEndLevel());
	}
	// -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - End
	
	private void getCommentDetails(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		eemDao.getCommentDetails(conn, objVO);
		logger.info(LoggerConstants.methodEndLevel());
	}

	private void getEligDetails(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO, String beqCheck) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		eemDao.getEligDetails(conn, objVO);
		//BEQ Short term solution --Start
		MBD mbd = null;
		MBDPersistence mp = new MBDPersistence();
		
			try {
				//SSNRI 2017 Changes : start
				String [] flags = new String[2];
		mbd = mp.getHicMatch(conn, objVO.getMbrHicNbr(), objVO.getMbrLastName(), objVO.getMbrBirthDt(), mp.checkDemoAccount(objVO.getCustomerNbr()),flags, beqCheck);
		//SSNRI 2017 Changes : end
		//BEQ Short term solution --End
		if (!objVO.getEsrd().equals("Y")) {
			objVO.setEsrdStDt("");
			objVO.setEsrdEndDt("");
		}
		if (!objVO.getLongTerm().equals("Y")) {
			objVO.setLongTermStDt("");
			objVO.setLongTermEndDt("");
		}
		if (!objVO.getStMedicaid().equals("Y")) {
			objVO.setMedicaidStDt("");
			objVO.setMedicaidEndDt("");
		}
		
	   //BEQ Short term solution --Start
	
		String prtAStDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getPartAEffDt()));
		String prtBStDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getPartBEffDt()));
		String prtDDate = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getPartDEffDt()));
		if(mbd != null){				
		String prtAMbd = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtAEntitleDate()));
		String prtBMbd = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtBEntitleDate()));
		String prtDMbd = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(mbd.getPrtDEligibleDate()));
	
			
		if(!((StringUtil.nonNullTrim(prtAStDt).equalsIgnoreCase(StringUtil.nonNullTrim(prtAMbd))) &
							(StringUtil.nonNullTrim(prtBStDt).equalsIgnoreCase(StringUtil.nonNullTrim(prtBMbd))) &
							(StringUtil.nonNullTrim(prtDDate).equalsIgnoreCase(StringUtil.nonNullTrim(prtDMbd))))){
	     objVO.setEligOverrideInd("Y");
		}else{
		 objVO.setEligOverrideInd("N");
		}
		}	} catch (SQLException e) {
			// TODO Auto-generated catch block
			//.printStackTrace();
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception : " + e.getMessage());
		}
			logger.info(LoggerConstants.methodEndLevel());
     //BEQ Short term Solution --End
	}
	//SSNRI 2017 Changes : start
	private void getMBDDetails(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO,String beqCheck) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String hicNbr =objVO.getMbrHicNbr();
		String hicMbiFlag = isHicOrMbi(hicNbr);
		if (hicMbiFlag.equalsIgnoreCase("mbi")){
			objVO.setIsHicOrMbi("mbi");
		}else{
			objVO.setIsHicOrMbi("hic");
		}
		MBD mbd = verifyEligibility(conn, objVO.getMbrHicNbr(),
				objVO.getMbrLastName(), objVO.getMbrBirthDt(), "",
				objVO.getCustomerNbr(), beqCheck,objVO.getIsHicOrMbi());
		//SSNRI 2017 Changes : end
		if (mbd == null) {
			objVO.setMbd(new MBD());
		} else {
			/**
			 * Cambia_BEQ-Start
			 */
			objVO.setEligibilitySrcTable(StringUtil.nonNullTrim(mbd.getEligibilitySrcTable()));
			/**
			 * Cambia_BEQ-End
			 */
			objVO.setMbd(mbd);
			objVO.setDtLstChked(new DateUtil().getDB2DTS());
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void getErrorDetails(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		List lstErrors = eemDao.getErrorDetails(conn, objVO);
		objVO.setLstErrors(lstErrors);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	private boolean setMasterDetails(EEMApplDao eemDao, Connection conn, String eemDb,
			EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		int rslt = 0;
	 	try {
			// Set Out of area indicator
			if (StringUtil.nonNullTrim(objVO.getOutOfArea()).equals("")) {
				objVO.setOutOfArea("N");
			} else {
				objVO.setOutOfArea("E");
			}
			
			String beqCheck = EEMProfileSettings.getCalendarProfileItem(eemDb,objVO.getCustomerId(), EEMProfileSettings.BEQCHECK);
			// Query fixed while debugging IFOX-00378975 ---- Start
			String customerId = objVO.getCustomerId();
			String subsInd=eemDao.getSubsInd(conn, customerId);
			// Query fixed while debugging IFOX-00378975 ---- End
	//Added for SSNRI changes to set the MBI form value : start
		if(objVO.getIsHicOrMbi().equals("mbi")){
			objVO.setMbiNbr(objVO.getMbrHicNbr());
		}
		//Added for SSNRI changes to set the MBI form value : end
			
			// Check for Ready Status
			if (objVO.getApplStatus().equals(EEMConstants.APPL_STATUS_READY)||objVO.getApplStatus().equals(EEMConstants.APPL_STATUS_READYAPPR)) {
				/*Cambia_BEQ --Start*/
				if(StringUtil.nonNullTrim(objVO.getEligibilitySrcTable()).equals(EEMConstants.EM_TABLE_BEQ)){
					/**IFOX-00427141 BEQ Supplemental ID Issue Fix. START**/
					if(subsInd.equals("Y") && (StringUtil.nonNullTrim(objVO.getAltMbrId()).equals("")))
						validatePartABDDates(objVO,beqCheck);
					else
						objVO.setApplStatus(EEMConstants.APPL_STATUS_BEQAPPR);
					/**IFOX-00427141 BEQ Supplemental ID Issue Fix. END**/
				} else {
					if(subsInd.equals("Y") && (StringUtil.nonNullTrim(objVO.getAltMbrId()).equals(""))){
						// Fix for IFOX-411158 - Start
						validatePartABDDates(objVO,beqCheck);
					}
					else{
						objVO.setApplStatus(EEMConstants.APPL_STATUS_READYAPPR);
					}
				}
			}
			else if(objVO.getApplStatus().equals(EEMConstants.APPL_STATUS_BEQAPPR) &&
					StringUtil.nonNullTrim(objVO.getEligibilitySrcTable()).equals(EEMConstants.EM_TABLE_MBD)){
				if(subsInd.equals("Y") && StringUtil.nonNullTrim(objVO.getAltMbrId()).equals("")){
					validatePartABDDates(objVO,beqCheck);
				} else{
					objVO.setApplStatus(EEMConstants.APPL_STATUS_READYAPPR);
				}
			}
			// IFOX-00380952, IFOX-00381513: Medicaid ID & ELGWARNING Apps to Suppend Fix -- Start
			else if((objVO.getApplStatus().equals(EEMConstants.APPL_STATUS_FORCEDAPPR) || objVO.getApplStatus().equals(EEMConstants.APPL_STATUS_ELGWARNING)) && 
					subsInd.equals("Y") && StringUtil.nonNullTrim(objVO.getAltMbrId()).equals("")){
				validatePartABDDates(objVO,beqCheck);
		    }	// Fix for IFOX-411158 - End
			// IFOX-00380952, IFOX-00381513: Medicaid ID & ELGWARNING Apps to Suppend Fix  -- End
			else if(objVO.getCurrStatus().equals(EEMConstants.APPL_STATUS_SUPPEND) &&
					objVO.getApplStatus().equals(EEMConstants.APPL_STATUS_READY) && (subsInd.equals("N") 
							|| !(StringUtil.nonNullTrim(objVO.getAltMbrId()).equals("")))){				

				//CMS FEB 2016 Release - Start
				//objVO.setApplStatus(EEMConstants.APPL_STATUS_READYAPPR);
				
				List lstErrors = objVO.getLstErrors();
				EEMErrorVO errorVO = null;
								
				for (int i = 0; i < lstErrors.size(); i++) {
					errorVO = (EEMErrorVO)lstErrors.get(i);
					String errorCode = errorVO.getErrorCode();
					if(errorCode.equalsIgnoreCase("AP337") || errorCode.equalsIgnoreCase("AP338")){
						objVO.setApplStatus(EEMConstants.APPL_STATUS_ELGWARNING);
						}
					else{
						objVO.setApplStatus(EEMConstants.APPL_STATUS_READYAPPR);
					}
				}
				
				
				//CMS FEB 2016 Release - End
			}
			/*Cambia_BEQ --End*/
			/*if (objVO.getApplStatus().equals(EEMConstants.APPL_STATUS_READY)) {
				objVO.setApplStatus(EEMConstants.APPL_STATUS_READYAPPR);
			}
			*/
			// Check for Update
			//original application start
			objVO.setOrigApplDate(StringUtil.nonNullTrim(objVO.getApplDate()));
			logger.debug("Original Application Date: "+objVO.getApplDate());
			
			boolean checForExistingEnrollment = false;
			
			if (checForExistingEnrollment){
				// Duplicate Enrollment Issue Fix : End					
					objVO.setApplStatus(EEMConstants.APPL_STATUS_DUPLENRL);
				logger.debug("objVO.getEligOverrideInd():"+objVO.getEligOverrideInd());
				}
			
			
			/*LA- care code retrofit for MMP plan- start*/
			
			logger.info("The application type : "+ objVO.getApplType());
			logger.info("The enroll plan designation :"+objVO.getEnrollPlanDesgn());
			if("Y".equalsIgnoreCase(objVO.getEligOverrideInd()) && objVO.getApplStatus().equalsIgnoreCase(EEMConstants.APPL_STATUS_FORCEDAPPR)){
				
				if("NMA".equalsIgnoreCase(objVO.getApplType()) ){
					
					if("MA".equalsIgnoreCase(objVO.getEnrollPlanDesgn())){
						if(objVO.getPartAEffDt() != null && !objVO.getPartAEffDt().equals("")){
							if(objVO.getPartBEffDt() != null && !objVO.getPartBEffDt().equals("")){
								logger.debug("Valid for Update In Case of FORCEDAPPR");
							}else{
								return false;
							}
						}else{
							return false;
						}
					}else if("MAPD".equalsIgnoreCase(objVO.getEnrollPlanDesgn())){

						if(objVO.getPartAEffDt() != null && !objVO.getPartAEffDt().equals("")){
							if(objVO.getPartBEffDt() != null && !objVO.getPartBEffDt().equals("")){
								if(objVO.getPartDEffDt() != null && !objVO.getPartDEffDt().equals("")){
									logger.debug("Valid for Update In Case of FORCEDAPPR");
								}else{
									return false;
								}

							}else{
								return false;
							}
						}else{
							return false;
						}
						
					}
				
				
				}else if("NPD".equalsIgnoreCase(objVO.getApplType()) ){
					
					if("MMP".equalsIgnoreCase(objVO.getEnrollPlanDesgn())){
						if(objVO.getPartDEffDt() != null && !objVO.getPartDEffDt().equals("")){
							if(objVO.getPartBEffDt() != null && !objVO.getPartBEffDt().equals("")){
								logger.debug("Valid for Update In Case of FORCEDAPPR");
							}else if(objVO.getPartAEffDt() != null && !objVO.getPartAEffDt().equals("")){
								logger.debug("Valid for Update In Case of FORCEDAPPR");
							}else{
								return false;
							}
						}else{
							return false;
						}
					}else if("PDP".equalsIgnoreCase(objVO.getEnrollPlanDesgn())){

						if(objVO.getPartDEffDt() != null && !objVO.getPartDEffDt().equals("")){
							if(objVO.getPartBEffDt() != null && !objVO.getPartBEffDt().equals("")){
								logger.debug("Valid for Update In Case of FORCEDAPPR");
							}else if(objVO.getPartAEffDt() != null && !objVO.getPartAEffDt().equals("")){
								logger.debug("Valid for Update In Case of FORCEDAPPR");
							}else{
								return false;
							}
						}else{
							return false;
						}
						
					}

				}
			}
			
			/*LA- care code retrofit for MMP plan- End*/
			
			
			if("Y".equals(beqCheck)) {

				//Begin: Added for IFOX-00364414
				if(null == objVO.getLstErrors() || objVO.getLstErrors().size() == 0)
				{
					////IFOX-00394060: BEQPEND is no more used.BEQPENDING status is used instead.  
					if(EEMConstants.APPL_STATUS_BEQPENDING.equals(objVO.getCurrStatus()) || EEMConstants.APPL_STATUS_SUPPEND.equals(objVO.getCurrStatus()))
					{
						if(subsInd!=null && subsInd.equalsIgnoreCase(EEMConstants.VALUE_YES)){
							
							//IFOX-00394060 - Added the SUPPLIMENTAL_ID check to avoid failure at memberConversion sweep
							if(StringUtil.nonNullTrim(objVO.getAltMbrId()).equalsIgnoreCase(EEMConstants.BLANK)){
								
								// Fix for IFOX-411158 - Start
								
								if(EEMConstants.EM_TABLE_BEQ.equals(objVO.getEligibilitySrcTable()))
									validatePartABDDates(objVO,beqCheck);
								else if(EEMConstants.EM_TABLE_MBD.equals(objVO.getEligibilitySrcTable()))
									validatePartABDDates(objVO,beqCheck);
								else{
									objVO.setApplStatus(EEMConstants.APPL_STATUS_BEQPENDING);
								}
								
								// Fix for IFOX-411158 - End
							}else{
								
								if(EEMConstants.EM_TABLE_BEQ.equals(objVO.getEligibilitySrcTable()))
									objVO.setApplStatus(EEMConstants.APPL_STATUS_BEQAPPR);
								else if(EEMConstants.EM_TABLE_MBD.equals(objVO.getEligibilitySrcTable()))
									objVO.setApplStatus(EEMConstants.APPL_STATUS_READYAPPR);
								else{
										objVO.setApplStatus(EEMConstants.APPL_STATUS_BEQPENDING);
								}
							}
							
						}else{
							
							if(EEMConstants.EM_TABLE_BEQ.equals(objVO.getEligibilitySrcTable()))
								objVO.setApplStatus(EEMConstants.APPL_STATUS_BEQAPPR);
							else
								if(EEMConstants.EM_TABLE_MBD.equals(objVO.getEligibilitySrcTable()))
								objVO.setApplStatus(EEMConstants.APPL_STATUS_READYAPPR);
							else{
								objVO.setApplStatus(EEMConstants.APPL_STATUS_BEQPENDING);
							}
							
						}

					}

				}
			}
			//End: Added for IFOX-00364414
			
			/* IFOX-00374947 / IFOX-00378975 to process Employer group applications with EGHP_ID=Y---Start*/
			if (objVO.getElectionType().equals("W")){
			EEMApplProductsVO prodVO=null;
			String eghpId="";
			String applDate;
			List lstProd = eemDao.getProducts(conn, objVO);
			if (lstProd != null && lstProd.size() > 0) {
				 prodVO = (EEMApplProductsVO) lstProd.get(0);
				 eghpId=prodVO.getEghpInd();
				 if(!eghpId.equals("") && eghpId.equals("Y")){
					applDate=DateUtil.formatMmDdYyyy(DateMath.getFirstOfPreviousMonth(DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(objVO.getReqDtCov()))));
					objVO.setApplDate(applDate);
					logger.debug("Modified Application Date: "+objVO.getApplDate());
					}
				}
			}
			
			/* IFOX-00374947 / IFOX-00378975 to process Employer group applications with EGHP_ID=Y---End*/
			
			//original application end
			/** Triple S BasePlus Migration START **/
			// MMO ACH CR-Start
			String achValue = EEMProfileSettings.getCalendarProfileItem(eemDb, objVO.getCustomerId(),
					EEMProfileSettings.ACHIND);
			objVO.setAchIndicator(achValue);
			// MMO ACH CR-End
			/** Triple S BasePlus Migration END **/
			//IFOX-00406767 -start
			if(!"Y".equalsIgnoreCase(objVO.getHealthPlanNews())){
				objVO.setHealthPlanNews("N");
			}
			//IFOX-00406767 -end
			if (objVO.getUpdateRec().equals("N")) {
				objVO.setApplId(""+eemDao.getNextSeqNo(eemDb, objVO.getCustomerId(), EEMDao.NEXT_APP_ID));
				checkApplicationNbr(conn, eemDb, objVO);
				setSupplId(conn, eemDb, objVO);
				rslt = eemDao.insertMasterDetails(conn, eemDb, objVO);
			} else if (objVO.getUpdateRec().equals("Y")) {
				checkApplicationNbr(conn, eemDb, objVO);
				setSupplId(conn, eemDb, objVO);
				rslt = eemDao.updateMasterDetails(conn, objVO);
			}
			if (rslt == 1) {
				/**
				 * Cambia_Application denial-Start
				 */
				if(isDenied(objVO)){
				Boolean trigResult= insertApplDeniedTrigger(eemDao, conn, objVO);
					if(!trigResult){
						logger.info(LoggerConstants.methodEndLevel());
					return false;
					}
					}
				/**
				 * Cambia_Application denial-End
				 */
					objVO.setCurrStatus(objVO.getApplStatus());
					logger.info(LoggerConstants.methodEndLevel());
					return true;
				
			}
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException(e);
		}
	 	logger.info(LoggerConstants.methodEndLevel());
		return false;
	}
	/**IFOX-00427141 BEQ Supplemental ID Issue Fix. START**/
	private void validatePartABDDates(EEMApplicationVO objVO, String beqCheck) {
		
		MBD mbd = objVO.getMbd();
		String prtAStDt = StringUtil.nonNullTrim(objVO.getPartAEffDt());
		String prtBStDt = StringUtil.nonNullTrim(objVO.getPartBEffDt());
		String prtDDate = StringUtil.nonNullTrim(objVO.getPartDEffDt());
						
		String prtAMbd = DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(mbd.getPrtAEntitleDate()));
		String prtBMbd = DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(mbd.getPrtBEntitleDate()));
		String prtDMbd = DateUtil.formatMmDdYyyy(StringUtil.nonNullTrim(mbd.getPrtDEligibleDate()));
		
		if(!((StringUtil.nonNullTrim(prtAStDt).equalsIgnoreCase(StringUtil.nonNullTrim(prtAMbd))) &
				(StringUtil.nonNullTrim(prtBStDt).equalsIgnoreCase(StringUtil.nonNullTrim(prtBMbd))) &
				(StringUtil.nonNullTrim(prtDDate).equalsIgnoreCase(StringUtil.nonNullTrim(prtDMbd))))){
			
			if(StringUtil.isNullZeroDateField(prtAStDt))
				prtAStDt = prtAMbd;
			
			if(StringUtil.isNullZeroDateField(prtBStDt))
				prtBStDt = prtBMbd;
			
			if(StringUtil.isNullZeroDateField(prtDDate))
				prtDDate = prtDMbd;
			
		}
		
		if("Y".equalsIgnoreCase(beqCheck) && (prtAStDt.equals("00/00/0000") || prtBStDt.equals("00/00/0000") || prtDDate.equals("00/00/0000")))
			objVO.setApplStatus(EEMConstants.APPL_STATUS_BEQPENDING);
		else
			objVO.setApplStatus(EEMConstants.APPL_STATUS_SUPPEND);
				
	}
	/**IFOX-00427141 BEQ Supplemental ID Issue Fix. END**/
	
	public void setSupplId(Connection conn, String eemDb, EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			String supplInd = EEMProfileSettings.getCalendarProfileItem(
									eemDb, objVO.getCustomerId(), EEMProfileSettings.SUPPLID);
			// 00414932 :Start
			String rxIdInd = EEMProfileSettings.getCalendarProfileItem(
					eemDb, objVO.getCustomerId(), EEMProfileSettings.RXID);
			// 00414932 :End
			if (supplInd != null) {
				if (supplInd.equals(EEMProfileSettings.SUPPLID_DERIVED)) {
					if (objVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_MA) ||
							objVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_PD)) {
						objVO.setAltMbrId(objVO.getMbrId());
					}
				} 
				else
				if (supplInd.equals(EEMProfileSettings.SUPPLID_GENERATED)) {
					if (objVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_MA) ||
							objVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_PD)) {
						// generate on initial save
						if (StringUtil.nonNullTrim(objVO.getUpdateRec()).equals("N")) {
							/*objVO.setAltMbrId(""+ eemDao.getNextSeqNo(eemDb,
											objVO.getCustomerId(),
											EEMDao.NEXT_SUP_ID));*/
							//for "G" supplid should not be generated
							// 00414932 :Start
							if (rxIdInd.equals(EEMProfileSettings.RXID_USE_SUPPLID)){
								objVO.setAltMbrId(objVO.getMbrRxId());
							}
							else
								// 00414932 :End
								objVO.setAltMbrId("");
							
						}
					} 
					else 
					if (objVO.getApplType().equals(EEMConstants.OPTION_CNTRCHG_MA) ||
								objVO.getApplType().equals(EEMConstants.OPTION_CNTRCHG_PD)) {
						if (!StringUtil.nonNullTrim(objVO.getCurrProduct()).equals(
									StringUtil.nonNullTrim(objVO.getEnrollProduct())) ||
							!StringUtil.nonNullTrim(objVO.getCurrPbp()).equals(
									StringUtil.nonNullTrim(objVO.getEnrollPbp())) ||
							!StringUtil.nonNullTrim(objVO.getCurrSegment()).equals(
									StringUtil.nonNullTrim(objVO.getEnrollSegment())) ) {
							// really need to have the previous values
							if (StringUtil.nonNullTrim(objVO.getAltMbrId()).equals(""))
								/*objVO.setAltMbrId(""+ eemDao.getNextSeqNo(eemDb,
										objVO.getCustomerId(),
										EEMDao.NEXT_SUP_ID));*/
								//for "G" supplid should not be generated
								// 00414932 :Start
								if (rxIdInd.equals(EEMProfileSettings.RXID_USE_SUPPLID)){
									objVO.setAltMbrId(objVO.getMbrRxId());
								}
								else
									// 00414932 :End
								objVO.setAltMbrId("");
						}
					}
				}
			}
			
		} catch (Exception e) {
			//e.printStackTrace(log.getStream());
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			objVO.setMessage("Error during Supplemental Id check.");
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	private String evalErrorStatus(List lstErrors) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		// Get the status list
		List lstStatus = EEMCodeCache.getInstance().getLstApplStatus();
		List lstPrior = new ArrayList();
		NameValuePair nvp = null;
		for (int i = 0; i < lstStatus.size(); i++) {
			nvp = (NameValuePair)lstStatus.get(i);
			lstPrior.add(nvp.getName());
		}
		
		// Evaluate the status priority
		EEMErrorVO errorVO = (EEMErrorVO)lstErrors.get(0);
		String status = errorVO.getStatus();
		int prevPrior = lstPrior.indexOf(status);
		int newPrior = prevPrior;
		for (int i = 1; i < lstErrors.size(); i++) {
			errorVO = (EEMErrorVO)lstErrors.get(i);
			newPrior = lstPrior.indexOf(errorVO.getStatus());
			if ((newPrior != -1 && newPrior < prevPrior) || prevPrior == -1) {
				prevPrior = newPrior;
				status = errorVO.getStatus();
			} 
		}
		logger.info(LoggerConstants.methodEndLevel());
		return status;
	}
	
	private boolean setAddressDetails(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO, EEMApplAddressVO addrVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		int rslt = 0;
		EEMCodeCache cache = EEMCodeCache.getInstance();
		//EEMApplAddressVO addrVO = new EEMApplAddressVO();
		addrVO.setCustomerId(objVO.getCustomerId());
		addrVO.setApplicationId(objVO.getApplId());

		String zip5 = "";
		String zip4 = "";
		boolean result = true;
		try {
			
			// Insert OR Update personal or primary address
			boolean empty = false;
			if (StringUtil.nonNullTrim(objVO.getPerAdd1()).equals("") &&
					StringUtil.nonNullTrim(objVO.getPerAdd2()).equals("") &&
					StringUtil.nonNullTrim(objVO.getPerAdd3()).equals("") &&
					StringUtil.nonNullTrim(objVO.getPerCity()).equals("") &&
					StringUtil.nonNullTrim(objVO.getPerState()).equals("") &&
					StringUtil.nonNullTrim(objVO.getPerZip5()).equals("") &&
					StringUtil.nonNullTrim(objVO.getPerZip4()).equals("") &&
					StringUtil.nonNullTrim(objVO.getPerCounty()).equals("") &&
					StringUtil.nonNullTrim(objVO.getPerPhone()).equals("") &&
					StringUtil.nonNullTrim(objVO.getPerCell()).equals("") &&
					StringUtil.nonNullTrim(objVO.getPerWorkPhone()).equals("") &&
					StringUtil.nonNullTrim(objVO.getPerFax()).equals("")) {
				empty = true;
			}
			
			if (!empty) {
				addrVO.setAddressType(EEMConstants.EEM_ADDRTYPE_PRIMARY);
				addrVO.setAddress1(objVO.getPerAdd1());
				addrVO.setAddress2(objVO.getPerAdd2());
				addrVO.setAddress3(objVO.getPerAdd3());
				addrVO.setCity(objVO.getPerCity());
				addrVO.setStateCd(cache.getDesc(objVO.getPerState(), cache.getLstStates()));
				if (!StringUtil.nonNullTrim(objVO.getPerZip5()).equals("")) {
					zip5 = StringUtil.nonNullTrim(objVO.getPerZip5()); 
				}
				if (!StringUtil.nonNullTrim(objVO.getPerZip4()).equals("")) {
					zip4 = StringUtil.nonNullTrim(objVO.getPerZip4()); 
				}
				addrVO.setZipCd(zip5 + zip4);
				
				// County details
				if (StringUtil.nonNullTrim(objVO.getPerCounty()).equals("")) {
					if (!StringUtil.nonNullTrim(addrVO.getZipCd()).equals("")) {
						objVO.setPerCounty(eemDao.getCounty(conn, zip5, zip4));
					}
					List lstCounty = (List)cache.getHmpCounty().get(objVO.getPerState());
					if (lstCounty != null) {
						addrVO.setCountyCd(cache.getCode(StringUtil.nonNullTrim(objVO.getPerCounty()), lstCounty));	
					}
				}else{
					addrVO.setCountyCd(StringUtil.nonNullTrim(objVO.getPerCounty()));
				}
				
				
				addrVO.setCountryCd("USA");
				addrVO.setHomePhoneNbr(objVO.getPerPhone());
				addrVO.setCellPhoneNbr(objVO.getPerCell());
				addrVO.setWorkPhoneNbr(objVO.getPerWorkPhone());
				addrVO.setFaxNbr(objVO.getPerFax());
				addrVO.setCreateUserId(objVO.getOperId());
				addrVO.setLastUpdtUserId(objVO.getOperId());
				//original application start
				String updateRecInd = objVO.getUpdateRec();
				//original application end
				if (objVO.getUpdateRec().equals("N") || objVO.getLstUpdtPrimAddr().equals("")) {
					//if (eemDao.insertAddressDetails(conn, addrVO) == 0)
					//original application start
					if (eemDao.insertAddressDetails(conn, addrVO, updateRecInd) == 0)
					//original application end
						result = false;
					objVO.setLstUpdtPrimAddr(addrVO.getLastUpdtTime());
				} else if (objVO.getUpdateRec().equals("Y")) {
					addrVO.setLastUpdtTime(objVO.getLstUpdtPrimAddr());
					if (eemDao.updateAddressDetails(conn, addrVO) == 0) {
						result = false;
					} else {
						objVO.setLstUpdtPrimAddr(addrVO.getLastUpdtTime());
					}
				}	
			} else if (empty && !StringUtil.nonNullTrim(objVO.getLstUpdtPrimAddr()).equals("")) {
				// Delete the record
				addrVO.setCustomerId(objVO.getCustomerId());
				addrVO.setApplicationId(objVO.getApplId());
				addrVO.setAddressType(EEMConstants.EEM_ADDRTYPE_PRIMARY);
				addrVO.setLastUpdtTime(objVO.getLstUpdtPrimAddr());
				
				if (eemDao.deleteAddressDetails(conn, addrVO) == 0) {
					result = false;
				} else {
					objVO.setLstUpdtPrimAddr(null);
				}
			}
			
			// Insert OR Update Mailing address
			empty = false;
			zip5 = "";
			zip4 = "";
			if (StringUtil.nonNullTrim(objVO.getMailAdd1()).equals("") &&
					StringUtil.nonNullTrim(objVO.getMailAdd2()).equals("") &&
					StringUtil.nonNullTrim(objVO.getMailAdd3()).equals("") &&
					StringUtil.nonNullTrim(objVO.getMailCity()).equals("") &&
					StringUtil.nonNullTrim(objVO.getMailState()).equals("") &&
					StringUtil.nonNullTrim(objVO.getMailZip5()).equals("") &&
					//IFOX-00377807 -- Commented the below line 
					//StringUtil.nonNullTrim(objVO.getMailZip4()).equals("") && 
					StringUtil.nonNullTrim(objVO.getMailCountry()).equals("")) {
				//IFOX-00377807
				if(!StringUtil.nonNullTrim(objVO.getMailZip4()).equals("")){
					objVO.setMailZip4("");
				}
				empty = true;
			}
			if (!empty) {
				addrVO.setAddressType(EEMConstants.EEM_ADDRTYPE_MAIL);
				addrVO.setAddress1(objVO.getMailAdd1());
				addrVO.setAddress2(objVO.getMailAdd2());
				addrVO.setAddress3(objVO.getMailAdd3());
				addrVO.setCity(objVO.getMailCity());
				addrVO.setStateCd(cache.getDesc(objVO.getMailState(), cache.getLstStates()));
				if (!StringUtil.nonNullTrim(objVO.getMailZip5()).equals("")) {
					zip5 = StringUtil.nonNullTrim(objVO.getMailZip5()); 
				}
				if (!StringUtil.nonNullTrim(objVO.getMailZip4()).equals("")) {
					zip4 = StringUtil.nonNullTrim(objVO.getMailZip4()); 
				}
				addrVO.setZipCd(zip5 + zip4);
				addrVO.setCountryCd(objVO.getMailCountry());
				addrVO.setHomePhoneNbr("");
				addrVO.setCellPhoneNbr("");
				addrVO.setWorkPhoneNbr("");
				addrVO.setFaxNbr("");
				addrVO.setCountyCd("");
				//original application start
				String updateRecInd = objVO.getUpdateRec();
				//original application end
				
				if (objVO.getUpdateRec().equals("N") || objVO.getLstUpdtMailAddr().equals("")) {
					if (eemDao.insertAddressDetails(conn, addrVO,updateRecInd) == 0)
						result = false;
					objVO.setLstUpdtMailAddr(addrVO.getLastUpdtTime());
				} else if (objVO.getUpdateRec().equals("Y")) {
					addrVO.setLastUpdtTime(objVO.getLstUpdtMailAddr());
					if (eemDao.updateAddressDetails(conn, addrVO) == 0) {
						result = false;
					} else {
						objVO.setLstUpdtMailAddr(addrVO.getLastUpdtTime());
					}
				}	
			} else if (empty && !StringUtil.nonNullTrim(objVO.getLstUpdtMailAddr()).equals("")) {
				// Delete the record
				addrVO.setCustomerId(objVO.getCustomerId());
				addrVO.setApplicationId(objVO.getApplId());
				addrVO.setAddressType(EEMConstants.EEM_ADDRTYPE_MAIL);
				addrVO.setLastUpdtTime(objVO.getLstUpdtMailAddr());
				
				if (eemDao.deleteAddressDetails(conn, addrVO) == 0) {
					result = false;
				} else {
					objVO.setLstUpdtMailAddr(null);
				}
			}
			
			// Insert OR Update Authorize Rep
			empty = false;
			zip5 = "";
			zip4 = "";
			if (StringUtil.nonNullTrim(objVO.getAuthRepStreet()).equals("") &&
					StringUtil.nonNullTrim(objVO.getAuthRepCity()).equals("") &&
					StringUtil.nonNullTrim(objVO.getAuthRepState()).equals("") &&
					StringUtil.nonNullTrim(objVO.getAuthRepPhone()).equals("")) {
				empty = true;
			}
			if (!empty) {
				addrVO.setAddressType(EEMConstants.EEM_ADDRTYPE_AUTH);
				addrVO.setAddress1(objVO.getAuthRepStreet());
				addrVO.setAddress2("");
				addrVO.setAddress3("");
				addrVO.setCity(objVO.getAuthRepCity());
				addrVO.setStateCd(cache.getDesc(objVO.getAuthRepState(), cache.getLstStates()));
				if (!StringUtil.nonNullTrim(objVO.getAuthRepZip5()).equals("")) {
					zip5 = StringUtil.nonNullTrim(objVO.getAuthRepZip5()); 
				}
				if (!StringUtil.nonNullTrim(objVO.getAuthRepZip4()).equals("")) {
					zip4 = StringUtil.nonNullTrim(objVO.getAuthRepZip4()); 
				}
				addrVO.setZipCd(zip5 + zip4);
				addrVO.setCountryCd("USA");
				addrVO.setHomePhoneNbr("");
				addrVO.setCellPhoneNbr("");
				addrVO.setWorkPhoneNbr(objVO.getAuthRepPhone());
				addrVO.setFaxNbr("");
				addrVO.setCountyCd("");
				
				//original application start
				String updateRecInd = objVO.getUpdateRec();
				
				//original application end
				if (objVO.getUpdateRec().equals("N")|| objVO.getLstUpdtAuthAddr().equals("")) {
					if (eemDao.insertAddressDetails(conn, addrVO,updateRecInd) == 0)
						result = false;
					objVO.setLstUpdtAuthAddr(addrVO.getLastUpdtTime());
				} else if (objVO.getUpdateRec().equals("Y")) {
					addrVO.setLastUpdtTime(objVO.getLstUpdtAuthAddr());
					if (eemDao.updateAddressDetails(conn, addrVO) == 0) {
						result = false;
					} else {
						objVO.setLstUpdtAuthAddr(addrVO.getLastUpdtTime());
					}
				}	
			} else if (empty && !StringUtil.nonNullTrim(objVO.getLstUpdtAuthAddr()).equals("")) {
				// Delete the record
				addrVO.setCustomerId(objVO.getCustomerId());
				addrVO.setApplicationId(objVO.getApplId());
				addrVO.setAddressType(EEMConstants.EEM_ADDRTYPE_AUTH);
				addrVO.setLastUpdtTime(objVO.getLstUpdtAuthAddr());
				
				if (eemDao.deleteAddressDetails(conn, addrVO) == 0) {
					result = false;
				} else {
					objVO.setLstUpdtAuthAddr(null);
				}
			}
			
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return result;
	}
	
	private boolean setProductDetails(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		int rslt = 0;
		
		// Check for insert
		if (objVO.getUpdateRec().equals("N") || objVO.getLstUpdtPlan().equals("")) {
			rslt += eemDao.insertPlanDetails(conn, objVO);
		} 
		if ((objVO.getUpdateRec().equals("N") || 
				objVO.getLstUpdtOtherPlan().equals("")) &&
					!StringUtil.nonNullTrim(objVO.getPcpName()).equals("")) {	
			rslt += eemDao.insertPCPDetails(conn, objVO);
		} 
		
		// Check for update
		if (objVO.getUpdateRec().equals("Y") && !objVO.getLstUpdtPlan().equals("")) {
			rslt += eemDao.updatePlanDetails(conn, objVO);
		}
		if (objVO.getUpdateRec().equals("Y") && !objVO.getLstUpdtOtherPlan().equals("")) {
			if (StringUtil.nonNullTrim(objVO.getPcpName()).equals("")) {
				rslt += eemDao.deletePCPDetails(conn, objVO);
			} else {
				rslt += eemDao.updatePCPDetails(conn, objVO);
			}	
		}
		if (rslt > 0) {
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}
		logger.info(LoggerConstants.methodEndLevel());
		return false;
	}

	private boolean setOtherCovDetails(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		int rslt = 0;
		// Check for Update
		if (objVO.getUpdateRec().equals("N") || objVO.getLstUpdtOtherCov().equals("")) {
			rslt = eemDao.insertOtherCovDetails(conn, objVO);
		} else if (objVO.getUpdateRec().equals("Y")) {
			rslt = eemDao.updateOtherCovDetails(conn, objVO);
		}
		if (rslt == 1) {
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}
		logger.info(LoggerConstants.methodEndLevel());
		return false;
	}

	private boolean setAttestDetails(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		
		int rslt = 0;
		int cnt = 0;
		// Check for Update
		if (objVO.getUpdateRec().equals("N")) {
			String[] arrExceptions = getExceptions(objVO.getSepException());
			String[] arrAttestDt = objVO.getAttestDt();
			if (objVO.getLstAttestation() != null) {
				for (int i = 0; i < objVO.getLstAttestation().size(); i++) {
					if (!StringUtil.nonNullTrim(arrExceptions[i]).equals("")) {
						cnt += 1;
						rslt += eemDao.insertAttestationDetails(conn, objVO, "" + (i + 1),
								arrExceptions[i], arrAttestDt[i]);
					}
				}
				if (rslt != cnt) 
					return false;
			}
		} else if (objVO.getUpdateRec().equals("Y")) {
			// Get the current records in table
			eemDao.getAttestationDetails(conn, objVO);
			
			// Check for insert and update records
			String[] arrExceptions = getExceptions(objVO.getSepException());
			List lstExceptions = objVO.getLstAttestation();
			String[] arrAttestDt = objVO.getAttestDt();
			int seqNo = lstExceptions.size();
			for (int i = 0; i < arrExceptions.length; i++) {
				if (!StringUtil.nonNullTrim(arrExceptions[i]).equals("")) {
					if (checkException(arrExceptions[i], lstExceptions)) {
						cnt += 1;
						rslt += eemDao.updateAttestationDetails(conn, objVO,
								arrExceptions[i], arrAttestDt[i]);
					} else {
						cnt += 1;
						//IFOX-00428796 Fix.
						rslt += eemDao.insertAttestationDetails(conn, objVO, "" + (++seqNo), arrExceptions[i], arrAttestDt[i]);
					}
				}
			}
			
			// Check for logical delete records
			for (int i = 0; i < lstExceptions.size(); i++) {
				EEMApplAttestationVO attestVO = (EEMApplAttestationVO) lstExceptions.get(i);
				if (attestVO.getLogicalDel().equals("Y")
						&& !attestVO.getDeleteInd().equals("Y")) {
					cnt += 1;
					rslt += eemDao.deleteAttestationDetails(conn, objVO, attestVO
							.getSepException(), attestVO.getAttestDt());
				}
			}
			
			if (rslt != cnt) {
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		}
	//	System.out.println("objVO.getUpdateRec()...2"+objVO.getUpdateRec());
		logger.info(LoggerConstants.methodEndLevel());
		return true;
	}

	private String[] getExceptions(String[] exceptions) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		if (exceptions == null) {
			logger.info(LoggerConstants.methodEndLevel());
			return null;
		}
		String[] sepExceptions = new String[exceptions.length];
		
		for (int i = 0; i < exceptions.length; i++) {
			if (!exceptions[i].equals("")) {
				sepExceptions[i] = exceptions[i].substring(0, exceptions[i].length()-1);	
			} else {
				sepExceptions[i] = "";
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return sepExceptions;
	}
	// Agent ID Issue Fix - IFOX-00375436 / IFOX-00382751 - Start
	private boolean setAgentDetails(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO) throws ApplicationException, SQLException {
		logger.info(LoggerConstants.methodStartLevel());
		// commented the below code as per IFOX-00375436 to remove the agent details if present in EM_APPL_AGENT table
		/*if (StringUtil.nonNullTrim(objVO.getBrokAgentId()).equals("")) {
			return true;
		}*/
		
		int rslt = 0;
		// Check for Update
		//Added to check the agent details present in EM_APPL_AGENT with the application_ID and setting LAST_UPDATE_TIME--Lakshman
		boolean applAgentFlag=eemDao.checkApplAgent(conn, objVO);
		if (objVO.getUpdateRec().equals("N") || !applAgentFlag) { //IFOX-00396423 :fixed existing prod issue
			if (StringUtil.nonNullTrim(objVO.getBrokAgentId()).equals("")) {
				logger.info(LoggerConstants.methodEndLevel());
				return true;
			}
			else{
				rslt = eemDao.insertAgentDetails(conn, objVO);
			}
		} else if (objVO.getUpdateRec().equals("Y")) {
			if (StringUtil.nonNullTrim(objVO.getBrokAgentId()).equals("") && true==applAgentFlag) {
				// Start IFOX-00396423
				logger.debug("Deleting Agent ID for "+objVO.getApplId());
				logger.debug("Current User ID "+StringUtil.nonNullTrim(objVO.getOperId()));
				logger.debug("Agency ID "+StringUtil.nonNullTrim(objVO.getCommAgencyId()));
				logger.debug("Broker Type "+objVO.getBrokerType());
				// End IFOX-00396423
				rslt = eemDao.deleteApplAgentDetails(conn, objVO.getCustomerId(), objVO.getApplId());
			}
			else{
			rslt = eemDao.updateAgentDetails(conn, objVO);
			}
		}
		
		if (rslt == 1) {
			/**
			 * Cambia_OEV-Start
			 */
			objVO.setOevAgentCheck(true);
			/**
			 * Cambia_OEV-End
			 */
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}
		logger.info(LoggerConstants.methodEndLevel());
		return false;
	}
	// Agent ID Issue Fix - IFOX-00375436 / IFOX-00382751 - End
	//original application start
	//performance original application
	//changed private to public to insert comments entered before cancellation.
	public boolean setCommentDetails(EEMApplDao eemDao, Connection conn,String eemDb,
			EEMApplicationVO objVO,EEMApplCommentsVO commentVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		List lstComments = objVO.getLstComments();
		if (lstComments == null) {
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}
		for (int i = lstComments.size()-1; i >= 0; i--) {
			commentVO = (EEMApplCommentsVO)lstComments.get(i);
			if (commentVO.getInsert().equals("Y")) {
				commentVO.setCustomerId(objVO.getCustomerId());
				commentVO.setApplicationId(objVO.getApplId());
				String comment = StringUtil.nonNullTrim(commentVO.getApplComments());
				if (comment.length() > 255) {
					comment = comment.substring(0, 255);
					commentVO.setApplComments(comment);
				}
				//eemDao.insertCommentDetails(conn, commentVO);
				//original application start
				eemDao.insertCommentDetails(conn, commentVO,objVO.getUpdateRec());
				//original application end
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return true;
	}

	private void clearCommentDetailsFlag(EEMApplicationVO objVO) {
		logger.info(LoggerConstants.methodStartLevel());
		List lstComments = objVO.getLstComments();
		if (lstComments != null) {
			for (int i = lstComments.size()-1; i >= 0; i--) {
				EEMApplCommentsVO commentVO = (EEMApplCommentsVO)lstComments.get(i);
				commentVO.setInsert("N");
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	// IFOX-00367254 - ABD Issue fix start
	private boolean setEligDetails(EEMApplDao eemDao, Connection conn,
                                                EEMApplicationVO objVO) throws ApplicationException, SQLException {
		logger.info(LoggerConstants.methodStartLevel());
                                MBD mbd = objVO.getMbd();
                                if(mbd == null || mbd.getHicNbr() == null){
                                                eemDao.insertEligDetailsNotInMBD(conn, objVO);
                                                objVO.setNeedMBDUpdate("N");
                                }
                                else if (mbd.getHicNbr() != null && !mbd.getHicNbr().equals("") ) {
                                                if ("Y".equals(objVO.getNeedMBDUpdate()))
                                                                eemDao.insertEligDetails(conn, objVO);
                                                objVO.setNeedMBDUpdate("N");
                                } 
                                logger.info(LoggerConstants.methodEndLevel());
                                return true;
                }
	// IFOX-00367254 - ABD Issue fix end

	private boolean setBEQDetails(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		
		// What to do if no DOB / Should not be in BEQ Pending ????
		if (objVO.getApplStatus().equals(EEMConstants.APPL_STATUS_BEQPENDING)) {
			EMBeqVO beq = eemDao.getBEQDetailsFor(conn,objVO);
			if (beq == null)
				eemDao.insertBEQDetails(conn, objVO);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return true;
	}

	private boolean setErrorDetails(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		
		List lstErrors = objVO.getLstErrors();
		List lstTemp = eemDao.getErrorDetails(conn, objVO);
		if (lstErrors != null){
			EEMErrorVO objError = null;
			int rslt = 0;
			for (int i = 0; i < lstErrors.size(); i++) {
				objError = (EEMErrorVO)lstErrors.get(i);
				objError.setApplId(objVO.getApplId());
				//Excellus Retrofit_Start
				objError.setApplDate(objVO.getApplDate());
				//Excellus Retrofit_End
				// Update
				objError.setErrorStatus(EEMConstants.ERROR_STATUS_OPEN);
				rslt = eemDao.updateErrorDetails(conn, objError,objVO);
				
				// Insert
				if (rslt == 0) {
					eemDao.insertErrorDetails(conn, objError);
					rslt = 1;
				}
			}
			
			// Close Remaining errors
			for (int i = 0; i < lstTemp.size(); i++) {
				EEMErrorVO objTemp = (EEMErrorVO)lstTemp.get(i);
				boolean found = false;
				
				for (int j = 0; j < lstErrors.size(); j++) {
					objError = (EEMErrorVO)lstErrors.get(j);
					if (StringUtil.nonNullTrim(objTemp.getErrorCode()).equals(
							StringUtil.nonNullTrim(objError.getErrorCode())) &&
							StringUtil.nonNullTrim(objTemp.getFieldNbr()).equals(
									StringUtil.nonNullTrim(objError.getFieldNbr())) &&
									StringUtil.nonNullTrim(objTemp.getValue()).equals(
											StringUtil.nonNullTrim(objError.getValue()))) {
						found = true;
						break;
					}
					
				}
				if (!found) {
					//Excellus Retrofit_Start
					objTemp.setApplDate(objVO.getApplDate());
					//Excellus Retrofit_End
					objTemp.setErrorStatus(EEMConstants.ERROR_STATUS_CLOSED);
					objTemp.setLstUpdtUser(objVO.getOperId());
					rslt += eemDao.updateErrorDetails(conn, objTemp,objVO);
				}
			} 
			
			if (rslt == 0) {
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		} else if (lstTemp.size() > 0) { // Close Errors
			int rslt = 0;
			for (int i = 0; i < lstTemp.size(); i++) {
				EEMErrorVO objTemp = (EEMErrorVO)lstTemp.get(i);
				objTemp.setErrorStatus(EEMConstants.ERROR_STATUS_CLOSED);
				objTemp.setLstUpdtUser(objVO.getOperId());
				//Excellus Retrofit_Start
				objTemp.setApplDate(objVO.getApplDate());
				//Excellus Retrofit_End
				rslt += eemDao.updateErrorDetails(conn, objTemp,objVO);
			}
			if (rslt == 0) {
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return true;
	}
	
	private boolean setLEPUncovMnthCalM(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());

		try {
			// IFOX-00367660 - Trigger Issue fix start
			// no RFI error status
			/*if (StringUtil.nonNullTrim(objVO.getStatusRFI()).equals("")) {

				// Has RFI trigger
				EMApplTriggerVO trig = hasRFI(conn,objVO); 
				if (trig != null && !StringUtil.nonNullTrim(trig.getTriggerStatus()).equals("")) {
					int rslt = 0;
					// Update Follow Up Trigger status 
					rslt = eemDao.updateFUATrigger(conn, objVO
							.getCustomerId(), objVO.getApplId(),
							EEMConstants.TRIGGER_STATUS_CLOSPNDRPT);
					// allow follow up trigger to not update because they are not being created 2/21/2013
					if (rslt > 1) return false;
					
					// Check for trigger status
					if (!StringUtil.nonNullTrim(trig.getTriggerStatus())
							.equals(EEMConstants.TRIGGER_STATUS_CLOSED)) {
						rslt = eemDao.closeApplTrigger(conn, objVO
								.getCustomerId(), objVO.getApplId(), trig
								.getTriggerType(), trig.getLastUpdtTime());
						if (rslt != 1) return false; 
					}
				}
			}*/
			// IFOX-00367660 - Trigger Issue fix end
			
			/*
			 * Insert LEP information - Start
			 *
			 */

			/* 
			 * Check whether this Application Id is having any row in EM_APPL_LEP table.
			 * If row exists then skip the below LEP calculation logic
			 */
			boolean lepRecordFlag = false;
			lepRecordFlag = eemDao.verifyLEPRecord(conn,objVO.getCustomerId(),objVO.getApplId());
//			if(!lepRecordFlag){  
// ======================================LEP CALCULATION LOGIC - START ====================================			
			MBD mbd = objVO.getMbd();
			//System.out.println("MBD UNCOVERED MONTHS ::"+mbd.getUncovMonths());
			//System.out.println("MBD UNCOVERED MONTHS INT::"+Integer.parseInt(mbd.getUncovMonths()));
			int rslt1,rslt2 = 0;
			int interval    = 0;
			objVO = eemDao.getLepCalculationFlag(conn,objVO);
			if(objVO.getLepCalcFlag()!=null && objVO.getLepCalcFlag().equalsIgnoreCase("M")){
				if(objVO.getEnrollPlanDesgn().equalsIgnoreCase("MAPD") || objVO.getEnrollPlanDesgn().equalsIgnoreCase("PDP") ){
					if(mbd.getUncovMonths()!=null && !mbd.getUncovMonths().equals("") && !mbd.getUncovMonths().equalsIgnoreCase("000") && !mbd.getUncovMonths().equalsIgnoreCase("N/A")){
					//System.out.println("IN METHOD ");
					//Derive Uncovered Month Start Date
					//SELECT PARM_TEXT_VALUE FROM MSSTM361.PROFILE WHERE PLAN_ID = '99999' AND PARM_CD = 'HIMASTER' AND OVERRIDE_IND = 'N'
					String defaultDt=eemDao.getDefaultDate(conn)+"/01";
					//System.out.println("default date :"+defaultDt);
					Date convdefdate=new Date(Date.parse(defaultDt));
					//System.out.println("converted default date :"+convdefdate);
					Date reqDate = new Date(Date.parse(objVO.getReqDtCov()));
					//System.out.println("Requested Date : "+reqDate);
					
					Calendar sDate = Calendar.getInstance();
					Calendar eDate = Calendar.getInstance();
					sDate.setTime(convdefdate);
					eDate.setTime(reqDate);
					int diffinMnths = (eDate.getTime().getYear()-sDate.getTime().getYear())*12;
					diffinMnths =diffinMnths+((12-(sDate.getTime().getMonth()-1)+(eDate.getTime().getMonth()-12)))-1;
					//-----
					//System.out.println("difference in months :--- "+diffinMnths);
					interval = Integer.parseInt(mbd.getUncovMonths());
					int totalUncovMnths= diffinMnths+interval;
					if( totalUncovMnths > 0 ){
					// (int) ((convdefdate.getTime() - reqDate.getTime())/(1000*60*60*24));
					//System.out.println("Total Uncovered Months: "+totalUncovMnths);
						
					// Fix for IFOX-00388790: Start
			 		int befNuncmo = objVO.getNbrUnCMonths();
					objVO = eemDao.getLepExistingVal(conn,objVO);
					int aftNuncmo = objVO.getNbrUnCMonths();
					
					objVO.setNbrUnCMonths(totalUncovMnths);
					Calendar c = Calendar.getInstance(); 
					c.setTime(reqDate); 
					c.add(Calendar.MONTH, -totalUncovMnths);
					//System.out.println("**********"+ c.getTime().getDate());
					SimpleDateFormat sdFormat = new SimpleDateFormat("MM/dd/yyyy");
					String unCovStDt = sdFormat.format(c.getTime());
					//System.out.println("Uncov----Ds:"+unCovStDt);
					
					  objVO.setUncovMnthStrtDt(unCovStDt);
					    
						//Insert row in EM_APPL_LEP
						if(!lepRecordFlag  ){ 
							//System.out.println("Record(s) Not Existing Case");
							rslt2 = eemDao.insertLEPApplDetails(conn, objVO);
							//if (rslt2 != 1) return false;
								//System.out.println(rslt2+"Record(s) inserted");
						}
						else {
							//System.out.println("Record(s) Existing Case");
							if(aftNuncmo != totalUncovMnths){
								rslt2 = eemDao.updateLEPApplDetails(conn, objVO);
							}
							
							//if (rslt2 <=0 ) return false;
								//System.out.println(rslt2+"Record(s) Updated");
						}
						// Fix for IFOX-00388790: End
					/*else{
					  objVO.setNbrUnCMonths(0);
					  objVO.setUncovMnthStrtDt(objVO.getReqDtCov());
					}*/
					 
					
						//Derive OBC1 Timer Interval Days From EM_PROFILE table
						// and add the Interval to the Current Date
					
						String days = eemDao.getInterval(conn,objVO.getCustomerId());
						
						days = days.substring(0, days.indexOf("."));
						
						Integer val = Integer.parseInt(days);
					Calendar calendar = new GregorianCalendar();
					calendar.set(Calendar.DATE, calendar.get(Calendar.DATE)+val);
					
					String strMonth = String.valueOf(calendar.get(Calendar.MONTH)+1);
					if(strMonth.length() == 1)
						strMonth = "0" + strMonth;

					String strDate = String.valueOf(calendar.get(Calendar.DATE));
					if(strDate.length() == 1)
						strDate = "0" + strDate;
					//Insert OBC1 trigger
					rslt1 = eemDao.openLEPApplTrigger(conn, objVO
							.getCustomerId(), objVO.getApplId(),objVO.getOperId(), calendar.get(Calendar.YEAR) + strMonth + strDate);
					if (rslt1 != 1) return false;
//Commented Letters triggering functionality as Cambia is not using this - Start	
				/*	
					//Letters Part - Start
					//Derive PRTD & RDS Cnt values From MBD table
					objVO = eemDao.getPrtdRdsCnt(conn,objVO);
					String planDesgn = objVO.getEnrollPlanDesgn();
					//System.out.println("planDesgn ::"+planDesgn);
					
					if(objVO.getRdsCnt()!=null && objVO.getRdsCnt().equalsIgnoreCase("000")
							&& objVO.getPrtdCnt()!=null && objVO.getPrtdCnt().equalsIgnoreCase("000")){
						if(planDesgn!=null && planDesgn.equalsIgnoreCase("MAPD")){
							//A0427BD
							String trigCode = eemDao.getTriggerCode(conn, EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_2, objVO.getCustomerId(), objVO.getEnrollPlanDesgn());
							//System.out.println("trig code ###:1:"+trigCode);
							if(trigCode != null)
							{
								objVO.setTrigger_Type(trigCode);
								rslt1 = eemDao.createApplLEPLetter(conn, objVO);
							}
							if (rslt1 != 1) return false;
						}
						else {
							//A0427BP  
							String trigCode = eemDao.getTriggerCode(conn, EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_2, objVO.getCustomerId(), objVO.getEnrollPlanDesgn());
							//System.out.println("trig code ###:2:"+trigCode);
							if(trigCode != null)
							{
								objVO.setTrigger_Type(trigCode);
								rslt1 = eemDao.createApplLEPLetter(conn, objVO);
							}
							if (rslt1 != 1) return false;
						}
						
					}else if(planDesgn!=null && planDesgn.equalsIgnoreCase("MAPD")){
						//MAPD - A0426AD  
						String trigCode = eemDao.getTriggerCode(conn, EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_1, objVO.getCustomerId(), objVO.getEnrollPlanDesgn());
						//System.out.println("trig code ###:3:"+trigCode);
						if(trigCode != null)
						{
							objVO.setTrigger_Type(trigCode);
							rslt1 = eemDao.createApplLEPLetter(conn, objVO);
						}
						if (rslt1 != 1) return false;
					}
					else{
						//PDP - A0426AP 
						String trigCode = eemDao.getTriggerCode(conn, EEMConstants.EEM_LEP_APPL_LTR_FUN_TYPE_1, objVO.getCustomerId(), objVO.getEnrollPlanDesgn());
						//System.out.println("trig code ***:4:"+trigCode);
						if(trigCode != null)
						{
							objVO.setTrigger_Type(trigCode);
							rslt1 = eemDao.createApplLEPLetter(conn, objVO);
						}
						if (rslt1 != 1) return false;
					}
					
					*/
//Commented Letters triggering functionality as Cambia is not using this - End					
				}
			
			else //If uncovmonths <=0 Delete LEP record from EM_APPL_LEP table, Close OBC1/Letters
			{
				//System.out.println("uncovmonths <=0 Case");
				rslt2 = eemDao.deleteLEPApplDetails(conn, objVO.getCustomerId(), objVO.getApplId());// deleting the LEP Details
				//if (rslt2 != 1) return false;
				   //// udating the OBC1/Letters
				rslt2 = eemDao.closeOBCLettersTrigger(conn, objVO.getCustomerId(), objVO.getApplId());
				//if (rslt2 >= 1) return false;
				//if (rslt2 <=0 ) return false;
					//System.out.println(rslt2+"Record(s) Updated");
			}
					
				//Letter Part End
				}
				
				
			
			// ======================================LEP CALCULATION LOGIC - ENDS ====================================
			
		} //main If loop  	
			/*
			 * Insert LEP information - End
			 */
			}//Plan Designation Check	
		} 
		catch(SQLException se) {
			logger.error(LoggerConstants.exceptionMessage(se.toString()));
			se.printStackTrace();
			throw new ApplicationException(se);
		}
		catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return true;
	}
	
	private boolean checkException(String value, List lstExceptions) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		boolean blnCheck = false;
		for (int i = 0; i < lstExceptions.size(); i++) {
			EEMApplAttestationVO attestVO = (EEMApplAttestationVO) lstExceptions.get(i);
			if (value.equals(attestVO.getSepException()) && !attestVO.getDeleteInd().equals("Y")) {
				attestVO.setLogicalDel("N");
				blnCheck = true;
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return blnCheck;
	}  
	
	private String changeCase(String field) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());

		String str = field.substring(0, 1);
		logger.info(LoggerConstants.methodEndLevel());
		return str.toUpperCase() + field.substring(1);
	}
		//original application start
	public EEMOriginalApplicationVO getApplOriginal(Connection conn,
			EEMApplicationVO objVO) {
		logger.info(LoggerConstants.methodStartLevel());
		EEMOriginalApplicationVO formVO =null;
		try{
			EEMCodeCache cache = EEMCodeCache.getInstance();
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			formVO = eemDao.getApplOrigDetails(conn, objVO);
			//for Primary address
			formVO.setPerState(cache.getCode(formVO.getPerState(), cache.getLstStates()));
			String zip = formVO.getPerZip5();
			if (zip.length() == 9) {
				formVO.setPerZip5(zip.substring(0,5));
				formVO.setPerZip4(zip.substring(5,9));
			} else if (zip.length() == 5) {
				formVO.setPerZip5(zip);
				formVO.setPerZip4("");
			}
			List lstCounty = (List)cache.getHmpCounty().get(formVO.getPerState());
			if (lstCounty != null) {
				formVO.setPerCounty(cache.getDesc(formVO.getPerCounty(), lstCounty));
			}
			//for Mailing Address
			formVO.setMailState(cache.getCode(formVO.getMailState(), cache.getLstStates()));
			 zip = formVO.getMailZip5();
			if (zip.length() == 9) {
				formVO.setMailZip5(zip.substring(0,5));
				formVO.setMailZip4(zip.substring(5,9));
			} else if (zip.length() == 5) {
				formVO.setMailZip5(zip);
				formVO.setMailZip4("");
			}
			lstCounty = (List)cache.getHmpCounty().get(formVO.getMailState());
			if (lstCounty != null) {
				formVO.setMailCounty(cache.getDesc(formVO.getMailCounty(), lstCounty));
			}
			//For AuthRep Address
			formVO.setAuthRepState(cache.getCode(formVO.getAuthRepState(), cache.getLstStates()));
			 zip = formVO.getAuthRepZip5();
			if (zip.length() == 9) {
				formVO.setAuthRepZip5(zip.substring(0,5));
				formVO.setAuthRepZip4(zip.substring(5,9));
			} else if (zip.length() == 5) {
				formVO.setAuthRepZip5(zip);
				formVO.setAuthRepZip4("");
			}
			
			getOrigAttestDetails(eemDao, conn, objVO, formVO, "orig");
			
		}
		catch(Exception e){
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Retrieve original application Error:"+ e.getMessage());
		}
		logger.info(LoggerConstants.methodEndLevel());
		return formVO;
	}
	//original application end
//original application start
	private void getOrigAttestDetails(EEMApplDao eemDao, Connection conn, EEMApplicationVO applVO,
			EEMOriginalApplicationVO objVO, String applType) throws ApplicationException, IllegalArgumentException, SQLException {
		logger.info(LoggerConstants.methodStartLevel());
		eemDao.getAttestationDetails(conn, applVO, applType);
		List lstAttest = applVO.getLstAttestation();
		List lstTemp = new ArrayList();
		int index = 0;
		for (int i = 0; i < lstAttest.size(); i++) {
			EEMApplAttestationVO attestVO = (EEMApplAttestationVO) lstAttest.get(i);
			if (!attestVO.getDeleteInd().equals("Y")) {
				attestVO.setIndex("" + index++);
				String exception = attestVO.getSepException();
				if (requireDtForException(exception)) {
					attestVO.setSepException(exception + "Y");
				} else {
					attestVO.setSepException(exception + "N");
				}
				lstTemp.add(attestVO);
			}
		}
		objVO.setLstAttestation(lstTemp);
		logger.info(LoggerConstants.methodEndLevel());
		
	}

	//original application end
	
	/**
	 * 
	 * @param eemDao contains  EEMApplDAo
	 * @param conn contains Connection
	 * @param objVO contains EEMApplicationVO
	 * @return boolean value
	 * @throws Exception 
	 */
	private boolean insertApplDeniedTrigger(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			int trigger=0;
			DateUtil du = new DateUtil();
			String ts = du.getDB2DTS();
			if(!(objVO.getCurrStatus().equals(EEMConstants.APPL_STATUS_COMPLETED)||objVO.getCurrStatus().equals(EEMConstants.APPL_STATUS_APPROVED))){
				if(isDenied(objVO)){
				//	System.out.println(" objVO.getEnrollPlanDesgn()--"+objVO.getEnrollPlanDesgn());
					/**UseCaseName 015_Highmark_SUC_Denials for Enrollment and Disenrollment - Start  */
				
					//Begin: Modfied for IFOX-00402714
					//String applDate = DateFormatter.reFormat(objVO.getApplDate(),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
					String effectiveDate = DateFormatter.reFormat(objVO.getReqDtCov(),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
					//End: Modfied for IFOX-00402714
					
					EMApplTriggerVO trig = new EMApplTriggerVO();
					//String planDesgn = eemDao.getPlanDesig(conn, objVO.getCustomerId(), objVO.getCurrGroup(), objVO.getCurrProduct(), applDate);
					String trigCode = eemDao.getTriggerCode(conn, EEMConstants.EEM_APPL_DENIAL_TRIG_FUN_TYPE, objVO.getCustomerId(), objVO.getEnrollPlanDesgn());
					
					if(trigCode != null)
						{
						
					trig.setApplicationId(Integer.parseInt(objVO.getApplId()));
					trig.setCustomerId(objVO.getCustomerId());
					trig.setTriggerType(EEMConstants.TRIGGER_TYPE_MANUAL_LTR);
					
					//Begin: Modfied for IFOX-00402714
					//trig.setEffectiveDate(applDate);
					trig.setEffectiveDate(effectiveDate);
					//End: Modfied for IFOX-00402714
					
					trig.setTriggerStatus(EEMConstants.TRIGGER_STATUS_OPEN);
					trig.setTriggerCode(trigCode);
					trig.setOrigTriggerType("");
					trig.setOrigTriggerCode("");
					trig.setOrigEffectiveDate("");
					trig.setOrigTriggerCreateTime("");
					trig.setCreateUserid(objVO.getOperId());
					trig.setCreateTime(ts);
					trig.setLastUpdtUserid(objVO.getOperId());
					trig.setLastUpdtTime(ts);
					eemDao.updateApplTrigger(conn, trig);
					trigger = eemDao.insertApplTrigger(conn, trig);
					/**UseCaseName 015_Highmark_SUC_Denials for Enrollment and Disenrollment - End  */
						}
					if(trigger==0){
						logger.info(LoggerConstants.methodEndLevel());
						return false;
					}
					}
				
			}
		} catch(Exception se) {
			logger.error(LoggerConstants.exceptionMessage(se.toString()));
			throw new ApplicationException(se);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return true;
	}
	/**
	 * 
	 * @param objVO contains EEMApplicationVO
	 * @return boolean
	 * @throws ApplicationException
	 */
	public boolean isDenied(EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String applStatus = StringUtil.nonNullTrim(objVO.getApplStatus());
		logger.info(LoggerConstants.methodEndLevel());
		if (applStatus.equals(EEMConstants.APPL_STATUS_DENIEDELG) ||
				applStatus.equals(EEMConstants.APPL_STATUS_DENIEDETYP) ||
				applStatus.equals(EEMConstants.APPL_STATUS_DENIEDOTHR)) {
			return true;
		}
		return false;
	}
	 /**
		 * Cambia_Application Cancellation-Start
		 */
		/**
		 * TO generate letter trigger for Cancellation
		 * @param conn contains Connection
		 * @param userId contains User Id
		 * @param mfId conains customer id
		 * @param context contains EEMContext
		 * @param filterVO contains EEMApplicationVO
		 * @return integer
		 * @throws Exception
		 */
	
				/*IFOX-00427552 - start*/
			public int applCancelLtrReg(Connection conn, String eemDb, String userId, String mfId, EEMContext context, EEMApplicationVO filterVO) throws Exception {
				logger.info(LoggerConstants.methodStartLevel());
				
				EEMApplDao applDao = new EEMApplDao();
				String reasonCd = filterVO.getReasonPDP();
				String triggerCode = null;
				

				DateUtil du = new DateUtil();
				String ts = du.getDB2DTS();

				boolean lastAutoCommit = conn.getAutoCommit();
				boolean inTrans = false;
				int sqlCnt = 0;
				
				//IFOX-00427552-start
				String cancl07 = EEMProfileSettings.getCalendarProfileItem(eemDb,mfId, EEMProfileSettings.TSACANCL07);
				
				conn.setAutoCommit(false);
				EMApplTriggerVO trig = new EMApplTriggerVO();

				trig.setCustomerId(mfId);
				trig.setApplicationId(Integer.parseInt(filterVO.getApplId()));
				trig.setTriggerType(EEMConstants.TRIGGER_TYPE_MANUAL_LTR);
				//INTERNAL DEFECT - 1 AS PER BCBSAZ Tracker - Start
				trig.setEffectiveDate(DateFormatter.reFormat(filterVO.getReqDtCov(), DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD));
				//INTERNAL DEFECT - 1 AS PER BCBSAZ Tracker - End
				trig.setTriggerStatus(EEMConstants.TRIGGER_STATUS_OPEN);
							
				if (cancl07 != null && cancl07.equals("Y")) {
					if ((reasonCd.equals("10007") && filterVO.getEnrollPlanDesgn().equals("MA"))){
						triggerCode = "CU043M ";
					}
					else if ((reasonCd.equals("10007") && filterVO.getEnrollPlanDesgn().equals("MAPD"))){
						triggerCode = "CU043D ";
					}
					else {
						if(!(reasonCd.equals("10005")||reasonCd.equals("10006")||reasonCd.equals("10008")))
					   triggerCode = applDao.getRejectLetterCode(conn, mfId, filterVO.getEnrollPlanDesgn(),EEMConstants.EEM_APPL_CANCEL_TRIG_FUA_TYPE);
					}
				}	
				
				else {
					if(!(reasonCd.equals("10005")||reasonCd.equals("10006")||reasonCd.equals("10007")||reasonCd.equals("10008")))
				   triggerCode = applDao.getRejectLetterCode(conn, mfId, filterVO.getEnrollPlanDesgn(),EEMConstants.EEM_APPL_CANCEL_TRIG_FUA_TYPE);
				}
				//IFOX-00427552-end
				trig.setTriggerCode(triggerCode);
				trig.setOrigTriggerType("");
				trig.setOrigTriggerCode("");
				trig.setOrigEffectiveDate("");
				trig.setOrigTriggerCreateTime("");
				trig.setCreateUserid(userId);
				trig.setCreateTime(ts);
				trig.setLastUpdtUserid(userId);
				trig.setLastUpdtTime(ts);
				
				if (triggerCode != null)
				{
				try {
					inTrans = true;
					sqlCnt = applDao.insertApplTrigger(conn,trig);
						
					if (sqlCnt != 1)
						throw new Exception("Invalid SQL Update Count [" + sqlCnt + "]");
				}catch(Exception e){
				//	LOGGER.error("Error Details: "+e.getMessage());
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug("Error Message while updating cancelation ltr trigger ::::::"+e.getMessage());
					throw new ApplicationException(e);
				}
				}

				try{

					int sqlCnt1 = applDao.updtApplReject(conn, filterVO , userId, mfId,reasonCd);
					
				     if (sqlCnt1 != 1)
						throw new Exception("Could not update Application table for reject reason: [" + reasonCd+ "]");
					sqlCnt = sqlCnt1;
					conn.commit();
					inTrans = false;
				} catch(Exception e) {
					
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug("Error Message while updating application status to cancel ::::::"+e.getMessage());

					
				} finally {
					if (inTrans) {
						try {
							conn.rollback();
						} catch(Exception e) {
							logger.error(LoggerConstants.exceptionMessage(e.toString()));
							logger.debug(e.toString());
						}
					}
					conn.setAutoCommit(lastAutoCommit);
				}
				logger.info(LoggerConstants.methodEndLevel());
				return sqlCnt;
			}
			
			/*IFOX-00427552 - End*/
			/**
			 * TO Close all the timers 
			 * @param objVO contains EEmApplicationVO
			 * @param conn contains Connection
			 * @throws ApplicationException
			 */
			public void cancelTimers(EEMApplicationVO objVO, Connection conn) throws ApplicationException {
				logger.info(LoggerConstants.methodStartLevel());
				logger.debug("CancelTimers for Applications :Start");
				
				try {
					
					EEMApplDao applDao = DaoFactory.getInstance().getEEMApplDao(); 
					EMApplTriggerVO trig = new EMApplTriggerVO();
					String ts = new DateUtil().getDB2DTS();
					trig.setCustomerId(objVO.getCustomerId());
					trig.setApplicationId(Integer.parseInt(objVO.getApplId()));
					trig.setTriggerType(EEMConstants.TRIGGER_TYPE_FOLLOW_UP);
					trig.setEffectiveDate(ts);
					trig.setTriggerStatus(EEMConstants.TRIGGER_STATUS_CLOSED);
					trig.setTriggerCode("");
					trig.setOrigTriggerType("");
					trig.setOrigTriggerCode("");
					trig.setOrigEffectiveDate("");
					trig.setOrigTriggerCreateTime("");
					trig.setCreateUserid(objVO.getOperId());
					trig.setCreateTime(ts);
					trig.setLastUpdtUserid(objVO.getOperId());
					trig.setLastUpdtTime(ts);
					
					int trigResult= applDao.closeFUATrigger(conn, objVO,trig);
					if(trigResult>0){
						logger.debug("Successfully  close the FUA trigger when Application Status is "+objVO.getApplStatus());
					}
					else {
						logger.debug("No FUA trigger when Application Status is "+objVO.getApplStatus());
					}
					
				

				} catch (Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					throw new ApplicationException(e);
				}
				logger.debug("CancelTimers for Applications :End");
				logger.info(LoggerConstants.methodEndLevel());
				
			}
			 /**
			 * Cambia_Application Cancellation- End
			 */
			/**
		     * Cambia_PRE-SET NOTES - Start
		     */
		     
			/**
			 * @author Komal
			 * @param conn contains Connection
			 * @param filterVO -EEMApplicationVO
			 * @param userId contains User ID
			 * @param presetnote contains Preset Note
			 * @param presetnotedesc contains PresetNote Description
			 * @param radioCheck contains the string
			 * @return boolean
			  * @throws ApplicationException
			 */
			public boolean addPreSetNote(Connection conn,EEMApplicationVO filterVO,String userId,String presetnote,String presetnotedesc,String radioCheck) throws ApplicationException, SQLException
			{
				logger.info(LoggerConstants.methodStartLevel());
				logger.debug("Updating PresetNote and LongDescription :Start");
				boolean lastAutoCommit = conn.getAutoCommit();
			    boolean success = false;
				
				try{
					
					conn.setAutoCommit(false);
					int cnt =0;
				
		        EEMApplDao applDao = new EEMApplDao(); 
				EmPreSetNoteVO newvo = new EmPreSetNoteVO();
				if(radioCheck.equals("A")){ //A is indicator for Adding preset note
			      newvo.setPreSetNote(presetnote); 
				  newvo.setPreSetNoteDesc(presetnotedesc);
			      cnt = applDao.insertPreSetNote(conn,newvo,filterVO);
			     
			     if(cnt==1)
				 { 
			    	 
						conn.commit();
						//inTrans = false;
						//return true;
						success = true;
						filterVO.setMessage("Preset Note added Successfully!");
				 }
				}
				else if(radioCheck.equals("M"))//M is the indicator for modifying preset note
				{
					String preSetKey = filterVO.getPreSetKey();
					newvo.setPreSetNote(presetnote); 
					newvo.setPreSetNoteDesc(presetnotedesc);
				
					  cnt = applDao.modifyPreSetNote(conn, newvo, preSetKey, filterVO.getCustomerId());
					 if(cnt!=0)
					 {
						 
							conn.commit();
						
							success = true;
							filterVO.setMessage("Preset Note modified Successfully!");
					 }
					 
				 
					
						}
					
							
				
				else if(radioCheck.equals("D"))//D indicator for deleting preset note
				{
					
					 newvo.setPreSetNote(presetnote); 
					   newvo.setPreSetNoteDesc(presetnotedesc);
					  
					cnt  = applDao.deletePreSetNote(conn, newvo, filterVO.getCustomerId());
					 
					if(cnt==1){
						
					conn.commit();
					
					success = true;
					filterVO.setMessage("Preset Note deleted Successfully!");
				
					} 
				
				
		      } else {
				filterVO.setMessage("Data Not Changes");
				success = false;
			}
			
				
			} catch(Exception e) {
				//LOGGER.error("Error Details: "+e.getMessage());
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("Updating PresetNote and LongDescription :"+ e.getMessage());
				conn.rollback();
				//return false;
				success = false;
				throw new ApplicationException(e);
			} 
			
					
				logger.debug("Updating PresetNote and LongDescription :End");	 
				logger.info(LoggerConstants.methodEndLevel());
				//return true;
				return success;

			}
			/**
			 * @author Komal
			 * @param conn contains Connection
			 * @param filterVO -EEMApplicationVO
			
			 * @return lstFields
			 * @throws ApplicationException
			 */
			public List getPreSetNoteList(Connection conn,EEMApplicationVO filterVO) throws ApplicationException
			{
				logger.info(LoggerConstants.methodStartLevel());
				logger.debug("Get List of PreSetNotes :Start");
				List lstFields = null;
				try {
					
					EEMApplDao applDao = DaoFactory.getInstance().getEEMApplDao(); 
				
					lstFields = applDao.getPreSetNotes(conn,filterVO,"");
					//System.out.println("list fields"+lstFields.size());
				   // lstFields = new ArrayList(mp.keySet());
				
				   // filterVO.setPreSetNoteList(lstFields);
					
				

				} catch (Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					//LOGGER.error("Error Details: "+e.getMessage());
					throw new ApplicationException(e);
				}
				logger.debug("Get List of PreSetNotes:End");
				logger.info(LoggerConstants.methodEndLevel());
				return lstFields;

			}


			 /**
		     *Cambia_PRE-SET NOTES - End
		     */
			/**
			 * Cambia_OEVProcess-Start
			 */
			
			/**
		     * Update OEV application 
		     * @author Srishti Srivastava
		     * @param conn contains Connection
		     * @param userId contains User Id
		     * @param mfId conains customer id
		     * @param context contains EEMContext
		     * @param filterVO contains EEMApplicationVO
		     * @throws Exception
		     * @return sqlCnt 
		     */

		    public EEMApplicationVO applOev(Connection conn, String userId, String mfId, EEMContext context, EEMApplicationVO filterVO, String eemDb) throws Exception {
		    	logger.info(LoggerConstants.methodStartLevel());
			//logger.info("applOev : Start");
			 
			 EEMOevService oevSetvice = new EEMOevService();
			 String button = filterVO.getOevButton();
			 EmMbrOevInfoVO mbrOevVO =  filterVO.getOevInfo();
			 EmMbrOevInfoVO mbrOevReturn = filterVO.getOevRetInfo();
			 List<EmMbrOevInfoVO> oevCalAttempts = new ArrayList<EmMbrOevInfoVO>();
			 List<EmMbrOevInfoVO> returnCalls = new ArrayList<EmMbrOevInfoVO>();
			
			 
			 if (filterVO.isOevInfoChanged()) {
					filterVO.setOevInfoChanged(false);
							if(mbrOevVO!=null){
									if(filterVO.getOevButton().equals("F"))
									mbrOevVO.setCallComplete("F");
									else if(filterVO.getOevButton().equals("S"))
									mbrOevVO.setCallComplete("S");
									mbrOevVO.setCallType("O");
									oevCalAttempts.add(mbrOevVO);
									filterVO.setOevCallAttempts(oevCalAttempts);
									
								}//if
			 }
			 if(filterVO.isOevReturnInfoChanged()){
				   filterVO.setOevReturnInfoChanged(false);
				  // System.out.println("mbr oevvo"+mbrOevReturn.getAttempt()+mbrOevReturn.getStatus());
				//   System.out.println("mbr oevvo"+mbrOevReturn.getAttempt()+mbrOevReturn.getStatus());
					if(mbrOevReturn!=null && !(mbrOevReturn.getStatus().equals("")||mbrOevReturn.getStatus()==null)){
					//	System.out.println(" in mbr oev value"+mbrOevReturn);
								if((mbrOevReturn.getAttempt()==null || mbrOevReturn.getAttempt().equals(""))&&filterVO.isOevCheck())
									mbrOevReturn.setAttempt(mbrOevVO.getAttempt());
								if(filterVO.getOevButton().equals("F"))
									mbrOevReturn.setCallComplete("F");
								else if(filterVO.getOevButton().equals("S"))
									mbrOevReturn.setCallComplete("S");
								mbrOevReturn.setCallType("R");
								returnCalls.add(mbrOevReturn);
								filterVO.setReturnCalls(returnCalls);	
							}//if
						
			}
			
			int applId = Integer.parseInt(filterVO.getApplId());
			
		    boolean rslt = oevSetvice.setApplOevUpdate(conn, filterVO.getCustomerId(),filterVO,filterVO.getMbrId(),
				  mbrOevVO, mbrOevReturn,oevCalAttempts,returnCalls,button,applId);
		   
		   // -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - Start
		    filterVO = getApplDetails(conn, eemDb, filterVO);
		   // -- IFOX-00370735 - Agent Dropdown Issue - Retro Fix from Base - End
		  
		    
		    if(!rslt) 
		    	filterVO.setMessage("No OEV Row(s) Updates");
		    
		   
				//logger.info("applOevUpdate : End");
		    logger.info(LoggerConstants.methodEndLevel());
		return filterVO;
			}
		    
		    /**
			 * 
			 * @param conn contains Connection
			 * @param formVO contains EEMApplicationVO
			 * @return EEMApplicationVO
			 * @throws ApplicationException
			 */
			public EEMApplicationVO getOevDetails(Connection conn,
					EEMApplicationVO formVO) throws ApplicationException {
				logger.info(LoggerConstants.methodStartLevel());
				
				try {

					EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
					EEMOevService oevSetvice = new EEMOevService();
					
		 
				
				String check = checkForOev(eemDao, conn, formVO);
		
				formVO.setOevTimerCheck(check);
				
		
				formVO.setOevCallAttempts(oevSetvice.getApplOevInfo(conn, formVO.getCustomerId(), formVO.getMbrId(),"O", formVO));
				formVO.setReturnCalls(oevSetvice.getApplOevInfo(conn, formVO.getCustomerId(), formVO.getMbrId(),"R",formVO)); 
				
				  if((formVO.getOevCallAttempts()!=null && formVO.getOevCallAttempts().size()>0) && (formVO.getOevCallStatus()!=null && formVO.getOevCallStatus().size()>0) ){
					
				        EmMbrOevInfoVO latestCall =(EmMbrOevInfoVO)formVO.getOevCallStatus().get(formVO.getOevCallStatus().size()-1);
				      
						if((latestCall.getStatus().equals("C") && latestCall.getCallComplete().equals("F")))
							formVO.setOev2TimerCheck(true);
						
				        }
				        if((formVO.getReturnCalls() !=null &&  formVO.getReturnCalls().size()>0) && (formVO.getOevRetStatus()!=null && formVO.getOevRetStatus().size()>0) ){
				        	
				        	EmMbrOevInfoVO latestRetCall =(EmMbrOevInfoVO)formVO.getOevRetStatus().get(formVO.getOevRetStatus().size()-1);
				        	 
						if(latestRetCall.getStatus().equals("C") && latestRetCall.getCallComplete().equals("F"))
								formVO.setOev2TimerCheck(true);
					      
				        }
				      
			
				}
				
				catch(Exception e){
					//LOGGER.error("Error Details: "+e.getMessage());
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug("getOEv Details Appl "+e.getMessage());
					throw new ApplicationException(e);
				}
				logger.info(LoggerConstants.methodEndLevel());
				return formVO;
			}
			
			/**
			 * Checks for whether OEV 10 day timer present 
			 * @param eemDao contains EEMApplDao
			 * @param conn contains Connection
			 * @param objVO contains EEMApplicationVO
			 * @return string
			 * @throws ApplicationException
			 */
			public String checkForOev(EEMApplDao eemDao, Connection conn,
					EEMApplicationVO objVO) throws ApplicationException {
				logger.info(LoggerConstants.methodStartLevel());
				
				EMApplTriggerVO trig = null;
			
				try {
					trig = eemDao.getApplTrigger(conn, objVO.getCustomerId(), NumberUtils.stringToInt(objVO.getApplId()),EEMConstants.TRIGGER_TYPE_FOLLOW_UP, "OEV1");
				      if(trig!=null){
				    	  logger.info(LoggerConstants.methodEndLevel());
				    	  return "true";
				    	  
				    
				      } else {
				    	trig = eemDao.getApplTrigger(conn, objVO.getCustomerId(), NumberUtils.stringToInt(objVO.getApplId()),EEMConstants.TRIGGER_TYPE_FOLLOW_UP, "OEV2");
				        if(trig!=null){
				        	logger.info(LoggerConstants.methodEndLevel());
				        	return "true";
				        }
				        else {
				        	logger.info(LoggerConstants.methodEndLevel());
				        	return "false";
				        }
				      }
				 
				} catch (Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug("application checkforOEv :"+e.getMessage());
					//throw new ApplicationException(e);
					//LOGGER.error("Error Details: "+e.getMessage());
				}
				logger.info(LoggerConstants.methodEndLevel());
				return "false";//no timer present 
			}
			
			
			/** Insert OEV 10 day timer 
			 * @param eemDao contains EEMApplDao
			 * @param conn contains Connection
			 * @param objVO contains EEMApplicationVO
			 * @return true
			 * @throws ApplicationException
			 */
			private boolean setOevTimer(EEMApplDao eemDao, Connection conn,
					EEMApplicationVO objVO) throws ApplicationException {
				logger.info(LoggerConstants.methodStartLevel());
				try {
				//	System.out.println("inside setting timer...");
				//	System.out.println(" agent "+objVO.getCommAgencyId()+" "+objVO.getBrokerType());
					//Changed for testing 
					if(!(objVO.getCommAgencyId().equals("")||objVO.getBrokerType().equals(""))){
					EEMOevDao dao = new EEMOevDao();
					EMApplTriggerVO trig = new EMApplTriggerVO();
					String 	ts = new DateUtil().getDB2DTS();
					//int sqlCnt= 0;
					boolean sqlCnt = false;
					EEMApplDao applDao = new EEMApplDao();
					boolean check;
					//Commented out the logic of creating the OEVtimer during the Application creation-Start
					/*
					//System.out.println(" in appls service "+objVO.getApplDate());
					String newEffectivateDate = DateMath.calculateTimerDate(objVO.getApplDate(), 10);
					//System.out.println(" in appl service aftr DateMath"+newEffectivateDate);
					String userId = objVO.getOperId();

					trig.setCustomerId(objVO.getCustomerId());
					trig.setApplicationId(Integer.parseInt(objVO.getApplId()));
					trig.setTriggerType(EEMConstants.TRIGGER_TYPE_FOLLOW_UP);
					trig.setEffectiveDate(newEffectivateDate);
					trig.setTriggerStatus(EEMConstants.TRIGGER_STATUS_OPEN);
					trig.setTriggerCode("OEV1");
					trig.setOrigTriggerType("");
					trig.setOrigTriggerCode("");
					trig.setOrigEffectiveDate("");
					trig.setOrigTriggerCreateTime("");
					trig.setCreateUserid(userId);
					trig.setCreateTime(ts);
					trig.setLastUpdtUserid(userId);
					trig.setLastUpdtTime(ts);
					EMApplTriggerVO trig1 = eemDao.getApplTrigger(conn, objVO.getCustomerId(), Integer.parseInt(objVO.getApplId()), EEMConstants.TRIGGER_TYPE_FOLLOW_UP, "OEV1");
				
					if(trig1==null || trig1.equals("")){
						
					sqlCnt = dao.insertApplOevTimer(conn, objVO, trig);
				
					*/
					//Commented out the logic of creating the OEVtimer during the Application creation-End
				if(objVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_MA) || objVO.getApplType().equals(EEMConstants.OPTION_APPLNEWMBR_PD) ){
				 	if(!objVO.getEnrollPbp().equals("")){
						if(Integer.parseInt(objVO.getEnrollPbp())<=799){
					String triggerCode = applDao.getRejectLetterCode(conn, objVO.getCustomerId(), objVO.getEnrollPlanDesgn(),EEMConstants.EEM_APPL_OEV_TRIG_LTR_TYPE);
					if(triggerCode != null){
					trig.setCustomerId(objVO.getCustomerId());
					trig.setApplicationId(Integer.parseInt(objVO.getApplId()));
					trig.setTriggerType(EEMConstants.TRIGGER_TYPE_MANUAL_LTR);
					trig.setEffectiveDate(DateFormatter.reFormat(StringUtil.nonNullTrim(objVO.getReqDtCov()),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD));
					trig.setTriggerStatus(EEMConstants.TRIGGER_STATUS_OPEN);
					trig.setTriggerCode(triggerCode);
					trig.setOrigTriggerType("");
					trig.setOrigTriggerCode("");
					trig.setOrigEffectiveDate("");
					trig.setOrigTriggerCreateTime("");
					trig.setCreateUserid(objVO.getOperId());
					trig.setCreateTime(ts);
					trig.setLastUpdtUserid(objVO.getOperId());
					trig.setLastUpdtTime(ts);
					 check = applDao.checkApplTriggerAnyStatus(conn, trig);
			        
					 // if trigger not present-insert new trigger     
				       if(check!=true){
							sqlCnt = applDao.insertApplOEVTrigger(conn, trig);
							if(!sqlCnt)
								objVO.setMessage("Error inserting oev trigger");
				       }
					}   
					// return false;
					 }	
				 	}
					}//PBP<=799
				  }//PBP not null
				}//NMA || NPD	
				catch(Exception se) {
					logger.error(LoggerConstants.exceptionMessage(se.toString()));
					logger.debug("Error Details: "+se.getMessage());
					logger.debug("Inserting 10 day oev timer for appl -Error:"+se.getMessage());
					//throw new ApplicationException(se);
					se.printStackTrace();
					logger.info(LoggerConstants.methodEndLevel());
					 return false;
				}
				//objVO.setOevTimerCheck("true");
				logger.info(LoggerConstants.methodEndLevel());
				return true;
			}
		    /**
		     *Cambia_OEVprocess -end
		     */
			/**
			 * Start -- for 020_UI Mock_ups-- to view letter from DB
			 * @throws ApplicationException 
			 */
			// Added Exception Class for LEP NUNCMO CR
			public void displayDocumentFromDB(Connection archivalDBConnection, Connection conn, EmCorrMbrVO emCorrMbrVO) throws ApplicationException, SQLException {
				logger.info(LoggerConstants.methodStartLevel());
				new EEMEnrollDao().displayDocumentFromDB(archivalDBConnection,conn, emCorrMbrVO); //IFOX-00412749
				logger.info(LoggerConstants.methodEndLevel());
			}	
			/**
			 * End -- for 020_UI Mock_ups-- to view letter from DB
			 */    
			
			/**
			 * @author Pramod Chandra
			 * @param conn contains Connection	
			 * @param eemDb contains String
			 * @param objVO contains EEMApplicationVO
			 * @param lstFields contains List

			 * @return EEMErrorVO
			 * @throws ApplicationException
			 */
			public List checkProviderDates(Connection conn, String eemDb, EEMApplicationVO objVO,
						List lstFields) throws ApplicationException {	
				logger.info(LoggerConstants.methodStartLevel());
				 	EEMErrorVO objError = null;
				 	//boolean checkProviderDate = false;
					EEMFieldErrorVO field = getField("pcpName", lstFields);
					/*if (field == null) {
						return objError;
					}*/
					List lstPcpErrors = new ArrayList();
					List validatePcp = new ArrayList();
				    Boolean flag = false;
				    String acceptNewPatient = null;
					try {
						EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
						boolean error = false;
						String errorCode = "";
						
						String pcpError = EEMProfileSettings.getCalendarProfileItem(eemDb,
								objVO.getCustomerId(), EEMProfileSettings.PCPNEWPATC);
						
						
						if(!(objVO.getPcpOfficeCd() == null) && !objVO.getPcpOfficeCd().equalsIgnoreCase("")){
							if(!(objVO.getReqDtCov() == null) && !objVO.getReqDtCov().equals("")){
								 validatePcp = eemDao.validateEnrolledPcp(conn,objVO);
							}
							if(validatePcp != null && validatePcp.size() > 0){
								flag = (Boolean)validatePcp.get(0);
								acceptNewPatient = (String)validatePcp.get(1);
							}
							if(!flag){
								errorCode = "AP218";
								String status = EEMConstants.APPL_STATUS_READYAPPR;
								objError = getErrorVO(field, objVO, errorCode, status);
								objError.setValue(objVO.getPcpOfficeCd());
								if(objError != null){
									lstPcpErrors.add(objError);
								}
							}	
							if(!flag){
								errorCode = "AP215";
								String status = EEMConstants.APPL_STATUS_READYAPPR;
								objError = getErrorVO(field, objVO, errorCode, status);
								objError.setValue(objVO.getPcpOfficeCd());
								if(objError != null){
									lstPcpErrors.add(objError);
								}
							}
							//IFOX-00394709
							
						if(!pcpError.equalsIgnoreCase("Y")){
							if(StringUtil.nonNullTrim(acceptNewPatient).equalsIgnoreCase("N") &&
									!StringUtil.nonNullTrim(objVO.getPcpCurrPatnt()).equalsIgnoreCase("Y")){
								errorCode = "AP187";
								String status = EEMConstants.APPL_STATUS_READYAPPR;
								objError = getErrorVO(field, objVO, errorCode, status);
								objError.setValue(objVO.getPcpOfficeCd());
								if(objError != null){
									lstPcpErrors.add(objError);
								}
							}
						}
						
						
						}
					} catch (Exception e) {
						logger.error(LoggerConstants.exceptionMessage(e.toString()));
						logger.debug("Provider Dates Check:::::"+e.getMessage());
						objVO.setMessage("Error during Enrolled PCP check");
						throw new ApplicationException(e);
					}
					logger.info(LoggerConstants.methodEndLevel());
				return lstPcpErrors; 
			 }
			/**
			 * @author M C Krishna Chaitanya
			 * @param conn contains Connection	
			 * @param eemDb contains String
			 * @param objVO contains EEMApplicationVO
			 * @param lstFields contains List
			 * @return EEMErrorVO
			 * @throws ApplicationException
			 */
			public EEMErrorVO checkActiveAgent(Connection conn, String eemDb, EEMApplicationVO objVO,
					List lstFields) throws ApplicationException {	
				logger.info(LoggerConstants.methodStartLevel());
			 	EEMErrorVO objError = null;
				EEMFieldErrorVO field = getField("brokerType", lstFields);
				if (field == null) {
					return objError;
				}
				try {
					EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
					boolean error = false;
					String errorCode = "";
					if((!(objVO.getBrokerType() == null) && !(objVO.getBrokerType().equalsIgnoreCase(""))) && 
							(!(objVO.getCommAgencyId() == null) && !(objVO.getCommAgencyId().equalsIgnoreCase("")))){
						boolean activeAgent = eemDao.checkAgent(conn,objVO);
						if(!activeAgent){
							error = true;
							errorCode = "AP224";
						}
					}
					if (error) {
						String status = EEMConstants.APPL_STATUS_READYAPPR;
						objError = getErrorVO(field, objVO, errorCode, status);
						objError.setValue(objVO.getBrokerType());
					}
				} catch (Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug("Error Details: "+e.getMessage());
					logger.debug("Agent Active or Inactive check:::::"+e.getMessage());
					objVO.setMessage("Error during Enrolled Agent check");
					throw new ApplicationException(e);
				}
				logger.info(LoggerConstants.methodEndLevel());
				return objError; 
			}
			/**
			 * @author M C Krishna Chaitanya
			 * @param conn contains Connection	
			 * @param eemDb contains String
			 * @param objVO contains EEMApplicationVO
			 * @param lstFields contains List
			 * @return EEMErrorVO
			 * @throws ApplicationException
			 */
			public List validateAgent(Connection conn, String eemDb, EEMApplicationVO objVO,
					List lstFields) throws ApplicationException {	
				logger.info(LoggerConstants.methodStartLevel());
			 	EEMErrorVO objError = null;
			 	List agentErrors = new ArrayList();
				EEMFieldErrorVO field = getField("brokerType", lstFields);
				try {
					EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
					boolean error = false;
					String errorCode = "";
					// Replaced objVO.getBrokAgentId() to avoid null or empty value to avoid DB error logs
					//if((!(objVO.getBrokerType() == null) && !(objVO.getBrokerType().equalsIgnoreCase("")))){
					
					//IFOX-416848 Default Agent ID - Start
					if((!(objVO.getBrokAgentId() == null) && !(objVO.getBrokAgentId().equalsIgnoreCase("")))){
						int checkAgent = eemDao.checkInvalidAgent(conn,objVO);
						//System.out.println(checkAgent);
						if(checkAgent == 0){
							errorCode = "AP221";
							String status = EEMConstants.APPL_STATUS_READYAPPR;
							objError = getErrorVO(field, objVO, errorCode, status);
							objError.setValue(objVO.getBrokerType());
							if(objError != null){
								agentErrors.add(objError);
							}
						}
					}else if(objVO.getBrokAgentId() == null || objVO.getBrokAgentId().equalsIgnoreCase("")){
						
						String agentDefault =   EEMProfileSettings.getCalendarProfileItem(eemDb, 
								objVO.getCustomerId(),EEMProfileSettings.AGTDEFAULT);
						logger.error("agentDefault:"+agentDefault);
						if("Y".equalsIgnoreCase(agentDefault)) {
							errorCode = "AP086";
							String status = EEMConstants.APPL_STATUS_ELGWARNING;
							objError = getErrorVO(field, objVO, errorCode, status);
							objError.setValue(objVO.getBrokerType());
							if(objError != null){
								agentErrors.add(objError);
							}
						}
					}
					
					//IFOX-416848 - Default Agent ID - End
				} catch (Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug("Error Details: "+e.getMessage());
					logger.debug("Agent Active or Inactive check:::::"+e.getMessage());
					objVO.setMessage("Error during Enrolled Agent check");
					throw new ApplicationException(e);
				}
				logger.info(LoggerConstants.methodEndLevel());
				return agentErrors; 
			}
			/**
			 * @author M C Krishna Chaitanya
			 * @param conn contains Connection	
			 * @param eemDb contains String
			 * @param objVO contains EEMApplicationVO
			 * @param lstFields contains List

			 * @return EEMErrorVO
			 * @throws ApplicationException
			 */
			public EEMErrorVO checkInvalidAgency(Connection conn, String eemDb, EEMApplicationVO objVO,
					List lstFields) throws ApplicationException {	
				logger.info(LoggerConstants.methodStartLevel());
			 	EEMErrorVO objError = null;
				EEMFieldErrorVO field = getField("brokerType", lstFields);
				if (field == null) {
					logger.info(LoggerConstants.methodEndLevel());
					return objError;
				}
				try {
					EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
					boolean error = false;
					String errorCode = "";
					if((!(objVO.getCommAgencyId() == null) && !(objVO.getCommAgencyId().equalsIgnoreCase("")))){
						int checkAgency = eemDao.checkInvalidAgency(conn,objVO);
						if(checkAgency == 0){
							error = true;
							errorCode = "AP222";
						}
					}
					if (error) {
						String status = EEMConstants.APPL_STATUS_READYAPPR;
						objError = getErrorVO(field, objVO, errorCode, status);
						objError.setValue(objVO.getCommAgencyId());
					}
				} catch (Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug("Error Details: "+e.getMessage());
					logger.debug("Agent Active or Inactive check:::::"+e.getMessage());
					objVO.setMessage("Error during Enrolled Agent check");
					throw new ApplicationException(e);
				}
				logger.info(LoggerConstants.methodEndLevel());
				return objError; 
			}
			/**
			 * Start --- save comments in Application Entry Tab
			 */	
		/*	public boolean commentsUpdate(Connection conn, EEMApplicationVO objVO) throws ApplicationException, SQLException {
			 	boolean success = false;
			 String message = "";
			 
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			
	        if (!setCommentDetails(eemDao, conn, objVO)) {
				message += "Comments Update failed.\n";
			}
			
			eemDao.getCommentDetails(conn, objVO);
			if (message.equals("")) {
				conn.commit();
			    clearCommentDetailsFlag(objVO);
				success = true;
				
			} else {
				objVO.setMessage(message);
			}
			return success;
			}	*/
			/**
			 * End --- save comments in Application Entry Tab
			 */	
			/**
			 * 
			 * @param eemDao contains EEMApplDao
			 * @param conn contains Connection
			 * @param objVO contains EEMApplicationVO
			 * @return boolean
			 * @throws ApplicationException
			 * @throws SQLException 
			 * @throws IllegalArgumentException 
			 */
			private boolean setCommentDetails(EEMApplDao eemDao, Connection conn,
					EEMApplicationVO objVO) throws ApplicationException, IllegalArgumentException, SQLException {
				logger.info(LoggerConstants.methodStartLevel());
				List lstComments = objVO.getLstComments();
				if (lstComments == null) {
					logger.info(LoggerConstants.methodEndLevel());
					return true;
				}
				
				for (int i = lstComments.size()-1; i >= 0; i--) {
					EEMApplCommentsVO commentVO = (EEMApplCommentsVO)lstComments.get(i);
					if (commentVO.getInsert().equals("Y")) {
						commentVO.setCustomerId(objVO.getCustomerId());
						commentVO.setApplicationId(objVO.getApplId());
						String comment = StringUtil.nonNullTrim(commentVO.getApplComments());
						if (comment.length() > 500) {
							comment = comment.substring(0, 500);
							commentVO.setApplComments(comment);
						}
						eemDao.insertCommentDetails(conn, commentVO,objVO.getUpdateRec());
					}
				}
				logger.info(LoggerConstants.methodEndLevel());
			
				return true;
			}
			/**
			 * Cambia_Election_Logic-Start
			 */
			
			/**
			 * 
			 * @param conn contains Connection
			 * @param objVO contains EEMApplication VO
			 * @return String
			 * @throws ParseException
			 * @throws ApplicationException
			 * @throws SQLException 
			 */
			public String attestationValidate(Connection conn,EEMApplicationVO objVO) throws ParseException, ApplicationException, SQLException{
				logger.info(LoggerConstants.methodStartLevel());
					
					String[] attestSepInd = null;
					String[] attestSepQue = null;
					String errorCode = "";
					int j=0;
					int i=0;
					//I2 bug fix -- start
					if(StringUtil.nonNullTrim(objVO.getEnrollPlanDesgn()).equalsIgnoreCase("MA")){
						if(StringUtil.nonNullTrim(objVO.getPartDEffDt()).equals("")){
							objVO.setPartDEffDt("00000000");
						}
					}
					//I2 bug fix -- end
					List<ElectionResponse> electionResponseList = new ArrayList<ElectionResponse>();
					electionResponseList = validateAttestations(conn,objVO.getApplDate(),objVO.getPartAEffDt(),objVO.getPartBEffDt(),objVO.getPartDEffDt(),
											objVO.getEnrollPlanDesgn(),objVO.getEnrollPbp(),objVO.getAttestDt(),objVO.getSepException(),objVO.getElectionType(),
											objVO.getApplId(),objVO.getMbrHicNbr(),objVO.getCustomerId(),
											objVO.getEnrollGroup(),objVO.getEnrollProduct(),objVO.getReqDtCov());
						
						int listSize = electionResponseList.size();
						if(listSize > 0)
						{
							attestSepInd = new String[listSize];
							attestSepQue = new String[listSize];
							for(int index = 0; index < listSize; index++)
							{
								ElectionResponse responseObj = (ElectionResponse)electionResponseList.get(index);
								if(responseObj.getINDICATOR().equals("invalid")){
									//I2 UAT Fix ---- Start
									EEMApplDao eemApplDao = new EEMApplDao();
									String[] dates = eemApplDao.getAEPDates(conn,objVO.getCustomerId());
									//I2 UAT Fix ---- End
									EEMElection eemElection = new EEMElection();
									errorCode = eemElection.getElectionType(objVO,errorCode,dates);
								}
								if(responseObj.getQUESTIONNUMBER() != null && !responseObj.getQUESTIONNUMBER().equals("") ){
									
									if(responseObj.getINDICATOR().equals("true") && !responseObj.getPRIORITY().equals("true")) {
								
										attestSepInd[index] = "V";
										attestSepQue[index] = responseObj.getQUESTIONNUMBER();
									}else if(responseObj.getREJECTEDBYHISTORY().equals("true")){
								
										attestSepInd[index] = "H";
										attestSepQue[index] = responseObj.getQUESTIONNUMBER();
										i++;
									}else if(responseObj.getINDICATOR().equals("false") && responseObj.getREJECTEDBYHISTORY().equals("false")){
								
										attestSepInd[index] = "I";
										attestSepQue[index] = responseObj.getQUESTIONNUMBER();
										j++;
									}
									if(responseObj.getPRIORITY().equals("true") && responseObj.getINDICATOR().equals("true")){
										
										
										attestSepInd[index] = "P";
										attestSepQue[index] = responseObj.getQUESTIONNUMBER();
										objVO.setElectionType(responseObj.getELECTIONCODE());
										objVO.setElectionDt(responseObj.getEFFDATE());
									}
									if(attestSepQue[index].length() == 1){
										attestSepQue[index] = "0" +attestSepQue[index];
									}
									
								}
							}
							if(objVO.getElectionType() != null && !objVO.getElectionType().equals("")){
								if(objVO.getElectionType().equals("S")){
									objVO.setSepReason("E6");
								}
							}
						
						if(objVO.getEnrollPbp()!= null && !(objVO.getEnrollPbp().equalsIgnoreCase("")) && Integer.parseInt(objVO.getEnrollPbp()) > 799){
							String applDate =objVO.getApplDate();
							String month;
							int year = 0;
							if(!(applDate.equalsIgnoreCase("")||applDate==null)){
								month = applDate.substring(0,2);
								year = Integer.parseInt(applDate.substring(6,10));
								//aepYear = Integer.parseInt(applDate.substring(6,10));
								if(Integer.parseInt(month) == 12){
									month = "01";
									year += 1;
								}
								else{
									month = Integer.toString((Integer.parseInt(month) + 1));
								}
								if(month.length() == 1){
									month = "0" + month;
								}
								applDate = month +"/"+ "01" + "/" + Integer.toString(year);
								}
							
								objVO.setElectionType("W");
								objVO.setElectionDt(applDate);
						}
						
						objVO.setSepInd(attestSepInd);
						objVO.setSepQueNo(attestSepQue);
						if( j == listSize){
		                    errorCode = "AP052";
		                    objVO.setElectionType("");
		                    objVO.setSepReason("");
		                    objVO.setElectionDt("");
		              }
		              if( i == listSize){
		                    objVO.setElectionType("");
		                    objVO.setSepReason("");
		                    objVO.setElectionDt("");
		              }
					}
						logger.info(LoggerConstants.methodEndLevel());
					return errorCode;
				}
			/**
			 * 
			 * @param conn contains Connection
			 * @param applDate contains Application Date
			 * @param partAEffDt contains Part a Effective Date
			 * @param partBEffDt contains Part B effective date
			 * @param partDEffDt
			 * @param planId contains Plan Id
			 * @param pbp contains Pbp
			 * @param attestDates contains Attested dates
			 * @param attestQues contains Attested Ques
			 * @param electionType contains Election Type
			 * @param appl_Id contains Application Id
			 * @param hic_Nbr contains HIC number
			 * @param customer_Id contains Customer ID
			 * @param group_Id contains Group Id
			 * @param product_Id contains Product Id
			 * @return List
			 * @throws ParseException
			 * @throws ApplicationException
			 */
			public List<ElectionResponse> validateAttestations(Connection conn,String applDate, String partAEffDt, String partBEffDt,
					String partDEffDt, String planId, String pbp, String[] attestDates, String[] attestQues,String electionType,
					String appl_Id,String hic_Nbr, String customer_Id,String group_Id,String product_Id,String reqDtCov) throws ParseException, ApplicationException{
				logger.info(LoggerConstants.methodStartLevel());
				
					int length = attestQues.length; 
					String[] queArray = new String[length];
					String[] dateArray = new String[length];
					int Value1;
					if(attestQues != null){
						for(int i = 0; i< length; i++){
							if(attestQues[i] != null && !attestQues[i].equals("")){
								Value1 = Integer.parseInt(attestQues[i].substring(0,2));
								queArray[i] = String.valueOf(Value1);
								dateArray[i] = DateFormatter.reFormat(attestDates[i],DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
							}
						}
					}
		    	applDate = DateFormatter.reFormat(applDate,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
		    	partAEffDt = DateFormatter.reFormat(partAEffDt,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
		    	partBEffDt = DateFormatter.reFormat(partBEffDt,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
		    	partDEffDt = DateFormatter.reFormat(partDEffDt,DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
		    	
		    	reqDtCov = DateFormatter.reFormat(StringUtil.nonNullTrim(reqDtCov),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD);
		  
		    	EEMApplDao eemApplDao = new EEMApplDao();
				if(planId == null || planId.equals("")){
					
					planId = eemApplDao.getPlanDesig(conn,customer_Id,group_Id,product_Id,applDate);     
				}
				ElectionVO electionVO;
				List<ElectionVO> attestationsList= new ArrayList<ElectionVO>();
				List<ElectionResponse> responseList = new ArrayList<ElectionResponse>();
				List<ElectionResponse> modifiedResponseList = new ArrayList<ElectionResponse>();
				for( int i=0; i<attestQues.length;i++){
					electionVO =new ElectionVO();
					electionVO.setELECTIONCODE(electionType);
					electionVO.setPARTAEFFDATE(partAEffDt);
					electionVO.setPARTBEFFDATE(partBEffDt);
					electionVO.setPARTDEFFDATE(partDEffDt);
					electionVO.setPLAN(planId);
					electionVO.setPBP(pbp);
					electionVO.setQUESTIONINSERTDATE(dateArray[i]);
					electionVO.setQUESTIONNUMBER(queArray[i]);
					electionVO.setELECTIONREASON("");
					electionVO.setSUBELECTION("");
					electionVO.setSELECTEDYEAR("");
					electionVO.setMANUALRESERCHDATES("");
					electionVO.setFACILITYSTATUS("");
					electionVO.setRECEIVEDDATE(applDate);
					electionVO.setCustomer_id(customer_Id);
					electionVO.setApplication_id(appl_Id);
					electionVO.setHic_number(hic_Nbr);
					electionVO.setReqDtCov(reqDtCov);
					attestationsList.add(electionVO);
				}
				ValidateElectionServiceHelper electionServiceHelper=new ValidateElectionServiceHelper();
					responseList = electionServiceHelper.validateElections(attestationsList);
					Iterator<ElectionResponse> iter = responseList.iterator();
					 while (iter.hasNext()) {
			        	ElectionResponse electionResponse = (ElectionResponse)iter.next();
			        	electionResponse.setEFFDATE( DateFormatter.reFormat(electionResponse.getEFFDATE(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
			        	modifiedResponseList.add(electionResponse);
					 }
					 logger.info(LoggerConstants.methodEndLevel());
				return modifiedResponseList;
				
			}
			/**
			 * Cambia_Election_Logic-End
			 */
			 
			public List getLstSrchAgencies(Connection conn, EEMApplicationVO objVO) throws ApplicationException {		
				logger.info(LoggerConstants.methodStartLevel());
				List lstAgencies = null;
				try {
					EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
					lstAgencies = eemDao.getLstSrchAgencies(conn, objVO);
					//lstAgencies = eemDao.getLstSrchAgencies(conn, objVO.getCustomerId(), objVO.getCommAgencyId(), objVO.getAgencyName(), objVO.getReqDtCov());					
				} catch (Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug("Error Message::::::"+e.getMessage());
					throw new ApplicationException(e);
				}	
				logger.info(LoggerConstants.methodEndLevel());
				return lstAgencies;
			}
			//IFOX- 415856 : New Agent Lookup CR -start
			public List getLstSrchAgenciesNew(Connection conn, EEMApplicationVO objVO) throws ApplicationException {		
				logger.info(LoggerConstants.methodStartLevel());
				List lstAgencies = null;
				try {
					EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
					lstAgencies = eemDao.getLstSrchAgenciesNew(conn, objVO);
					//lstAgencies = eemDao.getLstSrchAgencies(conn, objVO.getCustomerId(), objVO.getCommAgencyId(), objVO.getAgencyName(), objVO.getReqDtCov());					
				} catch (Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug("Error Message::::::"+e.getMessage());
					throw new ApplicationException(e);
				}	
				logger.info(LoggerConstants.methodEndLevel());
				return lstAgencies;
			}
			//IFOX- 415856 : New Agent Lookup CR -end
			/**
			 * LEP-ApplicationEntrySide-Iteration1_LeftOverScope - Start 1
			 */
			
			/**
			* This method will check whether LEP data is available for the CustomerId & ApplicationId 
			* upon clicking LEP button in Application Entry screen
			* method name - checkLEPDataAvailability
			* @param - conn hold Connection object and customerId holds CustomerId of the Customer
			* @param - appId holds Application Id
			* @return -  checkLEPData of type boolean
			*/
			public boolean chkLEPData(Connection conn,String customerId,int appId){
				logger.info(LoggerConstants.methodStartLevel());
				boolean flag=false;
				EEMApplDao applDao = new EEMApplDao();

				try {
						flag = applDao.checkLEPDataAvailability(conn,customerId,appId);
					
				}catch(Exception e){
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug("Checking chkLEPData APPL Side"+e.getMessage());
				}
				logger.info(LoggerConstants.methodEndLevel());
				return flag;
			}
			/**
			 * LEP-ApplicationEntrySide-Iteration1_LeftOverScope - End 1
			 */
			
			/**
			 * 24_LEP-ApplicationEntrySide - Start 2
			 */
			/**
			* @author santokmr
			* This method will fetch the LEP details wrt Application side
			* upon clicking LEP Details button in Application Entry screen
			* @param conn holds Connection object
			* @param objVO holds Application details
			* @return rslt of type boolean value
			*//*
			public boolean applLESPSelect(Connection conn,EEMApplicationVO objVO){

				boolean rslt = false;
				 EEMApplDao applDao = new EEMApplDao();

				try {
					//Method for retrieving LEP Summary Values
					List lepSummaryInfo = applDao.getapplSummaryInfo(conn,objVO.getMbrHicNbr());
					objVO.setLepInfos(lepSummaryInfo);
					//Method for retrieving LEP Attestation Values
					objVO = applDao.getApplLepAttestInfos(conn, objVO);
					
					//Method for retrieving NUNCMO values
					List lepNunCmoOInitAttests = applDao.getAppLepNunCmo(conn, objVO, "OUTBOUND_INITIAL");
					List lepNunCmoIInitAttests = applDao.getAppLepNunCmo(conn, objVO, "INBOUND_INITIAL");
					List lepNunCmoOIncAttests = null;
					List lepNunCmoIIncAttests = null;
					List lepNunCmoILateAttests = null;
					if(lepNunCmoOInitAttests != null && lepNunCmoOInitAttests.size() >= 3 && 
							((EEMApplicationVO)lepNunCmoOInitAttests.get(lepNunCmoOInitAttests.size()-1)).getStatus().trim().equalsIgnoreCase("INCOMPLETE")){
						lepNunCmoOIncAttests = applDao.getAppLepNunCmo(conn, objVO, "OUTBOUND_INCOMPLETE");
						lepNunCmoIIncAttests = applDao.getAppLepNunCmo(conn, objVO, "INBOUND_INCOMPLETE");
						lepNunCmoILateAttests = applDao.getAppLepNunCmo(conn, objVO, "INBOUND_LATE");
					}
					//set to EEMApplicationVO

					objVO.setOutInitAttests(lepNunCmoOInitAttests);
					objVO.setInInitAttests(lepNunCmoIInitAttests);
					objVO.setOutIncAttests(lepNunCmoOIncAttests);
					objVO.setInIncAttests(lepNunCmoIIncAttests);
					objVO.setInLateAttests(lepNunCmoILateAttests);
				} catch (Exception e) {
					LOGGER.info("Fetching APPL Side LEP Values "+e.getMessage());
				}
				return rslt;
				
			}
			*
//**
			
			 
			 
			 * 24_LEP-ApplicationEntrySide - End 2
			 */ 
			
			
			public boolean applLESPSelect(Connection conn,EEMApplicationVO objVO, String beqCheck){
				logger.info(LoggerConstants.methodStartLevel());
				boolean rslt = false;
				 EEMApplDao applDao = new EEMApplDao();
				 int totalPlepMonths= 0;
				try {
					
					//Method for retrieving LEP Summary Values
						//Modified for SSNRI 2017 : start
					//List lepSummaryInfo = applDao.getapplSummaryInfo(conn,objVO.getMbrHicNbr());
					MBDPersistence mp = new MBDPersistence();
					MBD mbd =  mp.get(conn, objVO.getMbrHicNbr(), beqCheck);
					/*List lepSummaryInfo = applDao.getapplSummaryInfo(conn,objVO.getMbrHicNbr(),objVO.getMbiNbr());*/ 
					//INTERNAL DEFECT - 4 AS PER BCBSAZ Tracker - Start
					if(mbd == null){
						return false;
					}
					//INTERNAL DEFECT - 4 AS PER BCBSAZ Tracker - End					
					List lepSummaryInfo = applDao.getapplSummaryInfo(conn,mbd.getHicNbr(),mbd.getMbi(), beqCheck); 
					//Modified for SSNRI 2017 : end 
				
					objVO.setLepInfos(lepSummaryInfo);
					//Method for retrieving LEP Attestation Values
			
					 objVO = applDao.getApplLepAttestInfos(conn, objVO);
					// objVO.setEmApplLepAttestInfolist(objVO.emApplLepAttestInfolist());
					//Method for retrieving Potn LEP UnCovered Months
					LepPtnlUncovMthsVO  lepPtnlUncovMthsVO= new LepPtnlUncovMthsVO();
					lepPtnlUncovMthsVO.setCustomerId(objVO.getCustomerId());
					lepPtnlUncovMthsVO.setApplicationId(objVO.getApplicationId());
					lepPtnlUncovMthsVO.setShowAllPtnl(objVO.getShowAllPtnl());
					
					List potentialUnCovMthsList= applDao.getPtnlUnCovMnthsApplLep(conn, lepPtnlUncovMthsVO);
					Iterator itr =	potentialUnCovMthsList.iterator();
					while(itr.hasNext()){  
						LepPtnlUncovMthsVO lepVo=(LepPtnlUncovMthsVO)itr.next();
						 if("N".equals(lepVo.getOverRideInd())){
							 totalPlepMonths=lepVo.getPlepMonths()+totalPlepMonths;	 
						 } 
					}
					objVO.setTotalPlepMonths(String.valueOf(totalPlepMonths));
					objVO.setPotentialUnCovMthsList(potentialUnCovMthsList);
					
					//Method for retrieving NUNCMO values
					List lepNunCmoOInitAttests = applDao.getAppLepNunCmo(conn, objVO, "OUTBOUND_INITIAL");
					List lepNunCmoIInitAttests = applDao.getAppLepNunCmo(conn, objVO, "INBOUND_INITIAL");
					List lepNunCmoOIncAttests = null;
					List lepNunCmoIIncAttests = null;
					List lepNunCmoILateAttests = null;
					//commented as per kishore suggested
					/*if(lepNunCmoOInitAttests != null && lepNunCmoOInitAttests.size() >= 3 && 
							((EEMApplicationVO)lepNunCmoOInitAttests.get(lepNunCmoOInitAttests.size()-1)).getStatus().trim().equalsIgnoreCase("INCOMPLETE")){*/
					/*SSNRI Defect  */
						lepNunCmoOIncAttests = applDao.getAppLepNunCmo(conn, objVO, "OUTBOUND_INCOMPLETE");
						lepNunCmoIIncAttests = applDao.getAppLepNunCmo(conn, objVO, "INBOUND_INCOMPLETE");
						lepNunCmoILateAttests = applDao.getAppLepNunCmo(conn, objVO, "INBOUND_LATE");
					/*SSNRI Defect  */
					//set to EEMApplicationVO

					objVO.setOutInitAttests(lepNunCmoOInitAttests);
					objVO.setInInitAttests(lepNunCmoIInitAttests);
					objVO.setOutIncAttests(lepNunCmoOIncAttests);
					objVO.setInIncAttests(lepNunCmoIIncAttests);
					objVO.setInLateAttests(lepNunCmoILateAttests);
					rslt = true;
				} catch (Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug("Fetching APPL Side LEP Values "+e.getMessage());
				}
				logger.info(LoggerConstants.methodEndLevel());
				return rslt;
				
			}


			/** @author Surya
			* UseCaseName 024_Cambia_LEP - Start 3
			*/ 
			
			/**
			* @author santokmr 
			* This method will save the LEP Attestation details wrt Application side
			* upon clicking Update button in LEP Details popup window
			* @param conn holds Connection object
			* @param objVO holds EEMApplicationVO details
			* @return res of type boolean 
			* @throws SQLException when code fails to execute
			*/
		/*	public boolean applLepAttestInfoUpdate(Connection conn, EEMApplicationVO apVO) throws SQLException{
				boolean res = false;

				int sqlCnt=0;
				EEMApplDao applDao = new EEMApplDao();
				try{
				//updating LEP Attestation values into EM_APPL_LEP
				boolean isMA = applDao.getMAApplication(conn, apVO);
				if(isMA != true){
				sqlCnt = applDao.insertApplLEPAttstDetails(conn,apVO);
				if(apVO.getBrkInCoverage() !=null ||apVO.getCredRXCoverage()!= null||
						apVO.getFromDate() !=null ||apVO.getToDate()!= null){
					//updating LEP Attestation values into EM_MBR_CCF
					sqlCnt = applDao.insertApplAttestCcfInfo(conn, apVO);
					res=true;
					}
				}
			  }catch(Exception e){
				  LOGGER.info("updating LEP At values @ APPL Side::applLepAttestInfoUpdate "+e.getMessage()); 
			  }
				return res;
			}*/
			
			//ne Lep Merge
			
			public boolean applLepAttestInfoUpdate(Connection conn, EEMApplicationVO apVO) throws SQLException {
				logger.info(LoggerConstants.methodStartLevel());
				boolean res = false;
				int sqlCnt = 0;
				EEMApplDao applDao = new EEMApplDao();
				try {
					/** Validate LEP UPDATE/ADD*/
					if (apVO.getSelectedLepApplAttnSubTab().equalsIgnoreCase(EEMConstants.EEM_APP_TAB_LEP_ATTEST_UPDATE)) {
						EEMApplicationVO oldEEMVO = applDao.getApplLepAttnDetails(conn, apVO);
						/** If Attestation status is COMPLETE*/
						if ("C".equalsIgnoreCase(apVO.getStatusCd())) {
							if (oldEEMVO != null && oldEEMVO.getStatusCd().equalsIgnoreCase("C")) {
								return true;
							}
							if (oldEEMVO != null) {
								/** Override the 'EM_APPL_CCF_RESP' table with override 'Y' **/
								sqlCnt = applDao.overrideApplLepAttnDetails(conn, apVO);
							}
							/** Insert the record in 'EM_APPL_CCF_RESP' table' */
							sqlCnt = applDao.insertApplLepAttnDetails(conn, apVO);

							if (sqlCnt == 1) {
								/** Close all timer related to the current application.**/
								int sqlCnt1 = applDao.closeALLApplTimers(conn, apVO);
								if (sqlCnt1 > 0) {
									logger.debug("All Timer mapped with Application "+apVO.getApplicationId()+" has been closed successfully");
								} else {
									logger.debug("All Timer mapped with Application "+apVO.getApplicationId()+" has been failed to close");
								}
							}

						/** If Attestation status is IN-COMPLETE*/
						} else if ("I".equalsIgnoreCase(apVO.getStatusCd())) {
							/*if (oldEEMVO != null && oldEEMVO.getStatusCd().equalsIgnoreCase("I")) {
								return true;
							}*/
							if(oldEEMVO != null){
								/** Update the 'EM_APPL_CCF_RESP' table with override 'Y' **/
								sqlCnt = applDao.overrideApplLepAttnDetails(conn, apVO);
							}
							/** Insert the record in 'EM_APPL_CCF_RESP' table' */
							sqlCnt = applDao.insertApplLepAttnDetails(conn, apVO);

							if (sqlCnt == 1) {
								res = true;
								/** LE21 timer trigger code */
								int sqlCnt1 = applDao.invokeTriggerUpdate(conn, apVO);
								if (sqlCnt1 > 0) {
									logger.debug("LE21 Timer for 28 Day's created successfully in Application Side");
								} else {
									logger.debug("LE21 Timer for 28 Day's Failed  in Application Side");
								}
							}

						/** If Attestation status is MISSING*/
						} else if ("M".equalsIgnoreCase(apVO.getStatusCd())) {
							if (oldEEMVO != null && oldEEMVO.getStatusCd().equalsIgnoreCase("M")) {
								return true;
							}
							if(oldEEMVO != null){
								/**Update the 'EM_APPL_CCF_RESP' table with override 'Y'*/
								sqlCnt = applDao.overrideApplLepAttnDetails(conn, apVO);
							}
							/** Insert the record in 'EM_APPL_CCF_RESP' table' */
							sqlCnt = applDao.insertApplLepAttnDetails(conn, apVO);

							if (sqlCnt == 1) {
								res = true;
							}
						}
					} else if (apVO.getSelectedLepApplAttnSubTab().equalsIgnoreCase(EEMConstants.EEM_APP_TAB_LEP_ATTEST_ADD)) {
						if ("Y".equalsIgnoreCase(apVO.getBrkInCoverage())) {
							apVO.setCcfUncovMnths(0);
						} else if ("N".equalsIgnoreCase(apVO.getBrkInCoverage())
								|| "P".equalsIgnoreCase(apVO.getBrkInCoverage())) {
							String frmDate = DateFormatter.reFormat(StringUtil.nonNullTrim(apVO.getFromDate()),
									DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
							String toDate = DateFormatter.reFormat(StringUtil.nonNullTrim(apVO.getToDate()),
									DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
							int uncovMonths = DateMath.monthsBetween(frmDate, toDate);
							apVO.setCcfUncovMnths(uncovMonths + 1);
						}
						int sqlCnt1 = applDao.insertAttnDetailsinCCF(conn, apVO);
					} /** Copy the Uncovered Data Section. START */
					else if (apVO.getSelectedLepApplAttnSubTab().equalsIgnoreCase(EEMConstants.EEM_APP_TAB_LEP_ATTEST_COPY)) {
						EEMApplicationVO applVO = new EEMApplicationVO();
						int result = 0, 
								totalPlepMonths = 0,
								plepMonths = 0;
						
						apVO.setApplId(""+apVO.getApplicationId()+"");
						result = applDao.overridePLepApplDetails(conn, apVO,apVO.getUserID());
						logger.debug("Appl: Override the Lep Potential data result : "+result);
						
						ArrayList<EmApplLepAttestInfoVO> emAplLepAttestVOList = applDao.getApplLepAttestDetails(conn, apVO,"N");
						
						for (EmApplLepAttestInfoVO attesVO : emAplLepAttestVOList) {
							applVO = new EEMApplicationVO();
							plepMonths = 0;
							logger.debug("Appl: Inserting PLEP Attes Data : " + apVO.getUserID() + "," + attesVO.getCustomerId() + ","
									+ attesVO.getApplicationId() + ","
									+ StringUtil.nonNullTrim(apVO.getReqDtCov()) + ","
									+ attesVO.getTxtFromDate() + "," + attesVO.getTxtToDate());
							
							applVO.setLastUpdtUserId(apVO.getUserID());
							applVO.setCustomerId(attesVO.getCustomerId());
							applVO.setApplicationId(attesVO.getApplicationId());
							String lepEffDate = DateFormatter.reFormat(StringUtil.nonNullTrim(apVO.getReqDtCov()),
									DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
							applVO.setLepEffDate(lepEffDate);
							applVO.setCreateUserId(apVO.getUserID());
							String frmDate = DateFormatter.reFormat(StringUtil.nonNullTrim(attesVO.getTxtFromDate()),
									DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
							String toDate = DateFormatter.reFormat(StringUtil.nonNullTrim(attesVO.getTxtToDate()),
									DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);
							applVO.setTxtUncovMthStDt(frmDate);
							applVO.setTxtUncovMthEndDt(toDate);
							plepMonths = DateMath.monthsBetween(frmDate, toDate)+1;
							totalPlepMonths = totalPlepMonths + plepMonths;
							applVO.setPlepMonths(plepMonths);
							result = applDao.insertApplPtnlUnCovMnthsDetails(conn, applVO);
							logger.debug("Appl: insertApplPtnlUnCovMnthsDetails data result : "+result);
							if (result <= 0) {
								conn.rollback();
								logger.debug("Appl: Copy Lep Potential data Failed.");
								logger.info(LoggerConstants.methodEndLevel());
								return false;
							}
						}
						conn.commit();
						apVO.setTotalPlepMonths(""+totalPlepMonths+"");
						logger.debug("Appl: Committed the Lep Potential data.");
						logger.info(LoggerConstants.methodEndLevel());
						return true;
					}
					/** Copy the Uncovered Data Section. END */
				} catch (Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug("updating LEP At values @ APPL Side::applLepAttestInfoUpdate " + e.getMessage());
					conn.rollback();
					e.printStackTrace();
				}
				logger.info(LoggerConstants.methodEndLevel());
				return res;
			}
			
			
			/** @author Surya
			* UseCaseName 024_Cambia_LEP - End 3
			*/ 
			
			/** @author Surya
			* UseCaseName 024_Cambia_LEP - Start 4
			*/ 
			
			/**
			*@author santokmr 
			* This method will save the LEP Attestation Call(NUNCMO) details wrt Application side
			* upon clicking Update button of Attestation Calls in LEP Details popup window
			* @param  conn holds Connection object
			* @param  custId holds Customer Id
			* @param  appId holds Application Id of Customer
			* @param  oiAttests,iiAttests,oIncAttests,iIncAttests and ilAttests of List type values 
			* 		  which holds OUTBOUND/INBOUND Attestation Calls relation information
			* @return -  boolean
			* @throws SQLException when code fails to execute 
			*/
			public boolean setApplLepNunCmo(Connection conn, String custId, int appId, List oiAttests, List iiAttests, List oIncAttests, List iIncAttests, List ilAttests,EEMApplicationVO vo) throws SQLException, ParseException{
				logger.info(LoggerConstants.methodStartLevel());
				// System.out.println("NUNCMO Service 1>getApplicationId>"+appId);
				EEMApplDao appDao = new EEMApplDao();
				boolean oiAttestsUpd=false, iiAttestsUpd=false, oIncAttestsUpd=false, iIncAttestsUpd=false, ilAttestsUpd=false;
				boolean oiAttestTimer=false;
				boolean iiAttestTimer=false;
				boolean iIncAttestTimer=false;
				boolean oIncAttestTimer=false;
				boolean olAttestTimer=false;
				
			
				if(oiAttests != null &&  oiAttests.size() > 0){
					//System.out.println("Out BOund Size"+oiAttests.size());
					oiAttestsUpd = appDao.setApplLepNunCmo(conn, custId, appId, oiAttests, "OUTBOUND_INITIAL");
					oiAttestTimer = setApplLepNunCmoTimer(conn, oiAttests,"OUTBOUND_INITIAL", vo);
				}
				
				if(iiAttests != null &&  iiAttests.size() > 0){
					iiAttestsUpd = appDao.setApplLepNunCmo(conn, custId, appId, iiAttests, "INBOUND_INITIAL");
					iiAttestTimer = setApplLepNunCmoTimer(conn, iiAttests,"INBOUND_INITIAL", vo);
				}
				
				/*SSNRI Fixes*/
				if(oIncAttests != null &&  oIncAttests.size() > 0){
					oIncAttestsUpd = appDao.setApplLepNunCmo(conn, custId, appId, oIncAttests, "OUTBOUND_INCOMPLETE");
					oIncAttestTimer = setApplLepNunCmoTimer(conn, oIncAttests,"OUTBOUND_INCOMPLETE", vo);
				}
				if(iIncAttests != null &&  iIncAttests.size() > 0){
					iIncAttestsUpd = appDao.setApplLepNunCmo(conn, custId, appId, iIncAttests, "INBOUND_INCOMPLETE");
					oIncAttestTimer = setApplLepNunCmoTimer(conn, iIncAttests, "INBOUND_INCOMPLETE", vo);
				}
				/*SSNRI Fixes*/
				if(ilAttests != null &&  ilAttests.size() > 0){
					ilAttestsUpd = appDao.setApplLepNunCmo(conn, custId, appId, ilAttests, "INBOUND_LATE");
					oIncAttestTimer = setApplLepNunCmoTimer(conn, ilAttests, "INBOUND_LATE", vo);
				}
				
				if(oiAttestsUpd || iiAttestsUpd || oIncAttestsUpd || iIncAttestsUpd || ilAttestsUpd){
					logger.info(LoggerConstants.methodEndLevel());
					return true;
				}else{
					logger.info(LoggerConstants.methodEndLevel());
					return false;
				}
				
			}//setApplLepNunCmo()	
			

			 
			
			 /** @author Surya
				* UseCaseName 024_Cambia_LEP - END 4
			*/
			
	/**
	 * Extracts LIS Details from DB.
	 * 
	 * @param eemDao
	 * @param conn
	 * @param objVO
	 * @return
	 * @throws ApplicationException
	 */
	private void getLisDetails(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		eemDao.getLisDetails(conn, objVO);
		logger.info(LoggerConstants.methodEndLevel());
	}
			
	/**
	 * LIS Details Insertion
	 * 
	 * @param eemDao
	 * @param conn
	 * @param objVO
	 * @return
	 * @throws ApplicationException
	 */
	private boolean setLisDetails(EEMApplDao eemDao, Connection conn,
			EEMApplicationVO objVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());

		int rslt = 0;
		if (objVO.getUpdateRec().equals("N")) {
			if (!(StringUtil.nonNullTrim(objVO.getLisEffStartDate()).equals(""))) { // If no LIS. No insertion to DB.
				rslt = eemDao.insertLisDetails(conn, objVO);
			} else {
				rslt = 1;
			}
		} else if (objVO.getUpdateRec().equals("Y")) {
			
			//IFOX-409315 - Start
			
			logger.debug("objVO.isLisChanged():"+objVO.isLisChanged());
			
			if (checkLISStatus(conn, objVO) == true || objVO.isLisChanged()) {
				eemDao.updateLisDetails(conn, objVO);
				if (!(StringUtil.nonNullTrim(objVO.getLisEffStartDate()).equals(""))) { // No LIS. No insertion to DB.
					logger.debug("***************************************LIS Effective Date*****************************************:"+objVO.getLisEffStartDate());
					rslt = eemDao.insertLisDetails(conn, objVO);
				} else {
					rslt = 1;
				}
			}// if  //IFOX-409315 - End
			else {
				rslt = 1;
			}// else
		}// else if

		if (rslt == 1) {
			logger.info(LoggerConstants.methodEndLevel());
			return true;
		}
		logger.info(LoggerConstants.methodEndLevel());
		return false;
	}// setLisDetails()

	/**
	 * Cambia LIS -End
	 */
	
	/**@author santokmr
	 * This method will calculate the rounded value of months that is returned(days/30.4).
	 * First it checks the digit after the decimal point
	 * If the digit is >= 5 then it will round the value to plus 1  
     * method name - getRoundedLepMonths
	 * throws SQLException
	 * @param - double months
	 * @return - int rndMths
	 */	
	 public static int getRoundedLepMonths(double months) {
		 logger.info(LoggerConstants.methodStartLevel());
		//logger.info("getRoundedLepMonths: Start :: months"+months);
		int rndMths = 0;
		String roundedVal="";
		String strMonth = String.valueOf(months);

		int index = strMonth.indexOf('.') ;
		String temp = strMonth.substring(index+1, index+2);
		roundedVal = strMonth.substring(0, index);
		if(Integer.parseInt(temp)>=5){
			roundedVal = String.valueOf(Integer.parseInt(roundedVal)+1);
		}
		//System.out.println("Rounded Val"+Integer.parseInt(roundedVal));
		rndMths = Integer.parseInt(roundedVal);
		//logger.info("getRoundedLepMonths: End :: rndMths"+rndMths);
		logger.info(LoggerConstants.methodEndLevel());
		return rndMths;
	}
	
	 /**
	 * This method will create a fresh application with data populated from mbd
	 * instance and add the newly created application to unassigned worklist
	 * queue.
	 * 
	 * @param conn
	 * @param mbd, data from MBD
	 * @return application/agreement ID as String
	 * @throws ApplicationException 
	 */
	public Map<String, String> createApplAndAddToWorklist(Connection conn, String customerId, String userId,
			MBD mbd, String eemDb, String reqDateOfCover, String applDate,String applCat, String hicMbiFlag) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Map<String, String> dataMap = new HashMap<String, String>();
		EEMWorkFlowDao eemWorkFlowDao = null;
		Integer applId = null;
		Integer agrmntId = null;
		Integer activityId = null;
		try {
			SimpleDateFormat srcFormatter = new SimpleDateFormat("MM/dd/yyyy");
			
			Date reqDate = srcFormatter.parse(reqDateOfCover);
			Date applicationDate = srcFormatter.parse(applDate);
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			// 1. Populate the application object using the data from MBD instance
			EEMApplicationVO eemApplVO = populateApplVOFromMBD(mbd,reqDate,applicationDate,applCat,userId,eemDao,conn,customerId,hicMbiFlag);
			eemApplVO.setCustomerId(customerId);
			//TSA Baseplus Changes - Start
			if(customerId.equalsIgnoreCase("HCF0281")){
				eemApplVO.setLanguage("SPA");				
			}
			else
			{
				eemApplVO.setLanguage("ENG");
			}
			//eemApplVO.setLanguage("ENG");
			//TSA Baseplus Changes - End
			
			// 2. Persist the populated application object
			eemApplVO = saveApplDetails(conn, eemDb, eemApplVO, eemDao);
			applId = eemApplVO.getApplicationId();
			logger.debug("createApplAndAddToWorklist applId: " + applId);
			// 3. In reference to the application instance, populate and insert a record into Agreement table
			if(applId != null && applId > 0) {
				EEMAgreementQueueActivityVO eemAgrmntQActivityVO = populateEEMAgreementQueueActivityVO(eemApplVO, userId);
				eemWorkFlowDao = DaoFactory.getInstance().getEEMWorkFlowDao();
				agrmntId = eemWorkFlowDao.insertAgreementQueueDeatils(conn, eemAgrmntQActivityVO, userId);
				eemAgrmntQActivityVO.setAgreementId(agrmntId);
				logger.debug("createApplAndAddToWorklist agrmntId: " + agrmntId);
				// 4. In reference to the instance of agreement, insert a record into work flow user queue table
				if(agrmntId != null && agrmntId > 0) {
					EEMQueueActivityVO eemQActivityVO = populateEEMQueueActivityVO(eemAgrmntQActivityVO, eemApplVO);
					activityId = eemWorkFlowDao.insertWFUserQueueDeatils(conn, eemQActivityVO, eemAgrmntQActivityVO, eemApplVO);
					logger.debug("createApplAndAddToWorklist activityId: " + activityId);
					if(activityId != null && activityId > 0) {
						// 5. Return the application Id, agreement Id
						dataMap.put("applId", applId.toString());
						dataMap.put("agrmntId", agrmntId.toString());
						logger.info(LoggerConstants.methodEndLevel());
						return dataMap;
					}
				}
			}
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return null;
	}
	
	/**
	 * Utility service to populate eemQActivityVO.
	 * 
	 * @param eemAgrmntQActivityVO
	 * @param eemApplVO
	 * @return eemQActivityVO
	 * @throws ApplicationException 
	 */
	private EEMQueueActivityVO populateEEMQueueActivityVO(EEMAgreementQueueActivityVO eemAgrmntQActivityVO,
			EEMApplicationVO eemApplVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMQueueActivityVO queueActivityVO = new EEMQueueActivityVO();
		try {
			queueActivityVO.setCustomerId(eemApplVO.getCustomerId());
			queueActivityVO.setQueueCode("100");
			queueActivityVO.setAgreementId(eemAgrmntQActivityVO.getAgreementId());
			queueActivityVO.setCurrentUserId("UNASSIGNED");
			queueActivityVO.setApplicationId(eemApplVO.getApplicationId());
			queueActivityVO.setMemberId(fill(null, FILLER_SPACE, 15, 1));
			queueActivityVO.setGroupId(fill(null, FILLER_SPACE, 10, 1));
			queueActivityVO.setHicNumber(eemApplVO.getMbrHicNbr());
			queueActivityVO.setOrggwCreatedTime("0001-01-01-00.00.00.000000");
			queueActivityVO.setDateComplete(fill(null, FILLER_SPACE, 8, 1));
			queueActivityVO.setQueueStatus("OPEN");
			queueActivityVO.setQueueSubStatus("OPEN");
			queueActivityVO.setCurrentQueueReg("A");
			queueActivityVO.setRiskIndicator("N");
			queueActivityVO.setReassignCentralDate("00010101");
			queueActivityVO.setLastCentralQueueDate("00010101");
			queueActivityVO.setInitialUserId("UNASSIGN");
			queueActivityVO.setUserRegTypeCode(fill(null, FILLER_SPACE, 4, 1));
			
			String memberFirstName = eemApplVO.getMbrFirstName() != null ? eemApplVO.getMbrFirstName() : "";
			String memberLastName = eemApplVO.getMbrLastName() != null ? eemApplVO.getMbrLastName() : "";
			
			queueActivityVO.setMemberName(memberLastName + " " + memberFirstName);
			queueActivityVO.setQueueCompletedTime("0001-01-01-00.00.00.000000");
			queueActivityVO.setQueueCompletedUser(fill(null, FILLER_SPACE, 10, 1));
			queueActivityVO.setUserReassigntime("0001-01-01-00.00.00.000000");
			queueActivityVO.setSource("ONLINE");
			queueActivityVO.setOrgActPerQueue(0);
			queueActivityVO.setRemActPerQueue(0);
			queueActivityVO.setOverideInd("N");
			queueActivityVO.setLastUpdatedUser(eemAgrmntQActivityVO.getLastUpdatedUser());
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return queueActivityVO;
	}

	/**
	 * Utility service to populate application data from MBD.
	 * 
	 * @param mbd, data from MBD
	 * @return applicationVO
	 * @throws ApplicationException 
	 */
	private EEMApplicationVO populateApplVOFromMBD(MBD mbd, Date reqDate,Date applicationDate,String applCat,String userId,EEMDao eemDao,
			Connection conn,String customerId, String hicMbiFlag)throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		
		SimpleDateFormat resFormatter = new SimpleDateFormat("yyyyMMdd");
		EEMApplicationVO objVO=new EEMApplicationVO();
		objVO.setReqDtCov(resFormatter.format(reqDate));
		objVO.setApplDate(resFormatter.format(applicationDate));
		objVO.setApplCategory(applCat);
		  // BEQ Short term solution --Start
		if (!StringUtil.nonNullTrim(mbd.getFirstName()).equals(""))
			objVO.setMbrFirstName(mbd.getFirstName());
		//shellapplication-start
		if(hicMbiFlag.equalsIgnoreCase("mbi")){
			objVO.setMbrHicNbr(mbd.getMbi());
		}
		else{
			objVO.setMbrHicNbr(mbd.getHicNbr());
		}
		//shellapplication-start
		/*if (!StringUtil.nonNullTrim(mbd.getHicNbr()).equals(""))
			objVO.setMbrHicNbr(mbd.getHicNbr());*/
		if (!StringUtil.nonNullTrim(mbd.getLastName()).equals(""))
			objVO.setMbrLastName(mbd.getLastName());
		if (!StringUtil.nonNullTrim(mbd.getMiddleInit()).equals(""))
			objVO.setMbrMiddleName(mbd.getMiddleInit());	
			
		if (!(StringUtil.nonNullTrim(mbd.getBirthDate()).equals("")) && (mbd.getBirthDate()).length()== 8){                               		
			objVO.setMbrBirthDt(DateFormatter.reFormat(mbd.getBirthDate(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
		}	
		
		else if (!(StringUtil.nonNullTrim(mbd.getBirthDate()).equals("")) && (mbd.getBirthDate()).length()== 10){
             objVO.setMbrBirthDt(mbd.getBirthDate());

		}
		//SSNRI Tracker defect #99 - Start
		if (!StringUtil.nonNullTrim(mbd.getEsrdInd()).equals(""))
			objVO.setEsrd(mbd.getEsrdInd());
		//SSNRI Tracker defect #99 - End
		
		if (StringUtil.nonNullTrim(objVO.getMbrGender()).equals(""))
			objVO.setMbrGender(getApplGender(mbd.getGenderCd()));
		//Defect fix for Issue #86 :start
		if (!StringUtil.nonNullTrim(mbd.getPrtAEntitleDate()).equals(""))
			objVO.setPartAEffDt(DateFormatter.reFormat(mbd.getPrtAEntitleDate(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
		if (!StringUtil.nonNullTrim(mbd.getPrtBEntitleDate()).equals(""))
			objVO.setPartBEffDt(DateFormatter.reFormat(mbd.getPrtBEntitleDate(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
		if (!StringUtil.nonNullTrim(mbd.getPrtDEligibleDate()).equals(""))
			objVO.setPartDEffDt(DateFormatter.reFormat(mbd.getPrtDEligibleDate(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
		//Defect fix for Issue #86 : end
		objVO.setApplType("NMA");
		if(DaoFactory.getInstance().getEEMApplDao().getMemberDetails(conn, objVO, ""))
		{
			objVO.setMbrId(objVO.getMbrId());
		}
		//objVO.setApplCategory(fill(null,FILLER_SPACE,3,1));
		objVO.setApplCategory(StringUtil.nonNullTrim(applCat));
		objVO.setMbrPrefix(fill(null,FILLER_SPACE,4,1));
		objVO.setMbrSuffix(fill(null,FILLER_SPACE,4,1));
		objVO.setBillLastName(fill(null,FILLER_SPACE,35,1));
		objVO.setBillFirstName(fill(null,FILLER_SPACE,24,1));
		objVO.setBillMiddleName(fill(null,FILLER_SPACE,1,1));
		objVO.setBillSuffix(fill(null,FILLER_SPACE,4,1));
		objVO.setMailFirstName(fill(null,FILLER_SPACE,24,1));
		objVO.setMailLastName(fill(null,FILLER_SPACE,35,1));
		objVO.setMailMiddleName(fill(null,FILLER_SPACE,1,1));
		objVO.setMailSuffix(fill(null,FILLER_SPACE,4,1));
		objVO.setSupplementalId(fill(null,FILLER_SPACE,15,1));
		objVO.setMbrRxId(fill(null,FILLER_SPACE,20,1));
		objVO.setMbrEmail(fill(null,FILLER_SPACE,50,1));
		objVO.setMbrEmail(fill(null,FILLER_SPACE,50,1));
		objVO.setPremium(fill(null,FILLER_SPACE,3,1));
		objVO.setSignOnFile(fill(null,FILLER_SPACE,1,1));
		objVO.setSignDt(fill(null,FILLER_SPACE,8,1));
		objVO.setReceiptDate(fill(null,FILLER_SPACE,8,1));
		objVO.setAuthRepLastName(fill(null,FILLER_SPACE,35,1));
		objVO.setAuthRepFirstName(fill(null,FILLER_SPACE,24,1));
		objVO.setAuthRepMidName(fill(null,FILLER_SPACE,1,1));
		objVO.setAuthRepRelation(fill(null,FILLER_SPACE,3,1));
		objVO.setEmergName(fill(null,FILLER_SPACE,50,1));
		objVO.setEmergPhone(fill(null,FILLER_SPACE,25,1));
		objVO.setEmergRelation(fill(null,FILLER_SPACE,3,1));
		objVO.setEmail(fill(null,FILLER_SPACE,50,1));
		objVO.setInsCardName(fill(null,FILLER_SPACE,50,1));
		objVO.setMbrSsn(fill(null,FILLER_SPACE,9,1));
		objVO.setLanguage(fill(null,FILLER_SPACE,3,1));
		//fixed for Issue #342 : start
		//objVO.setEnrollSrceCd(fill(null,FILLER_SPACE,1,1));
		objVO.setEnrollSrceCd("B");
		//Fixed for Issue #342 : end
		objVO.setOutOfArea(fill(null,FILLER_SPACE,1,1));
		objVO.setApplStatus("INCOMPLETE");
	    objVO.setEditOverride(fill(null,FILLER_SPACE,1,1));
	    objVO.setUserID(userId);
	    objVO.setOperId(userId);
	    objVO.setCreateUserId(userId);
	    objVO.setLastUpdtTime(new DateUtil().getDB2DTS());
	    objVO.setCreateTime(new DateUtil().getDB2DTS());
	    objVO.setSubscriberId(fill(null,FILLER_SPACE,10,1));
	    objVO.setDenialReasonCd(fill(null,FILLER_SPACE,5,1));
	    objVO.setAchNameOnAct(fill(null,FILLER_SPACE,60,1));
	    objVO.setAchAbaRoutingNbr(fill(null,FILLER_SPACE,9,1));
	    objVO.setAchbankAcctNbr(fill(null,FILLER_SPACE,17,1));
	    objVO.setAchAccountType(fill(null,FILLER_SPACE,1,1));
	    objVO.setAchBillFrequency(fill(null,FILLER_SPACE,1,1));
	    objVO.setElectionType(fill(null,FILLER_SPACE,1,1));
	    objVO.setElectionDt(fill(null,FILLER_SPACE,8,1));
	    objVO.setSepReason(fill(null,FILLER_SPACE,2,1));
	    objVO.setElcDerivedInd(fill(null,FILLER_SPACE,1,1));
	    objVO.setCurrPlan(fill(null,FILLER_SPACE,5,1));
	    objVO.setCurrPbp(fill(null,FILLER_SPACE,3,1));
	    objVO.setCurrSegment(fill(null,FILLER_SPACE,3,1));
	    objVO.setCurrProduct(fill(null,FILLER_SPACE,4,1));
	    objVO.setCurrGroup(fill(null,FILLER_SPACE,10,1));
	    objVO.setCurrPymtAmt("0.00");
	    objVO.setDtLstChked(new DateUtil().getDB2DTS());
	    objVO.setEnrollPlan(fill(null,FILLER_SPACE,5,1));
	    objVO.setEnrollPbp(fill(null,FILLER_SPACE,3,1));
	    objVO.setEnrollSegment(fill(null,FILLER_SPACE,3,1));
	    objVO.setEnrollProduct(fill(null,FILLER_SPACE,4,1));
	    objVO.setEnrollGroup(fill(null,FILLER_SPACE,10,1));
	    objVO.setEnrollPymtAmt("0.00");
	    
	    //objVO.setNbrUnCMonths((mbd.getUncovMonths()!=null)?Integer.parseInt(mbd.getUncovMonths()):0);
	    try {
	    	objVO.setNbrUnCMonths(Integer.parseInt(StringUtil.nonNullTrim(mbd.getUncovMonths()))); //Values may come as 'N/A' or NA
	    } catch(NumberFormatException nfe) {
	    	logger.error(LoggerConstants.exceptionMessage(nfe.toString()));
	    	objVO.setNbrUnCMonths(0);
	    }
	    
	    objVO.setStatusCd(fill(null,FILLER_SPACE,1,1));
	    objVO.setAppIncAttRcDt(fill(null,FILLER_SPACE,8,1));
	    objVO.setEligOverrideInd(fill(null,FILLER_SPACE,1,1));
	    objVO.setNeedMBDUpdate("Y");
	    objVO.setUpdateRec("N");
		//Cambia Lis -Start
		if (StringUtil.nonNullTrim(objVO.getApplId()).equals("")){// inserts values only at elig..check.
			
				if(  (!(StringUtil.nonNullTrim(mbd.getSubsidyStartDate1()).equals("00000000")))   &&  
                  DateMath.isBetween(DateFormatter.reFormat((objVO.getReqDtCov()),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD), StringUtil.nonNullTrim(mbd.getSubsidyStartDate1()), StringUtil.nonNullTrim(mbd.getSubsidyEndDate1()).equals("00000000") ? "99999999" : StringUtil.nonNullTrim(mbd.getSubsidyEndDate1()))  ){//LIS starte date as Ѱ0000000Ҡ, we assume that is no LIS.

						if (StringUtil.nonNullTrim(objVO.getLisEffStartDate()).equals("")) {
							objVO.setLisEffStartDate(DateFormatter.reFormat(mbd.getSubsidyStartDate1(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
						}
						if (StringUtil.nonNullTrim(objVO.getLisEffEndDate()).equals("")) {
										objVO.setLisEffEndDate(StringUtil.nonNullTrim(mbd.getSubsidyEndDate1()).equals("00000000") ? "99/99/9999" : DateFormatter.reFormat(mbd.getSubsidyEndDate1(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));//LIS End date as Ѱ00000000Ҡ, we assume this as open ended 
								//objVO.setLisEffEndDate(DateFormatter.reFormat(mbd.getSubsidyEndDate1(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
						}
						if (StringUtil.nonNullTrim(objVO.getLiCoPayCd()).equals("")) {
							objVO.setLiCoPayCd(mbd.getCopayLevelId1());
						}
						if (StringUtil.nonNullTrim(objVO.getLisPctCd()).equals("")) {
							objVO.setLisPctCd(mbd.getPartDPremsubsPct1());
						}
				}
				else if(  (!(StringUtil.nonNullTrim(mbd.getSubsidyStartDate2()).equals("00000000")))   &&  
						DateMath.isBetween(DateFormatter.reFormat((objVO.getReqDtCov()),DateFormatter.MM_DD_YYYY,DateFormatter.YYYYMMDD), StringUtil.nonNullTrim(mbd.getSubsidyStartDate2()), StringUtil.nonNullTrim(mbd.getSubsidyEndDate2()).equals("00000000") ? "99999999" : StringUtil.nonNullTrim(mbd.getSubsidyEndDate2()))  ){//LIS starte date as Ѱ0000000Ҡ, we assume that is no LIS.
           

						if (StringUtil.nonNullTrim(objVO.getLisEffStartDate()).equals("")) {
							objVO.setLisEffStartDate(DateFormatter.reFormat(mbd.getSubsidyStartDate2(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));
						}
						if (StringUtil.nonNullTrim(objVO.getLisEffEndDate()).equals("")) {
							objVO.setLisEffEndDate(StringUtil.nonNullTrim(mbd.getSubsidyEndDate2()).equals("00000000") ? "99/99/9999" : DateFormatter.reFormat(mbd.getSubsidyEndDate2(),DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY));//LIS End date as Ѱ00000000Ҡ, we assume this as open ended 
						}
						if (StringUtil.nonNullTrim(objVO.getLiCoPayCd()).equals("")) {
							objVO.setLiCoPayCd(mbd.getCopayLevelId2());
						}
						if (StringUtil.nonNullTrim(objVO.getLisPctCd()).equals("")) {
							objVO.setLisPctCd(mbd.getPartDPremsubsPct2());
						}
				}
				else{
					objVO.setLisEffStartDate("");
					objVO.setLisEffEndDate("");
					objVO.setLiCoPayCd("");
					objVO.setLisPctCd("");
				}
		}
		objVO.setMbd(mbd);
		logger.info(LoggerConstants.methodEndLevel());
		return objVO;
	}
	
	/**
	 * Utility service to populate a new agreement instance for the provided application.
	 * 
	 * @param eemApplVO, application VO
	 * @param dbname, database name to fetch the nextAgrmntID
	 * 
	 * @return eemAgrmntQActivityVO
	 */
	private EEMAgreementQueueActivityVO populateEEMAgreementQueueActivityVO(EEMApplicationVO eemApplVO, String userId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		EEMAgreementQueueActivityVO eemAgrmntQActivityVO = new EEMAgreementQueueActivityVO();
		try {
			eemAgrmntQActivityVO.setCustomerId(eemApplVO.getCustomerId());
			eemAgrmntQActivityVO.setApplicationId(eemApplVO.getApplicationId());
			eemAgrmntQActivityVO.setMemberId(fill(null, FILLER_SPACE, 15, 1));
			eemAgrmntQActivityVO.setAgreementNumber(fill(null, FILLER_SPACE, 10, 1));
			//Added for SSNRI changes -- Start
				if(!StringUtil.nonNullTrim(eemApplVO.getMbiNbr()).equals(""))
				eemAgrmntQActivityVO.setHicNumber(eemApplVO.getMbiNbr());
				else
			//Added for SSNRI changes -- End
			eemAgrmntQActivityVO.setHicNumber(eemApplVO.getMbrHicNbr());
			eemAgrmntQActivityVO.setGroupId(fill(null, FILLER_SPACE, 10, 1));
			
			if(StringUtil.isNullOrEmpty(StringUtil.nonNullTrim(eemApplVO.getApplDate()))) {
				eemAgrmntQActivityVO.setAgreementDate(new DateUtil().getTodaysDate("yyyyMMdd"));
			} else {
				eemAgrmntQActivityVO.setAgreementDate(eemApplVO.getApplDate());
			}
			
			eemAgrmntQActivityVO.setDateComplete(fill(null, FILLER_SPACE, 8, 1));
			eemAgrmntQActivityVO.setAgreementStatus("OPEN");
			eemAgrmntQActivityVO.setRiskIndicator("N");
			
			String memberFirstName = eemApplVO.getMbrFirstName() != null ? eemApplVO.getMbrFirstName() : "";
			String memberLastName = eemApplVO.getMbrLastName() != null ? eemApplVO.getMbrLastName() : "";
			
			eemAgrmntQActivityVO.setName(memberLastName + " " + memberFirstName);
			eemAgrmntQActivityVO.setSource("ONLINE");
			eemAgrmntQActivityVO.setAgreementCompletedUser(fill(null, FILLER_SPACE, 10, 1));
			eemAgrmntQActivityVO.setAgreementCompletedTime(fill(null, FILLER_SPACE, 8, 1));
			eemAgrmntQActivityVO.setOrgQueuePerAgreement(1);
			eemAgrmntQActivityVO.setRemQueuePerAgreement(1);
			eemAgrmntQActivityVO.setOverideInd("N");
			eemAgrmntQActivityVO.setLastUpdatedUser(userId);
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return eemAgrmntQActivityVO;
	}
	
	private EEMApplicationVO saveApplDetails(Connection conn, String eemDb,
			EEMApplicationVO objVO,EEMApplDao eemDao) throws ApplicationException
	{
		logger.info(LoggerConstants.methodStartLevel());
		boolean inTrans = false;
    	boolean origAutoCommit = false;
    	boolean success = false;
		try {
			origAutoCommit = conn.getAutoCommit();
			conn.setAutoCommit(false);
			inTrans = true;
			String message = "";

			String applStatus = StringUtil.nonNullTrim(objVO.getApplStatus());
			// IFOX-00369084 and IFOX-00372138 - Optimized FORCEDAPPR bypass
			String currStatus = StringUtil.nonNullTrim(objVO.getCurrStatus());
			
			// Set Master details
				String applId = eemDao.saveMasterDetails(conn, eemDb, objVO);
				if(applId==null){
				message = "Application Master Update failed.\n";
			}
				else
				{
					logger.debug("Application Id"+applId);
					objVO.setApplicationId((applId!=null)?Integer.parseInt(applId):0);	
				}
			
			// Set Product deatails
			if (!setProductDetails(eemDao, conn, objVO)) {
				message += "Product details Update failed.\n";
			}
			
			// Set Eligibility details
			if (!setEligDetails(eemDao, conn, objVO)) {
				message += "Eligibility details Update failed.\n";
			}
			
			// Set LEP New Calculation
			// Added the if condition for IFOX-00377369 - LEP NUNCMO CR - SUPP ID Check
			
			if (!setLEPUncovMnthCalC(eemDao, conn, objVO)) {
				message += "Application Trigger Update failed.\n";
			}
		/**
			 * Cambia Lis -Start
			 */
			// Set Lisdetails
				if (!setLisDetails(eemDao, conn, objVO)) {
					message += "LIS Information Update failed.\n";
				}
			/**
			 * Cambia Lis -End
			 */
			//SSNRI Tracker defect #99 - Start
			// Set Other Coverage details
				if (!setOtherCovDetails(eemDao, conn, objVO)) {
						message += "Other Coverage Update failed.\n";
				}
			//SSNRI Tracker defect #99 - End
			 //original application start
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception : " + e.getMessage());
			objVO.setMessage("Error during Record Update.");
			throw new ApplicationException(e);
		} finally {
			try {
				conn.commit();
    			if (inTrans)
    				conn.rollback();
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			throw new ApplicationException(e);
    		}
    		try {
    			conn.setAutoCommit(origAutoCommit);
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			throw new ApplicationException(e);
    		}	
		}
		logger.info(LoggerConstants.methodEndLevel());
		return objVO;
	}
	
	/**
	 * Utility method used to fill the field with specific filler up to the
	 * specified length based on the padding provided.
	 * 
	 * @param arg
	 *            field to be filled
	 * @param filler
	 *            filler used to fill
	 * @param length
	 *            field length
	 * @param padding
	 *            padding style, positive number indicates right padding,
	 *            negative number indicates left padding
	 * @return formatted value
	 * 
	 */
	private String fill(String arg, String filler, int length, int padding) {
		logger.info(LoggerConstants.methodStartLevel());
		if(arg == null) {
			arg = "";
		}
		StringBuilder result = new StringBuilder();
		StringBuilder sb = new StringBuilder();
		int gap = length - arg.length();
		for(int i=0; i < gap; i++) {
			sb.append(filler);
		}
		if(padding < 0) {
			result.append(sb);
			result.append(arg);
		} else {
			result.append(arg);			
			result.append(sb);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return result.toString();
	}
	
	private EEMApplEligibilityVO populateApplEligibilityVO(EEMApplicationVO eemApplVO, MBD mbd, String customerId, String currUserId) {
		logger.info(LoggerConstants.methodStartLevel());
		EEMApplEligibilityVO eligibilityVO = new EEMApplEligibilityVO();
		eligibilityVO.setCustomerId(customerId);
		eligibilityVO.setApplicationId(eemApplVO.getApplicationId());
		eligibilityVO.setLastCheckedTime("0001-01-01-00.00.00.000000");
		eligibilityVO.setHicNbr(mbd.getHicNbr());
		eligibilityVO.setLastName(mbd.getLastName());
		eligibilityVO.setFirstName(mbd.getFirstName());
		eligibilityVO.setMiddleInit(mbd.getMiddleInit());
		eligibilityVO.setGenderNumCd(getGenderValueFromCd(mbd.getGenderCd()));
		eligibilityVO.setBirthDate(mbd.getBirthDate());
		eligibilityVO.setLivingStatus(mbd.getLivingStatus());
		eligibilityVO.setDeathDate(mbd.getDeathDate());
		eligibilityVO.setPrtAEntitleDate(mbd.getPrtAEntitleDate());
		eligibilityVO.setPrtBEntitleDate(mbd.getPrtBEntitleDate());
		eligibilityVO.setPrtAEntitleEdate(mbd.getPrtAEntitleEndDate());
		eligibilityVO.setPrtBEntitleEdate(mbd.getPrtBEntitleEndDate());
		eligibilityVO.setPrtDEligSdate(mbd.getPrtDEligibleDate());
		eligibilityVO.setPrtAOption(mbd.getPrtAOption());
		eligibilityVO.setPrtBOption(mbd.getPrtBOption());
		eligibilityVO.setEnrollmentStatus(mbd.getEnrollmentStatus());
		eligibilityVO.setHospiceInd(mbd.getHospiceInd());
		eligibilityVO.setHospiceSdate(mbd.getHospiceStartDate());
		eligibilityVO.setHospiceEdate(mbd.getHospiceEndDate());
		eligibilityVO.setInstitutionalInd(mbd.getInstInd());
		eligibilityVO.setInstSdate(mbd.getInstStartDate());
		eligibilityVO.setInstEdate(mbd.getInstEndDate());
		eligibilityVO.setEsrdInd(mbd.getEsrdInd());
		eligibilityVO.setEsrdSdate(mbd.getEsrdStartDate());
		eligibilityVO.setEsrdEdate(mbd.getEsrdEndDate());
		eligibilityVO.setWrkagedInd(mbd.getWrkagedInd());
		eligibilityVO.setWrkagedSdate(mbd.getWrkagedStartDate());
		eligibilityVO.setWrkagedEdate(mbd.getWrkagedEndDate());
		eligibilityVO.setMedicInd(mbd.getMedicInd());
		eligibilityVO.setMedicSdate(mbd.getMedicStartDate());
		eligibilityVO.setMedicEdate(mbd.getMedicEndDate());
		eligibilityVO.setRaceCd(mbd.getRaceCd());
		eligibilityVO.setCountyCd(mbd.getCountyCd());
		eligibilityVO.setStateCd(mbd.getStateCd());
		eligibilityVO.setCalcUncovMonths(mbd.getUncovMonths());
		eligibilityVO.setEligibilitySource("MBD");
		eligibilityVO.setLastUpdtUserId(currUserId);
		eligibilityVO.setEligOverrideInd(fill(null, FILLER_SPACE, 1, 1));
		logger.info(LoggerConstants.methodEndLevel());
		return eligibilityVO;
	}
	

	
	/**
	 * Internal utility to get gender value out of numeric gender code.
	 * 0 - O
	 * 1 - M
	 * 2 - F
	 * 
	 * @param genderCd
	 * @return genderValue
	 */
	private String getGenderValueFromCd(String genderCd) {
		logger.info(LoggerConstants.methodStartLevel());
		logger.info(LoggerConstants.methodEndLevel());
		if(StringUtil.nonNullTrim(genderCd).equals("1")) {
			return "M";
		} else if(StringUtil.nonNullTrim(genderCd).equals("2")) {
			return "F";
		} else if(StringUtil.nonNullTrim(genderCd).equals("0")) {
			return "O";
		}
		return null;
	}
	
	//new LEP changes -- start
		public boolean applPtnlUnCovMnthsinfoDelete(Connection conn, EEMApplicationVO objVO) {
			logger.info(LoggerConstants.methodStartLevel());
			boolean res = false;

			int sqlCnt = 0;
			EEMApplDao applDao = new EEMApplDao();
			try {
				sqlCnt = applDao.updateApplPtnlUnCovMnthsDetails(conn, objVO);
				if (sqlCnt > 0) {
					LepPtnlUncovMthsVO lepptl = new LepPtnlUncovMthsVO();
					lepptl.setCustomerId(objVO.getCustomerId());
					lepptl.setApplicationId(objVO.getApplicationId());
					lepptl.setShowAllPtnl("N");
					List potentialUnCovMthsList= applDao.getPtnlUnCovMnthsApplLep(conn, lepptl);
					if (potentialUnCovMthsList != null && potentialUnCovMthsList.size() <= 0) {
						applDao.closeOBCTimer(conn, objVO.getCustomerId(), objVO.getApplId());
					}
					res = true;
				}

			} catch (Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("updating LEP At values @ APPL Side::applLepAttestInfoUpdate " + e.getMessage());
			}
			logger.info(LoggerConstants.methodEndLevel());
			return res;
		}
		
		
		public boolean applAttnSelect(Connection conn, EEMApplicationVO objVO) {
			logger.info(LoggerConstants.methodStartLevel());
			boolean rslt = false;
			 EEMApplDao applDao = new EEMApplDao();
			try {
				
				
			objVO.setShowAllPtnl(objVO.getAppAttnShowAll());
			objVO = applDao.getApplLepAttestInfos(conn, objVO);
			
			//Method for retrieving NUNCMO values
			List lepNunCmoOInitAttests = applDao.getAppLepNunCmo(conn, objVO, "OUTBOUND_INITIAL");
			List lepNunCmoIInitAttests = applDao.getAppLepNunCmo(conn, objVO, "INBOUND_INITIAL");
			List lepNunCmoOIncAttests = null;
			List lepNunCmoIIncAttests = null;
			List lepNunCmoILateAttests = null;
			// Commented as per kishore
			/*if(lepNunCmoOInitAttests != null && c && 
					((EEMApplicationVO)lepNunCmoOInitAttests.get(lepNunCmoOInitAttests.size()-1)).getStatus().trim().equalsIgnoreCase("INCOMPLETE")){
				lepNunCmoOIncAttests = applDao.getAppLepNunCmo(conn, objVO, "OUTBOUND_INCOMPLETE");
				lepNunCmoIIncAttests = applDao.getAppLepNunCmo(conn, objVO, "INBOUND_INCOMPLETE");
				lepNunCmoILateAttests = applDao.getAppLepNunCmo(conn, objVO, "INBOUND_LATE");
			}*/
			//set to EEMApplicationVO

			objVO.setOutInitAttests(lepNunCmoOInitAttests);
			objVO.setInInitAttests(lepNunCmoIInitAttests);
			objVO.setOutIncAttests(lepNunCmoOIncAttests);
			objVO.setInIncAttests(lepNunCmoIIncAttests);
			objVO.setInLateAttests(lepNunCmoILateAttests);
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Fetching APPL Side LEP Values "+e.getMessage());
		}
			logger.info(LoggerConstants.methodEndLevel());
		return rslt;
		

		}

		public boolean applAttnInfoDelete(Connection conn, EEMApplicationVO objVO) {
			logger.info(LoggerConstants.methodStartLevel());
			// TODO Auto-generated method stub
			boolean res = false;

			int sqlCnt=0;
			EEMApplDao applDao = new EEMApplDao();
			try{
				sqlCnt = applDao.updateApplAttnInfo(conn,objVO);
			if(sqlCnt>0){
				res=true;
			}
			
		  }catch(Exception e){
			  logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("updating LEP At values @ APPL Side::applLepAttestInfoUpdate "+e.getMessage()); 
		  }
			logger.info(LoggerConstants.methodEndLevel());
			return res;
		}
		/**
		 *  Created for IFOX-390197
		 * @param conn
		 * @param userId
		 * @param custId
		 * @param membId
		 * @param attests
		 * @param type
		 * @param applVO
		 * @return
		 * @throws SQLException
		 * @throws ParseException
		 */
		public boolean setApplLepNunCmoTimer(Connection conn, List attests,
				String type, EEMApplicationVO applVO) throws SQLException, ParseException {
			logger.info(LoggerConstants.methodStartLevel());
			logger.debug("Setting nuncmo timers :Start");
			EEMApplDao applDao = new EEMApplDao();
			
			EEMApplicationVO nunCmovo = (EEMApplicationVO) attests.get(attests.size() - 1);
			if (nunCmovo.getChange().equalsIgnoreCase("NEW")) {

				if (!(type.equalsIgnoreCase("INBOUND_INCOMPLETE") || type.equalsIgnoreCase("OUTBOUND_INCOMPLETE")
						|| type.equalsIgnoreCase("INBOUND_LATE"))) {
					if (nunCmovo.getStatus().equalsIgnoreCase("INCOMPLETE")) {
						applVO.setCreateUserId(nunCmovo.getUserID());
						applVO.setLastUpdtUserId(nunCmovo.getUserID()); 
						int sqlcnt1 = applDao.invokeTriggerUpdate(conn, applVO);

						logger.debug("Inserting timers and Updating attestation info from attest calls update for Incomplete"
								+ sqlcnt1);
						if (sqlcnt1 != 1) {
							return false;
						}
					}
				}
			}
			logger.info(LoggerConstants.methodEndLevel());
			logger.debug("Setting nuncmo timers :Start");
			return true;
		}

		public boolean applPtnlUnCovMnthsinfoUpdate(Connection conn, EEMApplicationVO apVO) throws ParseException {
			logger.info(LoggerConstants.methodStartLevel());
			String uncovMthStDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(apVO.getTxtUncovMthStDt()));
			String uncovMthEndDt = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(apVO.getTxtUncovMthEndDt()));

			EEMApplDao applDao = new EEMApplDao();

			String reqDtCov = DateUtil.changedDateFormatForMonth(StringUtil.nonNullTrim(apVO.getReqDtCov()));
			apVO.setLepEffDate(reqDtCov);
			boolean res = false;

			int sqlCnt = 0;
			apVO.setTxtUncovMthStDt(uncovMthStDt);
			apVO.setTxtUncovMthEndDt(uncovMthEndDt);
			int ptnUnMnths = DateMath.monthsBetween(uncovMthStDt, uncovMthEndDt);
			apVO.setPlepMonths(ptnUnMnths + 1);
			try {
				// insert ptnl LEP UnCovered months values into EM_APPL_LEP
				sqlCnt = applDao.insertApplPtnlUnCovMnthsDetails(conn, apVO);
				if (sqlCnt > 0) {
					createOBC1Timer(conn,apVO);
					res = true;
				}

			} catch (Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("updating LEP At values @ APPL Side::applLepAttestInfoUpdate " + e.getMessage());
			}
			// return res;
			logger.info(LoggerConstants.methodEndLevel());
			return res;
		}
		public boolean createOBC1Timer(Connection conn,EEMApplicationVO objVO) throws ApplicationException {
			logger.info(LoggerConstants.methodStartLevel());
			/**
			 * Derive OBC1 Timer Interval Days From EM_PROFILE table and add the
			 * Interval to the Current Date START
			 */
			EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
			int rslt1 = 0;
			String noOfDays = eemDao.getInterval(conn, objVO.getCustomerId());
			String OBC1Days = noOfDays.substring(0, 2);
			int val = Integer.parseInt(OBC1Days);
			logger.debug("OBC1Days:" + val);

			Calendar calendar = new GregorianCalendar();
			calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + val);

			String strMonth = String.valueOf(calendar.get(Calendar.MONTH) + 1);
			if (strMonth.length() == 1)
				strMonth = "0" + strMonth;

			String strDate = String.valueOf(calendar.get(Calendar.DATE));
			if (strDate.length() == 1)
				strDate = "0" + strDate;
			objVO.setApplId(""+objVO.getApplicationId()+"");
			/** Trigger OBC1 */
			if (!isDenied(objVO)) {
				rslt1 = eemDao.openLEPApplTrigger(conn, objVO.getCustomerId(), objVO.getApplId(), objVO.getOperId(),
						calendar.get(Calendar.YEAR) + strMonth + strDate);
				if (rslt1 == 1) {
					logger.info(LoggerConstants.methodEndLevel());
					return true;
				}
			}
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
      //new LEP -END
		
		
	//DupAppl-start
		/**
		 * 
		 * @param conn
		 * @param objVO
		 * @return
		 * @throws ApplicationException
		 */
		public boolean overrideDuplcateApplication(Connection conn,
				EEMApplicationVO objVO) throws ApplicationException {
			logger.info(LoggerConstants.methodStartLevel());
			EEMErrorVO objError = null;
			boolean error = true;
			try {
				EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
				List lstOrgPlan = eemDao.checkDuplicateApplication(conn, objVO);
				if (lstOrgPlan.size() > 0
						&& checkDuplicate(conn, eemDao, objVO, lstOrgPlan)) {
					if (objVO.getAppDuplicateCheck() != null
							&& objVO.getAppDuplicateCheck().equalsIgnoreCase("Y")) {
						if (eemDao.updateOverrideData(conn, objVO) > 0) {
							return true;
						} else {
							return false;
						}
					}
				}
			} catch (Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				objVO.setMessage("Error during Duplicate Application overider application.");
			}
			logger.info(LoggerConstants.methodEndLevel());
			return error;
		}
		
		//end
		
		public EEMErrorVO checkDupilcateEnrollmentNew(Connection conn,
				EEMApplicationVO objVO, List lstFields) throws ApplicationException {
			logger.info(LoggerConstants.methodStartLevel());
			EEMErrorVO objError = null;
			
			try {
				EEMApplDao eemDao = DaoFactory.getInstance().getEEMApplDao();
				logger.debug("checkDupilcateEnrollmentNew() :");
				
				List lstOrgPlan = eemDao.checkDuplicateEnrollment(conn, objVO);
				boolean error = false;
				String errorCode = "";
				if (lstOrgPlan.size() > 0) {
					String[] orgPlan = (String[]) lstOrgPlan.get(0);
					
					if(null != orgPlan && orgPlan.length > 4) { //Added to avoid ArrayIndexOutOfBoundsException
						String planId = orgPlan[3];
						String pbpId = orgPlan[4];
						//CR-IFOX-00408061. START
						String productId = orgPlan[5];
						String grpId = orgPlan[6];
						String pbpSegmentId = orgPlan[7];
						/*if (planId.equalsIgnoreCase(objVO.getEnrollPlan())
								&& pbpId.equalsIgnoreCase(objVO.getEnrollPbp())) {
							 errorCode = "AP061";
							 error = checkDuplicate(conn, eemDao, objVO, lstOrgPlan);
						}*/
						if (planId.equalsIgnoreCase(objVO.getEnrollPlan())
							&& pbpId.equalsIgnoreCase(objVO.getEnrollPbp())
								&& productId.equalsIgnoreCase(objVO.getEnrollProduct())
									&& grpId.equalsIgnoreCase(objVO.getEnrollGroup())
										&& pbpSegmentId.equalsIgnoreCase(objVO.getEnrollSegment())) {
							errorCode = "AP061";

							error = checkDuplicate(conn, eemDao, objVO,lstOrgPlan);
						}
					//CR-IFOX-00408061. END
					String reqDtCov = DateFormatter.reFormat(objVO.getReqDtCov(),
							DateFormatter.MM_DD_YYYY, DateFormatter.YYYYMMDD);

	/*					String startDate = orgPlan[2];
						if (error && DateMath.isLessThan(reqDtCov, startDate))
							errorCode = "AP193";

						}*/
				}
				}

				if (error) {
					EEMFieldErrorVO field = getField("mbrHicNbr", lstFields);
					objError = getErrorVO(field, objVO, errorCode,
							EEMConstants.APPL_STATUS_DUPLENRL);
				}

			} catch (Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				e.printStackTrace();
				objVO.setMessage("Error during Duplicate Enrollment check.");
			}
			logger.info(LoggerConstants.methodEndLevel());
			return objError;
		}
		//IFOX-00395242 - viewPdf-- start
		public boolean viewApplicationPdfs(Connection conn, EmCorrMbrVO emCorrMbrVO)
				throws ApplicationException, SQLException {
			logger.info(LoggerConstants.methodStartLevel());
			EEMEnrollDao enrlDao = new EEMEnrollDao();
			logger.info(LoggerConstants.methodEndLevel());
			return enrlDao.viewApplicationPdfs(conn, emCorrMbrVO);
		}
	
	/**
	 * @param connection
	 * @param emCorrMbrVO
	 * @return Status
	 * @throws ApplicationException
	 * @throws SQLException
	 */
	public String loadPDF(Connection connection, EmCorrMbrVO emCorrMbrVO) throws ApplicationException, SQLException {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("Loading the scan PDF in database.");
		EEMEnrollDao enrlDao = null;
		/**Load Security Property File.*/
		SecurityProperties serviceDetails = new SecurityProperties("security");
		
		// DEV KEY
		//String salt = "AsMM53cmHvPt~I%#";
		//String key = "(6moz_M8@5PiKiwVEAQIIH!I(a8~g7ac";
		// PROD KEY
		// String salt = "JY0*$i4tp#$!Io8K";
		// String keyStr = "k$7vieZ9X!^^2r9Rz!sIETW~sK6HD_*!";
		byte[] encryptedBytes = null;
		String savedFilePath = "C:\\Temp\\Decrypted.pdf";
		int status =  0;
		String response ="";
		try {
			String strDateTimeStamp = new DateUtil().getDB2DTS();
			if (null != emCorrMbrVO && !emCorrMbrVO.getPrimaryId().isEmpty()) {
				RESTClient clientObj = new RESTClient(serviceDetails.getServiceURL());
				/** Uncomment the below code for Local Testing START*/
				//encryptedBytes = loadFileInByte("response.txt");
				//clientObj.setResponseMsg("PDF NOT FOUND for Application ID");
				/** Uncomment the below code for Local Testing END*/
				encryptedBytes = clientObj.downloadScanPDFtoDatabase(emCorrMbrVO.getPrimaryId().trim());
				
				if (null != encryptedBytes) {
					byte[] dycriptedBytes = CipherUtil.decryptByteToByte(encryptedBytes,
							serviceDetails.getKey().getBytes(CipherUtil.ENCODING), serviceDetails.getSalt().getBytes(CipherUtil.ENCODING),
							CipherUtil.AES_ALGORITHM);
					enrlDao = new EEMEnrollDao();
					
					if(saveFileInLocal(dycriptedBytes,savedFilePath)){
						status = enrlDao.uploadLettersToDataBase(savedFilePath, connection, emCorrMbrVO.getCustomerId(), 
								emCorrMbrVO.getPrimaryId(), "PAPERPDF", "WEBCALL", "EM0001", strDateTimeStamp);
						logger.debug("Returning Response "+response);
						if (status == 1)
							response = "SUCCESS";
						else{
							logger.debug("Failed to Upload the PDF doc in database.");
							response = "Failed to Download the PDF Document.";
						}
						return response;
					}
				}else{
					response = clientObj.getResponseMsg();
					logger.debug(response);
					return response;
				}
			}else{
				logger.debug("Application ID is NULL or Empty.");
				response = "Application ID is NULL or Empty.";
				return response;
			}
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception while loading the Scan PDF.");
			response ="FAILED To Download the PDF document.";
			e.printStackTrace();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return response;
	}
	public byte[] loadFileInByte(String fileName) {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("Inside loadFileInByte method.");
		InputStream inputStream = null;
		BufferedInputStream bufferInputStream = null;
		byte[] content = null;
		try {
			inputStream = new FileInputStream("C:\\Advantage_M360\\Utilities\\WebServiceClient\\response.txt");
			bufferInputStream = new BufferedInputStream(inputStream);
			content = new byte[bufferInputStream.available()];
			bufferInputStream.read(content);
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			e.printStackTrace();
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					e.printStackTrace();
				}
			}
			if (bufferInputStream != null) {
				try {
					bufferInputStream.close();
				} catch (Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					e.printStackTrace();
				}
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return content;
	}

	public boolean saveFileInLocal(byte[] byteArray, String filepath) {
		logger.info(LoggerConstants.methodStartLevel());
		boolean status = false;
		OutputStream outputStream = null;
		//BufferedOutputStream bufferedOutputStream = null;
		try {
			outputStream = new FileOutputStream(new File(filepath));
			//bufferedOutputStream = new BufferedOutputStream(outputStream);
			//bufferedOutputStream.write(byteArray);
			outputStream.write(byteArray);
			outputStream.flush();
			//bufferedOutputStream.flush();
			status = true;
		} catch (Exception ex) {
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			ex.printStackTrace();
		} finally {
			/*if (null != bufferedOutputStream)
				try {
					bufferedOutputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}*/
			if (null != outputStream)
				try {
					outputStream.close();
				} catch (IOException e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					e.printStackTrace();
				}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return status;
	}
		//IFOX-00395242 - viewPdf-- end		
	/**CMS 2019 January Release- Requirement-3 : DUAL/LIS SEP � L and U. START**/
	/**
	 * Get the CARA_HISTORY data based on the HIC/MBI NUMBER.
	 * @param conn
	 * @param filterVO
	 * @throws SQLException
	 */
	public CARAHistoryDetails getCaraHistory(Connection conn, EEMApplicationVO filterVO) throws SQLException{
		logger.info(LoggerConstants.methodStartLevel());
		MBD mbd = filterVO.getMbd();
		CARAHistoryDetails caraHistory = null;
		// IFOX-00411323: Cambia MBD Null check fix for application creation & denials - Start
		//if(mbd != null ){
		if(mbd != null && !"".equals(StringUtil.nonNullTrim(mbd.getHicNbr()))){
		// IFOX-00411323: Cambia MBD Null check fix	for application creation & denials - End
			MBDHistoryPersistence mbdHisPersistence = new MBDHistoryPersistence();
			caraHistory = mbdHisPersistence.getCaraHistory(conn,mbd);
			filterVO.setCaraHistoryDetails(caraHistory);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return caraHistory;
	}
	/**CMS 2019 January Release- Requirement-3 : DUAL/LIS SEP � L and U. END**/
	//Begin : CMS 2019 January Release- Requirement-3 : DUAL/LIS SEP � L and U.
	
			private String getApplicationEffectiveDateMinusOne(String effectiveDate) throws Exception
			{
				logger.info(LoggerConstants.methodStartLevel());
				String oneDayBeforeApplicationEffectiveDate = null;
				try {
					String effectiveDateInMMDDYYYYFormat = effectiveDate.replaceAll("/", "");

					int effectiveDateInMMDDYYYYFormatYear = Integer.parseInt(effectiveDateInMMDDYYYYFormat.substring(4, 8));
					int effectiveDateInMMDDYYYYFormatMonth = Integer.parseInt(effectiveDateInMMDDYYYYFormat.substring(0, 2)) - 1;
					int effectiveDateInMMDDYYYYFormatDay = Integer.parseInt(effectiveDateInMMDDYYYYFormat.substring(2, 4));
					
					java.util.Calendar effectiveDateCalender = new java.util.GregorianCalendar(
							effectiveDateInMMDDYYYYFormatYear, effectiveDateInMMDDYYYYFormatMonth, effectiveDateInMMDDYYYYFormatDay);

					java.util.Calendar oneDayMinusOfEffectiveDateCalender = new java.util.GregorianCalendar(effectiveDateCalender.get(java.util.Calendar.YEAR),
							effectiveDateCalender.get(java.util.Calendar.MONTH), effectiveDateCalender.get(java.util.Calendar.DATE) - 1);
				
					int oneDayMinusOfEffectiveDateCalenderMonth = oneDayMinusOfEffectiveDateCalender.get(java.util.Calendar.MONTH);
					oneDayMinusOfEffectiveDateCalenderMonth = oneDayMinusOfEffectiveDateCalenderMonth + 1;
					int oneDayMinusOfEffectiveDateCalenderDate = oneDayMinusOfEffectiveDateCalender.get(java.util.Calendar.DATE);
				
					String oneDayBeforeEffectiveDate = oneDayMinusOfEffectiveDateCalender.get(java.util.Calendar.YEAR) + "" + 
							(oneDayMinusOfEffectiveDateCalenderMonth < 10 ? "0" + oneDayMinusOfEffectiveDateCalenderMonth : "" + oneDayMinusOfEffectiveDateCalenderMonth) + "" +
							(oneDayMinusOfEffectiveDateCalenderDate < 10 ? "0" + oneDayMinusOfEffectiveDateCalenderDate : "" + oneDayMinusOfEffectiveDateCalenderDate);
				
				} catch(Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug(" EEMApplService : getApplicationEffectiveDateMinusOne : Exception : " + e.getMessage());
					throw e;
				}
				logger.info(LoggerConstants.methodEndLevel());
				return oneDayBeforeApplicationEffectiveDate;
			}
			
			private void populateEEMElectionVO(EEMApplicationVO eemApplicationVO, EEMElectionVO eemElectionVO) throws Exception
			{
				logger.info(LoggerConstants.methodStartLevel());
				eemElectionVO.setCustomerId(eemApplicationVO.getCustomerId());
				eemElectionVO.setStrApplicationDate(eemApplicationVO.getApplDate());
				eemElectionVO.setDayBeforeRequestedDateOfCoverage(this.getApplicationEffectiveDateMinusOne(eemApplicationVO.getReqDtCov()));
				//CMS Changes Nov 2019 - IFOX : 00423084 start
				eemElectionVO.setEnrollStatus("EAPRV");
				//CMS Changes Nov 2019 - IFOX : 00423084 end
				logger.debug(" EEMApplService : populateEEMElectionVO : CustomerId : [" + eemElectionVO.getCustomerId() + "], HIC Number [" + eemApplicationVO.getDisplayHic() +
						"MBI [" + eemApplicationVO.getMbiNbr() + "], Application Date [" + eemElectionVO.getStrApplicationDate() + "], DayBeforeRequestedDateOfCoverage [" + 
						eemElectionVO.getDayBeforeRequestedDateOfCoverage() + "], MemberPresentInM360 [" + eemElectionVO.isMemberPresentInM360() + "] ");
				logger.info(LoggerConstants.methodEndLevel());
			}

			//End : CMS 2019 January Release- Requirement-3 : DUAL/LIS SEP � L and U.
			
			private static String checkEligOverrideInd(EEMApplicationVO objVO) {
				logger.info(LoggerConstants.methodStartLevel(null));
				MBD mbd = objVO.getMbd();
				String prtAStDt = DateUtil.changedDateFormatForMonth(StringUtil
						.nonNullTrim(objVO.getPartAEffDt()));
				String prtAEndDt = DateUtil.changedDateFormatForMonth(StringUtil
						.nonNullTrim(mbd.getPrtAEntitleEndDate()));
				String prtBStDt = DateUtil.changedDateFormatForMonth(StringUtil
						.nonNullTrim(objVO.getPartBEffDt()));
				String prtBEndDt = DateUtil.changedDateFormatForMonth(StringUtil
						.nonNullTrim(mbd.getPrtBEntitleEndDate()));

				String prtAMbd = DateUtil.changedDateFormatForMonth(StringUtil
						.nonNullTrim(mbd.getPrtAEntitleDate()));
				String prtBMbd = DateUtil.changedDateFormatForMonth(StringUtil
						.nonNullTrim(mbd.getPrtBEntitleDate()));
				String prtDMbd = DateUtil.changedDateFormatForMonth(StringUtil
						.nonNullTrim(mbd.getPrtDEligibleDate()));
				String prtDDate = DateUtil.changedDateFormatForMonth(StringUtil
						.nonNullTrim(objVO.getPartDEffDt()));

				// MMO Fix for Edit Override Ind for : Start
			/*	if ((StringUtil.nonNullTrim(prtAStDt).equalsIgnoreCase(StringUtil.nonNullTrim(prtAMbd)) && !StringUtil.nonNullTrim(prtAStDt).equals(""))
						& (StringUtil.nonNullTrim(prtBStDt).equalsIgnoreCase(StringUtil.nonNullTrim(prtBMbd)) && !StringUtil.nonNullTrim(prtBStDt).equals(""))
						& (StringUtil.nonNullTrim(prtDDate).equalsIgnoreCase(StringUtil.nonNullTrim(prtDMbd)) && !StringUtil.nonNullTrim(prtDDate).equals(""))) {*/
				if ((StringUtil.nonNullTrim(prtAStDt).equalsIgnoreCase(StringUtil.nonNullTrim(prtAMbd)))
						& (StringUtil.nonNullTrim(prtBStDt).equalsIgnoreCase(StringUtil.nonNullTrim(prtBMbd)))
						& (StringUtil.nonNullTrim(prtDDate).equalsIgnoreCase(StringUtil.nonNullTrim(prtDMbd)) )) {
					// MMO Fix for Edit Override Ind for : End
					logger.info(LoggerConstants.methodEndLevel("PartA St Date is equal to PartA MBD"));
					return "N";
				} else {
					logger.info(LoggerConstants.methodEndLevel("PartA St Date is not equal to PartA MBD"));
					return "Y";
				}
			}
}//class
