/*
 * $Id: BeneficiaryService.java,v 1.1 2014/06/26 07:43:47 praveen Exp $
 *
 */
package com.ps.mss.businesslogic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.BeneficiaryDao;
import com.ps.mss.dao.DaoFactory;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.helper.ServiceHelper;
import com.ps.mss.model.BeneficiaryDemographicVO;
import com.ps.mss.model.BeneficiaryPymtDetailVO;
import com.ps.mss.model.BeneficiaryPymtDetailVOList;
import com.ps.mss.model.BeneficiaryVO;
import com.ps.mss.model.FilterVO;
import com.ps.mss.model.PaymentSummaryHeaderVO;
import com.ps.mss.model.PymtEffDateDetailVO;
import com.ps.mss.model.ReconciliationListVO;
import com.ps.mss.model.ReconciliationVO;
import com.ps.mss.model.UnappliedPymtAdjVO;
import com.ps.util.StringUtil;

/**
 * This class has business logic apply into beneificary payment Detail page and pop ups.
 * @author deepak garg
 *
 */
public class BeneficiaryService {

	private static Logger logger=(Logger) LoggerFactory.getLogger(BeneficiaryService.class);
	
	private String dbId;
	
	/**
	 * Parameterize constructor of Beneficiary serivce Class.
	 * @param dbId
	 */
	public BeneficiaryService(String dbId){
		this.dbId = dbId;
	}
	
	/**
	 * This function find payment detail for beneficiary.If search type is 'month' then it also find demographic info for beneficiay.
	 * @param filterVO
	 * @param custPlanMap
	 * @param searchType
	 * @param uiContext
	 * @return
	 */
	public BeneficiaryPymtDetailVOList getBeneficiaryPymtDetail(FilterVO filterVO, Map custPlanMap, String searchType, Map adjReasonMap, List uiContext) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		BeneficiaryDao beneficiaryDao = null;
		BeneficiaryPymtDetailVOList beneficiaryPymtDetailVOList = new BeneficiaryPymtDetailVOList();
		
		try {
			DaoFactory factory = DaoFactory.getInstance();
			beneficiaryDao = factory.getBeneficiaryDao(this.dbId);

			if (filterVO != null) 
				beneficiaryDao.setHicNumbersAndMemberID(filterVO, custPlanMap);
			
			//Call for part C payment Detail for beneficiary. 
			Map retMap = getBenePymtDetail(filterVO, custPlanMap, Constants.PARTC, adjReasonMap, uiContext, beneficiaryDao);
			if (retMap != null ) {//set part C payement detail values
				beneficiaryPymtDetailVOList.setPartCBenPymtDetailVOArray((BeneficiaryPymtDetailVO [])retMap.get(Constants.PAYMENT_DETAIL));
				beneficiaryPymtDetailVOList.setPartCHeader((PaymentSummaryHeaderVO)retMap.get(Constants.HEADER));
			}
			
			//Call for part D payment Detail for beneficiary.
			retMap = getBenePymtDetail(filterVO, custPlanMap, Constants.PARTD, adjReasonMap, uiContext, beneficiaryDao);
			if (retMap != null ) {//set part D payement detail values
				beneficiaryPymtDetailVOList.setPartDBenPymtDetailVOArray((BeneficiaryPymtDetailVO [])retMap.get(Constants.PAYMENT_DETAIL));
				beneficiaryPymtDetailVOList.setPartDHeader((PaymentSummaryHeaderVO)retMap.get(Constants.HEADER));
			}
			
			if(beneficiaryPymtDetailVOList != null) {
				//we find demographic info only when search type is equal to month.
			    if(Constants.CONSTANTS_MONTH.equals(searchType)) {
			    	//Demograhic info for part C
			        BeneficiaryDemographicVO beneficiaryDemographicVO = beneficiaryDao.getBeneficiaryDemographicDetail(filterVO,Constants.PARTC);
			        if (beneficiaryDemographicVO == null) // fatch demograhic info for part D only when part C demographic detail is not null.
			            beneficiaryDemographicVO = beneficiaryDao.getBeneficiaryDemographicDetail(filterVO,Constants.PARTD);
			        beneficiaryPymtDetailVOList.setBeneficiaryDemographicVO(beneficiaryDemographicVO == null ? new BeneficiaryDemographicVO() : beneficiaryDemographicVO);
			    } 
			    
			    //find beneficiary detail on effective date.
			    BeneficiaryVO beneficiaryDetail = getBeneDetailOnEffDate(filterVO, beneficiaryDao);
			    
			    if (beneficiaryDetail != null) {
				    beneficiaryDetail.setOtherHics(ServiceHelper.convertHicsToStrings(filterVO.getHicNumber(), filterVO.getHicNumberList()));
			        beneficiaryDetail.setHicNbr(filterVO.getHicNumber());
			    }
			    beneficiaryPymtDetailVOList.setBeneficiaryDetail(beneficiaryDetail);
	
			    //unapplied payment for partC and PartD.
			    Map unappliedPayments = beneficiaryDao.getUnappliedPymtAdj_CandD(filterVO,custPlanMap,adjReasonMap);
			    beneficiaryPymtDetailVOList.setUnappliedPymtAdjVOs((UnappliedPymtAdjVO [])unappliedPayments.get(Constants.PartC_Plan));
			    beneficiaryPymtDetailVOList.setUnappliedPymtPartD((UnappliedPymtAdjVO [])unappliedPayments.get(Constants.PartD_Plan));
			    int[] partCLatestDate = beneficiaryDao.getLatestDate(filterVO,custPlanMap,Constants.PARTC);
			    int[] partDLatestDate = beneficiaryDao.getLatestDate(filterVO,custPlanMap,Constants.PARTD);
			    if(StringUtil.trimToNull(filterVO.getPageHeaderMsg()) == null){
			    	filterVO.setPageHeaderMsg(ServiceHelper.createHeaderTitle(filterVO,partCLatestDate,partDLatestDate,custPlanMap, null));
			    }
			    beneficiaryPymtDetailVOList.setHeaderTitle(filterVO.getPageHeaderMsg());
			}
		} finally {
			if(beneficiaryDao != null)
				beneficiaryDao.closeConnection();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return beneficiaryPymtDetailVOList;
	}
	
	
	/**
	 * @param filterVO
	 * @param custPlanMap
	 * @param partc
	 * @param adjReasonMap
	 * @param uiContext
	 * @param beneficiaryDao
	 * @return
	 * @throws ApplicationException
	 */
	private Map getBenePymtDetail(FilterVO filterVO, Map custPlanMap, String partName, Map adjReasonMap, List uiContext, BeneficiaryDao beneficiaryDao) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Map retMap = beneficiaryDao.getBeneficiaryPymtDetail (filterVO, custPlanMap, partName, adjReasonMap, Constants.EFF_DATE);
		Map benePymtMap = null ;
		BeneficiaryPymtDetailVO [] benePymtDetailVOs = null ;
		BeneficiaryPymtDetailVO benePymtDetailVO = null;
		String pymtEffDate = null;
		if (retMap != null ) {
			benePymtDetailVOs = (BeneficiaryPymtDetailVO [])retMap.get(Constants.PAYMENT_DETAIL);
			if(benePymtDetailVOs != null && uiContext != null) {
				FilterVO tempFilterVO = new FilterVO();
				for( int i = 0 ; i < benePymtDetailVOs.length ; i ++) {
					benePymtDetailVO = (BeneficiaryPymtDetailVO) benePymtDetailVOs[i];
					pymtEffDate = benePymtDetailVO.getEffectiveDate();
					String key = partName + pymtEffDate;
					if(Constants.PARTD.equals(partName))
						key += benePymtDetailVO.getPaymentType();
					
					if(uiContext.contains(key)||uiContext.contains(Constants.CONSTANTS_ALL)){
						tempFilterVO.setPlanName(filterVO.getPlanName());
						tempFilterVO.setHicNumber(filterVO.getHicNumber());	
						tempFilterVO.setStartDate(pymtEffDate);
						tempFilterVO.setEndDate(pymtEffDate);
						tempFilterVO.setPaymentType(benePymtDetailVO.getPaymentType());
						tempFilterVO.setHicNumberList(filterVO.getHicNumberList());
						benePymtMap = beneficiaryDao.getBeneficiaryPymtDetail (tempFilterVO, custPlanMap, partName, adjReasonMap, Constants.APPLY_DATE);
						benePymtDetailVO.setBenePymtDetailVOs((BeneficiaryPymtDetailVO [])benePymtMap.get(Constants.PAYMENT_DETAIL));
					}
				}
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return retMap;
	}
	
	/**
	 * This find payment detail of beneficiary for part C / part D. 
	 * @param filterVO
	 * @param custPlanMap
	 * @param partName
	 * @param adjReasonMap
	 * @return
	 * @throws ApplicationException
	 */
	public BeneficiaryPymtDetailVOList getPymtDetail(FilterVO filterVO, Map custPlanMap, String partName, Map adjReasonMap, List uiContext) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		BeneficiaryDao beneficiaryDao = null;
		BeneficiaryPymtDetailVOList beneficiaryPymtDetailVOList =  new BeneficiaryPymtDetailVOList();
		
		try {
			DaoFactory factory = DaoFactory.getInstance();
			beneficiaryDao = factory.getBeneficiaryDao(this.dbId);
			Map retMap = null ;
			List hicNumbers = null;
			if (filterVO != null) {
				if (filterVO.getHicNumber() != null)
					hicNumbers = beneficiaryDao.getHicNumbersFromMemberID(filterVO.getHicNumber(), custPlanMap); 
				filterVO.setHicNumberList(hicNumbers);
			}
			if(Constants.PARTC.equals(partName)) {
				/*retMap = beneficiaryDao.getBeneficiaryPymtDetail (filterVO, custPlanMap, Constants.PARTC,adjReasonMap,null)*/
				retMap = getBenePymtDetail(filterVO, custPlanMap, Constants.PARTC, adjReasonMap, uiContext, beneficiaryDao);
				if (retMap != null ) {
					beneficiaryPymtDetailVOList.setPartCBenPymtDetailVOArray((BeneficiaryPymtDetailVO [])retMap.get(Constants.PAYMENT_DETAIL));
					beneficiaryPymtDetailVOList.setPartCHeader((PaymentSummaryHeaderVO)retMap.get(Constants.HEADER));
				}
			} else if(Constants.PARTD.equals(partName)) {
				/*retMap = beneficiaryDao.getBeneficiaryPymtDetail (filterVO, custPlanMap, Constants.PARTD,adjReasonMap,null);*/
				retMap = getBenePymtDetail(filterVO, custPlanMap, Constants.PARTD, adjReasonMap, uiContext, beneficiaryDao);
				if (retMap != null ) {
					beneficiaryPymtDetailVOList.setPartDBenPymtDetailVOArray((BeneficiaryPymtDetailVO [])retMap.get(Constants.PAYMENT_DETAIL));
					beneficiaryPymtDetailVOList.setPartDHeader((PaymentSummaryHeaderVO)retMap.get(Constants.HEADER));
				}
			}
			BeneficiaryVO beneficiaryDetail = getBeneDetailOnEffDate(filterVO, beneficiaryDao);
			if(beneficiaryPymtDetailVOList !=null){
			    if (beneficiaryDetail != null) {
			        beneficiaryDetail.setHicNbr(filterVO.getHicNumber());
				    beneficiaryDetail.setOtherHics(ServiceHelper.convertHicsToStrings(filterVO.getHicNumber(), hicNumbers));
			    }
			    beneficiaryPymtDetailVOList.setBeneficiaryDetail(beneficiaryDetail);
			}
			/*int[] partCLatestDate = beneficiaryDao.getLatestDate(filterVO,custPlanMap,Constants.PARTC);
			int[] partDLatestDate = beneficiaryDao.getLatestDate(filterVO,custPlanMap,Constants.PARTD);*/
			beneficiaryPymtDetailVOList.setHeaderTitle(ServiceHelper.createHeaderTitle(filterVO,null,null,custPlanMap, null));
			
		} finally {
			if(beneficiaryDao != null)
				beneficiaryDao.closeConnection();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return beneficiaryPymtDetailVOList;
	}


	/**
	 * Function find beneficiary detail for part C and check wheter it is exist or not.If beneficiary detail
	 * does not exist for part C then it find beneficiary detail for partD.
	 * @param filterVO
	 * @param beneficiaryDao
	 * @throws ApplicationException
	 */
	private BeneficiaryVO getBeneDetailOnEffDate(FilterVO filterVO, BeneficiaryDao beneficiaryDao) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String hicNbr = filterVO.getHicNumber();
		BeneficiaryVO mostRecentbeneDetail = beneficiaryDao.getLatestBeneficiaryDetail(hicNbr,Constants.PARTC,filterVO);
		if(mostRecentbeneDetail != null ) {
			//mostRecentbeneDetail.setHicNbr(hicNbr); // check this
			BeneficiaryVO beneficiaryDetail = beneficiaryDao.getBeneDetailOnEffDate(hicNbr,Constants.PARTC,filterVO);
			mostRecentbeneDetail.setSupplementalId(beneficiaryDetail != null ? beneficiaryDetail.getSupplementalId():"");
			return mostRecentbeneDetail;
		}
		mostRecentbeneDetail = beneficiaryDao.getLatestBeneficiaryDetail(hicNbr,Constants.PARTD,filterVO);
		if(mostRecentbeneDetail != null ) {
			//mostRecentbeneDetail.setHicNbr(hicNbr);
			BeneficiaryVO beneficiaryDetail = beneficiaryDao.getBeneDetailOnEffDate(hicNbr,Constants.PARTD,filterVO);
			mostRecentbeneDetail.setSupplementalId(beneficiaryDetail != null ? beneficiaryDetail.getSupplementalId():"");
			return mostRecentbeneDetail;
		}
		String memberId = filterVO.getMemberId();
		if (memberId != null) {
			mostRecentbeneDetail = beneficiaryDao.getLatestBeneficiaryDetailByMember(memberId,Constants.PARTC,filterVO);
			if(mostRecentbeneDetail != null ) {
				//mostRecentbeneDetail.setHicNbr(hicNbr); // check this
				BeneficiaryVO beneficiaryDetail = beneficiaryDao.getBeneDetailOnEffDate(hicNbr,Constants.PARTC,filterVO);
				mostRecentbeneDetail.setSupplementalId(beneficiaryDetail != null ? beneficiaryDetail.getSupplementalId():"");
				return mostRecentbeneDetail;
			}
			mostRecentbeneDetail = beneficiaryDao.getLatestBeneficiaryDetailByMember(memberId,Constants.PARTD,filterVO);
			if(mostRecentbeneDetail != null ) {
				//mostRecentbeneDetail.setHicNbr(hicNbr);
				BeneficiaryVO beneficiaryDetail = beneficiaryDao.getBeneDetailOnEffDate(hicNbr,Constants.PARTD,filterVO);
				mostRecentbeneDetail.setSupplementalId(beneficiaryDetail != null ? beneficiaryDetail.getSupplementalId():"");
				return mostRecentbeneDetail;
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return null;
	}
	
	/**
	 * Function find payment Detail on effective date.
	 * This detail contains part A & part B payment detail for effective date.
	 * @param filterVO
	 * @param planMap
	 * @param seqNbr
	 * @param pymtType : contains UnApply payment or apply payment
	 * @return
	 * @throws ApplicationException
	 */
	public PymtEffDateDetailVO getBenePymtDetailByParts(FilterVO filterVO, Map planMap, String seqNbr, String pymtType) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		BeneficiaryDao beneficiaryDao = null;
		PymtEffDateDetailVO detailVO = new PymtEffDateDetailVO();
		try {		
		    DaoFactory factory = DaoFactory.getInstance();
		    beneficiaryDao = factory.getBeneficiaryDao(this.dbId);
			List hicNumbers = null;
			if (filterVO != null) {
				//If sequence number exist, ==DO NOT== search by member id.
				if (StringUtil.trimToNull(seqNbr) == null ) {
					hicNumbers = beneficiaryDao.getHicNumbersFromMemberID(filterVO.getHicNumber(), planMap);
					filterVO.setHicNumberList(hicNumbers);
				}
			}
		    BeneficiaryVO beneficiaryDetail = getBeneDetailOnEffDate(filterVO, beneficiaryDao);
		    if (beneficiaryDetail != null) {
		        beneficiaryDetail.setHicNbr(filterVO.getHicNumber());
			    beneficiaryDetail.setOtherHics(ServiceHelper.convertHicsToStrings(filterVO.getHicNumber(), hicNumbers));
		    }
		    detailVO.setBeneficiaryDetail(beneficiaryDetail);
		    detailVO.setHeaderTitle(ServiceHelper.createHeaderTitle(filterVO,null,null,planMap, null));
		    if (Constants.UNAPPLY_PYMT_D.equals(pymtType))
		    	detailVO.setPymtEffDateDetail(beneficiaryDao.getUnappliedPymtDetailPartD (filterVO, planMap, seqNbr, pymtType));
		    else
		    	detailVO.setPymtEffDateDetail(beneficiaryDao.getBenePymtDetailByParts (filterVO, planMap, seqNbr, pymtType));
		} finally {
			if(beneficiaryDao != null)
				beneficiaryDao.closeConnection();				
		}
		logger.info(LoggerConstants.methodEndLevel());
	    return detailVO;
	}
	/**
	 * This method create reconciliation List Vo which contain reconciliation vos for part c & part d and demographilc info. 
	 * @param filterVO
	 * @param custPlanMapp
	 * @return
	 * @throws ApplicationException
	 */
	public ReconciliationListVO getReconcilationList(FilterVO filterVO, Map custPlanMap) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		BeneficiaryDao beneficiaryDao = null;
		ReconciliationListVO reconciliationListVO = null;
		
		try {
			List partCList = null;
			List partDList = null;
			
			String partName = filterVO.getPartName();
			beneficiaryDao = DaoFactory.getInstance().getBeneficiaryDao(this.dbId);
			
			if(!Constants.PARTD.equals(partName)){ //when partName is Part C or Both
				ReconciliationVO [] beneReconciliationVOs = beneficiaryDao.getBeneficiaryReconcialation(filterVO,custPlanMap);
				if(beneReconciliationVOs != null) {
					compareBeneCmsPlanValue(beneReconciliationVOs);
					/*ReconciliationVO [] pymtReconciliationVOs = discrepancyDao.getPaymentReconcialation(filterVO,custPlanMap);
					//Now we are creating an Reconciliation VOs List for Part C and Part D from  these array.
					*/
					partCList = getList(beneReconciliationVOs,null,null);
				}
			} 
			
			if(!Constants.PARTC.equals(partName)){ //when partName is Part D or Both
				ReconciliationVO [] pdBeneReconciliationVOs = beneficiaryDao.getPDBeneficiaryReconcialation(filterVO,custPlanMap);
				if(pdBeneReconciliationVOs != null){
					comparePdBeneCmsPlanValue(pdBeneReconciliationVOs);
					
				ReconciliationVO [] pdRxhccPymtReconciliationVOs = null;
					
				String pbpIdCms = pdBeneReconciliationVOs[0].getCmsValue(); // getting PBP ID used to get des. group
				String pbpIdPlan = pdBeneReconciliationVOs[0].getPlanValue(); // getting PBP ID used to get des. group
					
				if(Constants.NO_DATA.equals(pbpIdCms) || Constants.NO_DATA.equals(pbpIdPlan)){
					pdRxhccPymtReconciliationVOs = new ReconciliationVO[1];
					ReconciliationVO reconciliationVO = new ReconciliationVO();
					pdRxhccPymtReconciliationVOs[0] = reconciliationVO;
					reconciliationVO.setDataFiled("Disease_Group");
					reconciliationVO.setStatus(Constants.MATCH);
					if(Constants.NO_DATA.equals(pbpIdCms)){
						reconciliationVO.setDiseaseGrpCmsValue(Constants.NO_DATA);
						reconciliationVO.setDiseaseGrpPlanValue(Constants.NO_COMPARISON);
					} else {
						reconciliationVO.setDiseaseGrpPlanValue(Constants.NO_DATA);
						reconciliationVO.setDiseaseGrpCmsValue(Constants.NO_COMPARISON);
					}
				}else {
					//ReconciliationVO [] pdPymtReconciliationVOs = discrepancyDao.getPDPaymentReconcialation(filterVO,custPlanMap);
					pdRxhccPymtReconciliationVOs = beneficiaryDao.getPDRxhccReconcialation(filterVO, custPlanMap, pbpIdCms);
				}
				//Now we are creating an Reconciliation VOs List for Part C and Part D from  these array.
				if(pdBeneReconciliationVOs != null )
					partDList = getList(pdBeneReconciliationVOs,null,pdRxhccPymtReconciliationVOs);
				}
			}
			
			reconciliationListVO = new  ReconciliationListVO();
			reconciliationListVO.setPartCReconciliation(partCList);
			reconciliationListVO.setPartDReconciliation(partDList);
			
			//TODO !!!!!!! : WHY is this one just setting the memberId??
			// May have to change getLatestBeneficiaryDetailByMember().
/*			String memberId = beneficiaryDao.getMemberId(filterVO.getHicNumber());
			filterVO.setMemberId(memberId);
*/			
			beneficiaryDao.setHicNumbersAndMemberID(filterVO, custPlanMap);
			
			BeneficiaryVO mostRecentbeneDetail = getBeneDetailOnEffDate(filterVO,beneficiaryDao );
			if(mostRecentbeneDetail != null) {
				mostRecentbeneDetail.setHicNbr(filterVO.getHicNumber());
				reconciliationListVO.setBeneficiaryDetail(mostRecentbeneDetail);
			}
			
			reconciliationListVO.setHeaderTitle(ServiceHelper.createHeaderTitle(filterVO,null,null,custPlanMap,null));
			
		} finally {
			if(beneficiaryDao != null)
				beneficiaryDao.closeConnection();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return reconciliationListVO;
	}


    /**
	 * @param pdBeneReconciliationVOs
	 */
	private void comparePdBeneCmsPlanValue(ReconciliationVO[] pdBeneReconciliationVOs) {
		logger.info(LoggerConstants.methodStartLevel());
		if(pdBeneReconciliationVOs != null) {
			String cmsValue = null;
			String planValue = null;
			for(int i = 0 ; i < pdBeneReconciliationVOs.length ; i++ ) {
				cmsValue = pdBeneReconciliationVOs[i].getCmsValue();
				planValue = pdBeneReconciliationVOs[i].getPlanValue();
				
				if(Constants.NO_DATA.equals(cmsValue) || Constants.NO_DATA.equals(planValue)){
					pdBeneReconciliationVOs[i].setStatus(Constants.NO_DATA);
				} else {
					if (i == 4)// Last Name
						pdBeneReconciliationVOs[i].setStatus(matchName(cmsValue, planValue, 7));
					else if (i == 5)// First Name
						pdBeneReconciliationVOs[i].setStatus(matchName(cmsValue, planValue, 1));
					else if(i == 0 ||i == 1 || i == 7 || i == 8 ||i == 9 || i == 17 || i == 19 || i == 20|| i == 22) 	//Modified for IFOX-00433193
						pdBeneReconciliationVOs[i].setStatus(cmsValue.equals(planValue) ? Constants.MATCH : Constants.NOT_MATCH);
					else if(i == 2 ||i == 3 || i == 10 || i == 12 || i == 13 || i == 14 || i == 16 || i == 18 || i == 21)	//Modified for IFOX-00433193
						pdBeneReconciliationVOs[i].setStatus(matchInd(cmsValue, planValue));
					else if(i == 6)
						pdBeneReconciliationVOs[i].setStatus(matchGenderCd(cmsValue, planValue));
					else if(i == 11)
						pdBeneReconciliationVOs[i].setStatus(matchPremiumWholeType(cmsValue, planValue));
					else if(i == 15)	//Modified for IFOX-00433193
						pdBeneReconciliationVOs[i].setStatus(matchLICSLevel(cmsValue, planValue));
					else if(i == 23)
						pdBeneReconciliationVOs[i].setStatus(matchPrvDisInd(cmsValue, planValue));
					else if(i==24 ||i==25)
						pdBeneReconciliationVOs[i].setStatus(Constants.MATCH);//change for IFOX-00415128
				}
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		
	}
	/**
	 * @param cmsValue
	 * @param planValue
	 * @return
	 */
	private String matchLICSLevel(String cmsValue, String planValue) {
		logger.info(LoggerConstants.methodStartLevel());
		String tempCmsValue = "".equals(cmsValue.trim()) ? "000" : cmsValue.trim();
		String tempPlanValue = "".equals(planValue.trim()) ? "000" : planValue.trim();
		logger.info(LoggerConstants.methodEndLevel());
		return tempCmsValue.equals(tempPlanValue) ? Constants.MATCH : Constants.NOT_MATCH;
	}
	/**
	 * <blank> , "D  " = "DIR".
	 * @param cmsValue
	 * @param planValue
	 * @return
	 */
	private String matchPremiumWholeType(String cmsValue, String planValue) {
		logger.info(LoggerConstants.methodStartLevel());
		String tempCmsValue = cmsValue;
		String tempPlanValue = planValue;
		if("".equals(cmsValue.trim())|| "D".equals(cmsValue.trim()))
			tempCmsValue = "DIR" ;
		
		if("".equals(planValue.trim())  || "D".equals(planValue.trim()))
			tempPlanValue = "DIR" ;
		
		logger.info(LoggerConstants.methodEndLevel());
		return tempCmsValue.equals(tempPlanValue) ? Constants.MATCH : Constants.NOT_MATCH;
	}
	
	/**
	 * @param beneReconciliationVOs
	 */
	private void compareBeneCmsPlanValue(ReconciliationVO[] beneReconciliationVOs) {
		logger.info(LoggerConstants.methodStartLevel());
		if(beneReconciliationVOs != null) {
			String cmsValue = null;
			String planValue = null;
			for(int i = 0 ; i < beneReconciliationVOs.length ; i++ ) {
				cmsValue = beneReconciliationVOs[i].getCmsValue();
				planValue = beneReconciliationVOs[i].getPlanValue();
				
				if(Constants.NO_DATA.equals(cmsValue) || Constants.NO_DATA.equals(planValue)){
					beneReconciliationVOs[i].setStatus(Constants.NO_DATA);
				} else {
					if (i == 0)// Last Name
						beneReconciliationVOs[i].setStatus(matchName(cmsValue, planValue, 7));
					else if (i == 1)// First Name
						beneReconciliationVOs[i].setStatus(matchName(cmsValue, planValue, 1));
					else if (i == 2 || i == 4 ||i == 5 || i == 6 ||i == 8 || i == 22 || i == 24 ||i == 25 || i == 32  ) 	//Modified for IFOX-00433193
						beneReconciliationVOs[i].setStatus(cmsValue.equals(planValue) ? Constants.MATCH : Constants.NOT_MATCH);
					else if(i == 7 || i == 9 ||i == 10 || i == 11 || i == 12 ||i == 13 || i == 14 ||i == 15 ||i == 16 || i == 17 || 
							i == 18 ||i == 19 || i == 21 || i == 27 || i == 28 || i == 29||i == 30 || i == 35|| i == 38 || i == 39) //Modified for IFOX-00433193
						beneReconciliationVOs[i].setStatus(matchInd(cmsValue, planValue));
					else if(i == 3)
						beneReconciliationVOs[i].setStatus(matchGenderCd(cmsValue, planValue));
					else if(i == 23)
						beneReconciliationVOs[i].setStatus(matchPrvDisInd(cmsValue, planValue));
					else if(i == 20)
						beneReconciliationVOs[i].setStatus(matchCategory(cmsValue, planValue));
					else if(i == 26)
						beneReconciliationVOs[i].setStatus(matchRaceCd(cmsValue, planValue));
					else if( i == 31 ) // RA_FACTOR
						beneReconciliationVOs[i].setStatus(matchBinaryZeroRAFactor(cmsValue, planValue));
					else if (i == 37) // MSP Ind.
						beneReconciliationVOs[i].setStatus(matchBinaryZeroMsp(cmsValue, planValue));
					else if(i==33 ||i==34)
						beneReconciliationVOs[i].setStatus(Constants.MATCH);//change for IFOX-00415128
				}
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		
	}
	
	/**
	 * <blank> = "N"
	 * @param cmsValue
	 * @param planValue
	 * @param length
	 * @return
	 */
	private String matchName(String cmsValue, String planValue, int length) {
		logger.info(LoggerConstants.methodStartLevel());
		String tempCmsValue = "".equals(cmsValue.trim()) ? "N" : cmsValue.trim();
		String tempPlanValue = "".equals(planValue.trim()) ? "N" : planValue.trim();
		
		if (tempPlanValue.length() > length) {
			tempPlanValue = tempPlanValue.substring(0, length);
		}
		
		logger.info(LoggerConstants.methodEndLevel());
		return tempCmsValue.equals(tempPlanValue) ? Constants.MATCH : Constants.NOT_MATCH;
	}
	
	/**
	 * <blank> can be binary zeroes, or two <space> chars: they are equivalent, and match each other, and match "N"
	 * @param cmsValue
	 * @param planValue
	 * @return
	 */
	private String matchBinaryZeroRAFactor(String cmsValue, String planValue) {
		logger.info(LoggerConstants.methodStartLevel());
		// checking is 'Any of' or 'Both' field having NO_DATA then return with "Not Match".
		if(Constants.NO_DATA.equals(cmsValue) || Constants.NO_DATA.equals(planValue)){
			return Constants.NOT_MATCH;
		}
		
		String tempCmsValue = cmsValue;
		String tempPlanValue = planValue;
		if("".equals(cmsValue.trim()))	//Modified for IFOX-00433193
			tempCmsValue = "N";
			
		if("".equals(planValue.trim()))	//Modified for IFOX-00433193
			tempPlanValue = "N";
		
		logger.info(LoggerConstants.methodEndLevel());
		return tempCmsValue.equals(tempPlanValue) ? Constants.MATCH : Constants.NOT_MATCH;
	}
	
	/**
	 * <blank> can be binary zeroes, or two <space> chars: they are equivalent, and match each other, and match "N"
	 * @param cmsValue
	 * @param planValue
	 * @return
	 */
	private String matchBinaryZeroMsp(String cmsValue, String planValue) {
		logger.info(LoggerConstants.methodStartLevel());
		// checking is 'Any of' or 'Both' field having NO_DATA then return with "Not Match".
		if(Constants.NO_DATA.equals(cmsValue) || Constants.NO_DATA.equals(planValue)){
			return Constants.NOT_MATCH;
		}
		
		String tempCmsValue = cmsValue;
		String tempPlanValue = planValue;
		if("".equals(cmsValue.trim()) || " ".equals(cmsValue.trim()))
			tempCmsValue = "N";
			
		if("".equals(planValue.trim()) || " ".equals(planValue.trim()))
			tempPlanValue = "N";
		
		logger.info(LoggerConstants.methodEndLevel());
		return tempCmsValue.equals(tempPlanValue) ? Constants.MATCH : Constants.NOT_MATCH;
	}
	
	
	/**
	 * <blank> = "0"
	 * @param cmsValue
	 * @param planValue
	 * @return
	 */
	private String matchRaceCd(String cmsValue, String planValue) {
		logger.info(LoggerConstants.methodStartLevel());
		String tempCmsValue = "".equals(cmsValue.trim()) ?"0" : cmsValue.trim();
		String tempPlanValue = "".equals(planValue.trim()) ?"0" : planValue.trim();
		logger.info(LoggerConstants.methodEndLevel());
		return tempCmsValue.equals(tempPlanValue) ? Constants.MATCH : Constants.NOT_MATCH;	
	}
	/**
	 * <blank> = "00"
	 * @param cmsValue
	 * @param planValue
	 * @return
	 */
	private String matchCategory(String cmsValue, String planValue) {
		logger.info(LoggerConstants.methodStartLevel());
		String tempCmsValue = "".equals(cmsValue.trim()) ?"00" : cmsValue.trim();
		String tempPlanValue = "".equals(planValue.trim()) ?"00" : planValue.trim();
		logger.info(LoggerConstants.methodEndLevel());
		return tempCmsValue.equals(tempPlanValue) ? Constants.MATCH : Constants.NOT_MATCH;	
	}
	
	/**
	 * <blank>, "0" = "N"; "1","3" = "Y"; "2" = "E" 
	 * @param cmsValue
	 * @param planValue
	 * @return
	 */
	private String matchPrvDisInd(String cmsValue, String planValue) {
		logger.info(LoggerConstants.methodStartLevel());
		String tempCmsValue = cmsValue;
		String tempPlanValue = planValue;
		if("".equals(cmsValue.trim())|| "0".equals(cmsValue.trim()))
			tempCmsValue = "N" ;
		else if("1".equals(cmsValue.trim()) || "3".equals(cmsValue.trim()))
			tempCmsValue = "Y";
		else if("2".equals(cmsValue.trim()))
			tempCmsValue = "E";
		
		if("".equals(planValue.trim())  || "0".equals(planValue.trim()))
			tempPlanValue = "N" ;
		else if("1".equals(planValue.trim()) || "3".equals(planValue.trim()))
			tempPlanValue = "Y";
		else if("2".equals(planValue.trim()))
			tempPlanValue = "E";

		logger.info(LoggerConstants.methodEndLevel());
		return tempCmsValue.equals(tempPlanValue) ? Constants.MATCH : Constants.NOT_MATCH;
	}
	/**
	 * "1" = "M"; "2" = "F"
	 * @param cmsValue
	 * @param planValue
	 * @return
	 */
	private String matchGenderCd(String cmsValue, String planValue) {
		logger.info(LoggerConstants.methodStartLevel());
		String tempCmsValue = cmsValue;
		String tempPlanValue = planValue;
		if("1".equals(cmsValue.trim()))
			tempCmsValue = "M" ;
		else if("2".equals(cmsValue.trim()))
			tempCmsValue = "F";
		
		if("1".equals(planValue.trim()))
			tempPlanValue = "M" ;
		else if("2".equals(planValue.trim()))
			tempPlanValue = "F";
		
		logger.info(LoggerConstants.methodEndLevel());
		return tempCmsValue.equals(tempPlanValue) ? Constants.MATCH : Constants.NOT_MATCH;
	}
	/**
	 * <blank> = "N"
	 * @param cmsValue
	 * @param planValue
	 * @return
	 */
	private String matchInd(String cmsValue, String planValue) {
		logger.info(LoggerConstants.methodStartLevel());
		String tempCmsValue = "".equals(cmsValue.trim()) ? "N" : cmsValue.trim();
		String tempPlanValue = "".equals(planValue.trim()) ? "N" : planValue.trim();
		logger.info(LoggerConstants.methodEndLevel());
		return tempCmsValue.equals(tempPlanValue) ? Constants.MATCH : Constants.NOT_MATCH;
	}
	
	/**
     * This method create a common list from these two Objects Arrays argument.
     * @param beneReconciliationVOs : ReconciliationVO[] of Beneficiary/PdBeneficiary table.
     * @param pymtReconciliationVOs : ReconciliationVO[] of Payment/PdPayment table.
     * @param pdRxhccPymtReconciliationVOs
     * @return list
     */
    private List getList(ReconciliationVO[] beneReconciliationVOs, ReconciliationVO[] pymtReconciliationVOs, ReconciliationVO[] pdRxhccPymtReconciliationVOs) {
    	logger.info(LoggerConstants.methodStartLevel());
        List retValue = null;
        if(beneReconciliationVOs != null)
            retValue = new ArrayList(Arrays.asList(beneReconciliationVOs));
	    if(pymtReconciliationVOs != null) {
	        List pymtList = Arrays.asList(pymtReconciliationVOs);
	        if(retValue != null)
	            retValue.addAll(pymtList);
	        else
	            retValue = pymtList;
	    }
	    if(pdRxhccPymtReconciliationVOs != null) {
	        List pxhccList = Arrays.asList(pdRxhccPymtReconciliationVOs);
	        if(retValue != null)
	            retValue.addAll(pxhccList);
	        else
	            retValue = pxhccList;
	    }
	    logger.info(LoggerConstants.methodEndLevel());
        return retValue;
    }
	
    /**
	 * @param filterVO
	 * @param paymentType
	 * @param planMap
	 * @return
	 */
	public BeneficiaryPymtDetailVO [] getPymtDetailOnEffDate(FilterVO filterVO, Map custPlanMap, String partName, Map adjReasonMap, String paymentType) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		BeneficiaryDao beneficiaryDao = null;
		BeneficiaryPymtDetailVO[] beneficiaryPymtDetailVOs = null;
		try {
			DaoFactory factory = DaoFactory.getInstance();
			beneficiaryDao = factory.getBeneficiaryDao(this.dbId);
			filterVO.setPaymentType(paymentType);
			if (filterVO != null) 
				beneficiaryDao.setHicNumbersAndMemberID(filterVO, custPlanMap);
			
			Map retMap = beneficiaryDao.getBeneficiaryPymtDetail(filterVO, custPlanMap, partName, adjReasonMap, Constants.APPLY_DATE);
			if (retMap != null)
				beneficiaryPymtDetailVOs = (BeneficiaryPymtDetailVO[]) retMap.get(Constants.PAYMENT_DETAIL);

		} finally {
			if (beneficiaryDao != null)
				beneficiaryDao.closeConnection();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return beneficiaryPymtDetailVOs;
	}

}
