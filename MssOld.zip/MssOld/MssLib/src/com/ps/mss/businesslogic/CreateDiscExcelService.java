package com.ps.mss.businesslogic;

import java.util.ArrayList;
import java.util.List;
import java.text.DateFormatSymbols;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.model.McaidAnomDiscrpDetailsVO;
import com.ps.mss.dao.model.McaidAnomSummDetailVO;
import com.ps.mss.dao.model.McaidDiscDashboardVO;
import com.ps.mss.dao.model.McaidFileDetailsVO;
import com.ps.mss.helper.McaidReconHelper;
import com.ps.mss.model.McaidReconAnomVO;
import com.ps.util.StringUtil;




/**
 *
 * @author prare
 */
public class CreateDiscExcelService {
	
	private static Logger logger=(Logger) LoggerFactory.getLogger(CreateDiscExcelService.class);

    public HSSFWorkbook createDashboardWorkbook(List dataList) throws Exception {
    	logger.info(LoggerConstants.methodStartLevel());
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet("Discrepancy Dashboard");
        
        
        sheet.setColumnWidth((short)0, (short)4000);
        sheet.setColumnWidth((short)1, (short)9000);
        sheet.setColumnWidth((short)2, (short)2000);
        sheet.setColumnWidth((short)3, (short)9000);
        sheet.setColumnWidth((short)4, (short)5000);
        sheet.setColumnWidth((short)5, (short)5000);

        /**
         * Style for the header cells.
         */
        HSSFCellStyle headerCellStyle = wb.createCellStyle();
        HSSFFont boldFont = wb.createFont();
        boldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        headerCellStyle.setFont(boldFont);

        HSSFRow row = sheet.createRow(0);
        HSSFCell cell = row.createCell((short) 0);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("PBP/Period").toString());
        cell = row.createCell((short) 1);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Total").toString());
        cell = row.createCell((short) 2);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Open").toString());
        cell = row.createCell((short) 3);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("In Progress").toString());
        cell = row.createCell((short) 4);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Force Closed").toString());
        cell = row.createCell((short) 5);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Resolved").toString());
        
        int index = 0;
        for (int pbpIndex = 0; pbpIndex < dataList.size(); pbpIndex++) {
        	
            McaidDiscDashboardVO pbpData = (McaidDiscDashboardVO) dataList.get(pbpIndex);
            index++;
            row = sheet.createRow(index);
            
            cell = row.createCell((short) 0);            
            HSSFRichTextString PBP_ID = new HSSFRichTextString(pbpData.getPbpDesc());
            cell.setCellValue(PBP_ID.toString());
            cell = row.createCell((short) 1);
            HSSFRichTextString count = new HSSFRichTextString(pbpData.getCount());
            cell.setCellValue(count.toString());
            cell = row.createCell((short) 2);
            HSSFRichTextString open = new HSSFRichTextString(pbpData.getOpen());
            cell.setCellValue(open.toString());
            cell = row.createCell((short) 3);
            HSSFRichTextString inProg = new HSSFRichTextString(pbpData.getInProgress());
            cell.setCellValue(inProg.toString());
            cell = row.createCell((short) 4);
            HSSFRichTextString forceClose = new HSSFRichTextString(pbpData.getForceClosed());
            cell.setCellValue(forceClose.toString());
            cell = row.createCell((short) 5);
            HSSFRichTextString resolve = new HSSFRichTextString(pbpData.getResolved());
            cell.setCellValue(resolve.toString());
            
            //year-START
            List yearDataList = pbpData.getPbpYrOrQtrOrMonLst();
            if(yearDataList != null){//yearIf
	            for (int yearIndex = 0; yearIndex < yearDataList.size(); yearIndex++) {
	            	 McaidDiscDashboardVO yearData = (McaidDiscDashboardVO) yearDataList.get(yearIndex);	            	 
	            	 index++;
	                 row = sheet.createRow(index);
	                 
	                 cell = row.createCell((short) 0);            
	                 PBP_ID = new HSSFRichTextString(yearData.getYear());
	                 cell.setCellValue(PBP_ID.toString());
	                 cell = row.createCell((short) 1);
	                 count = new HSSFRichTextString(yearData.getCount());
	                 cell.setCellValue(count.toString());
	                 cell = row.createCell((short) 2);
	                 open = new HSSFRichTextString(yearData.getOpen());
	                 cell.setCellValue(open.toString());
	                 cell = row.createCell((short) 3);
	                 inProg = new HSSFRichTextString(yearData.getInProgress());
	                 cell.setCellValue(inProg.toString());
	                 cell = row.createCell((short) 4);
	                 forceClose = new HSSFRichTextString(yearData.getForceClosed());
	                 cell.setCellValue(forceClose.toString());
	                 cell = row.createCell((short) 5);
	                 resolve = new HSSFRichTextString(yearData.getResolved());
	                 cell.setCellValue(resolve.toString());	            	
	            	
	               //QTR-START
	                 List qtrDataList = yearData.getPbpYrOrQtrOrMonLst();
	                 if(qtrDataList != null){//qtrIf
	     	            for (int qtrIndex = 0; qtrIndex < qtrDataList.size(); qtrIndex++) {
	     	            	 McaidDiscDashboardVO qtrData = (McaidDiscDashboardVO) qtrDataList.get(qtrIndex);	            	 
	     	            	 index++;
	     	                 row = sheet.createRow(index);
	     	                 
	     	                 cell = row.createCell((short) 0);            
	     	                 PBP_ID = new HSSFRichTextString(qtrData.getQuarter());
	     	                 cell.setCellValue(PBP_ID.toString());
	     	                 cell = row.createCell((short) 1);
	     	                 count = new HSSFRichTextString(qtrData.getCount());
	     	                 cell.setCellValue(count.toString());
	     	                 cell = row.createCell((short) 2);
	     	                 open = new HSSFRichTextString(qtrData.getOpen());
	     	                 cell.setCellValue(open.toString());
	     	                 cell = row.createCell((short) 3);
	     	                 inProg = new HSSFRichTextString(qtrData.getInProgress());
	     	                 cell.setCellValue(inProg.toString());
	     	                 cell = row.createCell((short) 4);
	     	                 forceClose = new HSSFRichTextString(qtrData.getForceClosed());
	     	                 cell.setCellValue(forceClose.toString());
	     	                 cell = row.createCell((short) 5);
	     	                 resolve = new HSSFRichTextString(qtrData.getResolved());
	     	                 cell.setCellValue(resolve.toString());
	     	                 
	     	                 
	     	                 
	     	              //MONTH-START
	    	                 List monthDataList = qtrData.getPbpYrOrQtrOrMonLst();
	    	                 if(monthDataList != null){//monthIf
	    	     	            for (int monthIndex = 0; monthIndex < monthDataList.size(); monthIndex++) {
	    	     	            	 McaidDiscDashboardVO monthData = (McaidDiscDashboardVO) monthDataList.get(monthIndex);	            	 
	    	     	            	 index++;
	    	     	                 row = sheet.createRow(index);
	    	     	                 
	    	     	                 cell = row.createCell((short) 0);            
	    	     	                 PBP_ID = new HSSFRichTextString(getMonthName(new Integer(monthData.getMonth()).intValue()));
	    	     	                 cell.setCellValue(PBP_ID.toString());
	    	     	                 cell = row.createCell((short) 1);
	    	     	                 count = new HSSFRichTextString(monthData.getCount());
	    	     	                 cell.setCellValue(count.toString());
	    	     	                 cell = row.createCell((short) 2);
	    	     	                 open = new HSSFRichTextString(monthData.getOpen());
	    	     	                 cell.setCellValue(open.toString());
	    	     	                 cell = row.createCell((short) 3);
	    	     	                 inProg = new HSSFRichTextString(monthData.getInProgress());
	    	     	                 cell.setCellValue(inProg.toString());
	    	     	                 cell = row.createCell((short) 4);
	    	     	                 forceClose = new HSSFRichTextString(monthData.getForceClosed());
	    	     	                 cell.setCellValue(forceClose.toString());
	    	     	                 cell = row.createCell((short) 5);
	    	     	                 resolve = new HSSFRichTextString(monthData.getResolved());
	    	     	                 cell.setCellValue(resolve.toString());
	    	     	            	
	    	     	            	
	    	     	            	
	    	     	            }//monthFor
	    	                 }//monthIf
	    	                 //MONTH-END
	     	                 
	     	            	
	     	            	
	     	            }//qtrFor
	                 }//qtrIf
	                 //QTR-END
	                 
	            	
	            }//yearFor
            }//yearIf
            //year-END
            
            
        }//pbpFor
        logger.info(LoggerConstants.methodEndLevel());
        return wb;
    }
    
    
    public HSSFWorkbook createDashboardSummaryWorkbook(List dataList) throws Exception {
    	logger.info(LoggerConstants.methodStartLevel());
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet("Discrepancy Summary");
        
        
        sheet.setColumnWidth((short)0, (short)4000);
        sheet.setColumnWidth((short)1, (short)9000);
        sheet.setColumnWidth((short)2, (short)2000);
        sheet.setColumnWidth((short)3, (short)9000);
        sheet.setColumnWidth((short)4, (short)5000);
        sheet.setColumnWidth((short)5, (short)5000);

        /**
         * Style for the header cells.
         */
        HSSFCellStyle headerCellStyle = wb.createCellStyle();
        HSSFFont boldFont = wb.createFont();
        boldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        headerCellStyle.setFont(boldFont);

        HSSFRow row = sheet.createRow(0);
        HSSFCell cell = row.createCell((short) 0);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Discrepancy").toString());
        cell = row.createCell((short) 1);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Count").toString());
        cell = row.createCell((short) 2);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("%").toString());
        cell = row.createCell((short) 3);
        cell.setCellStyle(headerCellStyle);
      
        int index = 0;
        for (int discIndex = 0; discIndex < dataList.size(); discIndex++) {
        	
        	McaidAnomDiscrpDetailsVO discData = (McaidAnomDiscrpDetailsVO) dataList.get(discIndex);
            index++;
            row = sheet.createRow(index);
            
            cell = row.createCell((short) 0);            
            HSSFRichTextString PBP_ID = new HSSFRichTextString(discData.getDiscrpCode());
            cell.setCellValue(PBP_ID.toString());
            cell = row.createCell((short) 1);
            HSSFRichTextString count = new HSSFRichTextString(discData.getValue());
            cell.setCellValue(count.toString());
            cell = row.createCell((short) 2);
            HSSFRichTextString open = new HSSFRichTextString(discData.getPercent());
            cell.setCellValue(open.toString());
            cell = row.createCell((short) 3);
          
        }//pbpFor
        logger.info(LoggerConstants.methodEndLevel());
        return wb;
    }
    
  
    public HSSFWorkbook createAnomalySummaryWorkbook(List dataList) throws Exception {
    	logger.info(LoggerConstants.methodStartLevel());
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet("Anomaly Summary");
        
        
        sheet.setColumnWidth((short)0, (short)4000);
        sheet.setColumnWidth((short)1, (short)9000);
        sheet.setColumnWidth((short)2, (short)2000);
        sheet.setColumnWidth((short)3, (short)9000);
        sheet.setColumnWidth((short)4, (short)5000);
        sheet.setColumnWidth((short)5, (short)5000);

        /**
         * Style for the header cells.
         */
        HSSFCellStyle headerCellStyle = wb.createCellStyle();
        HSSFFont boldFont = wb.createFont();
        boldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        headerCellStyle.setFont(boldFont);

        HSSFRow row = sheet.createRow(0);
        HSSFCell cell = row.createCell((short) 0);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Anomaly").toString());
        cell = row.createCell((short) 1);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Count").toString());
        cell = row.createCell((short) 2);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("%").toString());
        cell = row.createCell((short) 3);
        cell.setCellStyle(headerCellStyle);
      
        int index = 0;
        for (int discIndex = 0; discIndex < dataList.size(); discIndex++) {
        	
        	McaidAnomDiscrpDetailsVO discData = (McaidAnomDiscrpDetailsVO) dataList.get(discIndex);
            index++;
            row = sheet.createRow(index);
            
            cell = row.createCell((short) 0);            
            HSSFRichTextString PBP_ID = new HSSFRichTextString(discData.getDiscrpCode());
            cell.setCellValue(PBP_ID.toString());
            cell = row.createCell((short) 1);
            HSSFRichTextString count = new HSSFRichTextString(discData.getValue());
            cell.setCellValue(count.toString());
            cell = row.createCell((short) 2);
            HSSFRichTextString open = new HSSFRichTextString(discData.getPercent());
            cell.setCellValue(open.toString());
            cell = row.createCell((short) 3);
          
        }//pbpFor
        logger.info(LoggerConstants.methodEndLevel());
        return wb;
    }
    
  
    public HSSFWorkbook createSummaryWorkbook(List dataList, McaidReconAnomVO anomVO) throws Exception {
    	logger.info(LoggerConstants.methodStartLevel());
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet("Discrepancy Details");
        String discrpCode = null;
        if (anomVO.getSummSrchDiscrpCd() !=null)
        	discrpCode = anomVO.getSummSrchDiscrpCd();
        else if (anomVO.getDiscrepancyCategory() != null)
        	discrpCode = anomVO.getDiscrepancyCategory();
        
        
       if (discrpCode !=null && (discrpCode.equals("DSPA") || discrpCode.equals("DSPO")||discrpCode.equals("DSPR"))){
    	   
    	   sheet.setColumnWidth((short)0, (short)3000);
           sheet.setColumnWidth((short)1, (short)3000);
           sheet.setColumnWidth((short)2, (short)3000);
           sheet.setColumnWidth((short)3, (short)3000);
           sheet.setColumnWidth((short)4, (short)3000);
           sheet.setColumnWidth((short)5, (short)3000);
           sheet.setColumnWidth((short)6, (short)3000);
           sheet.setColumnWidth((short)7, (short)3000);
          

           /**
            * Style for the header cells.
            */
           HSSFCellStyle headerCellStyle = wb.createCellStyle();
           HSSFFont boldFont = wb.createFont();
           boldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
           headerCellStyle.setFont(boldFont);

           HSSFRow row = sheet.createRow(0);
           HSSFCell cell = row.createCell((short) 0);
           cell.setCellStyle(headerCellStyle);
           cell.setCellValue(new HSSFRichTextString(" Medicaid ID").toString());
           cell = row.createCell((short) 1);
           cell.setCellStyle(headerCellStyle);
           cell.setCellValue(new HSSFRichTextString("ClaimID").toString());
           cell = row.createCell((short) 2);
           cell.setCellStyle(headerCellStyle);
           cell.setCellValue(new HSSFRichTextString("Effective Date").toString());
           cell = row.createCell((short) 3);
           cell.setCellStyle(headerCellStyle);
           cell.setCellValue(new HSSFRichTextString("PBP").toString());
           cell = row.createCell((short) 4);
           cell.setCellStyle(headerCellStyle);
           cell.setCellValue(new HSSFRichTextString("Delivery Date").toString());
           cell = row.createCell((short) 5);
           cell.setCellStyle(headerCellStyle);
           cell.setCellValue(new HSSFRichTextString("Apply Date").toString());
           cell = row.createCell((short) 6);
           cell.setCellStyle(headerCellStyle);
           cell.setCellValue(new HSSFRichTextString("Recon Status").toString());
           cell = row.createCell((short) 7);
           cell.setCellStyle(headerCellStyle);
           cell.setCellValue(new HSSFRichTextString("Last Update").toString());
        
           
           //ArrayList<ApplistMBDQueue> data = (ArrayList<ApplistMBDQueue>)dataList;
           int indexValue = 0;
           for (int index = 0; index < dataList.size(); index++) {
//               row = sheet.createRow(index + 1);            
               McaidAnomSummDetailVO data = (McaidAnomSummDetailVO) dataList.get(index);
               indexValue++;
               row = sheet.createRow(indexValue);
               cell = row.createCell((short) 0);
               HSSFRichTextString medicaidId = new HSSFRichTextString(data.getMedicaidId());
               cell.setCellValue(medicaidId.toString());
            
                   cell = row.createCell((short) 1);
                   HSSFRichTextString disc = new HSSFRichTextString(data.getClaimID());
                   cell.setCellValue(disc.toString());
                   cell = row.createCell((short) 2);
                   HSSFRichTextString effDate = new HSSFRichTextString(McaidReconHelper.dateMonthByYearFormat(data.getEffDate()));
                   cell.setCellValue(effDate.toString());
                   cell = row.createCell((short) 3);
                   HSSFRichTextString status = new HSSFRichTextString(data.getPbpDesc());
                   cell.setCellValue(status.toString());
                   cell = row.createCell((short) 4);
                   HSSFRichTextString pbpDesc = new HSSFRichTextString(data.getDeliveryDate());
                   cell.setCellValue(pbpDesc.toString());
                   cell = row.createCell((short) 5);
                   HSSFRichTextString mcaidId = new HSSFRichTextString(data.getStrApplyDate());
                   cell.setCellValue(mcaidId.toString());
                   cell = row.createCell((short) 6);
                   HSSFRichTextString plan = new HSSFRichTextString(data.getStatus());
                   cell.setCellValue(plan.toString());
                   cell = row.createCell((short) 7);
                   HSSFRichTextString userId = new HSSFRichTextString(data.getLastUpdate());
                   cell.setCellValue(userId.toString());
                 
           }
    	   
       }else {
        sheet.setColumnWidth((short)0, (short)3000);
        sheet.setColumnWidth((short)1, (short)3000);
        sheet.setColumnWidth((short)2, (short)3000);
        sheet.setColumnWidth((short)3, (short)3000);
        sheet.setColumnWidth((short)4, (short)3000);
        sheet.setColumnWidth((short)5, (short)3000);
        sheet.setColumnWidth((short)6, (short)3000);
        sheet.setColumnWidth((short)7, (short)3000);
        sheet.setColumnWidth((short)8, (short)3000);

        /**
         * Style for the header cells.
         */
        HSSFCellStyle headerCellStyle = wb.createCellStyle();
        HSSFFont boldFont = wb.createFont();
        boldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        headerCellStyle.setFont(boldFont);

        HSSFRow row = sheet.createRow(0);
        HSSFCell cell = row.createCell((short) 0);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString(" Medicaid ID").toString());
        cell = row.createCell((short) 1);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Discrepancy").toString());
        cell = row.createCell((short) 2);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Effective Date").toString());
        cell = row.createCell((short) 3);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Status").toString());
        cell = row.createCell((short) 4);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("PBP").toString());
        cell = row.createCell((short) 5);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("State Value").toString());
        cell = row.createCell((short) 6);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Plan Value").toString());
        cell = row.createCell((short) 7);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("User ID").toString());
        cell = row.createCell((short) 8);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Last Update").toString());
        
        //ArrayList<ApplistMBDQueue> data = (ArrayList<ApplistMBDQueue>)dataList;
        int indexValue = 0;
        for (int index = 0; index < dataList.size(); index++) {
//            row = sheet.createRow(index + 1);            
            McaidAnomSummDetailVO data = (McaidAnomSummDetailVO) dataList.get(index);
            indexValue++;
            row = sheet.createRow(indexValue);
            cell = row.createCell((short) 0);
            HSSFRichTextString medicaidId = new HSSFRichTextString(data.getMedicaidId());
            cell.setCellValue(medicaidId.toString());
          //Newborn\Kick Export Change: start
            if(StringUtil.nonNullTrim(anomVO.getSummSrchDiscrpCd()).equals("NBRN")){
            	cell = row.createCell((short) 1);
                HSSFRichTextString disc = new HSSFRichTextString("NBRN");
                cell.setCellValue(disc.toString());
                cell = row.createCell((short) 2);
                HSSFRichTextString effDate = new HSSFRichTextString(McaidReconHelper.dateMonthByYearFormat(data.getEffDate()));
                cell.setCellValue(effDate.toString());
                cell = row.createCell((short) 3);
                HSSFRichTextString status = new HSSFRichTextString(data.getStatus());
                cell.setCellValue(status.toString());
                cell = row.createCell((short) 4);
                HSSFRichTextString pbpDesc = new HSSFRichTextString(data.getPbpDesc());
                cell.setCellValue(pbpDesc.toString());
                cell = row.createCell((short) 5);
                HSSFRichTextString mcaidId = new HSSFRichTextString(data.getStateMedicaidId());
                cell.setCellValue(mcaidId.toString());
                cell = row.createCell((short) 6);
                HSSFRichTextString plan = new HSSFRichTextString(data.getPlan());
                cell.setCellValue(plan.toString());
                cell = row.createCell((short) 7);
                HSSFRichTextString userId = new HSSFRichTextString(data.getUserId());
                cell.setCellValue(userId.toString());
                cell = row.createCell((short) 8);
                HSSFRichTextString lastUpdt = new HSSFRichTextString(data.getLastUpdate());
                cell.setCellValue(lastUpdt.toString());
            }else if(StringUtil.nonNullTrim(anomVO.getSummSrchDiscrpCd()).equals("KIUN")){
                	cell = row.createCell((short) 1);
                    HSSFRichTextString disc = new HSSFRichTextString("KIUN");
                    cell.setCellValue(disc.toString());
                    cell = row.createCell((short) 2);
                    HSSFRichTextString effDate = new HSSFRichTextString(McaidReconHelper.dateMonthByYearFormat(data.getEffDate()));
                    cell.setCellValue(effDate.toString());
                    cell = row.createCell((short) 3);
                    HSSFRichTextString status = new HSSFRichTextString(data.getStatus());
                    cell.setCellValue(status.toString());
                    cell = row.createCell((short) 4);
                    HSSFRichTextString pbpDesc = new HSSFRichTextString(data.getPbpDesc());
                    cell.setCellValue(pbpDesc.toString());
                    cell = row.createCell((short) 5);
                    HSSFRichTextString mcaidId = new HSSFRichTextString(data.getStateMedicaidId());
                    cell.setCellValue(mcaidId.toString());
                    cell = row.createCell((short) 6);
                    HSSFRichTextString plan = new HSSFRichTextString(data.getPlan());
                    cell.setCellValue(plan.toString());
                    cell = row.createCell((short) 7);
                    HSSFRichTextString userId = new HSSFRichTextString(data.getUserId());
                    cell.setCellValue(userId.toString());
                    cell = row.createCell((short) 8);
                    HSSFRichTextString lastUpdt = new HSSFRichTextString(data.getLastUpdate());
                    cell.setCellValue(lastUpdt.toString());
            }else if(StringUtil.nonNullTrim(anomVO.getSummSrchDiscrpCd()).equals("KIPN")){
            	cell = row.createCell((short) 1);
                HSSFRichTextString disc = new HSSFRichTextString("KIPN");
                cell.setCellValue(disc.toString());
                cell = row.createCell((short) 2);
                HSSFRichTextString effDate = new HSSFRichTextString(McaidReconHelper.dateMonthByYearFormat(data.getEffDate()));
                cell.setCellValue(effDate.toString());
                cell = row.createCell((short) 3);
                HSSFRichTextString status = new HSSFRichTextString(data.getStatus());
                cell.setCellValue(status.toString());
                cell = row.createCell((short) 4);
                HSSFRichTextString pbpDesc = new HSSFRichTextString(data.getPbpDesc());
                cell.setCellValue(pbpDesc.toString());
                cell = row.createCell((short) 5);
                HSSFRichTextString mcaidId = new HSSFRichTextString(data.getStateMedicaidId());
                cell.setCellValue(mcaidId.toString());
                cell = row.createCell((short) 6);
                HSSFRichTextString plan = new HSSFRichTextString(data.getPlan());
                cell.setCellValue(plan.toString());
                cell = row.createCell((short) 7);
                HSSFRichTextString userId = new HSSFRichTextString(data.getUserId());
                cell.setCellValue(userId.toString());
                cell = row.createCell((short) 8);
                HSSFRichTextString lastUpdt = new HSSFRichTextString(data.getLastUpdate());
                cell.setCellValue(lastUpdt.toString());
            }
            else{
            //Newborn\Kick Export Change: end
                cell = row.createCell((short) 1);
                HSSFRichTextString disc = new HSSFRichTextString(data.getAnomaly());
                cell.setCellValue(disc.toString());
                cell = row.createCell((short) 2);
                HSSFRichTextString effDate = new HSSFRichTextString(McaidReconHelper.dateMonthByYearFormat(data.getEffDate()));
                cell.setCellValue(effDate.toString());
                cell = row.createCell((short) 3);
                HSSFRichTextString status = new HSSFRichTextString(data.getStatus());
                cell.setCellValue(status.toString());
                cell = row.createCell((short) 4);
                HSSFRichTextString pbpDesc = new HSSFRichTextString(data.getPbpDesc());
                cell.setCellValue(pbpDesc.toString());
                cell = row.createCell((short) 5);
                HSSFRichTextString mcaidId = new HSSFRichTextString(data.getStateMedicaidId());
                cell.setCellValue(mcaidId.toString());
                cell = row.createCell((short) 6);
                HSSFRichTextString plan = new HSSFRichTextString(data.getPlan());
                cell.setCellValue(plan.toString());
                cell = row.createCell((short) 7);
                HSSFRichTextString userId = new HSSFRichTextString(data.getUserId());
                cell.setCellValue(userId.toString());
                cell = row.createCell((short) 8);
                HSSFRichTextString lastUpdt = new HSSFRichTextString(data.getLastUpdate());
                cell.setCellValue(lastUpdt.toString());
            }
        }
       }
       logger.info(LoggerConstants.methodEndLevel());
        return wb;
    	
    }//createSummaryWorkbook()
    
    
    
    public HSSFWorkbook createFileWorkbook (List dataList) throws Exception  {
    	logger.info(LoggerConstants.methodStartLevel());
    	HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet("Files");
                
        sheet.setColumnWidth((short)0, (short)3000);
        sheet.setColumnWidth((short)1, (short)3000);
        sheet.setColumnWidth((short)2, (short)3000);
        sheet.setColumnWidth((short)3, (short)3000);
        sheet.setColumnWidth((short)4, (short)3000);
        sheet.setColumnWidth((short)5, (short)3000);
        sheet.setColumnWidth((short)6, (short)3000);
        sheet.setColumnWidth((short)7, (short)3000);
        sheet.setColumnWidth((short)8, (short)3000);

        /**
         * Style for the header cells.
         */
        HSSFCellStyle headerCellStyle = wb.createCellStyle();
        HSSFFont boldFont = wb.createFont();
        boldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        headerCellStyle.setFont(boldFont);

        HSSFRow row = sheet.createRow(0);
        HSSFCell cell = row.createCell((short) 0);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString(" File Type").toString());
        cell = row.createCell((short) 1);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Cycle Period").toString());
        cell = row.createCell((short) 2);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("PBP").toString());
        cell = row.createCell((short) 3);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Payment Amount").toString());
        cell = row.createCell((short) 4);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Record Count").toString());
        cell = row.createCell((short) 5);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Status").toString());
        cell = row.createCell((short) 6);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("File Date").toString());
        cell = row.createCell((short) 7);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("File Frequency").toString());
        cell = row.createCell((short) 8);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("File Name").toString());
        
        //ArrayList<ApplistMBDQueue> data = (ArrayList<ApplistMBDQueue>)dataList;
        int indexValue = 0;
        for (int index = 0; index < dataList.size(); index++) {
//            row = sheet.createRow(index + 1);            
            McaidFileDetailsVO data = (McaidFileDetailsVO) dataList.get(index);
            indexValue++;
            row = sheet.createRow(indexValue);
            cell = row.createCell((short) 0);
            HSSFRichTextString medicaidId = new HSSFRichTextString(data.getFileType());
            cell.setCellValue(medicaidId.toString());
            cell = row.createCell((short) 1);
            HSSFRichTextString disc = new HSSFRichTextString(data.getCyclePeriod());
            cell.setCellValue(disc.toString());
            cell = row.createCell((short) 2);
            HSSFRichTextString effDate = new HSSFRichTextString(data.getPbp());
            cell.setCellValue(effDate.toString());
            cell = row.createCell((short) 3);
            HSSFRichTextString status = new HSSFRichTextString(data.getPaymentAmt());
            cell.setCellValue(status.toString());
            cell = row.createCell((short) 4);
            HSSFRichTextString pbpDesc = new HSSFRichTextString(data.getRecordCount());
            cell.setCellValue(pbpDesc.toString());
            cell = row.createCell((short) 5);
            HSSFRichTextString mcaidId = new HSSFRichTextString(data.getFileStatus());
            cell.setCellValue(mcaidId.toString());
            cell = row.createCell((short) 6);
            HSSFRichTextString plan = new HSSFRichTextString(data.getFileDate());
            cell.setCellValue(plan.toString());
            cell = row.createCell((short) 7);
            HSSFRichTextString userId = new HSSFRichTextString(data.getFileFrequency());
            cell.setCellValue(userId.toString());
            cell = row.createCell((short) 8);
            HSSFRichTextString lastUpdt = new HSSFRichTextString(data.getFileName());
            cell.setCellValue(lastUpdt.toString());
        }
        logger.info(LoggerConstants.methodEndLevel());
        return wb;
    }
    private String getMonthName(int monVal){
    	logger.info(LoggerConstants.methodStartLevel());
	 	String[] months = new DateFormatSymbols().getMonths();
	 	logger.info(LoggerConstants.methodEndLevel());
		return months[monVal-1];	 			 	
 	}	
}//class
