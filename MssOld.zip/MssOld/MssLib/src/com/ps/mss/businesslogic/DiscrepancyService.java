/*
 * $Id: DiscrepancyService.java,v 1.1 2014/06/26 07:44:19 praveen Exp $
 *
 */
package com.ps.mss.businesslogic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.BaseDao;
import com.ps.mss.dao.DaoFactory;
import com.ps.mss.dao.DiscrepancyDao;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.Constants;
import com.ps.mss.helper.ServiceHelper;
import com.ps.mss.model.BeneficiaryDemographicVO;
import com.ps.mss.model.BeneficiaryVO;
import com.ps.mss.model.DiscrepancyDashBoardVO;
import com.ps.mss.model.DiscrepancyDetailVO;
import com.ps.mss.model.DiscrepancyDetailVOList;
import com.ps.mss.model.DiscrepancyListVO;
import com.ps.mss.model.DiscrepancySummaryVOList;
import com.ps.mss.model.DiseaseGroupVO;
import com.ps.mss.model.DiseaseGroupVOList;
import com.ps.mss.model.FilterVO;
import com.ps.util.DateUtil;
import com.ps.util.StringUtil;

/**
 * This class has business logic apply into discrepancy Dashboard, Discrepancy Detail and summary pages.
 * @author deepak
 *
 */
public class DiscrepancyService {
	private static Logger logger=(Logger) LoggerFactory.getLogger(DiscrepancyService.class);
	
	private String dbId;
	
	/**
	 * Parameterize Constructor for discrepancy service class . 
	 * @param dbId - DataBase Id.
	 */
	public DiscrepancyService(String dbId){
		this.dbId = dbId;
	}
	
	/**
	 * <code>Method</code> Has business logic apply on discrepancy list .This method calls methods on
	 * discrepancy dao class to fatch records for discrepancy detail page.
	 * @author Deepak
	 * 
	 * @param filterVO - Contains search criteria that apply on resulted records.
	 * @param discMap  - Contains DiscrepancyDetailVO corresponding to first and last row on ui.  
	 * @param move     - This contains first,last,next and previous .
	 * @param dbId     - Database Id.	 
	 * @param planMap  - This contains list of plan accessible to user	
	 * @param searchType - This contians plan,year and month use to show demographic info on beneficiary Detial.
	 * @param discrpArrMap - This contains Map for metadata.
	 * @return list of discrepancies - list of Ten or less then ten records.
	 * @throws ApplicationException
	 */
	public DiscrepancyDetailVOList getDiscrepancyList(FilterVO filterVO, Map discMap, String move, Map planMap, String searchType, Map discrpArrMap, String menuName, Map adjReasonMap, boolean hasWriteOffSerivce) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		DiscrepancyDetailVOList discrepancyDetailVOList = null ;
		DiscrepancyListVO discList = null ;
		DiscrepancyListVO [] discListVOArray = null ;
		DiscrepancyDetailVO discrepancyDetailVO = null ;
		DiscrepancyDetailVO partDDiscDetailVO = null ;
		DiscrepancyDao discDao = null;
		Map detailmap =  null;
		Integer selectedRow = null ;
		int defaultSelectedRow = 0;
		boolean flag = false; //true if part D list is selected
		boolean showHistory = true;
		String part =  filterVO.getPartName();
		DaoFactory factory = DaoFactory.getInstance();
		try {

			discDao = factory.getDiscrepancyDao(this.dbId);
			if (filterVO != null) 
				discDao.setHicNumbersAndMemberID(filterVO, planMap);		
			
			if( Constants.BOTH_PARTS.equals(part)) {
				//retrive discrepancy Map for part C (This Map contain selected row,discrepancyDetailVO for last and frist row).
				detailmap =  discMap != null ?(Map)discMap.get(Constants.PARTC_DISCRP_DETAIL_MAP) : null ;
				
				// Part C
				//get discrepancyDetailVo for part C
				discrepancyDetailVO = getDiscrepancyList(filterVO, planMap, detailmap, move, discrpArrMap, discDao, adjReasonMap, hasWriteOffSerivce,Constants.PARTC);
				if(discrepancyDetailVO != null) {//set discrepancy Detail List for part C
					discrepancyDetailVOList = new DiscrepancyDetailVOList();
					discrepancyDetailVOList.setPartCDiscrpDetailVO(discrepancyDetailVO); 
				}	
				
				// Part D 
				//retrive discrepancy Map for part D (This Map contain selected row,discrepancyDetailVO for last and frist row).
				detailmap =  discMap != null ?(Map)discMap.get(Constants.PARTD_DISCRP_DETAIL_MAP) : null ;
				//get discrepancyDetailVo for part D
				partDDiscDetailVO = getDiscrepancyList(filterVO, planMap, detailmap, move, discrpArrMap, discDao, adjReasonMap, hasWriteOffSerivce, Constants.PARTD);
				
				if(partDDiscDetailVO != null ) {//set discrepancy Detail list for part D
					if(discrepancyDetailVOList == null)
						discrepancyDetailVOList = new DiscrepancyDetailVOList();
					discrepancyDetailVOList.setPartDDiscrpDetailVO(partDDiscDetailVO);	
				}
			
				//Retrive selected row from map 
				selectedRow = discMap != null ? (Integer) discMap.get(Constants.PAGE_SELECTED_LINE) : null;
				
				if (discrepancyDetailVOList != null) {
					if(selectedRow != null ) {
						if( selectedRow.intValue() >= 10){ // selected row >= 10 then we have selected row into part D section on ui.
							discrepancyDetailVO = discrepancyDetailVOList.getPartDDiscrpDetailVO();
							defaultSelectedRow = selectedRow.intValue() - 10 ;
							flag = true ; //part D selected
						} else {// selected row < 10 then we have selected row into part C section on ui.
							defaultSelectedRow = selectedRow.intValue() ;
							discrepancyDetailVO = discrepancyDetailVOList.getPartCDiscrpDetailVO();
						}
					} else { //selected row is null  
						discrepancyDetailVO = discrepancyDetailVOList.getPartCDiscrpDetailVO();
						if(discrepancyDetailVO == null) { // when part C list is null
							discrepancyDetailVO = discrepancyDetailVOList.getPartDDiscrpDetailVO();
							flag = true ; //part D selected
						}
					}
					if (discrepancyDetailVO != null) {
						discListVOArray = discrepancyDetailVO.getDiscrepancyListVO();
						
						/*When return list have record less then selected row then seleced row is set to frist row*/
						if(discListVOArray != null && discListVOArray.length <= defaultSelectedRow )
							defaultSelectedRow = 0;
						
						discList = discListVOArray[defaultSelectedRow]; // Discrepancy Detail is fatch and shown for discList Vo only.
					}
					if(flag) // if part D selected then selected line is into part D section. 
						defaultSelectedRow += 10 ;
					discrepancyDetailVOList.setSelectedLine(defaultSelectedRow);
				}
			} else if(Constants.PARTD.equals(part)){//find part D discrepancy List
				//Retrive discrepancy Map for part D (This Map contain selected row,discrepancyDetailVO for last and frist row).
				detailmap =  discMap != null ?(Map)discMap.get(Constants.PARTD_DISCRP_DETAIL_MAP) :null ;
				//Retrive selected row from map 
				selectedRow = discMap != null ? (Integer) discMap.get(Constants.PAGE_SELECTED_LINE) : null ;

				//get discrepancyDetailVo for part D
				discrepancyDetailVO = getDiscrepancyList(filterVO, planMap, detailmap, move, discrpArrMap,discDao, adjReasonMap, hasWriteOffSerivce , Constants.PARTD);
				
				if (discrepancyDetailVO != null) {
					discrepancyDetailVOList = new DiscrepancyDetailVOList();
					discrepancyDetailVOList.setPartDDiscrpDetailVO(discrepancyDetailVO);
				
					if(selectedRow != null ){
						if(selectedRow.intValue() >= 10) //when part D Row is selected. 
							defaultSelectedRow = selectedRow.intValue() - 10 ;
						else //when part D row is not selected then there is not need to find history for row.
							showHistory = false;
						discrepancyDetailVOList.setSelectedLine(selectedRow.intValue());
					} else //set part D row selected if no row selected on ui.
						discrepancyDetailVOList.setSelectedLine(defaultSelectedRow + 10 );
					
					discListVOArray = discrepancyDetailVO.getDiscrepancyListVO();
					
					//length of list is less then seleced row then we set selected row to frist row.
					if(discListVOArray != null && discListVOArray.length <= defaultSelectedRow ) {
						defaultSelectedRow = 0;
						discrepancyDetailVOList.setSelectedLine(defaultSelectedRow + 10 );
					}
					discList = discListVOArray[defaultSelectedRow];
				}
			} else {
				
				//Retrive discrepancy Map for part C (This Map contain selected row,discrepancyDetailVO for last and frist row).
				detailmap =  discMap != null ?(Map)discMap.get(Constants.PARTC_DISCRP_DETAIL_MAP) : null ;
				//Retrive selected row from map
				selectedRow = discMap != null ? (Integer) discMap.get(Constants.PAGE_SELECTED_LINE) : null;
				
				//get discrepancyDetailVo for part C
				discrepancyDetailVO = getDiscrepancyList(filterVO, planMap, detailmap, move, discrpArrMap, discDao, adjReasonMap, hasWriteOffSerivce, Constants.PARTC);
				
				if (discrepancyDetailVO != null) {
					discrepancyDetailVOList = new DiscrepancyDetailVOList();
					discrepancyDetailVOList.setPartCDiscrpDetailVO(discrepancyDetailVO);
					discListVOArray = discrepancyDetailVO.getDiscrepancyListVO();
					
					if(selectedRow != null ) { // when selected row is not null
						if(selectedRow.intValue() < 10) {//when part C Row is selected.
							defaultSelectedRow = selectedRow.intValue();
							discrepancyDetailVOList.setSelectedLine(selectedRow.intValue());
							if(discListVOArray != null && discListVOArray.length <= defaultSelectedRow ) {//length of list is less then seleced row then we set selected row to frist row.
								defaultSelectedRow = 0;
								discrepancyDetailVOList.setSelectedLine(defaultSelectedRow);
							}
							discList = discListVOArray[defaultSelectedRow];
						} else { // when part C list is not selected then we need not to fatch records for discrepancy history
							discrepancyDetailVOList.setSelectedLine(selectedRow.intValue());
							showHistory = false;
						}
					} else { //when selected row is null then we have to set first row to default selected row.
						if(discListVOArray != null && discListVOArray.length <= defaultSelectedRow ) {
							defaultSelectedRow = 0; //selecte first row to defaulted selected row
							discrepancyDetailVOList.setSelectedLine(defaultSelectedRow);
						}
						discList = discListVOArray[defaultSelectedRow];	
					}
				}
			}
			if(discrepancyDetailVOList != null ) {
				boolean isReqForAllExport = ServiceHelper.isExportALLRequest(discMap, part);
				
				if(discList != null && showHistory && isReqForAllExport == false) { //Fetch discrepancy history
					List historyList = getHistoryAndBeneDetail(discList, filterVO, discDao);
					discrepancyDetailVOList.setDiscrepancyHistoryVO((List)historyList.get(0));
				}
			}
			
			if(discrepancyDetailVOList == null) //creating object of discrepancyDeailVOList when it is null. 
				discrepancyDetailVOList = new DiscrepancyDetailVOList();
			
			
			// get header title only for first time page load and reports.
			if(move == null || "current".equals(move) || "first".equals(move)){
				if(StringUtil.trimToNull(filterVO.getPageHeaderMsg()) == null) {
					filterVO.setPageHeaderMsg(createHeaderTitle(filterVO,planMap, discDao, true));
				}
				discrepancyDetailVOList.setSummaryHeaderTitle(filterVO.getPageHeaderMsg());
			}
			
			//IFOX-00431034 :: All-Plans in Discrepancy Drop down :: START
			String planName = null;
			
			if(discList != null && discList.getPlanName() != null)
				planName = discList.getPlanName();
			//IFOX-00431034 :: All-Plans in Discrepancy Drop down :: END
			
			//In case of beneficiary discrepancy detail we have to show demographic and header .
			if (Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(menuName))
				setBeneficiaryDetail(discrepancyDetailVOList ,searchType, filterVO, discDao, planName);	 //Added for IFOX-00431034 :: All-Plans in Discrepancy Drop down
			
		} finally { //This block will execute after execution of this method.
			if(discDao != null)
				discDao.closeConnection();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return discrepancyDetailVOList;
	}
	
	/**
	 * This generate header info of beneficiary page . This contains latest supp Id , suppId on effective date.
	 * @author Deepak
	 * 
	 * @param discListVO - find beneficiary info for selected line and set beneficiary info into discListVo.
	 * @param discrepancyDao - discrepancyDao Object thourgh which database call is done.
	 * @param filterVO - Contains search criteria that apply on resulted records.
	 * @return
	 * @throws ApplicationException
	 */
	private DiscrepancyListVO setBeneDetailForDiscrepancy( DiscrepancyListVO discListVO, DiscrepancyDao discrepancyDao, FilterVO filterVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		BeneficiaryVO beneficiaryDetail = null;
		String hicNbr = discListVO.getHicNumber();
		String partName = discListVO.getDiscrepancyIndicator();
		
		//IFOX-00431034 :: All-Plans in Discrepancy Drop down :: START
		boolean isAllPlanId = false;
		if(filterVO.getPlanName().equalsIgnoreCase("ALL")) {
			filterVO.setPlanName(discListVO.getPlanName());
			isAllPlanId = true;
		}
		//IFOX-00431034 :: All-Plans in Discrepancy Drop down :: END
		
		String startDate = filterVO.getStartDate();
		String endDate = filterVO.getEndDate();
		filterVO.setStartDate(discListVO.getPymtEffDate());
		filterVO.setEndDate(discListVO.getPymtEffDate());
		
		
		// getBeneDetailOnEffDate is getting Beneficary Detail based on Eff Date.
		try {
			//Fatch beneficiary detail on effective date.
			beneficiaryDetail = discrepancyDao.getBeneDetailOnEffDate(hicNbr, partName, filterVO);
		} finally {
			filterVO.setStartDate(startDate);
			filterVO.setEndDate(endDate);
		}
		
		if( beneficiaryDetail != null ) {
				//Fatch latest beneficiary detail .
				BeneficiaryVO mostRecentbeneDetail = discrepancyDao.getLatestBeneficiaryDetail(hicNbr, partName, filterVO);
				
				//setting beneficiary for  discrepancy Detail .
				discListVO.setFirstName(StringUtil.nonNullTrim(beneficiaryDetail.getFirstName()));
				discListVO.setLastName(StringUtil.nonNullTrim(beneficiaryDetail.getLastName()));
				discListVO.setEffDateSuppId(StringUtil.nonNullTrim(beneficiaryDetail.getSupplementalId()));
				discListVO.setPbpSegmentId(StringUtil.nonNullTrim(beneficiaryDetail.getPbpSegmentId()));
				discListVO.setMostRecentSuppId(mostRecentbeneDetail != null ? mostRecentbeneDetail.getMostRecentSuppId():"");
				
				if(Constants.PARTC.equals(discListVO.getDiscrepancyIndicator())) // set pbpId only in Case of part C.
					discListVO.setPbpId(beneficiaryDetail.getPbpId());
		}
		
		//IFOX-00431034 :: All-Plans in Discrepancy Drop down :: START
		if(isAllPlanId)
			filterVO.setPlanName("ALL");
		//IFOX-00431034 :: All-Plans in Discrepancy Drop down :: END
				
		logger.info(LoggerConstants.methodEndLevel());
		return discListVO;
	}
	
	/**
	 * This method returns discrepancy detail vo that contains currenPage, pageNumber and list of discrepancies .
	 * @author Deepak
	 * 
	 * @param filterVO - Contains search criteria that apply on resulted records.
	 * @param discMap  - Contains DiscrepancyDetailVO corresponding to first and last row on ui.  
	 * @param move     - This contains first,last,next and previous .
	 * @param discrpArrMap - This contains Map for metadata.
	 * @param discDao - DiscrepancyDao object we are using this object for database calls.
	 * @param adjReasonMap
	 * @param hasWriteOffSerivce
	 * @param partName 
	 * @return
	 * @throws ApplicationException
	 */

	private DiscrepancyDetailVO getDiscrepancyList(FilterVO filterVO, Map planMap, Map discMap, String move,  Map discrpArrMap , DiscrepancyDao discDao, Map adjReasonMap, boolean hasWriteOffSerivce, String partName) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
	    DiscrepancyDetailVO discDetailVO = null ;
	    DiscrepancyListVO[] discList = null ;
	    //Call discrepancyDao method to fatch discrepancy list.
	    discList = discDao.getDiscrepancyList(filterVO ,planMap, discMap ,move,discrpArrMap, adjReasonMap, hasWriteOffSerivce, partName);
	    if(discList!= null && discList.length > 0) { //discrepancy list is not null or empty
	        discDetailVO = new DiscrepancyDetailVO ();
	        String currentPage = null;
	        Integer pageNumber = new Integer(1);
	        if(discMap != null) {
	        	//Retriveing current page and page number for discMap.
	            currentPage = (String) discMap.get(Constants.CURRENT_PAGE);
	            pageNumber =  (Integer) discMap.get(Constants.PAGE_NUMBER);
	            if(pageNumber != null) {
	                if("next".equals(move)){ //when this call is for next page (mean move is for next page). 
	                    pageNumber = new Integer(pageNumber.intValue() + 1); //increase page number by one
	                } else if ("previous".equals(move)) { //when this call is for previous page (mean move is for previous page).
	                    pageNumber = new Integer(pageNumber.intValue() - 1);//decrease page number by one
	                    if(pageNumber.intValue() == 0) //After decreasing if page Nuber is zero
	                        pageNumber = new Integer(1); // set page number to frist page.
	                } else if("first".equals(move)) { // when call is for frist page
	                    pageNumber = new Integer(1); // set page number to frist page.
	                }
	            } else { //default page is first page.
	                pageNumber = new Integer(1);
	            }
	        }		
	        //if list < 10 then there is no more records for this search criterial so it is last page for current search criteria.
	        if(discList != null && discList.length < 10 )
	            currentPage = "last";
	        else if( currentPage == null) // default current page is frist page 
	            currentPage = "first";
	        else {
	            currentPage = move; 
	        }
	        //set current page and page number inot discrepancy detail.
	        discDetailVO.setDiscrepancyListVO(discList);
	        discDetailVO.setCurrentPage(currentPage);
	        discDetailVO.setPageNumber(pageNumber.intValue());
	    }
	    logger.info(LoggerConstants.methodEndLevel());
	    return discDetailVO;
	}
	/**
	 * This set beneficiary detail into discperpancyDetailVOList for hic number .
	 * @param discrepancyDetailVOList - discrepancyDetailVoList in which we have to add beneficiary info.
	 * @param searchType - If seachType contains month then we have to find both demographic and beneficiary info otherwise beneficiary info only.
	 * @param filterVO - Contains search criteria that apply on resulted records. 
	 * @param discrepancyDao : Object of discrepancyDao using this we do call in database.
	 * @throws ApplicationException
	 * 
	 */
	private void setBeneficiaryDetail(DiscrepancyDetailVOList discDetailVOList,  String searchType, FilterVO filterVO, DiscrepancyDao discrepancyDao, String planName) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		if(discDetailVOList != null) {
			String hicNbr = filterVO.getHicNumber();
			BeneficiaryVO beneDetail = null;
			
			//IFOX-00431034 :: All-Plans in Discrepancy Drop down :: START
			boolean isAllPlanId = false;
			if(filterVO.getPlanName().equalsIgnoreCase("ALL") && null != planName) {
				filterVO.setPlanName(planName);
				isAllPlanId = true;
			}
			//IFOX-00431034 :: All-Plans in Discrepancy Drop down :: END
			
			if("month".equals(searchType)) { // Demographic info is shown only when search is made for a month
				//fatching demographic info for part C
				BeneficiaryDemographicVO beneficiaryDemographicVO = discrepancyDao.getBeneficiaryDemographicDetail(filterVO,Constants.PARTC);
				if (beneficiaryDemographicVO == null) // when demographic info for part c is null then only we find demographic info for part D
					beneficiaryDemographicVO = discrepancyDao.getBeneficiaryDemographicDetail(filterVO,Constants.PARTD);
				//create header info 
				beneDetail = getHeaderInfo(discrepancyDao ,hicNbr, filterVO);
				if(beneDetail != null) {
					discDetailVOList.setBeneficiaryDetail(beneDetail);
					discDetailVOList.setBeneficiaryDemographicVO(beneficiaryDemographicVO == null ? new BeneficiaryDemographicVO() : beneficiaryDemographicVO);
				}
			} else {
				beneDetail = getHeaderInfo(discrepancyDao, hicNbr, filterVO);
				discDetailVOList.setBeneficiaryDetail(beneDetail);
			}
			if (beneDetail != null && filterVO!=null) 
				beneDetail.setOtherHics(ServiceHelper.convertHicsToStrings(filterVO.getHicNumber(), filterVO.getHicNumberList()));
			
			//IFOX-00431034 :: All-Plans in Discrepancy Drop down :: START
			if(isAllPlanId)
				filterVO.setPlanName("ALL");
			//IFOX-00431034 :: All-Plans in Discrepancy Drop down :: END
		}
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	/**
	 * This generate header info of beneficiary.This contains latest supp Id , suppId on effective date.
	 * @param discrepancyDao - Object of discrepancyDao using this we do call in database.
	 * @param hicNbr - HIC# value. 
	 * @param filterVO - Contains search criteria that apply on resulted records.
	 * @return
	 * @throws ApplicationException
	 */
	private BeneficiaryVO getHeaderInfo(DiscrepancyDao discrepancyDao, String hicNbr, FilterVO filterVO) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		//call to find latest beneficiary detail from database.
		BeneficiaryVO mostRecentbeneDetail = discrepancyDao.getLatestBeneficiaryDetail(hicNbr,Constants.PARTC,filterVO);
		if( mostRecentbeneDetail == null ){ //part C does not contains latestBeneficiary detail.
			//call to find latest beneficiary deatil for part D .
			mostRecentbeneDetail = discrepancyDao.getLatestBeneficiaryDetail(hicNbr,Constants.PARTD,filterVO);
			
			//Call to find beneficiary Detail for part D on effective Date.			
			BeneficiaryVO beneficiaryDetail = discrepancyDao.getBeneDetailOnEffDate(hicNbr,Constants.PARTD,filterVO);
			if( mostRecentbeneDetail != null ) {
				mostRecentbeneDetail.setHicNbr(hicNbr);
				mostRecentbeneDetail.setSupplementalId(beneficiaryDetail != null ? beneficiaryDetail.getSupplementalId():"");
			}
		} else { // when beneficiary detail for part C is  not null.
			//Call to find beneficiary Detail on effective Date for part C.
			BeneficiaryVO beneficiaryDetail = discrepancyDao.getBeneDetailOnEffDate(hicNbr,Constants.PARTC,filterVO);
			mostRecentbeneDetail.setSupplementalId(beneficiaryDetail != null ? beneficiaryDetail.getSupplementalId():"");
		}
		logger.info(LoggerConstants.methodEndLevel());
		return mostRecentbeneDetail;
	}

	/**
	 * This method is to return total number of records for export. if this number is more than the MAX RECORD COUNT(obtained from database) than return 'TRUE'
	 * @author hemant  
	 * @param filterVO
	 * @param discrpMap
	 * @return "TRUE" or Max valid Number of records to show  
	 * @throws ApplicationException
	 */
	public String isExportDiscDetailRequestValid(FilterVO filterVO, Map discrpMap, Map planmap)throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		String result;
		DiscrepancyDao discDao = null;
		DaoFactory factory = DaoFactory.getInstance();
		
		//get MAX RECORD COUNT
		try {
			CodeCacheService codeCache = new CodeCacheService();
			Integer countObj = codeCache.getDiscMaxRecordCount();
			int count = 0;
			//Fix for export issue to limit temporarily :start
			//countObj = 1000;
			//Fix for export issue to limit temporarily :end
			if(countObj != null){
				count = countObj.intValue();
			}
			
			discDao = factory.getDiscrepancyDao(this.dbId);
			
			int selectedRowNo=0;
			
			//get selected row number 
			if(discrpMap != null) {
				Integer temp = ((Integer)discrpMap.get(Constants.PAGE_SELECTED_LINE));
				if(temp != null)
					selectedRowNo = temp.intValue() ; 
			}
			
			String saveDiscInd = filterVO.getPartName();
			if(Constants.PARTD.equals(saveDiscInd) && selectedRowNo == 0)
				selectedRowNo = 10;//because for part D, first row is default selected row with selectedRowNo '10' 
			
			if(selectedRowNo < 10){
				filterVO.setPartName(Constants.PARTC);
			}else{
				filterVO.setPartName(Constants.PARTD);
			}
			result = discDao.getTotalDiscrepancyRecords(filterVO,count+1, planmap);	//IFOX-00431034 :: All-Plans in Discrepancy Drop down
			//reset filterVO
			filterVO.setPartName(saveDiscInd);		
		} finally {
			if(discDao != null)
				discDao.closeConnection();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return result;
	}

	/**
	 * Get discrepancy detail, and discrepancy history
	 * @param discListVO 
	 * @param filterVO - Contains search criteria that apply on resulted records. 
	 * @return
	 * @throws ApplicationException
	 */
	public List getDiscrepancyDetails(DiscrepancyListVO discListVO, FilterVO filterVO, Map discrpArrMap, boolean hasWriteOffService, String partName) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		DiscrepancyDao discrepancyDao = null ;
		try {
			DaoFactory factory = DaoFactory.getInstance();
			discrepancyDao = factory.getDiscrepancyDao(this.dbId);
			discListVO = discrepancyDao.getDiscrepancyDetails(discListVO, discrpArrMap, hasWriteOffService, partName);
			// now get discrepancy History and beneficiary detail
			logger.info(LoggerConstants.methodEndLevel());
			return getHistoryAndBeneDetail(discListVO, filterVO, discrepancyDao);
		} finally {
			if(discrepancyDao != null)
				discrepancyDao.closeConnection();
		}
	}
		
	/**
	 * Fucntion fatches history for discrepancy and set Beneficiary detail into discrepancy list vo.
	 * @param discListVO
	 * @param filterVO - Contains search criteria that apply on resulted records.
	 * @param discrepancyDao - Object of discrepancyDao using this we do call in database.
	 * @return List : contain discrepancy Hostry and beneficiary detail.
	 * @throws ApplicationException
	 */
	private List getHistoryAndBeneDetail(DiscrepancyListVO discListVO, FilterVO filterVO , DiscrepancyDao discrepancyDao) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String planId  = discListVO.getPlanName();	//IFOX-00431034 :: All-Plans in Discrepancy Drop down
		//call for fatching discrepancy hostory.
		List discrepancyHistories = discrepancyDao.getDiscrepancyHistory(discListVO,planId);
		List returnList = new ArrayList();
		returnList.add(discrepancyHistories);
		//Set beneficiary detail into discListVO
		discListVO = setBeneDetailForDiscrepancy(discListVO, discrepancyDao, filterVO);
		returnList.add(discListVO);
		logger.info(LoggerConstants.methodEndLevel());
		return returnList ;
	}
	
	/**
	 * Method handle call for discrepancy Dashbaord into paln and beneficiary menu.
	 * <code>Method</code> apply logic for discrepancy dashbaord .
	 * It populate Array for Dashbaord according to ui Context.
	 * @param filterVO
	 * @param plansMap
	 * @param searchType
	 * @return
	 * @throws ApplicationException
	 */
	public DiscrepancyDashBoardVO[] getDiscrepancyDashBoard(FilterVO filterVO, Map plansMap, String searchType, List discrepancyDashBoardStatus, String menuName) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		DaoFactory factory = DaoFactory.getInstance();
		BaseDao baseDao = null;
		DiscrepancyDashBoardVO [] planDiscrDashboardVOArr = null;
		DiscrepancyDashBoardVO [] planDiscrpDeshBoardVOArr = null;
		try {
			if (Constants.BENEFICIARY_MENU.equals(menuName)) {//call for beneficiary discrepancy dashboard.
				baseDao = factory.getBeneficiaryDao(this.dbId);
			} else {
				baseDao = factory.getDiscrepancyDao(this.dbId);
			}
			planDiscrDashboardVOArr = baseDao.getDiscrepancyDashBoard(filterVO,plansMap,searchType);
			if(planDiscrDashboardVOArr != null) {
				ServiceHelper.addPlanName(plansMap,planDiscrDashboardVOArr);
				if(!"plan".equals(searchType))
					Arrays.sort(((DiscrepancyDashBoardVO[])planDiscrDashboardVOArr ));	
				if( discrepancyDashBoardStatus != null ) {
					FilterVO tempFilterVO = new FilterVO();
					DiscrepancyDashBoardVO planDiscrpDashboardVO = null;
					DiscrepancyDashBoardVO yearDiscrpDashboardVO = null;
					DiscrepancyDashBoardVO[] yearDiscrpDashboardVOArr = null;
					DiscrepancyDashBoardVO[] monthDiscrpDashboardVOArr = null;
					String key = null;
					String planName = null;
					String year = null;
					
					//Loop for finding Year for those plan which are expendes in uiContext
					for(int i=0 ; i< planDiscrDashboardVOArr.length ; i++) {
						//creating temprory filterVo from filterVo .
						tempFilterVO.setPlanName(filterVO.getPlanName());
						tempFilterVO.setDateType(filterVO.getDateType());
						tempFilterVO.setStartDate(filterVO.getStartDate());
						tempFilterVO.setEndDate(filterVO.getEndDate());
						tempFilterVO.setHicNumber(filterVO.getHicNumber());
						
						planDiscrpDashboardVO = (DiscrepancyDashBoardVO) planDiscrDashboardVOArr[i];
						planName = planDiscrpDashboardVO.getRollupId();
						key = planName; // key contain plan Name
						tempFilterVO.setPlanName(planName);
						searchType = "year";
						//Fatch discrpancy Dashboard records if key is exist into ui context
						yearDiscrpDashboardVOArr = getDiscrpDashboardArr(baseDao,tempFilterVO,plansMap,searchType,key,discrepancyDashBoardStatus);
						if(yearDiscrpDashboardVOArr != null) {
							Arrays.sort(((DiscrepancyDashBoardVO[])yearDiscrpDashboardVOArr ));
							//Loop for finding Month for those year which are expended for this plan,year.
							for(int j=0 ; j< yearDiscrpDashboardVOArr.length ; j++) {
								yearDiscrpDashboardVO = (DiscrepancyDashBoardVO) yearDiscrpDashboardVOArr[j];
								year = yearDiscrpDashboardVO.getRollupId();
								key  = planName + "_"+ year  ; // key is plan Name + year into this plan
								
								//if search critaria already does not have this year into start Date .
								if(!ServiceHelper.isContain(filterVO.getStartDate(),year) || !ServiceHelper.isContain(tempFilterVO.getStartDate(),year)) {
									if(ServiceHelper.isContain(filterVO.getStartDate(),year) ) { // seach cretarial contain year than we fatch records started from that particuarymonth which is into search cretaria.
										String month = DateUtil.addSlashIntoDate(filterVO.getStartDate()).substring(0,2);
										tempFilterVO.setStartDate(year+month);	
									} else //if filtervo does not contains year into start date then we find records from january. 
										tempFilterVO.setStartDate(year+"01");
								}
								//if search filter endDate does not have year .
								if(!ServiceHelper.isContain(filterVO.getEndDate(),year) || !ServiceHelper.isContain(tempFilterVO.getEndDate(),year)) {
									tempFilterVO.setEndDate(year+"12"); 
								}
								searchType = "month";
								//searching for month
								monthDiscrpDashboardVOArr = getDiscrpDashboardArr(baseDao,tempFilterVO,plansMap,searchType,key,discrepancyDashBoardStatus);
								if(monthDiscrpDashboardVOArr != null)
									Arrays.sort(((DiscrepancyDashBoardVO[])monthDiscrpDashboardVOArr ));
								yearDiscrpDashboardVO.setDiscrepancyDashBoardVOArray(monthDiscrpDashboardVOArr);
							}
						}
						planDiscrpDashboardVO.setDiscrepancyDashBoardVOArray(yearDiscrpDashboardVOArr);
					}
				}
			}
		} finally {
			if(baseDao != null)
				baseDao.closeConnection();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return planDiscrDashboardVOArr ;
	}
	
	/**
	 * <code >Method </code > fatch discrepancy Dashboard array for those key which are exist into ui - context list.
	 * or if call is for all records.
	 * @param paymentDao
	 * @param tempFilterVO
	 * @param plansMap
	 * @param searchType
	 * @param key
	 * @param paymentDashBoardStatus
	 * @return
	 * @throws ApplicationException
	 */
	private DiscrepancyDashBoardVO[] getDiscrpDashboardArr(BaseDao baseDao, FilterVO tempFilterVO, Map plansMap, String searchType, String key, List discrepancyDashBoardStatus) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		//check wether key is exist into ui- context array( discrepancyDashbaordStatus array) or call is for all records.
		if(discrepancyDashBoardStatus.contains(key)|| discrepancyDashBoardStatus.contains(Constants.CONSTANTS_ALL)){
			return baseDao.getDiscrepancyDashBoard(tempFilterVO,plansMap,searchType);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return null;
	}
	
	/**
	 * <colde>Method</code> populate discrepany summary from database and apply business logic.
	 * @param filterVO
	 * @param searchType
	 * @param partName
	 * @param plansMap
	 * @param discrpArrMap
	 * @return
	 * @throws ApplicationException
	 */
	public DiscrepancySummaryVOList getDiscrepancySummary(FilterVO filterVO,String searchType,String partName, Map plansMap, Map discrpArrMap ) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		
		DaoFactory factory = DaoFactory.getInstance();
		DiscrepancyDao discrepancyDao = null;
		DiscrepancySummaryVOList discrepancySummaryVOList = new DiscrepancySummaryVOList ();
		try {
			discrepancyDao  = factory.getDiscrepancyDao(this.dbId);
			partName = StringUtil.trimToNull(partName);
			//fatch discrepancy summary for part C and both.
			if (partName == null || Constants.BOTH_PARTS.equals(partName) || Constants.PARTC.equals(partName)) {
				int totalMember = discrepancyDao.getMembersByParts(filterVO,plansMap,Constants.PARTC);
				discrepancySummaryVOList.setTotalMbrPartC(totalMember);
				discrepancySummaryVOList.setDiscrepancySummaryPartCVOArray(discrepancyDao.getDiscrepancySummary(filterVO,searchType,Constants.PARTC,plansMap,totalMember,discrpArrMap));
			}
			//fatch discrepancy summary for part D and both.
			if (partName == null || Constants.BOTH_PARTS.equals(partName) || Constants.PARTD.equals(partName)) {
				int totalMember = discrepancyDao.getMembersByParts(filterVO,plansMap,Constants.PARTD);
				discrepancySummaryVOList.setTotalMbrPartD(totalMember)	;		
				discrepancySummaryVOList.setDiscrepancySummaryPartDVOArray(discrepancyDao.getDiscrepancySummary(filterVO,searchType,Constants.PARTD,plansMap,totalMember,discrpArrMap));
			}
			discrepancySummaryVOList.setLatestDateArray(getLatestDateArray(filterVO,plansMap,searchType,discrepancyDao));
			
			// getting Page Serach header String 
			if(StringUtil.trimToNull(filterVO.getPageHeaderMsg()) == null){
				filterVO.setPageHeaderMsg(createHeaderTitle(filterVO, plansMap, discrepancyDao, false));
			}
			discrepancySummaryVOList.setSummaryHeaderTitle(filterVO.getPageHeaderMsg());
			
		} finally {
			if(discrepancyDao != null)
				discrepancyDao.closeConnection();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return discrepancySummaryVOList;
	}
	
	/**
	 * @author Hemant
	 * @param filterVO
	 * @param plansMap
	 * @param searchType
	 * @param discrepancyDao
	 * @return
	 * @throws ApplicationException
	 */
	private String[] getLatestDateArray(FilterVO filterVO, Map plansMap, String searchType, DiscrepancyDao discrepancyDao) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		int[] partCLatestDate = discrepancyDao.getLatestDate(filterVO, plansMap, Constants.PARTC);
		int[] partDLatestDate = discrepancyDao.getLatestDate(filterVO, plansMap, Constants.PARTD);
		logger.info(LoggerConstants.methodEndLevel());
		return ServiceHelper.getLatestDateArray(partCLatestDate,partDLatestDate);
	}

	/**
	 * This function create Header discrepancy summary base on search criteria.
	 * @param filterVO
	 * @param custPlanMap
	 * @param searchType
	 * @param discrepancyDao
	 * @return
	 * @throws ApplicationException
	 */
	private String createHeaderTitle(FilterVO filterVO, Map custPlanMap, DiscrepancyDao discDao, boolean displayMultHic) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		int[] partCLatestDate = discDao.getLatestDate(filterVO,custPlanMap,Constants.PARTC);
		int[] partDLatestDate = discDao.getLatestDate(filterVO,custPlanMap,Constants.PARTD);
		String title =  ServiceHelper.createHeaderTitle(filterVO,partCLatestDate,partDLatestDate,custPlanMap, null);
		if (displayMultHic) {
			//August 11, 2009. For now, just display the note based on the existence of hicList.
			/*
			int number = discDao.numberOfHicForEffDate(filterVO, partCLatestDate, partDLatestDate);
			if (number > 1) 
				title = title.concat("  ** Multiple HIC numbers");
			*/
			List hicList =  filterVO.getHicNumberList();
			if (hicList != null && hicList.size() > 0)
				title = title.concat("  ** Multiple HIC numbers");
		}
		logger.info(LoggerConstants.methodEndLevel());
		return title;
			
	}
	
	/**
	 * @param filterVO
	 * @param pageName
	 * @param menuName
	 * @return
	 * @throws ApplicationException
	 */
	public String getSearchCreiteriaHeader(FilterVO filterVO, String pageName, String menuName) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		logger.info(LoggerConstants.methodEndLevel());
		return ServiceHelper.getSearchCreiteriaHeader(filterVO, pageName, menuName);
	}

	/**
	 * Method fatch disease group detail from database.
	 * @param filterVO
	 * @param planValue
	 * @param cmsValue
	 * @param planMap
	 * @return
	 * @throws ApplicationException
	 */
	public DiseaseGroupVOList diseaseGroupDetail(FilterVO filterVO, String cmsValue, String planValue, Map planMap) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		DaoFactory factory = DaoFactory.getInstance();
		DiscrepancyDao discrepancyDao = null;
		DiscrepancySummaryVOList discrepancySummaryVOList = new DiscrepancySummaryVOList ();
		DiseaseGroupVOList diseaseGroupVOList = new DiseaseGroupVOList();
		DiseaseGroupVO [] diseaseGroupVOs = null;
		String partName = filterVO.getPartName();
		try {
			discrepancyDao = factory.getDiscrepancyDao(this.dbId);
			// call for disease group detail.
			Map diseaseGrpMap = discrepancyDao.diseaseGroupDetail(filterVO);
			if(Constants.PARTD.equals(partName)) // find disease group detail for part D
				diseaseGroupVOs = getDiseasePartDGrpDetail(diseaseGrpMap);
			else // find disease group detail for part C
				diseaseGroupVOs = getDiseaseGrpDetail(diseaseGrpMap, cmsValue, planValue);
			
			diseaseGroupVOList.setDiseaseGroupVOs(diseaseGroupVOs);
			//create title.
			diseaseGroupVOList.setSummaryHeaderTitle(ServiceHelper.createHeaderTitle(filterVO, null , null, planMap, null));

			String hicNbr = filterVO.getHicNumber();
			//Find beneficiary detail header
			BeneficiaryVO beneficiaryDetail = getHeaderInfo(discrepancyDao,hicNbr,filterVO); 
			diseaseGroupVOList.setBeneficiaryDetail(beneficiaryDetail);
		} finally {
			if(discrepancyDao != null)
				discrepancyDao.closeConnection();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return diseaseGroupVOList;
	}

	/**
	 * Get DiseagseGroupVO array from map
	 * @param diseaseGrpMap
	 * @param cmsValue
	 * @param planValue
	 * @return
	 */
	private DiseaseGroupVO[] getDiseasePartDGrpDetail(Map diseaseGrpMap) {
		logger.info(LoggerConstants.methodStartLevel());
		if (diseaseGrpMap == null )
			return null;
		DiseaseGroupVO[] diseaseGroupVOs = null ;
		Collection collection = new TreeMap(diseaseGrpMap).values();
		logger.info(LoggerConstants.methodEndLevel());
		return (DiseaseGroupVO[])collection.toArray(new DiseaseGroupVO[collection.size()]);
	}

	/**
	 * This function give DiseaseGroupVO for cms and plan 
	 * @param diseaseGrpMap
	 * @param cmsValue
	 * @param planValue
	 */
	private DiseaseGroupVO [] getDiseaseGrpDetail(Map diseaseGrpMap, String cmsValue, String planValue) {
		logger.info(LoggerConstants.methodStartLevel());
		List diseaseList = new ArrayList();
		if (diseaseGrpMap == null )
			return null;
		DiseaseGroupVO diseaseGroupVO = null ;
		
		for(int i = 1 ; i <= 81 ; i++){
			diseaseGroupVO = new DiseaseGroupVO();
			diseaseGroupVO.setDiscrepancy((String)diseaseGrpMap.get(new Integer(i)));
			diseaseGroupVO.setCms(getValue(cmsValue,i));
			diseaseGroupVO.setPlan(getValue(planValue,i));
			diseaseList.add(diseaseGroupVO);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return (DiseaseGroupVO[])diseaseList.toArray(new DiseaseGroupVO[diseaseList.size()]);
	}

	/**
	 * Find cms And plan value and apply condition on cms & plan values.
	 * @param cmsPlanValue
	 * @param i
	 * @return
	 */
	private String getValue(String cmsPlanValue, int i) {
		logger.info(LoggerConstants.methodStartLevel());
		if(Constants.NO_DATA.equals(cmsPlanValue) || "".equals(cmsPlanValue)) 
			return Constants.NO_DATA; // Showing 'No Data' on UI if CMS or Plan having value as 'NO DATA'.
		
		String retValue  = "";
		if(cmsPlanValue != null && cmsPlanValue.length() >= i){
			char value = cmsPlanValue.charAt(i-1); // i is starting from 1		
			if('1' == value)
				retValue = "Y";
			else if('0' != value && ' ' != value) // valid entries are { '0', '1', ' ' }
				retValue = Constants.INVALID_DATA;
			
		} else // if cmsPlan vlaue is less then ith value
			retValue = Constants.INVALID_DATA;
		logger.info(LoggerConstants.methodEndLevel());
		return retValue;
	}
	
	public int updateDiscrepancyStatus(DiscrepancyListVO discrepancyVO, String currentUserId, boolean hasBothDiscPermission) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		DiscrepancyDao discrepancyDao = null;
		int result = -1;
		try {
			DaoFactory factory = DaoFactory.getInstance();
			discrepancyDao = factory.getDiscrepancyDao(this.dbId);
			result = discrepancyDao.updateDiscrepancyStatus(discrepancyVO, currentUserId, hasBothDiscPermission);
			
		} finally {
			if(discrepancyDao != null)
				discrepancyDao.closeConnection();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return result;
	}
	
	public int cancelWriteoffRequest(DiscrepancyListVO discrepancyListVO, String currentUserId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		int result = -1;
		DiscrepancyDao discrepancyDao = null;
		try {
			DaoFactory factory = DaoFactory.getInstance();
			discrepancyDao = factory.getDiscrepancyDao(this.dbId);

			if(Constants.PARTD.equals(discrepancyListVO.getDiscrepancyIndicator()))
				discrepancyListVO.setApplyTo("PARTD");
			else
				discrepancyListVO.setApplyTo("PARTC");

			
			if("2".equals(discrepancyListVO.getDiscrepancyType()))  //payment discrepancy
				result = discrepancyDao.cancelPaymentWriteoffRequest(discrepancyListVO, currentUserId);
			else
				result = discrepancyDao.cancelFCLOWriteoffRequest(discrepancyListVO, currentUserId);

		} finally {
			if(discrepancyDao != null)
				discrepancyDao.closeConnection();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return result;	
	}

	public int updateDiscrepancyWriteOff(DiscrepancyListVO discrepancyListVO, String currentUserId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		int result = -1;
		DiscrepancyDao discrepancyDao = null;
		try {
			DaoFactory factory = DaoFactory.getInstance();
			discrepancyDao = factory.getDiscrepancyDao(this.dbId);
			
			if(Constants.PARTD.equals(discrepancyListVO.getDiscrepancyIndicator())){
				discrepancyListVO.setApplyTo("PARTD");
			} else {
				discrepancyListVO.setApplyTo("PARTC");
			}
			result = discrepancyDao.updateDiscrepancyWriteOff(discrepancyListVO, currentUserId);
			
		} finally {
			if(discrepancyDao != null)
				discrepancyDao.closeConnection();
		}
		logger.info(LoggerConstants.methodEndLevel());
		return result;
	}
}
