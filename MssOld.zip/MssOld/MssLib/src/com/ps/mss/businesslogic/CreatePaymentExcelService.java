package com.ps.mss.businesslogic;

import java.awt.Color;
import java.text.DateFormatSymbols;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.model.McaidAnomSummDetailVO;
import com.ps.mss.dao.model.McaidPaymentDashBoardVO;
import com.ps.mss.helper.McaidReconHelper;
import com.ps.mss.model.McaidReconPaymentVO;
import com.ps.util.StringUtil;




/**
 *
 * @author prare
 */
public class CreatePaymentExcelService {
	
	private static Logger logger=(Logger) LoggerFactory.getLogger(CreatePaymentExcelService.class);

    public HSSFWorkbook createDashboardWorkbook(List dataList) throws Exception {
    	logger.info(LoggerConstants.methodStartLevel());
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet("Payment Dashboard");
        
        
        sheet.setColumnWidth((short)0, (short)4000);
        sheet.setColumnWidth((short)1, (short)9000);
        sheet.setColumnWidth((short)2, (short)2000);
        sheet.setColumnWidth((short)3, (short)9000);
        sheet.setColumnWidth((short)4, (short)5000);
        sheet.setColumnWidth((short)5, (short)5000);

        /**
         * Style for the header cells.
         */
        HSSFCellStyle headerCellStyle = wb.createCellStyle();
        HSSFFont boldFont = wb.createFont();
        boldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        headerCellStyle.setFont(boldFont);

        HSSFRow row = sheet.createRow(0);
        HSSFCell cell = row.createCell((short) 0);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("PBP/Period").toString());
        cell = row.createCell((short) 1);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("State Paid").toString());
        cell = row.createCell((short) 2);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Plan Expected").toString());
        cell = row.createCell((short) 3);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Difference").toString());
        /*cell = row.createCell((short) 4);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Force Closed").toString());
        cell = row.createCell((short) 5);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Resolved").toString());*/
        
        int index = 0;
        for (int pbpIndex = 0; pbpIndex < dataList.size(); pbpIndex++) {
        	
        	McaidPaymentDashBoardVO pbpData = (McaidPaymentDashBoardVO) dataList.get(pbpIndex);
            index++;
            row = sheet.createRow(index);
            
            cell = row.createCell((short) 0);            
            HSSFRichTextString PbpPeriod = new HSSFRichTextString(pbpData.getPbpDesc());
            cell.setCellValue(PbpPeriod.toString());
            cell = row.createCell((short) 1);
            HSSFRichTextString statePaid  = new HSSFRichTextString(pbpData.getCmsPaid());
            cell.setCellValue(statePaid.toString());
            cell = row.createCell((short) 2);
            HSSFRichTextString planExpected = new HSSFRichTextString(pbpData.getPlanExpected());
            cell.setCellValue(planExpected .toString());
            cell = row.createCell((short) 3);
            HSSFRichTextString difference = new HSSFRichTextString(pbpData.getDiffrence());
            cell.setCellValue(difference.toString());
            /*cell = row.createCell((short) 4);
            HSSFRichTextString forceClose = new HSSFRichTextString(pbpData.getForceClosed());
            cell.setCellValue(forceClose.toString());
            cell = row.createCell((short) 5);
            HSSFRichTextString resolve = new HSSFRichTextString(pbpData.getResolved());
            cell.setCellValue(resolve.toString());*/
            
            //year-START
            List yearDataList = pbpData.getPbpYrOrQtrOrMonLst();
            if(yearDataList != null){//yearIf
	            for (int yearIndex = 0; yearIndex < yearDataList.size(); yearIndex++) {
	            	McaidPaymentDashBoardVO yearData = (McaidPaymentDashBoardVO) yearDataList.get(yearIndex);	            	 
	            	 index++;
	                 row = sheet.createRow(index);
	                 
	                 cell = row.createCell((short) 0);            
	                 PbpPeriod = new HSSFRichTextString(yearData.getYear());
	                 cell.setCellValue(PbpPeriod.toString());
	                 cell = row.createCell((short) 1);
	                 statePaid = new HSSFRichTextString(yearData.getCmsPaid());
	                 cell.setCellValue(statePaid.toString());
	                 cell = row.createCell((short) 2);
	                 planExpected = new HSSFRichTextString(yearData.getPlanExpected());
	                 cell.setCellValue(planExpected.toString());
	                 cell = row.createCell((short) 3);
	                 difference = new HSSFRichTextString(yearData.getDiffrence());
	                 cell.setCellValue(difference.toString());	                            	
	            	
	               //QTR-START
	                 List qtrDataList = yearData.getPbpYrOrQtrOrMonLst();
	                 if(qtrDataList != null){//qtrIf
	     	            for (int qtrIndex = 0; qtrIndex < qtrDataList.size(); qtrIndex++) {
	     	            	McaidPaymentDashBoardVO qtrData = (McaidPaymentDashBoardVO) qtrDataList.get(qtrIndex);	            	 
	     	            	 index++;
	     	                 row = sheet.createRow(index);
	     	                 
	     	                 cell = row.createCell((short) 0);            
	     	                 PbpPeriod = new HSSFRichTextString(qtrData.getQuarter());	     	                
		   	                 cell.setCellValue(PbpPeriod.toString());
		   	                 cell = row.createCell((short) 1);
		   	                 statePaid = new HSSFRichTextString(qtrData.getCmsPaid());
		   	                 cell.setCellValue(statePaid.toString());
		   	                 cell = row.createCell((short) 2);
		   	                 planExpected = new HSSFRichTextString(qtrData.getPlanExpected());
		   	                 cell.setCellValue(planExpected.toString());
		   	                 cell = row.createCell((short) 3);
		   	                 difference = new HSSFRichTextString(qtrData.getDiffrence());
		   	                 cell.setCellValue(difference.toString());
	     	                 
	     	              //MONTH-START
	    	                 List monthDataList = qtrData.getPbpYrOrQtrOrMonLst();
	    	                 if(monthDataList != null){//monthIf
	    	     	            for (int monthIndex = 0; monthIndex < monthDataList.size(); monthIndex++) {
	    	     	            	McaidPaymentDashBoardVO monthData = (McaidPaymentDashBoardVO) monthDataList.get(monthIndex);	            	 
	    	     	            	 index++;
	    	     	                 row = sheet.createRow(index);
	    	     	                 
	    	     	                 cell = row.createCell((short) 0);            
	    	     	                 PbpPeriod = new HSSFRichTextString(getMonthName(new Integer(monthData.getMonth()).intValue()));	                
									 cell.setCellValue(PbpPeriod.toString());
									 cell = row.createCell((short) 1);
									 statePaid = new HSSFRichTextString(monthData.getCmsPaid());
									 cell.setCellValue(statePaid.toString());
									 cell = row.createCell((short) 2);
									 planExpected = new HSSFRichTextString(monthData.getPlanExpected());
									 cell.setCellValue(planExpected.toString());
									 cell = row.createCell((short) 3);
									 difference = new HSSFRichTextString(monthData.getDiffrence());
									 cell.setCellValue(difference.toString());
	    	     	            	
	    	     	            }//monthFor
	    	                 }//monthIf
	    	                 //MONTH-END
	     	                 
	     	            	
	     	            	
	     	            }//qtrFor
	                 }//qtrIf
	                 //QTR-END
	                 
	            	
	            }//yearFor
            }//yearIf
            //year-END
            
            
        }//pbpFor
        logger.info(LoggerConstants.methodEndLevel());
        return wb;
    }
    
    public HSSFWorkbook createSummaryWorkbook(McaidReconPaymentVO dataVO, List dataList,List dataList1, List dataList2) throws Exception {
    	logger.info(LoggerConstants.methodStartLevel());
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet("Payment Summary");
                
        sheet.setColumnWidth((short)0, (short)6000);
        sheet.setColumnWidth((short)1, (short)6000);
        sheet.setColumnWidth((short)2, (short)6000);
        sheet.setColumnWidth((short)3, (short)6000);
        sheet.setColumnWidth((short)4, (short)6000);
        sheet.setColumnWidth((short)5, (short)6000);
        sheet.setColumnWidth((short)6, (short)6000);
        sheet.setColumnWidth((short)7, (short)6000);
        sheet.setColumnWidth((short)8, (short)6000);
       // sheet.setColumnWidth((short)9, (short)3000);

        /**
         * Style for the header cells.
         */
        HSSFCellStyle headerCellStyle = wb.createCellStyle();
        HSSFFont boldFont = wb.createFont();
        boldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        headerCellStyle.setFont(boldFont);

        //Top Header
        HSSFRow row = sheet.createRow(0);
        HSSFCell cell = row.createCell((short) 0);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Total Payment").toString());
        
        // State Paid and CMS Paid Row
        row = sheet.createRow(2);
        cell = row.createCell((short) 1);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("State Paid").toString());
        cell = row.createCell((short) 2);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Plan Expected").toString());
        cell = row.createCell((short) 3);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Difference").toString());
        
        // Value for State n Plan for Total Payment
        row = sheet.createRow(3);
        cell = row.createCell((short) 1);
        HSSFRichTextString summcmsPaid = new HSSFRichTextString(dataVO.getSummDataCmsPaid());
        cell.setCellValue(summcmsPaid.toString());
        cell = row.createCell((short) 2);
        HSSFRichTextString summplanExpected = new HSSFRichTextString(dataVO.getSummDataPlanExpected());
        cell.setCellValue(summplanExpected.toString());
        cell = row.createCell((short) 3);
        HSSFRichTextString summdifference = new HSSFRichTextString(dataVO.getSummDataDiffrence());
        cell.setCellValue(summdifference.toString());
        
        
        // Total Payment Data Grid 
        row = sheet.createRow(5);
        cell = row.createCell((short) 0);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("PBP").toString());
        cell = row.createCell((short) 1);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("State Paid").toString());
        cell = row.createCell((short) 2);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Plan Expected").toString());
        cell = row.createCell((short) 3);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Difference").toString());
        
        //Values for Total Payment Array Grid   
          
        int index = 5;
        for (int pbpIndex = 0; pbpIndex < dataList.size(); pbpIndex++) {
//            row = sheet.createRow(pbpIndex + 1);            
            McaidPaymentDashBoardVO data = (McaidPaymentDashBoardVO) dataList.get(pbpIndex);                       
            index++;
            row = sheet.createRow(index++);
            //Values for Total Payment Data Grid
            cell = row.createCell((short) 0);
            HSSFRichTextString pbpDesc = new HSSFRichTextString(data.getPbpDesc());
            cell.setCellValue(pbpDesc.toString());
            cell = row.createCell((short) 1);
            HSSFRichTextString cmsPaid = new HSSFRichTextString(data.getCmsPaid());
            cell.setCellValue(cmsPaid.toString());
            cell = row.createCell((short) 2);
            HSSFRichTextString planExpected = new HSSFRichTextString(data.getPlanExpected());
            cell.setCellValue(planExpected.toString());
            cell = row.createCell((short) 3);
            HSSFRichTextString difference = new HSSFRichTextString(data.getDiffrence());
            cell.setCellValue(difference.toString());
            cell = row.createCell((short) 4);
           
            }
        
        
        int newRow = index+2;
        //Payment Details Header
        row = sheet.createRow(newRow);
        cell = row.createCell((short) 0);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Payment Details").toString());
        
        //State and Plan Paid for Details 
        row = sheet.createRow(newRow+2);
        cell = row.createCell((short) 1);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("State Paid").toString());
        cell = row.createCell((short) 2);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Plan Expected").toString());
        cell = row.createCell((short) 3);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Difference").toString());
        
     // Value for State n Plan for Total Payment
        row = sheet.createRow(newRow+3);
        cell = row.createCell((short) 1);
        HSSFRichTextString summDetcmsPaid = new HSSFRichTextString(dataVO.getSummDetailCmsPaid());
        cell.setCellValue(summDetcmsPaid.toString());
        cell = row.createCell((short) 2);
        HSSFRichTextString summDetplanExpected = new HSSFRichTextString(dataVO.getSummDetailPlanExpected());
        cell.setCellValue(summDetplanExpected.toString());
        cell = row.createCell((short) 3);
        HSSFRichTextString summDetdifference = new HSSFRichTextString(dataVO.getSummDetailDiffrence());
        cell.setCellValue(summDetdifference.toString());
        
        // Payment Details Data Grid
        row = sheet.createRow(newRow+5);
        cell = row.createCell((short) 0);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Payment Type").toString());
        cell = row.createCell((short) 1);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Description").toString());
        cell = row.createCell((short) 2);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("State Paid").toString());
        cell = row.createCell((short) 3);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Plan Expected").toString());
        cell = row.createCell((short) 4);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Difference").toString());
        
        index = newRow+5;
        for (int index1 = 0; index1 < dataList1.size(); index1++) {  
            
        McaidPaymentDashBoardVO data1 = (McaidPaymentDashBoardVO)dataList1.get(index1);
         index++;
		 row = sheet.createRow(index);
		 cell = row.createCell((short) 0);
		 HSSFRichTextString pbpId = new HSSFRichTextString(data1.getPbpId());
		 cell.setCellValue(pbpId.toString());
		 cell = row.createCell((short) 1);
		 HSSFRichTextString pbpDesc = new HSSFRichTextString(data1.getPbpDesc());
		 cell.setCellValue(pbpDesc.toString());
 		 cell = row.createCell((short) 2);
         HSSFRichTextString cmsPaid = new HSSFRichTextString(data1.getCmsPaid());
         cell.setCellValue(cmsPaid.toString());
         cell = row.createCell((short) 3);
         HSSFRichTextString planExpected = new HSSFRichTextString(data1.getPlanExpected());
         cell.setCellValue(planExpected.toString());
         cell = row.createCell((short) 4);
         HSSFRichTextString difference = new HSSFRichTextString(data1.getDiffrence());
         cell.setCellValue(difference.toString());
           
   
        }
        
        if(dataList2 != null){
        index = index++; 
         // Medicaid List Header 
        row = sheet.createRow(index++);
        cell = row.createCell((short) 0);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Medicaid Payment Details - "+dataVO.getSummSrchPaymentType()).toString());
        
        //Medicaid List Details 
        row = sheet.createRow(index+2);
        cell = row.createCell((short) 0);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Medicaid").toString());
        
        cell = row.createCell((short) 1);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Effective Date").toString());
        cell = row.createCell((short) 2);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Apply Date").toString());
        cell = row.createCell((short) 3);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("State Paid").toString());
        cell = row.createCell((short) 4);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Plan Expected").toString());
        cell = row.createCell((short) 5);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Difference").toString());
        
        //Valus for Medicaid List
        index = index+2;
        //Font font = FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL, Color.BLACK);
        for (int pbpIndex = 0; pbpIndex < dataList2.size(); pbpIndex++) {
        	
        	McaidPaymentDashBoardVO data1 = (McaidPaymentDashBoardVO) dataList2.get(pbpIndex);
        	index++;
        	 row = sheet.createRow(index);
    		 cell = row.createCell((short) 0);
    		 HSSFRichTextString pbpId = new HSSFRichTextString(data1.getPbpId());
    		 cell.setCellValue(pbpId.toString());
    		 cell = row.createCell((short) 1);
    		 HSSFRichTextString effDate = new HSSFRichTextString(data1.getEffDate());
    		 cell.setCellValue(effDate.toString());
     		 cell = row.createCell((short) 2);
             HSSFRichTextString applDate = new HSSFRichTextString(data1.getApplyDate());
             cell.setCellValue(applDate.toString());
             cell = row.createCell((short) 3);
             HSSFRichTextString cmsPaid = new HSSFRichTextString(data1.getCmsPaid());
             cell.setCellValue(cmsPaid.toString());
             cell = row.createCell((short) 4);
             HSSFRichTextString planExpected = new HSSFRichTextString(data1.getPlanExpected());
             cell.setCellValue(planExpected.toString());
             cell = row.createCell((short) 5);
             HSSFRichTextString difference = new HSSFRichTextString(data1.getDiffrence());
             cell.setCellValue("");
             
        }
        }
        sheet.autoSizeColumn((short)0);
        sheet.autoSizeColumn((short)1);
        sheet.autoSizeColumn((short)2);
        sheet.autoSizeColumn((short)3);
        sheet.autoSizeColumn((short)4);
        sheet.autoSizeColumn((short)5);
        sheet.autoSizeColumn((short)6);
        sheet.autoSizeColumn((short)7);
        sheet.autoSizeColumn((short)8);
        
        logger.info(LoggerConstants.methodEndLevel());
        return wb;
    	
    }//createSummaryWorkbook()
    
    
    
    public HSSFWorkbook createAllPymtSummaryWorkbook(McaidReconPaymentVO dataVO,List dataList,List dataList1, List dataList2) throws Exception {
    	logger.info(LoggerConstants.methodStartLevel());
    	  HSSFWorkbook wb = new HSSFWorkbook();
          HSSFSheet sheet = wb.createSheet("Payment Summary");
                  
          sheet.setColumnWidth((short)0, (short)6000);
          sheet.setColumnWidth((short)1, (short)6000);
          sheet.setColumnWidth((short)2, (short)6000);
          sheet.setColumnWidth((short)3, (short)6000);
          sheet.setColumnWidth((short)4, (short)6000);
          sheet.setColumnWidth((short)5, (short)6000);
          sheet.setColumnWidth((short)6, (short)6000);
          sheet.setColumnWidth((short)7, (short)6000);
          sheet.setColumnWidth((short)8, (short)6000);
         // sheet.setColumnWidth((short)9, (short)3000);

          /**
           * Style for the header cells.
           */
          HSSFCellStyle headerCellStyle = wb.createCellStyle();
          HSSFFont boldFont = wb.createFont();
          boldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
          headerCellStyle.setFont(boldFont);

          //Top Header
          HSSFRow row = sheet.createRow(0);
          HSSFCell cell = row.createCell((short) 0);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("Total Payment").toString());
          
          // State Paid and CMS Paid Row
          row = sheet.createRow(2);
          cell = row.createCell((short) 1);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("State Paid").toString());
          cell = row.createCell((short) 2);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("Plan Expected").toString());
          cell = row.createCell((short) 3);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("Difference").toString());
          
          // Value for State n Plan for Total Payment
          row = sheet.createRow(3);
          cell = row.createCell((short) 1);
          HSSFRichTextString summcmsPaid = new HSSFRichTextString(dataVO.getSummDataCmsPaid());
          cell.setCellValue(summcmsPaid.toString());
          cell = row.createCell((short) 2);
          HSSFRichTextString summplanExpected = new HSSFRichTextString(dataVO.getSummDataPlanExpected());
          cell.setCellValue(summplanExpected.toString());
          cell = row.createCell((short) 3);
          HSSFRichTextString summdifference = new HSSFRichTextString(dataVO.getSummDataDiffrence());
          cell.setCellValue(summdifference.toString());
          
          
          // Total Payment Data Grid 
          row = sheet.createRow(5);
          cell = row.createCell((short) 0);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("PBP").toString());
          cell = row.createCell((short) 1);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("State Paid").toString());
          cell = row.createCell((short) 2);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("Plan Expected").toString());
          cell = row.createCell((short) 3);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("Difference").toString());
          
          //Values for Total Payment Array Grid   
            
          int index = 5;
          for (int pbpIndex = 0; pbpIndex < dataList.size(); pbpIndex++) {
//              row = sheet.createRow(pbpIndex + 1);            
              McaidPaymentDashBoardVO data = (McaidPaymentDashBoardVO) dataList.get(pbpIndex);                       
              index++;
              row = sheet.createRow(index++);
              //Values for Total Payment Data Grid
              cell = row.createCell((short) 0);
              HSSFRichTextString pbpDesc = new HSSFRichTextString(data.getPbpDesc());
              cell.setCellValue(pbpDesc.toString());
              cell = row.createCell((short) 1);
              HSSFRichTextString cmsPaid = new HSSFRichTextString(data.getCmsPaid());
              cell.setCellValue(cmsPaid.toString());
              cell = row.createCell((short) 2);
              HSSFRichTextString planExpected = new HSSFRichTextString(data.getPlanExpected());
              cell.setCellValue(planExpected.toString());
              cell = row.createCell((short) 3);
              HSSFRichTextString difference = new HSSFRichTextString(data.getDiffrence());
              cell.setCellValue(difference.toString());
              cell = row.createCell((short) 4);
             
              }
          
          
          int newRow = index+2;
          //Payment Details Header
          row = sheet.createRow(newRow);
          cell = row.createCell((short) 0);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("Payment Details").toString());
          
          //State and Plan Paid for Details 
          row = sheet.createRow(newRow+2);
          cell = row.createCell((short) 1);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("State Paid").toString());
          cell = row.createCell((short) 2);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("Plan Expected").toString());
          cell = row.createCell((short) 3);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("Difference").toString());
          
       // Value for State n Plan for Total Payment
          row = sheet.createRow(newRow+3);
          cell = row.createCell((short) 1);
          HSSFRichTextString summDetcmsPaid = new HSSFRichTextString(dataVO.getSummDetailCmsPaid());
          cell.setCellValue(summDetcmsPaid.toString());
          cell = row.createCell((short) 2);
          HSSFRichTextString summDetplanExpected = new HSSFRichTextString(dataVO.getSummDetailPlanExpected());
          cell.setCellValue(summDetplanExpected.toString());
          cell = row.createCell((short) 3);
          HSSFRichTextString summDetdifference = new HSSFRichTextString(dataVO.getSummDetailDiffrence());
          cell.setCellValue(summDetdifference.toString());
          
          // Payment Details Data Grid
          row = sheet.createRow(newRow+5);
          cell = row.createCell((short) 0);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("Payment Type").toString());
          cell = row.createCell((short) 1);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("Description").toString());
          cell = row.createCell((short) 2);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("State Paid").toString());
          cell = row.createCell((short) 3);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("Plan Expected").toString());
          cell = row.createCell((short) 4);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("Difference").toString());
          
          index = newRow+5;
          for (int index1 = 0; index1 < dataList1.size(); index1++) {  
              
          McaidPaymentDashBoardVO data1 = (McaidPaymentDashBoardVO)dataList1.get(index1);
           index++;
  		 row = sheet.createRow(index);
  		 cell = row.createCell((short) 0);
  		 HSSFRichTextString pbpId = new HSSFRichTextString(data1.getPbpId());
  		 cell.setCellValue(pbpId.toString());
  		 cell = row.createCell((short) 1);
  		 HSSFRichTextString pbpDesc = new HSSFRichTextString(data1.getPbpDesc());
  		 cell.setCellValue(pbpDesc.toString());
   		 cell = row.createCell((short) 2);
           HSSFRichTextString cmsPaid = new HSSFRichTextString(data1.getCmsPaid());
           cell.setCellValue(cmsPaid.toString());
           cell = row.createCell((short) 3);
           HSSFRichTextString planExpected = new HSSFRichTextString(data1.getPlanExpected());
           cell.setCellValue(planExpected.toString());
           cell = row.createCell((short) 4);
           HSSFRichTextString difference = new HSSFRichTextString(data1.getDiffrence());
           cell.setCellValue(difference.toString());
             
     
          }
          
          if(dataList2 != null){
          index = index++; 
           // Medicaid List Header 
          row = sheet.createRow(index++);
          cell = row.createCell((short) 0);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("Medicaid Payment Details - "+StringUtil.nonNullTrim(dataVO.getSummSrchPaymentType()).toString()));
          
          //Medicaid List Details 
          row = sheet.createRow(index+2);
          cell = row.createCell((short) 0);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("Medicaid").toString());
          
          cell = row.createCell((short) 1);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("Effective Date").toString());
          cell = row.createCell((short) 2);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("Apply Date").toString());
          cell = row.createCell((short) 3);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("State Paid").toString());
          cell = row.createCell((short) 4);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("Plan Expected").toString());
          cell = row.createCell((short) 5);
          cell.setCellStyle(headerCellStyle);
          cell.setCellValue(new HSSFRichTextString("Difference").toString());
          
          //Valus for Medicaid List
          index = index+2;
          //Font font = FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL, Color.BLACK);
          for (int pbpIndex = 0; pbpIndex < dataList2.size(); pbpIndex++) {
          	
          	McaidPaymentDashBoardVO data1 = (McaidPaymentDashBoardVO) dataList2.get(pbpIndex);
          	index++;
          	 row = sheet.createRow(index);
      		 cell = row.createCell((short) 0);
      		 HSSFRichTextString pbpId = new HSSFRichTextString(data1.getPbpId());
      		 cell.setCellValue(pbpId.toString());
      		 cell = row.createCell((short) 1);
      		 HSSFRichTextString effDate = new HSSFRichTextString(data1.getEffDate());
      		 cell.setCellValue(effDate.toString());
       		 cell = row.createCell((short) 2);
               HSSFRichTextString applDate = new HSSFRichTextString(data1.getApplyDate());
               cell.setCellValue(applDate.toString());
               cell = row.createCell((short) 3);
               HSSFRichTextString cmsPaid = new HSSFRichTextString(data1.getCmsPaid());
               cell.setCellValue(cmsPaid.toString());
               cell = row.createCell((short) 4);
               HSSFRichTextString planExpected = new HSSFRichTextString(data1.getPlanExpected());
               cell.setCellValue(planExpected.toString());
               cell = row.createCell((short) 5);
               HSSFRichTextString difference = new HSSFRichTextString(data1.getDiffrence());
               cell.setCellValue("");
               
          }
          }
          sheet.autoSizeColumn((short)0);
          sheet.autoSizeColumn((short)1);
          sheet.autoSizeColumn((short)2);
          sheet.autoSizeColumn((short)3);
          sheet.autoSizeColumn((short)4);
          sheet.autoSizeColumn((short)5);
          sheet.autoSizeColumn((short)6);
          sheet.autoSizeColumn((short)7);
          sheet.autoSizeColumn((short)8);
          
          logger.info(LoggerConstants.methodEndLevel());
          return wb;
    	
    }//createSummaryWorkbook()
    
    
    private String getMonthName(int monVal){
    	logger.info(LoggerConstants.methodStartLevel());
	 	String[] months = new DateFormatSymbols().getMonths();
	 	logger.info(LoggerConstants.methodEndLevel());
		return months[monVal-1];	 			 	
 	}	
}//class
