package com.ps.mss.businesslogic;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import com.ps.mss.dao.DaoFactory;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.ChartEncounterDao;

import com.ps.mss.dao.model.Enc837ChangeClaimlogVOs;
import com.ps.mss.dao.model.Enc837iBillprvVO;
import com.ps.mss.dao.model.Enc837iBillprvVOs;
import com.ps.mss.dao.model.Enc837iClmAdjustVOs;
import com.ps.mss.dao.model.Enc837iClmAttachmentVOs;
import com.ps.mss.dao.model.Enc837iClmCondVOs;
import com.ps.mss.dao.model.Enc837iClmErrorVOs;
import com.ps.mss.dao.model.Enc837iClmExtinjVOs;
import com.ps.mss.dao.model.Enc837iClmNotesVOs;
import com.ps.mss.dao.model.Enc837iClmOccurVOs;
import com.ps.mss.dao.model.Enc837iClmOccurspanVOs;
import com.ps.mss.dao.model.Enc837iClmOthdiagVOs;
import com.ps.mss.dao.model.Enc837iClmOthprocVOs;
import com.ps.mss.dao.model.Enc837iClmOthsubsVO;
import com.ps.mss.dao.model.Enc837iClmOthsubsVOs;
import com.ps.mss.dao.model.Enc837iClmProviderVO;
import com.ps.mss.dao.model.Enc837iClmProviderVOs;
import com.ps.mss.dao.model.Enc837iClmStatlogVO;
import com.ps.mss.dao.model.Enc837iClmTreatVOs;
import com.ps.mss.dao.model.Enc837iClmVO;
import com.ps.mss.dao.model.Enc837iClmVOs;
import com.ps.mss.dao.model.Enc837iClmValueVOs;
import com.ps.mss.dao.model.Enc837iClmlineAdjudVOs;
import com.ps.mss.dao.model.Enc837iClmlineAdjustVOs;
import com.ps.mss.dao.model.Enc837iClmlineAttachmentVOs;
import com.ps.mss.dao.model.Enc837iClmlineProviderVOs;
import com.ps.mss.dao.model.Enc837iClmlineVOs;
import com.ps.mss.dao.model.Enc837iOthsubsProviderVOs;
import com.ps.mss.dao.model.Enc837iSubsVO;
import com.ps.mss.dao.model.Enc837iSubsVOs;
import com.ps.mss.dao.model.Enc837pBillprvVOs;
import com.ps.mss.dao.model.Enc837pClmOthsubsVO;
import com.ps.mss.dao.model.Enc837pClmProviderVO;
import com.ps.mss.dao.model.Enc837pClmStatlogVOs;
import com.ps.mss.dao.model.Enc837pSubsVOs;
import com.ps.mss.dao.model.EncErrorstatSumVOs;

import com.ps.mss.dao.model.Enc837pBillprvVO;
import com.ps.mss.dao.model.Enc837pClmAdjustVOs;
import com.ps.mss.dao.model.Enc837pClmAttachmentVOs;
import com.ps.mss.dao.model.Enc837pClmCondVOs;
import com.ps.mss.dao.model.Enc837pClmErrorVOs;
import com.ps.mss.dao.model.Enc837pClmOthdiagVOs;
import com.ps.mss.dao.model.Enc837pClmOthsubsVOs;
import com.ps.mss.dao.model.Enc837pClmProviderVOs;
import com.ps.mss.dao.model.Enc837pClmStatlogVO;
import com.ps.mss.dao.model.Enc837pClmVO;
import com.ps.mss.dao.model.Enc837pClmVOs;
import com.ps.mss.dao.model.Enc837pClmlineAdjudVOs;
import com.ps.mss.dao.model.Enc837pClmlineAdjustVOs;
import com.ps.mss.dao.model.Enc837pClmlineAttachmentVOs;
import com.ps.mss.dao.model.Enc837pClmlineDocVOs;
import com.ps.mss.dao.model.Enc837pClmlineProviderVOs;
import com.ps.mss.dao.model.Enc837pClmlineReferralVOs;
import com.ps.mss.dao.model.Enc837pClmlineVOs;
import com.ps.mss.dao.model.Enc837pOthsubsProviderVOs;
import com.ps.mss.dao.model.Enc837pSubsVO;

import com.ps.mss.dao.model.EncCmstatSumVOs;

import com.ps.mss.exception.ApplicationException;
import com.ps.mss.framework.ChartConstants;
import com.ps.mss.model.HPEContext;
import com.ps.mss.model.HPEEncounterVO;
import com.ps.mss.model.Pagination;

import com.ps.util.StringUtil;

/**
 * @author Douglas Parker
 */
public class ChartEncounterService {
	private static Logger logger=LoggerFactory.getLogger(ChartEncounterService.class);
	
	public void searchStatusSummaryByDateRange(Connection conn, HPEEncounterVO encounterVO)
		throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Retrieve DAO
			ChartEncounterDao ChartEncounterDao = DaoFactory.getInstance().getChartEncounterDao();

			// Search
			EncCmstatSumVOs searchSummaryResults = ChartEncounterDao.searchStatusSummaryByDateRange(conn, encounterVO.getMfId(), encounterVO.getSearchSummarySubmitterId(),encounterVO.getSearchSummaryDateInd(), encounterVO.getSearchSummaryFromDate(), encounterVO.getSearchSummaryToDate(),encounterVO.getSearchSummaryClmType());
			encounterVO.setSearchSummaryResults(searchSummaryResults);
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException("Exception searching", e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return;
	}
	public void searchErrorStatSummaryByDateRange(Connection conn, HPEEncounterVO encounterVO)
	throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Retrieve DAO
			ChartEncounterDao ChartEncounterDao = DaoFactory.getInstance().getChartEncounterDao();
	
			// Search
			EncErrorstatSumVOs  searchSummaryResults = ChartEncounterDao.searchErrorStatSummaryByDateRange(conn, encounterVO.getMfId(), encounterVO.getSearchSummarySubmitterId(), encounterVO.getSearchSummaryDateInd(), encounterVO.getSearchSummaryFromDate(), encounterVO.getSearchSummaryToDate(),encounterVO.getSearchSummaryClmType());
			encounterVO.setSearchErrorSummaryResults(searchSummaryResults);
			
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException("Exception searching", e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return;
	}

	public void selectClaimsBySearchCriteria(Connection conn, HPEEncounterVO encounterVO, Pagination claimDetailPagination, String move,String oldStatus)
		throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Retrieve DAO
			ChartEncounterDao ChartEncounterDao = DaoFactory.getInstance().getChartEncounterDao();

			// Parameters
			String mfId = encounterVO.getMfId();
			String submitterId = encounterVO.getSearchDetailSubmitterId();
			String clmType = encounterVO.getSearchDetailClmType();
			String encType = encounterVO.getSearchDetailEncType();
			String dateInd = encounterVO.getSearchDetailDateInd();
			String fromDate = encounterVO.getSearchDetailFromDate();
			String toDate = encounterVO.getSearchDetailToDate();
			String claimRefNbr = StringUtil.nonNullTrim(encounterVO.getSearchDetailClaimRefNbr());
			String hicNbr = StringUtil.nonNullTrim(encounterVO.getSearchDetailHicNbr());
			String groupStatus = StringUtil.nonNullTrim(encounterVO.getSearchDetailGroupStatus());
			String errorSource = encounterVO.getSearchDetailErrorSource();
			String errorGroup = encounterVO.getSearchDetailErrorGroup();
			String errorCode = encounterVO.getSearchDetailErrorCode();
			
			//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : Start
			String maoflag = encounterVO.getMaoflag();
			//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : End
			
			//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - Start
			String payerSecId = encounterVO.getSearchPayerSecId();
			String subsGrpOrPolNbr = encounterVO.getSearchSubsGrpOrPolNbr();
			//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria - End
			//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
			String vanTanNumber = encounterVO.getSearchVanTanNumber();
			//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
			
			//Traverse CR from file tracking to chart management
			String origFileId = encounterVO.getOrigIntrchgCtrlNbr();

			// Search
			if (encType.equals("I")) {
				//FileTrack code starts
				if(encounterVO.isFileTrackFlag()){
					Enc837iClmVOs instClaims = null;
					origFileId = encounterVO.getOrigIntrchgCtrlNbr();
					instClaims = ChartEncounterDao.selectInstClaimsByCriteriaByFileTrack(conn, claimDetailPagination, move, mfId, submitterId, dateInd, fromDate, toDate, claimRefNbr, hicNbr, groupStatus, errorSource,errorGroup,errorCode,oldStatus,clmType,origFileId);				
					encounterVO.setInstClaims(instClaims);
				}//FileTrack code ends
				else{
					Enc837iClmVOs instClaims = null;
					//instClaims = ChartEncounterDao.selectInstClaimsByCriteria(conn, claimDetailPagination, move, mfId, submitterId, dateInd, fromDate, toDate, claimRefNbr, hicNbr, groupStatus, errorSource,errorGroup,errorCode,oldStatus,clmType);
					//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
					
					//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : Start
					instClaims = ChartEncounterDao.selectInstClaimsByCriteria(conn, claimDetailPagination, move, mfId, submitterId, dateInd, fromDate, toDate, claimRefNbr, vanTanNumber, hicNbr, groupStatus, errorSource,errorGroup,errorCode,oldStatus,clmType, maoflag, payerSecId, subsGrpOrPolNbr);	//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria
					//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : End
					
					//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
					encounterVO.setInstClaims(instClaims);
				}
			}
			else
			if (encType.equals("P") || encType.equals("E")) {   //DME_Dashboard_changes
				//FileTrack code starts
				if(encounterVO.isFileTrackFlag()){
					Enc837pClmVOs profClaims = null;
					origFileId = encounterVO.getOrigIntrchgCtrlNbr();
					profClaims = ChartEncounterDao.selectProfClaimsByCriteriaByFileTrack(conn, claimDetailPagination, move, mfId, submitterId, dateInd, fromDate, toDate, claimRefNbr, hicNbr, groupStatus,errorSource,errorGroup,errorCode,oldStatus,clmType,origFileId);
					encounterVO.setProfClaims(profClaims);
				}//FileTrack code ends
				else{
					Enc837pClmVOs profClaims = null;
					//profClaims = ChartEncounterDao.selectProfClaimsByCriteria(conn, claimDetailPagination, move, mfId, submitterId, dateInd, fromDate, toDate, claimRefNbr, hicNbr, groupStatus,errorSource,errorGroup,errorCode,oldStatus,clmType);
					//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
					
					//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : Start
					profClaims = ChartEncounterDao.selectProfClaimsByCriteria(conn, claimDetailPagination, move, mfId, submitterId, dateInd, fromDate, toDate, claimRefNbr, vanTanNumber, hicNbr, groupStatus,errorSource,errorGroup,errorCode,oldStatus,clmType,encType, maoflag, payerSecId, subsGrpOrPolNbr);	//IFOX-00418232 - Add CMS Contract # and Network (Group Policy # in UI) to the search criteria
					//** IFOX-00403428 ** - (Include MAO004 field in EDS Portal) : End
					
					//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
					encounterVO.setProfClaims(profClaims);
				}
			}
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException("Exception selecting", e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return;
	}

	//
	// Claim data
	//

	public void selectClaim(Connection conn, HPEEncounterVO encounterVO)
		throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {

			encounterVO.setInstClaim(null);
			encounterVO.setInstClaimErrors(null);

			// Retrieve DAO
			ChartEncounterDao ChartEncounterDao = DaoFactory.getInstance().getChartEncounterDao();

			// Parameters
			String mfId = encounterVO.getMfId();
			String claimType = encounterVO.getSelectedClaimType();
			String claimRefNbr = encounterVO.getSelectedClaimRefNbr();
			int claimRevNbr = encounterVO.getSelectedClaimRevNbr();
			int claimSeqNbr = encounterVO.getSelectedClaimSeqNbr();
			String clmType = encounterVO.getSearchDetailClmType();
			String clmStatusExclude = "IGN";			

			// Select
			if (claimType.equals("I")) {
				Enc837iClmVOs instClaims = ChartEncounterDao.selectInstClaims(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837iClmVO instClaim = null;
				if (instClaims != null) {
					if (instClaims.size()>0) {
						instClaim = (Enc837iClmVO)instClaims.get(0);
					}
					
				}
				
				Enc837iClmErrorVOs instClaimErrors = ChartEncounterDao.selectInstClaimErrors(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				String intrchgSndrId = "";
				String prodTestInd = "";
				String intrchgCtrlNbr = "";
				String txnSetCtrlNbr = "";
				String billPrvHrchyId = "";
				String billPrvAffilTaxId = "";				
				String subsHrchyId = "";
				String subsHicNbr = "";				
				
				if (instClaim != null) {
					intrchgSndrId = instClaim.getInIntrchgSndrId();
					prodTestInd = instClaim.getProdTestInd();
					intrchgCtrlNbr = instClaim.getInIntrchgCtrlNbr();
					txnSetCtrlNbr = instClaim.getInTxnSetCtrlNbr();
					billPrvHrchyId = instClaim.getInBillPrvHrchyId();
					billPrvAffilTaxId = instClaim.getInBillPrvAffilTaxId();
					subsHrchyId = instClaim.getInSubsHrchyId();
					subsHicNbr = instClaim.getSubsHicNbr();
				}				
				
				//Enc837iSubsVO instSubscriber = (Enc837iSubsVO) ChartEncounterDao.selectInstSubscribers(conn, mfId, intrchgSndrId, prodTestInd, intrchgCtrlNbr, txnSetCtrlNbr, billPrvHrchyId, billPrvAffilTaxId,  subsHrchyId, subsHicNbr).get(0);
				Enc837iSubsVOs instSubscribers = ChartEncounterDao.selectInstSubscribers(conn, mfId, intrchgSndrId, prodTestInd, intrchgCtrlNbr, txnSetCtrlNbr, billPrvHrchyId, billPrvAffilTaxId, subsHrchyId, subsHicNbr);
				Enc837iSubsVO instSubscriber = null;
				if(instSubscribers != null){
					if(instSubscribers.size() > 0){
						instSubscriber = (Enc837iSubsVO)instSubscribers.get(0);
					}
				}
				
				//Enc837iBillprvVO instBillingProvider = (Enc837iBillprvVO) ChartEncounterDao.selectInstBillingProviders(conn, mfId, intrchgSndrId, prodTestInd, intrchgCtrlNbr, txnSetCtrlNbr, billPrvHrchyId, billPrvAffilTaxId).get(0);
				Enc837iBillprvVOs instBillingProviders = ChartEncounterDao.selectInstBillingProviders(conn, mfId, intrchgSndrId, prodTestInd, intrchgCtrlNbr, txnSetCtrlNbr, billPrvHrchyId, billPrvAffilTaxId);
				Enc837iBillprvVO instBillingProvider = null;
				if(instBillingProviders != null){
					if(instBillingProviders.size() > 0){
						instBillingProvider = (Enc837iBillprvVO)instBillingProviders.get(0);
					}
				}
				
				Enc837iClmAdjustVOs instClaimAdjustments = ChartEncounterDao.selectInstClaimAdjustments(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837iClmAttachmentVOs instClaimAttachments = ChartEncounterDao.selectInstClaimAttachments(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837iClmCondVOs instClaimConditions = ChartEncounterDao.selectInstClaimConditions(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837iClmOccurVOs instClaimOccurrences = ChartEncounterDao.selectInstClaimOccurrences(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837iClmOccurspanVOs instClaimOccurrenceSpans = ChartEncounterDao.selectInstClaimOccurrenceSpans(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837iClmValueVOs instClaimValues = ChartEncounterDao.selectInstClaimValues(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);				
				Enc837iClmOthdiagVOs instClaimOtherDiagnoses = ChartEncounterDao.selectInstClaimOtherDiagnoses(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,instClaim,clmType);				
				Enc837iClmOthprocVOs instClaimOtherProcedures = ChartEncounterDao.selectInstClaimOtherProcedures(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,instClaim,clmType);
				Enc837iClmTreatVOs instClaimTreatments = ChartEncounterDao.selectInstClaimTreatments(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837iClmExtinjVOs instClaimExternalInjuries = ChartEncounterDao.selectInstClaimExternalInjuries(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837iClmProviderVOs instClaimProviders = ChartEncounterDao.selectInstClaimProviders(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837iClmOthsubsVOs instClaimOtherSubscribers = ChartEncounterDao.selectInstClaimOtherSubscribers(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837iOthsubsProviderVOs instClaimOtherSubscriberProviders = ChartEncounterDao.selectInstClaimOtherSubscriberProviders(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837iClmlineVOs instClaimLines = ChartEncounterDao.selectInstClaimLines(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837iClmlineProviderVOs instClaimLineProviders = ChartEncounterDao.selectInstClaimLineProviders(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837iClmlineAttachmentVOs instClaimLineAttachments = ChartEncounterDao.selectInstClaimLineAttachments(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837iClmlineAdjudVOs instClaimLineAdjudications = ChartEncounterDao.selectInstClaimLineAdjudications(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837iClmlineAdjustVOs instClaimLineAdjustments = ChartEncounterDao.selectInstClaimLineAdjustments(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837iClmNotesVOs instClaimNotes = ChartEncounterDao.selectInstClaimNotes(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				//Enc837iClmStatlogVO instClmStatlog = (Enc837iClmStatlogVO) ChartEncounterDao.selectInstClmStatlog(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr, clmStatusExclude).get(0);
			    
				encounterVO.setInstClaim(instClaim);
				encounterVO.setInstClaimErrors(instClaimErrors);
				encounterVO.setInstSubscriber(instSubscriber);
				encounterVO.setInstBillingProvider(instBillingProvider);
				encounterVO.setInstClaimAdjustments(instClaimAdjustments);
				encounterVO.setInstClaimAttachments(instClaimAttachments);
				encounterVO.setInstClaimConditions(instClaimConditions);
				encounterVO.setInstClaimOccurrences(instClaimOccurrences);
				encounterVO.setInstClaimOccurrenceSpans(instClaimOccurrenceSpans);
				encounterVO.setInstClaimValues(instClaimValues);
				encounterVO.setInstClaimOtherDiagnoses(instClaimOtherDiagnoses);
				encounterVO.setInstClaimOtherProcedures(instClaimOtherProcedures);
				encounterVO.setInstClaimTreatments(instClaimTreatments);
				encounterVO.setInstClaimExternalInjuries(instClaimExternalInjuries);
				encounterVO.setInstClaimProviders(instClaimProviders);
				encounterVO.setInstClaimOtherSubscribers(instClaimOtherSubscribers);
				encounterVO.setInstClaimOtherSubscriberProviders(instClaimOtherSubscriberProviders);
				encounterVO.setInstClaimLines(instClaimLines);
				encounterVO.setInstClaimLineProviders(instClaimLineProviders);
				encounterVO.setInstClaimLineAttachments(instClaimLineAttachments);
				encounterVO.setInstClaimLineAdjudications(instClaimLineAdjudications);
				encounterVO.setInstClaimLineAdjustments(instClaimLineAdjustments);
				encounterVO.setInstClaimNotes(instClaimNotes);
				//encounterVO.setInstClmStatlog(instClmStatlog);
			}
			else
			if (claimType.equals("P")) {
				//Enc837pClmVO profClaim = (Enc837pClmVO) ChartEncounterDao.selectProfClaims(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr).get(0);				
				Enc837pClmVOs profClaims = ChartEncounterDao.selectProfClaims(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837pClmVO profClaim = null;
				if (profClaims != null) {
					if (profClaims.size()>0) {
						profClaim = (Enc837pClmVO)profClaims.get(0);
					}
					
				}
				Enc837pClmErrorVOs profClaimErrors = ChartEncounterDao.selectProfClaimErrors(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);

				String intrchgSndrId = "";
				String prodTestInd = "";
				String intrchgCtrlNbr = "";
				String txnSetCtrlNbr = "";
				String billPrvHrchyId = "";
				String billPrvAffilTaxId = "";				
				String subsHrchyId = "";
				String subsHicNbr = "";				
				
				if(profClaim != null){
					intrchgSndrId = profClaim.getInIntrchgSndrId();
					prodTestInd = profClaim.getProdTestInd();
					intrchgCtrlNbr = profClaim.getInIntrchgCtrlNbr();
					txnSetCtrlNbr = profClaim.getInTxnSetCtrlNbr();
					billPrvHrchyId = profClaim.getInBillPrvHrchyId();
					billPrvAffilTaxId = profClaim.getInBillPrvAffilTaxId();					
					subsHrchyId = profClaim.getInSubsHrchyId();
					subsHicNbr = profClaim.getSubsHicNbr();					
				}				

				//Enc837pSubsVO profSubscriber = (Enc837pSubsVO) ChartEncounterDao.selectProfSubscribers(conn, mfId, intrchgSndrId, prodTestInd, intrchgCtrlNbr, txnSetCtrlNbr, billPrvHrchyId, billPrvAffilTaxId, subsHrchyId, subsHicNbr).get(0);
				Enc837pSubsVOs profSubscribers = ChartEncounterDao.selectProfSubscribers(conn, mfId, intrchgSndrId, prodTestInd, intrchgCtrlNbr, txnSetCtrlNbr, billPrvHrchyId, billPrvAffilTaxId, subsHrchyId, subsHicNbr);
				Enc837pSubsVO profSubscriber = null;
				if(profSubscribers != null){
					if(profSubscribers.size() > 0){
						profSubscriber = (Enc837pSubsVO)profSubscribers.get(0);
					}
				}
				
				//Enc837pBillprvVO profBillingProvider = (Enc837pBillprvVO) ChartEncounterDao.selectProfBillingProviders(conn, mfId, intrchgSndrId, prodTestInd, intrchgCtrlNbr, txnSetCtrlNbr, billPrvHrchyId, billPrvAffilTaxId).get(0);				
				Enc837pBillprvVOs profBillingProviders = ChartEncounterDao.selectProfBillingProviders(conn, mfId, intrchgSndrId, prodTestInd, intrchgCtrlNbr, txnSetCtrlNbr, billPrvHrchyId, billPrvAffilTaxId);
				Enc837pBillprvVO profBillingProvider = null;
				if(profBillingProviders != null){
					if(profBillingProviders.size() > 0){
						profBillingProvider = (Enc837pBillprvVO)profBillingProviders.get(0);
					}
				}

				Enc837pClmAdjustVOs profClaimAdjustments = ChartEncounterDao.selectProfClaimAdjustments(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837pClmAttachmentVOs profClaimAttachments = ChartEncounterDao.selectProfClaimAttachments(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837pClmCondVOs profClaimConditions = ChartEncounterDao.selectProfClaimConditions(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837pClmOthdiagVOs profClaimOtherDiagnoses = ChartEncounterDao.selectProfClaimOtherDiagnoses(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837pClmProviderVOs profClaimProviders = ChartEncounterDao.selectProfClaimProviders(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837pClmOthsubsVOs profClaimOtherSubscribers = ChartEncounterDao.selectProfClaimOtherSubscribers(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837pOthsubsProviderVOs profClaimOtherSubscriberProviders = ChartEncounterDao.selectProfClaimOtherSubscriberProviders(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837pClmlineVOs profClaimLines = ChartEncounterDao.selectProfClaimLines(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837pClmlineProviderVOs profClaimLineProviders = ChartEncounterDao.selectProfClaimLineProviders(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837pClmlineAttachmentVOs profClaimLineAttachments = ChartEncounterDao.selectProfClaimLineAttachments(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837pClmlineReferralVOs profClaimLineReferrals = ChartEncounterDao.selectProfClaimLineReferrals(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837pClmlineDocVOs profClaimLineDocuments = ChartEncounterDao.selectProfClaimLineDocuments(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837pClmlineAdjudVOs profClaimLineAdjudications = ChartEncounterDao.selectProfClaimLineAdjudications(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				Enc837pClmlineAdjustVOs profClaimLineAdjustments = ChartEncounterDao.selectProfClaimLineAdjustments(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				
				/*
				 * Changed this logic to make it work
				 */
				Enc837pClmStatlogVOs enc837pClmStatlogVOs = ChartEncounterDao.selectProfClmStatlog(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr, clmStatusExclude,clmType);
				Enc837pClmStatlogVO profClmStatlog = null;
				if (enc837pClmStatlogVOs.size() > 0){
					profClmStatlog = (Enc837pClmStatlogVO) enc837pClmStatlogVOs.get(0);
				}
				
				encounterVO.setProfClaim(profClaim);
				encounterVO.setProfClaimErrors(profClaimErrors);
				encounterVO.setProfSubscriber(profSubscriber);
				encounterVO.setProfBillingProvider(profBillingProvider);
				encounterVO.setProfClaimAdjustments(profClaimAdjustments);
				encounterVO.setProfClaimAttachments(profClaimAttachments);
				encounterVO.setProfClaimConditions(profClaimConditions);
				encounterVO.setProfClaimOtherDiagnoses(profClaimOtherDiagnoses);
				encounterVO.setProfClaimProviders(profClaimProviders);
				encounterVO.setProfClaimOtherSubscribers(profClaimOtherSubscribers);
				encounterVO.setProfClaimOtherSubscriberProviders(profClaimOtherSubscriberProviders);
				encounterVO.setProfClaimLines(profClaimLines);
				encounterVO.setProfClaimLineProviders(profClaimLineProviders);
				encounterVO.setProfClaimLineAttachments(profClaimLineAttachments);
				encounterVO.setProfClaimLineReferrals(profClaimLineReferrals);
				encounterVO.setProfClaimLineDocuments(profClaimLineDocuments);
				encounterVO.setProfClaimLineAdjudications(profClaimLineAdjudications);
				encounterVO.setProfClaimLineAdjustments(profClaimLineAdjustments);
				encounterVO.setProfClmStatlog(profClmStatlog);				
			}
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception: "+ e.getMessage());
			throw new ApplicationException("Exception searching", e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return;
	}
	
	public void refreshUpdatedInst(Connection conn, HPEEncounterVO encounterVO) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		try {

			// Retrieve DAO
			ChartEncounterDao ChartEncounterDao = new ChartEncounterDao();

			// Parameters
			String mfId = encounterVO.getMfId();
			String claimRefNbr = encounterVO.getSelectedClaimRefNbr();
			int claimRevNbr = encounterVO.getSelectedClaimRevNbr();
			int claimSeqNbr = encounterVO.getSelectedClaimSeqNbr();	
			String clmType = encounterVO.getSearchDetailClmType();

			Enc837iClmVO instClaim = null;		
			if (encounterVO.isInstClaimDirty()) {
				Enc837iClmVOs instClaims = ChartEncounterDao.selectInstClaims(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				if (instClaims.size() != 1) {
					throw new Exception();
				}
				instClaim = (Enc837iClmVO)instClaims.get(0);
			} else {
				instClaim = encounterVO.getInstClaim();
			}
			
			String intrchgSndrId = instClaim.getInIntrchgSndrId();
			String prodTestInd = instClaim.getProdTestInd();
			String intrchgCtrlNbr = instClaim.getInIntrchgCtrlNbr();
			String txnSetCtrlNbr = instClaim.getInTxnSetCtrlNbr();
			String billPrvHrchyId = instClaim.getInBillPrvHrchyId();
			String billPrvAffilTaxId = instClaim.getInBillPrvAffilTaxId();

			Enc837iSubsVO instSubscriber = null;
			if (encounterVO.isInstSubsDirty()) {
				Enc837iSubsVOs instSubscribers = ChartEncounterDao.selectInstSubscribers(conn, mfId,intrchgSndrId,prodTestInd,intrchgCtrlNbr,txnSetCtrlNbr,
													billPrvHrchyId,billPrvAffilTaxId,instClaim.getInSubsHrchyId(), instClaim.getSubsHicNbr());
				
				if(instSubscribers == null) {
					throw new Exception();
				}
				if(instSubscribers.size() != 1){
					throw new Exception();
				}
				instSubscriber = (Enc837iSubsVO)instSubscribers.get(0);
			} else {
				instSubscriber = encounterVO.getInstSubscriber();
			}
			
			Enc837iClmOthsubsVOs instClaimOtherSubscribers = null;
			if (encounterVO.isInstOthSubsDirty()) {
				instClaimOtherSubscribers = ChartEncounterDao.selectInstClaimOtherSubscribers(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
			} else {
				instClaimOtherSubscribers = encounterVO.getInstClaimOtherSubscribers();
			}
			
			Enc837iBillprvVO instBillingProvider = null;
			if (encounterVO.isInstBillPrvDirty()) {
				Enc837iBillprvVOs instBillingProviders = ChartEncounterDao.selectInstBillingProviders(conn, mfId, intrchgSndrId, prodTestInd, intrchgCtrlNbr, txnSetCtrlNbr, billPrvHrchyId, billPrvAffilTaxId);
				if(instBillingProviders == null) {
					throw new Exception();
				}
				if(instBillingProviders.size() != 1){
					throw new Exception();
				}				
				instBillingProvider = (Enc837iBillprvVO)instBillingProviders.get(0);
				
			}else {
				instBillingProvider = encounterVO.getInstBillingProvider();
			}
			
			Enc837iClmProviderVOs instClaimProviders = null;
			if (encounterVO.isInstClmPrvDirty()) {
				instClaimProviders = ChartEncounterDao.selectInstClaimProviders(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
			}else {
				instClaimProviders = encounterVO.getInstClaimProviders();
			}	
			//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
			Enc837iClmlineVOs instClmline = null;
			if (encounterVO.isInstClmLineDirty()) {
				instClmline = ChartEncounterDao.selectInstClaimLines(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
			}else {
				instClmline = encounterVO.getInstClaimLines();
			}
			
			Enc837iClmlineAdjudVOs instClmlineAdjud = null;
			if (encounterVO.isInstClmLineAdjudDirty()) {
				instClmlineAdjud = ChartEncounterDao.selectInstClaimLineAdjudications(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
			}else {
				instClmlineAdjud = encounterVO.getInstClaimLineAdjudications();
			}
			//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
				    
			encounterVO.setInstClaim(instClaim);
			encounterVO.setInstSubscriber(instSubscriber);
			encounterVO.setInstClaimOtherSubscribers(instClaimOtherSubscribers);
			encounterVO.setInstClaimProviders(instClaimProviders);
			encounterVO.setInstBillingProvider(instBillingProvider);
			
			Enc837iClmVO tempClaim = null;
			Iterator iterator = encounterVO.getInstClaims().iterator();
			while (iterator.hasNext()) {
				tempClaim = (Enc837iClmVO)iterator.next();
				if (
						((String)tempClaim.getWtxClaimRefNbr()).equals(claimRefNbr) &&
						(int)tempClaim.getWtxClaimRevNbr()          == claimRevNbr  &&
						(int)tempClaim.getClmSeqNbr()               == claimSeqNbr		
				    )
					break;
			}
		
			int i = encounterVO.getInstClaims().indexOf(tempClaim);
				
			tempClaim.setProcessStatus(instClaim.getProcessStatus());
			tempClaim.setSubsHicNbr(instClaim.getSubsHicNbr());
			encounterVO.getInstClaims().remove(i);		
			encounterVO.getInstClaims().add(i,tempClaim);
			
			// Added for Updateable fields change : start
						Enc837iClmCondVOs instClaimConditions = ChartEncounterDao.selectInstClaimConditions(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
						Enc837iClmOthdiagVOs instClaimOtherDiagnoses = ChartEncounterDao.selectInstClaimOtherDiagnoses(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,instClaim,clmType);				
						Enc837iClmOthprocVOs instClaimOtherProcedures = ChartEncounterDao.selectInstClaimOtherProcedures(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,instClaim,clmType);
						Enc837iClmOccurVOs instClaimOccurrences = ChartEncounterDao.selectInstClaimOccurrences(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
						Enc837iClmOccurspanVOs instClaimOccurrenceSpans = ChartEncounterDao.selectInstClaimOccurrenceSpans(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
						Enc837iClmValueVOs instClaimValues = ChartEncounterDao.selectInstClaimValues(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);				
						Enc837iClmTreatVOs instClaimTreatments = ChartEncounterDao.selectInstClaimTreatments(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
						Enc837iClmExtinjVOs instClaimExternalInjuries = ChartEncounterDao.selectInstClaimExternalInjuries(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
						encounterVO.setInstClaimConditions(instClaimConditions);
						encounterVO.setInstClaimOccurrences(instClaimOccurrences);
						encounterVO.setInstClaimOccurrenceSpans(instClaimOccurrenceSpans);
						encounterVO.setInstClaimValues(instClaimValues);
						encounterVO.setInstClaimOtherDiagnoses(instClaimOtherDiagnoses);
						encounterVO.setInstClaimOtherProcedures(instClaimOtherProcedures);
						encounterVO.setInstClaimTreatments(instClaimTreatments);
						encounterVO.setInstClaimExternalInjuries(instClaimExternalInjuries);
						// Added for Updateable fields change : end
						//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
						encounterVO.setInstClaimLines(instClmline);
						encounterVO.setInstClaimLineAdjudications(instClmlineAdjud);
						//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
	
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception: "+ e.getMessage());
			throw new ApplicationException("Exception refreshing", e);
		}
		logger.info(LoggerConstants.methodEndLevel());

	}

	public void refreshUpdatedProf(Connection conn, HPEEncounterVO encounterVO) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		try {

			// Retrieve DAO
			ChartEncounterDao ChartEncounterDao = new ChartEncounterDao();

			// Parameters
			String mfId = encounterVO.getMfId();
			String claimRefNbr = encounterVO.getSelectedClaimRefNbr();
			int claimRevNbr = encounterVO.getSelectedClaimRevNbr();
			int claimSeqNbr = encounterVO.getSelectedClaimSeqNbr();	
			String clmType = encounterVO.getSearchDetailClmType();

			Enc837pClmVO profClaim = null;		
			if (encounterVO.isProfClaimDirty()) {
				Enc837pClmVOs profClaims = ChartEncounterDao.selectProfClaims(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
				if (profClaims.size() != 1) {
					throw new Exception();
				}
				profClaim = (Enc837pClmVO)profClaims.get(0);
			} else {
				profClaim = encounterVO.getProfClaim();
			}
			
			String intrchgSndrId = profClaim.getInIntrchgSndrId();
			String prodTestInd = profClaim.getProdTestInd();
			String intrchgCtrlNbr = profClaim.getInIntrchgCtrlNbr();
			String txnSetCtrlNbr = profClaim.getInTxnSetCtrlNbr();
			String billPrvHrchyId = profClaim.getInBillPrvHrchyId();
			String billPrvAffilTaxId = profClaim.getInBillPrvAffilTaxId();

			Enc837pSubsVO profSubscriber = null;
			if (encounterVO.isProfSubsDirty()) {				
				Enc837pSubsVOs profSubscribers = ChartEncounterDao.selectProfSubscribers(conn, mfId,intrchgSndrId,prodTestInd,intrchgCtrlNbr,txnSetCtrlNbr,
												billPrvHrchyId,billPrvAffilTaxId,profClaim.getInSubsHrchyId(), profClaim.getSubsHicNbr());
				
				if(profSubscribers == null) {
					throw new Exception();
				}
				if(profSubscribers.size() != 1){
					throw new Exception();
				}
				profSubscriber = (Enc837pSubsVO)profSubscribers.get(0);
			} else {
				profSubscriber = encounterVO.getProfSubscriber();
			}
				
			Enc837pClmOthsubsVOs profClaimOtherSubscribers = null;
			if (encounterVO.isProfOthSubsDirty()) {
				profClaimOtherSubscribers = ChartEncounterDao.selectProfClaimOtherSubscribers(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
			} else {
				profClaimOtherSubscribers = encounterVO.getProfClaimOtherSubscribers();
			}
			
			Enc837pBillprvVO profBillingProvider = null;
			if (encounterVO.isProfBillPrvDirty()) {
				Enc837pBillprvVOs profBillingProviders = ChartEncounterDao.selectProfBillingProviders(conn, mfId, intrchgSndrId, prodTestInd, intrchgCtrlNbr, txnSetCtrlNbr, billPrvHrchyId, billPrvAffilTaxId);
				if(profBillingProviders == null) {
					throw new Exception();
				}
				if(profBillingProviders.size() != 1){
					throw new Exception();
				}				
				profBillingProvider = (Enc837pBillprvVO)profBillingProviders.get(0);
				
			}else {
				profBillingProvider = encounterVO.getProfBillingProvider();
			}
			
			Enc837pClmProviderVOs profClaimProviders = null;
			if (encounterVO.isProfClmPrvDirty()) {
				profClaimProviders = ChartEncounterDao.selectProfClaimProviders(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
			}else {
				profClaimProviders = encounterVO.getProfClaimProviders();
			}
					    
			encounterVO.setProfClaim(profClaim);
			encounterVO.setProfSubscriber(profSubscriber);
			encounterVO.setProfClaimOtherSubscribers(profClaimOtherSubscribers);
			encounterVO.setProfClaimProviders(profClaimProviders);
			encounterVO.setProfBillingProvider(profBillingProvider);
			
			
			Enc837pClmVO tempClaim = null;						
			Iterator iterator = encounterVO.getProfClaims().iterator();
			while (iterator.hasNext()) {
				tempClaim = (Enc837pClmVO)iterator.next();
				if (
						((String)tempClaim.getWtxClaimRefNbr()).equals(claimRefNbr) &&
						(int)tempClaim.getWtxClaimRevNbr()          == claimRevNbr  &&
						(int)tempClaim.getClmSeqNbr()               == claimSeqNbr		
				    )
					break;
			}
		
			int i = encounterVO.getProfClaims().indexOf(tempClaim);
				
			tempClaim.setProcessStatus(profClaim.getProcessStatus());
			tempClaim.setSubsHicNbr(profClaim.getSubsHicNbr());
			encounterVO.getProfClaims().remove(i);		
			encounterVO.getProfClaims().add(i,tempClaim);	
			
			//Added for Updateable fields change : start
			Enc837pClmCondVOs profClaimConditions = ChartEncounterDao.selectProfClaimConditions(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
			Enc837pClmOthdiagVOs profClaimOtherDiagnoses = ChartEncounterDao.selectProfClaimOtherDiagnoses(conn, mfId, claimRefNbr, claimRevNbr, claimSeqNbr,clmType);
			
			encounterVO.setProfClaimConditions(profClaimConditions);
			encounterVO.setProfClaimOtherDiagnoses(profClaimOtherDiagnoses);
			//Added for Updateable fields change: end 
		
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("Exception: "+ e.getMessage());
				throw new ApplicationException("Exception searching", e);
		}
		logger.info(LoggerConstants.methodEndLevel());

	}

	public String updateInstSubscriber(Connection conn, HPEEncounterVO encounterVO, Enc837iSubsVO newInstSubs, Enc837iClmVO enc837iClmVO)
			throws Exception {		
		logger.info(LoggerConstants.methodStartLevel());
		String message = "";
		
		// Retrieve DAO
		ChartEncounterDao ChartEncounterDao = new ChartEncounterDao();		

		String mfId = encounterVO.getMfId();
		String userId = encounterVO.getUserId();
		String clmType = encounterVO.getSearchDetailClmType();
		
		//Create Record Key - This is wrong	
		String recordKey = ChartEncounterDao.getClaimChangeLogRecordKey(enc837iClmVO);
		ChartEncounterDao.setClaimDetailString(enc837iClmVO.getWtxClaimRefNbr() + "|" + enc837iClmVO.getWtxClaimRevNbr() + "|" +enc837iClmVO.getClmSeqNbr());
		
		int sqlCnt = -1;

		String fieldName = "";
		String tableName = "ENC_837I_SUBS";
		boolean dataChanged = false;
		
		String newFirstName = newInstSubs.getSubsFirstName();
		String newMiddleName = newInstSubs.getSubsMiddleName();
		String newLastName = newInstSubs.getSubsLastName();
		String newSSN = newInstSubs.getSubsSsn();
		String newAddress1 = newInstSubs.getSubsAddrLine1();
		String newAddress2 = newInstSubs.getSubsAddrLine2();
		String newDob = newInstSubs.getSubsDob();
		String newGender = newInstSubs.getSubsSex();
		String newCity = newInstSubs.getSubsCity();
		String newState = newInstSubs.getSubsState();
		String newZip = newInstSubs.getSubsZip();
		String newSubsHicNbr = newInstSubs.getSubsHicNbr();	
		String newMbi = newInstSubs.getMbi();
		String newBillPrvAffilTaxId = newInstSubs.getBillPrvAffilTaxId();
		
		String newSubsMemberId = newInstSubs.getSubsMemberId();
		String newSubsCountry = newInstSubs.getSubsCountry();
		String newSubsGrpName = newInstSubs.getSubsGrpName();
		String newSubsCntrySubdCd = newInstSubs.getSubsCntrySubdCd();
		String newSubsPayerSeqCd = newInstSubs.getSubsPayerSeqCd();
		String newSubsRelationCd = newInstSubs.getSubsRelationCd();
		String newSubsFilingIndCd = newInstSubs.getSubsFilingIndCd();
		String newSubsEntityType = newInstSubs.getSubsEntityType();
		String newSubsGrpOrPolNbr = newInstSubs.getSubsGrpOrPolNbr();
		
		String newPayerName = newInstSubs.getPayerName();
		String newPayerId = newInstSubs.getPayerId();
		String newPayerTaxId = newInstSubs.getPayerTaxId();
		String newPayerAddrLine1 = newInstSubs.getPayerAddrLine1();
		String newPayerPlanId = newInstSubs.getPayerPlanId();
		String newPayerLocNbr = newInstSubs.getPayerLocNbr();
		String newPayerAddrLine2 = newInstSubs.getPayerAddrLine2();
		String newPayerNaicCd = newInstSubs.getPayerNaicCd();
		String newPayerSecId = newInstSubs.getPayerSecId();
		String newPayerCity = newInstSubs.getPayerCity();
		String newPayerState = newInstSubs.getPayerState();
		String newPayerZip = newInstSubs.getPayerZip();
		String newPayerCountry = newInstSubs.getPayerCountry();
		String newPayerCntrySubdCd = newInstSubs.getPayerCntrySubdCd();
		String newBillPrvCommNbr = newInstSubs.getBillPrvCommNbr();
		String newBillPrvLocNbr = newInstSubs.getBillPrvLocNbr();
		String newPropCasltyClmNbr = newInstSubs.getPropCasltyClmNbr();
		
		//Retrieve Previous Subscriber Data
		Enc837iSubsVO oldInstSubs = encounterVO.getInstSubscriber();
		
		String oldFirstName = oldInstSubs.getSubsFirstName();
		String oldMiddleName = oldInstSubs.getSubsMiddleName();
		String oldLastName = oldInstSubs.getSubsLastName();
		String oldSSN = oldInstSubs.getSubsSsn();
		String oldAddress1 = oldInstSubs.getSubsAddrLine1();
		String oldAddress2 = oldInstSubs.getSubsAddrLine2();
		String oldDob = oldInstSubs.getSubsDob();
		String oldGender = oldInstSubs.getSubsSex();
		String oldCity = oldInstSubs.getSubsCity();
		String oldState = oldInstSubs.getSubsState();
		String oldZip = oldInstSubs.getSubsZip();
		String oldSubsHicNbr = oldInstSubs.getSubsHicNbr();	
		String oldMbi = oldInstSubs.getMbi();
		String oldBillPrvAffilTaxId = oldInstSubs.getBillPrvAffilTaxId();
		
		String oldSubsMemberId = oldInstSubs.getSubsMemberId();
		String oldSubsCountry = oldInstSubs.getSubsCountry();
		String oldSubsGrpName = oldInstSubs.getSubsGrpName();
		String oldSubsCntrySubdCd = oldInstSubs.getSubsCntrySubdCd();
		String oldSubsPayerSeqCd = oldInstSubs.getSubsPayerSeqCd();
		String oldSubsRelationCd = oldInstSubs.getSubsRelationCd();
		String oldSubsFilingIndCd = oldInstSubs.getSubsFilingIndCd();
		String oldSubsEntityType = oldInstSubs.getSubsEntityType();
		String oldSubsGrpOrPolNbr = oldInstSubs.getSubsGrpOrPolNbr();
		
		String oldPayerName = oldInstSubs.getPayerName();
		String oldPayerId = oldInstSubs.getPayerId();
		String oldPayerTaxId = oldInstSubs.getPayerTaxId();
		String oldPayerAddrLine1 = oldInstSubs.getPayerAddrLine1();
		String oldPayerPlanId = oldInstSubs.getPayerPlanId();
		String oldPayerLocNbr = oldInstSubs.getPayerLocNbr();
		String oldPayerAddrLine2 = oldInstSubs.getPayerAddrLine2();
		String oldPayerNaicCd = oldInstSubs.getPayerNaicCd();
		String oldPayerSecId = oldInstSubs.getPayerSecId();
		String oldPayerCity = oldInstSubs.getPayerCity();
		String oldPayerState = oldInstSubs.getPayerState();
		String oldPayerZip = oldInstSubs.getPayerZip();
		String oldPayerCountry = oldInstSubs.getPayerCountry();
		String oldPayerCntrySubdCd = oldInstSubs.getPayerCntrySubdCd();
		String oldBillPrvCommNbr = oldInstSubs.getBillPrvCommNbr();
		String oldBillPrvLocNbr = oldInstSubs.getBillPrvLocNbr();
		String oldPropCasltyClmNbr = oldInstSubs.getPropCasltyClmNbr();
		
		try {												
	    	
		    //For first name
		    if (!newFirstName.equals(oldFirstName)) {
		    	fieldName = "SUBS_FIRST_NAME";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldFirstName ,newFirstName,userId,clmType);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }			    
			    dataChanged = true;
		    }
		    
		    //For middle name
		    if (!newMiddleName.equals(oldMiddleName)) {
		    	fieldName = "SUBS_MIDDLE_NAME";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldMiddleName ,newMiddleName,userId,clmType);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }			    
			    dataChanged = true;
		    }
		    
		    //For last name
		    if (!newLastName.equals(oldLastName)) {
		    	fieldName = "SUBS_LAST_NAME";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldLastName ,newLastName,userId,clmType);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }			    
			    dataChanged = true;
		    }
		    
		    //For SSN
		    if (!newSSN.equals(oldSSN)) {
		    	fieldName = "SUBS_SSN";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSSN ,newSSN,userId,clmType);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }			    
			    dataChanged = true;
		    }
		    
		    //For Address1
		    if (!newAddress1.equals(oldAddress1)) {
		    	fieldName = "SUBS_ADDR_LINE1";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAddress1 ,newAddress1,userId,clmType);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }			    
			    dataChanged = true;
		    }
		    
		    //For Address 2
		    if (!newAddress2.equals(oldAddress2)) {
		    	fieldName = "SUBS_ADDR_LINE2";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAddress2 ,newAddress2,userId,clmType);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }			    
			    dataChanged = true;
		    }
		    
		    //For DOB
		    if (!newDob.equals(oldDob)) {
		    	fieldName = "SUBS_DOB";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldDob ,newDob,userId,clmType);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }			    
			    dataChanged = true;
		    }
		    
		    //For Sex
		    if (!newGender.equals(oldGender)) {
		    	fieldName = "SUBS_SEX";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldGender ,newGender,userId,clmType);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }			    
			    dataChanged = true;
		    }
		    
		    //For City
		    if (!newCity.equals(oldCity)) {
		    	fieldName = "SUBS_CITY";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldCity ,newCity,userId,clmType);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }			    
			    dataChanged = true;
		    }
		    
		    //For State
		    if (!newState.equals(oldState)) {
		    	fieldName = "SUBS_STATE";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldState ,newState,userId,clmType);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }			    
			    dataChanged = true;
		    }
		    
		    //For Zip
		    if (!newZip.equals(oldZip)) {
		    	fieldName = "SUBS_ZIP";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldZip ,newZip,userId,clmType);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }			    
			    dataChanged = true;
		    }
		    
		    //For subsHicNbr
		    if (!newSubsHicNbr.equals(oldSubsHicNbr)) {
		    	fieldName = "SUBS_HIC_NBR";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsHicNbr ,newSubsHicNbr,userId,clmType);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For MBI
		    if (!newMbi.equals(oldMbi)) {
		    	fieldName = "MBI";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldMbi ,newMbi,userId,clmType);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }

		    //For billPrvAffilTaxId
		    if (!newBillPrvAffilTaxId.equals(oldBillPrvAffilTaxId)) {
		    	fieldName = "BILL_PRV_AFFIL_TAX_ID";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvAffilTaxId ,newBillPrvAffilTaxId,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Member Id
		    if (!newSubsMemberId.equals(oldSubsMemberId)) {
		    	fieldName = "SUBS_MEMBER_ID";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsMemberId ,newSubsMemberId,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;
		    }
		    
		    //For Country Code
		    if (!newSubsCountry.equals(oldSubsCountry)) {
		    	fieldName = "SUBS_COUNTRY";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsCountry ,newSubsCountry,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;
		    }
		    
		    //For Group Name
		    if (!newSubsGrpName.equals(oldSubsGrpName)) {
		    	fieldName = "SUBS_GRP_NAME";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsGrpName ,newSubsGrpName,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;
		    }
		    
		    //For Country Subd Code
		    if (!newSubsCntrySubdCd.equals(oldSubsCntrySubdCd)) {
		    	fieldName = "SUBS_CNTRY_SUBD_CD";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsCntrySubdCd ,newSubsCntrySubdCd,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;
		    }
		    
		    //For Payer Sequence Code
		    if (!newSubsPayerSeqCd.equals(oldSubsPayerSeqCd)) {
		    	fieldName = "SUBS_PAYER_SEQ_CD";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsPayerSeqCd ,newSubsPayerSeqCd,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;
		    }
		    
		    //For Relation Code
		    if (!newSubsRelationCd.equals(oldSubsRelationCd)) {
		    	fieldName = "SUBS_RELATION_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsRelationCd ,newSubsRelationCd,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;
		    }
		    
		    //For Filing Ind Code
		    if (!newSubsFilingIndCd.equals(oldSubsFilingIndCd)) {
		    	fieldName = "SUBS_FILING_IND_CD";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsFilingIndCd ,newSubsFilingIndCd,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		
		    //For Entity Type
		    if (!newSubsEntityType.equals(oldSubsEntityType)) {
		    	fieldName = "SUBS_ENTITY_TYPE";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsEntityType ,newSubsEntityType,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Group or Policy Nbr
		    if (!newSubsGrpOrPolNbr.equals(oldSubsGrpOrPolNbr)) {
		    	fieldName = "SUBS_GRP_OR_POL_NBR";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsGrpOrPolNbr ,newSubsGrpOrPolNbr,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Payer Name
		    if (!newPayerName.equals(oldPayerName)) {
		    	fieldName = "PAYER_NAME";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerName ,newPayerName,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Payer Id
		    if (!newPayerId.equals(oldPayerId)) {
		    	fieldName = "PAYER_ID";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerId ,newPayerId,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Payer Tax Id
		    if (!newPayerTaxId.equals(oldPayerTaxId)) {
		    	fieldName = "PAYER_TAX_ID";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerTaxId ,newPayerTaxId,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Payer Addr Line1
		    if (!newPayerAddrLine1.equals(oldPayerAddrLine1)) {
		    	fieldName = "PAYER_ADDR_LINE1";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerAddrLine1 ,newPayerAddrLine1,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Payer Plan Id
		    if (!newPayerPlanId.equals(oldPayerPlanId)) {
		    	fieldName = "PAYER_PLAN_ID";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerPlanId ,newPayerPlanId,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Payer Loc Nbr
		    if (!newPayerLocNbr.equals(oldPayerLocNbr)) {
		    	fieldName = "PAYER_LOC_NBR";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerLocNbr ,newPayerLocNbr,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Payer Addr Line2
		    if (!newPayerAddrLine2.equals(oldPayerAddrLine2)) {
		    	fieldName = "PAYER_ADDR_LINE2";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerAddrLine2 ,newPayerAddrLine2,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Payer Naic Cd
		    if (!newPayerNaicCd.equals(oldPayerNaicCd)) {
		    	fieldName = "PAYER_NAIC_CD";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerNaicCd ,newPayerNaicCd,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Payer Sec Id
		    if (!newPayerSecId.equals(oldPayerSecId)) {
		    	fieldName = "PAYER_SEC_ID";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerSecId ,newPayerSecId,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Payer City
		    if (!newPayerCity.equals(oldPayerCity)) {
		    	fieldName = "PAYER_CITY";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerCity ,newPayerCity,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Payer State
		    if (!newPayerState.equals(oldPayerState)) {
		    	fieldName = "PAYER_STATE";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerState ,newPayerState,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Payer Zip
		    if (!newPayerZip.equals(oldPayerZip)) {
		    	fieldName = "PAYER_ZIP";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerZip ,newPayerZip,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Payer Country
		    if (!newPayerCountry.equals(oldPayerCountry)) {
		    	fieldName = "PAYER_COUNTRY";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerCountry ,newPayerCountry,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Payer Cntry Subd Code
		    if (!newPayerCntrySubdCd.equals(oldPayerCntrySubdCd)) {
		    	fieldName = "PAYER_CNTRY_SUBD_CD";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerCntrySubdCd ,newPayerCntrySubdCd,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Bill Prv Comm Nbr
		    if (!newBillPrvCommNbr.equals(oldBillPrvCommNbr)) {
		    	fieldName = "BILL_PRV_COMM_NBR";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvCommNbr ,newBillPrvCommNbr,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Bill prv Loc Nbr
		    if (!newBillPrvLocNbr.equals(oldBillPrvLocNbr)) {
		    	fieldName = "BILL_PRV_LOC_NBR";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvLocNbr ,newBillPrvLocNbr,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }
		    
		    //For Prop caslty Clm Nbr
		    if (!newPropCasltyClmNbr.equals(oldPropCasltyClmNbr)) {
		    	fieldName = "PROP_CASLTY_CLM_NBR";		    	
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPropCasltyClmNbr ,newPropCasltyClmNbr,userId,clmType);
			    if (sqlCnt != 1) {
		            throw new Exception();
			    }			    
			    dataChanged = true;		    
		    }

		    
		    if(dataChanged){
		
				encounterVO.setInstSubsDirty(true);

		    	/*sqlCnt = ChartEncounterDao.setOverride(conn,oldInstSubs);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }			    
	
		    	newInstSubs.setSubsSeqNbr(oldInstSubs.getSubsSeqNbr()+1);	    	
			    newInstSubs.setLastUpdtUserid(userId);
			    sqlCnt = ChartEncounterDao.insertInstSubscriber(conn, newInstSubs);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }*/
			    
				newInstSubs.setLastUpdtUserid(userId);
		    	sqlCnt = ChartEncounterDao.updateInstSubsDetails(conn, newInstSubs);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }
			    
		    }
		    		    	
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			message = "Error Updating Institutional Subscriber Data";
		}						
		logger.info(LoggerConstants.methodEndLevel());
		return message;	
		}
	
	public String updateInstOtherSubscriberFromSubscriber(Connection conn, HPEEncounterVO encounterVO, Enc837iSubsVO newInstSubs)
		throws Exception {		
		logger.info(LoggerConstants.methodStartLevel());
		String message = "";

		ChartEncounterDao ChartEncounterDao = new ChartEncounterDao();		

		String mfId = encounterVO.getMfId();
		String userId = encounterVO.getUserId();
		String clmType = encounterVO.getSearchDetailClmType();

		int sqlCnt = -1;

		String fieldName = "";
		String tableName = "ENC_837I_CLM_OTHSUBS";

		String newFirstName = newInstSubs.getSubsFirstName();
		String newMiddleName = newInstSubs.getSubsMiddleName();
		String newLastName = newInstSubs.getSubsLastName();
		String newSSN = newInstSubs.getSubsSsn();
		String newAddress1 = newInstSubs.getSubsAddrLine1();
		String newAddress2 = newInstSubs.getSubsAddrLine2();
		String newCity = newInstSubs.getSubsCity();
		String newState = newInstSubs.getSubsState();
		String newZip = newInstSubs.getSubsZip();
		String newSubsHicNbr = newInstSubs.getSubsHicNbr();			

		try {												
			

			Enc837iClmOthsubsVOs othrSubs = encounterVO.getInstClaimOtherSubscribers();
			if (othrSubs != null) {
				Iterator it = othrSubs.iterator();
				while (it.hasNext()) {

					boolean dataChanged = false;

					//Retrieve Previous Subscriber Data
					Enc837iClmOthsubsVO oldInstOthrSubs = (Enc837iClmOthsubsVO)it.next();
	
					String oldFirstName = oldInstOthrSubs.getOthInsuredFirstName();
					String oldMiddleName = oldInstOthrSubs.getOthInsuredMiddleName();
					String oldLastName = oldInstOthrSubs.getOthInsuredLastName();
					String oldSSN = oldInstOthrSubs.getOthSubsSsn();
					String oldAddress1 = oldInstOthrSubs.getOthSubsAddrLine1();
					String oldAddress2 = oldInstOthrSubs.getOthSubsAddrLine2();
					String oldCity = oldInstOthrSubs.getOthSubsCity();
					String oldState = oldInstOthrSubs.getOthSubsState();
					String oldZip = oldInstOthrSubs.getOthSubsZip();	
					String oldSubsHicNbr = oldInstOthrSubs.getOthSubsHicNbr();			
	
					//Create Record Key	
					String recordKey = ChartEncounterDao.getClaimChangeLogRecordKey(oldInstOthrSubs);
					ChartEncounterDao.setClaimDetailString(oldInstOthrSubs.getWtxClaimRefNbr() + "|" + oldInstOthrSubs.getWtxClaimRevNbr() + "|" +oldInstOthrSubs.getClmSeqNbr());

					//For first name
					if (!newFirstName.equals(oldFirstName)) {
						fieldName = "OTH_INSURED_FIRST_NAME";
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldFirstName ,newFirstName,userId,clmType);
						if (sqlCnt != 1) {
							throw new Exception();
						}			    
						dataChanged = true;
					}
    
					//For middle name
					if (!newMiddleName.equals(oldMiddleName)) {
						fieldName = "OTH_INSURED_MIDDLE_NAME";		    	
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldMiddleName ,newMiddleName,userId,clmType);
						if (sqlCnt != 1) {
							throw new Exception();
						}			    
						dataChanged = true;
					}
		    
					//For last name
					if (!newLastName.equals(oldLastName)) {
						fieldName = "OTH_INSURED_LAST_NAME";		    	
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldLastName ,newLastName,userId,clmType);
						if (sqlCnt != 1) {
							throw new Exception();
						}			    
						dataChanged = true;
					}
		    
				    //For SSN
				    if (!newSSN.equals(oldSSN)) {
				    	fieldName = "OTH_SUBS_SSN";		    	
					    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSSN ,newSSN,userId,clmType);
					    if (sqlCnt != 1) {
			                throw new Exception();
					    }			    
					    dataChanged = true;
				    }
				    //IFOX-00431676 � Sentara Portal issues - Start
				    //For Address1
					if (!newAddress1.equals(oldAddress1)) {
						/*fieldName = "OTH_SUBS_ADDR_LINE1";		    	
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAddress1 ,newAddress1,userId,clmType);
						if (sqlCnt != 1) {
							throw new Exception();
						}*/			    
						dataChanged = true;
					}
		    
					//For Address 2
					if (!newAddress2.equals(oldAddress2)) {
						/*fieldName = "OTH_SUBS_ADDR_LINE2";		    	
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAddress2 ,newAddress2,userId,clmType);
						if (sqlCnt != 1) {
							throw new Exception();
						}*/			    
						dataChanged = true;
					}
		    
					//For City
					if (!newCity.equals(oldCity)) {
						/*fieldName = "OTH_SUBS_CITY";		    	
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldCity ,newCity,userId,clmType);
						if (sqlCnt != 1) {
							throw new Exception();
						}*/			    
						dataChanged = true;
					}
		    
					//For State
					if (!newState.equals(oldState)) {
						/*fieldName = "OTH_SUBS_STATE";		    	
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldState ,newState,userId,clmType);
						if (sqlCnt != 1) {
							throw new Exception();
						}*/			    
						dataChanged = true;
					}
		    
					//For Zip
					if (!newZip.equals(oldZip)) {
						/*fieldName = "OTH_SUBS_ZIP";
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldZip ,newZip,userId,clmType);
						if (sqlCnt != 1) {
							throw new Exception();
						}*/			    
						dataChanged = true;
					}
					//IFOX-00431676 � Sentara Portal issues - End
					//For subsHicNbr
					if (!newSubsHicNbr.equals(oldSubsHicNbr)) {
						fieldName = "OTH_SUBS_HIC_NBR";		    	
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsHicNbr ,newSubsHicNbr,userId,clmType);
						if (sqlCnt != 1) {
							throw new Exception();
						}			    
						dataChanged = true;		    
					}
		    
					if(dataChanged){
		
						encounterVO.setInstOthSubsDirty(true);
						
						Enc837iClmOthsubsVO newInstOthrSubs = new Enc837iClmOthsubsVO(oldInstOthrSubs);
						
						newInstOthrSubs.setOthInsuredFirstName(newFirstName);
						newInstOthrSubs.setOthInsuredMiddleName(newMiddleName);
						newInstOthrSubs.setOthInsuredLastName(newLastName);
						newInstOthrSubs.setOthSubsSsn(newSSN);
						newInstOthrSubs.setOthSubsAddrLine1(newAddress1);
						newInstOthrSubs.setOthSubsAddrLine2(newAddress2);
						newInstOthrSubs.setOthSubsCity(newCity);
						newInstOthrSubs.setOthSubsState(newState);
						newInstOthrSubs.setOthSubsZip(newZip);
						newInstOthrSubs.setOthSubsHicNbr(newSubsHicNbr);			
						
						newInstOthrSubs.setLastUpdtUserid(userId);
						
						sqlCnt = othrSubs.update(conn, newInstOthrSubs);
						if (sqlCnt != 1) {
							throw new Exception();
						}
			
					}
				}
			}
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			message = "Error Updating Institutional Subscriber Data";
		}						
		logger.info(LoggerConstants.methodEndLevel());
		return message;	
	}			

	public String updateProfSubscriber(Connection conn, HPEEncounterVO encounterVO, Enc837pSubsVO newProfSubs, Enc837pClmVO enc837pClmVO) throws Exception {		
		logger.info(LoggerConstants.methodStartLevel());
		String message = "";
		
		// Retrieve DAO
		ChartEncounterDao ChartEncounterDao = new ChartEncounterDao();		
		
		String mfId = encounterVO.getMfId();
		String userId = encounterVO.getUserId();
		String clmType = encounterVO.getSearchDetailClmType();
		
		//Create Record Key - This is wrong	
		String recordKey = ChartEncounterDao.getClaimChangeLogRecordKey(enc837pClmVO);
		ChartEncounterDao.setClaimDetailString(enc837pClmVO.getWtxClaimRefNbr() + "|" + enc837pClmVO.getWtxClaimRevNbr() + "|" +enc837pClmVO.getClmSeqNbr());
	
		int sqlCnt = -1;
		
		String fieldName = "";
		String tableName = "ENC_837P_SUBS";

		boolean dataChanged = false;
				
		String newFirstName = newProfSubs.getSubsFirstName();
		String newMiddleName = newProfSubs.getSubsMiddleName();
		String newLastName = newProfSubs.getSubsLastName();
		String newSSN = newProfSubs.getSubsSsn();
		String newAddress1 = newProfSubs.getSubsAddrLine1();
		String newAddress2 = newProfSubs.getSubsAddrLine2();
		String newDob = newProfSubs.getSubsDob();
		String newGender = newProfSubs.getSubsSex();
		String newCity = newProfSubs.getSubsCity();
		String newState = newProfSubs.getSubsState();
		String newZip = newProfSubs.getSubsZip();
		String newSubsHicNbr = newProfSubs.getSubsHicNbr();
		String newMbi = newProfSubs.getMbi();
		String newBillPrvAffilTaxId = newProfSubs.getBillPrvAffilTaxId();
		
		String newSubsPayerSeqCd = newProfSubs.getSubsPayerSeqCd();
		String newSubsRelationCd = newProfSubs.getSubsRelationCd();
		String newSubsFilingIndCd = newProfSubs.getSubsFilingIndCd();
		String newSubsInsuranceTypeCd = newProfSubs.getSubsInsuranceTypeCd();		
		String newSubsEntityType = newProfSubs.getSubsEntityType();
		String newSubsMemberId = newProfSubs.getSubsMemberId();
		String newSubsCountry = newProfSubs.getSubsCountry();
		String newSubsCntrySubdCd = newProfSubs.getSubsCntrySubdCd();
		String newSubsGrpOrPolNbr = newProfSubs.getSubsGrpOrPolNbr();
		String newSubsPlanName = newProfSubs.getSubsPlanName();
		String newSubsPatDod = newProfSubs.getSubsPatDod();
		int  newSubsPatWeight = newProfSubs.getSubsPatWeight();
		String newSubsPatUom = newProfSubs.getSubsPatUom();
		String newSubsPatPregnantInd = newProfSubs.getSubsPatPregnantInd();
		
        String newPayerName = newProfSubs.getPayerName();
        String newPayerId = newProfSubs.getPayerId();
        String newPayerPlanId = newProfSubs.getPayerPlanId();
        String newPayerAddrLine1 = newProfSubs.getPayerAddrLine1();
        String newPayerAddrLine2 = newProfSubs.getPayerAddrLine2();
        String newPayerCity = newProfSubs.getPayerCity();
        String newPayerState = newProfSubs.getPayerState();
        String newPayerZip = newProfSubs.getPayerZip();
        String newPayerCountry = newProfSubs.getPayerCountry();
        String newPayerCntrySubdCd = newProfSubs.getPayerCntrySubdCd();
        String newPayerTaxId = newProfSubs.getPayerTaxId();
        String newPayerLocNbr = newProfSubs.getPayerLocNbr();
        String newPayerNaicCd = newProfSubs.getPayerNaicCd();
        String newgetPayerSecId = newProfSubs.getPayerSecId();
		

		String newBillPrvCommNbr = newProfSubs.getBillPrvCommNbr();
		String newBillPrvLocNbr = newProfSubs.getBillPrvLocNbr();
		String newPropCasltyClmNbr = newProfSubs.getPropCasltyClmNbr();
		String newPropCasltySubsName = newProfSubs.getPropCasltySubsName();		
		String newPropCasltySubsPhone = newProfSubs.getPropCasltySubsPhone();
		String newPropCasltySubsPhnExt = newProfSubs.getPropCasltySubsPhnExt();

		
		
		
		//Retrieve previous subscriber data
		Enc837pSubsVO oldProfSubs = encounterVO.getProfSubscriber();
				
		String oldFirstName = oldProfSubs.getSubsFirstName();
		String oldMiddleName = oldProfSubs.getSubsMiddleName();
		String oldLastName = oldProfSubs.getSubsLastName();
		String oldSSN = oldProfSubs.getSubsSsn();
		String oldAddress1 = oldProfSubs.getSubsAddrLine1();
		String oldAddress2 = oldProfSubs.getSubsAddrLine2();
		String oldDob = oldProfSubs.getSubsDob();
		String oldGender = oldProfSubs.getSubsSex();
		String oldCity = oldProfSubs.getSubsCity();
		String oldState = oldProfSubs.getSubsState();
		String oldZip = oldProfSubs.getSubsZip();
		String oldSubsHicNbr = oldProfSubs.getSubsHicNbr();
		String oldMbi = oldProfSubs.getMbi();
		String oldBillPrvAffilTaxId = oldProfSubs.getBillPrvAffilTaxId();		
		
		String oldSubsPayerSeqCd = oldProfSubs.getSubsPayerSeqCd();
		String oldSubsRelationCd = oldProfSubs.getSubsRelationCd();
		String oldSubsFilingIndCd = oldProfSubs.getSubsFilingIndCd();
		String oldSubsInsuranceTypeCd = oldProfSubs.getSubsInsuranceTypeCd();		
		String oldSubsEntityType = oldProfSubs.getSubsEntityType();
		String oldSubsMemberId = oldProfSubs.getSubsMemberId();
		String oldSubsCountry = oldProfSubs.getSubsCountry();
		String oldSubsCntrySubdCd = oldProfSubs.getSubsCntrySubdCd();
		String oldSubsGrpOrPolNbr = oldProfSubs.getSubsGrpOrPolNbr();
		String oldSubsPlanName = oldProfSubs.getSubsPlanName();
		String oldSubsPatDod = oldProfSubs.getSubsPatDod();
		int  oldSubsPatWeight = oldProfSubs.getSubsPatWeight();
		String oldSubsPatUom = oldProfSubs.getSubsPatUom();
		String oldSubsPatPregnantInd = oldProfSubs.getSubsPatPregnantInd();
		
        String oldPayerName = oldProfSubs.getPayerName();
        String oldPayerId = oldProfSubs.getPayerId();
        String oldPayerPlanId = oldProfSubs.getPayerPlanId();
        String oldPayerAddrLine1 = oldProfSubs.getPayerAddrLine1();
        String oldPayerAddrLine2 = oldProfSubs.getPayerAddrLine2();
        String oldPayerCity = oldProfSubs.getPayerCity();
        String oldPayerState = oldProfSubs.getPayerState();
        String oldPayerZip = oldProfSubs.getPayerZip();
        String oldPayerCountry = oldProfSubs.getPayerCountry();
        String oldPayerCntrySubdCd = oldProfSubs.getPayerCntrySubdCd();
        String oldPayerTaxId = oldProfSubs.getPayerTaxId();
        String oldPayerLocNbr = oldProfSubs.getPayerLocNbr();
        String oldPayerNaicCd = oldProfSubs.getPayerNaicCd();
        String oldgetPayerSecId = oldProfSubs.getPayerSecId();
		
		
		
		String oldBillPrvCommNbr = oldProfSubs.getBillPrvCommNbr();
		String oldBillPrvLocNbr = oldProfSubs.getBillPrvLocNbr();
		String oldPropCasltyClmNbr = oldProfSubs.getPropCasltyClmNbr();
		String oldPropCasltySubsName = oldProfSubs.getPropCasltySubsName();		
		String oldPropCasltySubsPhone = oldProfSubs.getPropCasltySubsPhone();
		String oldPropCasltySubsPhnExt = oldProfSubs.getPropCasltySubsPhnExt();
		
		try {																				
			
		    //For first name
		    if (!newFirstName.equals(oldFirstName)) {
		    	fieldName = "SUBS_FIRST_NAME";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldFirstName ,newFirstName,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    
		    //For middle name
		    if (!newMiddleName.equals(oldMiddleName)) {
		    	fieldName = "SUBS_MIDDLE_NAME";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey,tableName, fieldName, oldMiddleName ,newMiddleName,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    
		    //For last name
		    if (!newLastName.equals(oldLastName)) {
		    	fieldName = "SUBS_LAST_NAME";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldLastName ,newLastName,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    
		    //For SSN
		    if (!newSSN.equals(oldSSN)) {
		    	fieldName = "SUBS_SSN";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSSN ,newSSN,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    
		    //For Address1
		    if (!newAddress1.equals(oldAddress1)) {
		    	fieldName = "SUBS_ADDR_LINE1";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAddress1 ,newAddress1,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    
		    //For Address 2
		    if (!newAddress2.equals(oldAddress2)) {
		    	fieldName = "SUBS_ADDR_LINE2";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAddress2 ,newAddress2,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    
		    //For DOB
		    if (!newDob.equals(oldDob)) {
		    	fieldName = "SUBS_DOB";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldDob ,newDob,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    
		    //For Sex
		    if (!newGender.equals(oldGender)) {
		    	fieldName = "SUBS_SEX";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldGender ,newGender,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    
		    //For City
		    if (!newCity.equals(oldCity)) {
		    	fieldName = "SUBS_CITY";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldCity ,newCity,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    
		    //For State
		    if (!newState.equals(oldState)) {
		    	fieldName = "SUBS_STATE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldState ,newState,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    
		    //For Zip
		    if (!newZip.equals(oldZip)) {
		    	fieldName = "SUBS_ZIP";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldZip ,newZip,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    
		    //For subsHicNbr
		    if (!newSubsHicNbr.equals(oldSubsHicNbr)) {
		    	fieldName = "SUBS_HIC_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsHicNbr, newSubsHicNbr,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    
		  //For MBI
		    if (!newMbi.equals(oldMbi)) {
		    	fieldName = "MBI";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldMbi, newMbi,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    
		    //For subsPayerSeqCd
		    if (!newSubsPayerSeqCd.equals(oldSubsPayerSeqCd)) {
		    	fieldName = "SUBS_PAYER_SEQ_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsPayerSeqCd, newSubsPayerSeqCd,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newSubsRelationCd 
		    if (!newSubsRelationCd .equals(oldSubsRelationCd)) {
		    	fieldName = "SUBS_RELATION_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsRelationCd, newSubsRelationCd ,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newSubsGrpOrPolNbr
		    if (!newSubsGrpOrPolNbr.equals(oldSubsGrpOrPolNbr)) {
		    	fieldName = "SUBS_GRP_OR_POL_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsGrpOrPolNbr, newSubsGrpOrPolNbr,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newSubsPlanName
		    if (!newSubsPlanName.equals(oldSubsPlanName)) {
		    	fieldName = "SUBS_PLAN_NAME";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsPlanName, newSubsPlanName,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newSubsInsuranceTypeCd
		    if (!newSubsInsuranceTypeCd.equals(oldSubsInsuranceTypeCd)) {
		    	fieldName = "SUBS_INSURANCE_TYPE_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsInsuranceTypeCd, newSubsInsuranceTypeCd,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newSubsFilingIndCd
		    if (!newSubsFilingIndCd.equals(oldSubsFilingIndCd)) {
		    	fieldName = "SUBS_FILING_IND_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsFilingIndCd, newSubsFilingIndCd,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newSubsPatDod
		    if (!newSubsPatDod.equals(oldSubsPatDod)) {
		    	fieldName = "SUBS_PAT_DOD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsPatDod, newSubsPatDod,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newSubsPatUom
		    if (!newSubsPatUom.equals(oldSubsPatUom)) {
		    	fieldName = "SUBS_PAT_UOM";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsPatUom, newSubsPatUom,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newSubsPatWeight
		    if (newSubsPatWeight != oldSubsPatWeight){
		    	fieldName = "SUBS_PAT_WEIGHT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsPatWeight+"", newSubsPatWeight+"",userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newSubsPatPregnantInd
		    if (!newSubsPatPregnantInd .equals(oldSubsPatPregnantInd )) {
		    	fieldName = "SUBS_PAT_PREGNANT_IND";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsPatPregnantInd, newSubsPatPregnantInd,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newSubsEntityType
		    if (!newSubsEntityType.equals(oldSubsEntityType)) {
		    	fieldName = "SUBS_ENTITY_TYPE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsEntityType, newSubsEntityType,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newSubsMemberId
		    if (!newSubsMemberId.equals(oldSubsMemberId)) {
		    	fieldName = "SUBS_MEMBER_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsMemberId, newSubsMemberId,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newSubsCountry
		    if (!newSubsCountry.equals(oldSubsCountry)) {
		    	fieldName = "SUBS_COUNTRY";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsCountry, newSubsCountry,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newPayerName
		    if (!oldPayerName.equals(newPayerName)) {
		    	fieldName = "PAYER_NAME";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerName, newPayerName,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    
		    //For newPayerId
		    if (!oldPayerId.equals(newPayerId)) {
		    	fieldName = "PAYER_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerId, newPayerId,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newPayerPlanId
		    if (!oldPayerPlanId.equals(newPayerPlanId)) {
		    	fieldName = "PAYER_PLAN_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerPlanId, newPayerPlanId,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newPayerAddrLine1
		    if (!oldPayerAddrLine1.equals(newPayerAddrLine1)) {
		    	fieldName = "PAYER_ADDR_LINE1";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerAddrLine1, newPayerAddrLine1,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newPayerAddrLine2
		    if (!oldPayerAddrLine2.equals(newPayerAddrLine2)) {
		    	fieldName = "PAYER_ADDR_LINE2";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerAddrLine2, newPayerAddrLine2,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newPayerCity
		    if (!oldPayerCity.equals(newPayerCity)) {
		    	fieldName = "PAYER_CITY";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerCity, newPayerCity,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newPayerState
		    if (!oldPayerState.equals(newPayerState)) {
		    	fieldName = "PAYER_STATE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerState, newPayerState,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newPayerZip
		    if (!oldPayerZip.equals(newPayerZip)) {
		    	fieldName = "PAYER_ZIP";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerZip, newPayerZip,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newPayerCountry
		    if (!oldPayerCountry.equals(newPayerCountry)) {
		    	fieldName = "PAYER_COUNTRY";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerCountry, newPayerCountry,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newPayerCntrySubdCd
		    if (!oldPayerCntrySubdCd.equals(newPayerCntrySubdCd)) {
		    	fieldName = "PAYER_CNTRY_SUBD_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerCntrySubdCd, newPayerCntrySubdCd,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newPayerTaxId
		    if (!oldPayerTaxId.equals(newPayerTaxId)) {
		    	fieldName = "PAYER_TAX_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerTaxId, newPayerTaxId,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newPayerLocNbr
		    if (!oldPayerLocNbr.equals(newPayerLocNbr)) {
		    	fieldName = "PAYER_LOC_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerLocNbr, newPayerLocNbr,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newPayerNaicCd
		    if (!oldPayerNaicCd.equals(newPayerNaicCd)) {
		    	fieldName = "PAYER_NAIC_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerNaicCd, newPayerNaicCd,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newgetPayerSecId
		    if (!oldgetPayerSecId.equals(newgetPayerSecId)) {
		    	fieldName = "PAYER_SEC_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldgetPayerSecId, newgetPayerSecId,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    		    
		    //For billPrvCommNbr
		    if (!newBillPrvCommNbr.equals(oldBillPrvCommNbr)) {
		    	fieldName = "SUBS_CNTRY_SUBD_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvCommNbr, newBillPrvCommNbr,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newSubsCntrySubdCd
		    if (!newSubsCntrySubdCd.equals(oldSubsCntrySubdCd)) {
		    	fieldName = "SUBS_CNTRY_SUBD_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, newSubsCntrySubdCd, newSubsCntrySubdCd,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newBillPrvCommNbr
		    if (!newBillPrvCommNbr.equals(oldBillPrvCommNbr)) {
		    	fieldName = "BILL_PRV_COMM_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvCommNbr, newBillPrvCommNbr,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newBillPrvLocNbr 
		    if (!newBillPrvLocNbr.equals(oldBillPrvLocNbr)) {
		    	fieldName = "BILL_PRV_LOC_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvLocNbr , newBillPrvLocNbr ,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newPropCasltyClmNbr
		    if (!newPropCasltyClmNbr.equals(oldPropCasltyClmNbr)) {
		    	fieldName = "PROP_CASLTY_CLM_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPropCasltyClmNbr, newPropCasltyClmNbr,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For newPropCasltySubsName
		    if (!newPropCasltySubsName.equals(oldPropCasltySubsName)) {
		    	fieldName = "PROP_CASLTY_SUBS_NAME";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPropCasltySubsName, newPropCasltySubsName,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For oldPropCasltySubsPhone
		    if (!newPropCasltySubsPhone.equals(oldPropCasltySubsPhone)) {
		    	fieldName = "PROP_CASLTY_SUBS_PHONE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPropCasltySubsPhone, newPropCasltySubsPhone,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    //For oldPropCasltySubsPhnExt
		    if (!newPropCasltySubsPhnExt.equals(oldPropCasltySubsPhnExt)) {
		    	fieldName = "PROP_CASLTY_SUBS_PHN_EXT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPropCasltySubsPhnExt, newPropCasltySubsPhnExt,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }
		    
		    //For billPrvAffilTaxId
		    if (!newBillPrvAffilTaxId.equals(oldBillPrvAffilTaxId)) {
		    	fieldName = "BILL_PRV_AFFIL_TAX_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvAffilTaxId, newBillPrvAffilTaxId,userId,clmType);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
			    dataChanged = true;
		    }

		    if(dataChanged){
		    	
		    	encounterVO.setProfSubsDirty(true);
		    	
		    	/*
		    	sqlCnt = ChartEncounterDao.setOverride(conn,oldProfSubs);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }	    
	
		    	newProfSubs.setSubsSeqNbr(oldProfSubs.getSubsSeqNbr()+1);	    	
			    newProfSubs.setLastUpdtUserid(userId);
			    sqlCnt = ChartEncounterDao.insertProfSubscriber(conn, newProfSubs);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }*/		
		    	
		    	newProfSubs.setLastUpdtUserid(userId);
		    	sqlCnt = ChartEncounterDao.updateProfSubsDetails(conn, newProfSubs);
			    if (sqlCnt != 1) {
	                throw new Exception();
			    }
		    	
			}
		    	
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			message = "Error Updating Professional Subscriber Data";
			logger.debug(e.getMessage());
		}		
		logger.info(LoggerConstants.methodEndLevel());
		return message;								
		
	}		
	
	public String updateProfOtherSubscriberFromSubscriber(Connection conn, HPEEncounterVO encounterVO, Enc837pSubsVO newProfSubs)
	throws Exception {		
		logger.info(LoggerConstants.methodStartLevel());
		String message = "";

		ChartEncounterDao ChartEncounterDao = new ChartEncounterDao();		

		String mfId = encounterVO.getMfId();
		String userId = encounterVO.getUserId();
		String clmType = encounterVO.getSearchDetailClmType();
		int sqlCnt = -1;

		String fieldName = "";
		String tableName = "ENC_837P_CLM_OTHSUBS";

		String newFirstName = newProfSubs.getSubsFirstName();
		String newMiddleName = newProfSubs.getSubsMiddleName();
		String newLastName = newProfSubs.getSubsLastName();
		String newSSN = newProfSubs.getSubsSsn();
		String newAddress1 = newProfSubs.getSubsAddrLine1();
		String newAddress2 = newProfSubs.getSubsAddrLine2();
		String newCity = newProfSubs.getSubsCity();
		String newState = newProfSubs.getSubsState();
		String newZip = newProfSubs.getSubsZip();
		String newSubsHicNbr = newProfSubs.getSubsHicNbr();			

		try {												
		

			Enc837pClmOthsubsVOs othrSubs = encounterVO.getProfClaimOtherSubscribers();
			if (othrSubs != null) {
				Iterator it = othrSubs.iterator();
				while (it.hasNext()) {

					boolean dataChanged = false;

					//Retrieve Previous Subscriber Data
					Enc837pClmOthsubsVO oldProfOthrSubs = (Enc837pClmOthsubsVO)it.next();

					String oldFirstName = oldProfOthrSubs.getOthInsuredFirstName();
					String oldMiddleName = oldProfOthrSubs.getOthInsuredMiddleName();
					String oldLastName = oldProfOthrSubs.getOthInsuredLastName();
					String oldSSN = oldProfOthrSubs.getOthSubsSsn();
					String oldAddress1 = oldProfOthrSubs.getOthSubsAddrLine1();
					String oldAddress2 = oldProfOthrSubs.getOthSubsAddrLine2();
					String oldCity = oldProfOthrSubs.getOthSubsCity();
					String oldState = oldProfOthrSubs.getOthSubsState();
					String oldZip = oldProfOthrSubs.getOthSubsZip();	
					String oldSubsHicNbr = oldProfOthrSubs.getOthSubsHicNbr();			

					//Create Record Key	
					String recordKey = ChartEncounterDao.getClaimChangeLogRecordKey(oldProfOthrSubs);
					ChartEncounterDao.setClaimDetailString(oldProfOthrSubs.getWtxClaimRefNbr() + "|" + oldProfOthrSubs.getWtxClaimRevNbr() + "|" +oldProfOthrSubs.getClmSeqNbr());
	
					//For first name
					if (!newFirstName.equals(oldFirstName)) {
						fieldName = "OTH_INSURED_FIRST_NAME";
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldFirstName ,newFirstName,userId,clmType);
						if (sqlCnt != 1) {
							throw new Exception();
						}			    
						dataChanged = true;
					}
	
					//For middle name
					if (!newMiddleName.equals(oldMiddleName)) {
						fieldName = "OTH_INSURED_MIDDLE_NAME";		    	
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldMiddleName ,newMiddleName,userId,clmType);
						if (sqlCnt != 1) {
							throw new Exception();
						}			    
						dataChanged = true;
					}
		    
					//For last name
					if (!newLastName.equals(oldLastName)) {
						fieldName = "OTH_INSURED_LAST_NAME";		    	
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldLastName ,newLastName,userId,clmType);
						if (sqlCnt != 1) {
							throw new Exception();
						}			    
						dataChanged = true;
					}
		    
				    //For SSN
				    if (!newSSN.equals(oldSSN)) {
				    	fieldName = "OTH_SUBS_SSN";		    	
					    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSSN ,newSSN,userId,clmType);
					    if (sqlCnt != 1) {
			                throw new Exception();
					    }			    
					    dataChanged = true;
				    }
				    //IFOX-00431676 � Sentara Portal issues - Start
				    //For Address1
					if (!newAddress1.equals(oldAddress1)) {
						/*fieldName = "OTH_SUBS_ADDR_LINE1";		    	
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAddress1 ,newAddress1,userId,clmType);
						if (sqlCnt != 1) {
							throw new Exception();
						}*/			    
						dataChanged = true;
					}
		    
					//For Address 2
					if (!newAddress2.equals(oldAddress2)) {
						/*fieldName = "OTH_SUBS_ADDR_LINE2";		    	
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAddress2 ,newAddress2,userId,clmType);
						if (sqlCnt != 1) {
							throw new Exception();
						}*/			    
						dataChanged = true;
					}
		    
					//For City
					if (!newCity.equals(oldCity)) {
						/*fieldName = "OTH_SUBS_CITY";		    	
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldCity ,newCity,userId,clmType);
						if (sqlCnt != 1) {
							throw new Exception();
						}*/			    
						dataChanged = true;
					}
		    
					//For State
					if (!newState.equals(oldState)) {
						/*fieldName = "OTH_SUBS_STATE";		    	
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldState ,newState,userId,clmType);
						if (sqlCnt != 1) {
							throw new Exception();
						}*/			    
						dataChanged = true;
					}
		    
					//For Zip
					if (!newZip.equals(oldZip)) {
						/*fieldName = "OTH_SUBS_ZIP";
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldZip ,newZip,userId,clmType);
						if (sqlCnt != 1) {
							throw new Exception();
						}*/			    
						dataChanged = true;
					}
					//IFOX-00431676 � Sentara Portal issues - End
					//For subsHicNbr
					if (!newSubsHicNbr.equals(oldSubsHicNbr)) {
						fieldName = "OTH_SUBS_HIC_NBR";		    	
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsHicNbr ,newSubsHicNbr,userId,clmType);
						if (sqlCnt != 1) {
							throw new Exception();
						}			    
						dataChanged = true;		    
					}
	    
					if(dataChanged){
	
						encounterVO.setProfOthSubsDirty(true);
						
						Enc837pClmOthsubsVO newProfOthrSubs = new Enc837pClmOthsubsVO(oldProfOthrSubs);
					
						newProfOthrSubs.setOthInsuredFirstName(newFirstName);
						newProfOthrSubs.setOthInsuredMiddleName(newMiddleName);
						newProfOthrSubs.setOthInsuredLastName(newLastName);
						newProfOthrSubs.setOthSubsSsn(newSSN);
						newProfOthrSubs.setOthSubsAddrLine1(newAddress1);
						newProfOthrSubs.setOthSubsAddrLine2(newAddress2);
						newProfOthrSubs.setOthSubsCity(newCity);
						newProfOthrSubs.setOthSubsState(newState);
						newProfOthrSubs.setOthSubsZip(newZip);
						newProfOthrSubs.setOthSubsHicNbr(newSubsHicNbr);			
						
						newProfOthrSubs.setLastUpdtUserid(userId);
					
						sqlCnt = othrSubs.update(conn, newProfOthrSubs);
						if (sqlCnt != 1) {
							throw new Exception();
						}
		
					}
				}
			}
		
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			message = "Error Updating Institutional Subscriber Data";
		}						
		logger.info(LoggerConstants.methodEndLevel());
		return message;	
	}			

	public String updateInstClaim(Connection conn, HPEEncounterVO encounterVO, Enc837iClmVO newEnc837iClmVO)
			throws ApplicationException {		
		logger.info(LoggerConstants.methodStartLevel());
		String message = "";
		
		// Retrieve DAO
		ChartEncounterDao ChartEncounterDao = new ChartEncounterDao();		

		String mfId = encounterVO.getMfId();
		String userId = encounterVO.getUserId();
		String clmType = encounterVO.getSearchDetailClmType();
		
		Enc837iSubsVO oldInstSubs = encounterVO.getInstSubscriber();
		Enc837iClmVO oldEnc837iClmVO = encounterVO.getInstClaim();		
		String recordKey = ChartEncounterDao.getClaimChangeLogRecordKey(oldEnc837iClmVO);
		ChartEncounterDao.setClaimDetailString(oldEnc837iClmVO.getWtxClaimRefNbr() + "|" + oldEnc837iClmVO.getWtxClaimRevNbr() + "|" +oldEnc837iClmVO.getClmSeqNbr());
	    
	    String oldProcessStatus       = oldEnc837iClmVO.getProcessStatus(); 				
	    String oldSubsHic             = oldEnc837iClmVO.getSubsHicNbr();
	    String oldMbiSubs             = oldInstSubs.getMbi();
	    String oldMbi                 = oldEnc837iClmVO.getMbi();
	    String oldInBillPrvAffilTaxId = oldEnc837iClmVO.getInBillPrvAffilTaxId();
		String oldClmFacTypeCd        = oldEnc837iClmVO.getClmFacTypeCd();
		String oldAdmitType           = oldEnc837iClmVO.getAdmitType();
		String oldAdmitSourceCd       = oldEnc837iClmVO.getAdmitSourceCd();
		String oldAdmitDt             = oldEnc837iClmVO.getAdmitDt();
		String oldAdmitHour           = oldEnc837iClmVO.getAdmitHour();
		String oldPatientStatusCd     = oldEnc837iClmVO.getPatientStatusCd();
		String oldAmbPickupZip        = oldEnc837iClmVO.getAmbPickupZip();
		
		String oldPatientCtrlNbr  	  = oldEnc837iClmVO.getPatientCtrlNbr();
		String oldContractTypeCd  	  = oldEnc837iClmVO.getContractTypeCd();
		String oldAdmitDiagType  	  = oldEnc837iClmVO.getAdmitDiagType();
		String oldContractVersionId   = oldEnc837iClmVO.getContractVersionId();
		String oldAdmitDiagCd  		  = oldEnc837iClmVO.getAdmitDiagCd();
		String oldContractCd  		  = oldEnc837iClmVO.getContractCd();
		String oldPrvAcceptAssignCd   = oldEnc837iClmVO.getPrvAcceptAssignCd();
		String oldReleaseOfInfoCd     = oldEnc837iClmVO.getReleaseOfInfoCd();
		String oldAutoAccidentState   = oldEnc837iClmVO.getAutoAccidentState();
		String oldDelayReasonCd  	  = oldEnc837iClmVO.getDelayReasonCd();
		String oldDischargeHour  	  = oldEnc837iClmVO.getDischargeHour();
		String oldSvcAuthExcptCd  	  = oldEnc837iClmVO.getSvcAuthExcptCd();
		String oldStatementFromDt     = oldEnc837iClmVO.getStatementFromDt();
		String oldDrgCd  			  = oldEnc837iClmVO.getDrgCd();
		String oldStatementToDt  	  = oldEnc837iClmVO.getStatementToDt();
		String oldPayerClmCtrlNbr     = oldEnc837iClmVO.getPayerClmCtrlNbr();
		String oldReferralNbr  		  = oldEnc837iClmVO.getReferralNbr();
		String oldPriorAuthNbr  	  = oldEnc837iClmVO.getPriorAuthNbr();
		String oldInvestigDeviceExmptId  = oldEnc837iClmVO.getInvestigDeviceExmptId();
		String oldPeerRevewOrgAprvNbr = oldEnc837iClmVO.getPeerRevewOrgAprvNbr();
		String oldMedicalRecordNbr    = oldEnc837iClmVO.getMedicalRecordNbr();
		String oldDemonstrationProjectId  = oldEnc837iClmVO.getDemonstrationProjectId();
		String oldBillingNotes        = oldEnc837iClmVO.getBillingNotes();
		String oldPatVisitreasType1   = oldEnc837iClmVO.getPatVisitreasType1();
		String oldPatVisitreasCd1     = oldEnc837iClmVO.getPatVisitreasCd1();
		String oldPatVisitreasType2   = oldEnc837iClmVO.getPatVisitreasType2();
		String oldPatVisitreasCd2     = oldEnc837iClmVO.getPatVisitreasCd2();
		String oldPatVisitreasType3   = oldEnc837iClmVO.getPatVisitreasType3();
		String oldPatVisitreasCd3     = oldEnc837iClmVO.getPatVisitreasCd3();
		String oldRepricdClmRefNbr    = oldEnc837iClmVO.getRepricdClmRefNbr();
		String oldAdjRepricdClmRefNbr = oldEnc837iClmVO.getAdjRepricdClmRefNbr();
		String oldRepricedApprvdDrgCd = oldEnc837iClmVO.getRepricedApprvdDrgCd();
		String oldRepricedApprvdRevCd = oldEnc837iClmVO.getRepricedApprvdRevCd();
		String oldRepricerReceivedDt  = oldEnc837iClmVO.getRepricerReceivedDt();
		String oldRepricingOrgId      = oldEnc837iClmVO.getRepricingOrgId();
		String oldRepricedUom         = oldEnc837iClmVO.getRepricedUom();
		String oldRepricedRejReasonCd = oldEnc837iClmVO.getRepricedRejReasonCd();
		String oldRepricedPolCmpliantCd  = oldEnc837iClmVO.getRepricedPolCmpliantCd();
		String oldRepricedExceptionCd = oldEnc837iClmVO.getRepricedExceptionCd();
		//	00370957 - Changes
		String oldClmFreqTypeCd = oldEnc837iClmVO.getClmFreqTypeCd();
		
		String newProcessStatus       = newEnc837iClmVO.getProcessStatus(); 		
		String newSubsHic             = newEnc837iClmVO.getSubsHicNbr();
		String newMbi                 = newEnc837iClmVO.getMbi();
		String newInBillPrvAffilTaxId = newEnc837iClmVO.getInBillPrvAffilTaxId();
		String newClmFacTypeCd        = newEnc837iClmVO.getClmFacTypeCd();
		String newAdmitType           = newEnc837iClmVO.getAdmitType();
		String newAdmitSourceCd       = newEnc837iClmVO.getAdmitSourceCd();
		String newAdmitDt             = newEnc837iClmVO.getAdmitDt();
		String newAdmitHour           = newEnc837iClmVO.getAdmitHour();
		String newPatientStatusCd     = newEnc837iClmVO.getPatientStatusCd();
		String newAmbPickupZip        = newEnc837iClmVO.getAmbPickupZip();
		
		String newPatientCtrlNbr  	  = newEnc837iClmVO.getPatientCtrlNbr();
		String newContractTypeCd  	  = newEnc837iClmVO.getContractTypeCd();
		String newAdmitDiagType  	  = newEnc837iClmVO.getAdmitDiagType();
		String newContractVersionId   = newEnc837iClmVO.getContractVersionId();
		String newAdmitDiagCd  		  = newEnc837iClmVO.getAdmitDiagCd();
		String newContractCd  		  = newEnc837iClmVO.getContractCd();
		String newPrvAcceptAssignCd   = newEnc837iClmVO.getPrvAcceptAssignCd();
		String newReleaseOfInfoCd     = newEnc837iClmVO.getReleaseOfInfoCd();
		String newAutoAccidentState   = newEnc837iClmVO.getAutoAccidentState();
		String newDelayReasonCd  	  = newEnc837iClmVO.getDelayReasonCd();
		String newDischargeHour  	  = newEnc837iClmVO.getDischargeHour();
		String newSvcAuthExcptCd  	  = newEnc837iClmVO.getSvcAuthExcptCd();
		String newStatementFromDt     = newEnc837iClmVO.getStatementFromDt();
		String newDrgCd  			  = newEnc837iClmVO.getDrgCd();
		String newStatementToDt  	  = newEnc837iClmVO.getStatementToDt();
		String newPayerClmCtrlNbr     = newEnc837iClmVO.getPayerClmCtrlNbr();
		String newReferralNbr  		  = newEnc837iClmVO.getReferralNbr();
		String newPriorAuthNbr  	  = newEnc837iClmVO.getPriorAuthNbr();
		String newInvestigDeviceExmptId  = newEnc837iClmVO.getInvestigDeviceExmptId();
		String newPeerRevewOrgAprvNbr = newEnc837iClmVO.getPeerRevewOrgAprvNbr();
		String newMedicalRecordNbr    = newEnc837iClmVO.getMedicalRecordNbr();
		String newDemonstrationProjectId  = newEnc837iClmVO.getDemonstrationProjectId();
		String newBillingNotes        = newEnc837iClmVO.getBillingNotes();
		String newPatVisitreasType1   = newEnc837iClmVO.getPatVisitreasType1();
		String newPatVisitreasCd1     = newEnc837iClmVO.getPatVisitreasCd1();
		String newPatVisitreasType2   = newEnc837iClmVO.getPatVisitreasType2();
		String newPatVisitreasCd2     = newEnc837iClmVO.getPatVisitreasCd2();
		String newPatVisitreasType3   = newEnc837iClmVO.getPatVisitreasType3();
		String newPatVisitreasCd3     = newEnc837iClmVO.getPatVisitreasCd3();
		String newRepricdClmRefNbr    = newEnc837iClmVO.getRepricdClmRefNbr();
		String newAdjRepricdClmRefNbr = newEnc837iClmVO.getAdjRepricdClmRefNbr();
		String newRepricedApprvdDrgCd = newEnc837iClmVO.getRepricedApprvdDrgCd();
		String newRepricedApprvdRevCd = newEnc837iClmVO.getRepricedApprvdRevCd();
		String newRepricerReceivedDt  = newEnc837iClmVO.getRepricerReceivedDt();
		String newRepricingOrgId      = newEnc837iClmVO.getRepricingOrgId();
		String newRepricedUom         = newEnc837iClmVO.getRepricedUom();
		String newRepricedRejReasonCd = newEnc837iClmVO.getRepricedRejReasonCd();
		String newRepricedPolCmpliantCd  = newEnc837iClmVO.getRepricedPolCmpliantCd();
		String newRepricedExceptionCd = newEnc837iClmVO.getRepricedExceptionCd();
		//	00370957 - Changes
		String newClmFreqTypeCd = newEnc837iClmVO.getClmFreqTypeCd();
		
		int sqlCnt = -1;

		String fieldName = "";
		String tableName = "ENC_837I_CLM";

		boolean dataChanged = false;			
		boolean statusChanged = false;
		
		try {												
				    	
			if(!(newProcessStatus.equals(oldProcessStatus))){
				
				Enc837iClmStatlogVO enc837iClmStatlogVO = new Enc837iClmStatlogVO();
				enc837iClmStatlogVO.setMfId(oldEnc837iClmVO.getMfId());
				enc837iClmStatlogVO.setWtxClaimRefNbr(oldEnc837iClmVO.getWtxClaimRefNbr());
				enc837iClmStatlogVO.setWtxClaimRevNbr(oldEnc837iClmVO.getWtxClaimRevNbr());
				enc837iClmStatlogVO.setClmSeqNbr(oldEnc837iClmVO.getClmSeqNbr());
				enc837iClmStatlogVO.setClaimType(oldEnc837iClmVO.getClaimType());
				enc837iClmStatlogVO.setClmStatus(newProcessStatus);
				enc837iClmStatlogVO.setComment("");
				enc837iClmStatlogVO.setLastUpdtUserid(userId);
				
			    sqlCnt = ChartEncounterDao.insertInstClmStatlog(conn, enc837iClmStatlogVO);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }	
			    
		    	fieldName = "PROCESS_STATUS";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldProcessStatus, newProcessStatus,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		    
			    dataChanged = true;
			    statusChanged = true;
			}

			if(!(newSubsHic.equals(oldSubsHic))){
		    	
				fieldName = "SUBS_HIC_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSubsHic, newSubsHic,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			
           if(!(newMbi.equals(oldMbi))){
		    	
					fieldName = "MBI";
			   /*While updating MBI,if mbi previous is null, get previous value from subscriber section */
					if(oldMbi == null && !(oldMbiSubs == null)){
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldMbiSubs, newMbi, userId, clmType);
	          /*While updating MBI,if mbi previous is null, get previous value from subscriber section */
					}else{
						sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldMbiSubs, newMbi, userId, clmType); 
					}
				    if (sqlCnt != 1) {
				    	throw new Exception();
				    }				
			
				    dataChanged = true;
				}
			

			if(!(newInBillPrvAffilTaxId.equals(oldInBillPrvAffilTaxId))){
		    	
				fieldName = "IN_BILL_PRV_AFFIL_TAX_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldInBillPrvAffilTaxId, newInBillPrvAffilTaxId,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			
			if(!(newClmFacTypeCd.equals(oldClmFacTypeCd))){
		    	
				fieldName = "CLM_FAC_TYPE_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmFacTypeCd, newClmFacTypeCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newAdmitType.equals(oldAdmitType))){
		    	
				fieldName = "ADMIT_TYPE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAdmitType, newAdmitType,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
		   
			if(!(newAdmitSourceCd.equals(oldAdmitSourceCd))){
		    	
				fieldName = "ADMIT_SOURCE_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAdmitSourceCd, newAdmitSourceCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newAdmitDt.equals(oldAdmitDt))){
		    	
				fieldName = "ADMIT_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAdmitDt, newAdmitDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newAdmitHour.equals(oldAdmitHour))){
		    	
				fieldName = "ADMIT_HOUR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAdmitHour, newAdmitHour,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newPatientStatusCd.equals(oldPatientStatusCd))){
		    	
				fieldName = "PATIENT_STATUS_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPatientStatusCd, newPatientStatusCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newAmbPickupZip.equals(oldAmbPickupZip))){
		    	
				fieldName = "AMB_PICKUP_ZIP";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbPickupZip, newAmbPickupZip,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			
			if(!(newPatientCtrlNbr.equals(oldPatientCtrlNbr))){
		    	
				fieldName = "PATIENT_CTRL_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPatientCtrlNbr, newPatientCtrlNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newContractTypeCd.equals(oldContractTypeCd))){
		    	
				fieldName = "CONTRACT_TYPE_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldContractTypeCd, newContractTypeCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		    
			    dataChanged = true;
			}
			
			if(!(newAdmitDiagType.equals(oldAdmitDiagType))){
		    	
				fieldName = "ADMIT_DIAG_TYPE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAdmitDiagType, newAdmitDiagType,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			
			if(!(newContractVersionId.equals(oldContractVersionId))){
		    	
				fieldName = "CONTRACT_VERSION_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldContractVersionId, newContractVersionId,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newAdmitDiagCd.equals(oldAdmitDiagCd))){
		    	
				fieldName = "ADMIT_DIAG_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAdmitDiagCd, newAdmitDiagCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newContractCd.equals(oldContractCd))){
		    	
				fieldName = "CONTRACT_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldContractCd, newContractCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newPrvAcceptAssignCd.equals(oldPrvAcceptAssignCd))){
		    	
				fieldName = "PRV_ACCEPT_ASSIGN_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPrvAcceptAssignCd, newPrvAcceptAssignCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newReleaseOfInfoCd.equals(oldReleaseOfInfoCd))){
		    	
				fieldName = "RELEASE_OF_INFO_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldReleaseOfInfoCd, newReleaseOfInfoCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newAutoAccidentState.equals(oldAutoAccidentState))){
		    	
				fieldName = "AUTO_ACCIDENT_STATE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAutoAccidentState, newAutoAccidentState,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newDelayReasonCd.equals(oldDelayReasonCd))){
		    	
				fieldName = "DELAY_REASON_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldDelayReasonCd, newDelayReasonCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			
			if(!(newDischargeHour.equals(oldDischargeHour))){
		    	
				fieldName = "DISCHARGE_HOUR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldDischargeHour, newDischargeHour,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newSvcAuthExcptCd.equals(oldSvcAuthExcptCd))){
		    	
				fieldName = "SVC_AUTH_EXCPT_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSvcAuthExcptCd, newSvcAuthExcptCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newStatementFromDt.equals(oldStatementFromDt))){
		    	
				fieldName = "STATEMENT_FROM_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldStatementFromDt, newStatementFromDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newDrgCd.equals(oldDrgCd))){
		    	
				fieldName = "DRG_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldDrgCd, newDrgCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			
			if(!(newStatementToDt.equals(oldStatementToDt))){
		    	
				fieldName = "STATEMENT_TO_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldStatementToDt, newStatementToDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newPayerClmCtrlNbr.equals(oldPayerClmCtrlNbr))){
		    	
				fieldName = "PAYER_CLM_CTRL_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerClmCtrlNbr, newPayerClmCtrlNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newReferralNbr.equals(oldReferralNbr))){
		    	
				fieldName = "REFERRAL_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldReferralNbr, newReferralNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newPriorAuthNbr.equals(oldPriorAuthNbr))){
		    	
				fieldName = "PRIOR_AUTH_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPriorAuthNbr, newPriorAuthNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newInvestigDeviceExmptId.equals(oldInvestigDeviceExmptId))){
		    	
				fieldName = "INVESTIG_DEVICE_EXMPT_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldInvestigDeviceExmptId, newInvestigDeviceExmptId,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newPeerRevewOrgAprvNbr.equals(oldPeerRevewOrgAprvNbr))){
		    	
				fieldName = "PEER_REVEW_ORG_APRV_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPeerRevewOrgAprvNbr, newPeerRevewOrgAprvNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			
			if(!(newMedicalRecordNbr.equals(oldMedicalRecordNbr))){
		    	
				fieldName = "MEDICAL_RECORD_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldMedicalRecordNbr, newMedicalRecordNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newDemonstrationProjectId.equals(oldDemonstrationProjectId))){
		    	
				fieldName = "DEMONSTRATION_PROJECT_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldDemonstrationProjectId, newDemonstrationProjectId,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newBillingNotes.equals(oldBillingNotes))){
		    	
				fieldName = "BILLING_NOTES";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillingNotes, newBillingNotes,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newPatVisitreasType1.equals(oldPatVisitreasType1))){
		    	
				fieldName = "PAT_VISITREAS_TYPE1";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPatVisitreasType1, newPatVisitreasType1,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newPatVisitreasCd1.equals(oldPatVisitreasCd1))){
		    	
				fieldName = "PAT_VISITREAS_CD1";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPatVisitreasCd1, newPatVisitreasCd1,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newPatVisitreasType2.equals(oldPatVisitreasType2))){
		    	
				fieldName = "PAT_VISITREAS_TYPE2";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPatVisitreasType2, newPatVisitreasType2,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newPatVisitreasCd2.equals(oldPatVisitreasCd2))){
		    	
				fieldName = "PAT_VISITREAS_CD2";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPatVisitreasCd2, newPatVisitreasCd2,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newPatVisitreasType3.equals(oldPatVisitreasType3))){
		    	
				fieldName = "PAT_VISITREAS_TYPE3";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPatVisitreasType3, newPatVisitreasType3,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newPatVisitreasCd3.equals(oldPatVisitreasCd3))){
		    	
				fieldName = "PAT_VISITREAS_CD3";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPatVisitreasCd3, newPatVisitreasCd3,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newRepricdClmRefNbr.equals(oldRepricdClmRefNbr))){
		    	
				fieldName = "REPRICD_CLM_REF_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldRepricdClmRefNbr, newRepricdClmRefNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newAdjRepricdClmRefNbr.equals(oldAdjRepricdClmRefNbr))){
		    	
				fieldName = "ADJ_REPRICD_CLM_REF_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAdjRepricdClmRefNbr, newAdjRepricdClmRefNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newRepricedApprvdDrgCd.equals(oldRepricedApprvdDrgCd))){
		    	
				fieldName = "REPRICED_APPRVD_DRG_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldRepricedApprvdDrgCd, newRepricedApprvdDrgCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newRepricedApprvdRevCd.equals(oldRepricedApprvdRevCd))){
		    	
				fieldName = "REPRICED_APPRVD_REV_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldRepricedApprvdRevCd, newRepricedApprvdRevCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newRepricerReceivedDt.equals(oldRepricerReceivedDt))){
		    	
				fieldName = "REPRICER_RECEIVED_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldRepricerReceivedDt, newRepricerReceivedDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newRepricingOrgId.equals(oldRepricingOrgId))){
		    	
				fieldName = "REPRICING_ORG_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldRepricingOrgId, newRepricingOrgId,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newRepricedUom.equals(oldRepricedUom))){
		    	
				fieldName = "REPRICED_UOM";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldRepricedUom, newRepricedUom,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newRepricedRejReasonCd.equals(oldRepricedRejReasonCd))){
		    	
				fieldName = "REPRICED_REJ_REASON_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldRepricedRejReasonCd, newRepricedRejReasonCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newRepricedPolCmpliantCd.equals(oldRepricedPolCmpliantCd))){
		    	
				fieldName = "REPRICED_POL_CMPLIANT_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldRepricedPolCmpliantCd, newRepricedPolCmpliantCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(newRepricedExceptionCd.equals(oldRepricedExceptionCd))){
		    	
				fieldName = "REPRICED_EXCEPTION_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldRepricedExceptionCd, newRepricedExceptionCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			//00370957 - Changes
			if(!(newClmFreqTypeCd.equals(oldClmFreqTypeCd))){
		    	
				fieldName = "CLM_FREQ_TYPE_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId,recordKey, tableName, fieldName, oldClmFreqTypeCd, newClmFreqTypeCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			
			if (dataChanged) {				
									
				encounterVO.setInstClaimDirty(true);
				
				sqlCnt = ChartEncounterDao.updateInstClaim(conn, newEnc837iClmVO);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    if (statusChanged) {
			    	updateStatSum(conn,"I",mfId,oldEnc837iClmVO.getInIntrchgSndrId(), 
			    			      oldEnc837iClmVO.getTransFileDt(), oldEnc837iClmVO.getStatementFromDt(), 
								  oldProcessStatus,newProcessStatus,userId,clmType);
			    }
			}
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			message = "Error Updating Institutional Claim Data";
			logger.debug(e.getMessage());
		} 
		logger.info(LoggerConstants.methodEndLevel());
		return message;									
		
		}				
		
	public String updateProfClaim(Connection conn, HPEEncounterVO encounterVO, Enc837pClmVO newEnc837pClmVO) throws ApplicationException {		
		logger.info(LoggerConstants.methodStartLevel());
		String message = "";
		
		// Retrieve DAO
		ChartEncounterDao ChartEncounterDao = new ChartEncounterDao();		

		String mfId = encounterVO.getMfId();
		String userId = encounterVO.getUserId();
		String clmType = encounterVO.getSearchDetailClmType();
		
		Enc837pSubsVO oldProfSubs = encounterVO.getProfSubscriber();
		Enc837pClmVO oldEnc837pClmVO = encounterVO.getProfClaim();		
		String recordKey = ChartEncounterDao.getClaimChangeLogRecordKey(oldEnc837pClmVO);
		ChartEncounterDao.setClaimDetailString(oldEnc837pClmVO.getWtxClaimRefNbr() + "|" + oldEnc837pClmVO.getWtxClaimRevNbr() + "|" +oldEnc837pClmVO.getClmSeqNbr());
		
		String oldProcessStatus       = oldEnc837pClmVO.getProcessStatus(); 				
		String oldPlaceOfService      = oldEnc837pClmVO.getPlaceOfService(); 				
		String oldSubsHic             = oldEnc837pClmVO.getSubsHicNbr();
		String oldMbiSubs             = oldProfSubs.getMbi();
		String oldMbi                 = oldEnc837pClmVO.getMbi();
		String oldInBillPrvAffilTaxId = oldEnc837pClmVO.getInBillPrvAffilTaxId();
		String oldMammogramCertNbr    = oldEnc837pClmVO.getMammogramCertNbr();
		String oldCliaNbr             = oldEnc837pClmVO.getCliaNbr();
		String oldHospAdmitDt         = oldEnc837pClmVO.getHospAdmitDt();
		String oldHospDischargeDt     = oldEnc837pClmVO.getHospDischargeDt();
		String oldAmbPickupAddrLine1  = oldEnc837pClmVO.getAmbPickupAddrLine1();
		String oldAmbPickupAddrLine2  = oldEnc837pClmVO.getAmbPickupAddrLine2();
		String oldAmbPickupCity       = oldEnc837pClmVO.getAmbPickupCity();
		String oldAmbPickupState      = oldEnc837pClmVO.getAmbPickupState();
		String oldAmbPickupZip        = oldEnc837pClmVO.getAmbPickupZip();
		String oldAmbDropoffLoc       = oldEnc837pClmVO.getAmbDropoffLoc();
		String oldAmbDropoffAddrLine1 = oldEnc837pClmVO.getAmbDropoffAddrLine1();
		String oldAmbDropoffAddrLine2 = oldEnc837pClmVO.getAmbDropoffAddrLine2();
		String oldAmbDropoffCity      = oldEnc837pClmVO.getAmbDropoffCity();
		String oldAmbDropoffState     = oldEnc837pClmVO.getAmbDropoffState();
		String oldAmbDropoffZip       = oldEnc837pClmVO.getAmbDropoffZip();
		//old claim fields..
		String oldPatientCtrlNbr = oldEnc837pClmVO.getPatientCtrlNbr();
		String oldWtxClaimRefNbr = oldEnc837pClmVO.getWtxClaimRefNbr();
		String oldContractVersionId = oldEnc837pClmVO.getContractVersionId();
		String oldContractCd = oldEnc837pClmVO.getContractCd();
		String oldSvcFacContactName = oldEnc837pClmVO.getSvcFacContactName();
		String oldSvcFacPhone = oldEnc837pClmVO.getSvcFacPhone();
		String oldSvcFacPhoneExt = oldEnc837pClmVO.getSvcFacPhoneExt();
		String oldSvcAuthExcptCd = oldEnc837pClmVO.getSvcAuthExcptCd();
		String oldAnestSurgProcCd1 = oldEnc837pClmVO.getAnestSurgProcCd1();
		String oldAnestSurgProcCd2 = oldEnc837pClmVO.getAnestSurgProcCd2();
		String oldVisnCertCondInd = oldEnc837pClmVO.getVisnCertCondInd();
		String oldAutoAccidentCountry = oldEnc837pClmVO.getAutoAccidentCountry();
		String oldClaimRefCd = oldEnc837pClmVO.getClaimRefCd();
		String oldPatSignatureSrcCd = oldEnc837pClmVO.getPatSignatureSrcCd();
		String oldMedicareCrossoverCd = oldEnc837pClmVO.getMedicareCrossoverCd();
		String oldLabHomeRespCd = oldEnc837pClmVO.getLabHomeRespCd();
		String oldLabHomeCondInd = oldEnc837pClmVO.getLabHomeCondInd();
		String oldVisnCodeCategory = oldEnc837pClmVO.getVisnCodeCategory();
		String oldContractTypeCd = oldEnc837pClmVO.getContractTypeCd();
		String oldPrvAcceptAssignCd = oldEnc837pClmVO.getPrvAcceptAssignCd();
		String oldReleaseOfInfoCd = oldEnc837pClmVO.getReleaseOfInfoCd();
		String oldAutoAccidentState = oldEnc837pClmVO.getAutoAccidentState();
		String oldOtherAccidentInd = oldEnc837pClmVO.getOtherAccidentInd();
		String oldPrvSignatureOnfileInd = oldEnc837pClmVO.getPrvSignatureOnfileInd();
		String oldDelayReasonCd = oldEnc837pClmVO.getDelayReasonCd();
		String oldBeneAssignCertInd = oldEnc837pClmVO.getBeneAssignCertInd();
		String oldVisnCertCondCd1 = oldEnc837pClmVO.getVisnCertCondCd1();
		String oldVisnCertCondCd2 = oldEnc837pClmVO.getVisnCertCondCd2();
		String oldVisnCertCondCd3 = oldEnc837pClmVO.getVisnCertCondCd3();
		int oldWtxClaimRevNbr = oldEnc837pClmVO.getWtxClaimRevNbr();
		String oldClmFreqTypeCd = oldEnc837pClmVO.getClmFreqTypeCd();
		String oldEmploymentAccidentInd = oldEnc837pClmVO.getEmploymentAccidentInd();
		String oldAutoAccidentInd = oldEnc837pClmVO.getAutoAccidentInd();
		String oldEpsdtCondInd1 = oldEnc837pClmVO.getEpsdtCondInd1();
		String oldEpsdtCondInd2 = oldEnc837pClmVO.getEpsdtCondInd2();
		String oldEpsdtCondInd3 = oldEnc837pClmVO.getEpsdtCondInd3();
		String oldVisnCertCondCd4 = oldEnc837pClmVO.getVisnCertCondCd4();
		String oldVisnCertCondCd5 = oldEnc837pClmVO.getVisnCertCondCd5();
		String oldPayerClmCtrlNbr = oldEnc837pClmVO.getPayerClmCtrlNbr();
		String oldPriorAuthNbr = oldEnc837pClmVO.getPriorAuthNbr();
		String oldValueAddNtwkTraceNbr = oldEnc837pClmVO.getValueAddNtwkTraceNbr();
		String oldCarePlanOversightNbr = oldEnc837pClmVO.getCarePlanOversightNbr();
		String oldClaimNotes = oldEnc837pClmVO.getClaimNotes();
		String oldReferralNbr = oldEnc837pClmVO.getReferralNbr();
		String oldInvestigDeviceExempId = oldEnc837pClmVO.getInvestigDeviceExempId();
		String oldMedicalRecordNbr = oldEnc837pClmVO.getMedicalRecordNbr();
		String oldDemonstrationProjId = oldEnc837pClmVO.getDemonstrationProjId();
		String oldIllnessOccurDt = oldEnc837pClmVO.getIllnessOccurDt();
		String oldLastMenstrualPerDt = oldEnc837pClmVO.getLastMenstrualPerDt();
		String oldDisabilityStartDt = oldEnc837pClmVO.getDisabilityStartDt();
		String oldAsumdCareStartDt =  oldEnc837pClmVO.getAsumdCareStartDt();
		String oldPatientCondCd = oldEnc837pClmVO.getPatientCondCd();
		String oldInitialTreatmentDt = oldEnc837pClmVO.getInitialTreatmentDt();
		String oldLastXrayDt = oldEnc837pClmVO.getLastXrayDt();
		String oldDisabilityEndDt = oldEnc837pClmVO.getDisabilityEndDt();
		String oldAsumdCareEndDt = oldEnc837pClmVO.getAsumdCareEndDt();
		String oldLastSeenDt = oldEnc837pClmVO.getLastSeenDt();
		String oldHearVisionDt = oldEnc837pClmVO.getHearVisionDt();
		String oldLastWorkedDt = oldEnc837pClmVO.getLastWorkedDt();
		String oldFirstVisitConsultDt = oldEnc837pClmVO.getFirstVisitConsultDt();
		String oldAcuteManifestationDt = oldEnc837pClmVO.getAcuteManifestationDt();
		String oldAuthReturnWorkDt = oldEnc837pClmVO.getAuthReturnWorkDt();
		String oldAccidentDt= oldEnc837pClmVO.getAccidentDt();
		String oldRoundTripPurposeDesc = oldEnc837pClmVO.getRoundTripPurposeDesc();
		String oldStretcherPurposeDesc = oldEnc837pClmVO.getStretcherPurposeDesc();
		String oldAmbPatWeight = oldEnc837pClmVO.getAmbPatWeight();
		String oldAmbCertCondInd = oldEnc837pClmVO.getAmbCertCondInd();
		String oldAmbPickupCountry = oldEnc837pClmVO.getAmbPickupCountry();
		String oldAmbCertCondCd1 = oldEnc837pClmVO.getAmbCertCondCd1();
		String oldAmbCertCondCd2 = oldEnc837pClmVO.getAmbCertCondCd2();
		String oldAmbCertCondCd3 = oldEnc837pClmVO.getAmbCertCondCd3();
		String oldAmbDropoffCountry = oldEnc837pClmVO.getAmbDropoffCountry();
		String oldAmbTranspDistance = oldEnc837pClmVO.getAmbTranspDistance();
		String oldAmbTranspReasonCd = oldEnc837pClmVO.getAmbTranspReasonCd();
		String oldAmbPickupCntrySubd = oldEnc837pClmVO.getAmbPickupCntrySubd();
		String oldAmbCertCondCd4 = oldEnc837pClmVO.getAmbCertCondCd4();
		String oldAmbCertCondCd5 = oldEnc837pClmVO.getAmbCertCondCd5();
		String oldAmbDropoffCntrySubd = oldEnc837pClmVO.getAmbDropoffCntrySubd();
		
		// old claim feilds end...
		String newProcessStatus       = newEnc837pClmVO.getProcessStatus();		
		String newPlaceOfService      = newEnc837pClmVO.getPlaceOfService(); 
		String newSubsHic             = newEnc837pClmVO.getSubsHicNbr();
		String newMbi                    = newEnc837pClmVO.getMbi();
		String newInBillPrvAffilTaxId = newEnc837pClmVO.getInBillPrvAffilTaxId();
		String newMammogramCertNbr    = newEnc837pClmVO.getMammogramCertNbr();
		String newCliaNbr             = newEnc837pClmVO.getCliaNbr();
		String newHospAdmitDt         = newEnc837pClmVO.getHospAdmitDt();
		String newHospDischargeDt     = newEnc837pClmVO.getHospDischargeDt();
		String newAmbPickupAddrLine1  = newEnc837pClmVO.getAmbPickupAddrLine1();
		String newAmbPickupAddrLine2  = newEnc837pClmVO.getAmbPickupAddrLine2();
		String newAmbPickupCity       = newEnc837pClmVO.getAmbPickupCity();
		String newAmbPickupState      = newEnc837pClmVO.getAmbPickupState();
		String newAmbPickupZip        = newEnc837pClmVO.getAmbPickupZip();
		String newAmbDropoffLoc       = newEnc837pClmVO.getAmbDropoffLoc();
		String newAmbDropoffAddrLine1 = newEnc837pClmVO.getAmbDropoffAddrLine1();
		String newAmbDropoffAddrLine2 = newEnc837pClmVO.getAmbDropoffAddrLine2();
		String newAmbDropoffCity      = newEnc837pClmVO.getAmbDropoffCity();
		String newAmbDropoffState     = newEnc837pClmVO.getAmbDropoffState();
		String newAmbDropoffZip       = newEnc837pClmVO.getAmbDropoffZip();
		
		//new Claim feilds..

		String newPatientCtrlNbr = newEnc837pClmVO.getPatientCtrlNbr();
		String newWtxClaimRefNbr = newEnc837pClmVO.getWtxClaimRefNbr();
		String newContractVersionId = newEnc837pClmVO.getContractVersionId();
		String newContractCd = newEnc837pClmVO.getContractCd();
		String newSvcFacContactName = newEnc837pClmVO.getSvcFacContactName();
		String newSvcFacPhone = newEnc837pClmVO.getSvcFacPhone();
		String newSvcFacPhoneExt = newEnc837pClmVO.getSvcFacPhoneExt();
		String newSvcAuthExcptCd = newEnc837pClmVO.getSvcAuthExcptCd();
		String newAnestSurgProcCd1 = newEnc837pClmVO.getAnestSurgProcCd1();
		String newAnestSurgProcCd2 = newEnc837pClmVO.getAnestSurgProcCd2();
		String newVisnCertCondInd = newEnc837pClmVO.getVisnCertCondInd();
		String newAutoAccidentCountry = newEnc837pClmVO.getAutoAccidentCountry();
		String newClaimRefCd = newEnc837pClmVO.getClaimRefCd();
		String newPatSignatureSrcCd = newEnc837pClmVO.getPatSignatureSrcCd();
		String newMedicareCrossoverCd = newEnc837pClmVO.getMedicareCrossoverCd();
		String newLabHomeRespCd = newEnc837pClmVO.getLabHomeRespCd();
		String newLabHomeCondInd = newEnc837pClmVO.getLabHomeCondInd();
		String newVisnCodeCategory = newEnc837pClmVO.getVisnCodeCategory();
		String newContractTypeCd = newEnc837pClmVO.getContractTypeCd();
		String newPrvAcceptAssignCd = newEnc837pClmVO.getPrvAcceptAssignCd();
		String newReleaseOfInfoCd = newEnc837pClmVO.getReleaseOfInfoCd();
		String newAutoAccidentState = newEnc837pClmVO.getAutoAccidentState();
		String newOtherAccidentInd = newEnc837pClmVO.getOtherAccidentInd();
		String newPrvSignatureOnfileInd = newEnc837pClmVO.getPrvSignatureOnfileInd();
		String newDelayReasonCd = newEnc837pClmVO.getDelayReasonCd();
		String newBeneAssignCertInd = newEnc837pClmVO.getBeneAssignCertInd();
		String newVisnCertCondCd1 = newEnc837pClmVO.getVisnCertCondCd1();
		String newVisnCertCondCd2 = newEnc837pClmVO.getVisnCertCondCd2();
		String newVisnCertCondCd3 = newEnc837pClmVO.getVisnCertCondCd3();
		int newWtxClaimRevNbr = newEnc837pClmVO.getWtxClaimRevNbr();
		String newClmFreqTypeCd = newEnc837pClmVO.getClmFreqTypeCd();
		String newEmploymentAccidentInd = newEnc837pClmVO.getEmploymentAccidentInd();
		String newAutoAccidentInd = newEnc837pClmVO.getAutoAccidentInd();
		String newEpsdtCondInd1 = newEnc837pClmVO.getEpsdtCondInd1();
		String newEpsdtCondInd2 = newEnc837pClmVO.getEpsdtCondInd2();
		String newEpsdtCondInd3 = newEnc837pClmVO.getEpsdtCondInd3();
		String newVisnCertCondCd4 = newEnc837pClmVO.getVisnCertCondCd4();
		String newVisnCertCondCd5 = newEnc837pClmVO.getVisnCertCondCd5();
		String newPayerClmCtrlNbr = newEnc837pClmVO.getPayerClmCtrlNbr();
		String newPriorAuthNbr = newEnc837pClmVO.getPriorAuthNbr();
		String newValueAddNtwkTraceNbr = newEnc837pClmVO.getValueAddNtwkTraceNbr();
		String newCarePlanOversightNbr = newEnc837pClmVO.getCarePlanOversightNbr();
		String newClaimNotes = newEnc837pClmVO.getClaimNotes();
		String newReferralNbr = newEnc837pClmVO.getReferralNbr();
		String newInvestigDeviceExempId = newEnc837pClmVO.getInvestigDeviceExempId();
		String newMedicalRecordNbr = newEnc837pClmVO.getMedicalRecordNbr();
		String newDemonstrationProjId = newEnc837pClmVO.getDemonstrationProjId();
		String newIllnessOccurDt = newEnc837pClmVO.getIllnessOccurDt();
		String newLastMenstrualPerDt = newEnc837pClmVO.getLastMenstrualPerDt();
		String newDisabilityStartDt = newEnc837pClmVO.getDisabilityStartDt();
		String newAsumdCareStartDt =  newEnc837pClmVO.getAsumdCareStartDt();
		String newPatientCondCd = newEnc837pClmVO.getPatientCondCd();
		String newInitialTreatmentDt = newEnc837pClmVO.getInitialTreatmentDt();
		String newLastXrayDt = newEnc837pClmVO.getLastXrayDt();
		String newDisabilityEndDt = newEnc837pClmVO.getDisabilityEndDt();
		String newAsumdCareEndDt = newEnc837pClmVO.getAsumdCareEndDt();
		String newLastSeenDt = newEnc837pClmVO.getLastSeenDt();
		String newHearVisionDt = newEnc837pClmVO.getHearVisionDt();
		String newLastWorkedDt = newEnc837pClmVO.getLastWorkedDt();
		String newFirstVisitConsultDt = newEnc837pClmVO.getFirstVisitConsultDt();
		String newAcuteManifestationDt = newEnc837pClmVO.getAcuteManifestationDt();
		String newAuthReturnWorkDt = newEnc837pClmVO.getAuthReturnWorkDt();
		String newAccidentDt= newEnc837pClmVO.getAccidentDt();
		String newRoundTripPurposeDesc = newEnc837pClmVO.getRoundTripPurposeDesc();
		String newStretcherPurposeDesc = newEnc837pClmVO.getStretcherPurposeDesc();
		String newAmbPatWeight = newEnc837pClmVO.getAmbPatWeight();
		String newAmbCertCondInd = newEnc837pClmVO.getAmbCertCondInd();
		String newAmbPickupCountry = newEnc837pClmVO.getAmbPickupCountry();
		String newAmbCertCondCd1 = newEnc837pClmVO.getAmbCertCondCd1();
		String newAmbCertCondCd2 = newEnc837pClmVO.getAmbCertCondCd2();
		String newAmbCertCondCd3 = newEnc837pClmVO.getAmbCertCondCd3();
		String newAmbDropoffCountry = newEnc837pClmVO.getAmbDropoffCountry();
		String newAmbTranspDistance = newEnc837pClmVO.getAmbTranspDistance();
		String newAmbTranspReasonCd = newEnc837pClmVO.getAmbTranspReasonCd();
		String newAmbPickupCntrySubd = newEnc837pClmVO.getAmbPickupCntrySubd();
		String newAmbCertCondCd4 = newEnc837pClmVO.getAmbCertCondCd4();
		String newAmbCertCondCd5 = newEnc837pClmVO.getAmbCertCondCd5();
		String newAmbDropoffCntrySubd = newEnc837pClmVO.getAmbDropoffCntrySubd();
		//end of new Claim feilds...
		
		int sqlCnt = -1;

		String fieldName = "";
		String tableName = "ENC_837P_CLM";
		boolean dataChanged = false;	
		boolean statusChanged = false;
		
		try {		

			if(!(newProcessStatus.equals(oldProcessStatus))){
				
				Enc837pClmStatlogVO enc837pClmStatlogVO = new Enc837pClmStatlogVO();
				enc837pClmStatlogVO.setMfId(oldEnc837pClmVO.getMfId());
				enc837pClmStatlogVO.setWtxClaimRefNbr(oldEnc837pClmVO.getWtxClaimRefNbr());
				enc837pClmStatlogVO.setWtxClaimRevNbr(oldEnc837pClmVO.getWtxClaimRevNbr());
				enc837pClmStatlogVO.setClmSeqNbr(oldEnc837pClmVO.getClmSeqNbr());
				enc837pClmStatlogVO.setClaimType(oldEnc837pClmVO.getClaimType());
				enc837pClmStatlogVO.setClmStatus(newProcessStatus);
				enc837pClmStatlogVO.setComment("");
				enc837pClmStatlogVO.setLastUpdtUserid(userId);
				
			    sqlCnt = ChartEncounterDao.insertProfClmStatlog(conn, enc837pClmStatlogVO);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }	
			    
		    	fieldName = "PROCESS_STATUS";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldProcessStatus, newProcessStatus,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		    
			    dataChanged = true;
			    statusChanged = true;
			}

			if(!(newPlaceOfService.equals(oldPlaceOfService))){
		    	
				fieldName = "PLACE_OF_SERVICE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldProcessStatus, newProcessStatus,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newSubsHic.equals(oldSubsHic))){
		    	
				fieldName = "SUBS_HIC_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldProcessStatus, newProcessStatus,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			
           if(!(newMbi.equals(oldMbi))){
		    	
				fieldName = "MBI";
				if(oldMbi==null && !(oldMbiSubs == null)){
					sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId,recordKey, tableName, fieldName, oldMbiSubs, newMbi, userId,clmType); 
				}else{
					sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId,recordKey, tableName, fieldName, oldMbiSubs, newMbi, userId,clmType);  
				}
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			
			if(!(newInBillPrvAffilTaxId.equals(oldInBillPrvAffilTaxId))){
		    	
				fieldName = "IN_BILL_PRV_AFFIL_TAX_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldInBillPrvAffilTaxId, newInBillPrvAffilTaxId,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newMammogramCertNbr.equals(oldMammogramCertNbr))){
		    	
				fieldName = "MAMMOGRAM_CERT_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldMammogramCertNbr, newMammogramCertNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newCliaNbr.equals(oldCliaNbr))){
		    	
				fieldName = "CLIA_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldCliaNbr, newCliaNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newHospAdmitDt.equals(oldHospAdmitDt))){
		    	
				fieldName = "HOSP_ADMIT_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldHospAdmitDt, newHospAdmitDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newHospDischargeDt.equals(oldHospDischargeDt))){
		    	
				fieldName = "HOSP_DISCHARGE_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldHospDischargeDt, newHospDischargeDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newAmbPickupAddrLine1.equals(oldAmbPickupAddrLine1))){
		    	
				fieldName = "AMB_PICKUP_ADDR_LINE1";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbPickupAddrLine1, newAmbPickupAddrLine1,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newAmbPickupAddrLine2.equals(oldAmbPickupAddrLine2))){
		    	
				fieldName = "AMB_PICKUP_ADDR_LINE2";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbPickupAddrLine2, newAmbPickupAddrLine2,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newAmbPickupCity.equals(oldAmbPickupCity))){
		    	
				fieldName = "AMB_PICKUP_CITY";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbPickupCity, newAmbPickupCity,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newAmbPickupState.equals(oldAmbPickupState))){
		    	
				fieldName = "AMB_PICKUP_STATE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbPickupState, newAmbPickupState,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newAmbPickupZip.equals(oldAmbPickupZip))){
		    	
				fieldName = "AMB_PICKUP_ZIP";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbPickupZip, newAmbPickupZip,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newAmbDropoffLoc.equals(oldAmbDropoffLoc))){
		    	
				fieldName = "AMB_DROPOFF_LOC";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbDropoffLoc, newAmbDropoffLoc,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newAmbDropoffAddrLine1.equals(oldAmbDropoffAddrLine1))){
		    	
				fieldName = "AMB_DROPOFF_ADDR_LINE1";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbDropoffAddrLine1, newAmbDropoffAddrLine1,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newAmbDropoffAddrLine2.equals(oldAmbDropoffAddrLine2))){
		    	
				fieldName = "AMB_DROPOFF_ADDR_LINE2";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbDropoffAddrLine2, newAmbDropoffAddrLine2,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newAmbDropoffCity.equals(oldAmbDropoffCity))){
		    	
				fieldName = "AMB_DROPOFF_CITY";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbDropoffCity, newAmbDropoffCity,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newAmbDropoffState.equals(oldAmbDropoffState))){
		    	
				fieldName = "AMB_DROPOFF_STATE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbDropoffState, newAmbDropoffState,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}

			if(!(newAmbDropoffZip.equals(oldAmbDropoffZip))){
		    	
				fieldName = "AMB_DROPOFF_ZIP";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbDropoffZip, newAmbDropoffZip,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			

			if(!(newPatientCtrlNbr.equals(oldPatientCtrlNbr))){
		    	
				fieldName = "PATIENT_CTRL_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPatientCtrlNbr, newPatientCtrlNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
//			if(!(newWtxClaimRefNbr.equals(oldWtxClaimRefNbr))){
//		    	
//				fieldName = "WTX_CLAIM_REF_NBR";
//			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldWtxClaimRefNbr, newWtxClaimRefNbr,userId);    
//			    if (sqlCnt != 1) {
//			    	throw new Exception();
//			    }				
//
//			    dataChanged = true;
//			}
			if(!(newContractVersionId.equals(oldContractVersionId))){
		    	
				fieldName = "CONTRACT_VERSION_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldContractVersionId, newContractVersionId,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newContractCd.equals(oldContractCd))){
		    	
				fieldName = "CONTRACT_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldContractCd, newContractCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newSvcFacPhone.equals(oldSvcFacPhone))){
		    	
				fieldName = "AMB_DROPOFF_ZIP";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSvcFacPhone, newSvcFacPhone,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newAmbDropoffZip.equals(oldAmbDropoffZip))){
		    	
				fieldName = "SVC_FAC_PHONE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbDropoffZip, newAmbDropoffZip,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(newSvcFacPhoneExt.equals(oldSvcFacPhoneExt))){
		    	
				fieldName = "SVC_FAC_PHONE_EXT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSvcFacPhoneExt, newSvcFacPhoneExt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newAmbDropoffZip.equals(oldAmbDropoffZip))){
		    	
				fieldName = "AMB_DROPOFF_ZIP";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbDropoffZip, newAmbDropoffZip,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newSvcAuthExcptCd.equals(oldSvcAuthExcptCd))){
		    	
				fieldName = "SVC_AUTH_EXCPT_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldSvcAuthExcptCd, newSvcAuthExcptCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newAnestSurgProcCd1.equals(oldAnestSurgProcCd1))){
		    	
				fieldName = "ANEST_SURG_PROC_CD1";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAnestSurgProcCd1, newAnestSurgProcCd1,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newAnestSurgProcCd2.equals(oldAnestSurgProcCd2))){
		    	
				fieldName = "ANEST_SURG_PROC_CD2";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAnestSurgProcCd2, newAnestSurgProcCd2,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			
			if(!(newVisnCertCondInd.equals(oldVisnCertCondInd))){
		    	
				fieldName = "VISN_CERT_COND_IND";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldVisnCertCondInd, newVisnCertCondInd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
			    dataChanged = true;
			}
			
			if(!(newAutoAccidentCountry.equals(oldAutoAccidentCountry))){
		    	
				fieldName = "AUTO_ACCIDENT_COUNTRY";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAutoAccidentCountry, newAutoAccidentCountry,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newClaimRefCd.equals(oldClaimRefCd))){
		    	
				fieldName = "CLAIM_REF_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClaimRefCd, newClaimRefCd ,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newPatSignatureSrcCd.equals(oldPatSignatureSrcCd))){
		    	
				fieldName = "PAT_SIGNATURE_SRC_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPatSignatureSrcCd, newPatSignatureSrcCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newMedicareCrossoverCd.equals(oldMedicareCrossoverCd))){
		    	
				fieldName = "MEDICARE_CROSSOVER_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldMedicareCrossoverCd, newMedicareCrossoverCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newLabHomeRespCd.equals(oldLabHomeRespCd))){
		    	
				fieldName = "LAB_HOME_RESP_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldLabHomeRespCd, newLabHomeRespCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newLabHomeCondInd.equals(oldLabHomeCondInd))){
		    	
				fieldName = "LAB_HOME_COND_IND";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldLabHomeCondInd, newLabHomeCondInd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newVisnCodeCategory.equals(oldVisnCodeCategory))){
		    	
				fieldName = "VISN_CODE_CATEGORY";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldVisnCodeCategory, newVisnCodeCategory,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newContractTypeCd.equals(oldContractTypeCd))){
		    	
				fieldName = "CONTRACT_TYPE_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldContractTypeCd, newContractTypeCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newPrvAcceptAssignCd.equals(oldPrvAcceptAssignCd))){
		    	
				fieldName = "PRV_ACCEPT_ASSIGN_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPrvAcceptAssignCd, newPrvAcceptAssignCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newReleaseOfInfoCd.equals(oldReleaseOfInfoCd))){
		    	
				fieldName = "RELEASE_OF_INFO_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldReleaseOfInfoCd, newReleaseOfInfoCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newAutoAccidentState.equals(oldAutoAccidentState))){
		    	
				fieldName = "AUTO_ACCIDENT_STATE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAutoAccidentState, newAutoAccidentState,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newOtherAccidentInd.equals(oldOtherAccidentInd))){
		    	
				fieldName = "OTHER_ACCIDENT_IND";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldOtherAccidentInd, newOtherAccidentInd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newPrvSignatureOnfileInd.equals(oldPrvSignatureOnfileInd))){
		    	
				fieldName = "PRV_SIGNATURE_ONFILE_IND";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPrvSignatureOnfileInd, newPrvSignatureOnfileInd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newDelayReasonCd.equals(oldDelayReasonCd))){
		    	
				fieldName = "DELAY_REASON_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldDelayReasonCd, newDelayReasonCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newBeneAssignCertInd.equals(oldBeneAssignCertInd))){
		    	
				fieldName = "BENE_ASSIGN_CERT_IND";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBeneAssignCertInd, newBeneAssignCertInd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newVisnCertCondCd1.equals(oldVisnCertCondCd1))){
		    	
				fieldName = "VISN_CERT_COND_CD1";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldVisnCertCondCd1, newVisnCertCondCd1,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(newVisnCertCondCd2.equals(oldVisnCertCondCd2))){
		    	
				fieldName = "VISN_CERT_COND_CD2";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldVisnCertCondCd2, newVisnCertCondCd2,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(newVisnCertCondCd3.equals(oldVisnCertCondCd3))){
		    	
				fieldName = "VISN_CERT_COND_CD3";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldVisnCertCondCd3, newVisnCertCondCd3,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if((oldWtxClaimRevNbr!= oldWtxClaimRevNbr)){
		    	
				fieldName = "WTX_CLAIM_REV_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldWtxClaimRevNbr+"", newWtxClaimRevNbr+"",userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(newClmFreqTypeCd.equals(oldClmFreqTypeCd))){
		    	
				fieldName = "CLM_FREQ_TYPE_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmFreqTypeCd, newClmFreqTypeCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(newEmploymentAccidentInd.equals(oldEmploymentAccidentInd))){
		    	
				fieldName = "EMPLOYMENT_ACCIDENT_IND";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldEmploymentAccidentInd, newEmploymentAccidentInd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(newAutoAccidentInd.equals(oldAutoAccidentInd))){
		    	
				fieldName = "AUTO_ACCIDENT_IND";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAutoAccidentInd, newAutoAccidentInd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(newEpsdtCondInd1.equals(oldEpsdtCondInd1))){
		    	
				fieldName = "EPSDT_COND_IND1";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldEpsdtCondInd1, newEpsdtCondInd1,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(newEpsdtCondInd2.equals(oldEpsdtCondInd2))){
		    	
				fieldName = "EPSDT_COND_IND2";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldEpsdtCondInd2, newEpsdtCondInd2,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldEpsdtCondInd3.equals(oldEpsdtCondInd3))){
		    	
				fieldName = "EPSDT_COND_IND3";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldEpsdtCondInd3, newEpsdtCondInd3,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(newVisnCertCondCd4.equals(oldVisnCertCondCd4))){
		    	
				fieldName = "VISN_CERT_COND_CD4";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldVisnCertCondCd4, newVisnCertCondCd4,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(newVisnCertCondCd5.equals(oldVisnCertCondCd5))){
		    	
				fieldName = "VISN_CERT_COND_CD5";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldVisnCertCondCd5, newVisnCertCondCd5,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(newPayerClmCtrlNbr.equals(oldPayerClmCtrlNbr))){
		    	
				fieldName = "PAYER_CLM_CTRL_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPayerClmCtrlNbr, newPayerClmCtrlNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(newPriorAuthNbr.equals(oldPriorAuthNbr))){
		    	
				fieldName = "PRIOR_AUTH_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPriorAuthNbr, newPriorAuthNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}			
			if(!(oldValueAddNtwkTraceNbr.equals(oldValueAddNtwkTraceNbr))){
		    	
				fieldName = "VALUE_ADD_NTWK_TRACE_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldValueAddNtwkTraceNbr, newValueAddNtwkTraceNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newCarePlanOversightNbr.equals(oldCarePlanOversightNbr))){
		    	
				fieldName = "CARE_PLAN_OVERSIGHT_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldCarePlanOversightNbr, newCarePlanOversightNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newClaimNotes.equals(oldClaimNotes))){
		    	
				fieldName = "CLAIM_NOTES";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClaimNotes, newClaimNotes,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newReferralNbr.equals(oldReferralNbr))){
		    	
				fieldName = "REFERRAL_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldReferralNbr, newReferralNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newInvestigDeviceExempId.equals(oldInvestigDeviceExempId))){
		    	
				fieldName = "INVESTIG_DEVICE_EXEMP_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldInvestigDeviceExempId, newInvestigDeviceExempId,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(newMedicalRecordNbr.equals(oldMedicalRecordNbr))){
		    	
				fieldName = "MEDICAL_RECORD_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldMedicalRecordNbr, newMedicalRecordNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(newDemonstrationProjId.equals(oldDemonstrationProjId))){
		    	
				fieldName = "DEMONSTRATION_PROJ_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldDemonstrationProjId, newDemonstrationProjId,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newIllnessOccurDt.equals(oldIllnessOccurDt))){
		    	
				fieldName = "ILLNESS_OCCUR_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldIllnessOccurDt, newIllnessOccurDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newLastMenstrualPerDt.equals(oldLastMenstrualPerDt))){
		    	
				fieldName = "LAST_MENSTRUAL_PER_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldLastMenstrualPerDt, newLastMenstrualPerDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newDisabilityStartDt.equals(oldDisabilityStartDt))){
		    	
				fieldName = "DISABILITY_START_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldDisabilityStartDt, newDisabilityStartDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(newAsumdCareStartDt.equals(oldAsumdCareStartDt))){
		    	
				fieldName = "ASUMD_CARE_START_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAsumdCareStartDt, newAsumdCareStartDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(newPatientCondCd.equals(oldPatientCondCd))){
		    	
				fieldName = "PATIENT_COND_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldPatientCondCd, newPatientCondCd ,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldInitialTreatmentDt.equals(oldInitialTreatmentDt))){
		    	
				fieldName = "INITIAL_TREATMENT_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldInitialTreatmentDt, oldInitialTreatmentDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newLastXrayDt.equals(oldLastXrayDt))){
		    	
				fieldName = "LAST_XRAY_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldLastXrayDt, newLastXrayDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newDisabilityEndDt.equals(oldDisabilityEndDt))){
		    	
				fieldName = "DISABILITY_END_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldDisabilityEndDt, newDisabilityEndDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			logger.debug(" newAsumdCareEndDt " + newAsumdCareEndDt);
			logger.debug(" oldAsumdCareEndDt " + oldAsumdCareEndDt);
			
			if( oldAsumdCareEndDt != null && newAsumdCareEndDt != null && !(newAsumdCareEndDt.equals(oldAsumdCareEndDt))){
		    	
				fieldName = "ASUMD_CARE_END_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAsumdCareEndDt, newAsumdCareEndDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(!(newAmbDropoffZip.equals(oldAmbDropoffZip))){
		    	
				fieldName = "AMB_DROPOFF_ZIP";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbDropoffZip, newAmbDropoffZip,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(oldLastSeenDt != null && newLastSeenDt != null && !(newLastSeenDt.equals(oldLastSeenDt))){
		    	
				fieldName = "LAST_SEEN_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldLastSeenDt, newLastSeenDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(oldHearVisionDt != null && newHearVisionDt != null && !(newHearVisionDt.equals(oldHearVisionDt))){
		    	
				fieldName = "HEAR_VISION_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldHearVisionDt, newHearVisionDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(oldLastWorkedDt != null && newLastWorkedDt != null && !(newLastWorkedDt.equals(oldLastWorkedDt))){
		    	
				fieldName = "LAST_WORKED_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldLastWorkedDt, newLastWorkedDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(oldFirstVisitConsultDt != null && newFirstVisitConsultDt != null && !(newFirstVisitConsultDt.equals(oldFirstVisitConsultDt))){
		    	
				fieldName = "FIRST_VISIT_CONSULT_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldFirstVisitConsultDt, newFirstVisitConsultDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(oldAcuteManifestationDt != null && newAcuteManifestationDt != null && !(newAcuteManifestationDt.equals(oldAcuteManifestationDt))){
		    	
				fieldName = "ACUTE_MANIFESTATION_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAcuteManifestationDt, newAcuteManifestationDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(oldAuthReturnWorkDt != null && newAuthReturnWorkDt != null && !(newAuthReturnWorkDt.equals(oldAuthReturnWorkDt))){
		    	
				fieldName = "AUTH_RETURN_WORK_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAuthReturnWorkDt, newAuthReturnWorkDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
			    dataChanged = true;
			}
			if(oldAccidentDt != null && newAccidentDt != null && !(newAccidentDt.equals(oldAccidentDt))){
		    	
				fieldName = "ACCIDENT_DT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAccidentDt, newAccidentDt,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(oldRoundTripPurposeDesc != null && newRoundTripPurposeDesc != null && !(newRoundTripPurposeDesc.equals(oldRoundTripPurposeDesc))){
		    	
				fieldName = "ROUND_TRIP_PURPOSE_DESC";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldRoundTripPurposeDesc, newRoundTripPurposeDesc,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(newStretcherPurposeDesc != null && newStretcherPurposeDesc != null && !(newStretcherPurposeDesc.equals(oldStretcherPurposeDesc))){
		    	
				fieldName = "STRETCHER_PURPOSE_DESC";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldStretcherPurposeDesc, newStretcherPurposeDesc,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(oldAmbPatWeight != null && newAmbPatWeight != null && !(newAmbPatWeight.equals(oldAmbPatWeight))){
		    	
				fieldName = "AMB_PAT_WEIGHT";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbPatWeight, newAmbPatWeight,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(oldAmbCertCondInd != null && newAmbCertCondInd != null && !(newAmbCertCondInd.equals(oldAmbCertCondInd))){
		    	
				fieldName = "AMB_CERT_COND_IND";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbCertCondInd, newAmbCertCondInd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(oldAmbPickupCountry != null && newAmbPickupCountry != null && !(newAmbPickupCountry.equals(oldAmbPickupCountry))){
		    	
				fieldName = "AMB_PICKUP_COUNTRY";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbPickupCountry, newAmbPickupCountry,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(oldAmbCertCondCd1 != null && newAmbCertCondCd1 != null && !(newAmbCertCondCd1.equals(oldAmbCertCondCd1))){
		    	
				fieldName = "AMB_CERT_COND_CD1";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbCertCondCd1, newAmbCertCondCd1,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(oldAmbCertCondCd2 != null && newAmbCertCondCd2 != null && !(newAmbCertCondCd2.equals(oldAmbCertCondCd2))){
		    	
				fieldName = "AMB_CERT_COND_CD2";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbCertCondCd2, newAmbCertCondCd2,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(oldAmbCertCondCd3 != null && newAmbCertCondCd3 != null && !(newAmbCertCondCd3.equals(oldAmbCertCondCd3))){
		    	
				fieldName = "AMB_CERT_COND_CD3";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbCertCondCd3, newAmbCertCondCd3,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(oldAmbDropoffCountry != null && newAmbDropoffCountry != null && !(newAmbDropoffCountry.equals(oldAmbDropoffCountry))){
		    	
				fieldName = "AMB_DROPOFF_COUNTRY";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbDropoffCountry, newAmbDropoffCountry,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if( oldAmbTranspDistance != null && newAmbTranspDistance != null && !(newAmbTranspDistance.equals(oldAmbTranspDistance))){
		    	
				fieldName = "AMB_TRANSP_DISTANCE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbTranspDistance, newAmbTranspDistance,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(oldAmbTranspReasonCd != null && newAmbTranspReasonCd != null && !(newAmbTranspReasonCd.equals(oldAmbTranspReasonCd))){
		    	
				fieldName = "AMB_TRANSP_REASON_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbTranspReasonCd, newAmbTranspReasonCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(oldAmbPickupCntrySubd != null && newAmbPickupCntrySubd != null && !(newAmbPickupCntrySubd.equals(oldAmbPickupCntrySubd))){
		    	
				fieldName = "AMB_PICKUP_CNTRY_SUBD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbPickupCntrySubd, newAmbPickupCntrySubd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(newAmbCertCondCd4 != null && newAmbCertCondCd4 != null && !(newAmbCertCondCd4.equals(oldAmbCertCondCd4))){
		    	
				fieldName = "AMB_CERT_COND_CD4";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbCertCondCd4, newAmbCertCondCd4,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(oldAmbCertCondCd5 != null && newAmbCertCondCd5!= null && !(newAmbCertCondCd5.equals(oldAmbCertCondCd5))){
		    	
				fieldName = "AMB_CERT_COND_CD5";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbCertCondCd5, newAmbCertCondCd5,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
			if(newAmbDropoffCntrySubd != null && oldAmbDropoffCntrySubd != null && !(newAmbDropoffCntrySubd.equals(oldAmbDropoffCntrySubd))){
		    	
				fieldName = "AMB_DROPOFF_CNTRY_SUBD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldAmbDropoffCntrySubd, newAmbDropoffCntrySubd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				

			    dataChanged = true;
			}
		
						
			
//			

			if (dataChanged) {				
				
				encounterVO.setProfClaimDirty(true);
				
				sqlCnt = ChartEncounterDao.updateProfClaim(conn, newEnc837pClmVO);
				if (sqlCnt != 1) {
					throw new Exception();
				}				

				if (statusChanged) {
					updateStatSum(conn,"P",mfId,oldEnc837pClmVO.getInIntrchgSndrId(), 
							      oldEnc837pClmVO.getTransFileDt(), oldEnc837pClmVO.getServiceBeginDt(), 
								  oldProcessStatus,newProcessStatus,userId,clmType);
				}
			}
		    	
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			message = "Error Updating Professional Claim Data";
			logger.debug(e.getMessage());
		} 
		logger.info(LoggerConstants.methodEndLevel());
		return message;											
		
	}			

	public void updateStatSum(Connection conn,String claimType, String mfId, String intrchgSndrId, String transFileDt, String serviceDt, String oldProcessStatus, String newProcessStatus, String userId,String clmType) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		updateStatSumDate(conn,claimType,mfId,intrchgSndrId,"0",transFileDt,oldProcessStatus,newProcessStatus,userId,clmType);
		updateStatSumDate(conn,claimType,mfId,intrchgSndrId,"1",serviceDt,oldProcessStatus,newProcessStatus,userId,clmType);
		logger.info(LoggerConstants.methodEndLevel());
	}
	
	public void updateStatSumDate(Connection conn, String claimType, String mfId, String intrchgSndrId, String dateInd, String effDate, String oldProcessStatus, String newProcessStatus, String userId,String clmType) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		ChartEncounterDao ChartEncounterDao = new ChartEncounterDao();
		int sqlCnt = -1;						
		
		sqlCnt = ChartEncounterDao.updateCmstatSum(conn, mfId, intrchgSndrId, effDate.substring(0,6), dateInd, oldProcessStatus, claimType, -1, userId,clmType);
		if (sqlCnt != 1) {
			throw new Exception();
		}						

		sqlCnt = ChartEncounterDao.updateCmstatSum(conn, mfId, intrchgSndrId, effDate.substring(0,6), dateInd, newProcessStatus, claimType, 1, userId,clmType);
		if (sqlCnt != 1) {
			throw new Exception();
		}
		logger.info(LoggerConstants.methodEndLevel());
	}

	public void selectErrorsBySearchCriteria(Connection conn, HPEEncounterVO encounterVO)
	throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		try {
			// Retrieve DAO
			ChartEncounterDao ChartEncounterDao = DaoFactory.getInstance().getChartEncounterDao();			
			
			EncErrorstatSumVOs errorList = null;
			errorList = ChartEncounterDao.selectErrorsByCriteria(conn,encounterVO);
			encounterVO.setSearchErrorSummaryResults(errorList);			
			
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException("Exception selecting", e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return;
	}
	
	public Enc837ChangeClaimlogVOs getChangeLogDetails(Connection conn, HPEEncounterVO encounterVO,boolean historyFlag)
	throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		Enc837ChangeClaimlogVOs claimLogList = null;
		try {
			// Retrieve DAO
			ChartEncounterDao ChartEncounterDao = new ChartEncounterDao();
			claimLogList = ChartEncounterDao.getChangeLogDetails(conn,encounterVO,historyFlag);
						
		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException("Exception selecting", e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return claimLogList;
	}
	
	public String updateInstBillingProvider(Connection conn, HPEEncounterVO encounterVO, Enc837iBillprvVO newEnc837iBillprvVO, Enc837iClmVO enc837iClmVO)
	throws ApplicationException {		
		logger.info(LoggerConstants.methodStartLevel());
		String message = "";
		
		// Retrieve DAO
		ChartEncounterDao ChartEncounterDao = new ChartEncounterDao();		
		
		String mfId = encounterVO.getMfId();
		String userId = encounterVO.getUserId();
		String clmType = encounterVO.getSearchDetailClmType();
		
		Enc837iBillprvVO oldEnc837iBillprvVO = encounterVO.getInstBillingProvider();
		//Create Record Key 	
		String recordKey = ChartEncounterDao.getClaimChangeLogRecordKey(enc837iClmVO);	
		ChartEncounterDao.setClaimDetailString(enc837iClmVO.getWtxClaimRefNbr() + "|" + enc837iClmVO.getWtxClaimRevNbr() + "|" +enc837iClmVO.getClmSeqNbr());
		
		//Old Data
		String oldBillPrvOrgName = oldEnc837iBillprvVO.getBillPrvOrgName(); 				
		String oldBillPrvAddrLine1 = oldEnc837iBillprvVO.getBillPrvAddrLine1();
		String oldBillPrvAddrLine2 = oldEnc837iBillprvVO.getBillPrvAddrLine2();
		String oldBillPrvCity = oldEnc837iBillprvVO.getBillPrvCity();
		String oldBillPrvState = oldEnc837iBillprvVO.getBillPrvState();
		String oldBillPrvZip = oldEnc837iBillprvVO.getBillPrvZip();
		String oldBillPrvContactName = oldEnc837iBillprvVO.getBillPrvContactName();
		String oldBillPrvCountry = oldEnc837iBillprvVO.getBillPrvCountry();
		String oldBillPrvCntrySubdCd = oldEnc837iBillprvVO.getBillPrvCntrySubdCd();
		String oldBillPrvTaxonomyId = oldEnc837iBillprvVO.getBillPrvTaxonomyCd();
		String oldBillPrvAffilTaxId = oldEnc837iBillprvVO.getBillPrvAffilTaxId();
		String oldBillPrvNpi = oldEnc837iBillprvVO.getBillPrvNpi();
		String oldBillPrvComNbrQual1 = oldEnc837iBillprvVO.getBillPrvComNbrQual1();
		String oldBillPrvComNbrQual2 = oldEnc837iBillprvVO.getBillPrvComNbrQual2();
		String oldBillPrvComNbrQual3 = oldEnc837iBillprvVO.getBillPrvComNbrQual3();
		String oldBillPrvComNbr1 = oldEnc837iBillprvVO.getBillPrvComNbr1();
		String oldBillPrvComNbr2 = oldEnc837iBillprvVO.getBillPrvComNbr2();
		String oldBillPrvComNbr3 = oldEnc837iBillprvVO.getBillPrvComNbr3();	
		
		String oldP2prvAddrLine1 = oldEnc837iBillprvVO.getP2prvAddrLine1();
		String oldP2prvAddrLine2 = oldEnc837iBillprvVO.getP2prvAddrLine2();
		String oldP2prvCity = oldEnc837iBillprvVO.getP2prvCity();
		String oldP2prvState = oldEnc837iBillprvVO.getP2prvState();
		String oldP2prvZip = oldEnc837iBillprvVO.getP2prvZip();
		String oldP2prvCountry = oldEnc837iBillprvVO.getP2prvCountry();
		String oldP2prvCntrySubdCd = oldEnc837iBillprvVO.getP2prvCntrySubdCd();
		
		String oldP2pOrgName = oldEnc837iBillprvVO.getP2pOrgName();
		String oldP2pPrimPayerId = oldEnc837iBillprvVO.getP2pPrimPayerId();
		String oldP2pLocNbr = oldEnc837iBillprvVO.getP2pLocNbr();
		String oldP2pAddrLine1 = oldEnc837iBillprvVO.getP2pAddrLine1();
		String oldP2pPayerIdNbr = oldEnc837iBillprvVO.getP2pPayerIdNbr();
		String oldP2pNaicCd = oldEnc837iBillprvVO.getP2pNaicCd();
		String oldP2pAddrLine2 = oldEnc837iBillprvVO.getP2pAddrLine2();
		String oldP2pPrimPlanId = oldEnc837iBillprvVO.getP2pPrimPlanId();
		String oldP2pTaxId = oldEnc837iBillprvVO.getP2pTaxId();
		String oldP2pCity = oldEnc837iBillprvVO.getP2pCity();
		String oldP2pState = oldEnc837iBillprvVO.getP2pState();
		String oldP2pZip = oldEnc837iBillprvVO.getP2pZip();
		String oldP2pCountry = oldEnc837iBillprvVO.getP2pCountry();
		String oldP2pCntrySubdCd = oldEnc837iBillprvVO.getP2pCntrySubdCd();
		
		//New Data
		String newBillPrvOrgName = newEnc837iBillprvVO.getBillPrvOrgName(); 				
		String newBillPrvAddrLine1 = newEnc837iBillprvVO.getBillPrvAddrLine1();
		String newBillPrvAddrLine2 = newEnc837iBillprvVO.getBillPrvAddrLine2();
		String newBillPrvCity = newEnc837iBillprvVO.getBillPrvCity();
		String newBillPrvState = newEnc837iBillprvVO.getBillPrvState();
		String newBillPrvZip = newEnc837iBillprvVO.getBillPrvZip();
		String newBillPrvContactName = newEnc837iBillprvVO.getBillPrvContactName();
		String newBillPrvCountry = newEnc837iBillprvVO.getBillPrvCountry();
		String newBillPrvCntrySubdCd = newEnc837iBillprvVO.getBillPrvCntrySubdCd();
		String newBillPrvTaxonomyId = newEnc837iBillprvVO.getBillPrvTaxonomyCd();
		String newBillPrvAffilTaxId = newEnc837iBillprvVO.getBillPrvAffilTaxId();
		String newBillPrvNpi = newEnc837iBillprvVO.getBillPrvNpi();
		String newBillPrvComNbrQual1 = newEnc837iBillprvVO.getBillPrvComNbrQual1();
		String newBillPrvComNbrQual2 = newEnc837iBillprvVO.getBillPrvComNbrQual2();
		String newBillPrvComNbrQual3 = newEnc837iBillprvVO.getBillPrvComNbrQual3();
		String newBillPrvComNbr1 = newEnc837iBillprvVO.getBillPrvComNbr1();
		String newBillPrvComNbr2 = newEnc837iBillprvVO.getBillPrvComNbr2();
		String newBillPrvComNbr3 = newEnc837iBillprvVO.getBillPrvComNbr3();
		
		String newP2prvAddrLine1 = newEnc837iBillprvVO.getP2prvAddrLine1();
		String newP2prvAddrLine2 = newEnc837iBillprvVO.getP2prvAddrLine2();
		String newP2prvCity = newEnc837iBillprvVO.getP2prvCity();
		String newP2prvState = newEnc837iBillprvVO.getP2prvState();
		String newP2prvZip = newEnc837iBillprvVO.getP2prvZip();
		String newP2prvCountry = newEnc837iBillprvVO.getP2prvCountry();
		String newP2prvCntrySubdCd = newEnc837iBillprvVO.getP2prvCntrySubdCd();
		
		String newP2pOrgName = newEnc837iBillprvVO.getP2pOrgName();
		String newP2pPrimPayerId = newEnc837iBillprvVO.getP2pPrimPayerId();
		String newP2pLocNbr = newEnc837iBillprvVO.getP2pLocNbr();
		String newP2pAddrLine1 = newEnc837iBillprvVO.getP2pAddrLine1();
		String newP2pPayerIdNbr = newEnc837iBillprvVO.getP2pPayerIdNbr();
		String newP2pNaicCd = newEnc837iBillprvVO.getP2pNaicCd();
		String newP2pAddrLine2 = newEnc837iBillprvVO.getP2pAddrLine2();
		String newP2pPrimPlanId = newEnc837iBillprvVO.getP2pPrimPlanId();
		String newP2pTaxId = newEnc837iBillprvVO.getP2pTaxId();
		String newP2pCity = newEnc837iBillprvVO.getP2pCity();
		String newP2pState = newEnc837iBillprvVO.getP2pState();
		String newP2pZip = newEnc837iBillprvVO.getP2pZip();
		String newP2pCountry = newEnc837iBillprvVO.getP2pCountry();
		String newP2pCntrySubdCd = newEnc837iBillprvVO.getP2pCntrySubdCd();
		
		int sqlCnt = -1;
		
		String fieldName = "";
		String tableName = "ENC_837I_BILLPRV";
		
		boolean dataChanged = false;	
		
		try {												
				    	
			if(!(oldBillPrvOrgName.equals(newBillPrvOrgName))){			    
		    	fieldName = "BILL_PRV_ORG_NAME";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvOrgName, newBillPrvOrgName,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }			
		    
			    dataChanged = true;			   
			}
		
			if(!(oldBillPrvAddrLine1.equals(newBillPrvAddrLine1))){		    	
				fieldName = "BILL_PRV_ADDR_LINE1";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvAddrLine1, newBillPrvAddrLine1,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(oldBillPrvAddrLine2.equals(newBillPrvAddrLine2))){		    	
				fieldName = "BILL_PRV_ADDR_LINE2";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvAddrLine2, newBillPrvAddrLine2,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldBillPrvCity.equals(newBillPrvCity))){		    	
				fieldName = "BILL_PRV_CITY";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvCity, newBillPrvCity,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldBillPrvState.equals(newBillPrvState))){		    	
				fieldName = "BILL_PRV_STATE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvState, newBillPrvState,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldBillPrvZip.equals(newBillPrvZip))){		    	
				fieldName = "BILL_PRV_ZIP";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvZip, newBillPrvZip,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldBillPrvContactName.equals(newBillPrvContactName))){		    	
				fieldName = "BILL_PRV_CONTACT_NAME";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvContactName, newBillPrvContactName,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldBillPrvCountry.equals(newBillPrvCountry))){		    	
				fieldName = "BILL_PRV_COUNTRY";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvCountry, newBillPrvCountry,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldBillPrvCntrySubdCd.equals(newBillPrvCntrySubdCd))){		    	
				fieldName = "BILL_PRV_CNTRY_SUBD_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvCntrySubdCd, newBillPrvCntrySubdCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldBillPrvTaxonomyId.equals(newBillPrvTaxonomyId))){		    	
				fieldName = "BILL_PRV_TAXONOMY_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvTaxonomyId, newBillPrvTaxonomyId,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldBillPrvAffilTaxId.equals(newBillPrvAffilTaxId))){		    	
				fieldName = "BILL_PRV_AFFIL_TAX_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvAffilTaxId, newBillPrvAffilTaxId,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldBillPrvNpi.equals(newBillPrvNpi))){		    	
				fieldName = "BILL_PRV_NPI";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvNpi, newBillPrvNpi,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldBillPrvComNbrQual1.equals(newBillPrvComNbrQual1))){		    	
				fieldName = "BILL_PRV_COM_NBR_QUAL1";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvComNbrQual1, newBillPrvComNbrQual1,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldBillPrvComNbrQual2.equals(newBillPrvComNbrQual2))){		    	
				fieldName = "BILL_PRV_COM_NBR_QUAL2";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvComNbrQual2, newBillPrvComNbrQual2,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldBillPrvComNbrQual3.equals(newBillPrvComNbrQual3))){		    	
				fieldName = "BILL_PRV_COM_NBR_QUAL3";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvComNbrQual3, newBillPrvComNbrQual3,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldBillPrvComNbr1.equals(newBillPrvComNbr1))){		    	
				fieldName = "BILL_PRV_COM_NBR1";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvComNbr1, newBillPrvComNbr1,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldBillPrvComNbr2.equals(newBillPrvComNbr2))){		    	
				fieldName = "BILL_PRV_COM_NBR2";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvComNbr2, newBillPrvComNbr2,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldBillPrvComNbr3.equals(newBillPrvComNbr3))){		    	
				fieldName = "BILL_PRV_COM_NBR3";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvComNbr3, newBillPrvComNbr3,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(oldP2prvAddrLine1.equals(newP2prvAddrLine1))){		    	
				fieldName = "P2PRV_ADDR_LINE1";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2prvAddrLine1, newP2prvAddrLine1,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2prvAddrLine2.equals(newP2prvAddrLine2))){		    	
				fieldName = "P2PRV_ADDR_LINE2";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2prvAddrLine2, newP2prvAddrLine2,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2prvCity.equals(newP2prvCity))){		    	
				fieldName = "P2PRV_CITY";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2prvCity, newP2prvCity,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2prvState.equals(newP2prvState))){		    	
				fieldName = "P2PRV_STATE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2prvState, newP2prvState,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2prvZip.equals(newP2prvZip))){		    	
				fieldName = "P2PRV_ZIP";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2prvZip, newP2prvZip,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2prvCountry.equals(newP2prvCountry))){		    	
				fieldName = "P2PRV_COUNTRY";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2prvCountry, newP2prvCountry,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2prvCntrySubdCd.equals(newP2prvCntrySubdCd))){		    	
				fieldName = "P2PRV_CNTRY_SUBD_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2prvCntrySubdCd, newP2prvCntrySubdCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2pOrgName.equals(newP2pOrgName))){		    	
				fieldName = "P2P_ORG_NAME";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pOrgName, newP2pOrgName,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2pPrimPayerId.equals(newP2pPrimPayerId))){		    	
				fieldName = "P2P_PRIM_PAYER_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pPrimPayerId, newP2pPrimPayerId,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2pLocNbr.equals(newP2pLocNbr))){		    	
				fieldName = "P2P_LOC_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pLocNbr, newP2pLocNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2pAddrLine1.equals(newP2pAddrLine1))){		    	
				fieldName = "P2PRV_ADDR_LINE1";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pAddrLine1, newP2pAddrLine1,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2pPayerIdNbr.equals(newP2pPayerIdNbr))){		    	
				fieldName = "P2P_PAYER_ID_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pPayerIdNbr, newP2pPayerIdNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2pNaicCd.equals(newP2pNaicCd))){		    	
				fieldName = "P2P_NAIC_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pNaicCd, newP2pNaicCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2pAddrLine2.equals(newP2pAddrLine2))){		    	
				fieldName = "P2P_ADDR_LINE2";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pAddrLine2, newP2pAddrLine2,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2pPrimPlanId.equals(newP2pPrimPlanId))){		    	
				fieldName = "P2P_PRIM_PLAN_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pPrimPlanId, newP2pPrimPlanId,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2pTaxId.equals(newP2pTaxId))){		    	
				fieldName = "P2P_TAX_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pTaxId, newP2pTaxId,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2pCity.equals(newP2pCity))){		    	
				fieldName = "P2P_CITY";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pCity, newP2pCity,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2pState.equals(newP2pState))){		    	
				fieldName = "P2P_STATE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pState, newP2pState,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2pZip.equals(newP2pZip))){		    	
				fieldName = "P2P_ZIP";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pZip, newP2pZip,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2pCountry.equals(newP2pCountry))){		    	
				fieldName = "P2P_COUNTRY";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pCountry, newP2pCountry,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldP2pCntrySubdCd.equals(newP2pCntrySubdCd))){		    	
				fieldName = "P2P_CNTRY_SUBD_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pCntrySubdCd, newP2pCntrySubdCd,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
		   
			if (dataChanged) {			
				encounterVO.setInstBillPrvDirty(true);
				
				sqlCnt = ChartEncounterDao.updateInstBillPrv(conn, newEnc837iBillprvVO);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
				
										    
			}
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			message = "Error Updating Institutional Billing Provider Data";
			logger.debug(e.getMessage());
		} 
		logger.info(LoggerConstants.methodEndLevel());
		return message;									
		
		}
	
	public String updateInstClaimProvider(Connection conn, HPEEncounterVO encounterVO, int selectedIndex,Enc837iClmProviderVO enc837iClmProviderVO)
	throws ApplicationException {		
		logger.info(LoggerConstants.methodStartLevel());
		String message = "";
		
		// Retrieve DAO
		ChartEncounterDao ChartEncounterDao = new ChartEncounterDao();		
		
		String mfId = encounterVO.getMfId();
		String userId = encounterVO.getUserId();
		String clmType = encounterVO.getSearchDetailClmType();
		
		//Create Record Key 	
		Enc837iClmProviderVO oldEnc837iClmProviderVO = (Enc837iClmProviderVO)encounterVO.
															getInstClaimProviders().get(selectedIndex);
		
		String recordKey = ChartEncounterDao.getClaimChangeLogRecordKey(oldEnc837iClmProviderVO);
		ChartEncounterDao.setClaimDetailString(oldEnc837iClmProviderVO.getWtxClaimRefNbr() + "|" + oldEnc837iClmProviderVO.getWtxClaimRevNbr() + "|" +oldEnc837iClmProviderVO.getClmSeqNbr());
		
		//Old Data
		String oldClmPrvFirstName = oldEnc837iClmProviderVO.getProvFirstName(); 
		String oldClmPrvMiddleName = oldEnc837iClmProviderVO.getProvMiddleName(); 
		String oldClmPrvLastName = oldEnc837iClmProviderVO.getProvLastName(); 		 				
		String oldClmPrvAddrLine1 = oldEnc837iClmProviderVO.getProvAddrLine1();
		String oldClmPrvAddrLine2 = oldEnc837iClmProviderVO.getProvAddrLine2();
		String oldClmPrvCity = oldEnc837iClmProviderVO.getProvCity();
		String oldClmPrvState = oldEnc837iClmProviderVO.getProvState();
		String oldClmPrvZip = oldEnc837iClmProviderVO.getProvZip();
		String oldClmPrvTaxonomyId = oldEnc837iClmProviderVO.getProvTaxonomyCd();		
		String oldClmPrvNpi = oldEnc837iClmProviderVO.getProvNpi();
		String oldClmPrvEntityType = oldEnc837iClmProviderVO.getProvEntityType();
		String oldClmPrvOthPayerId = oldEnc837iClmProviderVO.getProvOthPayerId();
		String oldClmPrvLocNbr = oldEnc837iClmProviderVO.getProvLocNbr();
		String oldClmPrvLicNbr = oldEnc837iClmProviderVO.getProvLicNbr();
		String oldClmPrvUpin = oldEnc837iClmProviderVO.getProvUpin();
		String oldClmPrvCommNbr = oldEnc837iClmProviderVO.getProvCommNbr();
		String oldClmPrvType = oldEnc837iClmProviderVO.getProvType();	//IFOX-00418160 - NPI Provider fields update
						
		//New Data
		String newClmPrvFirstName = enc837iClmProviderVO.getProvFirstName(); 
		String newClmPrvMiddleName = enc837iClmProviderVO.getProvMiddleName(); 
		String newClmPrvLastName = enc837iClmProviderVO.getProvLastName(); 		 				
		String newClmPrvAddrLine1 = enc837iClmProviderVO.getProvAddrLine1();
		String newClmPrvAddrLine2 = enc837iClmProviderVO.getProvAddrLine2();
		String newClmPrvCity = enc837iClmProviderVO.getProvCity();
		String newClmPrvState = enc837iClmProviderVO.getProvState();
		String newClmPrvZip = enc837iClmProviderVO.getProvZip();
		String newClmPrvTaxonomyId = enc837iClmProviderVO.getProvTaxonomyCd();		
		String newClmPrvNpi = enc837iClmProviderVO.getProvNpi();
		String newClmPrvEntityType = enc837iClmProviderVO.getProvEntityType();
		String newClmPrvOthPayerId = enc837iClmProviderVO.getProvOthPayerId();
		String newClmPrvLocNbr = enc837iClmProviderVO.getProvLocNbr();
		String newClmPrvLicNbr = enc837iClmProviderVO.getProvLicNbr();
		String newClmPrvUpin = enc837iClmProviderVO.getProvUpin();
		String newClmPrvCommNbr = enc837iClmProviderVO.getProvCommNbr();
		String newClmPrvType = enc837iClmProviderVO.getProvTypeNew();	//IFOX-00418160 - NPI Provider fields update
		
		int sqlCnt = -1;
		
		String fieldName = "";
		String tableName = "ENC_837I_CLM_PROVIDER";
		
		boolean dataChanged = false;	
				
		try {
			//IFOX-00418160 - NPI Provider fields update - Start
			if(!(oldClmPrvType.equals(newClmPrvType))){			    
		    	fieldName = "PROV_TYPE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvType, newClmPrvType,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }			
		    
			    dataChanged = true;			   
			}
			//IFOX-00418160 - NPI Provider fields update - End
			if(!(oldClmPrvFirstName.equals(newClmPrvFirstName))){			    
		    	fieldName = "PROV_FIRST_NAME";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvFirstName, newClmPrvFirstName,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }			
		    
			    dataChanged = true;			   
			}
			
			if(!(oldClmPrvMiddleName.equals(newClmPrvMiddleName))){			    
		    	fieldName = "PROV_MIDDLE_NAME";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvMiddleName, newClmPrvMiddleName,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }			
		    
			    dataChanged = true;			   
			}
				    	
			if(!(oldClmPrvLastName.equals(newClmPrvLastName))){			    
		    	fieldName = "PROV_LAST_NAME";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvLastName, newClmPrvLastName,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }			
		    
			    dataChanged = true;			   
			}
			
			if(!(oldClmPrvAddrLine1.equals(newClmPrvAddrLine1))){		    	
				fieldName = "PROV_ADDR_LINE1";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvAddrLine1, newClmPrvAddrLine1,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(oldClmPrvAddrLine2.equals(newClmPrvAddrLine2))){		    	
				fieldName = "PROV_ADDR_LINE2";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvAddrLine2, newClmPrvAddrLine2,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(oldClmPrvCity.equals(newClmPrvCity))){		    	
				fieldName = "PROV_CITY";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvCity, newClmPrvCity,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldClmPrvState.equals(newClmPrvState))){		    	
				fieldName = "PROV_STATE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvState, newClmPrvState,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldClmPrvZip.equals(newClmPrvZip))){		    	
				fieldName = "PROV_ZIP";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvZip, newClmPrvZip,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(oldClmPrvTaxonomyId.equals(newClmPrvTaxonomyId))){		    	
				fieldName = "PROV_TAXONOMY_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvTaxonomyId, newClmPrvTaxonomyId,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
						
			if(!oldClmPrvEntityType.equals("") && !(oldClmPrvEntityType.equals(newClmPrvEntityType))){	//IFOX-00429690 - Wrongly updating while user changing the status to IGN or COR 			    
		    	fieldName = "PROV_ENTITY_TYPE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvEntityType, newClmPrvEntityType,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }			
		    
			    dataChanged = true;			   
			}
			

			if(!(oldClmPrvNpi.equals(newClmPrvNpi))){		    	
				fieldName = "PROV_NPI";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvNpi, newClmPrvNpi,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}			
			
			if(!(oldClmPrvOthPayerId.equals(newClmPrvOthPayerId))){		    	
				fieldName = "PROV_OTH_PAYER_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvOthPayerId, newClmPrvOthPayerId,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}		
			
			if(!(oldClmPrvLicNbr.equals(newClmPrvLicNbr))){		    	
				fieldName = "PROV_LIC_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvLicNbr, newClmPrvLicNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}			
			
			if(!(oldClmPrvLocNbr.equals(newClmPrvLocNbr))){		    	
				fieldName = "PROV_LOC_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvLocNbr, newClmPrvLocNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}			

			if(!(oldClmPrvUpin.equals(newClmPrvUpin))){		    	
				fieldName = "PROV_UPIN";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvUpin, newClmPrvUpin,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}			
			if(!(oldClmPrvCommNbr.equals(newClmPrvCommNbr))){		    	
				fieldName = "PROV_COMM_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvCommNbr, newClmPrvCommNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}			

			if (dataChanged) {			
				encounterVO.setInstClmPrvDirty(true);
				
				sqlCnt = ChartEncounterDao.updateInstClmPrv(conn,enc837iClmProviderVO);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
				
										    
			}
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//IFOX-00418160 - NPI Provider fields update - Start
			if(e.toString().equals("com.ps.mss.exception.DaoException: DUPLICATE CLAIM PROVIDER")){
				message = "Error Updating - Duplicate Claim Provider Type";
			}else{
			message = "Error Updating Institutional Claim Provider Data";
			}
			//IFOX-00418160 - NPI Provider fields update - End
			logger.debug(e.getMessage());
		} 
		logger.info(LoggerConstants.methodEndLevel());
		return message;									
		
	}			

	public String updateProfClaimProvider(Connection conn, HPEEncounterVO encounterVO, int selectedIndex,Enc837pClmProviderVO enc837pClmProviderVO)
	throws ApplicationException {		
		logger.info(LoggerConstants.methodStartLevel());
		String message = "";
		
		// Retrieve DAO
		ChartEncounterDao ChartEncounterDao = new ChartEncounterDao();		
		
		String mfId = encounterVO.getMfId();
		String userId = encounterVO.getUserId();
		String clmType = encounterVO.getSearchDetailClmType();
		
		//Create Record Key 	
		Enc837pClmProviderVO oldEnc837pClmProviderVO = (Enc837pClmProviderVO)encounterVO.
															getProfClaimProviders().get(selectedIndex);
		
		String recordKey = ChartEncounterDao.getClaimChangeLogRecordKey(oldEnc837pClmProviderVO);		
		ChartEncounterDao.setClaimDetailString(oldEnc837pClmProviderVO.getWtxClaimRefNbr() + "|" + oldEnc837pClmProviderVO.getWtxClaimRevNbr() + "|" +oldEnc837pClmProviderVO.getClmSeqNbr());
		
		//Old Data
		String oldClmPrvEntityType = oldEnc837pClmProviderVO.getProvEntityType();
		String oldClmPrvFirstName = oldEnc837pClmProviderVO.getProvFirstName(); 
		String oldClmPrvMiddleName = oldEnc837pClmProviderVO.getProvMiddleName(); 
		String oldClmPrvLastName = oldEnc837pClmProviderVO.getProvLastName(); 		 				
		String oldClmPrvAddrLine1 = oldEnc837pClmProviderVO.getProvAddrLine1();
		String oldClmPrvAddrLine2 = oldEnc837pClmProviderVO.getProvAddrLine2();
		String oldClmPrvCity = oldEnc837pClmProviderVO.getProvCity();
		String oldClmPrvState = oldEnc837pClmProviderVO.getProvState();
		String oldClmPrvZip = oldEnc837pClmProviderVO.getProvZip();
		String oldClmPrvTaxonomyId = oldEnc837pClmProviderVO.getProvTaxonomyCd();		
		String oldClmPrvNpi = oldEnc837pClmProviderVO.getProvNpi();
		String oldClmPrvLicNbr = oldEnc837pClmProviderVO.getProvLicNbr();
		String oldClmPrvUpin = oldEnc837pClmProviderVO.getProvUpin();
		String oldClmPrvCommNbr = oldEnc837pClmProviderVO.getProvCommNbr();
		String oldClmPrvLocNbr = oldEnc837pClmProviderVO.getProvLocNbr();
		String oldClmPrvOthPayerId = oldEnc837pClmProviderVO.getProvOthPayerId();
		String oldClmPrvType = oldEnc837pClmProviderVO.getProvType();	//IFOX-00418160 - NPI Provider fields update
						
		//New Data
		String newClmPrvEntityType = enc837pClmProviderVO.getProvEntityType();
		String newClmPrvFirstName = enc837pClmProviderVO.getProvFirstName(); 
		String newClmPrvMiddleName = enc837pClmProviderVO.getProvMiddleName(); 
		String newClmPrvLastName = enc837pClmProviderVO.getProvLastName(); 		 				
		String newClmPrvAddrLine1 = enc837pClmProviderVO.getProvAddrLine1();
		String newClmPrvAddrLine2 = enc837pClmProviderVO.getProvAddrLine2();
		String newClmPrvCity = enc837pClmProviderVO.getProvCity();
		String newClmPrvState = enc837pClmProviderVO.getProvState();
		String newClmPrvZip = enc837pClmProviderVO.getProvZip();
		String newClmPrvTaxonomyId = enc837pClmProviderVO.getProvTaxonomyCd();		
		String newClmPrvNpi = enc837pClmProviderVO.getProvNpi();
		String newClmPrvLicNbr = enc837pClmProviderVO.getProvLicNbr();
		String newClmPrvUpin = enc837pClmProviderVO.getProvUpin();
		String newClmPrvCommNbr = enc837pClmProviderVO.getProvCommNbr();
		String newClmPrvLocNbr = enc837pClmProviderVO.getProvLocNbr();
		String newClmPrvOthPayerId = enc837pClmProviderVO.getProvOthPayerId();
		String newClmPrvType = enc837pClmProviderVO.getProvTypeNew();	//IFOX-00418160 - NPI Provider fields update
		
		int sqlCnt = -1;
		
		String fieldName = "";
		String tableName = "ENC_837P_CLM_PROVIDER";
		
		boolean dataChanged = false;	
				
		try {
			//IFOX-00418160 - NPI Provider fields update - Start
			if(!(oldClmPrvType.equals(newClmPrvType))){			    
		    	fieldName = "PROV_TYPE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvType, newClmPrvType,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }			
		    
			    dataChanged = true;			   
			}
			//IFOX-00418160 - NPI Provider fields update - End
			if(!(oldClmPrvFirstName.equals(newClmPrvFirstName))){			    
		    	fieldName = "PROV_FIRST_NAME";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvFirstName, newClmPrvFirstName,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }			
		    
			    dataChanged = true;			   
			}
			
			if(!(oldClmPrvMiddleName.equals(newClmPrvMiddleName))){			    
		    	fieldName = "PROV_MIDDLE_NAME";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvMiddleName, newClmPrvMiddleName,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }			
		    
			    dataChanged = true;			   
			}
				    	
			if(!(oldClmPrvLastName.equals(oldClmPrvLastName))){			    
		    	fieldName = "PROV_LAST_NAME";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvLastName, newClmPrvLastName,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }			
		    
			    dataChanged = true;			   
			}
			
			if(!(oldClmPrvAddrLine1.equals(newClmPrvAddrLine1))){		    	
				fieldName = "PROV_ADDR_LINE1";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvAddrLine1, newClmPrvAddrLine1,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(oldClmPrvAddrLine2.equals(newClmPrvAddrLine2))){		    	
				fieldName = "PROV_ADDR_LINE2";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvAddrLine2, newClmPrvAddrLine2,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(oldClmPrvCity.equals(newClmPrvCity))){		    	
				fieldName = "PROV_CITY";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvCity, newClmPrvCity,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldClmPrvState.equals(newClmPrvState))){		    	
				fieldName = "PROV_STATE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvState, newClmPrvState,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			if(!(oldClmPrvZip.equals(newClmPrvZip))){		    	
				fieldName = "PROV_ZIP";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvZip, newClmPrvZip,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(oldClmPrvTaxonomyId.equals(newClmPrvTaxonomyId))){		    	
				fieldName = "PROV_TAXONOMY_CD";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvTaxonomyId, newClmPrvTaxonomyId,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
						
			if(!oldClmPrvEntityType.equals("") && !(oldClmPrvEntityType.equals(newClmPrvEntityType))){	//IFOX-00429690 - Wrongly updating while user changing the status to IGN or COR			    
		    	fieldName = "PROV_ENTITY_TYPE";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvEntityType, newClmPrvEntityType,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }			
		    
			    dataChanged = true;			   
			}
			
			if(!(oldClmPrvNpi.equals(newClmPrvNpi))){		    	
				fieldName = "PROV_NPI";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvNpi, newClmPrvNpi,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}
			
			if(!(oldClmPrvLicNbr.equals(newClmPrvLicNbr))){		    	
				fieldName = "PROV_LIC_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvLicNbr, newClmPrvLicNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}			

			if(!(oldClmPrvUpin.equals(newClmPrvUpin))){		    	
				fieldName = "PROV_UPIN";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvUpin, newClmPrvUpin,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}			

			if(!(oldClmPrvCommNbr.equals(newClmPrvCommNbr))){		    	
				fieldName = "PROV_COMM_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvCommNbr, newClmPrvCommNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}			

			if(!(oldClmPrvLocNbr.equals(newClmPrvLocNbr))){		    	
				fieldName = "PROV_LOC_NBR";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvLocNbr, newClmPrvLocNbr,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}			

			if(!(oldClmPrvOthPayerId.equals(newClmPrvOthPayerId))){		    	
				fieldName = "PROV_OTH_PAYER_ID";
			    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldClmPrvOthPayerId, newClmPrvOthPayerId,userId,clmType);    
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }				
		
			    dataChanged = true;
			}			
			
			if (dataChanged) {			
				encounterVO.setProfClmPrvDirty(true);
				
				sqlCnt = ChartEncounterDao.updateProfClmPrv(conn,enc837pClmProviderVO);
			    if (sqlCnt != 1) {
			    	throw new Exception();
			    }
				
										    
			}
			
		} catch(Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			//IFOX-00418160 - NPI Provider fields update - Start
			if(e.toString().equals("com.ps.mss.exception.DaoException: DUPLICATE CLAIM PROVIDER")){
				message = "Error Updating - Duplicate Claim Provider Type";
			}else{
			message = "Error Updating Professional Claim Provider Data";
			}
			//IFOX-00418160 - NPI Provider fields update - End
			logger.debug(e.getMessage());
		} 
		logger.info(LoggerConstants.methodEndLevel());
		return message;									
		
	}			
	

public String updateProfBillingProvider(Connection conn, HPEEncounterVO encounterVO, Enc837pBillprvVO enc837pBillprvVO, Enc837pClmVO enc837pClmVO)
throws ApplicationException {		
	logger.info(LoggerConstants.methodStartLevel());
	String message = "";

	
	// Retrieve DAO
	ChartEncounterDao ChartEncounterDao = new ChartEncounterDao();		
	
	String mfId = encounterVO.getMfId();
	String userId = encounterVO.getUserId();
	String clmType = encounterVO.getSearchDetailClmType();
	
	Enc837pBillprvVO oldEnc837pBillprvVO = encounterVO.getProfBillingProvider();
	//Create Record Key 	
	String recordKey = ChartEncounterDao.getClaimChangeLogRecordKey(enc837pClmVO);
	ChartEncounterDao.setClaimDetailString(enc837pClmVO.getWtxClaimRefNbr() + "|" + enc837pClmVO.getWtxClaimRevNbr() + "|" +enc837pClmVO.getClmSeqNbr());
	
	//Old Data
	String oldBillPrvFirstName = oldEnc837pBillprvVO.getBillPrvFirstName(); 
	String oldBillPrvMiddleName = oldEnc837pBillprvVO.getBillPrvMiddleName(); 
	String oldBillPrvEntityType = oldEnc837pBillprvVO.getBillPrvEntityType(); 
	String oldBillPrvOrgName = oldEnc837pBillprvVO.getBillPrvOrgName(); 				
	String oldBillPrvAddrLine1 = oldEnc837pBillprvVO.getBillPrvAddrLine1();
	String oldBillPrvAddrLine2 = oldEnc837pBillprvVO.getBillPrvAddrLine2();
	String oldBillPrvCity = oldEnc837pBillprvVO.getBillPrvCity();
	String oldBillPrvState = oldEnc837pBillprvVO.getBillPrvState();
	String oldBillPrvZip = oldEnc837pBillprvVO.getBillPrvZip();
	String oldBillPrvTaxonomyId = oldEnc837pBillprvVO.getBillPrvTaxonomyCd();
	String oldBillPrvAffilTaxId = oldEnc837pBillprvVO.getBillPrvAffilTaxId();
	String oldBillPrvNpi = oldEnc837pBillprvVO.getBillPrvNpi();
	String oldBillPrvLicNbr = oldEnc837pBillprvVO.getBillPrvLicNbr();
	String oldBillPrvUpin = oldEnc837pBillprvVO.getBillPrvUpin();
	String oldBillPrvSsn = oldEnc837pBillprvVO.getBillPrvSsn();
	String oldBillPrvComNbrQual1 = oldEnc837pBillprvVO.getBillPrvComNbrQual1();
	String oldBillPrvComNbrQual2 = oldEnc837pBillprvVO.getBillPrvComNbrQual2();
	String oldBillPrvComNbrQual3 = oldEnc837pBillprvVO.getBillPrvComNbrQual3();
	String oldBillPrvComNbr1 = oldEnc837pBillprvVO.getBillPrvComNbr1();
	String oldBillPrvComNbr2 = oldEnc837pBillprvVO.getBillPrvComNbr2();
	String oldBillPrvComNbr3 = oldEnc837pBillprvVO.getBillPrvComNbr3();	
	String oldP2prvAddrLine1 = oldEnc837pBillprvVO.getP2prvAddrLine1();
	String oldP2prvAddrLine2 = oldEnc837pBillprvVO.getP2prvAddrLine2();
	String oldP2prvCity = oldEnc837pBillprvVO.getP2prvCity();
	String oldP2prvState = oldEnc837pBillprvVO.getP2prvState();
	String oldP2prvZip = oldEnc837pBillprvVO.getP2prvZip();
	String oldP2prvEntityType = oldEnc837pBillprvVO.getP2prvEntityType();
	
	String oldBillPrvCountry = oldEnc837pBillprvVO.getBillPrvCountry();
	String oldBillPrvSubCountry = oldEnc837pBillprvVO.getBillPrvCntrySubdCd();
	
	String oldP2PrvCountry = oldEnc837pBillprvVO.getP2prvCountry();
	String oldP2prvCntrySubdCd = oldEnc837pBillprvVO.getP2prvCntrySubdCd();
	logger.debug(" oldP2prvCntrySubdCd 8888==  " + oldEnc837pBillprvVO.getP2prvCntrySubdCd());
	String oldP2pOrgName = oldEnc837pBillprvVO.getP2pOrgName();
	String oldP2pPrimPayerId = oldEnc837pBillprvVO.getP2pPrimPayerId();
	String oldP2pLocNbr = oldEnc837pBillprvVO.getP2pLocNbr();
	String oldP2pAddrLine1 = oldEnc837pBillprvVO.getP2pAddrLine1();
	String oldP2pPayerIdNbr = oldEnc837pBillprvVO.getP2pPayerIdNbr();
	String oldP2pNaicCd = oldEnc837pBillprvVO.getP2pNaicCd();
	String oldP2pAddrLine2 = oldEnc837pBillprvVO.getP2pAddrLine2();
	String oldP2pPrimPlanId = oldEnc837pBillprvVO.getP2pPrimPlanId();
	String oldP2pTaxId = oldEnc837pBillprvVO.getP2pTaxId();
	String oldP2pCity = oldEnc837pBillprvVO.getP2pCity();
	String oldP2pState = oldEnc837pBillprvVO.getP2pState();
	String oldP2pZip = oldEnc837pBillprvVO.getP2pZip();
	String oldP2pCountry = oldEnc837pBillprvVO.getP2pCountry();
	String oldP2pCntrySubdCd = oldEnc837pBillprvVO.getP2pCntrySubdCd();	
	
	logger.debug("oldBillPrvCountry " + oldBillPrvCountry );
	logger.debug("oldBillPrvSubCountry  " + oldBillPrvSubCountry );
	logger.debug("oldP2PrvCountry " + oldP2PrvCountry );
	logger.debug("oldP2pCntrySubdCd ---- =  " + oldP2pCntrySubdCd  );
	
			
	//New Data
	String newBillPrvFirstName = enc837pBillprvVO.getBillPrvFirstName(); 
	String newBillPrvMiddleName = enc837pBillprvVO.getBillPrvMiddleName(); 
	String newBillPrvEntityType = enc837pBillprvVO.getBillPrvEntityType(); 
	String newBillPrvOrgName = enc837pBillprvVO.getBillPrvOrgName(); 				
	String newBillPrvAddrLine1 = enc837pBillprvVO.getBillPrvAddrLine1();
	String newBillPrvAddrLine2 = enc837pBillprvVO.getBillPrvAddrLine2();
	String newBillPrvCity = enc837pBillprvVO.getBillPrvCity();
	String newBillPrvState = enc837pBillprvVO.getBillPrvState();
	String newBillPrvZip = enc837pBillprvVO.getBillPrvZip();
	String newBillPrvTaxonomyId = enc837pBillprvVO.getBillPrvTaxonomyCd();
	String newBillPrvAffilTaxId = enc837pBillprvVO.getBillPrvAffilTaxId();
	String newBillPrvNpi = enc837pBillprvVO.getBillPrvNpi();
	String newBillPrvLicNbr = enc837pBillprvVO.getBillPrvLicNbr();
	String newBillPrvUpin = enc837pBillprvVO.getBillPrvUpin();
	String newBillPrvSsn = enc837pBillprvVO.getBillPrvSsn();
	String newBillPrvComNbrQual1 = enc837pBillprvVO.getBillPrvComNbrQual1();
	String newBillPrvComNbrQual2 = enc837pBillprvVO.getBillPrvComNbrQual2();
	String newBillPrvComNbrQual3 = enc837pBillprvVO.getBillPrvComNbrQual3();
	String newBillPrvComNbr1 = enc837pBillprvVO.getBillPrvComNbr1();
	String newBillPrvComNbr2 = enc837pBillprvVO.getBillPrvComNbr2();
	String newBillPrvComNbr3 = enc837pBillprvVO.getBillPrvComNbr3();
	String newP2prvAddrLine1 = enc837pBillprvVO.getP2prvAddrLine1();
	String newP2prvAddrLine2 = enc837pBillprvVO.getP2prvAddrLine2();
	String newP2prvCity = enc837pBillprvVO.getP2prvCity();
	String newP2prvState = enc837pBillprvVO.getP2prvState();
	String newP2prvZip = enc837pBillprvVO.getP2prvZip();
	String newP2prvEntityType = enc837pBillprvVO.getP2prvEntityType();
	

	String newBillPrvCountry = enc837pBillprvVO.getBillPrvCountry();
	String newBillPrvSubCountry = enc837pBillprvVO.getBillPrvCntrySubdCd();
	
	String newP2PrvCountry = enc837pBillprvVO.getP2prvCountry();
	String newP2prvCntrySubdCd = enc837pBillprvVO.getP2prvCntrySubdCd();
	
	logger.debug("newP2prvCntrySubdCd 8888 " + enc837pBillprvVO.getP2prvCntrySubdCd());
	String newP2pOrgName = enc837pBillprvVO.getP2pOrgName();
	String newP2pPrimPayerId = enc837pBillprvVO.getP2pPrimPayerId();
	String newP2pLocNbr = enc837pBillprvVO.getP2pLocNbr();
	String newP2pAddrLine1 = enc837pBillprvVO.getP2pAddrLine1();
	String newP2pPayerIdNbr = enc837pBillprvVO.getP2pPayerIdNbr();
	String newP2pNaicCd = enc837pBillprvVO.getP2pNaicCd();
	String newP2pAddrLine2 = enc837pBillprvVO.getP2pAddrLine2();
	String newP2pPrimPlanId = enc837pBillprvVO.getP2pPrimPlanId();
	String newP2pTaxId = enc837pBillprvVO.getP2pTaxId();
	String newP2pCity = enc837pBillprvVO.getP2pCity();
	String newP2pState = enc837pBillprvVO.getP2pState();
	String newP2pZip = enc837pBillprvVO.getP2pZip();
	String newP2pCountry = enc837pBillprvVO.getP2pCountry();
	String newP2pCntrySubdCd = enc837pBillprvVO.getP2pCntrySubdCd();
	
	logger.debug("newBillPrvCountry " + newBillPrvCountry );
	logger.debug("newBillPrvSubCountry  " + newBillPrvSubCountry );
	logger.debug("newP2PrvCountry " + newP2PrvCountry );
	logger.debug("newP2PrvSubCountry 1" + newP2pCntrySubdCd ); 
	logger.debug("oldP2prvCntrySubdCd 2" + oldP2prvCntrySubdCd );
	
	int sqlCnt = -1;
	
	String fieldName = "";
	String tableName = "ENC_837P_BILLPRV";
	
	boolean dataChanged = false;	
	
	try {
		
		if(!(oldBillPrvFirstName.equals(newBillPrvFirstName))){			    
	    	fieldName = "BILL_PRV_FIRST_NAME";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvFirstName, newBillPrvFirstName,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }			
	    
		    dataChanged = true;			   
		}
		
		if(!(oldBillPrvMiddleName.equals(newBillPrvMiddleName))){			    
	    	fieldName = "BILL_PRV_MIDDLE_NAME";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvMiddleName, newBillPrvMiddleName,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }			
	    
		    dataChanged = true;			   
		}
			    	
		if(!(oldBillPrvOrgName.equals(newBillPrvOrgName))){			    
	    	fieldName = "BILL_PRV_ORG_NAME";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvOrgName, newBillPrvOrgName,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }			
	    
		    dataChanged = true;			   
		}
		
		if(!(oldBillPrvNpi.equals(newBillPrvNpi))){		    	
			fieldName = "BILL_PRV_NPI";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvNpi, newBillPrvNpi,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}
		
		if(!(oldBillPrvLicNbr.equals(newBillPrvLicNbr))){		    	
			fieldName = "BILL_PRV_LIC_NBR";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvLicNbr, newBillPrvLicNbr,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}

		if(!(oldBillPrvUpin.equals(newBillPrvUpin))){		    	
			fieldName = "BILL_PRV_UPIN";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvUpin, newBillPrvUpin,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}

		if(!(oldBillPrvSsn.equals(newBillPrvSsn))){		    	
			fieldName = "BILL_PRV_SSN";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvSsn, newBillPrvSsn,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}

		if(!(oldBillPrvEntityType.equals(newBillPrvEntityType))){			    
	    	fieldName = "BILL_PRV_ENTITY_TYPE";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvEntityType, newBillPrvEntityType,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }			
	    
		    dataChanged = true;			   
		}
	
		if(!(oldBillPrvAddrLine1.equals(newBillPrvAddrLine1))){		    	
			fieldName = "BILL_PRV_ADDR_LINE1";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvAddrLine1, newBillPrvAddrLine1,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}
		
		if(!(oldBillPrvTaxonomyId.equals(newBillPrvTaxonomyId))){		    	
			fieldName = "BILL_PRV_TAXONOMY_CD";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvTaxonomyId, newBillPrvTaxonomyId,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}
		
		if(!(oldBillPrvAddrLine2.equals(newBillPrvAddrLine2))){		    	
			fieldName = "BILL_PRV_ADDR_LINE2";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvAddrLine2, newBillPrvAddrLine2,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}
		
		if(!(oldBillPrvAffilTaxId.equals(newBillPrvAffilTaxId))){		    	
			fieldName = "BILL_PRV_AFFIL_TAX_ID";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvAffilTaxId, newBillPrvAffilTaxId,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}
		
		if(!(oldBillPrvCity.equals(newBillPrvCity))){		    	
			fieldName = "BILL_PRV_CITY";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvCity, newBillPrvCity,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}
		if(!(oldBillPrvState.equals(newBillPrvState))){		    	
			fieldName = "BILL_PRV_STATE";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvState, newBillPrvState,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}
		if(!(oldBillPrvZip.equals(newBillPrvZip))){		    	
			fieldName = "BILL_PRV_ZIP";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvZip, newBillPrvZip,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}		
		
		if(!(oldBillPrvComNbrQual1.equals(newBillPrvComNbrQual1))){		    	
			fieldName = "BILL_PRV_COM_NBR_QUAL1";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvComNbrQual1, newBillPrvComNbrQual1,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}
		if(!(oldBillPrvComNbrQual2.equals(newBillPrvComNbrQual2))){		    	
			fieldName = "BILL_PRV_COM_NBR_QUAL2";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvComNbrQual2, newBillPrvComNbrQual2,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}
		if(!(oldBillPrvComNbrQual3.equals(newBillPrvComNbrQual3))){		    	
			fieldName = "BILL_PRV_COM_NBR_QUAL3";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvComNbrQual3, newBillPrvComNbrQual3,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}
		if(!(oldBillPrvComNbr1.equals(newBillPrvComNbr1))){		    	
			fieldName = "BILL_PRV_COM_NBR1";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvComNbr1, newBillPrvComNbr1,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}
		if(!(oldBillPrvComNbr2.equals(newBillPrvComNbr2))){		    	
			fieldName = "BILL_PRV_COM_NBR2";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvComNbr2, newBillPrvComNbr2,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}
		if(!(oldBillPrvComNbr3.equals(newBillPrvComNbr3))){		    	
			fieldName = "BILL_PRV_COM_NBR3";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvComNbr3, newBillPrvComNbr3,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}
		
		if(!(oldP2prvAddrLine1.equals(newP2prvAddrLine1))){		    	
			fieldName = "P2PRV_ADDR_LINE1";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2prvAddrLine1, newP2prvAddrLine1,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}
		if(!(oldP2prvAddrLine2.equals(newP2prvAddrLine2))){		    	
			fieldName = "P2PRV_ADDR_LINE2";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2prvAddrLine2, newP2prvAddrLine2,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}
		if(!(oldP2prvEntityType.equals(newP2prvEntityType))){		    	
			fieldName = "P2PRV_ENTITY_TYPE";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2prvEntityType, newP2prvEntityType,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}	
		if(!(oldP2prvCity.equals(newP2prvCity))){		    	
			fieldName = "P2PRV_CITY";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2prvCity, newP2prvCity,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}
		if(!(oldP2prvState.equals(newP2prvState))){		    	
			fieldName = "P2PRV_STATE";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2prvState, newP2prvState,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}
		if(!(oldP2prvZip.equals(newP2prvZip))){		    	
			fieldName = "P2PRV_ZIP";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2prvZip, newP2prvZip,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}	
		
		if(!(oldBillPrvCountry.equals(newBillPrvCountry))){		    	
			fieldName = "BILL_PRV_COUNTRY";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvCountry, newBillPrvCountry,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}			
		if(!(oldBillPrvSubCountry.equals(newBillPrvCountry))){		    	
			fieldName = "BILL_PRV_CNTRY_SUBD_CD";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldBillPrvSubCountry, newBillPrvCountry,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}	
		if(!(oldP2PrvCountry.equals(newP2PrvCountry))){		    	
			fieldName = "P2PRV_COUNTRY";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2PrvCountry, newP2PrvCountry,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
	
		    dataChanged = true;
		}	                                                         
		if(!(oldP2prvCntrySubdCd.equals(newP2prvCntrySubdCd))){		    	
			fieldName = "P2PRV_CNTRY_SUBD_CD";
			logger.debug(" Change log added for oldP2PrvSubCountry");
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2prvCntrySubdCd, newP2prvCntrySubdCd,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
		    dataChanged = true;
		}	
		if(!(oldP2pOrgName.equals(newP2pOrgName))){		    	
			fieldName = "P2P_ORG_NAME";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pOrgName, newP2pOrgName,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
		    dataChanged = true;
		}	
		if(!(oldP2pPrimPayerId.equals(newP2pPrimPayerId))){		    	
			fieldName = "P2P_PRIM_PAYER_ID";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pPrimPayerId, newP2pPrimPayerId,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
		    dataChanged = true;
		}	
		if(!(oldP2pLocNbr.equals(newP2pLocNbr))){		    	
			fieldName = "P2P_LOC_NBR";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pLocNbr, newP2pLocNbr,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
		    dataChanged = true;
		}	
		if(!(oldP2pAddrLine1.equals(newP2pAddrLine1))){		    	
			fieldName = "P2P_ADDR_LINE1";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pAddrLine1, newP2pAddrLine1,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
		    dataChanged = true;
		}	
		if(!(oldP2pPayerIdNbr.equals(newP2pPayerIdNbr))){		    	
			fieldName = "P2P_PRIM_PAYER_ID";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pPayerIdNbr, newP2pPayerIdNbr,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
		    dataChanged = true;
		}	
		if(!(oldP2pNaicCd.equals(newP2pNaicCd))){		    	
			fieldName = "P2P_NAIC_CD";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pNaicCd, newP2pNaicCd,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
		    dataChanged = true;
		}	
		if(!(oldP2pAddrLine2.equals(newP2pAddrLine2))){		    	
			fieldName = "P2PRV_ADDR_LINE2";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pAddrLine2, newP2pAddrLine2,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
		    dataChanged = true;
		}	
		if(!(oldP2pPrimPlanId.equals(newP2pPrimPlanId))){		    	
			fieldName = "P2P_PRIM_PLAN_ID";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pPrimPlanId, newP2pPrimPlanId,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
		    dataChanged = true;
		}	
		if(!(oldP2pTaxId.equals(newP2pTaxId))){		    	
			fieldName = "P2P_TAX_ID";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pTaxId, newP2pTaxId,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
		    dataChanged = true;
		}	
		if(!(oldP2pCity.equals(newP2pCity))){		    	
			fieldName = "P2P_CITY";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pCity, newP2pCity,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
		    dataChanged = true;
		}	
		if(!(oldP2pState.equals(newP2pState))){		    	
			fieldName = "P2P_STATE";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pState, newP2pState,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
		    dataChanged = true;
		}	
		if(!(oldP2pZip.equals(newP2pZip))){		    	
			fieldName = "P2P_ZIP";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pZip, newP2pZip,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
		    dataChanged = true;
		}	
		if(!(oldP2pCountry.equals(newP2pCountry))){		    	
			fieldName = "P2P_COUNTRY";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pCountry, newP2pCountry,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
		    dataChanged = true;
		}	
		if(!(oldP2pCntrySubdCd.equals(newP2pCntrySubdCd))){		    	
			fieldName = "P2P_CNTRY_SUBD_CD";
		    sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, oldP2pCntrySubdCd, newP2pCntrySubdCd,userId,clmType);    
		    if (sqlCnt != 1) {
		    	throw new Exception();
		    }				
		    dataChanged = true;
		}	
		
		
		////
		if (dataChanged) {			
			encounterVO.setProfBillPrvDirty(true);
						
			sqlCnt = ChartEncounterDao.updateProfBillPrv(conn, enc837pBillprvVO);
		    if (sqlCnt != 1) {
		    	throw new Exception("Bill Prov Updt");
		    }
			
		}
		
	} catch(Exception e) {
		logger.error(LoggerConstants.exceptionMessage(e.toString()));
		message = "Error Updating Professiona Billing Provider Data";
		logger.debug(e.getMessage());
	} 
	logger.info(LoggerConstants.methodEndLevel());
	return message;									
	
	}			

//Editable Fileds CHS -- IFOX-00395627
	public HashMap<String,String> EditableUpdateCodes(Connection conn, HPEContext context, HPEEncounterVO encounterVO, String flagInd)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String msg ="";
		int sqlCnt =-1;
		
		// Retrieve DAO
			ChartEncounterDao ChartEncounterDao = new ChartEncounterDao();
			String mfId = encounterVO.getEditableMfid();
			String claimType = encounterVO.getSearchDetailClmType();
			String encType = encounterVO.getSearchDetailEncType();
			String clmNbr =  encounterVO.getSelectedClaimRefNbr();
			int clmRvNbr=  encounterVO.getSelectedClaimRevNbr();
			int clmSeqNbr = encounterVO.getSelectedClaimSeqNbr();
			int conSeqNbr = encounterVO.getEditableCndSeqNbr() ;
			String code= encounterVO.getEditableCode();
			String type =encounterVO.getEditableType();
			String poa =encounterVO.getEditablePOA();
			String date =encounterVO.getEditableDate();
			String from =encounterVO.getEditableFromDt();
			String thru = encounterVO.getEditableThruDt();
			Double amnt = encounterVO.getEditableAmount();
			String uid = encounterVO.getUserId();
			//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
			String groupCode = encounterVO.getAdjudGroupCode();
			String reasonCode = encounterVO.getAdjudReasonCode();
			Double adjudAmount = encounterVO.getAdjudAmount();
			int adjudQuantity = encounterVO.getAdjudQuantity();
			int clmliAdjudSeqNbr = encounterVO.getClmliAdjudSeqNbr();
			int clmliAdjustSeqNbr = encounterVO.getClmliAdjustSeqNbr();
			int clmliSeqNbr = encounterVO.getClmliSeqNbr();
			//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
			String recordKey = "";
			String tableName = "";
			String fieldName= "";
			boolean isPrincipleProcCode=false;
			boolean isPrincProcExists = false;
			boolean isOtherProcExists=false;
			
			HashMap<String,String> hm=new HashMap<String,String>();
			
				try {
				if (StringUtils.isNotEmpty(encounterVO.getHier())) {
					if (ChartConstants.EDITABLE_COND_CODE_CNSTNT.equals(encounterVO.getHier())) {
						
						if(StringUtils.isNotEmpty(flagInd)&& "DEL".equals(flagInd)){
							sqlCnt = ChartEncounterDao.deleteCondCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
									clmSeqNbr, conSeqNbr, code);
							
							if(sqlCnt==1){
								// Registering the insertion of codes in Claim Change log table  
								 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
								
								if(claimType.equals("I")){								
									 tableName  = "ENC_837I_CLM_COND";								
								}else{
									 tableName  = "ENC_837P_CLM_COND";
									 }
								 fieldName  = "CONDITION_CD-DELETED";							 
								 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
								 
								 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, code ,"",uid,claimType);
								
								
							}
							
							
							
						}
						else if(StringUtils.isNotEmpty(flagInd)&& "ADD".equals(flagInd)){
							 
							hm = ChartEncounterDao.addCondCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
									clmSeqNbr, conSeqNbr, code);
							sqlCnt=Integer.parseInt(hm.get("sqlCnt"));
							if(sqlCnt==1){
							// Registering the insertion of codes in Claim Change log table  
							 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
							 fieldName  = "CONDITION_CD-ADDED";
							 
							 if(encType.equals("I")){								
								 tableName  = "ENC_837I_CLM_COND";								
							}else{
								 tableName  = "ENC_837P_CLM_COND";
								 }
							 
							 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
							 
							 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, claimType,recordKey, tableName, fieldName, "" ,code,uid);	//IFOX-00408328 - Event logging issues
							 
							}
							
						}else{
							sqlCnt = ChartEncounterDao.updateCondCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
									clmSeqNbr, conSeqNbr, code);
							
							if(sqlCnt==1){
								// Registering the insertion of codes in Claim Change log table  
								 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
								 fieldName  = "CONDITION_CD-UPDATED";
								 
								 if(encType.equals("I")){								
									 tableName  = "ENC_837I_CLM_COND";								
								}else{
									 tableName  = "ENC_837P_CLM_COND";
									 }
								 
								 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
								 
								  sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, "", code,uid,claimType); 
								}
						}
						
					}

					if (ChartConstants.EDITABLE_DIAG_CODE_CNSTNT.equals(encounterVO.getHier())) {
						if(StringUtils.isNotEmpty(flagInd)&& "DEL".equals(flagInd)){
							sqlCnt = ChartEncounterDao.deleteDiagCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr, clmSeqNbr, conSeqNbr, code, type, poa);
							
							if(sqlCnt==1){
							// Registering the insertion of codes in Claim Change log table
							 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
							
							 fieldName  = "DIAG_CD-DELETED";
							 if(claimType.equals("I")){								
								 tableName  = "ENC_837I_CLM_OTHDIAG";								
							}else{
								 tableName  = "ENC_837P_CLM_OTHDIAG";
								 }
							 
							 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
							 
							 String cdVal = code+"|"+type+"|"+poa;
							 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, cdVal, "", uid,claimType);
							
							}
						}else if(StringUtils.isNotEmpty(flagInd)&& "ADD".equals(flagInd)){
							hm = ChartEncounterDao.addDiagCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr, clmSeqNbr, conSeqNbr, code, type, poa);
							sqlCnt=Integer.parseInt(hm.get("sqlCnt"));
							
							if(sqlCnt==1){						
							// Registering the insertion of codes in Claim Change log table
							 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
							 if(encType.equals("I")){								
								 tableName  = "ENC_837I_CLM_OTHDIAG";								
							}else{
								 tableName  = "ENC_837P_CLM_OTHDIAG";
								 }
							 fieldName  = "DIAG_CD-ADDED";
							 
							 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
							 
							 String cdVal = code+"|"+type+"|"+poa;
							 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, claimType,recordKey, tableName, fieldName, "" ,cdVal,uid);	//IFOX-00408328 - Event logging issues
							}
							
						}else{
							sqlCnt = ChartEncounterDao.updateDiagCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
									clmSeqNbr, conSeqNbr, code, type, poa);
							
							if(sqlCnt==1){						
								// Registering the insertion of codes in Claim Change log table
								 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
								 if(encType.equals("I")){								
									 tableName  = "ENC_837I_CLM_OTHDIAG";								
								}else{
									 tableName  = "ENC_837P_CLM_OTHDIAG";
									 }
								 fieldName  = "DIAG_CD-UPDATED";
								 
								 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
								 
								 String cdVal = code+"|"+type+"|"+poa;
								 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, "", code,uid,claimType); 
								}
						}
						
					}

					if (ChartConstants.EDITABLE_PROCEDURE_CODE_CNSTNT.equals(encounterVO.getHier())) {
							if(StringUtils.isNotEmpty(flagInd)&& "DEL".equals(flagInd)){
								if(type.equals("BR")|| type.equals("BBR")) {
									sqlCnt = ChartEncounterDao.deletePrincipalProcCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
											clmSeqNbr, conSeqNbr, code, type, date);
								}else {
								sqlCnt = ChartEncounterDao.deleteProcCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
										clmSeqNbr, conSeqNbr, code, type, date);
								}
								
								
								
								if(sqlCnt==1){	
								// Registering the insertion of codes in Claim Change log table
								 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
								
								 fieldName  = "PROC_CD-DELETED";
								 if(claimType.equals("I")){								
									 tableName  = "ENC_837I_CLM_OTHPROC";								
								}else{
									 tableName  = "ENC_837P_CLM_OTHPROC";
									 }
								 
								 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
								 
								 String cdVal = code+"|"+type+"|"+date;
								 
								 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, cdVal, "", uid,claimType);
								}
								
						}else if(StringUtils.isNotEmpty(flagInd)&& "ADD".equals(flagInd)){
							
							 /* Added for IFOX-00406912 Primary Procedure Code */	
							if ("I".equals(encType)) {
								if (type.equals("BR") || type.equals("BBR")) {
									isPrincipleProcCode = true;
									isPrincProcExists = isDuplicateEditablePrincipalProcCodes(conn, context, encounterVO,
											flagInd);
									logger.debug("isPrincProcExists------->" + isPrincProcExists);
									if (isPrincProcExists) {
										hm.put("princProc", "exists");
										return hm;
									}
								}
							}
							
							
							if (isPrincipleProcCode) {
								if ("I".equals(encType)) {
									hm = ChartEncounterDao.addPrincProcCode(conn, mfId, claimType, encType, uid, clmNbr,
											clmRvNbr, clmSeqNbr, conSeqNbr, code, type, date);
								}

							} else {
								hm = ChartEncounterDao.addProcCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
										clmSeqNbr, conSeqNbr, code, type, date);
							}
							
							
							
							
						
							sqlCnt=Integer.parseInt(hm.get("sqlCnt"));
							
							if(sqlCnt==1){	
								// Registering the insertion of codes in Claim Change log table
								 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
								
								 fieldName  = "PROC_CD-ADDED";
								 if(encType.equals("I")){								
									 tableName  = "ENC_837I_CLM_OTHPROC";								
								}else{
									 tableName  = "ENC_837P_CLM_OTHPROC";
									 }
								 
								 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
								 
								 String cdVal = code+"|"+type+"|"+date;
								 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, claimType,recordKey, tableName, fieldName, "" ,cdVal,uid);	//IFOX-00408328 - Event logging issues
								}
						}else{
							 /* Added for IFOX-00406912 Primary Procedure Code */
							if(type.equals("BR")|| type.equals("BBR")) {
								boolean isDuplicatePrincProc=ChartEncounterDao.checkDuplicatePrincipalProcCode(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr, clmSeqNbr, clmSeqNbr, code, type);
								if(isDuplicatePrincProc) {
									isOtherProcExists = ChartEncounterDao.isOtherProcCodesExists(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
											clmSeqNbr, conSeqNbr, code, type, date);
									if(!isOtherProcExists) {
									sqlCnt = ChartEncounterDao.updatePrincipalProcCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
											clmSeqNbr, conSeqNbr, code, type, date);
									}else {
										hm.put("princProc","exists");	
										return hm;
									}
								}else {
									sqlCnt = ChartEncounterDao.deleteOtherProcCodesForPrinc(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
											clmSeqNbr, conSeqNbr, code, type, date);
									hm = ChartEncounterDao.addPrincProcCode(conn, mfId, encType, claimType, uid, clmNbr, clmRvNbr, clmSeqNbr, conSeqNbr, code, type, date);
											
									
								}
								
							}else {
								boolean isDuplicatePrincProc=ChartEncounterDao.checkDuplicatePrincipalProcCode(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr, clmSeqNbr, clmSeqNbr, code, type);
								
							
								if(isDuplicatePrincProc){
									
									isOtherProcExists = ChartEncounterDao.isOtherProcCodesExists(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
											clmSeqNbr, conSeqNbr, code, type, date);
									if(isOtherProcExists) {
									sqlCnt = ChartEncounterDao.updateProcCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
											clmSeqNbr, conSeqNbr, code, type, date);
									}else {
									sqlCnt = ChartEncounterDao.deletePrincipalProcCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr, clmSeqNbr, conSeqNbr, code, type, date);
									hm = ChartEncounterDao.addProcCodes(conn, mfId, encType, claimType, uid, clmNbr, clmRvNbr,
											clmSeqNbr, conSeqNbr, code, type, date);
									}
									
								}else {
									sqlCnt = ChartEncounterDao.updateProcCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
											clmSeqNbr, conSeqNbr, code, type, date);
								}
							}
							
							
							
							if(sqlCnt==1){	
								// Registering the insertion of codes in Claim Change log table
								 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
								
								 fieldName  = "PROC_CD-UPDATED";
								 if(encType.equals("I")){								
									 tableName  = "ENC_837I_CLM_OTHPROC";								
								}else{
									 tableName  = "ENC_837P_CLM_OTHPROC";
									 }
								 
								 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
								 
								 String cdVal = code+"|"+type+"|"+date;
								 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, "", code,uid,claimType); 
								}
						}
						
					}
					if (ChartConstants.EDITABLE_OCCURSPAN_CODE_CNSTNT.equals(encounterVO.getHier())) {
						if(StringUtils.isNotEmpty(flagInd)&& "DEL".equals(flagInd)){
							sqlCnt = ChartEncounterDao.deleteOccurSpanCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
									clmSeqNbr, conSeqNbr, code, from, thru);
							
							if(sqlCnt==1){	
							
							// Registering the insertion of codes in Claim Change log table
							 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
							
							 fieldName  = "OCCUR_SPAN_CD-DELETED";
							 if(claimType.equals("I")){								
								 tableName  = "ENC_837I_CLM_OCCURSPAN";								
							}else{
								 tableName  = "ENC_837P_CLM_OCCURSPAN";
								 }
							 
							 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
							 
							 String cdVal = code+"|"+from+"|"+thru;
							 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, cdVal, "", uid,claimType);
							}
							
						}else if(StringUtils.isNotEmpty(flagInd)&& "ADD".equals(flagInd)){
							
							hm = ChartEncounterDao.addOccurSpanCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr, clmSeqNbr, conSeqNbr, code, from, thru);
							sqlCnt=Integer.parseInt(hm.get("sqlCnt"));
							
							if(sqlCnt==1){	
								
								// Registering the insertion of codes in Claim Change log table
								 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
								
								 fieldName  = "OCCUR_SPAN_CD-ADDED";
								 if(encType.equals("I")){								
									 tableName  = "ENC_837I_CLM_OCCURSPAN";								
								}else{
									 tableName  = "ENC_837P_CLM_OCCURSPAN";
									 }
								 
								 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
								 
								 String cdVal = code+"|"+from+"|"+thru;
								 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, claimType,recordKey, tableName, fieldName, "" ,cdVal,uid);	//IFOX-00408328 - Event logging issues
								}
							
							
						}else{
							sqlCnt = ChartEncounterDao.updateOccurSpanCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
									clmSeqNbr, conSeqNbr, code, from, thru);
							
	                         if(sqlCnt==1){	
								
								// Registering the insertion of codes in Claim Change log table
								 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
								
								 fieldName  = "OCCUR_SPAN_CD-UPDATED";
								 if(encType.equals("I")){								
									 tableName  = "ENC_837I_CLM_OCCURSPAN";								
								}else{
									 tableName  = "ENC_837P_CLM_OCCURSPAN";
									 }
								 
								 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
								 
								 String cdVal = code+"|"+from+"|"+thru;
								sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, "", code,uid,claimType); 
								}
						}
						
					}

					if (ChartConstants.EDITABLE_VALUE_CODE_CNSTNT.equals(encounterVO.getHier())) {
						if(StringUtils.isNotEmpty(flagInd)&& "DEL".equals(flagInd)){
							
							sqlCnt = ChartEncounterDao.deleteValueCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
									clmSeqNbr, conSeqNbr, code, amnt);
						
							
							 if(sqlCnt==1){	
							// Registering the insertion of codes in Claim Change log table
							 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
							
							 fieldName  = "VALUE_CD-DELETED";
							 if(claimType.equals("I")){								
								 tableName  = "ENC_837I_CLM_VALUE";								
							}else{
								 tableName  = "ENC_837P_CLM_VALUE";
								 }
							 
							 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
							 
							 String cdVal = code+"|"+amnt;
							 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, cdVal, "", uid,claimType);
							
							 }
							
						}else if(StringUtils.isNotEmpty(flagInd)&& "ADD".equals(flagInd)){
							hm = ChartEncounterDao.addValueCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
									clmSeqNbr, conSeqNbr, code, amnt);
							sqlCnt=Integer.parseInt(hm.get("sqlCnt"));
							
							 if(sqlCnt==1){	
									// Registering the insertion of codes in Claim Change log table
									 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
									
									 fieldName  = "VALUE_CD-ADDED";
									 if(encType.equals("I")){								
										 tableName  = "ENC_837I_CLM_VALUE";								
									}else{
										 tableName  = "ENC_837P_CLM_VALUE";
										 }
									 
									 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
									 
									 String cdVal = code+"|"+amnt;
									 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, claimType,recordKey, tableName, fieldName, "" ,cdVal,uid);	//IFOX-00408328 - Event logging issues
									
									 }
							
							
						}else{
							
							sqlCnt = ChartEncounterDao.updateValueCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
									clmSeqNbr, conSeqNbr, code, amnt);
							
							 if(sqlCnt==1){	
									// Registering the insertion of codes in Claim Change log table
									 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
									
									 fieldName  = "VALUE_CD-UPDATED";
									 if(encType.equals("I")){								
										 tableName  = "ENC_837I_CLM_VALUE";								
									}else{
										 tableName  = "ENC_837P_CLM_VALUE";
										 }
									 
									 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
									 
									 String cdVal = code+"|"+amnt;
									 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, "", code,uid,claimType); 
									
									 }
						}
						
					}

					if (ChartConstants.EDITABLE_OCCURENCE_CODE_CNSTNT.equals(encounterVO.getHier())) {
						if(StringUtils.isNotEmpty(flagInd)&& "DEL".equals(flagInd)){
							
							sqlCnt = ChartEncounterDao.deleteOccurCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
									clmSeqNbr, conSeqNbr, code, date);

							 if(sqlCnt==1){		
							// Registering the insertion of codes in Claim Change log table
							 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
							
							 fieldName  = "OCCURENCE_CD-DELETED";
							 
							 if(claimType.equals("I")){								
								 tableName  = "ENC_837I_CLM_OCCUR";								
							}else{
								 tableName  = "ENC_837P_CLM_OCCUR";	//IFOX-00408328 - Event logging issues
								 }
							 
							 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
							 
							 String cdVal = code+"|"+date;
							 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, cdVal, "", uid,claimType);
							
							 }
							
						}else if(StringUtils.isNotEmpty(flagInd)&& "ADD".equals(flagInd)){
							
							hm = ChartEncounterDao.addOccurCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
									clmSeqNbr, conSeqNbr, code, date);
							sqlCnt=Integer.parseInt(hm.get("sqlCnt"));
							
							 if(sqlCnt==1){		
									// Registering the insertion of codes in Claim Change log table
									 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
									
									 fieldName  = "OCCURENCE_CD-ADDED";
									 
									 if(encType.equals("I")){								
										 tableName  = "ENC_837I_CLM_OCCUR";								
									}else{
										 tableName  = "ENC_837P_CLM_OCCUR";
										 }
									 
									 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
									 
									 String cdVal = code+"|"+date;
									 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, claimType,recordKey, tableName, fieldName, "" ,cdVal,uid);	//IFOX-00408328 - Event logging issues
									
									 }
							
							
						}else{
							
							sqlCnt = ChartEncounterDao.updateOccurCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
									clmSeqNbr, conSeqNbr, code, date);
							
							 if(sqlCnt==1){		
									// Registering the insertion of codes in Claim Change log table
									 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
									
									 fieldName  = "OCCURENCE_CD-UPDATED";
									 
									 if(encType.equals("I")){								
										 tableName  = "ENC_837I_CLM_OCCUR";								
									}else{
										 tableName  = "ENC_837P_CLM_OCCUR";
										 }
									 
									 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
									 
									 String cdVal = code+"|"+date;
									 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, "", code,uid,claimType); 
									
									 }
						}
						

					}

					if (ChartConstants.EDITABLE_TREATMENT_CODE_CNSTNT.equals(encounterVO.getHier())) {
						if(StringUtils.isNotEmpty(flagInd)&& "DEL".equals(flagInd)){
							
							sqlCnt = ChartEncounterDao.deleteTreatCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
									clmSeqNbr, conSeqNbr, code);
							
							if(sqlCnt==1){	
							// Registering the insertion of codes in Claim Change log table
							 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
							
							 fieldName  = "TREATMENT_CD-DELETED";
							 
							 if(claimType.equals("I")){								
								 tableName  = "ENC_837I_CLM_TREAT";							
							}else{
								 tableName  = "ENC_837P_CLM_TREAT";
								 }
							 
							 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
							 
							 String cdVal = code;
							 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, cdVal, "", uid,claimType);
							}
							
						}else if(StringUtils.isNotEmpty(flagInd)&& "ADD".equals(flagInd)){
							
							hm = ChartEncounterDao.addTreatCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
									clmSeqNbr, conSeqNbr, code);
							sqlCnt=Integer.parseInt(hm.get("sqlCnt"));
							
							if(sqlCnt==1){	
								// Registering the insertion of codes in Claim Change log table
								 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
								
								 fieldName  = "TREATMENT_CD-ADDED";
								 
								 if(encType.equals("I")){								
									 tableName  = "ENC_837I_CLM_TREAT";							
								}else{
									 tableName  = "ENC_837P_CLM_TREAT";
									 }
								 
								 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
								 
								 String cdVal = code;
								 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, claimType,recordKey, tableName, fieldName, "" ,cdVal,uid);	//IFOX-00408328 - Event logging issues
								}
							
							
							
						}else{
							sqlCnt = ChartEncounterDao.updateTreatCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
									clmSeqNbr, conSeqNbr, code);
							
							
							if(sqlCnt==1){	
								// Registering the insertion of codes in Claim Change log table
								 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
								
								 fieldName  = "TREATMENT_CD-UPDATED";
								 
								 if(encType.equals("I")){								
									 tableName  = "ENC_837I_CLM_TREAT";							
								}else{
									 tableName  = "ENC_837P_CLM_TREAT";
									 }
								 
								 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
								 
								 String cdVal = code;
								 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, "", code,uid,claimType); 
								}
						}
						

					}

					if (ChartConstants.EDITABLE_EXT_INJ_CODE_CNSTNT.equals(encounterVO.getHier())) {
						if(StringUtils.isNotEmpty(flagInd)&& "DEL".equals(flagInd)){
							
							sqlCnt = ChartEncounterDao.deleteExtInjCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
									clmSeqNbr, conSeqNbr, type, code, poa);
							
							if(sqlCnt==1){	
							// Registering the insertion of codes in Claim Change log table
							 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
							
							 fieldName  = "EXTCAUSEOFINJURY_CD-DELETED";
							 if(encType.equals("I")){	//IFOX-00408328 - Event logging issues								
								 tableName  = "ENC_837I_CLM_EXTINJ";							
							}else{
								 tableName  = "ENC_837P_CLM_EXTINJ";
								 }
							 
							 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
							 
							 String cdVal = code+"|"+type+"|"+poa;
							sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, cdVal, "", uid,claimType);
							}
							
						}else if(StringUtils.isNotEmpty(flagInd)&& "ADD".equals(flagInd)){
							hm = ChartEncounterDao.addExtInjCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
									clmSeqNbr, conSeqNbr, type, code, poa);
							sqlCnt=Integer.parseInt(hm.get("sqlCnt"));
							
							if(sqlCnt==1){	
								// Registering the insertion of codes in Claim Change log table
								 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
								
								 fieldName  = "EXTCAUSEOFINJURY_CD-ADDED";
								 if(encType.equals("I")){								
									 tableName  = "ENC_837I_CLM_EXTINJ";							
								}else{
									 tableName  = "ENC_837P_CLM_EXTINJ";
									 }
								 
								 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
								 
								 String cdVal = code+"|"+type+"|"+poa;
								 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, claimType,recordKey, tableName, fieldName, "" ,cdVal,uid);	//IFOX-00408328 - Event logging issues
								}
							
						}else{
							sqlCnt = ChartEncounterDao.updateExtInjCodes(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
									clmSeqNbr, conSeqNbr, type, code, poa);
							
							
							if(sqlCnt==1){	
								// Registering the insertion of codes in Claim Change log table
								 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
								
								 fieldName  = "EXTCAUSEOFINJURY_CD-UPDATED";
								 if(encType.equals("I")){								
									 tableName  = "ENC_837I_CLM_EXTINJ";							
								}else{
									 tableName  = "ENC_837P_CLM_EXTINJ";
									 }
								 
								 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
								 
								 String cdVal = code+"|"+type+"|"+poa;
								 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, "", code,uid,claimType); 
								}
						}
					}
					//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - Start
						if (ChartConstants.EDITABLE_CLMLINE_ADJUD_ADJUST.equals(encounterVO.getHier())) {
							if(StringUtils.isNotEmpty(flagInd)&& "ADD".equals(flagInd)){
								
								
								hm = ChartEncounterDao.addClmLineAdjudAjust(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
										clmSeqNbr, conSeqNbr, groupCode, reasonCode, adjudAmount, adjudQuantity, clmliSeqNbr, clmliAdjudSeqNbr);
								sqlCnt=Integer.parseInt(hm.get("sqlCnt"));
								
								if(sqlCnt==1){	
									// Registering the insertion of codes in Claim Change log table
									 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
									
									 fieldName  = "CLMLINE_ADJUST-ADDED";
									 if(claimType.equals("I")){								
										 tableName  = "ENC_837I_CLMLINE_ADJUST";							
									}else{
										 tableName  = "ENC_837P_CLMLINE_ADJUST";
										 }
									 
									 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
									 
									 String cdVal = groupCode+"|"+reasonCode+"|"+adjudAmount+"|"+adjudQuantity;
//									 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, encType,recordKey, tableName, fieldName, "" ,cdVal,uid);
									 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, cdVal, "", uid,encType);
									}//EDITABLE_CLMLINE_ADJUD_ADJUST
								
							}else if(StringUtils.isNotEmpty(flagInd)&& "UPDT".equals(flagInd)){
								
								sqlCnt = ChartEncounterDao.updateClmLineAdjudAjust(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,clmSeqNbr, 
										conSeqNbr, groupCode, reasonCode, adjudAmount, adjudQuantity, clmliSeqNbr, clmliAdjudSeqNbr, clmliAdjustSeqNbr);
								
								if(sqlCnt==1){	
									// Registering the insertion of codes in Claim Change log table
									 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
									
									 fieldName  = "CLMLINE_ADJUST-UPDATED";
									 if(claimType.equals("I")){								
										 tableName  = "ENC_837I_CLMLINE_ADJUST";							
									}else{
										 tableName  = "ENC_837P_CLMLINE_ADJUST";
										 }
									 
									 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
									 
									 String cdVal = groupCode+"|"+reasonCode+"|"+adjudAmount+"|"+adjudQuantity;
//									 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, encType,recordKey, tableName, fieldName, "" ,cdVal,uid);
									 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, "", cdVal,uid,encType);
									}//EDITABLE_CLMLINE_ADJUD_ADJUST
							}else if(StringUtils.isNotEmpty(flagInd)&& "DEL".equals(flagInd)){
								sqlCnt = ChartEncounterDao.deleteClmLineAdjudAjust(conn, mfId, claimType, encType, uid, clmNbr, clmRvNbr,
										clmSeqNbr, conSeqNbr, groupCode, reasonCode, adjudAmount, adjudQuantity, clmliSeqNbr, clmliAdjudSeqNbr, clmliAdjustSeqNbr);
								
								if(sqlCnt==1){	
									// Registering the insertion of codes in Claim Change log table
									 recordKey = mfId+"|"+clmNbr+"|"+clmRvNbr+"|"+clmSeqNbr+"|"+encType;
									
									 fieldName  = "CLMLINE_ADJUST-DELETED";
									 if(claimType.equals("I")){								
										 tableName  = "ENC_837I_CLMLINE_ADJUST";							
									}else{
										 tableName  = "ENC_837P_CLMLINE_ADJUST";
										 }
									 
									 ChartEncounterDao.setClaimDetailString(clmNbr + "|" + clmRvNbr + "|" +clmSeqNbr);
									 
									 String cdVal = groupCode+"|"+reasonCode+"|"+adjudAmount+"|"+adjudQuantity;
//									 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, encType,recordKey, tableName, fieldName, "" ,cdVal,uid);
									 sqlCnt = ChartEncounterDao.insertEncClmChgLog(conn, mfId, recordKey, tableName, fieldName, cdVal, "", uid,encType);
									}//EDITABLE_CLMLINE_ADJUD_ADJUST
							}
						}
						//IFOX-00413184 - Opening of Claim Adjudication fields and amounts - End
				}
				} catch (Exception e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					throw new ApplicationException("Exception selecting", e);
				}
				hm.put("sqlCnt",sqlCnt+"");
				logger.info(LoggerConstants.methodEndLevel());
				return hm;
			}

	 /* Added for IFOX-00406912 Primary Procedure Code */
	public boolean isDuplicateEditablePrincipalProcCodes(Connection conn, HPEContext context, HPEEncounterVO encounterVO, String flagInd)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		boolean msg =false;
		
		// Retrieve DAO
			ChartEncounterDao chartEncounterDao = new ChartEncounterDao();
			String mfId = encounterVO.getEditableMfid();
			String claimType = encounterVO.getSearchDetailClmType();
			String encType = encounterVO.getSearchDetailEncType();
			String clmNbr =  encounterVO.getSelectedClaimRefNbr();
			int clmRvNbr=  encounterVO.getSelectedClaimRevNbr();
			int clmSeqNbr = encounterVO.getSelectedClaimSeqNbr();
			int conSeqNbr = encounterVO.getEditableCndSeqNbr() ;
			String code= encounterVO.getEditableCode();
			String type =encounterVO.getEditableType();
			String uid = encounterVO.getUserId();
			
			try{
	              msg = chartEncounterDao.checkDuplicatePrincipalProcCode(conn, mfId, encType, claimType, uid, clmNbr, clmRvNbr, clmSeqNbr, conSeqNbr, code, type);						
							
			}catch (Exception e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
					throw new ApplicationException("Exception selecting", e);
			}
			logger.info(LoggerConstants.methodEndLevel());
			return msg;
		}


}
