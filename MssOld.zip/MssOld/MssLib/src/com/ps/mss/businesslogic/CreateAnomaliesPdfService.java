package com.ps.mss.businesslogic;


import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.List;

import org.slf4j.Logger;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.model.McaidAnomDashBoardVO;
import com.ps.mss.dao.model.McaidAnomSummDetailDataVO;
import com.ps.mss.dao.model.McaidAnomSummDetailVO;
import com.ps.mss.dao.model.McaidPaymentDashBoardVO;
import com.ps.mss.helper.McaidReconHelper;
import com.ps.mss.model.McaidReconAnomVO;
import com.ps.mss.model.McaidReconPaymentVO;

/**
 *
 * @author bsanthos
 */
public class CreateAnomaliesPdfService {
/**
 * 
 * @param dataList
 * @return
 * @throws Exception
 */
	private static Logger logger=LoggerFactory.getLogger(CreateAnomaliesPdfService.class);

	public ByteArrayOutputStream createDashboardPDFReport(List dataList) throws Exception{
		
		logger.info(LoggerConstants.methodStartLevel());
	    
	    PdfContentByte contentByte;
	    ByteArrayOutputStream baosPDF;
	     
	   
	    try {
	        //connection=DbLocator.getInstance().getConnection("APPLDS");         
	         
	         
	        /*
	         * PDF generation using iText library
	         */
	        Document doc = new Document(PageSize.A4,16,16,36,36);
	        baosPDF = new ByteArrayOutputStream();
	        Font bfBold12 = FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD, Color.BLACK); 
	        Font font = FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL, Color.BLACK);
	        try {
	        	
        	  PdfWriter docWriter = PdfWriter.getInstance(doc, baosPDF);              
	             doc.open();             
	             Paragraph paragraph = new Paragraph("Anomaly Dashboard",FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD, Color.BLACK));
	             paragraph.setAlignment(Paragraph.ALIGN_CENTER);
	             doc.add(paragraph);
	             paragraph = new Paragraph("\n \n");
	             doc.add(paragraph);
	         
	            PdfPTable table = new PdfPTable(6);
	            table.setWidthPercentage(100f);
	            table.getDefaultCell().setUseAscender(true);
	            table.getDefaultCell().setUseDescender(true);
	            // define table header cell
	            PdfPCell cell;
	            // write table header
	            cell=new PdfPCell(new Phrase("PBP/Period",bfBold12));
	            cell.setPadding(2.5f);
	            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            
	            table.addCell(cell);
	             
//	            cell.setPhrase("State Paid", bfBold12);
	            cell=new PdfPCell(new Phrase("Total",bfBold12));
	            cell.setPadding(2.5f);
	            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            table.addCell(cell);
	     
//	            cell.setPhrase(new Phrase("Plan Expected", bfBold12));
	            cell=new PdfPCell(new Phrase("Open",bfBold12));
	            cell.setPadding(2.5f);
	            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            table.addCell(cell);
	             
//	            cell.setPhrase(new Phrase("Difference", bfBold12));
	            cell=new PdfPCell(new Phrase("In Progress",bfBold12));
	            cell.setPadding(2.5f);
	            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            table.addCell(cell);
	            
	            cell=new PdfPCell(new Phrase("Force Closed",bfBold12));
	            cell.setPadding(2.5f);
	            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            table.addCell(cell);
	            
	            cell=new PdfPCell(new Phrase("Resolved",bfBold12));
	            cell.setPadding(2.5f);
	            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            table.addCell(cell);

	            for (int pbpIndex = 0; pbpIndex < dataList.size(); pbpIndex++) {
	            	McaidAnomDashBoardVO pbpData = (McaidAnomDashBoardVO) dataList.get(pbpIndex);
					
					cell=new PdfPCell(new Phrase(pbpData.getPbpDesc(),font));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		            cell.setVerticalAlignment(Element.ALIGN_LEFT);
					table.addCell(cell);
					
//					table.addCell(pbpData.getCmsPaid());
					cell=new PdfPCell(new Phrase(pbpData.getTotal(),font));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
					table.addCell(cell);
					
//					table.addCell(new Phrase(new Chunk(pbpData.getPlanExpected())));
					cell=new PdfPCell(new Phrase(pbpData.getOpen(),font));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
					table.addCell(cell);
					
//					table.addCell(pbpData.getDiffrence());
					cell=new PdfPCell(new Phrase(pbpData.getInProgress(),font));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
					table.addCell(cell);

					cell=new PdfPCell(new Phrase(pbpData.getForceClose(),font));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
					table.addCell(cell);
					
					cell=new PdfPCell(new Phrase(pbpData.getResolved(),font));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
		         	table.addCell(cell);

					List yearDataList = pbpData.getPbpYrOrQtrOrMonLst();
					if (yearDataList != null) {// yearIf
						for (int yearIndex = 0; yearIndex < yearDataList.size(); yearIndex++) {
							McaidAnomDashBoardVO yearData = (McaidAnomDashBoardVO) yearDataList.get(yearIndex);
							
							cell=new PdfPCell(new Phrase(yearData.getYear(),font));
//							cell.setBorder(Rectangle.LEFT);
							cell.setPadding(2.5f);
				            cell.setPaddingLeft(16f);
				        	table.addCell(cell);
							
//							table.addCell(pbpData.getCmsPaid());
							cell=new PdfPCell(new Phrase(yearData.getTotal(),font));
				            cell.setPadding(2.5f);
				            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
				            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
//				        	cell.setBorder(Rectangle.NO_BORDER);
							table.addCell(cell);
				            
//							table.addCell(new Phrase(new Chunk(pbpData.getPlanExpected())));
							cell=new PdfPCell(new Phrase(yearData.getOpen(),font));
				            cell.setPadding(2.5f);
				            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
				            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
//				        	cell.setBorder(Rectangle.NO_BORDER);
							table.addCell(cell);
				        	
				        	cell=new PdfPCell(new Phrase(yearData.getInProgress(),font));
				            cell.setPadding(2.5f);
				            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
				            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
//				           	cell.setBorder(Rectangle.NO_BORDER);
							table.addCell(cell);
				        	
				        	cell=new PdfPCell(new Phrase(yearData.getForceClose(),font));
				            cell.setPadding(2.5f);
				            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
				            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
//				        	cell.setBorder(Rectangle.NO_BORDER);
							table.addCell(cell);
				            
//							table.addCell(pbpData.getDiffrence());
							cell=new PdfPCell(new Phrase(yearData.getResolved(),font));
				            cell.setPadding(2.5f);
				            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
				            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
//				        	cell.setBorder(Rectangle.RIGHT);
//				        	if(yearIndex==(yearDataList.size()-1))
//							{cell.setBorder(Rectangle.RIGHT);
//								cell.setBorder(Rectangle.BOTTOM);	
//								
//							}
				        	table.addCell(cell);
				        	
							List qtrDataList = yearData.getPbpYrOrQtrOrMonLst();
							if (qtrDataList != null) {// qtrIf
								for (int qtrIndex = 0; qtrIndex < qtrDataList.size(); qtrIndex++) {
									McaidAnomDashBoardVO qtrData = (McaidAnomDashBoardVO) qtrDataList.get(qtrIndex);
									
									
									cell=new PdfPCell(new Phrase(qtrData.getQuarter(),font));
//									cell.setBorder(Rectangle.LEFT);
									cell.setPadding(2.5f);
						            cell.setPaddingLeft(25f);
						         	table.addCell(cell);
									
									cell=new PdfPCell(new Phrase(qtrData.getTotal(),font));
//									cell.setBorder(Rectangle.LEFT);
									cell.setPadding(2.5f);
						            cell.setPaddingLeft(25f);
//						        	cell.setBorder(Rectangle.NO_BORDER);
									table.addCell(cell);
									
									cell=new PdfPCell(new Phrase(qtrData.getOpen(),font));
//									cell.setBorder(Rectangle.LEFT);
									cell.setPadding(2.5f);
						            cell.setPaddingLeft(25f);
//						        	cell.setBorder(Rectangle.NO_BORDER);
									table.addCell(cell);
									
									cell=new PdfPCell(new Phrase(qtrData.getInProgress(),font));
						            cell.setPadding(2.5f);
//						        	cell.setBorder(Rectangle.NO_BORDER);
						            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
						            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
//						        	cell.setBorder(Rectangle.NO_BORDER);
									table.addCell(cell);
								
									
									cell=new PdfPCell(new Phrase(qtrData.getForceClose(),font));
						            cell.setPadding(2.5f);
						            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
						            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
//						        	cell.setBorder(Rectangle.NO_BORDER);
									table.addCell(cell);
//									table.addCell(pbpData.getDiffrence());
									
									cell=new PdfPCell(new Phrase(qtrData.getResolved(),font));
						            cell.setPadding(2.5f);
						            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
						            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
						        	/*cell.setBorder(Rectangle.RIGHT);
						    		if(qtrIndex==qtrDataList.size()-1)
									{   cell.setBorder(Rectangle.RIGHT);
										cell.setBorder(Rectangle.BOTTOM);	
											
									}*/
						      
									
						            table.addCell(cell);
									
									List monthDataList = qtrData.getPbpYrOrQtrOrMonLst();
									if (monthDataList != null) {// monthIf
										for (int monthIndex = 0; monthIndex < monthDataList.size(); monthIndex++) {
											McaidAnomDashBoardVO monthData = (McaidAnomDashBoardVO) monthDataList.get(monthIndex);
											
											String revicedMonth = getMonthName(Integer.parseInt(monthData.getMonth()));
											cell=new PdfPCell(new Phrase(revicedMonth,font));
//											cell.setBorder(Rectangle.LEFT);
											cell.setPadding(2.5f);
								            cell.setPaddingLeft(35f);
								        	table.addCell(cell);
											
//											table.addCell(pbpData.getCmsPaid());
											cell=new PdfPCell(new Phrase(monthData.getTotal(),font));
								            cell.setPadding(2.5f);
								            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
											cell.setVerticalAlignment(Element.ALIGN_RIGHT);
//										    cell.setBorder(Rectangle.NO_BORDER);
											table.addCell(cell);
											
											cell=new PdfPCell(new Phrase(monthData.getOpen(),font));
								            cell.setPadding(2.5f);
								            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
											cell.setVerticalAlignment(Element.ALIGN_RIGHT);
//										    cell.setBorder(Rectangle.NO_BORDER);
											table.addCell(cell);
											
											cell=new PdfPCell(new Phrase(monthData.getInProgress(),font));
								            cell.setPadding(2.5f);
								            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
											cell.setVerticalAlignment(Element.ALIGN_RIGHT); 
//											cell.setBorder(Rectangle.NO_BORDER);
											table.addCell(cell);
											
//											table.addCell(new Phrase(new Chunk(pbpData.getPlanExpected())));
											cell=new PdfPCell(new Phrase(monthData.getForceClose(),font));
								            cell.setPadding(2.5f);
								            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
								            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
//								            cell.setBorder(Rectangle.NO_BORDER);
											table.addCell(cell);
//											table.addCell(pbpData.getDiffrence());
											
											cell=new PdfPCell(new Phrase(monthData.getResolved(),font));
								            cell.setPadding(2.5f);
								            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
								            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
								            /*cell.setBorder(Rectangle.RIGHT);
								            if(monthIndex==monthDataList.size()-1)
											{
								            	cell.setBorder(Rectangle.RIGHT);
												cell.setBorder(Rectangle.BOTTOM);	
													
											}*/
								           	table.addCell(cell);
											
										}// month for
									}// monthIf
								}// qtr for loop
							}// qtr if
						}// Year for loop
					}// yearIf End
				}// Base for loop
	           
	            doc.add(table);
	        }
	        catch(Exception e){
	        	logger.error(LoggerConstants.exceptionMessage(e.toString()));
	            logger.debug("Error-->generatePDFReport"+e);
	            throw new Exception(e);
	        }
	        doc.close();
	         
	         
	    }
	    catch (Exception e){
	    	logger.error(LoggerConstants.exceptionMessage(e.toString()));
	        logger.debug("Error-->generatePDFReport"+e);
	        throw new Exception(e);
	    }
	    finally{
	    	 logger.debug("finally:::::::::PDF");   
	        //DbLocator.closeConnection(connection);
	    }
	    logger.info(LoggerConstants.methodEndLevel());   
	    return baosPDF;
	}

	public ByteArrayOutputStream createSummaryCurrentPDFReport(Document doc,McaidReconPaymentVO data, List dataList, List dataList1) throws DocumentException {
		logger.info(LoggerConstants.methodStartLevel());
		ByteArrayOutputStream baosPDF;
		baosPDF = new ByteArrayOutputStream();
		
		Font bfBold12 = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD, Color.BLACK);
//		Paragraph para = new Paragraph(new Phrase());
//        para.setAlignment(Paragraph.ALIGN_LEFT);
        doc.add(new Chunk(data.getSummPageLabel1()));
        Paragraph para = new Paragraph("\n \n");
        doc.add(para);
        
//        Paragraph paragrph = new Paragraph(new Phrase(new Chunk("Total Payment",bfBold12)));
//        paragrph.setAlignment(Paragraph.ALIGN_LEFT);
        doc.add(new Chunk("Total Payment",bfBold12));
        Paragraph paragrph = new Paragraph("\n");
        doc.add(paragrph);
		
        PdfPTable table = new PdfPTable(6);
        table.setWidthPercentage(100f);

        table.getDefaultCell().setUseAscender(true);
        table.getDefaultCell().setUseDescender(true);

        // define table header cell
        PdfPCell cell;
        
        cell=new PdfPCell(new Phrase("State Paid : ",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM|Rectangle.LEFT);
        table.addCell(cell);
        
        cell=new PdfPCell(new Phrase(data.getSummDataCmsPaid(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_LEFT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM);
        table.addCell(cell);
        
        cell=new PdfPCell(new Phrase("Plan Expected : ",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM);
        table.addCell(cell);
        
        cell=new PdfPCell(new Phrase(data.getSummDataPlanExpected(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_LEFT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM);
        table.addCell(cell);
        
        cell=new PdfPCell(new Phrase("Difference : ",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM);
        table.addCell(cell);
        
        cell=new PdfPCell(new Phrase(data.getSummDataDiffrence(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_LEFT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM|Rectangle.RIGHT);
        table.addCell(cell);
        
        doc.add(table);
        
        paragrph = new Paragraph("\n");
        doc.add(paragrph);
        
        PdfPTable table1 = new PdfPTable(4);
        table1.setWidthPercentage(100f);
        cell=new PdfPCell(new Phrase("PBP",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table1.addCell(cell);
        
        cell=new PdfPCell(new Phrase("State Paid",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table1.addCell(cell);
        
        cell=new PdfPCell(new Phrase("Plan Expected",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table1.addCell(cell);
        
        cell=new PdfPCell(new Phrase("Difference",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table1.addCell(cell);
        
//        McaidPaymentDashBoardVO datatemp = (McaidPaymentDashBoardVO) dataList;
        int index = 0;       
        for (int pbpIndex = 0; pbpIndex < dataList.size(); pbpIndex++) {
            McaidPaymentDashBoardVO datatemp = (McaidPaymentDashBoardVO) dataList.get(pbpIndex);
            index++;
        cell=new PdfPCell(new Phrase(datatemp.getPbpDesc(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table1.addCell(cell);
        
        cell=new PdfPCell(new Phrase(datatemp.getCmsPaid(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        table1.addCell(cell);
        
        cell=new PdfPCell(new Phrase(datatemp.getPlanExpected(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        table1.addCell(cell);
        
        cell=new PdfPCell(new Phrase(datatemp.getDiffrence(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        table1.addCell(cell);
        
        }
        doc.add(table1);
        
        
//        Chunk  chunk = new  Chunk("Payment Details",bfBold12);
    //    //        paragrph1.setAlignment(Paragraph.ALIGN_LEFT);
        doc.add( new  Chunk("Payment Details",bfBold12));
        Paragraph   paragrph1 = new Paragraph("\n");
        doc.add(paragrph1);
		
        PdfPTable table3 = new PdfPTable(6);
        table3.setWidthPercentage(100f);

        table3.getDefaultCell().setUseAscender(true);
        table3.getDefaultCell().setUseDescender(true);

        // define table header cell
//        PdfPCell cell;
        
        cell=new PdfPCell(new Phrase("State Paid : ",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM|Rectangle.LEFT);
        table3.addCell(cell);
        
        cell=new PdfPCell(new Phrase(data.getSummDetailCmsPaid(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_LEFT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM);
        table3.addCell(cell);
        
        
        cell=new PdfPCell(new Phrase("Plan Expected : ",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM);
        table3.addCell(cell);
        
        cell=new PdfPCell(new Phrase(data.getSummDetailPlanExpected(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_LEFT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM);
        table3.addCell(cell);
        
        cell=new PdfPCell(new Phrase("Difference : ",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM);
        table3.addCell(cell);
        
        cell=new PdfPCell(new Phrase(data.getSummDetailDiffrence(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_LEFT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM|Rectangle.RIGHT);
        table3.addCell(cell);
        
        doc.add(table3);
        
        paragrph = new Paragraph("\n");
        doc.add(paragrph);
        
        PdfPTable table4 = new PdfPTable(5);
        table4.setWidthPercentage(100f);
        cell=new PdfPCell(new Phrase("Payment Type",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table4.addCell(cell);
        
        cell=new PdfPCell(new Phrase("Description",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table4.addCell(cell);
        
        cell=new PdfPCell(new Phrase("State Paid",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table4.addCell(cell);
        
        cell=new PdfPCell(new Phrase("Plan Expected",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table4.addCell(cell);
        
        cell=new PdfPCell(new Phrase("Difference",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table4.addCell(cell);
        
//        McaidPaymentDashBoardVO datatemp = (McaidPaymentDashBoardVO) dataList;
        for (int paymentIndex = 0; paymentIndex < dataList1.size(); paymentIndex++) {
            McaidPaymentDashBoardVO datatemp1 = (McaidPaymentDashBoardVO) dataList1.get(paymentIndex);
            index++;
        cell=new PdfPCell(new Phrase(datatemp1.getPbpId(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table4.addCell(cell);
        
        cell=new PdfPCell(new Phrase(datatemp1.getPbpDesc(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table4.addCell(cell);
        
        cell=new PdfPCell(new Phrase(datatemp1.getCmsPaid(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        table4.addCell(cell);
        
        cell=new PdfPCell(new Phrase(datatemp1.getPlanExpected(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        table4.addCell(cell);
        
        cell=new PdfPCell(new Phrase(datatemp1.getDiffrence(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        table4.addCell(cell);
        
        doc.add(table4);
        }
		
        logger.info(LoggerConstants.methodEndLevel());
		return baosPDF;
	}
	/**
	 * 
	 * @param mcaidAnomSummDetailDataVO 
	 * @param string 
	 * @param mcaidPymntSummLst
	 * @param mcaidPymntSummDetailLst
	 * @return
	 * @throws DocumentException 
	 */
		public ByteArrayOutputStream createSummaryPDFReport(String string, List dataList, McaidAnomSummDetailDataVO mcaidAnomSummDetailDataVO) throws DocumentException {
			logger.info(LoggerConstants.methodStartLevel());
			ByteArrayOutputStream baosPDF;
			Document doc = new Document(PageSize.A4,16,16,36,36);
		    baosPDF = new ByteArrayOutputStream();
		    int headingFontSize = 14;
			PdfWriter docWriter = PdfWriter.getInstance(doc, baosPDF);
			Font bfBold12 = FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD, Color.BLACK);
			Font font = FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL, Color.BLACK);
	        doc.open();             
	        Paragraph paragraph = new Paragraph("Anomaly Summary",FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD, Color.BLACK));
	        paragraph.setAlignment(Paragraph.ALIGN_CENTER);
	        doc.add(paragraph);
	        paragraph = new Paragraph("\n \n");
	        doc.add(paragraph);
	        Paragraph paragraph1 = new Paragraph("Anomaly Details",bfBold12);
	        paragraph1.setAlignment(Paragraph.ALIGN_LEFT);
	        doc.add(paragraph1);
	        Paragraph paragraph12 = new Paragraph("\n");
	        doc.add(paragraph12);	        
	        Paragraph paragraph2 = new Paragraph(string,bfBold12);
	        paragraph2.setAlignment(Paragraph.ALIGN_LEFT);
	        doc.add(paragraph2);
	        paragraph = new Paragraph("\n");
	        paragraph = new Paragraph(new Chunk("Anomaly List",bfBold12));
            doc.add(paragraph);
            paragraph = new Paragraph("\n");
            
            PdfPTable table = new PdfPTable(8);
	        table.setWidthPercentage(100f);
            table.getDefaultCell().setUseAscender(true);
	        table.getDefaultCell().setUseDescender(true);
	         
	        PdfPCell cell;
	         // write table header
	         cell=new PdfPCell(new Phrase("Medicaid ID",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
            
	         cell=new PdfPCell(new Phrase("Anomaly",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);

	         cell=new PdfPCell(new Phrase("Eff Date",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);

	         cell=new PdfPCell(new Phrase("Status",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("PBP",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
            
	         cell=new PdfPCell(new Phrase("Anomaly Type",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);

	         cell=new PdfPCell(new Phrase("User ID",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);

	         cell=new PdfPCell(new Phrase("Last Update",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
	        
	         int pbpIndex=0;
	         for (int index = 0; index < dataList.size(); index++) {
//	             row = sheet.createRow(index + 1);            
	             McaidAnomSummDetailVO data = (McaidAnomSummDetailVO) dataList.get(index);
	             pbpIndex++;
	             
	            cell=new PdfPCell(new Phrase(data.getMedicaidId(),font));
	            cell.setPadding(2.5f);
	            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell.setVerticalAlignment(Element.ALIGN_CENTER);
				table.addCell(cell);
				
				cell=new PdfPCell(new Phrase(data.getAnomaly(),font));
	            cell.setPadding(2.5f);
	            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell.setVerticalAlignment(Element.ALIGN_CENTER);
				table.addCell(cell);
				
				cell=new PdfPCell(new Phrase(McaidReconHelper.dateMonthByYearFormat(data.getEffDate()),font));
	            cell.setPadding(2.5f);
	            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell.setVerticalAlignment(Element.ALIGN_CENTER);
				table.addCell(cell);
				
				cell=new PdfPCell(new Phrase(data.getStatus(),font));
	            cell.setPadding(2.5f);
	            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell.setVerticalAlignment(Element.ALIGN_CENTER);
				table.addCell(cell);
				
				cell=new PdfPCell(new Phrase(data.getPbpDesc(),font));
	            cell.setPadding(2.5f);
	            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell.setVerticalAlignment(Element.ALIGN_CENTER);
				table.addCell(cell);
				
				cell=new PdfPCell(new Phrase(data.getAnomType(),font));
	            cell.setPadding(2.5f);
	            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell.setVerticalAlignment(Element.ALIGN_CENTER);
				table.addCell(cell);
				
				cell=new PdfPCell(new Phrase(data.getUserId(),font));
	            cell.setPadding(2.5f);
	            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell.setVerticalAlignment(Element.ALIGN_CENTER);
				table.addCell(cell);
				
				cell=new PdfPCell(new Phrase(data.getLastUpdate(),font));
	            cell.setPadding(2.5f);
	            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell.setVerticalAlignment(Element.ALIGN_CENTER);
				table.addCell(cell);
	             
	         }
	        
	         paragraph = new Paragraph("\n");
	         doc.add(paragraph);
	         doc.add(table);
	        anomalyDetails(mcaidAnomSummDetailDataVO, doc);
	        anomalyHistory(mcaidAnomSummDetailDataVO.getAnomSummHistLst(), doc);  
	            
	        doc.close();
	        logger.info(LoggerConstants.methodEndLevel());
	        return baosPDF;
		}
		
	private void anomalyDetails(McaidAnomSummDetailDataVO mcaidAnomSummDetailDataVO,Document doc) throws DocumentException {
		logger.info(LoggerConstants.methodStartLevel());
		Font bfBold12 = FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD, Color.BLACK);
		Font font = FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL, Color.BLACK); 
		
		Paragraph paragraph = new Paragraph("\n");
		paragraph = new Paragraph(new Chunk("Anomaly Details",bfBold12));
		doc.add(paragraph);
		paragraph = new Paragraph("\n");
			PdfPTable table1 = new PdfPTable(1);
			table1.setWidthPercentage(100f);
			table1.getDefaultCell().setUseAscender(true);
			table1.getDefaultCell().setUseDescender(true);
		   PdfPTable table = new PdfPTable(8);
	       table.setWidthPercentage(100f);
           table.getDefaultCell().setUseAscender(true);
	       table.getDefaultCell().setUseDescender(true);
	         
	        PdfPCell cell;
	         cell=new PdfPCell(new Phrase("Medicaid ID :",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase(mcaidAnomSummDetailDataVO.getMedicaidId(),font));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("Aspen/Case ID :",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase(mcaidAnomSummDetailDataVO.getRecentSuppId(),font));
	         cell.setPadding(2.5f);
	         cell.setColspan(5);
	         cell.setBorder(Rectangle.NO_BORDER);
	         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
	         
//	         cell=new PdfPCell(new Phrase());
//	         cell.setBorder(Rectangle.TOP);
//	         cell.setColspan(4);
//	         table.addCell(cell);
//	         table.addCell("");
//	         table.addCell("");
//	         table.addCell("");
//	         table.addCell("");
	         
	         cell=new PdfPCell(new Phrase("PBP ID :",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase(mcaidAnomSummDetailDataVO.getPbpDesc(),font));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("Payment Effective Date :",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase(McaidReconHelper.dateMonthByYearFormat(mcaidAnomSummDetailDataVO.getSuppIdEffDate()),font));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("First Name :",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase(mcaidAnomSummDetailDataVO.getFirstName(),font));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("Last Name :",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase(mcaidAnomSummDetailDataVO.getLastName(),font));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         /*--------------------------------*/
	         cell=new PdfPCell(new Phrase("Effective Date :",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase(McaidReconHelper.dateMonthByYearFormat(mcaidAnomSummDetailDataVO.getEffDate()),font));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("Apply Date :",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase(McaidReconHelper.dateMonthByYearFormat(mcaidAnomSummDetailDataVO.getApplyDate()),font));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("Create Date :",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase(mcaidAnomSummDetailDataVO.getCreateDate(),font));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("Last Update :",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase(mcaidAnomSummDetailDataVO.getLastUpdate(),font));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase());
	         cell.setBorder(Rectangle.NO_BORDER);
	         cell.setColspan(6);
	         table.addCell(cell);
//	         table.addCell("");
//	         table.addCell("");
//	         table.addCell("");
//	         table.addCell("");
//	         table.addCell("");
//	         table.addCell("");
	         
	         cell=new PdfPCell(new Phrase("User ID :",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase(mcaidAnomSummDetailDataVO.getUserId(),font));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("State Value :",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase(mcaidAnomSummDetailDataVO.getStateMedicaidId(),font));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	          
	         cell=new PdfPCell(new Phrase("Plan Value :",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase(mcaidAnomSummDetailDataVO.getPlan(),font));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         cell.setColspan(5);
	         table.addCell(cell);
	         
//	         cell=new PdfPCell(new Phrase());
//	         cell.setBorder(Rectangle.NO_BORDER);
//	         cell.setColspan(4);
//	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("Status :",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase(mcaidAnomSummDetailDataVO.getStatus(),font));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         cell.setColspan(3);
	         table.addCell(cell);
	         
//	         cell=new PdfPCell(new Phrase());
//	         cell.setBorder(Rectangle.NO_BORDER);
//	         cell.setColspan(2);
//	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("Change Status To :",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase(mcaidAnomSummDetailDataVO.getStatus(),font));
	         cell.setPadding(2.5f);
	         cell.setColspan(3);
	         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("Comment :",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase(mcaidAnomSummDetailDataVO.getComment(),font));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         cell.setColspan(3);
	         table.addCell(cell);
	         
//	         cell=new PdfPCell(new Phrase());
//	         cell.setBorder(Rectangle.NO_BORDER);
//	         cell.setColspan(2);
//	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("Comments :",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         cell.setBorder(Rectangle.NO_BORDER);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("",font));
	         cell.setPadding(2.5f);
	         cell.setColspan(3);
	         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
	         
	         table1.addCell(table);
	         doc.add(table1);
	         logger.info(LoggerConstants.methodEndLevel());
	         
	}
	private void anomalyHistory(List dataList, Document doc) throws DocumentException {
		logger.info(LoggerConstants.methodStartLevel());
		Font bfBold12 = FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD, Color.BLACK);
		Font font = FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL, Color.BLACK); 
		
		Paragraph paragraph = new Paragraph("\n");
		paragraph = new Paragraph(new Chunk("Anomaly History",bfBold12));
		doc.add(paragraph);
		Paragraph paragraph1 = new Paragraph("\n");
		doc.add(paragraph1);
			
			PdfPTable table = new PdfPTable(5);
	        table.setWidthPercentage(100f);
            table.getDefaultCell().setUseAscender(true);
	        table.getDefaultCell().setUseDescender(true);
	         
	        PdfPCell cell;
	         cell=new PdfPCell(new Phrase("Anomaly",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("Status",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
	         cell=new PdfPCell(new Phrase("Last Update",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("Comments",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
		
	         cell=new PdfPCell(new Phrase("User ID",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
	         if(dataList != null){
	         for (int index = 0; index < dataList.size(); index++) {
	             McaidAnomSummDetailVO data = (McaidAnomSummDetailVO) dataList.get(index);
	             
	             cell=new PdfPCell(new Phrase(data.getAnomaly(),font));
		         cell.setPadding(2.5f);
		         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		         table.addCell(cell);
		         
		         cell=new PdfPCell(new Phrase(data.getStatus(),font));
		         cell.setPadding(2.5f);
		         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		         table.addCell(cell);
		         
		         cell=new PdfPCell(new Phrase(data.getLastUpdate(),font));
		         cell.setPadding(2.5f);
		         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		         table.addCell(cell);
		         
		         cell=new PdfPCell(new Phrase(data.getComments(),font));
		         cell.setPadding(2.5f);
		         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		         table.addCell(cell);
		         
		         cell=new PdfPCell(new Phrase(data.getUserId(),font));
		         cell.setPadding(2.5f);
		         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		         table.addCell(cell);
	         }
	         }else{
	        	 cell=new PdfPCell(new Phrase("No Data",font));
		         cell.setPadding(2.5f);
		         cell.setColspan(5);
		         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		         table.addCell(cell); 
	         }
	         doc.add(table);
	         logger.info(LoggerConstants.methodEndLevel());
	}
	public ByteArrayOutputStream createAllAnomSummaryPDFReport( String string,
			List summAnomListLst) throws DocumentException {	
		logger.info(LoggerConstants.methodStartLevel());
		ByteArrayOutputStream baosPDF;
		Document doc = new Document(PageSize.A4,16,16,36,36);
	    baosPDF = new ByteArrayOutputStream();
	    int headingFontSize = 14;
		PdfWriter docWriter = PdfWriter.getInstance(doc, baosPDF);
		Font bfBold12 = FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD, Color.BLACK);
		Font font = FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL, Color.BLACK);
        doc.open();             
        Paragraph paragraph = new Paragraph("Anomaly Summary",FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD, Color.BLACK));
        paragraph.setAlignment(Paragraph.ALIGN_CENTER);
        doc.add(paragraph);
        paragraph = new Paragraph("\n \n");
        doc.add(paragraph);
        Paragraph paragraph1 = new Paragraph("Anomaly Details",bfBold12);
        paragraph1.setAlignment(Paragraph.ALIGN_LEFT);
        doc.add(paragraph1);
        Paragraph paragraph12 = new Paragraph("\n \n");
        doc.add(paragraph12);	        
        Paragraph paragraph2 = new Paragraph(string,bfBold12);
        paragraph2.setAlignment(Paragraph.ALIGN_LEFT);
        doc.add(paragraph2);
        paragraph = new Paragraph("\n");
        paragraph = new Paragraph(new Chunk("Anomaly List",bfBold12));
        doc.add(paragraph);
        paragraph = new Paragraph("\n");
        
        PdfPTable table = new PdfPTable(8);
        table.setWidthPercentage(100f);
        table.getDefaultCell().setUseAscender(true);
        table.getDefaultCell().setUseDescender(true);
         
        PdfPCell cell;
         // write table header
         cell=new PdfPCell(new Phrase("Medicaid ID",bfBold12));
         cell.setPadding(2.5f);
         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
         table.addCell(cell);
        
         cell=new PdfPCell(new Phrase("Anomaly",bfBold12));
         cell.setPadding(2.5f);
         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
         table.addCell(cell);

         cell=new PdfPCell(new Phrase("Eff Date",bfBold12));
         cell.setPadding(2.5f);
         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
         table.addCell(cell);

         cell=new PdfPCell(new Phrase("Status",bfBold12));
         cell.setPadding(2.5f);
         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
         table.addCell(cell);
         
         cell=new PdfPCell(new Phrase("PBP",bfBold12));
         cell.setPadding(2.5f);
         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
         table.addCell(cell);
        
         cell=new PdfPCell(new Phrase("Anomaly Type",bfBold12));
         cell.setPadding(2.5f);
         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
         table.addCell(cell);

         cell=new PdfPCell(new Phrase("User ID",bfBold12));
         cell.setPadding(2.5f);
         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
         table.addCell(cell);

         cell=new PdfPCell(new Phrase("Last Update",bfBold12));
         cell.setPadding(2.5f);
         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
         table.addCell(cell);
        
         int pbpIndex=0;
         for (int index = 0; index < summAnomListLst.size(); index++) {
//             row = sheet.createRow(index + 1);            
             McaidAnomSummDetailVO data = (McaidAnomSummDetailVO) summAnomListLst.get(index);
             pbpIndex++;
             
            cell=new PdfPCell(new Phrase(data.getMedicaidId(),font));
            cell.setPadding(2.5f);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);
			
			cell=new PdfPCell(new Phrase(data.getAnomaly(),font));
            cell.setPadding(2.5f);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);
			
			cell=new PdfPCell(new Phrase(McaidReconHelper.dateMonthByYearFormat(data.getEffDate()),font));
            cell.setPadding(2.5f);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);
			
			cell=new PdfPCell(new Phrase(data.getStatus(),font));
            cell.setPadding(2.5f);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);
			
			cell=new PdfPCell(new Phrase(data.getPbpDesc(),font));
            cell.setPadding(2.5f);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);
			
			cell=new PdfPCell(new Phrase(data.getAnomType(),font));
            cell.setPadding(2.5f);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);
			
			cell=new PdfPCell(new Phrase(data.getUserId(),font));
            cell.setPadding(2.5f);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);
			
			cell=new PdfPCell(new Phrase(data.getLastUpdate(),font));
            cell.setPadding(2.5f);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);
             
         }
        
         paragraph = new Paragraph("\n");
         doc.add(paragraph);
         doc.add(table);
         doc.close();
         logger.info(LoggerConstants.methodEndLevel());
         return baosPDF;
	}
		
	
	
	private String getMonthName(int monVal){
		logger.info(LoggerConstants.methodStartLevel());
	 	String[] months = new DateFormatSymbols().getMonths();
	 	logger.info(LoggerConstants.methodEndLevel());
		return months[monVal-1];	 			 	
 	}


	
}//class
