package com.ps.mss.businesslogic;


import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.List;

import org.slf4j.Logger;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.model.McaidPaymentDashBoardVO;
import com.ps.mss.model.McaidReconPaymentVO;
import com.ps.util.StringUtil;

/**
 *
 * @author bsanthos
 */
public class CreatePaymentPdfService {
/**
 * 
 * @param dataList
 * @return
 * @throws Exception
 */
	private static Logger logger=LoggerFactory.getLogger(CreatePaymentPdfService.class);

	public ByteArrayOutputStream createDashboardPDFReport(List dataList) throws Exception{
		logger.info(LoggerConstants.methodStartLevel());
	     
	    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
	    java.util.Date date = new java.util.Date();
	    Document document = new Document();
	    
	    PdfContentByte contentByte;
	    ByteArrayOutputStream baosPDF;
	   
	    try {
	        //connection=DbLocator.getInstance().getConnection("APPLDS");         
	         
	         
	        /*
	         * PDF generation using iText library
	         */
	        Document doc = new Document(PageSize.A4,16,16,36,36);
	        baosPDF = new ByteArrayOutputStream();
	        Font bfBold12 = FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD, Color.BLACK); 
	        Font font = FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL, Color.BLACK);
	        try {
	        	
        	  PdfWriter docWriter = PdfWriter.getInstance(doc, baosPDF);              
	             doc.open();             
	             Paragraph paragraph = new Paragraph("Payment Dashboard",bfBold12);
	             paragraph.setAlignment(Paragraph.ALIGN_CENTER);
	             doc.add(paragraph);
	             paragraph = new Paragraph("\n");
	             doc.add(paragraph);
	           /*  PdfPTable table1 = new PdfPTable(1); 
	             
	             table1.setWidthPercentage(100f);
	             */
	             
	        	// define font for table header row 
	             float[] columnWidths = new float[] {35f,22f,22f,21f};
	            PdfPTable table = new PdfPTable(columnWidths);
	            table.setWidthPercentage(100f);
	            table.getDefaultCell().setUseAscender(true);
	            table.getDefaultCell().setUseDescender(true);
	            // define table header cell
	            PdfPCell cell;
	            // write table header
	            cell=new PdfPCell(new Phrase("PBP/Period",bfBold12));
	            cell.setPadding(2.5f);
	            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            
	            table.addCell(cell);
	             
//	            cell.setPhrase("State Paid", bfBold12);
	            cell=new PdfPCell(new Phrase("State Paid",bfBold12));
	            cell.setPadding(2.5f);
	            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            table.addCell(cell);
	     
//	            cell.setPhrase(new Phrase("Plan Expected", bfBold12));
	            cell=new PdfPCell(new Phrase("Plan Expected",bfBold12));
	            cell.setPadding(2.5f);
	            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            table.addCell(cell);
	             
//	            cell.setPhrase(new Phrase("Difference", bfBold12));
	            cell=new PdfPCell(new Phrase("Difference",bfBold12));
	            cell.setPadding(2.5f);
	            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            table.addCell(cell);

	            for (int pbpIndex = 0; pbpIndex < dataList.size(); pbpIndex++) {
					McaidPaymentDashBoardVO pbpData = (McaidPaymentDashBoardVO) dataList.get(pbpIndex);
					
					cell=new PdfPCell(new Phrase(pbpData.getPbpDesc(),font));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		            cell.setVerticalAlignment(Element.ALIGN_LEFT);
					table.addCell(cell);
					
//					table.addCell(pbpData.getCmsPaid());
					cell=new PdfPCell(new Phrase(pbpData.getCmsPaid(),font));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
					table.addCell(cell);
					
//					table.addCell(new Phrase(new Chunk(pbpData.getPlanExpected())));
					cell=new PdfPCell(new Phrase(pbpData.getPlanExpected(),font));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
					table.addCell(cell);

					cell=new PdfPCell(new Phrase(pbpData.getDiffrence(),fontColorpicker(pbpData.getDiffrence())));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
					table.addCell(cell);

					List yearDataList = pbpData.getPbpYrOrQtrOrMonLst();
					if (yearDataList != null) {// yearIf
						for (int yearIndex = 0; yearIndex < yearDataList.size(); yearIndex++) {
							McaidPaymentDashBoardVO yearData = (McaidPaymentDashBoardVO) yearDataList.get(yearIndex);
							
							cell=new PdfPCell(new Phrase(yearData.getYear(),font));
//							cell.setBorder(Rectangle.LEFT);
							cell.setPadding(2.5f);
				            cell.setPaddingLeft(16f);
				            
							table.addCell(cell);
//							table.addCell(pbpData.getCmsPaid());
							cell=new PdfPCell(new Phrase(yearData.getCmsPaid(),font));
				            cell.setPadding(2.5f);
				            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
				            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
//							cell.setBorder(Rectangle.NO_BORDER);
							
				            table.addCell(cell);
//							table.addCell(new Phrase(new Chunk(pbpData.getPlanExpected())));
							cell=new PdfPCell(new Phrase(yearData.getPlanExpected(),font));
				            cell.setPadding(2.5f);
				            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
				            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
//				        	cell.setBorder(Rectangle.NO_BORDER);
							
				            table.addCell(cell);
//							table.addCell(yearData.getDiffrence());
							cell=new PdfPCell(new Phrase(yearData.getDiffrence(),fontColorpicker(yearData.getDiffrence())));
				            cell.setPadding(2.5f);
				            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
				            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
//				        	cell.setBorder(Rectangle.RIGHT);
				          
				        	/*if(yearIndex==(yearDataList.size()-1))
							{
								cell.setBorder(Rectangle.BOTTOM);	
								
							}*/
				        	table.addCell(cell);
							List qtrDataList = yearData.getPbpYrOrQtrOrMonLst();
							if (qtrDataList != null) {// qtrIf
								for (int qtrIndex = 0; qtrIndex < qtrDataList.size(); qtrIndex++) {
									McaidPaymentDashBoardVO qtrData = (McaidPaymentDashBoardVO) qtrDataList.get(qtrIndex);
									
									
									cell=new PdfPCell(new Phrase(qtrData.getQuarter(),font));
//									cell.setBorder(Rectangle.LEFT);
									cell.setPadding(2.5f);
						            cell.setPaddingLeft(25f);
									table.addCell(cell);
									
									cell=new PdfPCell(new Phrase(qtrData.getCmsPaid(),font));
						            cell.setPadding(2.5f);
//						        	cell.setBorder(Rectangle.NO_BORDER);
						            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
						            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
									table.addCell(cell);
									
									cell=new PdfPCell(new Phrase(qtrData.getPlanExpected(),font));
						            cell.setPadding(2.5f);
//						        	cell.setBorder(Rectangle.NO_BORDER);
						            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
						            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
									table.addCell(cell);
									
//									table.addCell(pbpData.getDiffrence());
									cell=new PdfPCell(new Phrase(qtrData.getDiffrence(),fontColorpicker(qtrData.getDiffrence())));
						            cell.setPadding(2.5f);
						            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
						            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
//						        	cell.setBorder(Rectangle.RIGHT);
						    		/*if(qtrIndex==qtrDataList.size()-1)
									{
										cell.setBorder(Rectangle.BOTTOM);
									}
						    		 */
									 table.addCell(cell);
									
									List monthDataList = qtrData.getPbpYrOrQtrOrMonLst();
									if (monthDataList != null) {// monthIf
										for (int monthIndex = 0; monthIndex < monthDataList.size(); monthIndex++) {
											McaidPaymentDashBoardVO monthData = (McaidPaymentDashBoardVO) monthDataList.get(monthIndex);
											
											String revicedMonth = getMonthName(Integer.parseInt(monthData.getMonth()));
											cell=new PdfPCell(new Phrase(revicedMonth,font));
//											cell.setBorder(Rectangle.LEFT);
											cell.setPadding(2.5f);
								            cell.setPaddingLeft(35f);
								            /*if((monthIndex==monthDataList.size()-1))
											{
												cell.setBorder(Rectangle.BOTTOM);
											    cell.setBorder(Rectangle.RIGHT);
											}*/
								            table.addCell(cell);
//										
								            //table.addCell(pbpData.getCmsPaid());
											cell=new PdfPCell(new Phrase(monthData.getCmsPaid(),font));
								            cell.setPadding(2.5f);
								            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
//								        	cell.setBorder(Rectangle.NO_BORDER);
											cell.setVerticalAlignment(Element.ALIGN_RIGHT);
											/*
								            if((monthIndex==monthDataList.size()-1))
											{
												cell.setBorder(Rectangle.BOTTOM);
											    cell.setBorder(Rectangle.RIGHT);
											}*/
								      		table.addCell(cell);
											
//											table.addCell(new Phrase(new Chunk(pbpData.getPlanExpected())));
											cell=new PdfPCell(new Phrase(monthData.getPlanExpected(),font));
								            cell.setPadding(2.5f);
								            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
								            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
//								            cell.setBorder(Rectangle.NO_BORDER);
								            
								            /*if((monthIndex==monthDataList.size()-1))
											{
												cell.setBorder(Rectangle.BOTTOM);
											    cell.setBorder(Rectangle.RIGHT);
											}*/
								      		table.addCell(cell);
											
//											table.addCell(pbpData.getDiffrence());
											
											cell=new PdfPCell(new Phrase(monthData.getDiffrence(),fontColorpicker(monthData.getDiffrence())));
								            cell.setPadding(2.5f);
								            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
								            cell.setVerticalAlignment(Element.ALIGN_RIGHT);
//								            cell.setBorder(Rectangle.RIGHT);
								           
								            /*if((monthIndex==monthDataList.size()-1))
											{
												cell.setBorder(Rectangle.BOTTOM);
											    cell.setBorder(Rectangle.RIGHT);
											}*/
								      
								            
								          
								            table.addCell(cell);
											
										}// month for
									}// monthIf
								}// qtr for loop
							}// qtr if
						}// Year for loop
					}// yearIf End
				}// Base for loop
	           
	          doc.add(table);
	        }
	        catch(Exception e){
	        	logger.error(LoggerConstants.exceptionMessage(e.toString()));
	            logger.debug("Error-->generatePDFReport"+e);
	            throw new Exception(e);
	        }
	        doc.close();
	         
	         
	    }
	    catch (Exception e){
	    	logger.error(LoggerConstants.exceptionMessage(e.toString()));
	        logger.debug("Error-->generatePDFReport"+e);
	        throw new Exception(e);
	    }
	    finally{
	        //DbLocator.closeConnection(connection);
	    }
	    logger.info(LoggerConstants.methodEndLevel());      
	    return baosPDF;
	}

	public ByteArrayOutputStream createSummaryCurrentPDFReport(Document doc,McaidReconPaymentVO data, List dataList, List dataList1) throws DocumentException {
		logger.info(LoggerConstants.methodStartLevel());
		ByteArrayOutputStream baosPDF;
		baosPDF = new ByteArrayOutputStream();
		
		Font bfBold12 = FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD, Color.BLACK);
//		Paragraph para = new Paragraph(new Phrase());
//        para.setAlignment(Paragraph.ALIGN_LEFT);
        doc.add(new Chunk(data.getSummPageLabel1(),bfBold12));
        Paragraph para = new Paragraph("\n \n");
        doc.add(para);
        
//        Paragraph paragrph = new Paragraph(new Phrase(new Chunk("Total Payment",bfBold12)));
//        paragrph.setAlignment(Paragraph.ALIGN_LEFT);
        doc.add(new Chunk("Total Payment",bfBold12));
        Paragraph paragrph = new Paragraph("\n");
        doc.add(paragrph);
		
        PdfPTable table = new PdfPTable(6);
        table.setWidthPercentage(100f);

        table.getDefaultCell().setUseAscender(true);
        table.getDefaultCell().setUseDescender(true);

        // define table header cell
        PdfPCell cell;
        
        cell=new PdfPCell(new Phrase("State Paid : ",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM|Rectangle.LEFT);
        table.addCell(cell);
        
        cell=new PdfPCell(new Phrase(data.getSummDataCmsPaid(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_LEFT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM);
        table.addCell(cell);
        
        cell=new PdfPCell(new Phrase("Plan Expected : ",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM);
        table.addCell(cell);
        
        cell=new PdfPCell(new Phrase(data.getSummDataPlanExpected(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_LEFT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM);
        table.addCell(cell);
        
        cell=new PdfPCell(new Phrase("Difference : ",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM);
        table.addCell(cell);
        
        cell=new PdfPCell(new Phrase(data.getSummDataDiffrence(), fontColorpicker(data.getSummDataDiffrence())));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_LEFT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM|Rectangle.RIGHT);
        table.addCell(cell);
        
        doc.add(table);
        
        paragrph = new Paragraph("\n");
        doc.add(paragrph);
        
        PdfPTable table1 = new PdfPTable(4);
        table1.setWidthPercentage(100f);
        cell=new PdfPCell(new Phrase("PBP",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table1.addCell(cell);
        
        cell=new PdfPCell(new Phrase("State Paid",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table1.addCell(cell);
        
        cell=new PdfPCell(new Phrase("Plan Expected",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table1.addCell(cell);
        
        cell=new PdfPCell(new Phrase("Difference",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table1.addCell(cell);
        
//        McaidPaymentDashBoardVO datatemp = (McaidPaymentDashBoardVO) dataList;
        int index = 0;       
        for (int pbpIndex = 0; pbpIndex < dataList.size(); pbpIndex++) {
            McaidPaymentDashBoardVO datatemp = (McaidPaymentDashBoardVO) dataList.get(pbpIndex);
            index++;
        cell=new PdfPCell(new Phrase(datatemp.getPbpDesc(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table1.addCell(cell);
        
        cell=new PdfPCell(new Phrase(datatemp.getCmsPaid(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        table1.addCell(cell);
        
        cell=new PdfPCell(new Phrase(datatemp.getPlanExpected(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        table1.addCell(cell);
        
        cell=new PdfPCell(new Phrase(datatemp.getDiffrence(),fontColorpicker(datatemp.getDiffrence())));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        table1.addCell(cell);
        
        }
        doc.add(table1);
        
        
//        Chunk  chunk = new  Chunk("Payment Details",bfBold12);
    //    //        paragrph1.setAlignment(Paragraph.ALIGN_LEFT);
        doc.add( new  Chunk("Payment Details",bfBold12));
        Paragraph   paragrph1 = new Paragraph("\n");
        doc.add(paragrph1);
		
        PdfPTable table3 = new PdfPTable(6);
        table3.setWidthPercentage(100f);

        table3.getDefaultCell().setUseAscender(true);
        table3.getDefaultCell().setUseDescender(true);

        // define table header cell
//        PdfPCell cell;
        
        cell=new PdfPCell(new Phrase("State Paid : ",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM|Rectangle.LEFT);
        table3.addCell(cell);
        
        cell=new PdfPCell(new Phrase(data.getSummDetailCmsPaid(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_LEFT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM);
        table3.addCell(cell);
        
        
        cell=new PdfPCell(new Phrase("Plan Expected : ",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM);
        table3.addCell(cell);
        
        cell=new PdfPCell(new Phrase(data.getSummDetailPlanExpected(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_LEFT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM);
        table3.addCell(cell);
        
        cell=new PdfPCell(new Phrase("Difference : ",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM);
        table3.addCell(cell);
        
        cell=new PdfPCell(new Phrase(data.getSummDetailDiffrence(), fontColorpicker(data.getSummDetailDiffrence())));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_LEFT);
        cell.setBorder(Rectangle.TOP|Rectangle.BOTTOM|Rectangle.RIGHT);
        table3.addCell(cell);
        
        doc.add(table3);
        
        paragrph = new Paragraph("\n");
        doc.add(paragrph);
        
        PdfPTable table4 = new PdfPTable(5);
        table4.setWidthPercentage(100f);
        cell=new PdfPCell(new Phrase("Payment Type",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table4.addCell(cell);
        
        cell=new PdfPCell(new Phrase("Description",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table4.addCell(cell);
        
        cell=new PdfPCell(new Phrase("State Paid",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table4.addCell(cell);
        
        cell=new PdfPCell(new Phrase("Plan Expected",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table4.addCell(cell);
        
        cell=new PdfPCell(new Phrase("Difference",FontFactory.getFont(FontFactory.HELVETICA, 7, Font.BOLD)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table4.addCell(cell);
        
//        McaidPaymentDashBoardVO datatemp = (McaidPaymentDashBoardVO) dataList;
        for (int paymentIndex = 0; paymentIndex < dataList1.size(); paymentIndex++) {
            McaidPaymentDashBoardVO datatemp1 = (McaidPaymentDashBoardVO) dataList1.get(paymentIndex);
            index++;
        cell=new PdfPCell(new Phrase(datatemp1.getPbpId(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table4.addCell(cell);
        
        cell=new PdfPCell(new Phrase(datatemp1.getPbpDesc(),FontFactory.getFont(FontFactory.HELVETICA, 7)));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table4.addCell(cell);
        
        cell=new PdfPCell(new Phrase(datatemp1.getCmsPaid(),fontColorpicker(datatemp1.getCmsPaid())));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        table4.addCell(cell);
        
        cell=new PdfPCell(new Phrase(datatemp1.getPlanExpected(),fontColorpicker(datatemp1.getPlanExpected())));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        table4.addCell(cell);
        
       
        cell=new PdfPCell(new Phrase(datatemp1.getDiffrence(), fontColorpicker(datatemp1.getDiffrence())));
        cell.setPadding(2.5f);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_RIGHT);
        table4.addCell(cell);
        
       
        }
        doc.add(table4);
        logger.info(LoggerConstants.methodEndLevel());
		return baosPDF;
	}
	/**
	 * 
	 * @param mcaidPymntSummLst
	 * @param mcaidPymntSummDetailLst
	 * @return
	 * @throws DocumentException 
	 */
		@SuppressWarnings("null")
		public ByteArrayOutputStream createSummaryPDFReport(McaidReconPaymentVO data, List dataList, List dataList1,List dataList3) throws DocumentException {
			logger.info(LoggerConstants.methodStartLevel());
			ByteArrayOutputStream baosPDF;
			Document doc = new Document(PageSize.A4,16,16,36,36);
		    baosPDF = new ByteArrayOutputStream();
		    int headingFontSize = 14;
			PdfWriter docWriter = PdfWriter.getInstance(doc, baosPDF);
			Font bfBold12 = FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD, Color.BLACK);
	        doc.open();             
	        Paragraph paragraph = new Paragraph("Payment Summary",FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD, Color.BLACK));
	        paragraph.setAlignment(Paragraph.ALIGN_CENTER);
	        doc.add(paragraph);
	        paragraph = new Paragraph("\n \n");
	        doc.add(paragraph);
	        /* For Total Payment and Total Payment - START */
	        createSummaryCurrentPDFReport(doc,data,dataList,dataList1);
	        /* For Total Payment and Total Payment - END */
	        
	        /* For Medicaid Payment Details - CAP in Current Page*/
	        if (dataList3 != null ){
	         paragraph = new Paragraph(new Chunk("Medicaid Payment Details - "+data.getSummSrchPaymentType(),bfBold12));
	         paragraph.setIndentationLeft(0);
	         doc.add(paragraph);
	         
	         paragraph = new Paragraph("\n");
	         doc.add(paragraph);
	         
	         PdfPTable table = new PdfPTable(6);
	         table.setWidthPercentage(100f);
	         table.getDefaultCell().setUseAscender(true);
	         table.getDefaultCell().setUseDescender(true);
	         
	         PdfPCell cell;
	         // write table header
	         cell=new PdfPCell(new Phrase("Medicaid",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         
	         table.addCell(cell);
	          
//	         cell.setPhrase("State Paid", bfBold12);
	         cell=new PdfPCell(new Phrase("Effective Date",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
	  
//	         cell.setPhrase(new Phrase("Plan Expected", bfBold12));
	         cell=new PdfPCell(new Phrase("Apply Date",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
	          
//	         cell.setPhrase(new Phrase("Difference", bfBold12));
	         cell=new PdfPCell(new Phrase("State Paid",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("Plan Expected",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("Difference",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
	         int index = 0;
	         Font font = FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL, Color.BLACK);
	         for (int pbpIndex = 0; pbpIndex < dataList3.size(); pbpIndex++) {
	         	
	         	McaidPaymentDashBoardVO data1 = (McaidPaymentDashBoardVO) dataList3.get(pbpIndex);
	             index++;
					cell=new PdfPCell(new Phrase(data1.getPbpId(),font));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		            cell.setVerticalAlignment(Element.ALIGN_CENTER);
					table.addCell(cell);
	         
					cell=new PdfPCell(new Phrase(dateConvertion(data1.getEffDate()),font));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		            cell.setVerticalAlignment(Element.ALIGN_CENTER);
					table.addCell(cell);
					
					cell=new PdfPCell(new Phrase(dateConvertion(data1.getApplyDate()),font));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		            cell.setVerticalAlignment(Element.ALIGN_CENTER);
					table.addCell(cell);
					
					cell=new PdfPCell(new Phrase(data1.getCmsPaid(),fontColorpicker(data1.getCmsPaid())));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            cell.setVerticalAlignment(Element.ALIGN_CENTER);
					table.addCell(cell);
					
					cell=new PdfPCell(new Phrase(data1.getPlanExpected(),fontColorpicker(data1.getPlanExpected())));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            cell.setVerticalAlignment(Element.ALIGN_CENTER);
					table.addCell(cell);
					
					cell=new PdfPCell(new Phrase(""));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            cell.setVerticalAlignment(Element.ALIGN_CENTER);
					table.addCell(cell);
	         }
	         doc.add(table);
	        }
	        doc.close();
	        logger.info(LoggerConstants.methodEndLevel());
	        return baosPDF;
		}
	public ByteArrayOutputStream createAllPymtSummaryPDFReport(McaidReconPaymentVO data, List dataList,List mcaidPymntSummDetailLst, List listData) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		ByteArrayOutputStream baosPDF;
		Document doc = new Document(PageSize.A4,16,16,36,36);
	    baosPDF = new ByteArrayOutputStream();
	    PdfWriter docWriter = PdfWriter.getInstance(doc, baosPDF);
	    Font bfBold12 = FontFactory.getFont(FontFactory.HELVETICA, 9, Font.BOLD, Color.BLACK);
	    Font font = FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL, Color.BLACK);
	    try {
	    	
	         doc.open();
	         Paragraph paragraph = new Paragraph("Payment Summary",FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD, Color.BLACK));
	         paragraph.setAlignment(Paragraph.ALIGN_CENTER);
	         doc.add(paragraph);
	         paragraph = new Paragraph("\n \n");
	         doc.add(paragraph);
	         
	         createSummaryCurrentPDFReport(doc,data,dataList,mcaidPymntSummDetailLst);
	         paragraph = new Paragraph("\n");
	         doc.add(paragraph);
	         
	         
	         paragraph = new Paragraph(new Chunk("Medicaid Payment Details - "+StringUtil.nonNullTrim(data.getSummSrchPaymentType()),bfBold12));
	         paragraph.setIndentationLeft(0);
 	         doc.add(paragraph);
	         
	         paragraph = new Paragraph("\n");
	         doc.add(paragraph);
	         
	         PdfPTable table = new PdfPTable(6);
	         table.setWidthPercentage(100f);
	         logger.debug("CreatePaymentPdfService.createDashboardPDFReport()::::"+table.getWidthPercentage());
	         table.getDefaultCell().setUseAscender(true);
	         table.getDefaultCell().setUseDescender(true);
	         
	         PdfPCell cell;
	         // write table header
	         cell=new PdfPCell(new Phrase("Medicaid",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         
	         table.addCell(cell);
	          
//	         cell.setPhrase("State Paid", bfBold12);
	         cell=new PdfPCell(new Phrase("Effective Date",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
	  
//	         cell.setPhrase(new Phrase("Plan Expected", bfBold12));
	         cell=new PdfPCell(new Phrase("Apply Date",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
	          
//	         cell.setPhrase(new Phrase("Difference", bfBold12));
	         cell=new PdfPCell(new Phrase("State Paid",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("Plan Expected",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
	         
	         cell=new PdfPCell(new Phrase("Difference",bfBold12));
	         cell.setPadding(2.5f);
	         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	         cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
	         table.addCell(cell);
	         int index = 0;
	         for (int pbpIndex = 0; pbpIndex < listData.size(); pbpIndex++) {
	         	
	         	McaidPaymentDashBoardVO data1 = (McaidPaymentDashBoardVO) listData.get(pbpIndex);
	             index++;
					cell=new PdfPCell(new Phrase(data1.getPbpId(),font));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		            cell.setVerticalAlignment(Element.ALIGN_CENTER);
					table.addCell(cell);
	         
//					String tempEffDate = data1.getEffDate();
//					String tempEffDate1 = tempEffDate.substring(0, 4);
//					String tempEffDate2 = tempEffDate.substring(4, 6);
//					String effdate = tempEffDate2+"/"+tempEffDate1;
					cell=new PdfPCell(new Phrase(dateConvertion(data1.getEffDate()),font));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		            cell.setVerticalAlignment(Element.ALIGN_CENTER);
					table.addCell(cell);
					
					cell=new PdfPCell(new Phrase(dateConvertion(data1.getApplyDate()),font));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		            cell.setVerticalAlignment(Element.ALIGN_CENTER);
					table.addCell(cell);
					
					cell=new PdfPCell(new Phrase(data1.getCmsPaid(),fontColorpicker(data1.getCmsPaid())));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            cell.setVerticalAlignment(Element.ALIGN_CENTER);
					table.addCell(cell);
					
					cell=new PdfPCell(new Phrase(data1.getPlanExpected(),fontColorpicker(data1.getPlanExpected())));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            cell.setVerticalAlignment(Element.ALIGN_CENTER);
					table.addCell(cell);
					
					cell=new PdfPCell(new Phrase(""));
		            cell.setPadding(2.5f);
		            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		            cell.setVerticalAlignment(Element.ALIGN_CENTER);
					table.addCell(cell);
	         }
	         doc.add(table);
	         doc.close();
	    } catch(Exception e){
	    	logger.error(LoggerConstants.exceptionMessage(e.toString()));
	        logger.debug("Error-->generatePDFReport"+e);
	        throw new Exception(e);
	    }
	    logger.info(LoggerConstants.methodEndLevel());
		return baosPDF;
	}
	private String getMonthName(int monVal){
		logger.info(LoggerConstants.methodStartLevel());
	 	String[] months = new DateFormatSymbols().getMonths();
	 	logger.info(LoggerConstants.methodEndLevel());
		return months[monVal-1];	 			 	
 	}
	
	private String dateConvertion(String dateValue){
		logger.info(LoggerConstants.methodStartLevel());
		String tempEffDate1 = dateValue.substring(0, 4);
		String tempEffDate2 = dateValue.substring(4, 6);
		String date = tempEffDate2+"/"+tempEffDate1;
		logger.info(LoggerConstants.methodEndLevel());
		return date;
	}
	private Font fontColorpicker(String fontName){
		logger.info(LoggerConstants.methodStartLevel());
		Font font;
		if(fontName.startsWith("(")){
			font = FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL, Color.RED);
		}else{
			font = FontFactory.getFont(FontFactory.HELVETICA, 7, Font.NORMAL, Color.BLACK);
		}
		logger.info(LoggerConstants.methodEndLevel());
		return font;
	}
	
}//class
