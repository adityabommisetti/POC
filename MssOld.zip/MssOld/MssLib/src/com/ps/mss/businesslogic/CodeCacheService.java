/*
 * $Id: CodeCacheService.java,v 1.1 2014/06/26 07:44:07 praveen Exp $
 */
package com.ps.mss.businesslogic;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.CodeCacheDao;
import com.ps.mss.dao.DaoFactory;
import com.ps.mss.exception.ApplicationException;
import com.ps.util.NameValuePair;

/**
 * @author Deepak
 *
 */
public class CodeCacheService {
	
	private static Logger logger=(Logger) LoggerFactory.getLogger(CodeCacheService.class);
	
	public Map getPlanList(String custNbr) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		DaoFactory factory = DaoFactory.getInstance();
		CodeCacheDao codeCache=factory.getCodeCacheMaster();
		logger.info(LoggerConstants.methodEndLevel());
		return 	codeCache.getPlanList(custNbr);
	}
	
	/**
	 * Function <code>resetCache</code> will reset all CACHE OBJECT.
	 */
	public static void resetCache(){
		CodeCacheDao.resetCache();
	}
	
	/**
	 * this method returns maximum no of records to show for 'ALL' option in Discrepancy Detail PDF and Print 
	 * @author Hemant
	 * @return
	 * @throws ApplicationException
	 */
	public  Integer getMaxRecordCount() {
		logger.info(LoggerConstants.methodStartLevel());
		logger.info(LoggerConstants.methodEndLevel());
		return 	CodeCacheDao.getMaxRecordCount();
	}
	/**
	 * this method returns maximum no of records to show for 'ALL' option in Discrepancy Detail PDF and Print 
	 * @author Hemant
	 * @return
	 * @throws ApplicationException
	 */
	public  Integer getDiscMaxRecordCount() {
		logger.info(LoggerConstants.methodStartLevel());
		logger.info(LoggerConstants.methodEndLevel());
		return 	CodeCacheDao.getDiscMaxRecordCount();
	}
	public  Map getDiscrpArr() throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		DaoFactory factory = DaoFactory.getInstance();
		CodeCacheDao codeCache = factory.getCodeCacheMaster();
		logger.info(LoggerConstants.methodEndLevel());
		return 	codeCache.getDiscrpMap(null);
	}
	
	public  Map getDiscrpArrMap() throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		DaoFactory factory = DaoFactory.getInstance();
		CodeCacheDao codeCache = factory.getCodeCacheMaster();
		logger.info(LoggerConstants.methodEndLevel());
		return 	codeCache.getDiscrpArrMap(null);
	}
	
	public  NameValuePair [] getDiscrpStatusArr() throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		DaoFactory factory = DaoFactory.getInstance();
		CodeCacheDao codeCache=factory.getCodeCacheMaster();
		logger.info(LoggerConstants.methodEndLevel());
		return 	codeCache.getDiscrpStatusArr();
	}
	
	public  Map getAdjReasonMap() throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		DaoFactory factory = DaoFactory.getInstance();
		CodeCacheDao codeCache = factory.getCodeCacheMaster();
		logger.info(LoggerConstants.methodEndLevel());
		return 	codeCache.getAdjReasonMap();
	}
	
	public Map getProfileParmsMap() throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		DaoFactory factory = DaoFactory.getInstance();
		CodeCacheDao codeCache = factory.getCodeCacheMaster();
		logger.info(LoggerConstants.methodEndLevel());
		return codeCache.getProfileParmsMap();		
	}	
}
