package com.ps.mss.businesslogic;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;

import org.codehaus.jackson.map.ObjectMapper;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.io.ModuleLog;
import com.ps.logger.LoggerConstants;
import com.ps.mss.vo.AdminProdVO;
import com.ps.mss.vo.AdminServiceAreaVO;
import com.ps.mss.vo.EEMBBBSubProductVO;
import com.ps.mss.vo.EmGrpProductVO;
import com.ps.mss.vo.EmLisSubsidyVO;
import com.ps.util.DateUtil;

public class EEMAdminService {

	ModuleLog log = new ModuleLog("EEMApplService");
	private final static Logger logger = LoggerFactory.getLogger(EEMAdminService.class);

	public boolean editProdData(HttpServletRequest request, Connection conn, String userId, String customerId) {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("Inside editProdData.");
		try {
			AdminProdVO prodVO = new AdminProdVO();
			prodVO.setProdId((String) request.getParameter("prodId"));
			prodVO.setProdName((String) request.getParameter("prodName"));
			prodVO.setSd((String) request.getParameter("sd"));
			prodVO.setEd((String) request.getParameter("ed"));
			prodVO.setLastUpdTime((String) request.getParameter("lastUpdTime"));
			prodVO.setUserId(userId);

			String sql = "update em_product_name set PRODUCT_NAME=?, PRODNAME_START_DATE=?, PRODNAME_END_DATE=?, LAST_UPDT_TIME=?, LAST_UPDT_USERID=? where CUSTOMER_ID=? AND PRODUCT_ID=? AND LAST_UPDT_TIME=?";
			PreparedStatement ps1 = conn.prepareStatement(sql);
			ps1.setString(1, prodVO.getProdName());
			ps1.setString(2, DateUtil.changedDateFormatForMonth(prodVO.getSd()));
			ps1.setString(3, DateUtil.changedDateFormatForMonth(prodVO.getEd()));
			ps1.setString(4, new DateUtil().getDB2DTS());
			ps1.setString(5, prodVO.getUserId());
			ps1.setString(6, "HCFLCS4");
			ps1.setString(7, prodVO.getProdId());
			ps1.setString(8, prodVO.getLastUpdTime());
			int upd = ps1.executeUpdate();
			if (upd == 0) {
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			} else {
				logger.info(LoggerConstants.methodEndLevel());
				return true;
			}
		} catch (Exception ex) {
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			logger.debug("Exception in editProdData: " + ex.getMessage());
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
	}

	public boolean editServiceAreaData(HttpServletRequest request, Connection conn, String userId, String customerId) {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("Inside editServiceAreaData.");
		try {
			AdminServiceAreaVO srvcAreaVO = new AdminServiceAreaVO();
			srvcAreaVO.setSrvcAreaId((String) request.getParameter("srvcId"));
			srvcAreaVO.setSrvcName((String) request.getParameter("srvcName"));
			srvcAreaVO.setSrvcSd((String) request.getParameter("sd"));
			srvcAreaVO.setSrvcEd((String) request.getParameter("ed"));
			srvcAreaVO.setLstUpdTime((String) request.getParameter("lastUpdTime"));
			srvcAreaVO.setUserId(userId);

			String sql = "Update EM_SVC_AREA set SVC_START_DATE=?, SVC_END_DATE=?, SRVC_AREA_NAME=?, LAST_UPDT_TIME=?, LAST_UPDT_USERID=? WHERE CUSTOMER_ID=? AND SRVC_AREA_ID=? AND LAST_UPDT_TIME=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, DateUtil.changedDateFormatForMonth(srvcAreaVO.getSrvcSd()));
			ps.setString(2, DateUtil.changedDateFormatForMonth(srvcAreaVO.getSrvcEd()));
			ps.setString(3, srvcAreaVO.getSrvcName());
			ps.setString(4, new DateUtil().getDB2DTS());
			ps.setString(5, userId);
			ps.setString(6, "HCFLCS4");
			ps.setString(7, srvcAreaVO.getSrvcAreaId());
			ps.setString(8, srvcAreaVO.getLstUpdTime());
			int upd = ps.executeUpdate();

			if (upd == 0) {
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			} else {
				logger.info(LoggerConstants.methodEndLevel());
				return true;
			}
		} catch (Exception ex) {
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			logger.debug("Exception in editServiceAreaData: " + ex.getMessage());
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
	}
	
	/*public List<EEMBBBSubProductVO> getBBBSubProductDetails(Connection conn)
	{
		List<EEMBBBSubProductVO> subProdList=null;
		EEMBBBSubProductVO subProdObj=new EEMBBBSubProductVO();
		try{
	      System.out.print(" Connection obj--"+conn);
		  Statement stmt = conn.createStatement();
		  String sql = "  SELECT CUSTOMER_ID, PRODUCT_ID, SUBPRODUCT_ID, SUBPRODUCT_START_DATE, SUBPRODUCT_END_DATE, SUBPRODUCT_TYPE,"+ 
						"SUBPRODUCT_DESC, RATE_AMT, FUNCTION_CD FROM BBB_SUB_PRODUCT";
		  stmt.execute(sql);
		  ResultSet rs = stmt.getResultSet();
		  if(rs!=null)
		  {
			  subProdList=new ArrayList<EEMBBBSubProductVO>();
		  
		 	while(rs.next()){
		 		subProdObj.setProductId(rs.getString("PRODUCT_ID"));
		 		subProdObj.setSubProductId(rs.getString("SUBPRODUCT_ID"));
		 		subProdObj.setSubProductStrtDate(DateUtil.formatMmDdYyyy(rs.getString("SUBPRODUCT_START_DATE")));
		 		subProdObj.setSubProductEndDate(DateUtil.formatMmDdYyyy( rs.getString("SUBPRODUCT_END_DATE")));
		 		subProdObj.setSubProductType(rs.getString("SUBPRODUCT_TYPE"));
		 		subProdObj.setSubProductDesc(rs.getString("SUBPRODUCT_DESC"));
		 		subProdObj.setRateAmnt(rs.getString("RATE_AMT"));
		 		subProdObj.setFunctionCd(rs.getString("FUNCTION_CD"));
		 		subProdList.add(subProdObj);
			 }
		  }
		}catch(Exception e){
			e.printStackTrace();
		}   
		return subProdList;
	}*/
	
	
	public boolean editGrpProdLisData(HttpServletRequest request, Connection conn, String userId, String customerId) {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("Inside editGrpProdLisData.");
		try {
			EmLisSubsidyVO lisSubsidyVO = new EmLisSubsidyVO();
			lisSubsidyVO.setPlanId((String) request.getParameter("planId"));
			lisSubsidyVO.setPbpId((String) request.getParameter("pbpId"));
			lisSubsidyVO.setLisLevel((String) request.getParameter("lisLevel"));
			lisSubsidyVO.setLisAmount((String) request.getParameter("lisAmt"));
			lisSubsidyVO.setSd((String) request.getParameter("sd"));
			lisSubsidyVO.setEd((String) request.getParameter("ed"));
			lisSubsidyVO.setLastUpdTime((String) request.getParameter("lastUpdTime"));
			lisSubsidyVO.setUserId(userId);

			String sql = "Update EM_LI_SUBSIDY set LIS_LEVEL=?, LIS_AMT=?, EFF_START_DATE=?, EFF_END_DATE=?, LAST_UPDT_TIME=?, LAST_UPDT_USERID=? WHERE CUSTOMER_ID=? AND PLAN_ID=? AND PBP_ID=? AND LAST_UPDT_TIME=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, lisSubsidyVO.getLisLevel());
			ps.setString(2, lisSubsidyVO.getLisAmount());
			ps.setString(3, DateUtil.changedDateFormatForMonth(lisSubsidyVO.getSd()));
			ps.setString(4, DateUtil.changedDateFormatForMonth(lisSubsidyVO.getEd()));
			ps.setString(5, new DateUtil().getDB2DTS());
			ps.setString(6, userId);
			ps.setString(7, "HCFLCS4");
			ps.setString(8, lisSubsidyVO.getPlanId());
			ps.setString(9, lisSubsidyVO.getPbpId());
			ps.setString(10, lisSubsidyVO.getLastUpdTime());
			int upd = ps.executeUpdate();

			if (upd == 0) {
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			} else {
				logger.info(LoggerConstants.methodEndLevel());
				return true;
			}
		} catch (Exception ex) {
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			logger.debug("Exception in editGrpProdLisData: " + ex.getMessage());
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
	}
	
	public boolean editGrpProdAsscData(HttpServletRequest request, Connection conn, String userId, String customerId) {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("Inside editGrpProdAsscData.");
		try {
			String jsonReq = (String) request.getParameter("data");
			ObjectMapper mapper = new ObjectMapper();
			EmGrpProductVO emGrpPrdVO = (EmGrpProductVO) mapper.readValue(jsonReq, EmGrpProductVO.class);
			logger.debug(emGrpPrdVO.getCustomerId());
			emGrpPrdVO.setLastUpdUserId(userId);

			String sql = "Update EM_GRP_PRODUCT set "
					+ "GRP_PROD_START_DATE=?, GRP_PROD_END_DATE=?, RX_BIN=?, RX_PCN=?, "
					+ "RX_GROUP=?, GROUPPROD_STATUS=?, OPT_OUT_IND=?, "
					+ "SPLIT_LIS_IND=?, RDS_WAIVER_IND=?, ESRD_WAIVER_IND=?, SNP_IND=?, EGHP_IND=?, "
					+ "EXTEND_MONTHS_CNT=?, DEFAULT_GRPPROD_IND=?, PRTD_PREMIUM_AMT=?, PRTC_PREMIUM_AMT=?, "
					+ "SUPPL_PREMIUM_AMT=?, PREMIUM_REDUCTION_AMT=?, DSBREBATE_AMT=?, LAST_UPDT_TIME=?, LAST_UPDT_USERID=?"
					+ "WHERE CUSTOMER_ID=? AND GRP_ID=? AND PRODUCT_ID=? AND LAST_UPDT_TIME=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, DateUtil.changedDateFormatForMonth(emGrpPrdVO.getGrpPrdSd()));
			ps.setString(2, DateUtil.changedDateFormatForMonth(emGrpPrdVO.getGrpPrdEd()));
			ps.setString(3, emGrpPrdVO.getRxBin());
			ps.setString(4, emGrpPrdVO.getRxPcn());
			ps.setString(5, emGrpPrdVO.getRxGrp());
			ps.setString(6, emGrpPrdVO.getGrpPrdStatus());
			ps.setString(7, emGrpPrdVO.getOptOutInd());
			ps.setString(8, emGrpPrdVO.getSplitLisInd());
			ps.setString(9, emGrpPrdVO.getRdsWaivInd());
			ps.setString(10, emGrpPrdVO.getEsrdWaivInd());
			ps.setString(11, emGrpPrdVO.getSnpInd());
			ps.setString(12, emGrpPrdVO.getEghpInd());
			ps.setString(13, emGrpPrdVO.getExtMonCnt());
			ps.setString(14, emGrpPrdVO.getDefGrpPrdInd());
			ps.setString(15, emGrpPrdVO.getPrtDPrem());
			ps.setString(16, emGrpPrdVO.getPrtCPrem());
			ps.setString(17, emGrpPrdVO.getSupplPrem());
			ps.setString(18, emGrpPrdVO.getPrtDPremRedAmt());
			ps.setString(19, emGrpPrdVO.getPrtDSupplBftReb());
			ps.setString(20, new DateUtil().getDB2DTS());
			ps.setString(21, userId);
			ps.setString(22, "HCFLCS4");
			ps.setString(23, emGrpPrdVO.getGrpId());
			ps.setString(24, emGrpPrdVO.getPrdId());
			ps.setString(25, emGrpPrdVO.getLastUpdTime());
			
			int upd = ps.executeUpdate();

			if (upd == 0) {
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			} else {
				logger.info(LoggerConstants.methodEndLevel());
				return true;
			}
		} catch (Exception ex) {
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			logger.debug("Exception in editGrpProdAsscData: " + ex.getMessage());
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
	}
	public boolean editbillingSubProdData(HttpServletRequest request, Connection conn, String userId, String customerId) {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("Inside editbillingSubProdData.");
		try {
			EEMBBBSubProductVO billingSubProdVO=new EEMBBBSubProductVO();
			billingSubProdVO.setProductId((String) request.getParameter("prodId"));
			billingSubProdVO.setSubProductId((String) request.getParameter("subprd"));
			billingSubProdVO.setSubProductStrtDate((String) request.getParameter("startDate"));
			billingSubProdVO.setSubProductEndDate((String) request.getParameter("endDate"));
			billingSubProdVO.setSubProductType((String) request.getParameter("type"));
			billingSubProdVO.setSubProductDesc((String) request.getParameter("desc"));
			billingSubProdVO.setRateAmnt((String) request.getParameter("rate"));
			billingSubProdVO.setFunctionCd((String) request.getParameter("functionCode"));
			

			String sql = "Update BBB_SUB_PRODUCT set PRODUCT_ID=?, SUBPRODUCT_ID=?, SUBPRODUCT_START_DATE=?,"+
					     "SUBPRODUCT_END_DATE=?, SUBPRODUCT_TYPE=?, SUBPRODUCT_DESC=? , RATE_AMT=? , FUNCTION_CD=?," +
					     " LAST_UPDT_TIME=? , LAST_UPDT_USERID =? WHERE CUSTOMER_ID=? and  PRODUCT_ID=? and SUBPRODUCT_ID=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, billingSubProdVO.getProductId());
			ps.setString(2, billingSubProdVO.getSubProductId());
			ps.setString(3, DateUtil.changedDateFormatForMonth(billingSubProdVO.getSubProductStrtDate()));
			ps.setString(4, DateUtil.changedDateFormatForMonth(billingSubProdVO.getSubProductEndDate()));
			ps.setString(5, billingSubProdVO.getSubProductType());
			ps.setString(6, billingSubProdVO.getSubProductDesc());
			ps.setString(7, billingSubProdVO.getRateAmnt());
			ps.setString(8, billingSubProdVO.getFunctionCd());
			ps.setString(9, new DateUtil().getDB2DTS());
			ps.setString(10, userId);
			ps.setString(11, "HCFLCS4");
			ps.setString(12, billingSubProdVO.getProductId());
			ps.setString(13, billingSubProdVO.getSubProductId());
			int upd = ps.executeUpdate();

			if (upd == 0) {
				logger.info(LoggerConstants.methodEndLevel());
				return false;
			} else {
				logger.info(LoggerConstants.methodEndLevel());
				return true;
			}
		} catch (Exception ex) {
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
			logger.debug("Exception in editGrpProdLisData: " + ex.getMessage());
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
	}
	
	public boolean editGroupData(HttpServletRequest request, Connection conn, String userId, String mfId) {
		logger.info(LoggerConstants.methodStartLevel());
		int upd1 = 0;
		String msg = null;
		try{

			String grpId = StringUtils.trim(request.getParameter("id"));
			String grpName =  StringUtils.trim(request.getParameter("name"));
			String grpSd =  StringUtils.trim(request.getParameter("sd"));
			String grpEd =  StringUtils.trim(request.getParameter("ed"));
			String supp =  StringUtils.trim(request.getParameter("supp"));
			String addType =  StringUtils.trim(request.getParameter("adtype"));
			String asd =  StringUtils.trim(request.getParameter("asd"));
			String aed =  StringUtils.trim(request.getParameter("aed"));
			String att = StringUtils.trim( request.getParameter("att"));
			String add1 =  StringUtils.trim(request.getParameter("add1"));
			String add2 =  StringUtils.trim(request.getParameter("add2"));
			String add3 =  StringUtils.trim(request.getParameter("add3"));
			String city =  StringUtils.trim(request.getParameter("city"));
			String stcode = StringUtils.trim( request.getParameter("stcode"));
			String zipcd =  StringUtils.trim(request.getParameter("zipcd"));
			String ccd =  StringUtils.trim(request.getParameter("ccd"));
			String ph =  StringUtils.trim(request.getParameter("ph"));
			String fax =  StringUtils.trim(request.getParameter("fax"));

			logger.debug("grpId ==="+grpId+"grpName:  "+grpName+"supp:  "+supp+"add1:  "+add1);
			if(grpId != null && grpName !=null && grpSd != null && grpEd != null 
					&& grpId != "" && grpName !="" && grpSd != "" && grpEd != ""){
				//System.out.println(" in if");
				int upd=0;
				String sql="";
				String sql1="";
				String sql2="";
				sql1 = "update em_grp set suppl_grp_id=?,grp_start_date=?, grp_end_date=?,last_updt_time=? , last_updt_userid=? where grp_id=? and customer_id=?";
				sql = "update em_grp_name set group_name=?, grpname_start_date=?,grpname_end_date=?, last_updt_time=? , last_updt_userid=?  where grp_id=? and customer_id=?";
				sql2 = "update em_grp_address set grpaddress_type=?, grp_addr_start_date=?, grp_addr_end_date=?, grp_start_date=?, attention_name=?, address1=?, address2=?, address3=?, city=?, state_cd=?, zip_cd=?, country_cd=?, office_phone_nbr=?, fax_nbr=?, last_updt_time=? , last_updt_userid=? where grp_id=? and customer_id=?";
				PreparedStatement ps1 = conn.prepareStatement(sql1);
				ps1.setString(1, supp);
				ps1.setString(2, DateUtil.changedDateFormatForMonth(grpSd));
				ps1.setString(3, DateUtil.changedDateFormatForMonth(grpEd));
				ps1.setString(4, new DateUtil().getDB2DTS());
				ps1.setString(5, userId);
				ps1.setString(6, grpId);
				ps1.setString(7, "HCFLCS4");
				upd = ps1.executeUpdate();

				if(upd == 0){
					msg = "fail";
					logger.info(LoggerConstants.methodEndLevel());
					return false;

				}
				else if(upd >0){
					PreparedStatement ps2 = conn.prepareStatement(sql);
					ps2.setString(1, grpName);
					ps2.setString(2, DateUtil.changedDateFormatForMonth(grpSd));
					ps2.setString(3, DateUtil.changedDateFormatForMonth(grpEd));
					ps2.setString(4, new DateUtil().getDB2DTS());
					ps2.setString(5, userId);
					ps2.setString(6, grpId);
					ps2.setString(7, "HCFLCS4");
					upd1 = ps2.executeUpdate();
					if(upd1 ==0){
						msg = "fail";
						logger.info(LoggerConstants.methodEndLevel());
						return false;

					}
					else if( upd1 >0){
						PreparedStatement ps = conn.prepareStatement(sql2);
						ps.setString(1, addType);
						ps.setString(2, DateUtil.changedDateFormatForMonth(asd));
						ps.setString(3, DateUtil.changedDateFormatForMonth(aed));
						ps.setString(4, DateUtil.changedDateFormatForMonth(grpSd));
						ps.setString(5, att);
						ps.setString(6, add1);
						ps.setString(7, add2);
						ps.setString(8, add3);
						ps.setString(9, city);
						ps.setString(10, stcode);
						ps.setString(11, zipcd);
						ps.setString(12, ccd);
						ps.setString(13, ph);
						ps.setString(14, fax);
						ps.setString(15, new DateUtil().getDB2DTS());
						ps.setString(16, userId);
						ps.setString(17, grpId);
						ps.setString(18, "HCFLCS4");
						upd1 = ps.executeUpdate();
						if(upd1 ==0){
							msg = "fail";
							logger.info(LoggerConstants.methodEndLevel());
							return false;

						}
						else{
							msg = "success";
							logger.info(LoggerConstants.methodEndLevel());
							return true;

						}
					}
				}

			}

		}
		catch(Exception e){
			msg = "fail";
			e.printStackTrace();
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.info(LoggerConstants.methodEndLevel());
			return false;
		}
		logger.debug("msg: "+msg);
		logger.info(LoggerConstants.methodEndLevel());
		return true;
	}
	
	
}