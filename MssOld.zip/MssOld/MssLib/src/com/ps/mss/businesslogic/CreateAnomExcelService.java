package com.ps.mss.businesslogic;

import java.util.ArrayList;
import java.util.List;
import java.text.DateFormatSymbols;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.mss.dao.model.McaidAnomSummDetailVO;
import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.model.McaidAnomDashBoardVO;
import com.ps.mss.dao.model.McaidAnomSummDetailDataVO;
import com.ps.mss.helper.McaidReconHelper;




/**
 *
 * @author prare
 */
public class CreateAnomExcelService {
	
	private static Logger logger=(Logger) LoggerFactory.getLogger(CreateAnomExcelService.class);

    public HSSFWorkbook createDashboardWorkbook(List dataList) throws Exception {
    	logger.info(LoggerConstants.methodStartLevel());
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet("Anomaly Dashboard");
        
        
        sheet.setColumnWidth((short)0, (short)4000);
        sheet.setColumnWidth((short)1, (short)9000);
        sheet.setColumnWidth((short)2, (short)2000);
        sheet.setColumnWidth((short)3, (short)9000);
        sheet.setColumnWidth((short)4, (short)5000);
        sheet.setColumnWidth((short)5, (short)5000);
        /*sheet.setColumnWidth((short)6, (short)5000);
        sheet.setColumnWidth((short)7, (short)5000);*/
        /**
         * Style for the header cells.
         */
        HSSFCellStyle headerCellStyle = wb.createCellStyle();
        HSSFFont boldFont = wb.createFont();
        boldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        headerCellStyle.setFont(boldFont);

        HSSFRow row = sheet.createRow(0);
        HSSFCell cell = row.createCell((short) 0);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("PBP/Period").toString());
        cell = row.createCell((short) 1);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Total").toString());
        cell = row.createCell((short) 2);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Open").toString());
        cell = row.createCell((short) 3);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("In Progress").toString());
        cell = row.createCell((short) 4);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Force Closed").toString());
        cell = row.createCell((short) 5);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Resolved").toString());
        /*cell = row.createCell((short) 6);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("User ID").toString());
        cell = row.createCell((short) 7);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Last Update").toString());*/
        
        int index = 0;
        for (int pbpIndex = 0; pbpIndex < dataList.size(); pbpIndex++) {
        	
//        	McaidAnomSummDetailVO pbpData = (McaidAnomSummDetailVO) dataList.get(pbpIndex);
        	McaidAnomDashBoardVO pbpData =  (McaidAnomDashBoardVO) dataList.get(pbpIndex);
            index++;
            row = sheet.createRow(index);
            
            cell = row.createCell((short) 0);            
            HSSFRichTextString pbpDesc = new HSSFRichTextString(pbpData.getPbpDesc());
            cell.setCellValue(pbpDesc.toString());
            cell = row.createCell((short) 1);
            HSSFRichTextString total = new HSSFRichTextString(pbpData.getTotal());
            cell.setCellValue(total.toString());
            cell = row.createCell((short) 2);
            HSSFRichTextString open = new HSSFRichTextString(pbpData.getOpen());
            cell.setCellValue(open.toString());
            cell = row.createCell((short) 3);
            HSSFRichTextString inProgress = new HSSFRichTextString(pbpData.getInProgress());
            cell.setCellValue(inProgress.toString());
            cell = row.createCell((short) 4);
            HSSFRichTextString forceClose = new HSSFRichTextString(pbpData.getForceClose());
            cell.setCellValue(forceClose.toString());
            cell = row.createCell((short) 5);
            HSSFRichTextString resolved = new HSSFRichTextString(pbpData.getResolved());
            cell.setCellValue(resolved.toString());
           /* cell = row.createCell((short) 6);
            HSSFRichTextString userId = new HSSFRichTextString(pbpData.getUserId());
            cell.setCellValue(userId.toString());
            cell = row.createCell((short) 7);
            HSSFRichTextString lastUpdate = new HSSFRichTextString(pbpData.getLastUpdate());
            cell.setCellValue(lastUpdate.toString());*/
            
            //year-START
            List yearDataList = pbpData.getPbpYrOrQtrOrMonLst();
            if(yearDataList != null){//yearIf
	            for (int yearIndex = 0; yearIndex < yearDataList.size(); yearIndex++) {
	            	McaidAnomDashBoardVO yearData = (McaidAnomDashBoardVO) yearDataList.get(yearIndex);
	            	 index++;
	                 row = sheet.createRow(index);
	                 
	                 cell = row.createCell((short) 0);            
	                 pbpDesc = new HSSFRichTextString(yearData.getYear());
	                 cell.setCellValue(pbpDesc.toString());
	                 cell = row.createCell((short) 1);
	                 total = new HSSFRichTextString(yearData.getTotal());
	                 cell.setCellValue(total.toString());
	                 cell = row.createCell((short) 2);
	                 open = new HSSFRichTextString(yearData.getOpen());
	                 cell.setCellValue(open.toString());
	                 cell = row.createCell((short) 3);
	                 inProgress = new HSSFRichTextString(yearData.getInProgress());
	                 cell.setCellValue(inProgress.toString());
	                 cell = row.createCell((short) 4);
	                 forceClose = new HSSFRichTextString(yearData.getForceClose());
	                 cell.setCellValue(forceClose.toString());
	                 cell = row.createCell((short) 5);
	                 resolved = new HSSFRichTextString(yearData.getResolved());
	                 cell.setCellValue(resolved.toString());
	                 
	                 /*
	                 
	                 
	                 cell = row.createCell((short) 1);
	                 anomaly = new HSSFRichTextString(pbpData.getAnomaly());
	                 cell.setCellValue(anomaly.toString());
	                 cell = row.createCell((short) 2);
	                 effDate = new HSSFRichTextString(pbpData.getEffDate());
	                 cell.setCellValue(effDate.toString());
	                 cell = row.createCell((short) 3);
	                 status = new HSSFRichTextString(pbpData.getStatus());
	                 cell.setCellValue(status.toString());
	                 cell = row.createCell((short) 4);
	                 pbpId = new HSSFRichTextString(pbpData.getPbpId());
	                 cell.setCellValue(pbpId.toString());
	                 cell = row.createCell((short) 5);
	                 anomalyType = new HSSFRichTextString(pbpData.getAnomType());
	                 cell.setCellValue(anomalyType.toString());
	                 cell = row.createCell((short) 6);
	                 userId = new HSSFRichTextString(pbpData.getUserId());
	                 cell.setCellValue(userId.toString());
	                 cell = row.createCell((short) 7);
	                 lastUpdate = new HSSFRichTextString(pbpData.getLastUpdate());
	                 cell.setCellValue(lastUpdate.toString());*/

	            	
	               //QTR-START
	                 List qtrDataList = yearData.getPbpYrOrQtrOrMonLst();
	                 if(qtrDataList != null){//qtrIf
	     	            for (int qtrIndex = 0; qtrIndex < qtrDataList.size(); qtrIndex++) {
	     	            	McaidAnomDashBoardVO qtrData = (McaidAnomDashBoardVO) qtrDataList.get(qtrIndex);	     	            	
	     	            	 index++;
	     	                 row = sheet.createRow(index);
	     	                 
	     	                 cell = row.createCell((short) 0);            
	     	                pbpDesc = new HSSFRichTextString(qtrData.getQuarter());
	     	                 cell.setCellValue(pbpDesc.toString());
	     	                 cell = row.createCell((short) 1);
		   	                 total = new HSSFRichTextString(qtrData.getTotal());
		   	                 cell.setCellValue(total.toString());
		   	                 cell = row.createCell((short) 2);
		   	                 open = new HSSFRichTextString(qtrData.getOpen());
		   	                 cell.setCellValue(open.toString());
		   	                 cell = row.createCell((short) 3);
		   	                 inProgress = new HSSFRichTextString(qtrData.getInProgress());
		   	                 cell.setCellValue(inProgress.toString());
		   	                 cell = row.createCell((short) 4);
		   	                 forceClose = new HSSFRichTextString(qtrData.getForceClose());
		   	                 cell.setCellValue(forceClose.toString());
		   	                 cell = row.createCell((short) 5);
		   	                 resolved = new HSSFRichTextString(qtrData.getResolved());
		   	                 cell.setCellValue(resolved.toString());
	     	                /* cell = row.createCell((short) 1);
	     	                anomaly = new HSSFRichTextString(pbpData.getAnomaly());
	     	                 cell.setCellValue(anomaly.toString());
	     	                 cell = row.createCell((short) 2);
	     	                effDate = new HSSFRichTextString(pbpData.getEffDate());
	     	                 cell.setCellValue(effDate.toString());
	     	                 cell = row.createCell((short) 3);
	     	                status = new HSSFRichTextString(pbpData.getStatus());
	     	                 cell.setCellValue(status.toString());
	     	                 cell = row.createCell((short) 4);
	     	                pbpId = new HSSFRichTextString(pbpData.getPbpId());
	     	                 cell.setCellValue(pbpId.toString());
	     	                 cell = row.createCell((short) 5);
	     	                anomalyType = new HSSFRichTextString(pbpData.getAnomType());
	     	                 cell.setCellValue(anomalyType.toString());
	     	                cell = row.createCell((short) 6);
	     	               userId = new HSSFRichTextString(pbpData.getUserId());
	     	                 cell.setCellValue(userId.toString());
	     	                cell = row.createCell((short) 7);
	     	               lastUpdate = new HSSFRichTextString(pbpData.getLastUpdate());
	     	                 cell.setCellValue(lastUpdate.toString());*/
	     	                 
	     	                 
	     	                 
	     	              //MONTH-START
	    	                 List monthDataList = qtrData.getPbpYrOrQtrOrMonLst();
	    	                 if(monthDataList != null){//monthIf
	    	     	            for (int monthIndex = 0; monthIndex < monthDataList.size(); monthIndex++) {
	    	     	            	McaidAnomDashBoardVO monthData = (McaidAnomDashBoardVO) monthDataList.get(monthIndex);	            	 
	    	     	            	 index++;
	    	     	                 row = sheet.createRow(index);
	    	     	                 
	    	     	                cell = row.createCell((short) 0);  
	    	     	               String revicedMonth = getMonthName(Integer.parseInt(monthData.getMonth()));
	    	     	                pbpDesc = new HSSFRichTextString(revicedMonth);
	    	     	                 cell.setCellValue(pbpDesc.toString());
	    	     	                 cell = row.createCell((short) 1);
		   		   	                 total = new HSSFRichTextString(monthData.getTotal());
		   		   	                 cell.setCellValue(total.toString());
		   		   	                 cell = row.createCell((short) 2);
		   		   	                 open = new HSSFRichTextString(monthData.getOpen());
		   		   	                 cell.setCellValue(open.toString());
		   		   	                 cell = row.createCell((short) 3);
		   		   	                 inProgress = new HSSFRichTextString(monthData.getInProgress());
		   		   	                 cell.setCellValue(inProgress.toString());
		   		   	                 cell = row.createCell((short) 4);
		   		   	                 forceClose = new HSSFRichTextString(monthData.getForceClose());
		   		   	                 cell.setCellValue(forceClose.toString());
		   		   	                 cell = row.createCell((short) 5);
		   		   	                 resolved = new HSSFRichTextString(monthData.getResolved());
		   		   	                 cell.setCellValue(resolved.toString());
	    	     	                /* cell = row.createCell((short) 1);
	    	     	                anomaly = new HSSFRichTextString(pbpData.getAnomaly());
	    	     	                 cell.setCellValue(anomaly.toString());
	    	     	                 cell = row.createCell((short) 2);
	    	     	                effDate = new HSSFRichTextString(pbpData.getEffDate());
	    	     	                 cell.setCellValue(effDate.toString());
	    	     	                 cell = row.createCell((short) 3);
	    	     	                status = new HSSFRichTextString(pbpData.getStatus());
	    	     	                 cell.setCellValue(status.toString());
	    	     	                 cell = row.createCell((short) 4);
	    	     	                pbpId = new HSSFRichTextString(pbpData.getPbpId());
	    	     	                 cell.setCellValue(pbpId.toString());
	    	     	                 cell = row.createCell((short) 5);
	    	     	                anomalyType = new HSSFRichTextString(pbpData.getAnomType());
	    	     	                 cell.setCellValue(anomalyType.toString());
	    	     	                cell = row.createCell((short) 6);
	    	     	               userId = new HSSFRichTextString(pbpData.getUserId());
	    	     	                 cell.setCellValue(userId.toString());
	    	     	                cell = row.createCell((short) 7);
	    	     	               lastUpdate = new HSSFRichTextString(pbpData.getLastUpdate());
	    	     	                 cell.setCellValue(lastUpdate.toString());*/
	    	     	                 
	    	     	            	
	    	     	            	
	    	     	            	
	    	     	            }//monthFor
	    	                 }//monthIf
	    	                 //MONTH-END
	     	                 
	     	            	
	     	            	
	     	            }//qtrFor
	                 }//qtrIf
	                 //QTR-END
	                 
	            	
	            }//yearFor
            }//yearIf
            //year-END
            
            
        }//pbpFor
        logger.info(LoggerConstants.methodEndLevel());
        return wb;
    }
    
    public HSSFWorkbook createSummaryWorkbook(String string, List dataList, McaidAnomSummDetailDataVO mcaidAnomSummDetailDataVO) throws Exception {
    	logger.info(LoggerConstants.methodStartLevel());
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet("Anomaly Summary");
                
        sheet.setColumnWidth((short)0, (short)3000);
        sheet.setColumnWidth((short)1, (short)3000);
        sheet.setColumnWidth((short)2, (short)3000);
        sheet.setColumnWidth((short)3, (short)3000);
        sheet.setColumnWidth((short)4, (short)3000);
        sheet.setColumnWidth((short)5, (short)3000);
        sheet.setColumnWidth((short)6, (short)3000);
        sheet.setColumnWidth((short)7, (short)3000);
//        sheet.setColumnWidth((short)8, (short)3000);

        /**
         * Style for the header cells.
         */
        HSSFCellStyle headerCellStyle = wb.createCellStyle();
        HSSFFont boldFont = wb.createFont();
        boldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        headerCellStyle.setFont(boldFont);

        HSSFRow row = sheet.createRow(0);
        HSSFCell cell = row.createCell((short) 0);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Medicaid ID").toString());
        cell = row.createCell((short) 1);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Anomaly").toString());
        cell = row.createCell((short) 2);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Effective Date").toString());
        cell = row.createCell((short) 3);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Status").toString());
        cell = row.createCell((short) 4);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("PBP").toString());
        cell = row.createCell((short) 5);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Anomaly Type").toString());
        cell = row.createCell((short) 6);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("User ID").toString());
        cell = row.createCell((short) 7);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Last Update").toString());
       /* cell = row.createCell((short) 8);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Last Update").toString());*/
        
        //ArrayList<ApplistMBDQueue> data = (ArrayList<ApplistMBDQueue>)dataList;
        int pbpIndex=0;
        for (int index = 0; index < dataList.size(); index++) {
//            row = sheet.createRow(index + 1);            
            McaidAnomSummDetailVO data = (McaidAnomSummDetailVO) dataList.get(index);
            pbpIndex++;
            row = sheet.createRow(pbpIndex);
            cell = row.createCell((short) 0);
            HSSFRichTextString medicaidId = new HSSFRichTextString(data.getMedicaidId());
            cell.setCellValue(medicaidId.toString());
            cell = row.createCell((short) 1);
            HSSFRichTextString disc = new HSSFRichTextString(data.getAnomaly());
            cell.setCellValue(disc.toString());
            cell = row.createCell((short) 2);
            HSSFRichTextString effDate = new HSSFRichTextString(McaidReconHelper.dateMonthByYearFormat(data.getEffDate()));
            cell.setCellValue(effDate.toString());
            cell = row.createCell((short) 3);
            HSSFRichTextString status = new HSSFRichTextString(data.getStatus());
            cell.setCellValue(status.toString());
            cell = row.createCell((short) 4);
            HSSFRichTextString pbpDesc = new HSSFRichTextString(data.getPbpDesc());
            cell.setCellValue(pbpDesc.toString());
            cell = row.createCell((short) 5);
            HSSFRichTextString anomType = new HSSFRichTextString(data.getAnomType());
            cell.setCellValue(anomType.toString());
            /*cell = row.createCell((short) 6);
            HSSFRichTextString plan = new HSSFRichTextString(data.getPlan());
            cell.setCellValue(plan.toString());*/
            cell = row.createCell((short) 6);
            HSSFRichTextString userId = new HSSFRichTextString(data.getUserId());
            cell.setCellValue(userId.toString());
            cell = row.createCell((short) 7);
            HSSFRichTextString lastUpdt = new HSSFRichTextString(data.getLastUpdate());
            cell.setCellValue(lastUpdt.toString());
        }
        logger.info(LoggerConstants.methodEndLevel());
        return wb;
    	
    }//createSummaryWorkbook()
    
    private String getMonthName(int monVal){
    	logger.info(LoggerConstants.methodStartLevel());
	 	String[] months = new DateFormatSymbols().getMonths();
	 	logger.info(LoggerConstants.methodEndLevel());
		return months[monVal-1];	 			 	
 	}	
}//class
