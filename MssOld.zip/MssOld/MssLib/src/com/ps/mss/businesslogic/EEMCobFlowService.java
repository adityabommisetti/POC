 /*
  * $Id: EEMTimersService.java,v 1.1 2014/06/26 07:43:46 praveen Exp $ 
  */


package com.ps.mss.businesslogic;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.DaoFactory;
import com.ps.mss.dao.EEMCobFlowDao;
import com.ps.mss.dao.EEMTimersDao;
import com.ps.mss.dao.model.EEMCobFlowVO;
import com.ps.mss.dao.model.EMTimersSearchVO;
import com.ps.mss.dao.model.EMTimersVO;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.model.Pagination;
import com.ps.text.DateFormatter;
import com.ps.util.DateUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class EEMCobFlowService {
private static Logger logger = LoggerFactory.getLogger(EEMCobFlowService.class);
	/**
	 * This method returns the Timers List
	 * @param conn
	 * @param objVO
	 * @param pagination
	 * @param move
	 * @param custId
	 * @return lstFields
	 * @throws ApplicationException
	 */
	
	public EEMCobFlowVO getSearchList(Connection conn, EEMCobFlowVO objVO, String pagination, String move,String custId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
	
		logger.debug("Get List of RFI Timers from EEMTimersDao :Start");
		EEMCobFlowVO resultVO = null;
		try {
			

			EEMCobFlowDao eemDao = DaoFactory.getInstance().getEEMCobFlowDao();
         
			 resultVO = eemDao.getCobList(conn, objVO, pagination, move,custId);
		

		} catch (Exception e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			throw new ApplicationException(e);
		}
		logger.info(LoggerConstants.methodEndLevel());
		logger.debug("Get List of RFI Timers from EEMTimersDao :End");
		return resultVO;
	}

	
	public boolean cobFlowUpdate(Connection conn, EEMCobFlowVO objVO,String userId,String custId) throws ApplicationException, SQLException {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("RFI Timers Update :Start");
		
    	try
    	{
	
			
			EEMCobFlowDao eemDao = new EEMCobFlowDao();
		    int sqlCnt = eemDao.updateCob(conn, objVO, userId, custId);
		    if(sqlCnt!=1){
		    	logger.info(LoggerConstants.methodEndLevel());
		    	return false;
		    }
    	}
			
    	
		 finally {
			try {
    			
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			throw new ApplicationException(e);
    		}
    		try {
    			
    		} catch(Exception e) {
    			logger.error(LoggerConstants.exceptionMessage(e.toString()));
    			throw new ApplicationException(e);
    		}	
		}
	

    	logger.info(LoggerConstants.methodEndLevel());
    	logger.debug("RFI Timers Update :End");
		
    	return true;
			

}
}