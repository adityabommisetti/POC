/*
 * $Id: CsvService.java,v 1.3 2015/06/25 05:29:10 praveen Exp $
 */
package com.ps.mss.businesslogic;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;//367728
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.DecimalFormat; //367728
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ps.io.CSVUtil;
import com.ps.logger.LoggerConstants;
import com.ps.mss.dao.ChartEncounterDao;
import com.ps.mss.dao.DaoFactory;
import com.ps.mss.dao.HPEEncounterDao;
import com.ps.mss.dao.HPEFileTrackDao;
import com.ps.mss.dao.model.Enc837ChangeClaimlogVO;
import com.ps.mss.dao.model.Enc837ChangeClaimlogVOs;
import com.ps.mss.dao.model.Enc837iClmErrorVO;
import com.ps.mss.dao.model.Enc837iClmErrorVOs;
import com.ps.mss.dao.model.Enc837iClmVO;
import com.ps.mss.dao.model.Enc837iClmVOs;
import com.ps.mss.dao.model.Enc837pClmErrorVO;
import com.ps.mss.dao.model.Enc837pClmErrorVOs;
import com.ps.mss.dao.model.Enc837pClmVO;
import com.ps.mss.dao.model.Enc837pClmVOs;
//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export Start
import com.ps.mss.dao.model.Enc837iSubsVO;
import com.ps.mss.dao.model.Enc837iSubsVOs;
import com.ps.mss.dao.model.Enc837pSubsVO;
import com.ps.mss.dao.model.Enc837pSubsVOs;
//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export End
import com.ps.mss.dao.model.EncCmstatSumVO;
import com.ps.mss.dao.model.EncCmstatSumVOs;
import com.ps.mss.dao.model.EncErrorstatSumVO;
import com.ps.mss.dao.model.EncErrorstatSumVOs;
import com.ps.mss.dao.model.HPEFTDailyFileProcessingDO;
import com.ps.mss.dao.model.McaidPaymentDashBoardVO;
import com.ps.mss.db.ENCCodeCache;
import com.ps.mss.exception.ApplicationException;
import com.ps.mss.exception.DaoException;
import com.ps.mss.framework.Constants;
import com.ps.mss.framework.HPEConstants;
import com.ps.mss.helper.ServiceHelper;
import com.ps.mss.model.BeneficiaryPymtDetailByPartsVO;
import com.ps.mss.model.BeneficiaryPymtDetailVO;
import com.ps.mss.model.BeneficiaryPymtDetailVOList;
import com.ps.mss.model.CgapReconItem;
import com.ps.mss.model.DashBoardItem;
import com.ps.mss.model.DiscrepancyCdVO;
import com.ps.mss.model.DiscrepancyDashBoardVO;
import com.ps.mss.model.DiscrepancyDetailVO;
import com.ps.mss.model.DiscrepancyDetailVOList;
import com.ps.mss.model.DiscrepancyListVO;
import com.ps.mss.model.DiscrepancySummaryVO;
import com.ps.mss.model.DiscrepancySummaryVOList;
import com.ps.mss.model.DiseaseGroupVO;
import com.ps.mss.model.DiseaseGroupVOList;
import com.ps.mss.model.FilterVO;
import com.ps.mss.model.GenericDashboard;
import com.ps.mss.model.HPEContext;
import com.ps.mss.model.HPEEncounterVO;
import com.ps.mss.model.LicsReconItem;
import com.ps.mss.model.McaidReconPaymentVO;
import com.ps.mss.model.Pagination;
import com.ps.mss.model.PartDForeCastItem;
import com.ps.mss.model.PaymentDashBoardVO;
import com.ps.mss.model.PaymentSummaryVO;
import com.ps.mss.model.PaymentSummaryVOList;
import com.ps.mss.model.PdeContext;
import com.ps.mss.model.PdeDashboardVO;
import com.ps.mss.model.PdeErrDetailItem;
import com.ps.mss.model.PdeEventDetailVO;
import com.ps.mss.model.PdeEventDetailVoList;
import com.ps.mss.model.ProfileSearchDetailVO;
import com.ps.mss.model.ProfileSearchVO;
import com.ps.mss.model.ProfileSearchVOList;
import com.ps.mss.model.PymtEffDateDetailVO;
import com.ps.mss.model.RapsClaimDashBoard;
import com.ps.mss.model.RapsClaimDetailItem;
import com.ps.mss.model.RapsClaimsDetailPage;
import com.ps.mss.model.RapsContext;
import com.ps.mss.model.RapsDashBoard;
import com.ps.mss.model.RapsDetailItem;
import com.ps.mss.model.RapsDetailPage;
import com.ps.mss.model.RapsErrorsItem;
import com.ps.mss.model.RapsErrorsPage;
import com.ps.mss.model.RapsFilter;
import com.ps.mss.model.RapsStatisticItem;
import com.ps.mss.model.ReconciliationListVO;
import com.ps.mss.model.ReconciliationVO;
import com.ps.mss.model.ReinReconItem;
import com.ps.mss.model.ReinddirItem;
import com.ps.mss.model.ReinsuranceContext;
import com.ps.mss.model.RiskReconItem;
import com.ps.mss.model.TroopDashBoardVO;
import com.ps.mss.model.TroopDashBoardVOList;
import com.ps.mss.model.TroopDetailVO;
import com.ps.mss.model.TroopDetailVOList;
import com.ps.mss.model.UnappliedPymtAdjVO;
import com.ps.mss.model.WorkAgedSummaryVO;
import com.ps.mss.util.MssProperties;
import com.ps.text.DateFormatter;
import com.ps.util.DateUtil;
import com.ps.util.GridUtil;
import com.ps.util.GridUtil.Month;
import com.ps.util.GridUtil.Year;
import com.ps.util.NameValuePair;
import com.ps.util.StringUtil;

/**
 * @author hemant
 *
 */
public class CsvService implements ExportService {
	
	private String dbId;
	//private ServiceHelper serviceHelper = null;
	private static Logger logger=LoggerFactory.getLogger(CsvService.class);
	
	//SSNRI 2017 : start (HIC# = Medicare ID)
	private static final String RECONCIALIATION_POPUP= "Source,Extract Date,Plan ID,Plan Name,Medicare ID,Date,Date Type,Part Ind,Data Field,CMS Value,Plan Value,Match";
	private static final String BENE_PYMT_DETAIL_PARTC_POPUP= "Source,Extract Date,Plan ID,Plan Name,Medicare ID,Part Ind,Effective Date,Apply Date,Payment Type,Part A Amt,Part B Amt,Total Amt";
	private static final String DISEASE_GROUP_POPUP= "Source,Extract Date,Plan ID,Plan Name,Medicare ID,Date,Date Type,Part Ind,Disease Group,CMS Value,Plan Value";
	private static final String DISCREPANCY_PAYMENT_POPUP= "Source,Extract Date,Plan ID,Plan Name,Medicare ID,Part Ind,Effective Date,Apply Date,Adj Code,Adj Description,Payment Type,CMS Paid,Plan Expected,Difference";
	private static final String PAYMENT_DESHBOARD_HEADING = "Source,Extract Date,Plan ID,Plan Name,Date,Date Type,Part C - CMS Paid,Part C - Plan Expected,Part C - Difference,Part D - CMS Paid,Part D - Plan Expected,Part D - Difference,Search Plan ID,Search Start Date,Search End Date,Search Date Type";
	private static final String BENEFICIARY_PAYMENT_DESHBOARD_HEADING ="Source,Extract Date,Plan ID,Plan Name,Date,Date Type,Part C - CMS Paid,Part C - Plan Expected,Part C - Difference,Part D - CMS Paid,Part D - Plan Expected,Part D - Difference,Search Plan ID,Search Medicare ID,Search Start Date,Search End Date,Search Date Type";
	private static final String TROOP_DESHBOARD_HEADING ="Source,Extract Date,Plan ID,Plan Name,Medicare ID,Date,Date Type,Total TrOOP,Patient Pay Amount,Other TrOOP Amount,LICS Amount,CGAP Amount,Search Plan ID,Search Medicare ID,Search Start Date,Search End Date";	// Added for CGAP Screen IFOX-00432723
	private static final String PDE_DESHBOARD_HEADING ="Source,Extract Date,Plan ID,Plan Name,Medicare ID,Date,Date Type,Event Accepted,Event Rejected,Event Total, Adjusted, Resubmitted,Total PDE,Search Plan ID,Search Medicare ID,Search Start Date,Search End Date";
	private static final String DISCREPANCY_DESHBOARD_HEADING = "Source,Extract Date,Plan ID,Plan Name,Date,Date Type,Part C - Total Count,Part C - Open,Part C � In Progress,Part C � Force Close,Part C - Resolved,Part D - Total Count,Part D - Open,Part D � In Progress,Part D � Force Close,Part D - Resolved,Search Plan ID,Search Start Date,Search End Date,Search Date Type";
	private static final String BENEFICIARY_DISCREPANCY_DESHBOARD_HEADING = "Source,Extract Date,Plan ID,Plan Name,Medicare ID,Date,Date Type,Part C - Total Count,Part C - Open,Part C � In Progress,Part C � Force Close,Part C - Resolved,Part D - Total Count,Part D - Open,Part D � In Progress,Part D � Force Close,Part D - Resolved,Search Plan ID,Search Start Date,Search End Date,Search Date Type";
	private static final String DISCREPANCY_DETAIL_HEADING = "Source,Extract Date,Plan ID,Plan Name,Part Ind,Medicare ID,Alt Medicare ID,Discrepancy Code,Discrepancy Text,Date,Date Type,Status,PBP ID,CMS Value,Plan Value, Comments, Update User ID,Last Update,Search Plan ID,Search Part Ind,Search Eff Start Date,Search Eff End Date,Search Upd Start Date,Search Upd End Date,Search Status Code,Search Medicare ID,Search Type Code,Search Upd ID";
	private static final String WORK_QUEUE_HEADING = "Source,Extract Date,Plan ID,Plan Name,Part Ind,Medicare ID,Discrepancy Code,Discrepancy Text,Date,Date Type,Status,PBP ID,PBP Segment ID, Assigned By, Assigned To, Assigned On,CMS Value,Plan Value, Comments, Update User ID,Last Update,Search Plan ID,Search Eff Start Date,Search Eff End Date,Search Upd Start Date,Search Upd End Date,Search Status Code,Search Medicare ID,Search Type Code,Search Upd ID";
	
	private static final String BENEFICIARY_DISCREPANCY_DETAIL_HEADING = "Source,Extract Date,Plan Id,Plan Name,Medicare ID,Alt Medicare ID,Part Ind,Discrepancy Code,Discrepancy Text,Date,Date Type,Status,PBP ID,CMS Value,Plan Value,Update User ID,Last Update,Search Plan ID,Search Eff Start Date,Search Eff End Date,Search Upd Start Date,Search Upd End Date,Search Status Code,Search Part Ind,Search Medicare ID,Search Type Code,Search Upd ID";
	private static final String PAYMENT_SUMMARY_HEADING = "Source,Extract Date,Plan ID,Plan Name,Earliest Date,Latest Date,Date Type,Part Ind,Pay Ind,Payment Type,Payment Description,CMS Paid (Pre WA),Plan Expected (Pre WA),Difference,Search Plan ID,Search Start Date,Search End Date,Search Date Type";
	private static final String DISCREPANCY_SUMMARY_HEADING = "Source,Extract Date,Plan ID,Plan Name,Earliest Date,Latest Date,Date Type,Part Ind,Membership,Discrepancy Code,Discrepancy Text,Count,Percentage,Search Plan ID,Search Part Ind,Search Status Code,Search Start Date,Search End Date,Search Date Type";
	private static final String BENEFICIARY_PYMT_DETAIL_HEADING = "Source,Extract Date,Plan ID,Plan Name,Medicare ID,Part Ind,Effective Date,Apply Date,Received Date,Payment Start Date,Payment End Date,Adj Code,Adj Description,Payment Type,CMS Paid,Plan Expected,Difference,Search Plan ID,Search Medicare ID,Search Start Date,Search End Date,Search Date Type";
	private static final String TROOP_DETAIL_HEADING ="Source,Extract Date,Plan ID,Plan Name,Effective Date,Apply Date,Medicare ID,Total TrOOP Amt,Adj Code,Adj Description,Patient Pay Amt,Other TrOOP Amt,LICS Amt,CGAP Amt,Search Plan ID,Search Start Date,Search End Date,Search Date Type,Search Medicare ID";	//Added for CGAP Screen IFOX-00432723
	private static final String PDE_DETAIL_HEADING ="Source,Extract Date,Plan ID,Plan Name,Medicare ID,Service Date,Status,Reference #,Product ID,Last Update,Search Plan ID,Search Start Date,Search End Date,Search Status Code,Search Medicare ID";
	private static final String PDE_ERR_DB_HEADING ="Source,Extract Date,Plan ID,Plan Name,PBP ID,Date,Date Type,Information,Rejected,Resubmitted,Total,Search Plan ID,Search PBP,Search Start Date,Search End Date, Search Record Id, Search Error";
	private static final String PDE_ERR_CODES_HEADING ="Source,Extract Date,Plan ID,Plan Name,PBP ID,Date,Date Type,Record Id,Error Code,Count,Search Plan ID,Search PBP,Search Start Date,Search End Date, Search Record Id, Search Error";
	private static final String PDE_ERRDETAIL_HEADING ="Source,Extract Date,Plan ID,Plan Name,PBP ID,Medicare ID,Service Date,Status,Reference #,Product ID,Last Update,Search Plan ID,Search PBP,Search Start Date,Search End Date,Search Record Id, Search Error,Search Medicare ID";
	private static final String PROFILE_DETAIL_HEADING = "Source, Extract Date, Plan ID, Plan Name, PBP Id, Segment Id, Start Date, End Date, Parameter Code, Parameter Value, Last Update, Search Plan ID, Search Start Date, Search End Date, Search Parameter Code, Search PBP ID, Search Segment ID";
	//SSNRI 2017 : end (HIC# = Medicare ID)
	
	/*private static final String ENCOUNTER_HEADER_NAMES ="Source,Extract Date,Submitter Id,Date Type,Search From,Search To,Search Claim Type,Search Claim Nbr,Search Hic Number,Search Status,Search Error Source,Search Error Group,Search Error Code," +
				"Claim Ref Nbr,"+ Constants.CUST_CLM_NBR +"Claim Rev Nbr,Hic Number,Service Date,Submission Date,ENC Type,Status,CMS File Id,Original File Id,Receiver Id," +				
				"Error Segment,Error Code,Error Source,Error Group,Claim Line Seq Nbr,Error Description";
	*/
	
	//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
	//SSNRI 2017 : start
	/*private static final String ENCOUNTER_HEADER_NAMES ="Source,Extract Date,Submitter Id,Date Type,Search From,Search To,Search Claim Type,Search Claim Nbr," + Constants.VALUE_ADDED_NTWK_TRACE_NBR + "Search Hic Number,Search Status,Search Error Source,Search Error Group,Search Error Code," +
					"Claim Ref Nbr,"+ Constants.CUST_CLM_NBR +"Claim Rev Nbr,"+ Constants.PAT_CTRL_NBR +"Hic Number,Service Date,Submission Date,ENC Type,Status,CMS File Id,Original File Id,Receiver Id," +				
					"Error Segment,Error Code,Error Source,Error Group,Claim Line Seq Nbr,Error Description";*/
	
	
	private static final String ENCOUNTER_HEADER_NAMES ="Source,Extract Date,Submitter Id,Date Type,Search From,Search To,Search Claim Type,Search Claim Nbr," + Constants.VALUE_ADDED_NTWK_TRACE_NBR + "Search HICN, Search Medicare ID,Search Status,Search Error Source,Search Error Group,Search Error Code," +
			"Claim Ref Nbr,"+ Constants.CUST_CLM_NBR +"Claim Rev Nbr,"+ Constants.PAT_CTRL_NBR +"HICN, Medicare ID,Service Date,Submission Date,ENC Type,Status,CMS ICN,CMS File Id,Original File Id,Receiver Id," +//IFOX-00415108 - Add CMS ICN to the export
			"Group or Policy Number, Contract Id," + //IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export
			"Error Segment,Error Code,Error Source,Error Group,Claim Line Seq Nbr,Error Description, MAO004 Status, Allowed/Disallowed";	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
	//SSNRI 2017 : end
	//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
		
	private static final String ENCOUNTER_LOG_HEADING 	= "Claim Ref Nbr,Claim Rev Nbr,Log Time,Entity Name,Field Name,Value Before,Value After,User Id";
	private static final String DASHBOARD_HEADING_I_P 	="Source,Extract Date,Submitter Id,Search From,Search To,Date Type,Service/Submission Date,Institutional Pending, Institutional Accepted, Institutional Rejected, Institutional Ignored,Totals, Professional Pending, Professional Accepted, Professional Rejected, Professional Ignored,Totals";
	private static final String DASHBOARD_HEADING_DME 	="Source,Extract Date,Submitter Id,Search From,Search To,Date Type,Service/Submission Date,DME Pending,DME Accepted,DME Rejected,DME Ignored,Totals";
	private static final String REJECTDASHBOARD_HEADING_I_P ="Source,Extract Date,Submitter Id,Search From,Search To,Date Type,Service/Submission Date,Institutional CCR,Institutional Rejected,Totals,Professional CCR,Professional Rejected,Totals";
	private static final String REJECTDASHBOARD_HEADING_DME ="Source,Extract Date,Submitter Id,Search From,Search To,Date Type,Service/Submission Date,DME CCR,DME Rejected,Totals";
	private static final String ERRORDASHBOARD_HEADING 	="Source,Extract Date,Submitter Id,Claim Type,Search From,Search To,Error Source,Error Group,Error Code,Date Type,Service/Submission Date,Source,Group,Reject Code,Reject Description,Error Total,Claim Total,Type";
	
	private static final int I_RAPS_CLAIMS_DASHBOARD = 1;
	private static final int I_RAPS_DASHBOARD = 2;
	private static final int I_RAPS_STATISTIC = 3;

	private static final String LINE_SEPARATOR = System.getProperty("line.separator");
	
	public CsvService(String dbId){
		this.dbId = dbId;
		//serviceHelper = new ServiceHelper();
	}
	
	public CsvService(){
		
		//serviceHelper = new ServiceHelper();
	}
	
	/**
	 * format currency values to show in csv
	 * removes commas in currency value and replace $0.00 or 0 with null space if flag is true
	 * @author hemant
	 * @param value
	 * @param flag
	 * @return
	 */
	private String formatCurrencyValue(String value, boolean flag) {
		logger.info(LoggerConstants.methodStartLevel());
		if(value == null){
			return value;
		}else if ( flag && ("$0.00".equals(value) || "0".equals(value))) {//if flag is true and value is 0 than replace that with null string
			logger.info(LoggerConstants.methodEndLevel());
			return "";
		} else {
			value = value.replaceAll(",", "");
			
			if (value.startsWith("(")) { //show negative values as -$12712.02 insread of ($12,712.02)
				value = "-"+value.substring(1,value.length()-1);
			}
			logger.info(LoggerConstants.methodEndLevel());
			return value;
		}
	}
	
	/**
	 * For 'Payment Dashboard' or 'Beneficiary Payment Dashboard' export
	 * @author hemant
	 * @param filterVO
	 * @param planMap
	 * @param planName
	 * @param pageStatus
	 * @param menuName
	 * @return
	 */
	public String createPaymentDashBoard(FilterVO filterVO, Map planMap, String planName, List pageStatus, String menuName) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		String dateType = null;
		String searchHicNbr = "";

		String searchPlanId = "ALL";
		String searchDateType = "E";
		String searchStartDate = Constants.BEGIN_OF_DATE;
		String searchEndDate = Constants.END_OF_DATE;
		
		String fileName = getCvsFileName();
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		
		FileOutputStream stream = null;
		
		try {
			stream = new FileOutputStream(new File(fileName));
			
			// get search criteria from filterVO
			if(filterVO != null){
				dateType = filterVO.getDateType();
				if(Constants.BENEFICIARY_MENU.equals(menuName)){
					searchHicNbr = filterVO.getHicNumber();
				}
				if(filterVO.getDateType() != null)
					searchDateType = filterVO.getDateType();
				if(filterVO.getPlanName() != null)
					searchPlanId = filterVO.getPlanName();
				if(filterVO.getStartDate() != null)
					searchStartDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getStartDate(),true);
				if(filterVO.getEndDate() != null)
					searchEndDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getEndDate(),false);
				
			}
			
			// drawing Payment deshboard Heading.
			if(Constants.BENEFICIARY_MENU.equals(menuName))
				stream.write((BENEFICIARY_PAYMENT_DESHBOARD_HEADING+LINE_SEPARATOR).getBytes());
			else
				stream.write((PAYMENT_DESHBOARD_HEADING + LINE_SEPARATOR).getBytes());
			
			PaymentService paymentService = new PaymentService(this.dbId);
			//get payment dashboard data and write CSV rows for it
			PaymentDashBoardVO[] paymentDeshBoardVOArray = paymentService.getPaymentDashBoard(filterVO, planMap, "plan", pageStatus, menuName);
			PaymentDashBoardVO[] yearVOArray = null;
			PaymentDashBoardVO[] monthVOArray = null;
			String rollUpId = null;
			String rollUpName = null;
			String year = null;
			
			if(paymentDeshBoardVOArray != null){
				for(int i=0; i < paymentDeshBoardVOArray.length; i++){
					if(paymentDeshBoardVOArray[i] != null){
						rollUpId = paymentDeshBoardVOArray[i].getRollupId();
						rollUpName = planMap != null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(rollUpId, planMap, false)) : "";
						yearVOArray = paymentDeshBoardVOArray[i].getPaymentDashBoardVOArray();
						if(yearVOArray != null){
							for(int j=0; j<yearVOArray.length; j++){
								if(yearVOArray[j] != null){
									year = yearVOArray[j].getRollupId();
									monthVOArray = yearVOArray[j].getPaymentDashBoardVOArray();
									if(monthVOArray != null) {
										for(int k=0; k < monthVOArray.length;k++){
											if(monthVOArray[k] != null){
												String monthName = monthVOArray[k].getRollupId();
												int month = Integer.parseInt((DateUtil.convetMonthToNumericValue(monthName)));
												String date = month+"/1/"+year;
												
												String cmsPaidPartC = StringUtil.nonNullTrim(monthVOArray[k].getCmsPaidPartC());
												String planExpPartC = StringUtil.nonNullTrim(monthVOArray[k].getPlanExpectedPartC());
												String diffPartC = StringUtil.nonNullTrim(monthVOArray[k].getDiffrencePartC());
												
												cmsPaidPartC = formatCurrencyValue(cmsPaidPartC, false);
												planExpPartC = formatCurrencyValue(planExpPartC, false);
												diffPartC = formatCurrencyValue(diffPartC, false);
												
												String cmsPaidPartD = StringUtil.nonNullTrim(monthVOArray[k].getCmsPaidPartD());
												String planExpPartD = StringUtil.nonNullTrim(monthVOArray[k].getPlanExpectedPartD());
												String diffPartD  = StringUtil.nonNullTrim(monthVOArray[k].getDiffrencePartD());
												
												cmsPaidPartD = formatCurrencyValue(cmsPaidPartD,false);
												planExpPartD = formatCurrencyValue(planExpPartD,false);
												diffPartD = formatCurrencyValue(diffPartD,false);
												
												StringBuffer dashBoardRow = new StringBuffer();
												if(Constants.BENEFICIARY_MENU.equals(menuName)){
													dashBoardRow.append(Constants.BENEFICIARY_PYMT_DASHBOARD_SOURCE_VALUE).append(",");
												} else {
													dashBoardRow.append(Constants.PLAN_PYMT_DASHBOARD_SOURCE_VALUE).append(",");
												}
												
												dashBoardRow.append(extractDate).append(",")
												.append(rollUpId).append(",\"").append(rollUpName).append("\",");
										
												dashBoardRow.append(date)
												.append(",").append(dateType).append(",").append(cmsPaidPartC)
												.append(",").append(planExpPartC).append(",").append(diffPartC)
												.append(",").append(cmsPaidPartD).append(",").append(planExpPartD)
												.append(",").append(diffPartD)
												.append(",").append(searchPlanId);
												if(Constants.BENEFICIARY_MENU.equals(menuName))
													dashBoardRow.append(",").append(searchHicNbr);
												dashBoardRow.append(",").append(searchStartDate).append(",").append(searchEndDate)
												.append(",").append(searchDateType);
												stream.write((dashBoardRow+LINE_SEPARATOR).getBytes());
											}
										} // end of Month array loop
									}
								}
							} // end of Year array loop
						}
					}	
				} // end of plan array loop
			}
			
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPaymentDashBoard method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPaymentDashBoard method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}	
	
	/**
	 * @return
	 */
	private String getCvsFileName() {
		logger.info(LoggerConstants.methodStartLevel());
		String csvDr = MssProperties.getExportLocation();
		logger.info(LoggerConstants.methodEndLevel());
		return csvDr + File.separator + System.currentTimeMillis() + ".csv";
	}

	/**
	 * For 'Discrepancy Dashboard' or 'Beneficiary Discrepancy Dashboard' export
	 * @author hemant
	 * @param filterVO
	 * @param planMap
	 * @param planName
	 * @param pageStatus
	 * @param menuName
	 * @return
	 * @throws ApplicationException
	 */
	public String createDiscrepancyDashBoard(FilterVO filterVO, Map planMap, String planName, List pageStatus, String menuName) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		String hicNbr = null;
		String dateType=null;
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;;
		
		
		String searchStartDate = Constants.BEGIN_OF_DATE;
		String searchEndDate = Constants.END_OF_DATE;
		String searchPlanId = "ALL";
		String searchDateType = "E";
		try {
			stream = new FileOutputStream(new File(fileName));
			if(filterVO!=null){
				dateType=filterVO.getDateType();
				if(Constants.BENEFICIARY_MENU.equals(menuName)){
					hicNbr = filterVO.getHicNumber();
				}
				if(filterVO.getDateType()!=null)
					searchDateType = filterVO.getDateType();
				if(filterVO.getPlanName()!=null)
					searchPlanId = filterVO.getPlanName();
				if(filterVO.getStartDate()!=null)
					searchStartDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getStartDate(),true);
				if(filterVO.getEndDate()!=null)
					searchEndDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getEndDate(),false);
				
			}
			
			// drawing Discrepancy deshboard Heading. 
			if(Constants.BENEFICIARY_MENU.equals(menuName))
				stream.write((BENEFICIARY_DISCREPANCY_DESHBOARD_HEADING+LINE_SEPARATOR).getBytes());
			else
				stream.write((DISCREPANCY_DESHBOARD_HEADING+LINE_SEPARATOR).getBytes());
			
			String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
			
			//get data for Discrepancy Dashboard and write CSV rows
			DiscrepancyService discService = new DiscrepancyService(this.dbId);
			DiscrepancyDashBoardVO[] discDeshBoardVOArray = discService.getDiscrepancyDashBoard(filterVO, planMap, "plan", pageStatus, menuName);
			if(discDeshBoardVOArray!=null){
				for(int i=0; i<discDeshBoardVOArray.length; i++){
					if(discDeshBoardVOArray[i] != null){
						String rollUpId = discDeshBoardVOArray[i].getRollupId();
						String rollUpName = planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(rollUpId, planMap, false)) : "";
						DiscrepancyDashBoardVO[] yearVOArray = discDeshBoardVOArray[i].getDiscrepancyDashBoardVOArray();
						if(yearVOArray!=null){
							for(int j=0;j<yearVOArray.length;j++){
								if(yearVOArray[j]!=null){
									String year = yearVOArray[j].getRollupId();
									DiscrepancyDashBoardVO[] monthVOArray = yearVOArray[j].getDiscrepancyDashBoardVOArray();
									if(monthVOArray!=null){
										// ROW PREFIX
										StringBuffer rowPrefix = new StringBuffer();
										if(Constants.BENEFICIARY_MENU.equals(menuName))
											rowPrefix.append(Constants.BENEFICIARY_DISC_DASHBOARD_SOURCE_VALUE).append(",");
										else
											rowPrefix.append(Constants.PLAN_DISC_DASHBOARD_SOURCE_VALUE).append(",");
										
										rowPrefix.append(extractDate).append(",").append(rollUpId).append(",\"")
										.append(rollUpName).append("\",");
										
										if(Constants.BENEFICIARY_MENU.equals(menuName)){
											rowPrefix.append(hicNbr).append(",");
										}
										
										for(int k=0; k<monthVOArray.length;k++){
											if(monthVOArray[k]!=null){
												String monthName = monthVOArray[k].getRollupId();
												int month= Integer.parseInt((DateUtil.convetMonthToNumericValue(monthName)));
												String date = month+"/1/"+year;
												
												String partCCount = monthVOArray[k].getCountPartC();
												String partCOpen = monthVOArray[k].getOpenPartC();
												String partCInProgress = monthVOArray[k].getInProgressPartC();
												String partCForceClosed = monthVOArray[k].getForceClosedPartC();
												String partCResolved = monthVOArray[k].getResolvedPartC();
												
												StringBuffer dashBoardRow = new StringBuffer();
												dashBoardRow.append(rowPrefix)
												.append(date).append(",").append(dateType).append(",")
												.append(formatCurrencyValue(partCCount,true)).append(",")
												.append(formatCurrencyValue(partCOpen,true)).append(",")
												.append(formatCurrencyValue(partCInProgress,true)).append(",")
												.append(formatCurrencyValue(partCForceClosed,true)).append(",")
												.append(formatCurrencyValue(partCResolved,true)).append(",");
												
												String partDCount = monthVOArray[k].getCountPartD();
												String partDOpen = monthVOArray[k].getOpenPartD();
												String partDInProgress = monthVOArray[k].getInProgressPartD();
												String partDForceClosed = monthVOArray[k].getForceClosedPartD();
												String partDResolved = monthVOArray[k].getResolvedPartD();
												
												dashBoardRow.append(formatCurrencyValue(partDCount,true)).append(",")
												.append(formatCurrencyValue(partDOpen,true)).append(",")
												.append(formatCurrencyValue(partDInProgress,true)).append(",")
												.append(formatCurrencyValue(partDForceClosed,true)).append(",")
												.append(formatCurrencyValue(partDResolved,true))
												.append(",").append(searchPlanId)
												.append(",").append(searchStartDate).append(",").append(searchEndDate)
												.append(",").append(searchDateType);
												stream.write((dashBoardRow+LINE_SEPARATOR).getBytes());
											}
										} // end of Month array loop
									}
								}
							} // end of Year array Loop
						}
					}
				} // end of Plan array Loop
			}
			//stream.close();
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createDiscrepancyDashBoard method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createDiscrepancyDashBoard method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	
	/**
	 * this method is to export of Troop Dashboard
	 * @author hemant
	 * @param filterVO
	 * @param planMap
	 * @param planName
	 * @param pageStatus
	 * @param menuName
	 * @return
	 * @throws ApplicationException
	 */
	public String createTroopDashBoard(FilterVO filterVO, Map planMap, String planName, List pageStatus, String menuName) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		String dateType = null;
		String hicNbr = null;
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;;
		
		
		String searchStartDate = Constants.BEGIN_OF_DATE;
		String searchEndDate = Constants.END_OF_DATE;
		String searchPlanId = "ALL";
		try {
			stream = new FileOutputStream(new File(fileName));
			if(filterVO!=null){
				dateType=filterVO.getDateType();
				hicNbr = StringUtil.nonNullTrim(filterVO.getHicNumber());
				if(filterVO.getPlanName()!=null)
					searchPlanId = filterVO.getPlanName();
				if(filterVO.getStartDate()!=null)
					searchStartDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getStartDate(),true);
				if(filterVO.getEndDate()!=null)
					searchEndDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getEndDate(),false);
			}
			
			// drawing Troop deshboard Heading.
			stream.write((TROOP_DESHBOARD_HEADING+LINE_SEPARATOR).getBytes());
			
			//get data for 'Troop Dashboard' and write csv rows for it
			PdeTroopService pdeTroopService = new PdeTroopService(this.dbId);
			TroopDashBoardVO[] troopDashboardVOArray = null;
			TroopDashBoardVOList troopDashboardVOList = pdeTroopService.getTroopDashBoard(filterVO,planMap,"plan", pageStatus);
			if(troopDashboardVOList!=null)
				troopDashboardVOArray = troopDashboardVOList.getTroopDashBoardVOs();
			
			if(troopDashboardVOArray != null){
				for(int i=0; i<troopDashboardVOArray.length; i++){
					if(troopDashboardVOArray[i] != null){
						String rollUpId = troopDashboardVOArray[i].getRollupId();
						String rollUpName = planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(rollUpId, planMap, false)) : "";
						TroopDashBoardVO[] yearVOArray = troopDashboardVOArray[i].getTroopDashBoardVOArr();
						if(yearVOArray!=null){
							for(int j=0; j<yearVOArray.length; j++){
								if(yearVOArray[j] != null){
									String year = yearVOArray[j].getRollupId();
									TroopDashBoardVO[] monthVOArray = yearVOArray[j].getTroopDashBoardVOArr();
									if(monthVOArray != null){
										for(int k=0; k<monthVOArray.length;k++){
											if(monthVOArray[k]!=null){
												String monthName = monthVOArray[k].getRollupId();
												int month= Integer.parseInt((DateUtil.convetMonthToNumericValue(monthName)));
												String date = month+"/1/"+year;
												
												StringBuffer dashBoardRow = new StringBuffer(Constants.TROOP_DASHBOARD_SOURCE_VALUE);
												dashBoardRow.append(",").append(extractDate)
												.append(",").append(rollUpId)
												.append(",\"").append(rollUpName)
												.append("\",").append(hicNbr)
												.append(",").append(date)
												.append(",").append(dateType)
												.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(monthVOArray[k].getTotalTroop()),false))
												.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(monthVOArray[k].getPatientPayAmt()),false))
												.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(monthVOArray[k].getOtherTroopAmt()),false))
												.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(monthVOArray[k].getLICSAmount()),false))
												.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(monthVOArray[k].getCGAPAmount()),false))		//Added for CGAP Screen IFOX-00432723
												.append(",").append(searchPlanId)
												.append(",").append(hicNbr)
												.append(",").append(searchStartDate)
												.append(",").append(searchEndDate);
												stream.write((dashBoardRow+LINE_SEPARATOR).getBytes());
											}
										} // end of Month array loop
									}
								}
							} // end of Year array loop
						}
					}	
				} // end of plan array loop
			}
			
			//stream.close();
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createTroopDashBoard method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createTroopDashBoard method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	
	/**
	 * This method is to export of PDE Dashboard
	 * @author hemant
	 * @param filterVO
	 * @param planMap
	 * @param planName
	 * @param pageStatus
	 * @param menuName
	 * @return
	 * @throws ApplicationException
	 */
	public String createPdeDashBoard(FilterVO filterVO, Map planMap, String planName, List pageStatus, String menuName) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		String dateType = "S";
		String hicNbr = null;
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;
		
		
		String searchStartDate = Constants.BEGIN_OF_DATE;
		String searchEndDate = Constants.END_OF_DATE;
		String searchPlanId = "ALL";
		try {
			stream = new FileOutputStream(new File(fileName));
			if(filterVO!=null){
				hicNbr = StringUtil.nonNullTrim(filterVO.getHicNumber());
				if(filterVO.getPlanName()!=null)
					searchPlanId = filterVO.getPlanName();
				if(filterVO.getStartDate()!=null)
					searchStartDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getStartDate(),true);
				if(filterVO.getEndDate()!=null)
					searchEndDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getEndDate(),false);
			}
			
			// drawing PDE deshboard Heading.
			stream.write((PDE_DESHBOARD_HEADING+LINE_SEPARATOR).getBytes());
			
			//get data for 'PDE Dashboard' and write csv rows for it
			PdeTroopService pdeTroopService = new PdeTroopService(this.dbId);
			
			PdeDashboardVO[] pdeDashboardVOArray = pdeTroopService.getPdeDashBoard(filterVO,planMap,"plan", pageStatus);
			
			if(pdeDashboardVOArray != null){
				for(int i=0; i<pdeDashboardVOArray.length; i++){
					if(pdeDashboardVOArray[i] != null){
						String rollUpId = pdeDashboardVOArray[i].getRollupId();
						String rollUpName = planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(rollUpId, planMap, false)) : "";
						PdeDashboardVO[] yearVOArray = pdeDashboardVOArray[i].getPdeDashBoardVOArray();
						if(yearVOArray!=null){
							for(int j=0; j<yearVOArray.length; j++){
								if(yearVOArray[j] != null){
									String year = yearVOArray[j].getRollupId();
									PdeDashboardVO[] monthVOArray = yearVOArray[j].getPdeDashBoardVOArray();
									if(monthVOArray != null){
										for(int k=0; k<monthVOArray.length;k++){
											if(monthVOArray[k]!=null){
												String monthName = monthVOArray[k].getRollupId();
												int month= Integer.parseInt((DateUtil.convetMonthToNumericValue(monthName)));
												String date = month+"/1/"+year;
												
												StringBuffer dashBoardRow = new StringBuffer(Constants.PDE_DASHBOARD_SOURCE_VALUE);
												dashBoardRow.append(",").append(extractDate)
												.append(",").append(rollUpId)
												.append(",\"").append(rollUpName)
												.append("\",").append(hicNbr)
												.append(",").append(date)
												.append(",").append(dateType)
												.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(monthVOArray[k].getEventAccepted()),false))
												.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(monthVOArray[k].getEventRejected()),false))
												.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(monthVOArray[k].getEventTotal()),false))
												.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(monthVOArray[k].getOverridden()),false))
												.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(monthVOArray[k].getResubmitted()),false))
												.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(monthVOArray[k].getTotal()),false))
												.append(",").append(searchPlanId)
												.append(",").append(hicNbr)
												.append(",").append(searchStartDate)
												.append(",").append(searchEndDate);
												stream.write((dashBoardRow+LINE_SEPARATOR).getBytes());
											}
										} // end of Month array loop
									}
								}
							} // end of Year array loop
						}
					}	
				} // end of plan array loop
			}
			
			//stream.close();
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPdeDashBoard method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPdeDashBoard method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;	
	}
	
	/**
	 * This private method is called to create CSV of PDE event detail
	 * @author hemant
	 * @param filterVO
	 * @param planMap
	 * @param pageStatus
	 * @param uiContextRange
	 * @param recordCountMap
	 * @param pageName
	 * @param searchType
	 * @param discrpArrMap
	 * @param custName
	 * @return
	 * @throws ApplicationException
	 */
	public String createPdeEventDetail(FilterVO filterVO, Map planMap, List pageStatus, String uiContextRange, Map recordCountMap, String pageName, String searchType, Map discrpArrMap, String custName) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		String searchStatusCd = "ALL";
		String searchHicNbr = "";
		String searchPlanId = "ALL";
		String searchStartDate = Constants.BEGIN_OF_DATE;
		String searchEndDate = Constants.END_OF_DATE;
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		String planId = "";
		String planName = "";
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;;
		try {
			stream = new FileOutputStream(new File(fileName));
			if(filterVO!=null){
				searchHicNbr = StringUtil.nonNullTrim(filterVO.getHicNumber());
				if(filterVO.getPlanName()!=null)
					searchPlanId = filterVO.getPlanName();
				if(filterVO.getPdeStatus()!=null)
					searchStatusCd = StringUtil.nonNullTrim((String)(Constants.PDE_STATUS_MAP.get(filterVO.getPdeStatus())));
				planId = filterVO.getPlanName();
				if(filterVO.getStartDate()!=null)
					searchStartDate = filterVO.getStartDate();
				if(filterVO.getEndDate()!=null)
					searchEndDate = filterVO.getEndDate();
			}
			planName = planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(planId, planMap, false)) : "";
			
			//write heading row
			stream.write((PDE_DETAIL_HEADING+LINE_SEPARATOR).getBytes());
			
			String move="current";
			
			if(Constants.CONSTANTS_ALL.equals(uiContextRange) && recordCountMap!=null){
				CodeCacheService codeCache=new CodeCacheService();
				Integer maxRecordCount=codeCache.getMaxRecordCount();
				recordCountMap.put(Constants.SESSION_MAX_RECORD_COUNT,maxRecordCount);
				recordCountMap.put(Constants.UI_CONTEXT_RANGE, Constants.CONSTANTS_ALL);
				move = "first";
			}		
			
			//get data for CSV of PDE event detail and write CSV rows
			
			PdeTroopService pdeTroopService = new PdeTroopService(this.dbId);
			PdeEventDetailVoList pdeDetailPageObj = pdeTroopService.getPdeEventDetail(filterVO, recordCountMap, searchType,move, planMap, custName);		
			
			if(recordCountMap!=null){
				recordCountMap.put(Constants.SESSION_MAX_RECORD_COUNT,new Integer(10));
				recordCountMap.remove(Constants.UI_CONTEXT_RANGE);
			}
			
			if(pdeDetailPageObj!=null){
				StringBuffer rowPrefix = null;
				rowPrefix = new StringBuffer(Constants.PDE_DETAIL_SOURCE_VALUE);
				
				rowPrefix.append(",").append(extractDate)
				.append(",").append(planId)
				.append(",\"").append(planName).append("\"");
				
				
				StringBuffer rowSuffix= new StringBuffer();
				rowSuffix.append(",").append(searchPlanId)
				.append(",").append(searchStartDate)
				.append(",").append(searchEndDate)
				.append(",").append(searchStatusCd)
				.append(",").append(searchHicNbr);
				
				PdeEventDetailVO[]	pdeListObjArr = (PdeEventDetailVO[])pdeDetailPageObj.getPdeEventDetailVOs();
				if(pdeListObjArr!=null){
					for(int i=0;i<pdeListObjArr.length;i++){
						if(pdeListObjArr[i]!=null){
							String serviceDate = pdeListObjArr[i].getServiceDate();
							if(serviceDate!=null && serviceDate.length()== 8){
								serviceDate = serviceDate.substring(0,4)+"/"+serviceDate.substring(4,6)+"/"+serviceDate.substring(6);
							}
							String lastUpdateDate = pdeListObjArr[i].getShowLastUpdtDate();
							if(lastUpdateDate!=null){
								lastUpdateDate = lastUpdateDate.substring(0,4)+"/"+lastUpdateDate.substring(5,7)+"/"+lastUpdateDate.substring(8);
							}
							StringBuffer pdeDetailListRow = new StringBuffer();						
							pdeDetailListRow.append(rowPrefix)			
							.append(",").append(StringUtil.nonNullTrim(pdeListObjArr[i].getHicNumber()))
							.append(",").append(StringUtil.nonNullTrim(serviceDate))
							.append(",").append(StringUtil.nonNullTrim(pdeListObjArr[i].getDetRecId()))
							.append(",").append(StringUtil.nonNullTrim(pdeListObjArr[i].getReferenceNumber()));
							String productId = formatCurrencyValue(StringUtil.nonNullTrim(pdeListObjArr[i].getProductSvcId()),false);
							pdeDetailListRow.append(",").append(StringUtil.isNullOrEmpty(productId)?"":"=\""+productId+"\"")
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(lastUpdateDate),false))
							.append(rowSuffix);
							stream.write((pdeDetailListRow+LINE_SEPARATOR).getBytes());
							pdeListObjArr[i] = null;
						}
					}
				}
			}
			
			
			//stream.close();
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPdeEventDetail method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPdeEventDetail method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	
	/**
	 * This private method is called to create CSV of Troop detail
	 * @author hemant
	 * @param filterVO
	 * @param planMap
	 * @param pageStatus
	 * @param uiContextRange
	 * @param recordCountMap
	 * @param pageName
	 * @param searchType
	 * @param discrpArrMap
	 * @param custName
	 * @return
	 * @throws ApplicationException
	 */
	public String createTroopDetail(FilterVO filterVO, Map planMap, List pageStatus, String uiContextRange, Map recordCountMap, String pageName, String searchType, Map discrpArrMap, String custName) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		String searchHicNbr = "";
		String searchPlanId = "ALL";
		String searchDateType = "E";
		String searchStartDate = Constants.BEGIN_OF_DATE;
		String searchEndDate = Constants.END_OF_DATE;
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		String planId = "";
		String planName = "";
		
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;;
		try {
			stream = new FileOutputStream(new File(fileName));
			
			if(filterVO!=null){
				searchHicNbr = StringUtil.nonNullTrim(filterVO.getHicNumber());
				planId = filterVO.getPlanName();
				if(filterVO.getPlanName()!=null)
					searchPlanId = filterVO.getPlanName();
				if(filterVO.getStartDate()!=null)
					searchStartDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getStartDate(),true);
				if(filterVO.getEndDate()!=null)
					searchEndDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getEndDate(),false);
			}
			planName = planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(planId, planMap, false)) : "";
			
			//write heading row
			stream.write((TROOP_DETAIL_HEADING+LINE_SEPARATOR).getBytes());
			String move="current";
			
			if(Constants.CONSTANTS_ALL.equals(uiContextRange) && recordCountMap!=null){
				CodeCacheService codeCache=new CodeCacheService();
				Integer maxRecordCount=codeCache.getMaxRecordCount();
				recordCountMap.put(Constants.SESSION_MAX_RECORD_COUNT,maxRecordCount);
				recordCountMap.put(Constants.UI_CONTEXT_RANGE,Constants.CONSTANTS_ALL);
				move = "first";
			}		
			
			//get data for CSV of Troop Detail and write CSV rows
			
			PdeTroopService pdeTroopService = new PdeTroopService(this.dbId);
			TroopDetailVOList troopDetailPageObj = pdeTroopService.getTroopDetail(filterVO,recordCountMap,move,planMap,searchType,discrpArrMap, custName);
			
			if(recordCountMap!=null){
				recordCountMap.put(Constants.SESSION_MAX_RECORD_COUNT,new Integer(10));
				recordCountMap.remove(Constants.UI_CONTEXT_RANGE);
			}
			
			if(troopDetailPageObj!=null){
				StringBuffer rowPrefix = null;
				rowPrefix = new StringBuffer(Constants.TROOP_DETAIL_SOURCE_VALUE);
				
				rowPrefix.append(",").append(extractDate)
				.append(",").append(planId)
				.append(",\"").append(planName).append("\"");
				
				
				StringBuffer rowSuffix= new StringBuffer();
				rowSuffix.append(",").append(searchPlanId)
				.append(",").append(searchStartDate)
				.append(",").append(searchEndDate)
				.append(",").append(searchDateType)
				.append(",").append(searchHicNbr);
				
				TroopDetailVO[]	troopListObjArr = troopDetailPageObj.getTroopDetailVO();
				if(troopListObjArr!=null){
					for(int i=0;i<troopListObjArr.length;i++){
						if(troopListObjArr[i]!=null){
							StringBuffer troopDetailListRow = new StringBuffer();						
							troopDetailListRow.append(rowPrefix)			
							.append(",").append(DateUtil.getFirstOrLastDayOfMonth(StringUtil.nonNullTrim(troopListObjArr[i].getPymtEffDate()),true))
							.append(",").append(DateUtil.getFirstOrLastDayOfMonth(StringUtil.nonNullTrim(troopListObjArr[i].getPymtApplyDate()),true))
							.append(",").append(StringUtil.nonNullTrim(troopListObjArr[i].getHicNbr()))
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(troopListObjArr[i].getTotalTroop()),false))
							.append(",").append(StringUtil.nonNullTrim(troopListObjArr[i].getAdjReasonCd()))
							.append(",").append(StringUtil.nonNullTrim(troopListObjArr[i].getAdjDesc()))
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(troopListObjArr[i].getPatientPayAmt()),false))
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(troopListObjArr[i].getOtherTroopAmt()),false))
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(troopListObjArr[i].getLICSAmount()),false))
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(troopListObjArr[i].getCGAPAmount()),false))	//Added for CGAP Screen IFOX-00432723
							.append(rowSuffix);
							stream.write((troopDetailListRow+LINE_SEPARATOR).getBytes());
						}
						troopListObjArr[i] = null;
					}
				}
			}
			
			//stream.close();
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createTroopDetail method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createTroopDetail method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	/**
	 * For 'Payment Summary' or 'Plan Show Payments' export
	 * @author hemant
	 * @param filterVO
	 * @param planMap
	 * @param searchType
	 * @param planName
	 * @param pageStatus
	 * @param uiContextRange
	 * @return
	 * @throws ApplicationException
	 */
	public String createPaymentSummary(FilterVO filterVO, Map planMap, String searchType, String planId, List pageStatus, String uiContextRange) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String dateType = "";
		String startDate="";
		String endDate="";
		String searchStartDate = Constants.BEGIN_OF_DATE;
		String searchEndDate = Constants.END_OF_DATE;
		String searchPlanId = "ALL";
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		String planName= planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(planId, planMap, false)) : "";
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;;
		try {
			stream = new FileOutputStream(new File(fileName));
			if(filterVO!=null){
				dateType = filterVO.getDateType();
				
				if(filterVO.getPlanName()!=null)
					searchPlanId = filterVO.getPlanName();
				if(filterVO.getStartDate()!=null)
					searchStartDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getStartDate(),true);
				if(filterVO.getEndDate()!=null)
					searchEndDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getEndDate(),false);
			}
			
			//write heading row
			stream.write((PAYMENT_SUMMARY_HEADING+LINE_SEPARATOR).getBytes());
			PaymentService planService = new PaymentService(this.dbId);
			
			PaymentSummaryVOList pymtSummaryVOList = planService.getPaymentSummary(filterVO,searchType,planMap);
			
			if(pymtSummaryVOList!=null){
				String startEndDates[] = pymtSummaryVOList.getLatestDateArray();
				if(startEndDates != null && startEndDates.length == 2 ){
					startDate = DateUtil.getFirstOrLastDayOfMonth( StringUtil.nonNullTrim(startEndDates[0]),true);
					endDate = DateUtil.getFirstOrLastDayOfMonth( StringUtil.nonNullTrim(startEndDates[1]),false);
				}
				
				//write csv rows for part C
				if(! Constants.PARTD.equals(filterVO.getPartName())){
					//write csv rows for part A
					PaymentSummaryVO[] pymtSmmyPartAVoArr = pymtSummaryVOList.getPaymentByPartAVOList();
					if(pymtSmmyPartAVoArr!=null){
						String[]  columnStr = {"A,P,CAP,Part C: Part A Payments", "A,S,CAS,Part C: Part A Suspense"};
						StringBuffer partADataRow =null;
						for(int i=0;i<2;i++){
							partADataRow = new StringBuffer(Constants.PLAN_PYMT_SUMMARY_SOURCE_VALUE)						
							.append(",").append(extractDate)
							.append(",").append(planId).append(",\"").append(planName).append("\",").append(startDate)
							.append(",").append(endDate).append(",").append(dateType).append(",").append(columnStr[i])
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(pymtSmmyPartAVoArr[i+1].getCmsPaid()),false));
							
							if(i==0){
								partADataRow.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(pymtSmmyPartAVoArr[i+1].getPlanExpected()),false));	
							}else{
								partADataRow.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(pymtSmmyPartAVoArr[i+1].getPlanExpected()),true));
							}
							
							partADataRow.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(pymtSmmyPartAVoArr[i+1].getDifference()),false))
							.append(",").append(searchPlanId)
							.append(",").append(searchStartDate).append(",").append(searchEndDate)
							.append(",").append(dateType);
							stream.write((partADataRow+LINE_SEPARATOR).getBytes());
						}
					}
					//write csv row for part B
					PaymentSummaryVO[] pymtSmmyPartBVoArr = pymtSummaryVOList.getPaymentByPartBVOList();
					if(pymtSmmyPartBVoArr!=null){
						String[]  columnStr = {"B,P,CBP,Part C: Part B Payments", "B,S,CBS,Part C: Part B Suspense"};
						StringBuffer partBDataRow =null;
						for(int i=0;i<2;i++){
							partBDataRow = new StringBuffer(Constants.PLAN_PYMT_SUMMARY_SOURCE_VALUE)						
							.append(",").append(extractDate)
							.append(",").append(planId).append(",\"").append(planName).append("\",").append(startDate)
							.append(",").append(endDate).append(",").append(dateType).append(",").append(columnStr[i])
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(pymtSmmyPartBVoArr[i+1].getCmsPaid()),false));
							if(i==0){
								partBDataRow.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(pymtSmmyPartBVoArr[i+1].getPlanExpected()),false));	
							}else{
								partBDataRow.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(pymtSmmyPartBVoArr[i+1].getPlanExpected()),true));
							}
							
							partBDataRow.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(pymtSmmyPartBVoArr[i+1].getDifference()),false))
							.append(",").append(searchPlanId)
							.append(",").append(searchStartDate).append(",").append(searchEndDate)
							.append(",").append(dateType);
							stream.write((partBDataRow+LINE_SEPARATOR).getBytes());
						}
					}
					//Change for Part C UI - Start
					//write csv row for part C Premium
					PaymentSummaryVO[] pymtSmmyPartCVoArr = pymtSummaryVOList.getPaymentByPartCVOList();
					if(pymtSmmyPartCVoArr!=null){
						String[]  columnStr = {"C,P,CPREMP,Part C: Premium Payments", "C,S,CPREMS,Part C: Premium Suspense"};
						StringBuffer partCDataRow =null;
						for(int i=0;i<2;i++){
							partCDataRow = new StringBuffer(Constants.PLAN_PYMT_SUMMARY_SOURCE_VALUE)						
							.append(",").append(extractDate)
							.append(",").append(planId).append(",\"").append(planName).append("\",").append(startDate)
							.append(",").append(endDate).append(",").append(dateType).append(",").append(columnStr[i])
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(pymtSmmyPartCVoArr[i+1].getCmsPaid()),false));
							if(i==0){
								partCDataRow.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(pymtSmmyPartCVoArr[i+1].getPlanExpected()),false));	
							}else{
								partCDataRow.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(pymtSmmyPartCVoArr[i+1].getPlanExpected()),true));
							}
							
							partCDataRow.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(pymtSmmyPartCVoArr[i+1].getDifference()),false))
							.append(",").append(searchPlanId)
							.append(",").append(searchStartDate).append(",").append(searchEndDate)
							.append(",").append(dateType);
							stream.write((partCDataRow+LINE_SEPARATOR).getBytes());
						}
					}					
					//Change for Part C UI - End
					//write csv row for workage
					WorkAgedSummaryVO workAgedSummaryVO = pymtSummaryVOList.getWorkAgedSummaryVO();
					String cmsPaid="$0.00";
					String planExpected = "$0.00";
					String difference =  "";
					if(workAgedSummaryVO != null){
						cmsPaid = formatCurrencyValue(StringUtil.nonNullTrim(workAgedSummaryVO.getCmsWorkAged()),false);
						planExpected = formatCurrencyValue(StringUtil.nonNullTrim(workAgedSummaryVO.getPlanWorkAged()),false);
						
						StringBuffer workAgedRow =new StringBuffer(Constants.PLAN_PYMT_SUMMARY_SOURCE_VALUE)
						.append(",").append(extractDate)
						.append(",").append(planId).append(",\"").append(planName).append("\",").append(startDate)
						.append(",").append(endDate).append(",").append(dateType).append(",").append("C").append(",")
						.append("W").append(",").append("WAG").append(",").append("Part C: Working Aged Adj")
						.append(",").append(cmsPaid).append(",")
						.append(planExpected).append(",").append(difference)
						.append(",").append(searchPlanId)
						.append(",").append(searchStartDate).append(",").append(searchEndDate)
						.append(",").append(dateType);
						stream.write((workAgedRow+LINE_SEPARATOR).getBytes());
					}
					
				}
				//write CSV rows for part d 			
				if(!Constants.PARTC.equals(filterVO.getPartName())){
					PaymentSummaryVO[] paymentSummaryPartDVOArr = pymtSummaryVOList.getPaymentByPartDVOList();
					
					if(paymentSummaryPartDVOArr!=null){
						StringBuffer partDDataRow =null;
						for(int i=0;i<paymentSummaryPartDVOArr.length;i++){
							partDDataRow = new StringBuffer();						
							partDDataRow.append(Constants.PLAN_PYMT_SUMMARY_SOURCE_VALUE).append(",").append(extractDate)
							.append(",").append(planId).append(",\"").append(planName).append("\",").append(startDate)
							.append(",").append(endDate).append(",").append(dateType).append(",").append("D,P").append(",")
							.append(StringUtil.nonNullTrim(paymentSummaryPartDVOArr[i].getPartName())).append(",").append(StringUtil.nonNullTrim(paymentSummaryPartDVOArr[i].getDescription()))
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(paymentSummaryPartDVOArr[i].getCmsPaid()),false))
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(paymentSummaryPartDVOArr[i].getPlanExpected()),false))
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(paymentSummaryPartDVOArr[i].getDifference()),false))
							.append(",").append(searchPlanId)
							.append(",").append(searchStartDate).append(",").append(searchEndDate)
							.append(",").append(dateType);
							stream.write((partDDataRow+LINE_SEPARATOR).getBytes());
						}
					}
				}
			}
			//stream.close();
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPaymentSummary method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPaymentSummary method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	
	/** 
	 * creates CSV file for planPaymentService
	 * @author hemant
	 * @param filterVO
	 * @param map
	 * @param searchType
	 * @param planName
	 * @param pageStatus
	 * @param adjReasonMap
	 * @return
	 */
	public String createDiscrepancySummary(FilterVO filterVO, Map planMap, String searchType, String planId, List pageStatus, String uiContextRange, Map adjReasonMap)throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		String dateType=null;
		String startDate="1/1/97";
		String endDate="1/1/97";
		String searchPlanId = "ALL";
		String searchStartDate = Constants.BEGIN_OF_DATE;
		String searchEndDate = Constants.END_OF_DATE;
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		
		String planName= planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(planId, planMap, false)) : "";
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;;
		
		String searchPartInd = "B";
		String searchStatusCd = "Not Closed";
		try {
			stream = new FileOutputStream(new File(fileName));
			if(filterVO!=null){
				dateType = filterVO.getDateType();
				if(filterVO.getPlanName()!=null)
					searchPlanId = filterVO.getPlanName();
				
				if(Constants.BOTH_PARTS.equals(filterVO.getPartName()))
					searchPartInd = "B";
				else if(Constants.PARTC.equals(filterVO.getPartName()))
					searchPartInd = "C";
				else if(Constants.PARTD.equals(filterVO.getPartName()))
					searchPartInd = "D";
				
				if(filterVO.getDiscrepancyIndicator()!= null)
					searchStatusCd = (String)Constants.DISCREPANCY_SUMMARY_STATUS_MAP.get(filterVO.getDiscrepancyIndicator());
				
				if(filterVO.getStartDate()!= null)
					searchStartDate=DateUtil.getFirstOrLastDayOfMonth(filterVO.getStartDate(),true);
				
				if(filterVO.getEndDate() != null)
					searchEndDate=DateUtil.getFirstOrLastDayOfMonth(filterVO.getEndDate(),false);
			}
			//write heading row
			stream.write((DISCREPANCY_SUMMARY_HEADING+LINE_SEPARATOR).getBytes());
			DiscrepancyService discrepancyService = new DiscrepancyService(this.dbId);
			
			//write CSV rows for part C
			if(filterVO.getPartName() == null || Constants.BOTH_PARTS.equals(filterVO.getPartName())||Constants.PARTC.equals(filterVO.getPartName())){
				DiscrepancySummaryVOList discrepancySummaryVOList = discrepancyService.getDiscrepancySummary(filterVO,searchType,Constants.PARTC ,planMap,adjReasonMap);
				if(discrepancySummaryVOList!=null){
					String startEndDates[] = discrepancySummaryVOList.getLatestDateArray();
					if(startEndDates != null && startEndDates.length == 2 ){
						startDate = DateUtil.getFirstOrLastDayOfMonth( startEndDates[0],true);
						endDate = DateUtil.getFirstOrLastDayOfMonth( startEndDates[1],false);					
					}
					
					DiscrepancySummaryVO[] discrepancySummaryVO = discrepancySummaryVOList.getDiscrepancySummaryPartCVOArray();
					if(discrepancySummaryVO!=null){
						String percent="";
						String ttlMbrStr="";
						StringBuffer partCRow = null;
						
						int ttlMbrPartC = discrepancySummaryVOList.getTotalMbrPartC();
						for(int i=0;i<discrepancySummaryVO.length;i++){
							if(Constants.CONSTANTS_MONTH.equals(searchType)){
								percent = formatCurrencyValue(StringUtil.nonNullTrim(discrepancySummaryVO[i].getDiscrepancyPercentage()),false)+"%";
								ttlMbrStr = String.valueOf(ttlMbrPartC);
							}
							partCRow = new StringBuffer(Constants.PLAN_DISC_SUMMARY_SOURCE_VALUE)
							.append(",").append(extractDate)
							.append(",").append(planId).append(",\"").append(planName).append("\",").append(StringUtil.nonNullTrim(startDate))
							.append(",").append(StringUtil.nonNullTrim(endDate)).append(",").append(dateType).append(",").append("C")
							.append(",").append(formatCurrencyValue(ttlMbrStr,false))
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(discrepancySummaryVO[i].getDiscrepancyName()),false))
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(discrepancySummaryVO[i].getDiscrepancyShortName()),false))
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(discrepancySummaryVO[i].getDiscrepancyCount()),false))
							.append(",").append(percent)
							.append(",").append(searchPlanId).append(",").append(searchPartInd)
							.append(",").append(searchStatusCd)
							.append(",").append(searchStartDate).append(",").append(searchEndDate)
							.append(",").append(dateType);
							stream.write((partCRow+LINE_SEPARATOR).getBytes());
						}
					}
				}
			}
			
			//write CSV rows for part D
			if(filterVO.getPartName() == null || Constants.BOTH_PARTS.equals(filterVO.getPartName())||Constants.PARTD.equals(filterVO.getPartName())){
				DiscrepancySummaryVOList discrepancySummaryVOList = discrepancyService.getDiscrepancySummary(filterVO, searchType, Constants.PARTD ,planMap,adjReasonMap);
				if(discrepancySummaryVOList!=null){
					String startEndDates[] = discrepancySummaryVOList.getLatestDateArray();
					if(startEndDates != null && startEndDates.length == 2 ){
						startDate = DateUtil.getFirstOrLastDayOfMonth( startEndDates[0],true);					
						endDate = DateUtil.getFirstOrLastDayOfMonth( startEndDates[1],false);
					}
					
					DiscrepancySummaryVO[] discrepancySummaryVO = discrepancySummaryVOList.getDiscrepancySummaryPartDVOArray();
					if(discrepancySummaryVO!=null){
						String percent="";
						String ttlMbrStr="";
						StringBuffer partDRow = null;
						int ttlMbrPartD = discrepancySummaryVOList.getTotalMbrPartD();
						
						for(int i=0;i<discrepancySummaryVO.length;i++){
							if(Constants.CONSTANTS_MONTH.equals(searchType)){
								percent = formatCurrencyValue(StringUtil.nonNullTrim(discrepancySummaryVO[i].getDiscrepancyPercentage()),false)+"%";
								ttlMbrStr = String.valueOf(ttlMbrPartD);
							}
							partDRow = new StringBuffer(Constants.PLAN_DISC_SUMMARY_SOURCE_VALUE)
							.append(",").append(extractDate)
							.append(",").append(planId).append(",\"").append(planName).append("\",").append(startDate)
							.append(",").append(endDate).append(",").append(dateType).append(",").append("D")
							.append(",").append(formatCurrencyValue(ttlMbrStr,false))
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(discrepancySummaryVO[i].getDiscrepancyName()),false))
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(discrepancySummaryVO[i].getDiscrepancyShortName()),false))
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(discrepancySummaryVO[i].getDiscrepancyCount()),false))
							.append(",").append(percent)
							.append(",").append(searchPlanId).append(",").append(searchPartInd)
							.append(",").append(searchStatusCd)
							.append(",").append(searchStartDate).append(",").append(searchEndDate)
							.append(",").append(dateType);
							stream.write((partDRow+LINE_SEPARATOR).getBytes());
						}
					}
				}
			}
			//stream.close();
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createDiscrepancySummary method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createDiscrepancySummary method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	
	
	/**
	 * For 'Discrepancy Detail' or 'Beneficiary Discrepancy Detail' or 'Beneficiary Show Discrepancies' export
	 * @author hemant
	 * @param filterVO
	 * @param planMap
	 * @param searchType
	 * @param planName
	 * @param pageStatus
	 * @param uiContextRange
	 * @param discMap
	 * @param discrpArrMap
	 * @param menuName
	 * @param adjReasonMap
	 * @param hasWriteOffSerivce
	 * @return
	 * @throws Exception
	 */
	public String createDiscrepancyDetail(FilterVO filterVO, Map planMap, String searchType, String planId, List pageStatus, String uiContextRange, Map discMap, Map discrpArrMap, String menuName,Map adjReasonMap, boolean hasWriteOffSerivce) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		String dateType = "";
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		
		//String planName = planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(planId, planMap, false)) : "";
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;;
		
		
		String searchEffStartDate = Constants.BEGIN_OF_DATE;
		String searchEffEndDate = Constants.END_OF_DATE;
		String searchUpdStartDate = Constants.BEGIN_OF_DATE;
		String searchUpdEndDate = Constants.END_OF_DATE;
		String searchStatusCode = "ALL";
		String searchTypeCode = "ALL";
		String searchPlanId = "ALL";
		String searchPartInd = null;
		try {
			stream = new FileOutputStream(new File(fileName));
			if(filterVO!=null){
				dateType = filterVO.getDateType();
				
				//set saerch part indicator
				if(Constants.BOTH_PARTS.equals(filterVO.getPartName()))
					searchPartInd = "B";
				else if(Constants.PARTC.equals(filterVO.getPartName()))
					searchPartInd = "C";
				else 
					searchPartInd = "D";
				
				if(filterVO.getPlanName()!=null)
					searchPlanId = filterVO.getPlanName();
				if(filterVO.getStartDate()!=null)
					searchEffStartDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getStartDate(),true);
				if(filterVO.getEndDate()!=null)
					searchEffEndDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getEndDate(),false);
				if(filterVO.getUpdateDateFrom()!=null)
					searchUpdStartDate = filterVO.getUpdateDateFrom();
				if(filterVO.getUpdateDateFrom()!=null)
					searchUpdEndDate = filterVO.getUpdateDateTo();
				//get search status code
				if(filterVO.getDiscrpStatus()!=null){
					searchStatusCode = filterVO.getDiscrpStatus();
					CodeCacheService codeCache=new CodeCacheService();
					NameValuePair[] discrpStatusArr = codeCache.getDiscrpStatusArr();
					String statusDes = null;
					if(discrpStatusArr != null){
						for(int i=0;i<discrpStatusArr.length;i++){
							if(discrpStatusArr[i]!=null && discrpStatusArr[i].getName().equals(searchStatusCode)){
								statusDes = discrpStatusArr[i].getValue();
								break;
							}
						}
					}
					if(statusDes != null){
						searchStatusCode = statusDes;
					}else{
						statusDes = (String)Constants.DISCRP_STATUS_MAP.get(searchStatusCode);
						if(statusDes!=null)
							searchStatusCode = statusDes;
					}
				}
				//get search type code
				if(filterVO.getDiscrpCd()!=null)
					searchTypeCode = filterVO.getDiscrpCd();
				CodeCacheService codeCache=new CodeCacheService();
				Map temDiscrpMap = codeCache.getDiscrpArrMap();
				DiscrepancyCdVO discrepancyCdVO = null;
				if(temDiscrpMap!=null){
					Map partCDiscMap = (Map)temDiscrpMap.get(Constants.PARTC_DISCRP_CD_MAP);
					if(partCDiscMap != null)
						discrepancyCdVO  = (DiscrepancyCdVO)partCDiscMap.get(searchTypeCode);
					if(discrepancyCdVO == null){
						Map partDDiscMap = (Map)temDiscrpMap.get(Constants.PARTD_DISCRP_CD_MAP);
						if(partDDiscMap != null)
							discrepancyCdVO  = (DiscrepancyCdVO)partDDiscMap.get(searchTypeCode);
					}
					if(discrepancyCdVO != null && discrepancyCdVO.getDiscrpShortName()!=null){
						searchTypeCode=searchTypeCode+"-"+discrepancyCdVO.getDiscrpShortName();
					}
				}
			}
			
			//write heading row
			if(Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(menuName))
				stream.write((BENEFICIARY_DISCREPANCY_DETAIL_HEADING+LINE_SEPARATOR).getBytes()); 
			else
				stream.write((DISCREPANCY_DETAIL_HEADING+LINE_SEPARATOR).getBytes());
			
			//get selected row number
			int selectedRowNo=0;
			if(discMap!=null) {
				Integer temp = ((Integer)discMap.get(Constants.PAGE_SELECTED_LINE));
				if(temp != null)
					selectedRowNo = temp.intValue() ; 
			}
			
			if(Constants.PARTD.equals(filterVO.getPartName()) && selectedRowNo == 0)
				selectedRowNo = 10;//because for part D, first row is default selected row with selectedRowNo '10'
			
			
			String move="current";
			Map detailmap=null;
			
			//for ALL, get MAXRECORDCOUNT and set move to 'first' to fetch records from start  
			if(Constants.CONSTANTS_ALL.equals(uiContextRange) && discMap!=null){
				CodeCacheService codeCache=new CodeCacheService();
				//Modified for fix for Export Issue Performance : Start
				//Integer maxRecordCount=codeCache.getMaxRecordCount();
				Integer maxRecordCount=codeCache.getDiscMaxRecordCount();
				//Modified for fix for Export Issue Performance : End
				if(selectedRowNo<10){
					detailmap =  discMap != null ?(Map)discMap.get(Constants.PARTC_DISCRP_DETAIL_MAP) :null ;
					searchPartInd = "C";
				}else{
					detailmap =  discMap != null ?(Map)discMap.get(Constants.PARTD_DISCRP_DETAIL_MAP) :null ;
					searchPartInd = "D";
				}		
				if(detailmap!=null){
					detailmap.put(Constants.SESSION_MAX_RECORD_COUNT,maxRecordCount);
					detailmap.put(Constants.UI_CONTEXT_RANGE,Constants.CONSTANTS_ALL);
					move = "first";
				}
			}		
			
			DiscrepancyService discrepancyService = new DiscrepancyService(this.dbId);
			DiscrepancyDetailVOList discrepancyDetailPageObj = null;
			
			//for ALL, fetch records only for part C, if part C's row is selected or fetch records only for part D, if part D's row is selected  
			if(Constants.CONSTANTS_ALL.equals(uiContextRange)){
				String discInd = filterVO.getPartName();
				if(selectedRowNo<10){
					filterVO.setPartName(Constants.PARTC);
				}else{
					filterVO.setPartName(Constants.PARTD);
				}
				// Logging time for fetching discrepancy list for all 
				long starttime = System.currentTimeMillis();
				discrepancyDetailPageObj = discrepancyService.getDiscrepancyList(filterVO,discMap,move,planMap,filterVO.getSearchType(),discrpArrMap, menuName,adjReasonMap, hasWriteOffSerivce);
				long endTime = System.currentTimeMillis();
				logger.debug(" In CSV Service -- fetching disc list 1st time =="+(endTime-starttime));
				filterVO.setPartName(discInd);
			}else{
				// Logging time for fetching discrepancy list for all 
				long starttime = System.currentTimeMillis();
				discrepancyDetailPageObj = discrepancyService.getDiscrepancyList(filterVO,discMap,move,planMap,filterVO.getSearchType(),discrpArrMap, menuName,adjReasonMap, hasWriteOffSerivce);
				long endTime = System.currentTimeMillis();
				logger.debug(" In CSV Service -- fetching disc list 2nd time =="+(endTime-starttime));
			}
			
			//reset no of fetching records to 10
			if(detailmap!=null) {
				detailmap.put(Constants.SESSION_MAX_RECORD_COUNT,new Integer(10));
				detailmap.remove(Constants.UI_CONTEXT_RANGE);
			}
			
			
			if(discrepancyDetailPageObj!=null){
				DiscrepancyDetailVO discListPartC =discrepancyDetailPageObj.getPartCDiscrpDetailVO();
				DiscrepancyDetailVO discListPartD =discrepancyDetailPageObj.getPartDDiscrpDetailVO();
				DiscrepancyListVO[] discListPartCObjArr = null;
				DiscrepancyListVO[] discListPartDObjArr = null;
				StringBuffer rowPrefix = null;
				if(Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(menuName))
					rowPrefix = new StringBuffer(Constants.BENE_DISC_DETAIL_SOURCE_VALUE);
				else
					rowPrefix = new StringBuffer(Constants.PLAN_DISC_DETAIL_SOURCE_VALUE);
				
				rowPrefix.append(",").append(extractDate);
				/*.append(",").append(planId)
				.append(",\"").append(planName).append("\"");*/
				
				StringBuffer rowSuffix= new StringBuffer();
				rowSuffix.append(",").append(searchPlanId);
				
				if(!Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(menuName))
					rowSuffix.append(",").append(searchPartInd);
				
				rowSuffix.append(",").append(searchEffStartDate)
				.append(",").append(searchEffEndDate)
				.append(",").append(searchUpdStartDate)
				.append(",").append(searchUpdEndDate)
				.append(",").append(searchStatusCode);
				
				if(Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(menuName))
					rowSuffix.append(",").append(searchPartInd);
				
				rowSuffix.append(",").append(StringUtil.nonNullTrim(filterVO.getHicNumber()))
				.append(",").append(searchTypeCode)
				.append(",").append(StringUtil.nonNullTrim(filterVO.getUpdateId()));
				
				//write CSV rows for Part C
				if(discListPartC!=null ){
					discListPartCObjArr = discListPartC.getDiscrepancyListVO();
					if(discListPartCObjArr!=null){
						long starttime = System.currentTimeMillis();
						stream = (FileOutputStream)createCsvRowsForDiscrepancyDetail(discListPartCObjArr, planMap, stream, rowPrefix,dateType,rowSuffix, "C" ,menuName);
						long endTime = System.currentTimeMillis();
						logger.debug(" In CSV Service -- createCsvRowsForDiscrepancyDetail Part C time =="+(endTime-starttime));
					}
				}
				
				//write CSV rows for Part D
				if(discListPartD!=null){
					discListPartDObjArr = discListPartD.getDiscrepancyListVO();
					if(discListPartDObjArr!=null){
						long starttime = System.currentTimeMillis();
						stream = (FileOutputStream)createCsvRowsForDiscrepancyDetail(discListPartDObjArr, planMap, stream, rowPrefix,dateType,rowSuffix, "D" ,menuName);
						long endTime = System.currentTimeMillis();
						logger.debug(" In CSV Service -- createCsvRowsForDiscrepancyDetail Part D time =="+(endTime-starttime));
					}
				}
			}
			
			
			//stream.close();
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createDiscrepancyDetail method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createDiscrepancyDetail method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	/**
	 * For 'Work Queue' export
	 * @author hemant
	 * @param filterVO
	 * @param planMap
	 * @param searchType
	 * @param planName
	 * @param pageStatus
	 * @param uiContextRange
	 * @param discMap
	 * @param discrpArrMap
	 * @param menuName
	 * @param adjReasonMap
	 * @param hasWriteOffSerivce
	 * @return
	 * @throws Exception
	 */
	public String createWorkQueue(FilterVO filterVO, Map planMap, String searchType, String planId, List pageStatus, String uiContextRange, Map discMap, Map discrpArrMap, String menuName,Map adjReasonMap, boolean hasWriteOffSerivce) throws Exception {
		logger.info(LoggerConstants.methodStartLevel());
		String dateType = "";
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		
		String planName = planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(planId, planMap, false)) : "";
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;;
		
		
		/*String searchEffStartDate = Constants.BEGIN_OF_DATE;
		String searchEffEndDate = Constants.END_OF_DATE;
		String searchUpdStartDate = Constants.BEGIN_OF_DATE;
		String searchUpdEndDate = Constants.END_OF_DATE;*/
		String searchEffStartDate = "";
		String searchEffEndDate = "";
		String searchUpdStartDate = "";
		String searchUpdEndDate = "";
		String searchStatusCode = "ALL";
		String searchTypeCode = "ALL";
		String searchPlanId = "ALL";
		String searchPartInd = null;
		try {
			stream = new FileOutputStream(new File(fileName));
			if(filterVO!=null){
				dateType = filterVO.getDateType();
				
				//set saerch part indicator
				if(Constants.BOTH_PARTS.equals(filterVO.getPartName()))
					searchPartInd = "B";
				else if(Constants.PARTC.equals(filterVO.getPartName()))
					searchPartInd = "C";
				else 
					searchPartInd = "D";
				
				if(filterVO.getPlanName()!=null)
					searchPlanId = filterVO.getPlanName();
				if(filterVO.getStartDate()!=null)
					searchEffStartDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getStartDate(),true);
				if(filterVO.getEndDate()!=null)
					searchEffEndDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getEndDate(),false);
				if(filterVO.getUpdateDateFrom()!=null)
					searchUpdStartDate = filterVO.getUpdateDateFrom();
				if(filterVO.getUpdateDateFrom()!=null)
					searchUpdEndDate = filterVO.getUpdateDateTo();
				//get search status code
				if(filterVO.getDiscrpStatus()!=null){
					searchStatusCode = filterVO.getDiscrpStatus();
					CodeCacheService codeCache=new CodeCacheService();
					NameValuePair[] discrpStatusArr = codeCache.getDiscrpStatusArr();
					String statusDes = null;
					if(discrpStatusArr != null){
						for(int i=0;i<discrpStatusArr.length;i++){
							if(discrpStatusArr[i]!=null && discrpStatusArr[i].getName().equals(searchStatusCode)){
								statusDes = discrpStatusArr[i].getValue();
								break;
							}
						}
					}
					if(statusDes != null){
						searchStatusCode = statusDes;
					}else{
						statusDes = (String)Constants.DISCRP_STATUS_MAP.get(searchStatusCode);
						if(statusDes!=null)
							searchStatusCode = statusDes;
					}
				}
				//get search type code
				if(filterVO.getDiscrpCd()!=null)
					searchTypeCode = filterVO.getDiscrpCd();
				CodeCacheService codeCache=new CodeCacheService();
				Map temDiscrpMap = codeCache.getDiscrpArrMap();
				DiscrepancyCdVO discrepancyCdVO = null;
				if(temDiscrpMap!=null){
					Map partCDiscMap = (Map)temDiscrpMap.get(Constants.PARTC_DISCRP_CD_MAP);
					if(partCDiscMap != null)
						discrepancyCdVO  = (DiscrepancyCdVO)partCDiscMap.get(searchTypeCode);
					if(discrepancyCdVO == null){
						Map partDDiscMap = (Map)temDiscrpMap.get(Constants.PARTD_DISCRP_CD_MAP);
						if(partDDiscMap != null)
							discrepancyCdVO  = (DiscrepancyCdVO)partDDiscMap.get(searchTypeCode);
					}
					if(discrepancyCdVO != null && discrepancyCdVO.getDiscrpShortName()!=null){
						searchTypeCode=searchTypeCode+"-"+discrepancyCdVO.getDiscrpShortName();
					}
				}
			}
			
		
				stream.write((WORK_QUEUE_HEADING+LINE_SEPARATOR).getBytes());
			
			//get selected row number
			int selectedRowNo=0;
			if(discMap!=null) {
				Integer temp = ((Integer)discMap.get(Constants.PAGE_SELECTED_LINE));
				if(temp != null)
					selectedRowNo = temp.intValue() ; 
			}
			
					
			String move="current";
			Map detailmap=null;
			
			//for ALL, get MAXRECORDCOUNT and set move to 'first' to fetch records from start  
			if(Constants.CONSTANTS_ALL.equals(uiContextRange) && discMap!=null){
				CodeCacheService codeCache=new CodeCacheService();
				//Modified for fix for Export Issue Performance : Start
				//Integer maxRecordCount=codeCache.getMaxRecordCount();
				Integer maxRecordCount=codeCache.getDiscMaxRecordCount();
				//Modified for fix for Export Issue Performance : End
				/*if(selectedRowNo<10){
					detailmap =  discMap != null ?(Map)discMap.get(Constants.PARTC_DISCRP_DETAIL_MAP) :null ;
					searchPartInd = "C";
				}else{
					detailmap =  discMap != null ?(Map)discMap.get(Constants.PARTD_DISCRP_DETAIL_MAP) :null ;
					searchPartInd = "D";
				}		
				if(detailmap!=null){
					detailmap.put(Constants.SESSION_MAX_RECORD_COUNT,maxRecordCount);
					detailmap.put(Constants.UI_CONTEXT_RANGE,Constants.CONSTANTS_ALL);
					move = "first";
				}*/
			}		
			
			WorkQueueService discrepancyService = new WorkQueueService(this.dbId);
			DiscrepancyDetailVOList discrepancyDetailPageObj = null;
			CodeCacheService codeCache=new CodeCacheService();
			Integer maxExportCount=codeCache.getDiscMaxRecordCount();
			
			//for ALL, fetch records only for part C, if part C's row is selected or fetch records only for part D, if part D's row is selected  
			if(Constants.CONSTANTS_ALL.equals(uiContextRange)){
				String discInd = filterVO.getPartName();
				/*if(selectedRowNo<10){
					filterVO.setPartName(Constants.PARTC);
				}else{
					filterVO.setPartName(Constants.PARTD);
				}*/
				// Logging time for fetching discrepancy list for all 
				long starttime = System.currentTimeMillis();
				discrepancyDetailPageObj = discrepancyService.getDiscrepancyList(maxExportCount,null,filterVO,discMap,"allExport",planMap,filterVO.getSearchType(),discrpArrMap, menuName,adjReasonMap, hasWriteOffSerivce);
				long endTime = System.currentTimeMillis();
				logger.debug(" In CSV Service -- fetching disc list 1st time =="+(endTime-starttime));
				filterVO.setPartName(discInd);
			}else{
				// Logging time for fetching discrepancy list for all 
				long starttime = System.currentTimeMillis();
				discrepancyDetailPageObj = discrepancyService.getDiscrepancyList(maxExportCount,null, filterVO,discMap,"currentPage",planMap,filterVO.getSearchType(),discrpArrMap, menuName,adjReasonMap, hasWriteOffSerivce);
				long endTime = System.currentTimeMillis();
				logger.debug(" In CSV Service -- fetching disc list 2nd time =="+(endTime-starttime));
			}
			
			//reset no of fetching records to 10
			/*if(detailmap!=null) {
				detailmap.put(Constants.SESSION_MAX_RECORD_COUNT,new Integer(10));
				detailmap.remove(Constants.UI_CONTEXT_RANGE);
			}*/
			
			
			if(discrepancyDetailPageObj!=null){
				DiscrepancyDetailVO discListPartC =discrepancyDetailPageObj.getPartCDiscrpDetailVO();
				//DiscrepancyDetailVO discListPartD =discrepancyDetailPageObj.getPartDDiscrpDetailVO();
				DiscrepancyListVO[] discListPartCObjArr = null;
				//DiscrepancyListVO[] discListPartDObjArr = null;
				StringBuffer rowPrefix = null;
				rowPrefix = new StringBuffer(Constants.PLAN_DISC_DETAIL_SOURCE_VALUE);
				
				rowPrefix.append(",").append(extractDate);
				/*.append(",").append(planId)
				.append(",\"").append(planName).append("\"");*/
				
				StringBuffer rowSuffix= new StringBuffer();
				rowSuffix.append(",").append(searchPlanId);
				
				rowSuffix.append(",").append(searchEffStartDate)
				.append(",").append(searchEffEndDate)
				.append(",").append(searchUpdStartDate)
				.append(",").append(searchUpdEndDate)
				.append(",").append(searchStatusCode);
				
				rowSuffix.append(",").append(StringUtil.nonNullTrim(filterVO.getHicNumber()))
				.append(",").append(searchTypeCode)
				.append(",").append(StringUtil.nonNullTrim(filterVO.getUpdateId()));
				
				//write CSV rows for Part C
				if(discListPartC!=null ){
					discListPartCObjArr = discListPartC.getDiscrepancyListVO();
					if(discListPartCObjArr!=null){
						long starttime = System.currentTimeMillis();
						stream = (FileOutputStream)createCsvRowsForWorkQueue(planMap,discListPartCObjArr, stream, rowPrefix,dateType,rowSuffix, "C" ,menuName);
						long endTime = System.currentTimeMillis();
						logger.debug(" In CSV Service -- createCsvRowsForDiscrepancyDetail Part C time =="+(endTime-starttime));
					}
				}
				
				
			}
			
			
			//stream.close();
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createDiscrepancyDetail method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createDiscrepancyDetail method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	
	/**
	 * This method is to create rows in Discrepancy Detail CSV
	 * @author hemant 
	 * @param discListObjArr
	 * @param stream
	 * @param rowPrefix
	 * @param dateType
	 * @param rowSuffix
	 * @param discInd
	 * @param menuName
	 * @return
	 */
	private OutputStream createCsvRowsForDiscrepancyDetail(DiscrepancyListVO[] discListObjArr, Map planMap, OutputStream stream, StringBuffer rowPrefix,String dateType, StringBuffer rowSuffix, String discInd, String menuName)throws IOException{
		logger.info(LoggerConstants.methodStartLevel());
		String date = null;
		
		for(int i=0;i<discListObjArr.length;i++){
				if(discListObjArr[i] != null){
					if("E".equals(dateType))
						date = discListObjArr[i].getPymtEffDate();
					else if("A".equals(dateType))
						date = discListObjArr[i].getPymtApplyDate();
					StringBuffer discListRow = new StringBuffer();						
					discListRow.append(rowPrefix);
					
					//IFOX-00431034 :: All-Plans in Discrepancy Drop down ::: START
					String planName = planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(discListObjArr[i].getPlanName(), planMap, false)) : "";
					discListRow.append(",").append(discListObjArr[i].getPlanName())
					.append(",\"").append(planName).append("\"");
					//IFOX-00431034 :: All-Plans in Discrepancy Drop down ::: END
					
					if(!Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(menuName)) 
						discListRow.append(",").append(discInd)
						.append(",").append(discListObjArr[i].getHicNumber())
						.append(",").append(StringUtil.nonNullTrim(discListObjArr[i].getCsvAltHic()));
					
					else 
						discListRow.append(",").append(discListObjArr[i].getHicNumber())
						.append(",").append(StringUtil.nonNullTrim(discListObjArr[i].getCsvAltHic()))
						.append(",").append(discInd);
					
					// displaying PBP ID as blank for Part C, bcoz 'discrphist' did not contain PBP ID as field.
					String pbpId = discListObjArr[i].getPbpId();
					
					discListRow.append(",").append(discListObjArr[i].getDiscrepancyCd())
					.append(",").append(discListObjArr[i].getDiscrepancyShortName())
					.append(",").append(DateUtil.getFirstOrLastDayOfMonth(StringUtil.nonNullTrim(date),true))
					.append(",").append(dateType)
					.append(",").append(discListObjArr[i].getDiscrepancyStatus())
					.append(",").append(pbpId)
					.append(",").append("\""+discListObjArr[i].getCmsValue()+"\"")
					.append(",").append("\""+discListObjArr[i].getPlanValue()+"\"");
					
					if ( ! Constants.BENEFICIARY_DISCRP_DETAIL_MENU.equals(menuName))
						discListRow.append(",").append(CSVUtil.quoteString(discListObjArr[i].getComment()));
					
					discListRow.append(",").append(discListObjArr[i].getLastUpdtUserID())
					.append(",").append(discListObjArr[i].getShortLastUpdtDate())
					.append(rowSuffix);
					
					((FileOutputStream)stream).write((discListRow+LINE_SEPARATOR).getBytes());
				}
			discListObjArr[i] = null;
		}	
		logger.info(LoggerConstants.methodEndLevel());
		return stream;
	}
	
	/**
	 * This method is to create rows in Work Queue CSV
	 * @author hemant 
	 * @param discListObjArr
	 * @param stream
	 * @param rowPrefix
	 * @param dateType
	 * @param rowSuffix
	 * @param discInd
	 * @param menuName
	 * @return
	 */
	private OutputStream createCsvRowsForWorkQueue(Map planMap,DiscrepancyListVO[] discListObjArr, OutputStream stream, StringBuffer rowPrefix,String dateType, StringBuffer rowSuffix, String discInd, String menuName)throws IOException{
		logger.info(LoggerConstants.methodStartLevel());
		String date = null;
		
		for(int i=0;i<discListObjArr.length;i++){
			String planId = StringUtil.nonNullTrim(discListObjArr[i].getPlanName());
			String planName = planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(planId, planMap, false)) : "";
			
				if(discListObjArr[i] != null){
					if("E".equals(dateType))
						date = discListObjArr[i].getPymtEffDate();
					else if("A".equals(dateType))
						date = discListObjArr[i].getPymtApplyDate();
					StringBuffer discListRow = new StringBuffer();						
					discListRow.append(rowPrefix);
					discListRow.append(",").append(planId)
					.append(",").append(StringUtil.nonNullTrim(planName));
						discListRow.append(",").append(discListObjArr[i].getDiscrepancyIndicator())
						.append(",").append(StringUtil.nonNullTrim(discListObjArr[i].getHicNumber()));
						
					
					// displaying PBP ID as blank for Part C, bcoz 'discrphist' did not contain PBP ID as field.
					String pbpId = discListObjArr[i].getPbpId();
					String pbpSegId = discListObjArr[i].getPbpSegmentId();
					
					discListRow.append(",").append(discListObjArr[i].getDiscrepancyCd())
					.append(",").append(discListObjArr[i].getDiscrepancyShortName())
					.append(",").append(DateUtil.getFirstOrLastDayOfMonth(StringUtil.nonNullTrim(date),true))
					.append(",").append(dateType)
					.append(",").append(discListObjArr[i].getDiscrepancyStatus())
					.append(",").append(pbpId)
					.append(",").append(pbpSegId)
					.append(",").append(discListObjArr[i].getAssignedBy())
					.append(",").append(discListObjArr[i].getAssignedTo())
					.append(",").append(discListObjArr[i].getAssignedOnDate())
					.append(",").append("\""+discListObjArr[i].getCmsValue()+"\"")
					.append(",").append("\""+discListObjArr[i].getPlanValue()+"\"");
					discListRow.append(",").append(CSVUtil.quoteString(discListObjArr[i].getComment()));
					
					discListRow.append(",").append(discListObjArr[i].getLastUpdtUserID())
					.append(",").append(discListObjArr[i].getShortLastUpdtDate())
					.append(rowSuffix);
					
					((FileOutputStream)stream).write((discListRow+LINE_SEPARATOR).getBytes());
				}
			discListObjArr[i] = null;
		}	
		logger.info(LoggerConstants.methodEndLevel());
		return stream;
	}

	/**
	 * For 'Beneficiary Pymt Detail' or 'Beneficiary Show Payments' or 'Pymt Detail Popup' export
	 * @author hemant
	 * @param filterVO
	 * @param planMap
	 * @param searchType
	 * @param planName
	 * @param pageStatus
	 * @param uiContextRange
	 * @param menuName
	 * @param adjReasonMap
	 * @return
	 * @throws ApplicationException
	 */
	public String createBeneficiaryPaymentDetail(FilterVO filterVO, Map planMap, String searchType, String planId, List pageStatus, String uiContextRange,String menuName,Map adjReasonMap) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		String planName= planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(planId, planMap, false)) : "";
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		String fileName = getCvsFileName();

		FileOutputStream stream = null;
		
		
		String searchStartDate = Constants.BEGIN_OF_DATE;
		String searchEndDate = Constants.END_OF_DATE;
		String searchPlanId = "ALL";
		String searchDateType = "E";
		String searchHic = "";
		try {
			stream = new FileOutputStream(new File(fileName));
			//write heading row
			if(Constants.PAYMENT_DETAIL.equals(menuName))
				stream.write((DISCREPANCY_PAYMENT_POPUP+LINE_SEPARATOR).getBytes());
			else
				stream.write((BENEFICIARY_PYMT_DETAIL_HEADING+LINE_SEPARATOR).getBytes());
			
			BeneficiaryService beneficiaryService = new BeneficiaryService(this.dbId);
			BeneficiaryPymtDetailVOList benePymtDetailVOList = beneficiaryService.getBeneficiaryPymtDetail(filterVO, planMap, searchType, adjReasonMap,pageStatus);
			if(benePymtDetailVOList!=null){
//				String hicNbr=null;
				if(filterVO!=null){
					searchHic = StringUtil.nonNullTrim(filterVO.getHicNumber());
					if(filterVO.getPlanName()!=null)
						searchPlanId = filterVO.getPlanName();
					if(filterVO.getStartDate()!=null)
						searchStartDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getStartDate(),true);
					if(filterVO.getEndDate()!=null)
						searchEndDate=DateUtil.getFirstOrLastDayOfMonth(filterVO.getEndDate(),false);
				}
				
				StringBuffer rowPrefix = new StringBuffer(Constants.BENEFICIARY_PYMT_DETAIL_SOURCE_VALUE).append(",")
				.append(extractDate).append(",").append(planId).append(",\"").append(planName)
				.append("\",");
				String hicNbr = null;
				//add part c CSV rows
				if(!Constants.PARTD.equals(filterVO.getPartName())){
					BeneficiaryPymtDetailVO[] beneficiaryPymtDetailPartCVOArr = benePymtDetailVOList.getPartCBenPymtDetailVOArray();
					if(beneficiaryPymtDetailPartCVOArr!=null){
						for(int i=0;i<beneficiaryPymtDetailPartCVOArr.length;i++){
							if(beneficiaryPymtDetailPartCVOArr[i]!=null){
								String effDate = DateUtil.getFirstOrLastDayOfMonth(StringUtil.nonNullTrim(beneficiaryPymtDetailPartCVOArr[i].getEffectiveDate()),true);	
								BeneficiaryPymtDetailVO[] childVOArr= beneficiaryPymtDetailPartCVOArr[i].getBenePymtDetailVOs();
								if(childVOArr!=null){
									StringBuffer partCDataRow =null;
									for(int j=0;j<childVOArr.length;j++){
										partCDataRow = new StringBuffer();
										hicNbr = StringUtil.trimToNull(childVOArr[j].getHicNbr());
										if (hicNbr == null) 
											hicNbr= searchHic;
										partCDataRow.append(rowPrefix).append(hicNbr).append(",C,")
										.append(effDate).append(",")
										.append( DateUtil.getFirstOrLastDayOfMonth(StringUtil.nonNullTrim(childVOArr[j].getApplyDate()),true)).append(",");
										if(! Constants.PAYMENT_DETAIL.equals(menuName)){
											partCDataRow.append("").append(",")
											.append("").append(",")
											.append("").append(",");
										}
										partCDataRow.append(StringUtil.nonNullTrim(childVOArr[j].getAdjustmentCode())).append(",")
										.append(StringUtil.nonNullTrim(childVOArr[j].getAdjustmentDiscrp())).append(",");//Change for Part C UI - Start
/*										.append("PARTCPYMT").append(",")
										.append(formatCurrencyValue(StringUtil.nonNullTrim(childVOArr[j].getCmsPaid()),false)).append(",")*/
										if(null != childVOArr[j].getPaymentType() && childVOArr[j].getPaymentType().equals("MMA")){
											partCDataRow.append("PARTCMMAPYMT").append(",");
										} else if(null != childVOArr[j].getPaymentType() && childVOArr[j].getPaymentType().equals("PREMIUM")){
											partCDataRow.append("PARTCPREMPYMT").append(",");
										} else {
											partCDataRow.append("PARTCPYMT").append(",");
										}
										partCDataRow.append(formatCurrencyValue(StringUtil.nonNullTrim(childVOArr[j].getCmsPaid()),false)).append(",")//Change for Part C UI - End
										.append(formatCurrencyValue(StringUtil.nonNullTrim(childVOArr[j].getPlanExpected()),false)).append(",")
										.append(formatCurrencyValue(StringUtil.nonNullTrim(childVOArr[j].getDifference()),false));
										
										if(! Constants.PAYMENT_DETAIL.equals(menuName)){
											partCDataRow.append(",").append(searchPlanId).append(",").append(searchHic)
											.append(",").append(searchStartDate).append(",").append(searchEndDate)
											.append(",").append(searchDateType);
										}
										stream.write((partCDataRow+LINE_SEPARATOR).getBytes());
									}
								}
							}
						}
					}
					//add CSV rows for unapplied payment detail
					if(! Constants.PAYMENT_DETAIL.equals(menuName)){
						UnappliedPymtAdjVO[] unappliedAdjVOArr = benePymtDetailVOList.getUnappliedPymtAdjVOs();
						if( unappliedAdjVOArr != null){
							StringBuffer unappliedDataRow =null;
							for(int i=0;i<unappliedAdjVOArr.length;i++){
								unappliedDataRow = new StringBuffer();						
								hicNbr = StringUtil.trimToNull(unappliedAdjVOArr[i].getHicNbr());
								if (hicNbr == null) 
									hicNbr= searchHic;
								unappliedDataRow.append(rowPrefix).append(hicNbr).append(",C,")
								.append("").append(",")
								.append("").append(",")
								.append(DateUtil.getFirstOrLastDayOfMonth(StringUtil.nonNullTrim(unappliedAdjVOArr[i].getEffectiveDate()),true)).append(",")
								.append(DateUtil.getFirstOrLastDayOfMonth(StringUtil.nonNullTrim(unappliedAdjVOArr[i].getPymtStartDate()),true)).append(",")
								.append(DateUtil.getFirstOrLastDayOfMonth(StringUtil.nonNullTrim(unappliedAdjVOArr[i].getPymtEndDate()),false)).append(",")
								.append(StringUtil.nonNullTrim(unappliedAdjVOArr[i].getAdjCD())).append(",")
								.append(StringUtil.nonNullTrim(unappliedAdjVOArr[i].getAdjDiscrp())).append(",")
								.append("PARTCSUSP").append(",")
								.append(formatCurrencyValue(StringUtil.nonNullTrim(unappliedAdjVOArr[i].getCmsValue()),false)).append(",")
								.append("$0.00").append(",")
								.append(formatCurrencyValue(StringUtil.nonNullTrim(unappliedAdjVOArr[i].getCmsValue()),false))
								.append(",").append(searchPlanId).append(",").append(searchHic)
								.append(",").append(searchStartDate).append(",").append(searchEndDate)
								.append(",").append(searchDateType);
								
								stream.write((unappliedDataRow+LINE_SEPARATOR).getBytes());
							}
						}	
					}
				}
				
				//add CSV rows for part D payment detail
				if(!Constants.PARTC.equals(filterVO.getPartName())){
					BeneficiaryPymtDetailVO[] beneficiaryPymtDetailPartDVOArr = benePymtDetailVOList.getPartDBenPymtDetailVOArray();
					if(beneficiaryPymtDetailPartDVOArr!=null){
						for(int i=0;i<beneficiaryPymtDetailPartDVOArr.length;i++){
							if(beneficiaryPymtDetailPartDVOArr[i]!=null){
								String effDate = DateUtil.getFirstOrLastDayOfMonth(StringUtil.nonNullTrim(beneficiaryPymtDetailPartDVOArr[i].getEffectiveDate()),true);	
								BeneficiaryPymtDetailVO[] childVOArr= beneficiaryPymtDetailPartDVOArr[i].getBenePymtDetailVOs();
								if(childVOArr!=null){
									for(int j=0;j<childVOArr.length;j++){
										StringBuffer partdDataRow = new StringBuffer();						
										hicNbr = StringUtil.trimToNull(childVOArr[j].getHicNbr());
										if (hicNbr == null) 
											hicNbr= searchHic;
										partdDataRow.append(rowPrefix).append(hicNbr).append(",D,")
										.append(effDate).append(",")
										.append(DateUtil.getFirstOrLastDayOfMonth(StringUtil.nonNullTrim(childVOArr[j].getApplyDate()),true)).append(",");
										if(! Constants.PAYMENT_DETAIL.equals(menuName)){
											partdDataRow.append("").append(",")
											.append("").append(",")
											.append("").append(",");
										}
										partdDataRow.append(StringUtil.nonNullTrim(childVOArr[j].getAdjustmentCode())).append(",")
										.append(StringUtil.nonNullTrim(childVOArr[j].getAdjustmentDiscrp())).append(",")
										.append(StringUtil.nonNullTrim(childVOArr[j].getPaymentType())).append(",")
										.append(formatCurrencyValue(StringUtil.nonNullTrim(childVOArr[j].getCmsPaid()),false)).append(",")
										.append(formatCurrencyValue(StringUtil.nonNullTrim(childVOArr[j].getPlanExpected()),false)).append(",")
										.append(formatCurrencyValue(StringUtil.nonNullTrim(childVOArr[j].getDifference()),false));
										if(! Constants.PAYMENT_DETAIL.equals(menuName)){
											partdDataRow.append(",").append(searchPlanId).append(",").append(searchHic)
											.append(",").append(searchStartDate).append(",").append(searchEndDate)
											.append(",").append(searchDateType);
										}
										stream.write((partdDataRow+LINE_SEPARATOR).getBytes());}
								}
							}
						}
					}
					//add CSV rows for unapplied payment detail part D
					if(! Constants.PAYMENT_DETAIL.equals(menuName)){
						UnappliedPymtAdjVO[] unappliedAdjVOArr = benePymtDetailVOList.getUnappliedPymtPartD();
						if( unappliedAdjVOArr != null){
							StringBuffer unappliedDataRow =null;
							for(int i=0;i<unappliedAdjVOArr.length;i++){
								unappliedDataRow = new StringBuffer();						
								hicNbr = StringUtil.trimToNull(unappliedAdjVOArr[i].getHicNbr());
								if (hicNbr == null) 
									hicNbr= searchHic;
								unappliedDataRow.append(rowPrefix).append(hicNbr).append(",D,")
								.append("").append(",")
								.append("").append(",")
								.append(DateUtil.getFirstOrLastDayOfMonth(StringUtil.nonNullTrim(unappliedAdjVOArr[i].getEffectiveDate()),true)).append(",")
								.append(DateUtil.getFirstOrLastDayOfMonth(StringUtil.nonNullTrim(unappliedAdjVOArr[i].getPymtStartDate()),true)).append(",")
								.append(DateUtil.getFirstOrLastDayOfMonth(StringUtil.nonNullTrim(unappliedAdjVOArr[i].getPymtEndDate()),false)).append(",")
								.append(StringUtil.nonNullTrim(unappliedAdjVOArr[i].getAdjCD())).append(",\"")
								.append(StringUtil.nonNullTrim(unappliedAdjVOArr[i].getAdjDiscrp())).append("\",")
								.append("PARTDSUSP").append(",")
								.append(formatCurrencyValue(StringUtil.nonNullTrim(unappliedAdjVOArr[i].getCmsValue()),false)).append(",")
								.append("$0.00").append(",")
								.append(formatCurrencyValue(StringUtil.nonNullTrim(unappliedAdjVOArr[i].getCmsValue()),false))
								.append(",").append(searchPlanId).append(",").append(hicNbr)
								.append(",").append(searchStartDate).append(",").append(searchEndDate)
								.append(",").append(searchDateType);
								
								stream.write((unappliedDataRow+LINE_SEPARATOR).getBytes());
							}
						}	
					}
					
				}	//end of part D		
			}
			//stream.close();
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createBeneficiaryPaymentDetail method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createBeneficiaryPaymentDetail method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	
	/**
	 * For 'Disease group popup' CSV
	 * @author hemant
	 * @param filterVO
	 * @param planMap
	 * @param pageStatus
	 * @param cmsValue
	 * @param planValue
	 * @return
	 * @throws ApplicationException
	 */
	public String createPopupDisease(FilterVO filterVO, Map planMap, List pageStatus, String cmsValue, String planValue) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		String planId = null;
		String planName = null;
		String dateType = null;
		String date = null;
		String partInd = null;
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;;
		try {
			stream = new FileOutputStream(new File(fileName));		
			//write heading row
			stream.write((DISEASE_GROUP_POPUP+LINE_SEPARATOR).getBytes());

		DiscrepancyService discrepancyService = new DiscrepancyService(this.dbId);
			DiseaseGroupVOList diseaseGroupVOList = discrepancyService.diseaseGroupDetail(filterVO, cmsValue, planValue, planMap);
			
			if(diseaseGroupVOList!=null){
				String hicNbr=null;
				if(filterVO!=null){
					hicNbr = StringUtil.nonNullTrim(filterVO.getHicNumber());
					if(filterVO.getPlanName()!=null)
						planId = filterVO.getPlanName();
					planName = planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(planId, planMap, false)) : "";
					dateType = filterVO.getDateType();
					date = DateUtil.getFirstOrLastDayOfMonth(StringUtil.nonNullTrim(filterVO.getStartDate()),true);
					if(Constants.PARTC.equals(filterVO.getPartName()))
						partInd = "C";
					else if(Constants.PARTD.equals(filterVO.getPartName()))
						partInd = "D";
				}
				StringBuffer rowPrefix = new StringBuffer(Constants.DISEASE_GROUP_DETAIL_SOURCE_VALUE).append(",")
				.append(extractDate).append(",").append(planId).append(",\"").append(planName)
				.append("\",").append(hicNbr).append(",").append(date).append(",").append(dateType).append(",").append(partInd).append(",");
				
				//add disease group detail rows
				
				DiseaseGroupVO[] diseaseGroupVOArr = diseaseGroupVOList.getDiseaseGroupVOs();
				if(diseaseGroupVOArr!=null){
					for(int i=0;i<diseaseGroupVOArr.length;i++){
						if(diseaseGroupVOArr[i]!=null){
							StringBuffer dataRow =	new StringBuffer();						
							dataRow.append(rowPrefix)
							.append("\""+diseaseGroupVOArr[i].getDiscrepancy()+"\"").append(",")
							.append(diseaseGroupVOArr[i].getCms()).append(",")
							.append(diseaseGroupVOArr[i].getPlan());
							stream.write((dataRow+LINE_SEPARATOR).getBytes());
						}
					}
				}
			}
			//stream.close();
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPopupDisease method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPopupDisease method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	/**
	 * For 'Popup Pymt Detail Part A/B' export
	 * @author hemant
	 * @param filterVO
	 * @param planMap
	 * @param pageStatus
	 * @param seqNbr
	 * @param pymtType
	 * @param applyDate
	 * @return
	 * @throws ApplicationException
	 */
	public String createPopupPymtDetail(FilterVO filterVO, Map planMap, List pageStatus, String seqNbr, String pymtType, String applyDate) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		
		String planId = null;
		String planName = null;
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;;
		boolean partD = false;
		
		try {
			stream = new FileOutputStream(new File(fileName));
			
			//write heading row

			stream.write((BENE_PYMT_DETAIL_PARTC_POPUP+LINE_SEPARATOR).getBytes());
			BeneficiaryService beneficiaryService = new BeneficiaryService(this.dbId);
			PymtEffDateDetailVO pymtEffDateDetailVO = beneficiaryService.getBenePymtDetailByParts(filterVO, planMap, seqNbr, pymtType);
			String part = "C";
			if (Constants.UNAPPLY_PYMT_D.equals(pymtType)) {
				part = "D";
				partD = true;
			}
			
			if(pymtEffDateDetailVO!=null){
				String hicNbr=null;
				if(filterVO!=null){
					hicNbr = StringUtil.nonNullTrim(filterVO.getHicNumber());
					if(filterVO.getPlanName()!=null)
						planId = filterVO.getPlanName();
					planName = planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(planId, planMap, false)) : "";
				}
				
				StringBuffer rowPrefix = new StringBuffer(Constants.BENE_PYMT_DETAIL_PARTC_POPUP_SOURCE_VALUE).append(",")
				.append(extractDate).append(",").append(planId).append(",\"").append(planName)
				.append("\",").append(hicNbr).append(",").append(part).append(",").append(DateUtil.getFirstOrLastDayOfMonth(StringUtil.nonNullTrim(filterVO.getStartDate()),true)).append(",");
				
				//add disease group detail rows
				
				BeneficiaryPymtDetailByPartsVO[] benePymtDetailByParts = pymtEffDateDetailVO.getPymtEffDateDetail();
				if(benePymtDetailByParts!=null){
					String formattedApplyDate = ",";
					//BUG: applyDate sometimes not available;e.g. when summing payment for a particular pymt_eff_date
					if (!"undefined".equals(applyDate))
						formattedApplyDate = DateUtil.getFirstOrLastDayOfMonth(StringUtil.nonNullTrim(applyDate),true).concat(",");
					rowPrefix.append(formattedApplyDate);
					for(int i=0;i<benePymtDetailByParts.length;i++){
						if(benePymtDetailByParts[i]!=null){
							StringBuffer dataRow =	new StringBuffer();						
							dataRow.append(rowPrefix)
							.append(benePymtDetailByParts[i].getAmtType()).append(",");
							if (partD) 
								dataRow.append(",,");
							else {
								dataRow.append(formatCurrencyValue(benePymtDetailByParts[i].getPartAAmt(),false)).append(",")
								.append(formatCurrencyValue(benePymtDetailByParts[i].getPartBAmt(),false)).append(",");
							}
							dataRow.append(formatCurrencyValue(benePymtDetailByParts[i].getTotal(),false));
							stream.write((dataRow+LINE_SEPARATOR).getBytes());
						}
					}
				}
			}
			//stream.close();
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPopupPymtDetail method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPopupPymtDetail method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
		
	}
	
	/**
	 * this method is to export Profile Details
	 * @author ppalat
	 * @param filterVO
	 * @param planMap
	 * @param planName
	 * @param pageStatus
	 * @param pageName
	 * @return
	 * @throws ApplicationException
	 */
	public String createProfileDetail(FilterVO filterVO, Map planMap, String searchType, String planId, List pageStatus, String uiContextRange, Map profileMap, Map profileArrMap, String menuName, Map profileDateRangeMap, String userId) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		
		String planName = planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(planId, planMap, false)) : "";
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;;
		
		
		String searchEffStartDate = Constants.BEGIN_OF_DATE;
		String searchEffEndDate = Constants.END_OF_DATE;
		String searchParmCode = "ALL";
		String searchPbpId = "ALL";			
		String searchSegmentId = "ALL";
		String searchPlanId = "ALL";
		String searchPartInd = null;
		String partDFetchListInd = "";
		
		//set saerch part indicator
		if(Constants.PARTC.equals(filterVO.getPartName())){
			searchPartInd = "C";
		}else{ 
			searchPartInd = "D";
			partDFetchListInd = Constants.PROFILE_PARTD_FETCH_BOTHLIST;
		}
		//profileDateRangeMap = (Map)sessionHelper.getAttribute(Constants.SESSION_PROFILE_DATE_RANGE);
		try {
			stream = new FileOutputStream(new File(fileName));
			
			if ( filterVO != null){
				if ( filterVO.getPlanName()!=null)
					searchPlanId = filterVO.getPlanName();
				
				if ( ! StringUtil.isNullOrEmpty(filterVO.getStartDate()))
					searchEffStartDate = filterVO.getStartDate();
				
				if ( ! StringUtil.isNullOrEmpty(filterVO.getEndDate()))
					searchEffEndDate = filterVO.getEndDate();
				
				if ( ! StringUtil.isNullOrEmpty(filterVO.getParameterCode()))
					searchParmCode = filterVO.getParameterCode();
				
				if ( ! StringUtil.isNullOrEmpty(filterVO.getPbpId()))
					searchPbpId = filterVO.getPbpId();			
				
				if ( ! StringUtil.isNullOrEmpty(filterVO.getSegmentId()))
					searchSegmentId = filterVO.getSegmentId();
				
				/*
				 //get search status code
				  if(filterVO.getDiscrpStatus()!=null){
				  searchStatusCode = filterVO.getDiscrpStatus();
				  CodeCacheMasterService codeCache=new CodeCacheMasterService();
				  NameValuePair[] discrpStatusArr = codeCache.getDiscrpStatusArr();
				  String statusDes = null;
				  if(discrpStatusArr != null){
				  for(int i=0;i<discrpStatusArr.length;i++){
				  if(discrpStatusArr[i]!=null && discrpStatusArr[i].getName().equals(searchStatusCode)){
				  statusDes = discrpStatusArr[i].getValue();
				  break;
				  }
				  }
				  }
				  if(statusDes != null){
				  searchStatusCode = statusDes;
				  }else{
				  statusDes = (String)Constants.DISCRP_STATUS_MAP.get(searchStatusCode);
				  if(statusDes!=null)
				  searchStatusCode = statusDes;
				  }
				  }
				  */
				/*
				 //get search type code
				  if(filterVO.getDiscrpCd()!=null){
				  searchTypeCode = filterVO.getDiscrpCd();
				  }
				  
				  CodeCacheMasterService codeCache=new CodeCacheMasterService();
				  Map temDiscrpMap = codeCache.getDiscrpArrMap();
				  DiscrepancyCdVO discrepancyCdVO = null;
				  if(temDiscrpMap!=null){
				  Map partCDiscMap = (Map)temDiscrpMap.get(Constants.PARTC_DISCRP_CD_MAP);
				  if(partCDiscMap != null)
				  discrepancyCdVO  = (DiscrepancyCdVO)partCDiscMap.get(searchTypeCode);
				  if(discrepancyCdVO == null){
				  Map partDDiscMap = (Map)temDiscrpMap.get(Constants.PARTD_DISCRP_CD_MAP);
				  if(partDDiscMap != null)
				  discrepancyCdVO  = (DiscrepancyCdVO)partDDiscMap.get(searchTypeCode);
				  }
				  if(discrepancyCdVO != null && discrepancyCdVO.getDiscrpShortName()!=null){
				  searchTypeCode=searchTypeCode+"-"+discrepancyCdVO.getDiscrpShortName();
				  }			
				  }
				  */
			}
			
			//write heading row
			stream.write((PROFILE_DETAIL_HEADING+LINE_SEPARATOR).getBytes());
			String move="current";
			Map detailmap = null;
			Map detailpbpmap = null;
			
			//for ALL, get MAXRECORDCOUNT and set move to 'first' to fetch records from start
			if(Constants.CONSTANTS_ALL.equals(uiContextRange) && profileMap!=null){
				CodeCacheService codeCache=new CodeCacheService();
				Integer maxRecordCount=codeCache.getMaxRecordCount();
				
				// Fetch the correct detailMap 
				if ( Constants.PARTC.equals(filterVO.getPartName())){
					detailmap =  profileMap != null ?(Map)profileMap.get(Constants.PARTC_PROFILE_DETAIL_MAP) :null ;
					searchPartInd = "C";
				}else{
					detailmap =  profileMap != null ?(Map)profileMap.get(Constants.PARTD_PROFILE_DETAIL_MAP) :null ;
					detailpbpmap =  profileMap != null ?(Map)profileMap.get(Constants.PARTD_PBP_PROFILE_DETAIL_MAP) :null ;
					searchPartInd = "D";
				}		
				
				//Reset the navigation direction and the max record count for the profile data 
				if ( detailmap != null){
					detailmap.put(Constants.SESSION_MAX_RECORD_COUNT,maxRecordCount);
					detailmap.put(Constants.UI_CONTEXT_RANGE,Constants.CONSTANTS_ALL);
					move = "first";
				}
				if ( detailpbpmap != null ){
					detailpbpmap.put(Constants.SESSION_MAX_RECORD_COUNT,maxRecordCount);
					detailpbpmap.put(Constants.UI_CONTEXT_RANGE,Constants.CONSTANTS_ALL);
					move = "first";
				}
				
			}		
			
			ProfileService profileService = new ProfileService(this.dbId);
			ProfileSearchDetailVO profileSearchDetailVO = null;
			
			//for ALL, fetch records only for part C, if part C's row is selected or fetch records only for part D, if part D's row is selected  
			if(Constants.CONSTANTS_ALL.equals(uiContextRange)){
				String partName = filterVO.getPartName();
				profileSearchDetailVO = profileService.getProfileSearchDetailVO(filterVO, profileMap, move, planMap, partDFetchListInd, profileArrMap, menuName, profileDateRangeMap);
				filterVO.setPartName(partName);
			}else{
				profileSearchDetailVO = profileService.getProfileSearchDetailVO(filterVO, profileMap, move, planMap, partDFetchListInd, profileArrMap, menuName, profileDateRangeMap);
			}
			
			//reset no of fetching records to 10
			if(detailmap!=null) {
				detailmap.put(Constants.SESSION_MAX_RECORD_COUNT,new Integer(10));
				detailmap.remove(Constants.UI_CONTEXT_RANGE);
			}
			
			//reset no of fetching records to 10
			if(detailpbpmap!=null) {
				detailpbpmap.put(Constants.SESSION_MAX_RECORD_COUNT,new Integer(10));
				detailpbpmap.remove(Constants.UI_CONTEXT_RANGE);
			}
			
			if(profileSearchDetailVO!=null){
				ProfileSearchVOList profileListPartC =profileSearchDetailVO.getPartCProfileSearchVOList();
				ProfileSearchVOList profileListPartD =profileSearchDetailVO.getPartDProfileSearchVOList();
				ProfileSearchVOList profilePbpListPartD =profileSearchDetailVO.getPartDPBPProfileSearchVOList();
				
				ProfileSearchVO[] profileSearchPartCArr = null;
				ProfileSearchVO[] profileSearchPartDArr = null;
				ProfileSearchVO[] profileSearchPbpPartDArr = null;
				
				//Source, Extract Date, Plan ID, Plan Name, PBP Id, Segment Id, Start Date, End Date, Parameter Code, Parameter Value
				
				StringBuffer rowPrefix = new StringBuffer(Constants.PROFILE_DETAIL_SOURCE_VALUE).append(",");
				rowPrefix.append(extractDate).append(",").append(planId).append(",\"").append(planName).append("\"");
				
				StringBuffer rowSuffix= new StringBuffer();			
				rowSuffix.append(filterVO.getPlanName()).append(",")
				.append(searchEffStartDate).append(",")
				.append(searchEffEndDate).append(",")
				.append(searchParmCode).append(",")
				.append(searchPbpId).append(",")
				.append(searchSegmentId);
				
				if(profileListPartC!=null ){
					profileSearchPartCArr = profileListPartC.getProfileSearchVOList();
					if ( profileSearchPartCArr != null){
						stream = (FileOutputStream)createCsvRowsForProfileDetail(profileSearchPartCArr, stream, rowPrefix,"",rowSuffix, "C" ,menuName);
					
					}
				}
				
				if(profileListPartD!=null){
					profileSearchPartDArr = profileListPartD.getProfileSearchVOList();
					if ( profileSearchPartDArr != null){
						stream = (FileOutputStream)createCsvRowsForProfileDetail(profileSearchPartDArr, stream, rowPrefix,"",rowSuffix, "D" ,menuName);
					}
				}
				
				if(profilePbpListPartD!=null){
					profileSearchPartDArr = profilePbpListPartD.getProfileSearchVOList();
					if ( profileSearchPartDArr != null){
						stream = (FileOutputStream)createCsvRowsForProfileDetail(profileSearchPartDArr, stream, rowPrefix,"",rowSuffix, "D" ,menuName);
					}
				}			
			}
			
			//stream.close();
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createProfileDetail method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createProfileDetail method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
		
	}
	
	/**
	 * This method is to create rows in Profile Detail CSV
	 * @param profileSearchVOArr
	 * @param stream
	 * @param rowPrefix
	 * @param dateType
	 * @param rowSuffix
	 * @param discInd
	 * @param menuName
	 * @return
	 * @throws IOException
	 */
	private OutputStream createCsvRowsForProfileDetail(ProfileSearchVO[] profileSearchVOArr, OutputStream stream, StringBuffer rowPrefix, String dateType, StringBuffer rowSuffix, String discInd, String menuName ) throws IOException{
		logger.info(LoggerConstants.methodStartLevel());
		try{
			ProfileSearchVO profileSearchVO;
			String startDate = "";
			String endDate = "";
			
			for(int i = 0; i < profileSearchVOArr.length; i++){
				StringBuffer profileRow = new StringBuffer(); 
				profileSearchVO = profileSearchVOArr[i];
				startDate = profileSearchVO.getStartDate();
				endDate = profileSearchVO.getEndDate();
				String frmt = profileSearchVO.getParmValueCode();
				
				profileRow.append ( rowPrefix).append(",")
				.append ( profileSearchVO.getPbpId()).append(",")
				.append ( profileSearchVO.getSegmentId()).append(",")
				.append ( (startDate == null ? "" : startDate)).append(",")
				.append ( (endDate == null ? "" : endDate)).append(",")
				.append ( profileSearchVO.getParmCode()).append(",");
				if (frmt.equals("T") || frmt.equals("I"))
					profileRow.append("\"").append ( profileSearchVO.getParmValue()).append("\"");
				else
					profileRow.append ( profileSearchVO.getParmValue());
				profileRow.append(",")
				.append ( profileSearchVO.getLastUpdtTime()).append(",")
				.append ( rowSuffix);
				((FileOutputStream)stream).write((profileRow+LINE_SEPARATOR).getBytes());
			}
		}finally{}
		logger.info(LoggerConstants.methodEndLevel());
		return stream;
	}
	
	/**
	 * for 'Reconciliation popup' export
	 * @author hemant
	 * @param filterVO
	 * @param planMap
	 * @param pageStatus
	 * @return
	 * @throws ApplicationException
	 */
	public String createPopupReconciliation(FilterVO filterVO, Map planMap, List pageStatus)throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		
		String planId = null;
		String planName = null;
		String dateType = null;
		String date = null;
		String partInd = null;
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;;
		
		try {
			stream = new FileOutputStream(new File(fileName));	
			//write heading row
			stream.write((RECONCIALIATION_POPUP+LINE_SEPARATOR).getBytes());
			
			BeneficiaryService service = new BeneficiaryService(dbId);
			ReconciliationListVO reconListVO = service.getReconcilationList(filterVO, planMap);
			
			if(reconListVO!=null){
				String hicNbr=null;
				if(filterVO!=null){
					hicNbr = StringUtil.nonNullTrim(filterVO.getHicNumber());
					if(filterVO.getPlanName()!=null)
						planId = filterVO.getPlanName();
					planName = planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(planId, planMap, false)) : "";
					dateType = filterVO.getDateType();
					date = DateUtil.getFirstOrLastDayOfMonth(StringUtil.nonNullTrim(filterVO.getStartDate()),true);
				}
				
				StringBuffer rowPrefix = new StringBuffer(Constants.RECONCIALIATION_SOURCE_VALUE).append(",")
				.append(extractDate).append(",").append(planId).append(",\"").append(planName)
				.append("\",").append(hicNbr).append(",").append(date).append(",").append(dateType).append(",");
				
				//add part C rows
				
				List reconListVOArr = reconListVO.getPartCReconciliation();
				if(reconListVOArr!=null){
					for(int i=0;i<reconListVOArr.size();i++){
						ReconciliationVO reconciliationVO = (ReconciliationVO)reconListVOArr.get(i);
						if(reconciliationVO!=null){
							StringBuffer dataRow =	new StringBuffer();						
							dataRow.append(rowPrefix)
							.append("C").append(",")
							.append(StringUtil.nonNullTrim(reconciliationVO.getDataFiled())).append(",");
							if("Disease_Groups".equals(reconciliationVO.getDataFiled())){
								dataRow.append(formatCurrencyValue(StringUtil.nonNullTrim(reconciliationVO.getDiseaseGrpCmsValue()),false)).append(",")
								.append(formatCurrencyValue(StringUtil.nonNullTrim(reconciliationVO.getDiseaseGrpPlanValue()),false)).append(",");
							}else{
								dataRow.append(formatCurrencyValue(StringUtil.nonNullTrim(reconciliationVO.getCmsValue()),false)).append(",")
								.append(formatCurrencyValue(StringUtil.nonNullTrim(reconciliationVO.getPlanValue()),false)).append(",");
							}
							
							String status = null;
							if("Disease_Groups".equals(reconciliationVO.getDataFiled())){
								if(reconciliationVO.getDiseaseGrpCmsValue().equals(Constants.DOES_NOT_MATCH)&&reconciliationVO.getDiseaseGrpPlanValue().equals(Constants.DOES_NOT_MATCH))
									status = "N";
								else{
									if(StringUtil.nonNull(reconciliationVO.getDiseaseGrpCmsValue()).equals(reconciliationVO.getDiseaseGrpPlanValue()))
										status = "Y";
									else
										status = "N";
								}	
							}else{
								if(StringUtil.nonNull(reconciliationVO.getCmsValue()).equals(reconciliationVO.getPlanValue()))
									status = "Y";
								else
									status = "N";

							}
							
							dataRow.append(StringUtil.nonNullTrim(status));
							stream.write((dataRow+LINE_SEPARATOR).getBytes());
						}
					}
				}
				
				//add part D rows
				reconListVOArr = reconListVO.getPartDReconciliation();
				if(reconListVOArr!=null){
					for(int i=0;i<reconListVOArr.size();i++){
						ReconciliationVO reconciliationVO = (ReconciliationVO)reconListVOArr.get(i);
						if(reconciliationVO!=null){
							StringBuffer dataRow =	new StringBuffer();						
							dataRow.append(rowPrefix)
							.append("D").append(",")
							.append(StringUtil.nonNullTrim(reconciliationVO.getDataFiled())).append(",");
							if("Disease_Group".equals(reconciliationVO.getDataFiled())){
								dataRow.append(formatCurrencyValue(StringUtil.nonNullTrim(reconciliationVO.getDiseaseGrpCmsValue()),false)).append(",")
								.append(formatCurrencyValue(StringUtil.nonNullTrim(reconciliationVO.getDiseaseGrpPlanValue()),false)).append(",");
							}else{
								dataRow.append(formatCurrencyValue(StringUtil.nonNullTrim(reconciliationVO.getCmsValue()),false)).append(",")
								.append(formatCurrencyValue(StringUtil.nonNullTrim(reconciliationVO.getPlanValue()),false)).append(",");
							}
							
							String status = null;
							if("Disease_Group".equals(reconciliationVO.getDataFiled())){
								if(reconciliationVO.getDiseaseGrpCmsValue().equals(Constants.DOES_NOT_MATCH)&&reconciliationVO.getDiseaseGrpPlanValue().equals(Constants.DOES_NOT_MATCH))
									status = "N";
								else{
									if(StringUtil.nonNull(reconciliationVO.getDiseaseGrpCmsValue()).equals(reconciliationVO.getDiseaseGrpPlanValue()))
										status = "Y";
									else
										status = "N";
								}	
							}else{
								if(StringUtil.nonNull(reconciliationVO.getCmsValue()).equals(reconciliationVO.getPlanValue()))
									status = "Y";
								else
									status = "N";

							}
							dataRow.append(StringUtil.nonNullTrim(status));
							stream.write((dataRow+LINE_SEPARATOR).getBytes());
						}
					}
				}
			}
		//	stream.close();
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPopupReconciliation method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPopupReconciliation method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	public String createRapsClaimsDashBoard(Connection conn, RapsContext rc) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		logger.info(LoggerConstants.methodEndLevel());
		return allDashBoardsForRaps(conn, rc, I_RAPS_CLAIMS_DASHBOARD);
}
	public String createRapsDashBoard(Connection conn, RapsContext rc) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		logger.info(LoggerConstants.methodEndLevel());
		return allDashBoardsForRaps(conn, rc, I_RAPS_DASHBOARD);
	}

	public String createRapsStatistics(Connection conn, RapsContext rc) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		logger.info(LoggerConstants.methodEndLevel());
		return allDashBoardsForRaps(conn, rc, I_RAPS_STATISTIC);
	}
	
	private String allDashBoardsForRaps(Connection conn, RapsContext rc, int pageIndex) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		String hicNbr = "ALL";
		String mbi= "ALL";
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;
		String claimID = "ALL";
		String searchStartDate = Constants.BEGIN_OF_DATE;
		String searchEndDate = Constants.END_OF_DATE;
		String searchPlanId = "ALL";
		RapsFilter filter = null;
		DashBoardItem[] arr = null;
		try {
			RapsService rapsService = new RapsService();
			stream = new FileOutputStream(new File(fileName));
			//Note: For CSV, always generate everything.
		    List expandedItems = new ArrayList();
		    expandedItems.add(Constants.CONSTANTS_ALL);
		    String source = null;
			switch (pageIndex) {
			case I_RAPS_CLAIMS_DASHBOARD: 
				source = Constants.RAPS_CLAIM_DASHBOARD_SOURCE_VALUE;
				//SSNRI 2017 : start
				//stream.write(("Source,Extract Date,Plan ID,Plan Name,Date,Single Claims,Multiple Claims,With HCCs,Without HCCs,Total Claims,Search Plan ID,Search Start Date,Search End Date,Search Hic"+LINE_SEPARATOR).getBytes());
				stream.write(("Source,Extract Date,Plan ID,Plan Name,Date,Single Claims,Multiple Claims,With HCCs,Without HCCs,Total Claims,Search Plan ID,Search Start Date,Search End Date,Search HIC,Search Medicare ID"+LINE_SEPARATOR).getBytes());
				//SSNRI 2017 :end
				filter = rc.getClaimsDashboardFilter();
				arr =  rapsService.getRapsClaimsDashBoard(conn, rc, filter, expandedItems);
				break;
			case I_RAPS_DASHBOARD:
				source = Constants.RAPS_CLUSTER_DASHBOARD_SOURCE_VALUE;
				//SSNRI 2017 : start
				//stream.write(("Source,Extract Date,Plan ID,Plan Name,Date,CMS Pending,CMS Accepted,CMS Rejected,Enroll Error,Deleted,Total,Search Plan ID,Search Start Date,Search End Date,Search Hic"+LINE_SEPARATOR).getBytes());
				stream.write(("Source,Extract Date,Plan ID,Plan Name,Date,CMS Pending,CMS Accepted,CMS Rejected,Enroll Error,Deleted,Total,Search Plan ID,Search Start Date,Search End Date,Search HIC,Search Medicare ID"+LINE_SEPARATOR).getBytes());
				//SSNRI 2017 : end
				filter = rc.getRapsDashboardFilter();
				arr =  rapsService.getRapsDashBoard(conn, rc, filter, expandedItems);
				break;
			case I_RAPS_STATISTIC:
				source = Constants.RAPS_STATISTIC_SOURCE_VALUE;
				stream.write(("Source,Extract Date,Plan ID,Plan Name,Date,File Submitted,Claims Processed,All Diagnoses,Non-HCC Diagnoses,Duplicate Clusters,Submitted To CMS,CMS Rejected"+LINE_SEPARATOR).getBytes());
				arr =  rapsService.getStatistics(conn, rc, expandedItems);
				break;
			}			
			String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
			if (filter != null) {
				if (filter.getPlanName()!=null)
					searchPlanId = "\"" + filter.getPlanName()+ "\"";
				if (filter.getFromDate() != null)
					searchStartDate = DateUtil.getFirstOrLastDayOfMonth(filter.getFromDate(), true);
				if (filter.getToDate() != null)
					searchEndDate = DateUtil.getFirstOrLastDayOfMonth(filter.getToDate(), false);	
				if (filter.getHicNbr() != null)
					hicNbr = filter.getHicNbr();
				if (filter.getMbi() != null)
					mbi = filter.getMbi();
			}

			if(arr != null){
				for(int i=0; i<arr.length; i++){
					if(arr[i] != null){
						String rollUpId = arr[i].getRollupId();
						//rollUpName will be something like : H9988 - Triple-s, Inc.
						String rollUpName = rc.getPlanName(rollUpId);
						if (rollUpId.length() + 3 < rollUpName.length())
							rollUpName = "\"" + rc.getPlanName(rollUpId).substring(rollUpId.length() + 3) + "\"";
						DashBoardItem[] yearVOArray = arr[i].getChildren();
						if(yearVOArray!=null){
							for(int j=0; j<yearVOArray.length; j++){
								if(yearVOArray[j] != null){
									String year = yearVOArray[j].getRollupId();
									DashBoardItem[] monthVOArray = yearVOArray[j].getChildren();
									if(monthVOArray != null){
										for(int k=0; k<monthVOArray.length;k++){
											if(monthVOArray[k]!=null){
												String monthName = monthVOArray[k].getRollupId();
												int month= Integer.parseInt((DateUtil.convetMonthToNumericValue(monthName)));
												String date = month+"/1/"+year;
												
												StringBuffer dashBoardRow = new StringBuffer(source);
												dashBoardRow.append(",").append(extractDate)
												.append(",").append(rollUpId)
												.append(",").append(rollUpName)
												.append(",").append(date);
												switch (pageIndex) {
												case I_RAPS_CLAIMS_DASHBOARD: 
													RapsClaimDashBoard item1 = (RapsClaimDashBoard)monthVOArray[k];
													dashBoardRow.append(",").append(item1.getSingle())
													.append(",").append(item1.getMultiple())
													.append(",").append(item1.getHasHCCs())
													.append(",").append(item1.getNoHCCs())
													.append(",").append(item1.getTotal())
													.append(",").append(searchPlanId)
													.append(",").append(searchStartDate)
													.append(",").append(searchEndDate)
													.append(",").append(hicNbr)
													.append(",").append(mbi);
													break;
												case I_RAPS_DASHBOARD:
													RapsDashBoard item2 = (RapsDashBoard) monthVOArray[k];
													dashBoardRow.append(",").append(item2.getCmsPending())
													.append(",").append(item2.getCmsAccepted())
													.append(",").append(item2.getCmsRejected())
													.append(",").append(item2.getEnrollError())
													.append(",").append(item2.getDeleted())
													.append(",").append(item2.getTotal())
													.append(",").append(searchPlanId)
													.append(",").append(searchStartDate)
													.append(",").append(searchEndDate)
													.append(",").append(hicNbr)
													.append(",").append(mbi);
													break;
												case I_RAPS_STATISTIC:
													RapsStatisticItem item3 = (RapsStatisticItem)monthVOArray[k];
													dashBoardRow.append(",").append(item3.getFilesSubmitted())
													.append(",").append(item3.getClaimsProcessed())
													.append(",").append(item3.getAllDiagnoses())
													.append(",").append(item3.getNonHCCDiagnoses())
													.append(",").append(item3.getDuplicateClusters())
													.append(",").append(item3.getSubmittedToCMS())
													.append(",").append(item3.getCmsRejected());
													break;
												}			

												stream.write((dashBoardRow+LINE_SEPARATOR).getBytes());
											}
										} // end of Month array loop
									}
								}
							} // end of Year array loop
						}
					}	
				} // end of plan array loop			
			}
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createRapsDashBoard method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createRapsDashBoard method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	
	public String createRapsClaimDetail(Connection conn, RapsContext rc, String uiContextRange ) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		FileOutputStream stream = null;
		String fileName = getCvsFileName();		
		try {
			//Get search criteria
			RapsFilter filter = rc.getClaimsDetailFilter();
			StringBuffer searchCriteria = new StringBuffer();			
			if (filter != null) {
				String temp = StringUtil.trimToNull(filter.getPlanName());
				searchCriteria.append(",").append(temp==null? "ALL" : temp); //planId
				temp = StringUtil.trimToNull(filter.getHicNbr());
				searchCriteria.append(",").append(temp==null? "" : temp); //hic number
				temp = StringUtil.trimToNull(filter.getMbi());
				searchCriteria.append(",").append(temp==null? "" : temp); //mbi number
				temp = StringUtil.trimToNull(filter.getClaimId());
				searchCriteria.append(",").append(temp==null? "" : temp); //claim ID
				temp = StringUtil.trimToNull(filter.getFromDate());
				searchCriteria.append(",").append(temp==null? Constants.BEGIN_OF_DATE : temp); //from date
				temp = StringUtil.trimToNull(filter.getToDate());	
				searchCriteria.append(",").append(temp==null? Constants.END_OF_DATE : temp); //to date
			}	
			else
				searchCriteria.append(",ALL,,,,").append(Constants.BEGIN_OF_DATE).append(",").append(Constants.END_OF_DATE);
			
			//get the data
			String move = "current";
	        Pagination pagination = rc.getClaimsDetailsPagination();
			if(Constants.CONSTANTS_ALL.equals(uiContextRange)){
				CodeCacheService codeCache=new CodeCacheService();
				Integer maxRecordCount=codeCache.getMaxRecordCount();
				pagination.setMaxRecordCount(maxRecordCount.intValue());
				pagination.setAllPage(true);
				move = "first";
			}			
			RapsService rapsService = new RapsService();
	        RapsClaimsDetailPage detailPage = rapsService.getClaimsDetailPage(conn, rc, rc.getClaimsDetailFilter(), move);
			pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
			pagination.setAllPage(false);

			//Build output
			stream = new FileOutputStream(new File(fileName));
			//SSNRI 2017 : start
			//stream.write(("Source,Extract Date,Claim ID,Version,Submission Date,HIC Number,Multiple,HCCs,Search Plan ID,Search Hic,Search Claim ID,Search Start Date,Search End Date"+LINE_SEPARATOR).getBytes());
			stream.write(("Source,Extract Date,Claim ID,Version,Submission Date,HIC Number,Medicare ID,Multiple,HCCs,Search Plan ID,Search Hic,Search Medicare ID,Search Claim ID,Search Start Date,Search End Date"+LINE_SEPARATOR).getBytes());
			//SSNRI 2017 : end
			RapsClaimDetailItem[] items = detailPage.getClaimsList();
			if (items != null) {
				String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
				for (int i = 0; i < items.length; i++) {
					RapsClaimDetailItem item = items[i];
					StringBuffer row = new StringBuffer(Constants.RAPS_CLAIM_DETAIL_SOURCE_VALUE);
					row.append(",").append(extractDate)
					.append(",").append(item.getClaimId())
					.append(",").append(item.getVersion())
					.append(",").append(item.getSubmissionDate())
					.append(",").append(item.getHicNumber())
					.append(",").append(item.getMbi())
					.append(",").append(item.getMultiple())
					.append(",").append(item.getHcc())
					.append(searchCriteria);
					stream.write((row+LINE_SEPARATOR).getBytes());
				}
			}
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createRapsDashBoard method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createRapsClaimDetail method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	
	public String createRapsDetail(Connection conn, RapsContext rc, String uiContextRange ) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		FileOutputStream stream = null;
		String fileName = getCvsFileName();		
		try {
			//Get search criteria
			RapsFilter filter = rc.getRapsDetailFilter();
			StringBuffer searchCriteria = new StringBuffer();
			if (filter != null) {
				String temp = StringUtil.trimToNull(filter.getPlanName());
				searchCriteria.append(",").append(temp==null? "ALL" : temp); //planId
				temp = StringUtil.trimToNull(filter.getHicNbr());
				searchCriteria.append(",").append(temp==null? "ALL" : temp); //hic number
				temp = StringUtil.trimToNull(filter.getMbi());
				searchCriteria.append(",").append(temp==null? "ALL" : temp); //mbi number
				temp = StringUtil.trimToNull(filter.getStatus());
				searchCriteria.append(",").append(temp==null? "ALL" : temp); //Status
				temp = StringUtil.trimToNull(filter.getFromDate());
				searchCriteria.append(",").append(temp==null? Constants.BEGIN_OF_DATE : temp); //from date
				temp = StringUtil.trimToNull(filter.getToDate());	
				searchCriteria.append(",").append(temp==null? Constants.END_OF_DATE : temp); //to date
			}
			else 
				searchCriteria.append(",ALL,ALL,ALL,ALL,").append(Constants.BEGIN_OF_DATE).append(",").append(Constants.END_OF_DATE);
			
			//get the data
			String move = "current";
	        Pagination pagination = rc.getRapsDetailsPagination();
			if(Constants.CONSTANTS_ALL.equals(uiContextRange)){
				CodeCacheService codeCache=new CodeCacheService();
				Integer maxRecordCount=codeCache.getMaxRecordCount();
				pagination.setMaxRecordCount(maxRecordCount.intValue());
				pagination.setAllPage(true);
				move = "first";
			}			
			RapsService rapsService = new RapsService();
	        RapsDetailPage detailPage = rapsService.getRapsDetailPage(conn, rc, rc.getRapsDetailFilter(), move);
			pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
			pagination.setAllPage(false);

			//Build output
			stream = new FileOutputStream(new File(fileName));
			//SSNRI 2017 : start
			//stream.write(("Source,Extract Date,Plan,HIC Number,From Service,Thru Service,Status,Diagnosis Code,Diagnosis Description,HCC,RxHCC,Dup,ReSub,Search Plan ID,Search Hic,Search Status,Search Start Date,Search End Date"+LINE_SEPARATOR).getBytes());
			stream.write(("Source,Extract Date,Plan,HIC Number,Medicare ID,From Service,Thru Service,Status,Diagnosis Code,Diagnosis Description,HCC,RxHCC,Dup,ReSub,Search Plan ID,Search HIC,Search Medicare ID,Search Status,Search Start Date,Search End Date"+LINE_SEPARATOR).getBytes());
			//SSNRI 2017 : end
			RapsDetailItem[] items = detailPage.getRapsDetails();
			if (items != null) {
				String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
				for (int i = 0; i < items.length; i++) {
					RapsDetailItem item = items[i];
					StringBuffer row = new StringBuffer(Constants.RAPS_CLUSTER_DETAIL_SOURCE_VALUE);
					row.append(",").append(extractDate)
					.append(",").append(item.getPlanID()) 
					.append(",").append(item.getHicNbr())
					.append(",").append(item.getMbi())
					.append(",").append(item.getFromServiceDate())
					.append(",").append(item.getThruServiceDate())
					.append(",").append(item.getClusterStatus())
					.append(",").append(item.getDiagCode())
					.append(",\"").append(item.getDiagDescription())
					.append("\",").append(item.getHcc())
					.append(",").append(item.getRxhcc())
					.append(",").append(item.getDup())
					.append(",").append(item.getResub());
					row.append(searchCriteria);
					stream.write((row+LINE_SEPARATOR).getBytes());
				}
			}
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createRapsDashBoard method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createRapsClaimDetail method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}	
	public String createClaimDetailPopup(Connection conn, RapsContext context) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("createCSV: createClaimDetailPopup shouldn't be called");
		logger.info(LoggerConstants.methodEndLevel());
		throw new ApplicationException("createClaimDetailPopup shouldn't be called");
	}
	public String createRapsDetailPopup(Connection conn, RapsContext context) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("createCSV: createRapsDetailPopup shouldn't be called");
		logger.info(LoggerConstants.methodEndLevel());
		throw new ApplicationException("createRapsDetailPopup shouldn't be called");
	}

	public String createReInsurance(ReinsuranceContext context) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String fileName = getCvsFileName();		
		FilterVO filter = context.getFilter();
		FileOutputStream stream = null;;
		try {
			List items = context.getReinddirItems();
			stream = new FileOutputStream(new File(fileName));	
			String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
			//write heading row
			
			String tableType = "Source, Extract Date, Plan ID, PBP Id, Year, Quarter, DDIR Amount (rebates),"; //5 column
			String sourceType = Constants.REINSURANCE_SOURCE_VALUE;
			if (context.getLastAction() == ReinsuranceContext.UPDATED) {
				tableType = tableType.concat("Update Status,"); //6 column
				sourceType = Constants.REINSURANCESTATUS_SOURCE_VALUE;
			}
			stream.write((tableType +" Search Plan ID, Search Year, Search End Year, Search PBP ID"+LINE_SEPARATOR).getBytes());
			if (items == null)
				return fileName;
			StringBuffer rowPrefix = new StringBuffer(sourceType).append(",")
			.append(extractDate).append(",").append(filter.getPlanName()).append(",");
			StringBuffer rowSuffix = new StringBuffer(filter.getPlanName()).append(",")
			.append(filter.getStartDate()).append(",")
			.append(filter.getEndDate()).append(",")
			.append(filter.getPbpId());
			Iterator it = items.iterator();
			while (it.hasNext()) {
				ReinddirItem item = (ReinddirItem)it.next();
				StringBuffer reinsuranceRow = new StringBuffer(); 			
				reinsuranceRow.append ( rowPrefix)
				.append(item.getPbpId()).append(",")
				.append(item.getYear()).append(",")
				.append(item.getQuarter()).append(",")
				.append(item.getAmount()).append(",");
				if (context.getLastAction() == ReinsuranceContext.UPDATED)
					reinsuranceRow.append(item.getStatusTxt()).append(",");
				reinsuranceRow.append ( rowSuffix);
				((FileOutputStream)stream).write((reinsuranceRow+LINE_SEPARATOR).getBytes());
			}
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPopupReconciliation method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPopupReconciliation method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	public String createAnnualRecon(ReinsuranceContext context, String pageName) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String fileName = getCvsFileName();	
		FileOutputStream stream = null;;
		try {
			
			FilterVO filter = null; 
			ReinsuranceService reinsuranceService = new ReinsuranceService(dbId);
			StringBuffer header = new StringBuffer("");
			
			stream = new FileOutputStream(new File(fileName));	
			String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
			//write heading row
			List items = null;
			StringBuffer tableType =  new StringBuffer("Source, Extract Date, PBP Id, "); 
			String source = null;
			if (Constants.PAGE_FORECASTSUM.equals(pageName)) {
				filter = context.getSummaryFilter();
				items = reinsuranceService.forecastSummary(filter, header);
				tableType.append("LICS RECON, REIN RECON, RISK RECON, CGAP RECON, TOTAL RECON");	//Added for CGAP Screen IFOX-00432723
				source = Constants.FORECASTSUM_SOURCE_VALUE;		
			} else if (Constants.PAGE_LICS_DETAIL.equals(pageName)) {
				filter = context.getDetailFilter();
				items = reinsuranceService.licsDetail(filter, header);
				tableType.append("Quarter, Product Id, Prosp LICS, Actual LICS, LICS RECON");
				source = Constants.LICSRECON_SOURCE_VALUE;
			} 
			//Added for CGAP Screen IFOX-00432723 :: START
			else if (Constants.PAGE_CGAP_DETAIL.equals(pageName)) {
				filter = context.getDetailFilter();
				items = reinsuranceService.cgapDetail(filter, header);
				tableType.append("Quarter, Product Id, Prosp CGAP, Actual CGAP, CGAP RECON");
				source = Constants.CGAPRECON_SOURCE_VALUE;
			} 
			//Added for CGAP Screen IFOX-00432723 :: END
			else if (Constants.PAGE_REIN_DETAIL.equals(pageName)) {
				filter = context.getDetailFilter();
				items = reinsuranceService.reinDetail(filter, header);
				source = Constants.REINRECON_SOURCE_VALUE;
				tableType.append("Quarter, Product Id, Prosp Reins,GDCB, GDCA, GDCT,");
				tableType.append("Dir Ratio, DDIR, Reins Dir, Allow Reins, Reins Subs, Rein Recon, Ddir Used");
				source = Constants.REINRECON_SOURCE_VALUE;
			} else if (Constants.PAGE_RISK_DETAIL.equals(pageName)) {
				filter = context.getDetailFilter();
				items = reinsuranceService.riskRecon(filter, header);
				source = Constants.RISKRECON_SOURCE_VALUE;
				tableType.append("Quarter, Product Id, Reins Subs, DDIR, Non Pharm Amt, Gain Loss Amt, Basic Bid,")
				.append("AC Ratio, DRSB Amt, Prem Amt, Target Amt, STLL Ratio, STLL Amt, FTLL Ratio,")
				.append("FTLL Amt, FTUL Ratio, FTUL Amt, STUL Ratio, STUL Amt, URCC Amt, AARCC Amt, ")
				.append("Risk Apply Ind, AARC Ind, Over STUL RCV, Over FTUL RCV, Under FTLL Pay, Under STLL Pay, Risk Recon");
				source = Constants.RISKRECON_SOURCE_VALUE;
			}
			tableType.append(", Search Plan ID, Search Year, Search PBP ID");

			stream.write((tableType + LINE_SEPARATOR).getBytes());
			String sourceType = source;
			if (items == null)
				return fileName;
			StringBuffer rowPrefix = new StringBuffer(sourceType).append(",").append(extractDate).append(",");
			StringBuffer rowSuffix = new StringBuffer(filter.getPlanName()).append(",")
			.append(filter.getStartDate().substring(0,4)).append(",").append(filter.getPbpId());
			Iterator it = items.iterator();
			NumberFormat nf = NumberFormat.getCurrencyInstance();
			while (it.hasNext()) {
				StringBuffer reinsuranceRow = new StringBuffer(rowPrefix.toString());
				if (Constants.PAGE_FORECASTSUM.equals(pageName)) {
					PartDForeCastItem item = (PartDForeCastItem)it.next();
					reinsuranceRow.append(item.getPbpId()).append(",")
					.append(formatCurrencyValue(item.getFormattedLicsReconAmt(), false)).append(",")
					.append(formatCurrencyValue(item.getFormattedReinReconAmt(), false)).append(",")
					.append(formatCurrencyValue(item.getFormattedRiskReconAmt(), false)).append(",")
					.append(formatCurrencyValue(item.getFormattedCgapReconAmt(), false)).append(",")	//Added for CGAP Screen IFOX-00432723
					.append(formatCurrencyValue(item.getFormattedTotalReconAmt(), false)).append(",");
				} else if (Constants.PAGE_LICS_DETAIL.equals(pageName)) {
					LicsReconItem item = (LicsReconItem)it.next();
					reinsuranceRow.append(item.getPbpId()).append(",")
					.append(item.getQuarter()).append(",").append(item.getProductId()).append(",")
					.append(convertDoubleToAmt(nf,item.getProspectiveAmount()))
					.append(convertDoubleToAmt(nf, item.getActualAmount()))
					.append(convertDoubleToAmt(nf, item.getLicsRecon()));
				} 
				//Added for CGAP Screen IFOX-00432723 :: START
				else if (Constants.PAGE_CGAP_DETAIL.equals(pageName)) {
					CgapReconItem item = (CgapReconItem)it.next();
					reinsuranceRow.append(item.getPbpId()).append(",")
					.append(item.getQuarter()).append(",").append(item.getProductId()).append(",")
					.append(convertDoubleToAmt(nf,item.getProspectiveAmount()))
					.append(convertDoubleToAmt(nf, item.getActualAmount()))
					.append(convertDoubleToAmt(nf, item.getCgapRecon()));
				} 
				//Added for CGAP Screen IFOX-00432723 :: END
				else if (Constants.PAGE_REIN_DETAIL.equals(pageName)) {
					ReinReconItem item = (ReinReconItem) it.next();
					reinsuranceRow.append(item.getPbpId()).append(",")
					.append(item.getQuarter()).append(",").append(item.getProductId()).append(",")
					.append(convertDoubleToAmt(nf, item.getProspReins()))
					.append(convertDoubleToAmt(nf, item.getGdcb()))
					.append(convertDoubleToAmt(nf, item.getGdca()))
					.append(convertDoubleToAmt(nf, item.getGdct()))
					.append(item.getDirRatio()).append(",")
					.append(convertDoubleToAmt(nf, item.getDdirAmt()))
					.append(convertDoubleToAmt(nf, item.getReinsDir()))
					.append(convertDoubleToAmt(nf, item.getAllowReins()))
					.append(convertDoubleToAmt(nf, item.getReinsSub()))
					.append(convertDoubleToAmt(nf, item.getReinRecon()))
					.append(item.getDdirUsed()).append(",");
				} else if (Constants.PAGE_RISK_DETAIL.equals(pageName)) {
					RiskReconItem item = (RiskReconItem)it.next();
					reinsuranceRow.append(item.getPbpId()).append(",")
					.append(item.getQuarter()).append(",").append(item.getProductId()).append(",")
					.append(convertDoubleToAmt(nf, item.getReinsSub()))
					.append(convertDoubleToAmt(nf, item.getDdir()))
					.append(convertDoubleToAmt(nf, item.getNonPharmAmt()))
					.append(convertDoubleToAmt(nf, item.getGainLostAmt()))
					.append(convertDoubleToAmt(nf, item.getBasicBid()))
					.append(item.getAcRatio()).append(",")
					.append(convertDoubleToAmt(nf, item.getDrsbAmt()))
					.append(convertDoubleToAmt(nf, item.getPremAmt()))
					.append(convertDoubleToAmt(nf, item.getTargetAmt()))
					.append(item.getStllRatio()).append(",")
					.append(convertDoubleToAmt(nf, item.getStllAmt()))
					.append(item.getFtllRatio()).append(",")
					.append(convertDoubleToAmt(nf, item.getFtllAmt()))
					.append(item.getFtulRatio()).append(",")
					.append(convertDoubleToAmt(nf, item.getFtulAmt()))
					.append(item.getStulRatio()).append(",")
					.append(convertDoubleToAmt(nf, item.getStulAmt()))
					.append(convertDoubleToAmt(nf, item.getUrccAmt()))
					.append(convertDoubleToAmt(nf, item.getAarccAmt()))
					.append(item.getRiskApplyInd()).append(",")
					.append(item.getAarcInd()).append(",")
					.append(convertDoubleToAmt(nf, item.getOverStulRcv()))
					.append(convertDoubleToAmt(nf, item.getOverFtulRcv()))
					.append(convertDoubleToAmt(nf, item.getUnderFtllPay()))
					.append(convertDoubleToAmt(nf, item.getUnderStllPay()))
					.append(convertDoubleToAmt(nf, item.getRiskRecon()));
				}
				reinsuranceRow.append ( rowSuffix);
				((FileOutputStream)stream).write((reinsuranceRow+LINE_SEPARATOR).getBytes());
			}
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in foreCastSummary method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in foreCastSummary method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;		
	}
	
	private String convertDoubleToAmt(NumberFormat nf, double d) {
		logger.info(LoggerConstants.methodStartLevel());
		logger.info(LoggerConstants.methodEndLevel());
		return (formatCurrencyValue(nf.format(d), false)+ ",");
	}
	
	public String createRapsErrors(Connection conn, RapsContext rc, String uiContextRange ) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		FileOutputStream stream = null;
		String fileName = getCvsFileName();		
		try {
			//Get search criteria
			RapsFilter filter = rc.getRapsErrorsFilter();
			StringBuffer searchCriteria = new StringBuffer();
			if (filter != null) {
				String temp = StringUtil.trimToNull(filter.getPlanName());
				searchCriteria.append(",").append(temp==null? "ALL" : temp); //planId
				temp = StringUtil.trimToNull(filter.getHicNbr());
				searchCriteria.append(",").append(temp==null? "ALL" : temp); //hic number
				temp = StringUtil.trimToNull(filter.getMbi());
				searchCriteria.append(",").append(temp==null? "ALL" : temp); //mbi number
				temp = StringUtil.trimToNull(filter.getStatus());
				searchCriteria.append(",").append(temp==null? "ALL" : temp); //Status
				temp = StringUtil.trimToNull(filter.getFromDate());
				searchCriteria.append(",").append(temp==null? Constants.BEGIN_OF_DATE : temp); //from date
				temp = StringUtil.trimToNull(filter.getToDate());	
				searchCriteria.append(",").append(temp==null? Constants.END_OF_DATE : temp); //to date
			}
			else 
				searchCriteria.append(",ALL,ALL,ALL,").append(Constants.BEGIN_OF_DATE).append(",").append(Constants.END_OF_DATE);
			
			//get the data
			String move = "current";
	        Pagination pagination = rc.getRapsErrorsPagination();
			if(Constants.CONSTANTS_ALL.equals(uiContextRange)){
				CodeCacheService codeCache=new CodeCacheService();
				Integer maxRecordCount=codeCache.getMaxRecordCount();
				pagination.setMaxRecordCount(maxRecordCount.intValue());
				pagination.setAllPage(true);
				move = "first";
			}			
			RapsService rapsService = new RapsService();
	        RapsErrorsPage errorsPage = rapsService.getRapsErrorsPage(conn, rc, rc.getRapsErrorsFilter(), move);
			pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
			pagination.setAllPage(false);

			//Build output
			stream = new FileOutputStream(new File(fileName));
			//SSNRI 2017 : start
			/*stream.write(("Source,Extract Date,Plan,HIC Number,From Service,Thru Service,Status,Diagnosis Code,Diagnosis Description,Dup, ReSub," +
						  "Provider Type,DC Type,Claim Id," +
					      "Patient Control Nbr,PrtC HCC Category1,PrtC HCC Category2,PrtD HCC Category1,PrtD HCC Category2,Esrd HCC Category1,Esrd HCC Category2," +
					      "CCC Seq Error Cd,Hic Error Cd,Corrected Hic Nbr,DC Error Cluster1,DC Error Cluster2,Delete Ind,Error Work Status Cd," +
					      "Search Plan ID,Search Hic,Search Status,Search Start Date,Search End Date"+LINE_SEPARATOR).getBytes());*/
			stream.write(("Source,Extract Date,Plan,HIC,Medicare ID,From Service,Thru Service,Status,Diagnosis Code,Diagnosis Description,Dup, ReSub," +
					  "Provider Type,DC Type,Claim Id," +
				      "Patient Control Nbr,PrtC HCC Category1,PrtC HCC Category2,PrtD HCC Category1,PrtD HCC Category2,Esrd HCC Category1,Esrd HCC Category2," +
				      "CCC Seq Error Cd,Medicare ID Error Cd,Corrected Medicare ID,DC Error Cluster1,DC Error Cluster2,Delete Ind,Error Work Status Cd," +
				      "Search Plan ID,Search HIC,Search Medicare ID,Search Status,Search Start Date,Search End Date"+LINE_SEPARATOR).getBytes());
			//SSNRI 2017 : end
			RapsErrorsItem[] items = errorsPage.getRapsErrors();
			if (items != null) {
				String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
				for (int i = 0; i < items.length; i++) {
					RapsErrorsItem item = items[i];
					// TODO find out what the value of Constants.RAPS_CLUSTER_DETAIL_SOURCE_VALUE is for
					StringBuffer row = new StringBuffer(Constants.RAPS_ERRORS_DETAIL_SOURCE_VALUE);
					row.append(",").append(extractDate)
					.append(",").append(item.getPlanID()) 
					.append(",").append(item.getHicNbr())
					.append(",").append(item.getMbi())
					.append(",").append(item.getFromServiceDate())
					.append(",").append(item.getThruServiceDate())
					.append(",").append(item.getClusterStatus())
					.append(",").append(item.getDiagCode())
					.append(",\"").append(item.getDiagDescription())
					.append("\",").append(item.getDup())
					.append(",").append(item.getResub())
					.append(",").append(item.getProviderType())
					.append(",").append(item.getDcType());
					
					if (item.getSourceType().equals("CLM"))
						row.append(",").append(item.getClaimId());
					else
						row.append(",");
					
					row.append(",").append(item.getPatientCtrlNbr())
					.append(",").append(item.getPrtCHccCategory1())
					.append(",").append(item.getPrtCHccCategory2())
					.append(",").append(item.getPrtDHccCategory1())
					.append(",").append(item.getPrtDHccCategory2())
					.append(",").append(item.getEsrdHccCategory1())
					.append(",").append(item.getEsrdHccCategory2())
					.append(",").append(item.getCccSeqErrCd())
					.append(",").append(item.getHicErrCd())
					.append(",").append(item.getCorrectedHicNbr())
					.append(",").append(item.getDcErrCluster1())
					.append(",").append(item.getDcErrCluster2())
					.append(",").append(item.getDeleteInd())
					.append(",").append(item.getErrorWorkStatusCode());
					
					row.append(searchCriteria);
					stream.write((row+LINE_SEPARATOR).getBytes());
				}
			}
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createRapsErrorrs method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createRapsErrors method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}

	public String createPdeErrDb(FilterVO filterVO, Map planMap, PdeContext context) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String dateType = "S";
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;
		try {
			String searchCriteria = pdeErrSearchCriteria(filterVO);
			stream = new FileOutputStream(new File(fileName));
			// drawing PDE deshboard Heading.
			stream.write((PDE_ERR_DB_HEADING+LINE_SEPARATOR).getBytes());
			
			//get data for 'PDE Dashboard' and write csv rows for it
			PdeTroopService pdeTroopService = new PdeTroopService(this.dbId);
			
			Map returnObjects = pdeTroopService.getPdeErrDashBoard(filterVO, planMap, context, false);
			GenericDashboard[] items= (GenericDashboard[])returnObjects.get("items");
			
			if(items != null){
				for(int i=0; i<items.length; i++){
					if(items[i] != null){
						String [] fieldArr = items[i].getRollupId().split("[/]");
						String rollUpId = fieldArr[0];
						String pbpId = fieldArr[1];						
						String rollUpName = planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(rollUpId, planMap, false)) : "";
						GenericDashboard[] yearVOArray = (GenericDashboard[])items[i].getChildren();
						if(yearVOArray!=null){
							for(int j=0; j<yearVOArray.length; j++){
								if(yearVOArray[j] != null){
									String year = yearVOArray[j].getRollupId();
									GenericDashboard[] monthVOArray = (GenericDashboard[])yearVOArray[j].getChildren();
									if(monthVOArray != null){
										for(int k=0; k<monthVOArray.length;k++){
											if(monthVOArray[k]!=null){
												String monthName = monthVOArray[k].getRollupId();
												int month= Integer.parseInt((DateUtil.convetMonthToNumericValue(monthName)));
												String date = month+"/1/"+year;
												
												StringBuffer dashBoardRow = new StringBuffer(Constants.PDE_ERR_DASHBOARD_SOURCE_VALUE);
												dashBoardRow.append(",").append(extractDate)
												.append(",").append(rollUpId)
												.append(",\"").append(rollUpName)
												.append("\",").append(pbpId)
												.append(",").append(date)
												.append(",").append(dateType)
												.append(",").append(monthVOArray[k].getCol1I())
												.append(",").append(monthVOArray[k].getCol2I())
												.append(",").append(monthVOArray[k].getCol3I())
												.append(",").append(monthVOArray[k].getCol4I())
												.append(searchCriteria);
												stream.write((dashBoardRow+LINE_SEPARATOR).getBytes());
											}
										} // end of Month array loop
									}
								}
							} // end of Year array loop
						}
					}	
				} // end of plan array loop
			}
			
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPopupReconciliation method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPopupReconciliation method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}

	public String createPdeErrCodes(FilterVO filterVO, Map planMap, String uiContextRange) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String dateType = "S";
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;
		
		String searchCriteria = pdeErrSearchCriteria(filterVO);
		try {
			stream = new FileOutputStream(new File(fileName));			
			// drawing PDE dashboard Heading.
			stream.write((PDE_ERR_CODES_HEADING+LINE_SEPARATOR).getBytes());
			
			//get data for 'PDE Dashboard' and write csv rows for it
			PdeTroopService pdeTroopService = new PdeTroopService(this.dbId);
			
			Map returnObjects = pdeTroopService.getPdeErrCodes(filterVO, planMap);
			GenericDashboard[] items = (GenericDashboard[])returnObjects.get("items");
			StringBuffer staticElements = new StringBuffer(Constants.PDE_ERR_CODES_SOURCE_VALUE).append(",").append(extractDate);
			String planId = filterVO.getPlanName();
			String planName = planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(planId, planMap, false)) : "";
			staticElements.append(",").append(planId).append(",\"").append(planName)
			.append("\",").append(filterVO.getPbpId());
			if(items != null){
				for(int i=0; i<items.length; i++){
					String date = items[i].getRollDate();
					String fDate = date.substring(0,2)+"/1/"+date.substring(3,7);
					StringBuffer dashBoardRow = new StringBuffer(staticElements.toString())
					.append(",").append(fDate)
					.append(",").append(dateType)
					.append(",").append(items[i].getCol1S())
					.append(",").append(items[i].getCol2S())
					.append(",").append(items[i].getCol3I())
					.append(searchCriteria);
					stream.write((dashBoardRow+LINE_SEPARATOR).getBytes());
				} // end of plan array loop
			}
			
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPopupReconciliation method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPopupReconciliation method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	
	public String createPdeErrDetail(FilterVO filterVO, Map planMap, PdeContext context, String uiContextRange, String custName) throws ApplicationException{
		logger.info(LoggerConstants.methodStartLevel());
		String searchHicNbr = "";
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		String planId = "";
		String planName = "";
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;;
		try {
			stream = new FileOutputStream(new File(fileName));
			String searchCriteria = pdeErrSearchCriteria(filterVO);
			if(filterVO!=null){
				searchHicNbr = StringUtil.nonNullTrim(filterVO.getHicNumber());
				if(filterVO.getPlanName()!=null)
					planId = filterVO.getPlanName();
			}
			planName = planMap!=null ? StringUtil.nonNullTrim(ServiceHelper.getPlanName(planId, planMap, false)) : "";
			
			//write heading row
			stream.write((PDE_ERRDETAIL_HEADING+LINE_SEPARATOR).getBytes());
			

			//get the data
			String move = "current";
	        Pagination pagination = context.getErrDetailPagination();
			if(Constants.CONSTANTS_ALL.equals(uiContextRange)){
				CodeCacheService codeCache=new CodeCacheService();
				Integer maxRecordCount=codeCache.getMaxRecordCount();
				pagination.setMaxRecordCount(maxRecordCount.intValue());
				pagination.setAllPage(true);
				move = "first";
			}	
			
			//get data for CSV of PDE event detail and write CSV rows			
			PdeTroopService pdeTroopService = new PdeTroopService(this.dbId);
	        Map results = pdeTroopService.getPdeErrDetail(filterVO, pagination, move, planMap, custName, false);
	        PdeEventDetailVoList pdeEventDetailVoList =  (PdeEventDetailVoList)results.get("data");
			
			pagination.setMaxRecordCount(Constants.DB_MAX_RECORD_FETCH);
			pagination.setAllPage(false);
			
			if(pdeEventDetailVoList!=null){
				StringBuffer rowPrefix = null;
				rowPrefix = new StringBuffer(Constants.PDE_ERRDETAIL_SOURCE_VALUE);
				
				rowPrefix.append(",").append(extractDate)
				.append(",").append(planId)
				.append(",\"").append(planName).append("\",").append(filterVO.getPbpId());
				
				
				StringBuffer rowSuffix= new StringBuffer(searchCriteria).append(",").append(searchHicNbr);
				
				PdeErrDetailItem[]	pdeListObjArr = (PdeErrDetailItem[])pdeEventDetailVoList.getPdeEventDetailVOs();
				if(pdeListObjArr!=null){
					for(int i=0;i<pdeListObjArr.length;i++){
						if(pdeListObjArr[i]!=null){
							String serviceDate = pdeListObjArr[i].getShowServiceDate();
							if(serviceDate!=null && serviceDate.length()== 8){
								serviceDate = serviceDate.substring(0,4)+"/"+serviceDate.substring(4,6)+"/"+serviceDate.substring(6);
							}
							String lastUpdateDate = pdeListObjArr[i].getShowLastUpdtDate();
							if(lastUpdateDate!=null){
								lastUpdateDate = lastUpdateDate.substring(0,4)+"/"+lastUpdateDate.substring(5,7)+"/"+lastUpdateDate.substring(8);
							}
							StringBuffer pdeDetailListRow = new StringBuffer();						
							pdeDetailListRow.append(rowPrefix)			
							.append(",").append(StringUtil.nonNullTrim(pdeListObjArr[i].getHicNumber()))
							.append(",").append(StringUtil.nonNullTrim(serviceDate))
							.append(",").append(StringUtil.nonNullTrim(pdeListObjArr[i].getDetRecId()))
							.append(",").append(pdeListObjArr[i].getReferenceNumber());
							String productId = formatCurrencyValue(StringUtil.nonNullTrim(pdeListObjArr[i].getProductSvcId()),false);
							pdeDetailListRow.append(",").append(StringUtil.isNullOrEmpty(productId)?"":"=\""+productId+"\"")
							.append(",").append(formatCurrencyValue(StringUtil.nonNullTrim(lastUpdateDate),false))
							.append(rowSuffix);
							stream.write((pdeDetailListRow+LINE_SEPARATOR).getBytes());
							pdeListObjArr[i] = null;
						}
					}
				}
			}
			
			
			//stream.close();
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPdeEventDetail method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPdeEventDetail method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	
	private String pdeErrSearchCriteria(FilterVO filterVO) {
		logger.info(LoggerConstants.methodStartLevel());
		StringBuffer s = new StringBuffer("");
		String searchStartDate = Constants.BEGIN_OF_DATE;
		String searchEndDate = Constants.END_OF_DATE;
		String searchErrorCd = "ALL";
		String searchRecordId= "ALL";
		String searchPlanId = "ALL";
		String searchPbp = "ALL";
		if(filterVO!=null){
			if(filterVO.getPlanName()!=null)
				searchPlanId = filterVO.getPlanName();
			if(filterVO.getStartDate()!=null)
				searchStartDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getStartDate(),true);
			if(filterVO.getEndDate()!=null)
				searchEndDate = DateUtil.getFirstOrLastDayOfMonth(filterVO.getEndDate(),false);
			String temp = StringUtil.trimToNull(filterVO.getPdeStatus());
			if (temp != null) searchRecordId = temp;
			temp = StringUtil.trimToNull(filterVO.getDiscrpCd());
			if (temp != null) searchErrorCd = temp;
			temp = StringUtil.trimToNull(filterVO.getPbpId());
			if (temp != null) searchPbp = temp;
		}
		s.append(",").append(searchPlanId)
		.append(",").append(searchPbp)
		.append(",").append(searchStartDate)
		.append(",").append(searchEndDate)
		.append(",").append(searchRecordId)
		.append(",").append(searchErrorCd);
		logger.info(LoggerConstants.methodEndLevel());
		return s.toString();
	}
	
	/**
	 * this method is to export Encounter Details in CSV Report
	 * @author ppalat
	 * @param filterVO
	 * @param planMap
	 * @param planName
	 * @param pageStatus
	 * @param pageName
	 * @return
	 * @throws ApplicationException
	 */
	public String createEncounterDetail(Connection conn, String uiContextRange, HPEContext context, String exportType,String clmType) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		logger.debug("Create Encounter details ");
		String fileName = getCvsFileName();		
		ENCCodeCache cc = ENCCodeCache.getInstance();
		FileOutputStream stream = null;	
		Enc837iClmVO clmVO = null;		
		Enc837iClmErrorVO clmErrorVO = null;
		Enc837pClmVO pclmVO = null;
		Enc837pClmErrorVO pclmErrorVO = null;		
		HPEEncounterVO encounterVO = null;		
		HPEEncounterDao hpeEncounterDao = null;
		
		    /* IFOX 367728 Starts*/
		 DecimalFormat df = new DecimalFormat("00");//*To add revision number in claim number IFOX 367728*/
		 String uniqueClaimInd = "FALSE"; 
		 String mfId;
	     /* IFOX 367728 * Ends */
		ChartEncounterDao chartEncounterDao = null;
		Enc837iClmVO chartClmVO = null;		
		Enc837iClmErrorVO chartClmErrorVO = null;
		Enc837pClmVO chartPclmVO = null;
		Enc837pClmErrorVO chartPclmErrorVO = null;
		
		StringBuffer s = null;		
		int claimRevNo = 0,clmli_seq_nbr = 0;
		String claimType = "",claimRefNo = "",fileType = "",custClmNbr="";
		String hicNBR = "", mbi = "", dateInd = "",formatedSubmissionDate = "",formatedServiceDate = "",processStatus = "",inItrchgCtrlNbr = "",origIntrchgCtrlNbr="",receiverId="";		
		String dateType = "", errSegment = "", errGrp = "";
		String errSource = "", errCode = "",errDescription = "",flag = "false";
		String source = null;
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		String searchFrom = "",searchTo = "",submitterId = "";
		String searchErrorCode = "",searchErrorGroup = "",searchErrorSource = "";
		String searchClaimNBR = "",searchHicNBR = "",searchStatus = "";
		String mao4status = "";	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
		String cmsIcn = ""; //IFOX-00415108 - Add CMS ICN to the export
		String allowedDisallowedFlag = "";	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
		//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export Start
		Enc837iSubsVO instSubsVO = null;
		Enc837pSubsVO profSubsVO = null;
		String txnSetCtrlNbr = "";
		String billPrvHrchyId = "";
		String billPrvAffilTaxId = "";
		String subsHrchyId = "";
		String prodTestInd = "";
		String groupPolicyNbr = "";
		String payerSecId = "";
		//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export End
		
		//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
		String patCtrlNbr="", searchVanTraceNbr ="";
		//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
				
		Iterator itr = null;
		Iterator itr1 = null;
		Iterator itr2 = null;
						
		List srcLst = cc.getLstENCErrorSource();
		List grpLst = cc.getLstENCErrorGroup();
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
		logger.debug(" CsvService encounterVO #####----"+dateFormat.format(Calendar.getInstance().getTime()));		
	
		try {			
			if ("EN".equalsIgnoreCase(clmType) || "MD".equalsIgnoreCase(clmType)){
				source = "ENCDET0";			
				final StringBuffer headerNames = new StringBuffer();
				encounterVO = context.getEncounterVO();
				mfId=encounterVO.getMfId(); // IFOX 367728
				uniqueClaimInd = getProfileEntry (mfId,conn, uniqueClaimInd);// IFOX 367728
				stream = new FileOutputStream(new File(fileName));				
				claimType = encounterVO.getSearchDetailEncType();
				dateInd = encounterVO.getSearchDetailDateInd();	
				searchFrom = DateFormatter.reFormat(encounterVO.getSearchDetailFromDate(), 
						DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
				searchTo = DateFormatter.reFormat(encounterVO.getSearchDetailToDate(), 
						DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);			
				submitterId = encounterVO.getSearchDetailSubmitterId();
				searchClaimNBR = encounterVO.getSearchDetailClaimRefNbr();
				searchHicNBR = encounterVO.getSearchDetailHicNbr();
				
				searchStatus = encounterVO.getSearchDetailGroupStatus();
				if (searchStatus != null){								
					searchStatus = cc.getListBoxDesc(searchStatus,cc.getLstENCGroupStatus());
					if (searchStatus == null)
						searchStatus = encounterVO.getSearchDetailGroupStatus();				
				}
			
				searchErrorSource = cc.getListBoxDesc(encounterVO.getSearchDetailErrorSource(),srcLst);
				if (searchErrorSource == null) {
					searchErrorSource = encounterVO.getSearchDetailErrorSource();
				}
						
				searchErrorGroup = cc.getListBoxDesc(encounterVO.getSearchDetailErrorGroup(),grpLst);
				if (searchErrorGroup == null) {
					searchErrorGroup = encounterVO.getSearchDetailErrorGroup();
				}
					
				searchErrorCode = encounterVO.getSearchDetailErrorCode();

				
//				write heading row
			
//				starts :  IFOX-00377243
				if(Constants.CIGNA_HCFs.contains(encounterVO.getMfId())) {
					headerNames.append(ENCOUNTER_HEADER_NAMES.replaceAll(Constants.CUST_CLM_NBR, Constants.ENCOUNTER_HEADER_NAME_FOR_CIGNA).replaceAll(Constants.VALUE_ADDED_NTWK_TRACE_NBR, "").replaceAll(Constants.PAT_CTRL_NBR, ""));
				}
				else {
					headerNames.append(ENCOUNTER_HEADER_NAMES.replaceAll(Constants.CUST_CLM_NBR, "").replaceAll(Constants.VALUE_ADDED_NTWK_TRACE_NBR, "").replaceAll(Constants.PAT_CTRL_NBR, ""));
				}
//				ends :  IFOX-00377243
				logger.debug(" CsvService encounterVO #####----"+dateFormat.format(Calendar.getInstance().getTime()));				
				stream.write((headerNames.toString()+LINE_SEPARATOR).getBytes());
				
				if (claimType != null) {
					if (claimType.equals("I")) {
						claimType = HPEConstants.HPE_INSTITUTIONAL;
						if ("Current".equals(uiContextRange)){					
							Enc837iClmVOs clmList = encounterVO.getInstClaims();
							Enc837iClmErrorVOs clmErrorList = encounterVO.getInstClaimErrors();
							Enc837iSubsVOs instSubsList = new Enc837iSubsVOs(); //IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export
							itr = clmList.iterator();
						
							while (itr.hasNext()) {
								s = new StringBuffer();
								clmVO = (Enc837iClmVO)itr.next();
								if (clmVO != null) {
									flag = "false";
									claimRefNo =  StringUtil.nonNullTrim(clmVO.getWtxClaimRefNbr()); // IFOX-00411017 - Removed additional spaces from claim number
									claimRevNo =  clmVO.getWtxClaimRevNbr();
								
//									starts :  IFOX-00377243
									//IFOX-00408731 - Retrieve cust_claim_numbers for old claims in Export - Start
									if(StringUtil.nonNullTrim(clmVO.getCustClaimNbr()).equals("")){
//										custClmNbr = "0";
										custClmNbr = StringUtil.nonNullTrim(clmVO.getValueAddNtwkTraceNbr());
									//IFOX-00408731 - Retrieve cust_claim_numbers for old claims in Export - End
									}else{
										//IFOX-00409810 - Starts
										custClmNbr = StringUtil.nonNullTrim(clmVO.getCustClaimNbr());
									}
									
									if(!custClmNbr.isEmpty()) {
										custClmNbr = "'"+custClmNbr+"'";
									}
									//IFOX-00409810 - Ends
//									ends :  IFOX-00377243
 									
									/*To add revision number in claim number IFOX 367728*/
									if (("TRUE").equals(uniqueClaimInd)){
									claimRefNo= claimRefNo.substring(0,3)+ df.format(claimRevNo) + claimRefNo.substring(5);
									}
									/*To add revision number in claim number IFOX 367728*/
									
									inItrchgCtrlNbr = clmVO.getInIntrchgCtrlNbr();
									
									origIntrchgCtrlNbr = clmVO.getOrigIntrchgCtrlNbr();
									receiverId = clmVO.getReceiverId();
									
									hicNBR = clmVO.getSubsHicNbr();
									mbi = clmVO.getMbi();
									fileType = clmVO.getFileType();
									formatedSubmissionDate = clmVO.getFormattedTransFileDt();
									formatedServiceDate = clmVO.getFormattedStatementFromDt();
									if (dateInd.equals("0")) {
										dateType = HPEConstants.HPE_SUBMISSION_DATE;				
									} else if (dateInd.equals("1")) {
										dateType = HPEConstants.HPE_SERVICE_DATE;																
									}
									processStatus = clmVO.getProcessStatus();		
									mao4status = clmVO.getMaoflag();	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
									allowedDisallowedFlag = clmVO.getAllowedDisallowedFlag();	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
									cmsIcn = StringUtil.nonNullTrim(clmVO.getCmsIcn());//IFOX-00415108 - Add CMS ICN to the export
									
									//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export Start
									txnSetCtrlNbr = StringUtil.nonNullTrim(clmVO.getInTxnSetCtrlNbr());
									prodTestInd = StringUtil.nonNullTrim(clmVO.getProdTestInd());
									billPrvHrchyId = StringUtil.nonNullTrim(clmVO.getInBillPrvHrchyId());
									billPrvAffilTaxId = StringUtil.nonNullTrim(clmVO.getInBillPrvAffilTaxId());
									subsHrchyId = StringUtil.nonNullTrim(clmVO.getInSubsHrchyId());
									
									instSubsList.selectByKey(conn, mfId, submitterId, prodTestInd, inItrchgCtrlNbr, txnSetCtrlNbr, billPrvHrchyId, billPrvAffilTaxId, subsHrchyId, hicNBR, "N");
									
									if(instSubsList != null) {
										itr2 = instSubsList.iterator();
										while(itr2.hasNext()) {
											instSubsVO = (Enc837iSubsVO)itr2.next();
											if(instSubsVO!=null) {
													groupPolicyNbr = instSubsVO.getSubsGrpOrPolNbr().trim();
													payerSecId = instSubsVO.getPayerSecId();
													
													if(mfId.equals("HCF0241")) {
														groupPolicyNbr = getModifiedGrpOrPolNum(groupPolicyNbr);
													}
											}
										}
									}
									//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export End
									if (clmErrorList != null) {
										itr1 = clmErrorList.iterator();
										while (itr1.hasNext()){
											clmErrorVO = (Enc837iClmErrorVO)itr1.next();
											if (clmErrorVO != null) {
												if (claimRefNo.equals(clmErrorVO.getWtxClaimRefNbr().trim()) && 
														claimRevNo == (clmErrorVO.getWtxClaimRevNbr())) {
													flag = "true";
													errSegment = clmErrorVO.getErrorSegment();
													clmli_seq_nbr = clmErrorVO.getClmLineSeqNbr();
													errSource = cc.getListBoxDesc(clmErrorVO.getErrorSource(),srcLst);
													if (errSource == null)
														errSource = clmErrorVO.getErrorSource();
													errGrp = cc.getListBoxDesc(clmErrorVO.getErrorGroup(),grpLst);
													if (errGrp == null)
														errGrp = clmErrorVO.getErrorGroup();
													errCode = clmErrorVO.getErrorCd();
													errDescription = clmErrorVO.getErrorDescription();
													
													s.append(source)
													.append(",").append(extractDate)
													.append(",").append(submitterId)
													.append(",").append(dateType)
													.append(",").append(searchFrom)
													.append(",").append(searchTo)
													.append(",").append(claimType)
													.append(",").append(searchClaimNBR);
													if(searchHicNBR.equalsIgnoreCase(hicNBR)){s.append(",").append(hicNBR);}
													else{s.append(",").append("");}
													if (searchHicNBR.equalsIgnoreCase(mbi)){s.append(",").append(mbi);}
													else{s.append(",").append("");}
													s.append(",").append(searchStatus)
													.append(",").append(searchErrorSource)
													.append(",").append(searchErrorGroup)
													.append(",").append(searchErrorCode)
													.append(",").append(claimRefNo);
//													starts :  IFOX-00377243
													if(Constants.CIGNA_HCFs.contains(encounterVO.getMfId()) )
													s.append(",").append(custClmNbr);
//													ends :  IFOX-00377243
													 s.append(",").append(claimRevNo)
													.append(",").append(hicNBR)											
													.append(",").append(mbi)
													.append(",").append(formatedServiceDate)
													.append(",").append(formatedSubmissionDate)
													.append(",").append(fileType)
													.append(",").append(processStatus)
													.append(",").append(cmsIcn) //IFOX-00415108 - Add CMS ICN to the export
													.append(",").append(inItrchgCtrlNbr)
													.append(",").append(origIntrchgCtrlNbr)
													.append(",").append(receiverId)
													//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export Start
													.append(",").append(groupPolicyNbr)
													.append(",").append(payerSecId)
													//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export End
													.append(",").append(errSegment)
													.append(",").append(errCode)
													.append(",").append(errSource)
													.append(",").append(errGrp)
													.append(",").append(clmli_seq_nbr)
													.append(",").append(CSVUtil.quoteString(errDescription))
													.append(",").append(mao4status)	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)						
													.append(",").append(allowedDisallowedFlag);	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
													
													stream.write((s+LINE_SEPARATOR).getBytes());
													s = new StringBuffer();
												}																
											}							
										}
									
										errSegment = "";
										errGrp = "";
										errSource = "";
										errCode = "";
										clmli_seq_nbr = 0;
										errDescription = "";						
									}	
								
									if (flag.equals("false")) {
										s.append(source)
										.append(",").append(extractDate)
										.append(",").append(submitterId)
										.append(",").append(dateType)
										.append(",").append(searchFrom)
										.append(",").append(searchTo)
										.append(",").append(claimType)
										.append(",").append(searchClaimNBR);
										if(searchHicNBR.equalsIgnoreCase(hicNBR)){s.append(",").append(hicNBR);}
										else{s.append(",").append("");}
										if (searchHicNBR.equalsIgnoreCase(mbi)){s.append(",").append(mbi);}
										else{s.append(",").append("");}
										s.append(",").append(searchStatus)
										.append(",").append(searchErrorSource)
										.append(",").append(searchErrorGroup)
										.append(",").append(searchErrorCode)
										.append(",").append(claimRefNo);
//										starts :  IFOX-00377243
										if(Constants.CIGNA_HCFs.contains(encounterVO.getMfId()))
										s.append(",").append(custClmNbr);
//										ends :  IFOX-00377243
										s.append(",").append(claimRevNo)
										.append(",").append(hicNBR)								
										.append(",").append(mbi)
										.append(",").append(formatedServiceDate)
										.append(",").append(formatedSubmissionDate)
										.append(",").append(fileType)
										.append(",").append(processStatus)
										.append(",").append(cmsIcn)//IFOX-00415108 - Add CMS ICN to the export
										.append(",").append(inItrchgCtrlNbr)
										.append(",").append(origIntrchgCtrlNbr)
										.append(",").append(receiverId)
										//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export Start
										.append(",").append(groupPolicyNbr)
										.append(",").append(payerSecId)
										//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export End
										.append(",").append(errSegment)
										.append(",").append(errCode)
										.append(",").append(errSource)
										.append(",").append(errGrp)
										.append(",").append(clmli_seq_nbr)
										.append(",").append(CSVUtil.quoteString(errDescription))
										.append(",").append(mao4status)	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
										.append(",").append(allowedDisallowedFlag);	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
										//if (errDescription.indexOf("\"") != -1 || errDescription.indexOf(",") != -1) {         
										//	errDescription = errDescription.replaceAll("\"", "\"\""); 
										//	s.append(",").append("\"").append(errDescription).append("\"");     
										//} else {
										//	s.append(",").append(errDescription);
										//}
										stream.write((s+LINE_SEPARATOR).getBytes());								
									}			
								}									
							}
						} else if ("ALL".equals(uiContextRange)) {
							logger.debug("for ALL type claimType:I -> export :");
							hpeEncounterDao = DaoFactory.getInstance().getHPEEncounterDao();
							fileName = hpeEncounterDao.getEncounterData(conn,context, encounterVO,fileName,claimType);
						}					
					}else if ("P".equals(claimType) || "E".equals(claimType)) {	
						claimType = ("P".equals(claimType))?HPEConstants.HPE_PROFESSIONAL:HPEConstants.HPE_DME;
						if ("Current".equals(uiContextRange)){						
							Enc837pClmVOs clmList = encounterVO.getProfClaims();
							Enc837pClmErrorVOs clmErrorList = encounterVO.getProfClaimErrors();
							Enc837pSubsVOs profSubsList = new Enc837pSubsVOs(); //IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export
							itr = clmList.iterator();
						
							while (itr.hasNext()) {
								s = new StringBuffer();
								pclmVO = (Enc837pClmVO)itr.next();
								if (pclmVO != null) {
									flag = "false";
									claimRefNo =  StringUtil.nonNullTrim(pclmVO.getWtxClaimRefNbr()); // IFOX-00411017 - Removed additional spaces from claim number
									claimRevNo =  pclmVO.getWtxClaimRevNbr();
									
//									starts :  IFOX-00377243
									//IFOX-00408731 - Retrieve cust_claim_numbers for old claims in Export - Start
									if(StringUtil.nonNullTrim(pclmVO.getCustClaimNbr()).equals("")){
//										custClmNbr = "0";
										custClmNbr = StringUtil.nonNullTrim(pclmVO.getValueAddNtwkTraceNbr());
									//IFOX-00408731 - Retrieve cust_claim_numbers for old claims in Export - End
									}else{
										//IFOX-00409810 - Starts
										custClmNbr = StringUtil.nonNullTrim(pclmVO.getCustClaimNbr());
									}
									if(!custClmNbr.isEmpty()) {
										custClmNbr = "'"+custClmNbr+"'";
									}
									//IFOX-00409810 - Ends
//									ends :  IFOX-00377243
									
							//		logger.error("Cust Clm Nbr in EN/MR for Prof -- current "+ custClmNbr);
									if (("TRUE").equals(uniqueClaimInd)){
										claimRefNo= claimRefNo.substring(0,3)+ df.format(claimRevNo) + claimRefNo.substring(5);/*To add revision number in claim number IFOX 367728*/
										}
									inItrchgCtrlNbr = pclmVO.getInIntrchgCtrlNbr();
									
									origIntrchgCtrlNbr = pclmVO.getOrigIntrchgCtrlNbr();
									receiverId = pclmVO.getReceiverId();
									
									hicNBR = pclmVO.getSubsHicNbr();
									mbi = pclmVO.getMbi();
									fileType = pclmVO.getFileType();
									formatedSubmissionDate = pclmVO.getFormattedTransFileDt();
									formatedServiceDate = pclmVO.getFormattedServiceBeginDt();
									if (dateInd.equals("0")) {
										dateType = HPEConstants.HPE_SUBMISSION_DATE;									
									} else if (dateInd.equals("1")) {
										dateType = HPEConstants.HPE_SERVICE_DATE;																	
									}							
									processStatus = pclmVO.getProcessStatus();
									mao4status = pclmVO.getMaoflag();	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
									allowedDisallowedFlag = pclmVO.getAllowedDisallowedFlag();	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
									cmsIcn = StringUtil.nonNullTrim(pclmVO.getCmsIcn()); //IFOX-00415108 - Add CMS ICN to the export
									
									//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export Start
									txnSetCtrlNbr = StringUtil.nonNullTrim(pclmVO.getInTxnSetCtrlNbr());
									prodTestInd = StringUtil.nonNullTrim(pclmVO.getProdTestInd());
									billPrvHrchyId = StringUtil.nonNullTrim(pclmVO.getInBillPrvHrchyId());
									billPrvAffilTaxId = StringUtil.nonNullTrim(pclmVO.getInBillPrvAffilTaxId());
									subsHrchyId = StringUtil.nonNullTrim(pclmVO.getInSubsHrchyId());
									profSubsList.selectByKey(conn, mfId, submitterId, prodTestInd, inItrchgCtrlNbr, txnSetCtrlNbr, billPrvHrchyId, billPrvAffilTaxId, subsHrchyId, hicNBR, "N");
								
									if(profSubsList != null) {
										itr2 = profSubsList.iterator();
										while(itr2.hasNext()) {
											profSubsVO = (Enc837pSubsVO)itr2.next();
											if(profSubsVO!=null) {
													groupPolicyNbr = profSubsVO.getSubsGrpOrPolNbr().trim();
													payerSecId = profSubsVO.getPayerSecId();
													
													if(mfId.equals("HCF0241")) {
														groupPolicyNbr = getModifiedGrpOrPolNum(groupPolicyNbr);
													}
											}
										}
									}
									//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export End
									
									if (clmErrorList != null) {
										itr1 = clmErrorList.iterator();
										while (itr1.hasNext()){
											pclmErrorVO = (Enc837pClmErrorVO)itr1.next();
											if (pclmErrorVO != null) {
												if (claimRefNo.equals(pclmErrorVO.getWtxClaimRefNbr().trim()) && 
														claimRevNo == (pclmErrorVO.getWtxClaimRevNbr())) {
													flag = "true";
													errSegment = pclmErrorVO.getErrorSegment();
													clmli_seq_nbr = pclmErrorVO.getClmLineSeqNbr();
													errSource = cc.getListBoxDesc(pclmErrorVO.getErrorSource(),srcLst);
													if (errSource == null)
														errSource = pclmErrorVO.getErrorSource();
													errGrp = cc.getListBoxDesc(pclmErrorVO.getErrorGroup(),grpLst);
													if (errGrp == null)
														errGrp = pclmErrorVO.getErrorGroup();
													errCode = pclmErrorVO.getErrorCd();
													errDescription = pclmErrorVO.getErrorDescription();
												
													s.append(source)
													.append(",").append(extractDate)
													.append(",").append(submitterId)
													.append(",").append(dateType)
													.append(",").append(searchFrom)
													.append(",").append(searchTo)
													.append(",").append(claimType)
													.append(",").append(searchClaimNBR);
													if(searchHicNBR.equalsIgnoreCase(hicNBR)){s.append(",").append(hicNBR);}
													else{s.append(",").append("");}
													if (searchHicNBR.equalsIgnoreCase(mbi)){s.append(",").append(mbi);}
													else{s.append(",").append("");}
													s.append(",").append(searchStatus)
													.append(",").append(searchErrorSource)
													.append(",").append(searchErrorGroup)
													.append(",").append(searchErrorCode)
													.append(",").append(claimRefNo);
													logger.debug("mfid is in CsvService 4th :: "+ encounterVO.getMfId());
//													starts :  IFOX-00377243
													if(Constants.CIGNA_HCFs.contains(encounterVO.getMfId())) 
														s.append(",").append(custClmNbr);
//													ends :  IFOX-00377243
													 s.append(",").append(claimRevNo)				
													.append(",").append(hicNBR)											
													.append(",").append(mbi)
													.append(",").append(formatedServiceDate)
													.append(",").append(formatedSubmissionDate)
													.append(",").append(fileType)
													.append(",").append(processStatus)
													.append(",").append(cmsIcn)//IFOX-00415108 - Add CMS ICN to the export 
													.append(",").append(inItrchgCtrlNbr)
													.append(",").append(origIntrchgCtrlNbr)   //origIntrchgCtrlNbr
													.append(",").append(receiverId)   //rcvrId
													//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export Start
													.append(",").append(groupPolicyNbr)
													.append(",").append(payerSecId)
													//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export End
													.append(",").append(errSegment)
													.append(",").append(errCode)
													.append(",").append(errSource)
													.append(",").append(errGrp)
													.append(",").append(clmli_seq_nbr)
													.append(",").append(CSVUtil.quoteString(errDescription))
													.append(",").append(mao4status)	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
													.append(",").append(allowedDisallowedFlag);	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
												
													stream.write((s+LINE_SEPARATOR).getBytes());
													s = new StringBuffer();
												}																
											}							
										}
									
										errSegment = "";
										errSource = "";
										errGrp = "";
										errCode = "";
										clmli_seq_nbr = 0;
										errDescription = "";						
									}	
								
									if (flag.equals("false")) {
										s.append(source)
										.append(",").append(extractDate)
										.append(",").append(submitterId)
										.append(",").append(dateType)
										.append(",").append(searchFrom)
										.append(",").append(searchTo)
										.append(",").append(claimType)
										.append(",").append(searchClaimNBR);
										if(searchHicNBR.equalsIgnoreCase(hicNBR)){s.append(",").append(hicNBR);}
										else{s.append(",").append("");}
										if (searchHicNBR.equalsIgnoreCase(mbi)){s.append(",").append(mbi);}
										else{s.append(",").append("");}
										s.append(",").append(searchStatus)
										.append(",").append(searchErrorSource)
										.append(",").append(searchErrorGroup)
										.append(",").append(searchErrorCode)
										.append(",").append(claimRefNo);
									//	logger.error("mfid is in CsvService 5th :: "+ encounterVO.getMfId());
//										starts :  IFOX-00377243
										if(Constants.CIGNA_HCFs.contains(encounterVO.getMfId())) 
										s.append(",").append(custClmNbr);
//										ends :  IFOX-00377243
										s.append(",").append(claimRevNo)				
										.append(",").append(hicNBR)											
										.append(",").append(mbi)
										.append(",").append(formatedServiceDate)
										.append(",").append(formatedSubmissionDate)
										.append(",").append(fileType)
										.append(",").append(processStatus)
										.append(",").append(cmsIcn)//IFOX-00415108 - Add CMS ICN to the export
										.append(",").append(inItrchgCtrlNbr)
										.append(",").append(origIntrchgCtrlNbr)   //origIntrchgCtrlNbr
										.append(",").append(receiverId)   //rcvrId
										//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export Start
										.append(",").append(groupPolicyNbr)
										.append(",").append(payerSecId)
										//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export End
										.append(",").append(errSegment)
										.append(",").append(errCode)
										.append(",").append(errSource)
										.append(",").append(errGrp)
										.append(",").append(clmli_seq_nbr)
										.append(",").append(CSVUtil.quoteString(errDescription))
										.append(",").append(mao4status)	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
										.append(",").append(allowedDisallowedFlag);	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
										stream.write((s+LINE_SEPARATOR).getBytes());
									}			
								}									
							}
						} else if ("ALL".equals(uiContextRange)) {
							logger.debug("for ALL type claimType:P -> export :");
							hpeEncounterDao = DaoFactory.getInstance().getHPEEncounterDao();
							fileName = hpeEncounterDao.getEncounterData(conn,context, encounterVO,fileName,claimType);
						}					
					}
				}
			}
			else if ("CR".equalsIgnoreCase(clmType) || "MC".equalsIgnoreCase(clmType)){
				source = "CRDET0";
				final StringBuffer headerNames = new StringBuffer();
				encounterVO = context.getChartEncounterVO();				
				stream = new FileOutputStream(new File(fileName));				
				claimType = encounterVO.getSearchDetailEncType();
				mfId=encounterVO.getMfId(); // IFOX 367728
				uniqueClaimInd = getProfileEntry (mfId,conn, uniqueClaimInd);// IFOX 367728
				dateInd = encounterVO.getSearchDetailDateInd();	
				searchFrom = DateFormatter.reFormat(encounterVO.getSearchDetailFromDate(), 
							DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);
				searchTo = DateFormatter.reFormat(encounterVO.getSearchDetailToDate(), 
							DateFormatter.YYYYMMDD,DateFormatter.MM_DD_YYYY);			
				submitterId = encounterVO.getSearchDetailSubmitterId();
				searchClaimNBR = encounterVO.getSearchDetailClaimRefNbr();
				searchHicNBR = encounterVO.getSearchDetailHicNbr();
					
				searchStatus = encounterVO.getSearchDetailGroupStatus();
				
				//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start 
				searchVanTraceNbr =  encounterVO.getSearchVanTanNumber();
				//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
				
				if (searchStatus != null){								
					searchStatus = cc.getListBoxDesc(searchStatus,cc.getLstENCGroupStatus());
					if (searchStatus == null)
						searchStatus = encounterVO.getSearchDetailGroupStatus();				
				}
				
				searchErrorSource = cc.getListBoxDesc(encounterVO.getSearchDetailErrorSource(),srcLst);
				if (searchErrorSource == null) {
					searchErrorSource = encounterVO.getSearchDetailErrorSource();
				}
							
				searchErrorGroup = cc.getListBoxDesc(encounterVO.getSearchDetailErrorGroup(),grpLst);
				if (searchErrorGroup == null) {
					searchErrorGroup = encounterVO.getSearchDetailErrorGroup();
				}
						
				searchErrorCode = encounterVO.getSearchDetailErrorCode();

				logger.debug("mfid is in CsvService 6th :: "+ encounterVO.getMfId());
				

				//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
				if(Constants.CIGNA_HCFs.contains(encounterVO.getMfId())) {
					headerNames.append(ENCOUNTER_HEADER_NAMES.replaceAll(Constants.CUST_CLM_NBR, Constants.ENCOUNTER_HEADER_NAME_FOR_CIGNA));
				
				}
				else {
					headerNames.append(ENCOUNTER_HEADER_NAMES.replaceAll(Constants.CUST_CLM_NBR, "")
							.replaceAll(Constants.VALUE_ADDED_NTWK_TRACE_NBR, "").replaceAll(Constants.PAT_CTRL_NBR, ""));
				}
				// ends :  IFOX-00377243
				//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
				
				
				//write heading row
				stream.write((headerNames.toString()+LINE_SEPARATOR).getBytes());	
				
				if (claimType != null) {
					if (claimType.equals("I")) {
						claimType = HPEConstants.HPE_INSTITUTIONAL;
						if ("Current".equals(uiContextRange)){					
							Enc837iClmVOs clmList = encounterVO.getInstClaims();
							Enc837iClmErrorVOs clmErrorList = encounterVO.getInstClaimErrors();
							Enc837iSubsVOs instSubsList = new Enc837iSubsVOs(); //IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export
							itr = clmList.iterator();
							
							while (itr.hasNext()) {
								s = new StringBuffer();
								chartClmVO = (Enc837iClmVO)itr.next();
								if (chartClmVO != null) {
									flag = "false";
									claimRefNo =  StringUtil.nonNullTrim(chartClmVO.getWtxClaimRefNbr()); // IFOX-00411017 - Removed additional spaces from claim number
									claimRevNo =  chartClmVO.getWtxClaimRevNbr();
									
									//if(chartClmVO.getCustClaimNbr() != null)
									if(chartClmVO.getCustClaimNbr() == null){
//										custClmNbr = "0";
										custClmNbr = StringUtil.nonNullTrim(chartClmVO.getValueAddNtwkTraceNbr());	//IFOX-00408731 - Retrieve cust_claim_numbers for old claims in Export
									}else{
										//IFOX-00409810 - Starts
										custClmNbr = StringUtil.nonNullTrim(chartClmVO.getCustClaimNbr());
									}
									
									if(!custClmNbr.isEmpty()) {
										custClmNbr = "'"+custClmNbr+"'";
									}
									//IFOX-00409810 - Ends
										// IFOX-00377243
									logger.debug("For Ins - CustClmNbr for CR/MC :: "+ custClmNbr);
									
									if (("TRUE").equals(uniqueClaimInd)){
										claimRefNo= claimRefNo.substring(0,3)+ df.format(claimRevNo) + claimRefNo.substring(5);/*To add revision number in claim number IFOX 367728*/
										}
									inItrchgCtrlNbr = chartClmVO.getInIntrchgCtrlNbr();
								    //Ifox - 00391283 Export adding fields Intrchg ctrl nbr, Receiver Id 
									origIntrchgCtrlNbr=chartClmVO.getOrigIntrchgCtrlNbr();
									receiverId = chartClmVO.getReceiverId();								
									//Ifox - 00391283 Export adding fields Intrchg ctrl nbr, Receiver Id 
									
									//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
									patCtrlNbr = chartClmVO.getPatCtrlNbr();
									//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
									mao4status = chartClmVO.getMaoflag();	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
									allowedDisallowedFlag = chartClmVO.getAllowedDisallowedFlag();	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
									cmsIcn = StringUtil.nonNullTrim(chartClmVO.getCmsIcn());//IFOX-00415108 - Add CMS ICN to the export
									
									hicNBR = chartClmVO.getSubsHicNbr();
									mbi = chartClmVO.getMbi();
									fileType = chartClmVO.getFileType();
									formatedSubmissionDate = chartClmVO.getFormattedTransFileDt();
									formatedServiceDate = chartClmVO.getFormattedStatementFromDt();
									if (dateInd.equals("0")) {
										dateType = HPEConstants.HPE_SUBMISSION_DATE;				
									} else if (dateInd.equals("1")) {
										dateType = HPEConstants.HPE_SERVICE_DATE;																
									}
									processStatus = chartClmVO.getProcessStatus();		
									
									//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export Start
									txnSetCtrlNbr = StringUtil.nonNullTrim(clmVO.getInTxnSetCtrlNbr());
									prodTestInd = StringUtil.nonNullTrim(clmVO.getProdTestInd());
									billPrvHrchyId = StringUtil.nonNullTrim(clmVO.getInBillPrvHrchyId());
									billPrvAffilTaxId = StringUtil.nonNullTrim(clmVO.getInBillPrvAffilTaxId());
									subsHrchyId = StringUtil.nonNullTrim(clmVO.getInSubsHrchyId());
									
									instSubsList.selectByKey(conn, mfId, submitterId, prodTestInd, inItrchgCtrlNbr, txnSetCtrlNbr, billPrvHrchyId, billPrvAffilTaxId, subsHrchyId, hicNBR, "N");
									
									if(instSubsList != null) {
										itr2 = instSubsList.iterator();
										while(itr2.hasNext()) {
											instSubsVO = (Enc837iSubsVO)itr2.next();
											if(instSubsVO!=null) {
													groupPolicyNbr = instSubsVO.getSubsGrpOrPolNbr().trim();
													payerSecId = instSubsVO.getPayerSecId();
													
													if(mfId.equals("HCF0241")) {
														groupPolicyNbr = getModifiedGrpOrPolNum(groupPolicyNbr);
													}
											}
										}
									}
									//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export End
									
									if (clmErrorList != null) {
										itr1 = clmErrorList.iterator();
										while (itr1.hasNext()){
											chartClmErrorVO = (Enc837iClmErrorVO)itr1.next();
											if (chartClmErrorVO != null) {
												if (claimRefNo.equals(chartClmErrorVO.getWtxClaimRefNbr().trim()) && 
													claimRevNo == (chartClmErrorVO.getWtxClaimRevNbr())) {
													flag = "true";
													errSegment = chartClmErrorVO.getErrorSegment();
													clmli_seq_nbr = chartClmErrorVO.getClmLineSeqNbr();
													errSource = cc.getListBoxDesc(chartClmErrorVO.getErrorSource(),srcLst);
													if (errSource == null)
														errSource = chartClmErrorVO.getErrorSource();
													errGrp = cc.getListBoxDesc(chartClmErrorVO.getErrorGroup(),grpLst);
													if (errGrp == null)
														errGrp = chartClmErrorVO.getErrorGroup();
													errCode = chartClmErrorVO.getErrorCd();
													errDescription = chartClmErrorVO.getErrorDescription();
														
													s.append(source)
													.append(",").append(extractDate)
													.append(",").append(submitterId)
													.append(",").append(dateType)
													.append(",").append(searchFrom)
													.append(",").append(searchTo)
													.append(",").append(claimType)
													.append(",").append(searchClaimNBR)
													.append(",").append(StringUtils.isEmpty(searchHicNBR)?"":hicNBR);
													//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
													if(Constants.CIGNA_HCFs.contains(encounterVO.getMfId())) 
													s.append(",").append(searchVanTraceNbr);
													//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
													s.append(",").append(StringUtils.isEmpty(searchHicNBR)?"":mbi)
													.append(",").append(searchStatus)
													.append(",").append(searchErrorSource)
													.append(",").append(searchErrorGroup)
													.append(",").append(searchErrorCode)
													.append(",").append(claimRefNo);
												//	logger.error("mfid is in CsvService 7th :: "+ encounterVO.getMfId());
//													starts :  IFOX-00377243
													if(Constants.CIGNA_HCFs.contains(encounterVO.getMfId())) 
														s.append(",").append(custClmNbr);
//													ends :  IFOX-00377243
													s.append(",").append(claimRevNo);
													//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
													if(Constants.CIGNA_HCFs.contains(encounterVO.getMfId())) 
													s.append(",").append(patCtrlNbr);
													//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
													s.append(",").append(hicNBR)	
													.append(",").append(mbi)
													.append(",").append(formatedServiceDate)
													.append(",").append(formatedSubmissionDate)
													.append(",").append(fileType)
													.append(",").append(processStatus)
													.append(",").append(cmsIcn) //IFOX-00415108 - Add CMS ICN to the export
													.append(",").append(inItrchgCtrlNbr)
													//Ifox - 00391283 Export adding fields Intrchg ctrl nbr, Receiver Id 
													.append(",").append(origIntrchgCtrlNbr)   //origIntrchgCtrlNbr
													.append(",").append(receiverId)   //rcvrId
													//Ifox - 00391283 Export adding fields Intrchg ctrl nbr, Receiver Id
													//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export Start
													.append(",").append(groupPolicyNbr)
													.append(",").append(payerSecId)
													//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export End
													.append(",").append(errSegment)
													.append(",").append(errCode)
													.append(",").append(errSource)
													.append(",").append(errGrp)
													.append(",").append(clmli_seq_nbr)
													.append(",").append(CSVUtil.quoteString(errDescription))
													.append(",").append(mao4status)	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
													.append(",").append(allowedDisallowedFlag);	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
													stream.write((s+LINE_SEPARATOR).getBytes());
													s = new StringBuffer();
												}																
											}							
										}
										
										errSegment = "";
										errGrp = "";
										errSource = "";
										errCode = "";
										clmli_seq_nbr = 0;
										errDescription = "";						
									}	
									
									if (flag.equals("false")) {
										s.append(source)
										.append(",").append(extractDate)
										.append(",").append(submitterId)
										.append(",").append(dateType)
										.append(",").append(searchFrom)
										.append(",").append(searchTo)
										.append(",").append(claimType)
										.append(",").append(searchClaimNBR)
										.append(",").append(StringUtils.isEmpty(searchHicNBR)?"":hicNBR);
										//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
										if(Constants.CIGNA_HCFs.contains(encounterVO.getMfId())) 
										s.append(",").append(searchVanTraceNbr);
										//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
										s.append(",").append(StringUtils.isEmpty(searchHicNBR)?"":mbi)
										.append(",").append(searchStatus)
										.append(",").append(searchErrorSource)
										.append(",").append(searchErrorGroup)
										.append(",").append(searchErrorCode)
										.append(",").append(claimRefNo);
									//	logger.error("mfid is in CsvService 8th :: "+ encounterVO.getMfId());
//										starts :  IFOX-00377243
										if(Constants.CIGNA_HCFs.contains(encounterVO.getMfId()) ) 
										s.append(",").append(custClmNbr);
//										ends :  IFOX-00377243
										s.append(",").append(claimRevNo);
										//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
										if(Constants.CIGNA_HCFs.contains(encounterVO.getMfId())) 
										s.append(",").append(patCtrlNbr);
										//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
										s.append(",").append(hicNBR)								
										.append(",").append(mbi)
										.append(",").append(formatedServiceDate)
										.append(",").append(formatedSubmissionDate)
										.append(",").append(fileType)
										.append(",").append(processStatus)
										.append(",").append(cmsIcn) //IFOX-00415108 - Add CMS ICN to the export
										.append(",").append(inItrchgCtrlNbr)
										//Ifox - 00391283 Export adding fields Intrchg ctrl nbr, Receiver Id 
										.append(",").append(origIntrchgCtrlNbr)   //origIntrchgCtrlNbr
										.append(",").append(receiverId)   //rcvrId
										//Ifox - 00391283 Export adding fields Intrchg ctrl nbr, Receiver Id
										//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export Start
										.append(",").append(groupPolicyNbr)
										.append(",").append(payerSecId)
										//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export End
										.append(",").append(errSegment)
										.append(",").append(errCode)
										.append(",").append(errSource)
										.append(",").append(errGrp)
										.append(",").append(clmli_seq_nbr)
										.append(",").append(CSVUtil.quoteString(errDescription))
										.append(",").append(mao4status)	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
										.append(",").append(allowedDisallowedFlag);	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
										stream.write((s+LINE_SEPARATOR).getBytes());								
									}			
								}									
							}
						} else if ("ALL".equals(uiContextRange)) {
							chartEncounterDao = DaoFactory.getInstance().getChartEncounterDao();
							fileName = chartEncounterDao.getEncounterData(conn,context, encounterVO,fileName,claimType);
						}					
					}else if ("P".equals(claimType) || "E".equals(claimType)) {	
						claimType = ("P".equals(claimType))?HPEConstants.HPE_PROFESSIONAL:HPEConstants.HPE_DME;
						if ("Current".equals(uiContextRange)){						
							Enc837pClmVOs clmList = encounterVO.getProfClaims();
							Enc837pClmErrorVOs clmErrorList = encounterVO.getProfClaimErrors();
							Enc837pSubsVOs chartProfSubsList = new Enc837pSubsVOs(); //IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export
							itr = clmList.iterator();
							
							while (itr.hasNext()) {
								s = new StringBuffer();
								chartPclmVO = (Enc837pClmVO)itr.next();
								if (chartPclmVO != null) {
									flag = "false";
									claimRefNo =  StringUtil.nonNullTrim(chartPclmVO.getWtxClaimRefNbr()); // IFOX-00411017 - Removed additional spaces from claim number
									claimRevNo =  chartPclmVO.getWtxClaimRevNbr();
									
									//if(chartPclmVO.getCustClaimNbr() != null)
									if(chartPclmVO.getCustClaimNbr() == null){
//										custClmNbr = "0";
										custClmNbr = StringUtil.nonNullTrim(chartPclmVO.getValueAddNtwkTraceNbr());		//IFOX-00408731 - Retrieve cust_claim_numbers for old claims in Export
									}else{
										//IFOX-00409810 - Starts
										custClmNbr = StringUtil.nonNullTrim(chartPclmVO.getCustClaimNbr());
									}
									
									if(!custClmNbr.isEmpty()) {
										custClmNbr = "'"+custClmNbr+"'";
									}
									//IFOX-00409810 - Ends
									
									//logger.println("for CR/MC for Prof is CustClmNbr :: "+ custClmNbr);
									if (("TRUE").equals(uniqueClaimInd)){
										claimRefNo= claimRefNo.substring(0,3)+ df.format(claimRevNo) + claimRefNo.substring(5);/*To add revision number in claim number IFOX 367728*/
										}
									inItrchgCtrlNbr = chartPclmVO.getInIntrchgCtrlNbr();
									 //Ifox - 00391283 Export adding fields Intrchg ctrl nbr, Receiver Id 
									origIntrchgCtrlNbr=chartPclmVO.getOrigIntrchgCtrlNbr();
									receiverId = chartPclmVO.getReceiverId();
									 //Ifox - 00391283 Export adding fields Intrchg ctrl nbr, Receiver Id 
									
									//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
									patCtrlNbr = chartPclmVO.getPatCtrlNbr();
									//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
									
									hicNBR = chartPclmVO.getSubsHicNbr();
									mbi = chartPclmVO.getMbi();
									fileType = chartPclmVO.getFileType();
									formatedSubmissionDate = chartPclmVO.getFormattedTransFileDt();
									formatedServiceDate = chartPclmVO.getFormattedServiceBeginDt();
									if (dateInd.equals("0")) {
										dateType = HPEConstants.HPE_SUBMISSION_DATE;									
									} else if (dateInd.equals("1")) {
										dateType = HPEConstants.HPE_SERVICE_DATE;																	
									}							
									processStatus = chartPclmVO.getProcessStatus();												
									
									mao4status = chartPclmVO.getMaoflag();	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
									allowedDisallowedFlag = chartPclmVO.getAllowedDisallowedFlag();	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
									cmsIcn = StringUtil.nonNullTrim(chartPclmVO.getCmsIcn()); //IFOX-00415108 - Add CMS ICN to the export
									
									//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export Start
									txnSetCtrlNbr = StringUtil.nonNullTrim(chartPclmVO.getInTxnSetCtrlNbr());
									prodTestInd = StringUtil.nonNullTrim(chartPclmVO.getProdTestInd());
									billPrvHrchyId = StringUtil.nonNullTrim(chartPclmVO.getInBillPrvHrchyId());
									billPrvAffilTaxId = StringUtil.nonNullTrim(chartPclmVO.getInBillPrvAffilTaxId());
									subsHrchyId = StringUtil.nonNullTrim(chartPclmVO.getInSubsHrchyId());
									chartProfSubsList.selectByKey(conn, mfId, submitterId, prodTestInd, inItrchgCtrlNbr, txnSetCtrlNbr, billPrvHrchyId, billPrvAffilTaxId, subsHrchyId, hicNBR, "N");
								
									if(chartProfSubsList != null) {
										itr2 = chartProfSubsList.iterator();
										while(itr2.hasNext()) {
											profSubsVO = (Enc837pSubsVO)itr2.next();
											if(profSubsVO!=null) {
													groupPolicyNbr = profSubsVO.getSubsGrpOrPolNbr().trim();
													payerSecId = profSubsVO.getPayerSecId();
													
													if(mfId.equals("HCF0241")) {
														groupPolicyNbr = getModifiedGrpOrPolNum(groupPolicyNbr);
													}
											}
										}
									}
									//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export End

									if (clmErrorList != null) {
										itr1 = clmErrorList.iterator();
										while (itr1.hasNext()){
											chartPclmErrorVO = (Enc837pClmErrorVO)itr1.next();
											if (chartPclmErrorVO != null) {
												if (claimRefNo.equals(chartPclmErrorVO.getWtxClaimRefNbr().trim()) && 
													claimRevNo == (chartPclmErrorVO.getWtxClaimRevNbr())) {
													flag = "true";
													errSegment = chartPclmErrorVO.getErrorSegment();
													clmli_seq_nbr = chartPclmErrorVO.getClmLineSeqNbr();
													errSource = cc.getListBoxDesc(chartPclmErrorVO.getErrorSource(),srcLst);
													if (errSource == null)
														errSource = chartPclmErrorVO.getErrorSource();
													errGrp = cc.getListBoxDesc(chartPclmErrorVO.getErrorGroup(),grpLst);
													if (errGrp == null)
														errGrp = chartPclmErrorVO.getErrorGroup();
													errCode = chartPclmErrorVO.getErrorCd();
													errDescription = chartPclmErrorVO.getErrorDescription();
													
													s.append(source)
													.append(",").append(extractDate)
													.append(",").append(submitterId)
													.append(",").append(dateType)
													.append(",").append(searchFrom)
													.append(",").append(searchTo)
													.append(",").append(claimType)
													.append(",").append(searchClaimNBR)
													.append(",").append(StringUtils.isEmpty(searchHicNBR)?"":hicNBR);
													//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
													if(Constants.CIGNA_HCFs.contains(encounterVO.getMfId())) 
													s.append(",").append(searchVanTraceNbr);
													//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
													s.append(",").append(StringUtils.isEmpty(searchHicNBR)?"":mbi)
													.append(",").append(searchStatus)
													.append(",").append(searchErrorSource)
													.append(",").append(searchErrorGroup)
													.append(",").append(searchErrorCode)
													.append(",").append(claimRefNo);
												//	logger.error("mfid is in CsvService 9th :: "+ encounterVO.getMfId());
//													starts :  IFOX-00377243
													if(Constants.CIGNA_HCFs.contains(encounterVO.getMfId())) 
													s.append(",").append(custClmNbr);
//													ends :  IFOX-00377243
													s.append(",").append(claimRevNo);
													//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
													if(Constants.CIGNA_HCFs.contains(encounterVO.getMfId())) 
													s.append(",").append(patCtrlNbr);
													//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
													s.append(",").append(hicNBR)											
													 .append(",").append(mbi)
													.append(",").append(formatedServiceDate)
													.append(",").append(formatedSubmissionDate)
													.append(",").append(fileType)
													.append(",").append(processStatus)
													.append(",").append(cmsIcn) //IFOX-00415108 - Add CMS ICN to the export
													.append(",").append(inItrchgCtrlNbr)
													//Ifox - 00391283 Export adding fields Intrchg ctrl nbr, Receiver Id 
													.append(",").append(origIntrchgCtrlNbr)   //origIntrchgCtrlNbr
													.append(",").append(receiverId)   //rcvrId
													//Ifox - 00391283 Export adding fields Intrchg ctrl nbr, Receiver Id
													//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export Start
													.append(",").append(groupPolicyNbr)
													.append(",").append(payerSecId)
													//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export End
													.append(",").append(errSegment)
													.append(",").append(errCode)
													.append(",").append(errSource)
													.append(",").append(errGrp)
													.append(",").append(clmli_seq_nbr)
													.append(",").append(CSVUtil.quoteString(errDescription))
													.append(",").append(mao4status)	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
													.append(",").append(allowedDisallowedFlag);	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
													
													stream.write((s+LINE_SEPARATOR).getBytes());
													s = new StringBuffer();
												}																
											}							
										}
										
										errSegment = "";
										errSource = "";
										errGrp = "";
										errCode = "";
										clmli_seq_nbr = 0;
										errDescription = "";						
									}	
									
									if (flag.equals("false")) {
										s.append(source)
										.append(",").append(extractDate)
										.append(",").append(submitterId)
										.append(",").append(dateType)
										.append(",").append(searchFrom)
										.append(",").append(searchTo)
										.append(",").append(claimType)
										.append(",").append(searchClaimNBR)
										.append(",").append(StringUtils.isEmpty(searchHicNBR)?"":hicNBR);
										//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
										if(Constants.CIGNA_HCFs.contains(encounterVO.getMfId())) 
										s.append(",").append(searchVanTraceNbr);
										//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
										s.append(",").append(StringUtils.isEmpty(searchHicNBR)?"":mbi)	
										.append(",").append(searchStatus)
										.append(",").append(searchErrorSource)
										.append(",").append(searchErrorGroup)
										.append(",").append(searchErrorCode)
										.append(",").append(claimRefNo);
									//	logger.error("mfid is in CsvService 10th :: "+ encounterVO.getMfId());
//										starts :  IFOX-00377243
										if(Constants.CIGNA_HCFs.contains(encounterVO.getMfId()) ) 
										s.append(",").append(custClmNbr);
//										ends :  IFOX-00377243
										s.append(",").append(claimRevNo);
										//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : Start
										if(Constants.CIGNA_HCFs.contains(encounterVO.getMfId())) 
										s.append(",").append(patCtrlNbr);
										//**IFOX-00392958 ** - (Supplemental(HCC) Unique ID changes for CHS customer alone) : End
										s.append(",").append(hicNBR)											
										.append(",").append(mbi)
										.append(",").append(formatedServiceDate)
										.append(",").append(formatedSubmissionDate)
										.append(",").append(fileType)
										.append(",").append(processStatus)
										.append(",").append(cmsIcn) //IFOX-00415108 - Add CMS ICN to the export
										.append(",").append(inItrchgCtrlNbr)
										//Ifox - 00391283 Export adding fields Intrchg ctrl nbr, Receiver Id 
										.append(",").append(origIntrchgCtrlNbr)   //origIntrchgCtrlNbr
										.append(",").append(receiverId)   //rcvrId
										//Ifox - 00391283 Export adding fields Intrchg ctrl nbr, Receiver Id
										//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export Start
										.append(",").append(groupPolicyNbr)
										.append(",").append(payerSecId)
										//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export End
										.append(",").append(errSegment)
										.append(",").append(errCode)
										.append(",").append(errSource)
										.append(",").append(errGrp)
										.append(",").append(clmli_seq_nbr)
										.append(",").append(CSVUtil.quoteString(errDescription))
										.append(",").append(mao4status)	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
										.append(",").append(allowedDisallowedFlag);	// ** IFOX-00403428 ** - (Include MAO004 field in EDS Portal)
										stream.write((s+LINE_SEPARATOR).getBytes());
									}			
								}									
							}
						} else if ("ALL".equals(uiContextRange)) {
							chartEncounterDao = DaoFactory.getInstance().getChartEncounterDao();
							fileName = chartEncounterDao.getEncounterData(conn,context, encounterVO,fileName,claimType);
						}					
					}
				}
			}			
			logger.debug(" CsvService encounterVO #####----"+dateFormat.format(Calendar.getInstance().getTime()));	
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createProfileDetail method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createProfileDetail method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		
		if(!exportType.equalsIgnoreCase("CSV"))
			fileName = convertToTXTFile(fileName, exportType);
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}	
	
	//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export Start
	private String getModifiedGrpOrPolNum(String grpOrPolNum) {
		
		if(grpOrPolNum.equals("BAMC"))
			return "BMG";
		else if(grpOrPolNum.equals("AMC"))
			return "BMG";
		else if(grpOrPolNum.equals("AIP"))
			return "NPA";
		else if(grpOrPolNum.equals("MAIP"))
			return "NPA";
		else if(grpOrPolNum.equals("LEG"))
			return "NPA";
		else if(grpOrPolNum.equals("BPHO"))
			return "NPA";
		else if(grpOrPolNum.equals("PHO"))
			return "NPA";
		else if(grpOrPolNum.equals("MAR"))
			return "NPA";
		else if(grpOrPolNum.equals("JCL"))
			return "ICP";
		else if(grpOrPolNum.equals("SHC"))
			return "ICP";
		else if(grpOrPolNum.equals("SHCP"))
			return "ICP";
		else if(grpOrPolNum.equals("PIMA"))
			return "PIMA";
		else if(grpOrPolNum.equals("Carondelet"))
			return "PIMA";
		else if(grpOrPolNum.equals("SCZ"))
			return "SANTA CRUZ";
		else
			return grpOrPolNum;
	}
	//IFOX-00416818 & IFOX-00416820 - Add GroupOrPolicy Number and Contract Id to the Export End
	
	public String convertToTXTFile(String fileName, String exportType) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		BufferedReader bin = null;
		BufferedWriter bout = null;
		final int XLSDPI = 267;
		String dstTXTFile = null;
		
		try {
			
//			txt file containing output data
			int index = fileName.indexOf(".");
			dstTXTFile = fileName.subSequence(0, index)+".txt";
			
//			create BufferedWriter to write txt file
			bout = new BufferedWriter( new FileWriter(dstTXTFile));
			
//			create BufferedReader to read csv file
			bin = new BufferedReader( new FileReader(fileName));
			String strLine; 
			StringTokenizer st = null;
			int tokenNumber = 0;
	
//			read comma separated file line by line
			while( (strLine = bin.readLine()) != null) {
				bout.write(strLine);
				bout.newLine();
//				reset token number
				tokenNumber = 0;
	
			}
		}catch(Exception e){
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("Exception while reading csv file: " + e);
		}finally{
			try{
				if(bout != null)
					bout.close();
				if(bin != null)
					bin.close();
			}catch(Exception ex){
				logger.error(LoggerConstants.exceptionMessage(ex.toString()));
				logger.debug("Exception while reading csv file: " + ex);
			}
		}
		
		if(!exportType.equalsIgnoreCase("TXT"))
			dstTXTFile = convertToExcel(dstTXTFile);
		logger.info(LoggerConstants.methodEndLevel());
		return dstTXTFile;
		
	}
	
	public String convertToExcel(String fileName) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String dstXLSFile = null;
		
		BufferedReader bin = null;
		FileOutputStream fileOut = null;
		List arList = null;
		List al = null;
		String thisLine; 
		
		int count=0; 
		logger.debug("START TIME === " + new Date());
		
		try {
		
			bin = new BufferedReader(new FileReader(fileName));
			int i=0;
			arList = new ArrayList();
			
			while ((thisLine = bin.readLine()) != null){
	
				al = new ArrayList();
				String strar[] = thisLine.split(",");
				for(int j=0;j<strar.length;j++){
					al.add(strar[j]);
				}
				arList.add(al);
				i++;
			} 
			
			int index = fileName.indexOf(".");
			dstXLSFile = fileName.subSequence(0, index)+".xls";
			fileOut = new FileOutputStream(dstXLSFile);
			
			HSSFWorkbook hwb = new HSSFWorkbook();
			int sheetCt = 0;
			int minCt = 0;
			int maxCt = arList.size();
			int limit = 64000;

			if(arList.size() > limit){
				int rowCtRem = arList.size()%64000;
				sheetCt = (arList.size()-rowCtRem)/64000;
			}else
				limit = maxCt;
			
			for(int q=0; q<= sheetCt; q++){
				
				List arrList = new ArrayList();
				arrList = arList.subList(minCt, limit);
				
				HSSFSheet sheet = hwb.createSheet("EDPS"+q);
				for(int k=0;k<arrList.size();k++) {

					ArrayList ardata = (ArrayList)arrList.get(k);
					HSSFRow row = sheet.createRow((short) 0+k);
					
					for(int p=0;p<ardata.size();p++){
						HSSFCell cell = row.createCell((short) p);
						cell.setCellValue(ardata.get(p).toString());
					}
				}
				
				minCt += limit;
				if(q+1 == sheetCt)
					limit = maxCt;
				else
					limit += limit;										
			}
			
			hwb.write(fileOut);
			
			logger.debug("END TIME === " + new Date());
			logger.debug("Your excel file has been generated");
			
		} catch (Exception ex ) {
			logger.error(LoggerConstants.exceptionMessage(ex.toString()));
		} //convertToXLS method ends
		finally {
			try{
				if(fileOut != null)
					fileOut.close();
				if(bin != null)
					bin.close();
			}catch(Exception ex){
				logger.error(LoggerConstants.exceptionMessage(ex.toString()));
				logger.debug("Exception while reading csv file: " + ex);
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return dstXLSFile;
	}
	
	
	/**
	 * This method is to export Encounter Details Log in to CSV Report
	 * @author raghu
	 * @param conn
	 * @param uiContextRange
	 * @param context
	 * @return String
	 * @throws ApplicationException
	 */
	public String createEncounterDetailLog(Connection conn, String uiContextRange, HPEContext context,String clmType,boolean historyFlag) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String fileName = null;		
		HPEEncounterVO encounterVO = null;
		if ("EN".equalsIgnoreCase(clmType) || "MD".equalsIgnoreCase(clmType)){
			encounterVO = context.getEncounterVO();
			Enc837ChangeClaimlogVOs claimLogList = context.getEncounterService().getChangeLogDetails(conn, encounterVO,historyFlag);
			fileName = createTempDataFile(claimLogList, getCvsFileName(), encounterVO, conn);//367728
		}else if ("CR".equalsIgnoreCase(clmType) || "MC".equalsIgnoreCase(clmType)){
			encounterVO = context.getChartEncounterVO();
			Enc837ChangeClaimlogVOs claimLogList = context.getChartEncounterService().getChangeLogDetails(conn, encounterVO,historyFlag);
			fileName = createTempDataFile(claimLogList, getCvsFileName(), encounterVO, conn);//367728
		}		
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;	
	}	
	
	// Passinf Connection argument for IFOX 367728
	private String createTempDataFile(Enc837ChangeClaimlogVOs claimLogList, String fileName, HPEEncounterVO encounterVO, Connection conn) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		FileOutputStream stream = null;
		
		try {
			stream = new FileOutputStream(new File(fileName));
			stream.write((ENCOUNTER_LOG_HEADING + LINE_SEPARATOR).getBytes());
			
			String claimRefNbr = encounterVO.getSelectedClaimRefNbr();
			int claimRevNbr = encounterVO.getSelectedClaimRevNbr();
			///*To add revision number in claim number IFOX 367728*/
			 DecimalFormat df = new DecimalFormat("00");
			 
			 String uniqueClaimFlag = getProfileEntry (encounterVO.getMfId(), conn, "FALSE");// IFOX 367728
				if (("TRUE").equals(uniqueClaimFlag)){
					claimRefNbr= claimRefNbr.substring(0,3)+ df.format(claimRevNbr) + claimRefNbr.substring(5);/*To add revision number in claim number IFOX 367728*/	}
		
			for (int i = 0; i < claimLogList.size(); i++) {
				Enc837ChangeClaimlogVO claimLog = (Enc837ChangeClaimlogVO)claimLogList.get(i);
				StringBuffer sbf = new StringBuffer();
				sbf.append(claimRefNbr)
				   .append(",").append(claimRevNbr)
				   .append(",").append(StringUtil.nonNullTrim(claimLog.getLogTime()))
				   .append(",").append(StringUtil.nonNullTrim(claimLog.getScreenBlock()))
				   .append(",").append(StringUtil.nonNullTrim(claimLog.getScreenField()))
				   .append(",").append(StringUtil.nonNullTrim(claimLog.getValueBefore()))
				   .append(",").append(StringUtil.nonNullTrim(claimLog.getValueAfter()))
				   .append(",").append(StringUtil.nonNullTrim(claimLog.getUserId()));
				
				stream.write((sbf + LINE_SEPARATOR).getBytes());
			}			
			
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createTempDataFile method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createTempDataFile method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	
	/**
	 * this method is to export Dashboard Details in CSV report
	 * @author Srity
	 * @version 1.1
	 * @param filterVO
	 * @param planMap
	 * @param planName
	 * @param pageStatus
	 * @param pageName
	 * @return
	 * @throws ApplicationException
	 */
	public String createDashboard(Connection conn, String uiContextRange, HPEContext context, String exportType,String clmType,String encType) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;	
		StringBuffer s = null;				
		String claimType = "";
		String source = null;
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		String dateType = "",searchFrom = "",searchTo = "";
		String submitterId = "", dateInd = "";
		
		String DASHBOARD_HEADING = ("E".equalsIgnoreCase(encType))?DASHBOARD_HEADING_DME:DASHBOARD_HEADING_I_P;
		
		ENCCodeCache cc = ENCCodeCache.getInstance();
		HashMap codes = cc.getHmENCDashboardStatusIndex();
		
		String[] monthShortNames = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
		String[] monthMMs = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }; 
		
		try{
			stream = new FileOutputStream(new File(fileName));	
			if("EN".equalsIgnoreCase(clmType) || "MD".equalsIgnoreCase(clmType)){
				source = "ENCDASH0";
				EncCmstatSumVOs searchSummaryResults = context.getEncounterVO().getSearchSummaryResults();
				submitterId = context.getEncounterVO().getSearchSummarySubmitterId();						
				searchFrom = DateFormatter.reFormat(context.getEncounterVO().getSearchSummaryFromDate(), DateFormatter.YYYYMM,DateFormatter.MM_YYYY);
				searchTo = DateFormatter.reFormat(context.getEncounterVO().getSearchSummaryToDate(), DateFormatter.YYYYMM,DateFormatter.MM_YYYY);		
				dateInd = context.getEncounterVO().getSearchSummaryDateInd();
				
				if (dateInd.equals("0")) {
					dateType = HPEConstants.HPE_SUBMISSION_DATE;				
				} else if (dateInd.equals("1")) {
					dateType = HPEConstants.HPE_SERVICE_DATE;				
				}
				
				GridUtil gridUtil = new GridUtil();
				GridUtil.Year year = null;
				GridUtil.Month month = null;
				GridUtil.Totals grandTotals = null;
				GridUtil.Totals yearTotals = null;
				GridUtil.Totals monthTotals = null;
				LinkedHashMap years = null;
				LinkedHashMap months = null;
				
				Iterator iterator = searchSummaryResults.iterator();
				while (iterator.hasNext()) {				
					EncCmstatSumVO encCmstatSumVO = (EncCmstatSumVO) iterator.next();
					Integer tempYear = Integer.valueOf(encCmstatSumVO.getDateYrmo().substring(0, 4));
					Integer tempMonth = Integer.valueOf(encCmstatSumVO.getDateYrmo().substring(4, 6));
					int encounters = encCmstatSumVO.getEncCount();
					
					if ((year == null) || (!year.getYear().equals(tempYear))) {
						year = gridUtil.getYears().addYear(tempYear);
						month = year.getMonths().addMonth(tempMonth);
					}
					if (!month.getMonth().equals(tempMonth)) {
						month = year.getMonths().addMonth(tempMonth);
					}

					if (encCmstatSumVO.getEncType().equals("I")) {
						grandTotals = gridUtil.getInstTotals();
						yearTotals = year.getInstTotals();
						monthTotals = month.getInstTotals();
					}
					if (encCmstatSumVO.getEncType().equals("P")) {
						grandTotals = gridUtil.getProfTotals();
						yearTotals = year.getProfTotals();
						monthTotals = month.getProfTotals();
					}if (encCmstatSumVO.getEncType().equals("E")) {
						grandTotals = gridUtil.getDmeTotals();
						yearTotals = year.getDmeTotals();
						monthTotals = month.getDmeTotals();
					}
					String group = (String)codes.get(encCmstatSumVO.getProcessStatus());
					if ("PEN".equals(group)) {
							grandTotals.setPending(grandTotals.getPending() + encounters);
							yearTotals.setPending(yearTotals.getPending() + encounters);
							monthTotals.setPending(monthTotals.getPending() + encounters);
					}
					else
					if ("ACC".equals(group)) {
							grandTotals.setAccepted(grandTotals.getAccepted() + encounters);
							yearTotals.setAccepted(yearTotals.getAccepted() + encounters);
							monthTotals.setAccepted(monthTotals.getAccepted() + encounters);
					}
					else
					if ("FAL".equals(group)) {
							grandTotals.setRejected(grandTotals.getRejected() + encounters);
							yearTotals.setRejected(yearTotals.getRejected() + encounters);
							monthTotals.setRejected(monthTotals.getRejected() + encounters);
					}
					else
					if ("IGN".equals(group)) {
							grandTotals.setIgnored(grandTotals.getIgnored() + encounters);
							yearTotals.setIgnored(yearTotals.getIgnored() + encounters);
							monthTotals.setIgnored(monthTotals.getIgnored() + encounters);
					}
					grandTotals.setTotal(grandTotals.getTotal() + encounters);
					yearTotals.setTotal(yearTotals.getTotal() + encounters);
					monthTotals.setTotal(monthTotals.getTotal() + encounters);
				}
				
				//write heading row
				stream.write((DASHBOARD_HEADING+LINE_SEPARATOR).getBytes());			
				
				years = gridUtil.getYears();			
				Iterator itr = years.values().iterator();
				
				while (itr.hasNext()) {				
					year = (Year) itr.next();				
					int formatedYear = year.getYear().intValue();				
					months = year.getMonths();
					Iterator itr1 = months.values().iterator();	
					
					while(itr1.hasNext()) {
						month = (Month) itr1.next();					
						String monthMM = monthMMs[month.getMonth().intValue() - 1];
	                    String formatedDate = monthMM + "/" + formatedYear; 
						
						s = new StringBuffer();			
						s.append(source)
						.append(",").append(extractDate)
						.append(",").append(submitterId)
						.append(",").append(searchFrom.toString())
						.append(",").append(searchTo.toString())
						.append(",").append(dateType)
						.append(",").append(formatedDate.toString());
						if("E".equalsIgnoreCase(encType)){
							s.append(",").append(month.getDmeTotals().getPending())	//DME_Dashboard_changes
							.append(",").append(month.getDmeTotals().getAccepted())
							.append(",").append(month.getDmeTotals().getRejected())
							.append(",").append(month.getDmeTotals().getIgnored())
							.append(",").append(month.getDmeTotals().getTotal());
								
						}else{
						s.append(",").append(month.getInstTotals().getPending())		
						.append(",").append(month.getInstTotals().getAccepted())
						.append(",").append(month.getInstTotals().getRejected())
						.append(",").append(month.getInstTotals().getIgnored())
						.append(",").append(month.getInstTotals().getTotal())
						.append(",").append(month.getProfTotals().getPending())
						.append(",").append(month.getProfTotals().getAccepted())
						.append(",").append(month.getProfTotals().getRejected())
						.append(",").append(month.getProfTotals().getIgnored())
						.append(",").append(month.getProfTotals().getTotal());
						}
						stream.write((s+LINE_SEPARATOR).getBytes());
					}
				}				
			}else if("CR".equalsIgnoreCase(clmType) || "MC".equalsIgnoreCase(clmType)){
				source = "CRDASH0";
				EncCmstatSumVOs searchSummaryResults = context.getChartEncounterVO().getSearchSummaryResults();
				submitterId = context.getChartEncounterVO().getSearchSummarySubmitterId();						
				searchFrom = DateFormatter.reFormat(context.getChartEncounterVO().getSearchSummaryFromDate(), DateFormatter.YYYYMM,DateFormatter.MM_YYYY);
				searchTo = DateFormatter.reFormat(context.getChartEncounterVO().getSearchSummaryToDate(), DateFormatter.YYYYMM,DateFormatter.MM_YYYY);		
				dateInd = context.getChartEncounterVO().getSearchSummaryDateInd();
				
				if (dateInd.equals("0")) {
					dateType = HPEConstants.HPE_SUBMISSION_DATE;				
				} else if (dateInd.equals("1")) {
					dateType = HPEConstants.HPE_SERVICE_DATE;				
				}
				
				GridUtil gridUtil = new GridUtil();
				GridUtil.Year year = null;
				GridUtil.Month month = null;
				GridUtil.Totals grandTotals = null;
				GridUtil.Totals yearTotals = null;
				GridUtil.Totals monthTotals = null;
				LinkedHashMap years = null;
				LinkedHashMap months = null;
				
				Iterator iterator = searchSummaryResults.iterator();
				while (iterator.hasNext()) {				
					EncCmstatSumVO encCmstatSumVO = (EncCmstatSumVO) iterator.next();
					Integer tempYear = Integer.valueOf(encCmstatSumVO.getDateYrmo().substring(0, 4));
					Integer tempMonth = Integer.valueOf(encCmstatSumVO.getDateYrmo().substring(4, 6));
					int encounters = encCmstatSumVO.getEncCount();
					
					if ((year == null) || (!year.getYear().equals(tempYear))) {
						year = gridUtil.getYears().addYear(tempYear);
						month = year.getMonths().addMonth(tempMonth);
					}
					if (!month.getMonth().equals(tempMonth)) {
						month = year.getMonths().addMonth(tempMonth);
					}

					if (encCmstatSumVO.getEncType().equals("I")) {
						grandTotals = gridUtil.getInstTotals();
						yearTotals = year.getInstTotals();
						monthTotals = month.getInstTotals();
					}
					if (encCmstatSumVO.getEncType().equals("P")) {
						grandTotals = gridUtil.getProfTotals();
						yearTotals = year.getProfTotals();
						monthTotals = month.getProfTotals();
					}
					if (encCmstatSumVO.getEncType().equals("E")) {
						grandTotals = gridUtil.getDmeTotals();
						yearTotals = year.getDmeTotals();
						monthTotals = month.getDmeTotals();
					}
					String group = (String)codes.get(encCmstatSumVO.getProcessStatus());
					if ("PEN".equals(group)) {
							grandTotals.setPending(grandTotals.getPending() + encounters);
							yearTotals.setPending(yearTotals.getPending() + encounters);
							monthTotals.setPending(monthTotals.getPending() + encounters);
					}
					else
					if ("ACC".equals(group)) {
							grandTotals.setAccepted(grandTotals.getAccepted() + encounters);
							yearTotals.setAccepted(yearTotals.getAccepted() + encounters);
							monthTotals.setAccepted(monthTotals.getAccepted() + encounters);
					}
					else
					if ("FAL".equals(group)) {
							grandTotals.setRejected(grandTotals.getRejected() + encounters);
							yearTotals.setRejected(yearTotals.getRejected() + encounters);
							monthTotals.setRejected(monthTotals.getRejected() + encounters);
					}
					else
					if ("IGN".equals(group)) {
							grandTotals.setIgnored(grandTotals.getIgnored() + encounters);
							yearTotals.setIgnored(yearTotals.getIgnored() + encounters);
							monthTotals.setIgnored(monthTotals.getIgnored() + encounters);
					}
					grandTotals.setTotal(grandTotals.getTotal() + encounters);
					yearTotals.setTotal(yearTotals.getTotal() + encounters);
					monthTotals.setTotal(monthTotals.getTotal() + encounters);
				}
				
				//write heading row
				stream.write((DASHBOARD_HEADING+LINE_SEPARATOR).getBytes());			
				
				years = gridUtil.getYears();			
				Iterator itr = years.values().iterator();
				
				while (itr.hasNext()) {				
					year = (Year) itr.next();				
					int formatedYear = year.getYear().intValue();				
					months = year.getMonths();
					Iterator itr1 = months.values().iterator();	
					
					while(itr1.hasNext()) {
						month = (Month) itr1.next();					
						String monthMM = monthMMs[month.getMonth().intValue() - 1];
	                    String formatedDate = monthMM + "/" + formatedYear; 
						
						s = new StringBuffer();			
						s.append(source)
						.append(",").append(extractDate)
						.append(",").append(submitterId)
						.append(",").append(searchFrom.toString())
						.append(",").append(searchTo.toString())
						.append(",").append(dateType)
						.append(",").append(formatedDate.toString());
						if("E".equalsIgnoreCase(encType)){
							s.append(",").append(month.getDmeTotals().getPending())	//DME_Dashboard_changes
							.append(",").append(month.getDmeTotals().getAccepted())
							.append(",").append(month.getDmeTotals().getRejected())
							.append(",").append(month.getDmeTotals().getIgnored())
							.append(",").append(month.getDmeTotals().getTotal());
								
						}else{
						s.append(",").append(month.getInstTotals().getPending())		
						.append(",").append(month.getInstTotals().getAccepted())
						.append(",").append(month.getInstTotals().getRejected())
						.append(",").append(month.getInstTotals().getIgnored())
						.append(",").append(month.getInstTotals().getTotal())
						.append(",").append(month.getProfTotals().getPending())
						.append(",").append(month.getProfTotals().getAccepted())
						.append(",").append(month.getProfTotals().getRejected())
						.append(",").append(month.getProfTotals().getIgnored())
						.append(",").append(month.getProfTotals().getTotal());
						}
						stream.write((s+LINE_SEPARATOR).getBytes());
					}
				}			
			}
		 	
			
		}catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createDashboard method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createDashboard method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}		
		
		if(!exportType.equalsIgnoreCase("CSV"))
			fileName = convertToTXTFile(fileName, exportType);
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	
	/**
	 * this method is to export Reject Dashboard Details in CSV report
	 * @author Srity
	 * @version 1.0
	 * @param filterVO
	 * @param planMap
	 * @param planName
	 * @param pageStatus
	 * @param pageName
	 * @return
	 * @throws ApplicationException
	 */
	public String createRejectDashboard(Connection conn, String uiContextRange, HPEContext context, String exportType,String clmType,String encType) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String fileName = getCvsFileName();		
		FileOutputStream stream = null;	
		StringBuffer s = null;				
		String claimType = "";
		String source = null;
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		String dateType = "",searchFrom = "",searchTo = "";
		String submitterId = "", dateInd = "";
		
		String REJECTDASHBOARD_HEADING = ("E".equalsIgnoreCase(encType))?REJECTDASHBOARD_HEADING_DME:REJECTDASHBOARD_HEADING_I_P;
		
		String[] monthShortNames = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
		String[] monthMMs = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }; 
		
		try{
			stream = new FileOutputStream(new File(fileName));	
			
			if("EN".equalsIgnoreCase(clmType) || "MD".equalsIgnoreCase(clmType)){
				source = "ENCREJDASH0";
				EncErrorstatSumVOs searchSummaryResults = context.getEncounterVO().getSearchErrorSummaryResults();
				submitterId = context.getEncounterVO().getSearchSummarySubmitterId();						
				searchFrom = DateFormatter.reFormat(context.getEncounterVO().getSearchSummaryFromDate(), DateFormatter.YYYYMM,DateFormatter.MM_YYYY);
				searchTo = DateFormatter.reFormat(context.getEncounterVO().getSearchSummaryToDate(), DateFormatter.YYYYMM,DateFormatter.MM_YYYY);		
				dateInd = context.getEncounterVO().getSearchSummaryDateInd();
				
				if (dateInd.equals("0")) {
					dateType = HPEConstants.HPE_SUBMISSION_DATE;				
				} else if (dateInd.equals("1")) {
					dateType = HPEConstants.HPE_SERVICE_DATE;				
				}
				
				GridUtil gridUtil = new GridUtil();
				GridUtil.Year year = null;
				GridUtil.Month month = null;
				GridUtil.Totals grandTotals = null;
				GridUtil.Totals yearTotals = null;
				GridUtil.Totals monthTotals = null;
				LinkedHashMap years = null;
				LinkedHashMap months = null;
				
				Iterator iterator = searchSummaryResults.iterator();
				while (iterator.hasNext()) {									
					EncErrorstatSumVO encErrorstatSumVO = (EncErrorstatSumVO) iterator.next();
					Integer tempYear = Integer.valueOf(encErrorstatSumVO.getDateYrmo().substring(0, 4));
					Integer tempMonth = Integer.valueOf(encErrorstatSumVO.getDateYrmo().substring(4, 6));
					int errors = encErrorstatSumVO.getErrorCnt();
					
					if ((year == null) || (!year.getYear().equals(tempYear))) {
						year = gridUtil.getYears().addYear(tempYear);
						month = year.getMonths().addMonth(tempMonth);
					}
					if (!month.getMonth().equals(tempMonth)) {
						month = year.getMonths().addMonth(tempMonth);
					}
			
					if (encErrorstatSumVO.getEncType().equals("I")) {
						grandTotals = gridUtil.getInstTotals();
						yearTotals = year.getInstTotals();
						monthTotals = month.getInstTotals();
					}
					if (encErrorstatSumVO.getEncType().equals("P")) {
						grandTotals = gridUtil.getProfTotals();
						yearTotals = year.getProfTotals();
						monthTotals = month.getProfTotals();
					}if (encErrorstatSumVO.getEncType().equals("E")) {
						grandTotals = gridUtil.getDmeTotals();
						yearTotals = year.getDmeTotals();
						monthTotals = month.getDmeTotals();
					}
					
					String errorSource = encErrorstatSumVO.getErrorSource();	
					if ("CCR".equals(errorSource)) {
							grandTotals.setCCR(grandTotals.getCCR() + errors);
							yearTotals.setCCR(yearTotals.getCCR() + errors);
							monthTotals.setCCR(monthTotals.getCCR() + errors);
					}else if ("CMS".equals(errorSource)) {
							grandTotals.setRejected(grandTotals.getRejected() + errors);
							yearTotals.setRejected(yearTotals.getRejected() + errors);
							monthTotals.setRejected(monthTotals.getRejected() + errors);
					}
					grandTotals.setTotal(grandTotals.getTotal() + errors);
					yearTotals.setTotal(yearTotals.getTotal() + errors);
					monthTotals.setTotal(monthTotals.getTotal() + errors);				
				}
				
				//write heading row
				stream.write((REJECTDASHBOARD_HEADING+LINE_SEPARATOR).getBytes());			
				
				years = gridUtil.getYears();			
				Iterator itr = years.values().iterator();
				
				while (itr.hasNext()) {				
					year = (Year) itr.next();				
					int formatedYear = year.getYear().intValue();				
					months = year.getMonths();
					Iterator itr1 = months.values().iterator();	
					
					while(itr1.hasNext()) {
						month = (Month) itr1.next();					
						String monthMM = monthMMs[month.getMonth().intValue() - 1];
	                    String formatedDate = monthMM + "/" + formatedYear; 
						
						s = new StringBuffer();			
						s.append(source)
						.append(",").append(extractDate)
						.append(",").append(submitterId)
						.append(",").append(searchFrom.toString())
						.append(",").append(searchTo.toString())
						.append(",").append(dateType)
						.append(",").append(formatedDate.toString());
						if("E".equalsIgnoreCase(encType)){
						s.append(",").append(month.getDmeTotals().getCCR())
							.append(",").append(month.getDmeTotals().getRejected())					
							.append(",").append(month.getDmeTotals().getTotal());
						}else{
						s.append(",").append(month.getInstTotals().getCCR())
							.append(",").append(month.getInstTotals().getRejected())					
							.append(",").append(month.getInstTotals().getTotal())
							.append(",").append(month.getProfTotals().getCCR())
							.append(",").append(month.getProfTotals().getRejected())					
							.append(",").append(month.getProfTotals().getTotal());
						}
						stream.write((s+LINE_SEPARATOR).getBytes());
					}
				}				
			}else if("CR".equalsIgnoreCase(clmType) || "MC".equalsIgnoreCase(clmType)){
				source = "CRREJDASH0";
				EncErrorstatSumVOs searchSummaryResults = context.getChartEncounterVO().getSearchErrorSummaryResults();
				submitterId = context.getChartEncounterVO().getSearchSummarySubmitterId();						
				searchFrom = DateFormatter.reFormat(context.getChartEncounterVO().getSearchSummaryFromDate(), DateFormatter.YYYYMM,DateFormatter.MM_YYYY);
				searchTo = DateFormatter.reFormat(context.getChartEncounterVO().getSearchSummaryToDate(), DateFormatter.YYYYMM,DateFormatter.MM_YYYY);		
				dateInd = context.getChartEncounterVO().getSearchSummaryDateInd();
				
				if (dateInd.equals("0")) {
					dateType = HPEConstants.HPE_SUBMISSION_DATE;				
				} else if (dateInd.equals("1")) {
					dateType = HPEConstants.HPE_SERVICE_DATE;				
				}
				
				GridUtil gridUtil = new GridUtil();
				GridUtil.Year year = null;
				GridUtil.Month month = null;
				GridUtil.Totals grandTotals = null;
				GridUtil.Totals yearTotals = null;
				GridUtil.Totals monthTotals = null;
				LinkedHashMap years = null;
				LinkedHashMap months = null;
				
				Iterator iterator = searchSummaryResults.iterator();
				while (iterator.hasNext()) {									
					EncErrorstatSumVO encErrorstatSumVO = (EncErrorstatSumVO) iterator.next();
					Integer tempYear = Integer.valueOf(encErrorstatSumVO.getDateYrmo().substring(0, 4));
					Integer tempMonth = Integer.valueOf(encErrorstatSumVO.getDateYrmo().substring(4, 6));
					int errors = encErrorstatSumVO.getErrorCnt();
					
					if ((year == null) || (!year.getYear().equals(tempYear))) {
						year = gridUtil.getYears().addYear(tempYear);
						month = year.getMonths().addMonth(tempMonth);
					}
					if (!month.getMonth().equals(tempMonth)) {
						month = year.getMonths().addMonth(tempMonth);
					}
			
					if (encErrorstatSumVO.getEncType().equals("I")) {
						grandTotals = gridUtil.getInstTotals();
						yearTotals = year.getInstTotals();
						monthTotals = month.getInstTotals();
					}
					if (encErrorstatSumVO.getEncType().equals("P")) {
						grandTotals = gridUtil.getProfTotals();
						yearTotals = year.getProfTotals();
						monthTotals = month.getProfTotals();
					}
					if (encErrorstatSumVO.getEncType().equals("E")) {
						grandTotals = gridUtil.getDmeTotals();
						yearTotals = year.getDmeTotals();
						monthTotals = month.getDmeTotals();
					}
										
					String errorSource = encErrorstatSumVO.getErrorSource();	
					if ("CCR".equals(errorSource)) {
							grandTotals.setCCR(grandTotals.getCCR() + errors);
							yearTotals.setCCR(yearTotals.getCCR() + errors);
							monthTotals.setCCR(monthTotals.getCCR() + errors);
					}else if ("CMS".equals(errorSource)) {
							grandTotals.setRejected(grandTotals.getRejected() + errors);
							yearTotals.setRejected(yearTotals.getRejected() + errors);
							monthTotals.setRejected(monthTotals.getRejected() + errors);
					}
					grandTotals.setTotal(grandTotals.getTotal() + errors);
					yearTotals.setTotal(yearTotals.getTotal() + errors);
					monthTotals.setTotal(monthTotals.getTotal() + errors);				
				}
				
				//write heading row
				stream.write((REJECTDASHBOARD_HEADING+LINE_SEPARATOR).getBytes());			
				
				years = gridUtil.getYears();			
				Iterator itr = years.values().iterator();
				
				while (itr.hasNext()) {				
					year = (Year) itr.next();				
					int formatedYear = year.getYear().intValue();				
					months = year.getMonths();
					Iterator itr1 = months.values().iterator();	
					
					while(itr1.hasNext()) {
						month = (Month) itr1.next();					
						String monthMM = monthMMs[month.getMonth().intValue() - 1];
	                    String formatedDate = monthMM + "/" + formatedYear; 
						
						s = new StringBuffer();			
						s.append(source)
						.append(",").append(extractDate)
						.append(",").append(submitterId)
						.append(",").append(searchFrom.toString())
						.append(",").append(searchTo.toString())
						.append(",").append(dateType)
						.append(",").append(formatedDate.toString());
						if ("E".equalsIgnoreCase(encType)) {
							s.append(",").append(month.getDmeTotals().getCCR()).append(",")
									.append(month.getDmeTotals().getRejected()).append(",")
									.append(month.getDmeTotals().getTotal());
						} else {
							s.append(",").append(month.getInstTotals().getCCR()).append(",")
									.append(month.getInstTotals().getRejected()).append(",")
									.append(month.getInstTotals().getTotal()).append(",")
									.append(month.getProfTotals().getCCR()).append(",")
									.append(month.getProfTotals().getRejected()).append(",")
									.append(month.getProfTotals().getTotal());
						}
						stream.write((s + LINE_SEPARATOR).getBytes());
					}
			}
		}
		}catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createRejectDashboard method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createRejectDashboard method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}		
		
		if(!exportType.equalsIgnoreCase("CSV"))
			fileName = convertToTXTFile(fileName, exportType);
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}
	
	/**
	 * this method is to export Error Dashboard Details in CSV report
	 * @author Srity
	 * @version 1.0
	 * @param filterVO
	 * @param planMap
	 * @param planName
	 * @param pageStatus
	 * @param pageName
	 * @return
	 * @throws ApplicationException
	 */
	public String createErrorDashboard(Connection conn, String uiContextRange, HPEContext context, String exportType,String clmType) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		String fileName = getCvsFileName();		
		ENCCodeCache cc = ENCCodeCache.getInstance();
		FileOutputStream stream = null;	
		StringBuffer s = null;				
		String claimType = "";
		String source = null;
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		String dateType = "";
		String searchFrom = "";
		String searchTo = "";
		String submitterId = "";
		String dateInd = "";
		String srchErrorSource = "";
		String srchErrorGroup = "";
		String srchErrorCode = "";		
		String flag = "false";	
		HPEEncounterVO encounterVO = null;
		
		String[] monthShortNames = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
		String[] monthMMs = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }; 		
		
		ArrayList srcLst = cc.getLstENCErrorSource();
		ArrayList grpLst = cc.getLstENCErrorGroup();
		try{			
			stream = new FileOutputStream(new File(fileName));				
			if("EN".equalsIgnoreCase(clmType) || "MD".equalsIgnoreCase(clmType)){
				source = "ENCERRDASH0";	
				encounterVO = context.getEncounterVO();
				submitterId = encounterVO.getSearchSummarySubmitterId();						
				searchFrom = DateFormatter.reFormat(encounterVO.getSearchSummaryFromDate(), DateFormatter.YYYYMM,DateFormatter.MM_YYYY);
				searchTo = DateFormatter.reFormat(encounterVO.getSearchSummaryToDate(), DateFormatter.YYYYMM,DateFormatter.MM_YYYY);		
				dateInd = encounterVO.getSearchSummaryDateInd();			
				if (encounterVO.getSearchSummaryErrorSource()!= null){
					srchErrorSource = encounterVO.getSearchSummaryErrorSource();
					srchErrorSource = cc.getListBoxDesc(srchErrorSource,srcLst);
					
					if (srchErrorSource == null)
						srchErrorSource = encounterVO.getSearchSummaryErrorSource();				
				}
				if (encounterVO.getSearchSummaryErrorGroup()!= null){
					srchErrorGroup = encounterVO.getSearchSummaryErrorGroup();
					srchErrorGroup = cc.getListBoxDesc(srchErrorGroup,grpLst);
					
					if (srchErrorGroup == null)
						srchErrorGroup = encounterVO.getSearchSummaryErrorGroup();				
				}
				
				if (encounterVO.getSearchSummaryErrorCode()!= null){
					srchErrorCode = encounterVO.getSearchSummaryErrorCode();
				}
				
				if (encounterVO.getSearchSummaryEncType() != null) {
					claimType = encounterVO.getSearchSummaryEncType();
					if (claimType.equals("I")) {
						claimType = HPEConstants.HPE_INSTITUTIONAL;				
					} else if (claimType.equals("P")) {
						claimType = HPEConstants.HPE_PROFESSIONAL;				
					}else if (claimType.equals("E")) {
						claimType = HPEConstants.HPE_DME;				
					}
					flag = "true";
				}else {
					claimType = HPEConstants.HPE_INSTITUTIONAL;			
				}
				
				
				if (dateInd.equals("0")) {
					dateType = HPEConstants.HPE_SUBMISSION_DATE;				
				} else if (dateInd.equals("1")) {
					dateType = HPEConstants.HPE_SERVICE_DATE;				
				}
				
				//write heading row
				stream.write((ERRORDASHBOARD_HEADING+LINE_SEPARATOR).getBytes());
				if (flag.equals("true")) {
					EncErrorstatSumVOs errorLists = encounterVO.getSearchErrorSummaryResults();
					Iterator iterator = errorLists.iterator();
					String srcDesc;
					String grpDesc;
					String errDescription;
					while (iterator.hasNext()) {									
						EncErrorstatSumVO encErrorstatSumVO = (EncErrorstatSumVO) iterator.next();
						
						srcDesc = cc.getListBoxDesc(encErrorstatSumVO.getErrorSource(),srcLst);
						if (srcDesc == null)
							srcDesc = encErrorstatSumVO.getErrorSource();
						grpDesc = cc.getListBoxDesc(encErrorstatSumVO.getErrorGroup(),grpLst);
						if (grpDesc == null)
							grpDesc = encErrorstatSumVO.getErrorGroup();
						
						s = new StringBuffer();			
						s.append(source)
						.append(",").append(extractDate)
						.append(",").append(submitterId)
						.append(",").append(claimType)				
						.append(",").append(searchFrom.toString())
						.append(",").append(searchTo.toString())
						.append(",").append(srchErrorSource)
						.append(",").append(srchErrorGroup)
						.append(",").append(srchErrorCode)	
						.append(",").append(dateType)
						.append(",").append(encErrorstatSumVO.getDateYrmo())					
						.append(",").append(srcDesc)
						.append(",").append(grpDesc)
						.append(",").append(encErrorstatSumVO.getRejectCode())
						.append(",").append(CSVUtil.quoteString(encErrorstatSumVO.getErrorDescription()))								
						.append(",").append(encErrorstatSumVO.getErrorCnt())
						.append(",").append(encErrorstatSumVO.getClmCnt())
						.append(",").append(encErrorstatSumVO.getEncType());
						stream.write((s+LINE_SEPARATOR).getBytes());				
					}	
				}				
			}else if("CR".equalsIgnoreCase(clmType) || "MC".equalsIgnoreCase(clmType)){
				source = "CRERRDASH0";		
				encounterVO = context.getChartEncounterVO();
				submitterId = encounterVO.getSearchSummarySubmitterId();						
				searchFrom = DateFormatter.reFormat(encounterVO.getSearchSummaryFromDate(), DateFormatter.YYYYMM,DateFormatter.MM_YYYY);
				searchTo = DateFormatter.reFormat(encounterVO.getSearchSummaryToDate(), DateFormatter.YYYYMM,DateFormatter.MM_YYYY);		
				dateInd = encounterVO.getSearchSummaryDateInd();			
				if (encounterVO.getSearchSummaryErrorSource()!= null){
					srchErrorSource = encounterVO.getSearchSummaryErrorSource();
					srchErrorSource = cc.getListBoxDesc(srchErrorSource,srcLst);
					
					if (srchErrorSource == null)
						srchErrorSource = encounterVO.getSearchSummaryErrorSource();				
				}
				if (encounterVO.getSearchSummaryErrorGroup()!= null){
					srchErrorGroup = encounterVO.getSearchSummaryErrorGroup();
					srchErrorGroup = cc.getListBoxDesc(srchErrorGroup,grpLst);
					
					if (srchErrorGroup == null)
						srchErrorGroup = encounterVO.getSearchSummaryErrorGroup();				
				}
				
				if (encounterVO.getSearchSummaryErrorCode()!= null){
					srchErrorCode = encounterVO.getSearchSummaryErrorCode();
				}
				
				if (encounterVO.getSearchSummaryEncType() != null) {
					claimType = encounterVO.getSearchSummaryEncType();
					if (claimType.equals("I")) {
						claimType = HPEConstants.HPE_INSTITUTIONAL;				
					} else if (claimType.equals("P")) {
						claimType = HPEConstants.HPE_PROFESSIONAL;				
					}else if (claimType.equals("E")) {
						claimType = HPEConstants.HPE_DME;				
					}
					flag = "true";
				}else {
					claimType = HPEConstants.HPE_INSTITUTIONAL;			
				}
				
				
				if (dateInd.equals("0")) {
					dateType = HPEConstants.HPE_SUBMISSION_DATE;				
				} else if (dateInd.equals("1")) {
					dateType = HPEConstants.HPE_SERVICE_DATE;				
				}
				
				//write heading row
				stream.write((ERRORDASHBOARD_HEADING+LINE_SEPARATOR).getBytes());
				if (flag.equals("true")) {
					EncErrorstatSumVOs errorLists = encounterVO.getSearchErrorSummaryResults();
					Iterator iterator = errorLists.iterator();
					String srcDesc;
					String grpDesc;
					String errDescription;
					while (iterator.hasNext()) {									
						EncErrorstatSumVO encErrorstatSumVO = (EncErrorstatSumVO)iterator.next();
						
						srcDesc = cc.getListBoxDesc(encErrorstatSumVO.getErrorSource(),srcLst);
						if (srcDesc == null)
							srcDesc = encErrorstatSumVO.getErrorSource();
						grpDesc = cc.getListBoxDesc(encErrorstatSumVO.getErrorGroup(),grpLst);
						if (grpDesc == null)
							grpDesc = encErrorstatSumVO.getErrorGroup();
						
						s = new StringBuffer();			
						s.append(source)
						.append(",").append(extractDate)
						.append(",").append(submitterId)
						.append(",").append(claimType)				
						.append(",").append(searchFrom.toString())
						.append(",").append(searchTo.toString())
						.append(",").append(srchErrorSource)
						.append(",").append(srchErrorGroup)
						.append(",").append(srchErrorCode)	
						.append(",").append(dateType)
						.append(",").append(encErrorstatSumVO.getDateYrmo())					
						.append(",").append(srcDesc)
						.append(",").append(grpDesc)
						.append(",").append(encErrorstatSumVO.getRejectCode())
						.append(",").append(CSVUtil.quoteString(encErrorstatSumVO.getErrorDescription()))									
						.append(",").append(encErrorstatSumVO.getErrorCnt())
						.append(",").append(encErrorstatSumVO.getClmCnt())
						.append(",").append(encErrorstatSumVO.getEncType());
						stream.write((s+LINE_SEPARATOR).getBytes());				
					}	
				}
			 }
		 
			
		}catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createErrorDashboard method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createErrorDashboard method", e);
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}	
		
		if(!exportType.equalsIgnoreCase("CSV"))
			fileName = convertToTXTFile(fileName, exportType);
		logger.info(LoggerConstants.methodEndLevel());
		return fileName;
	}

	public HSSFWorkbook createMcaidPaymentDashBoard(McaidReconPaymentVO paymentVO, String mfId)
			throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
		StringBuffer s = null;	
		
		
		String fileName = getCvsFileName();
		String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
		
		FileOutputStream stream = null;
		 HSSFWorkbook workbook =null;
		
		try {
			//List summData = new McaidILDao().getpaymentSummData(conn, mfId, filterVO);
			
			List summData = new ArrayList();
//			logger.error("CsvService.createMcaidPaymentDashBoard()::::::::::: "+paymentVO.getMcaidPymntDsbPBPLst().size());
//			summData.add("001");
//			summData.add("$2143214");
//			summData.add("$2143214");			
			  workbook = createWorkbook(paymentVO.getMcaidPymntDsbPBPLst());
			
		} catch (FileNotFoundException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPaymentDashBoard method", e);
		} catch (IOException e) {
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in createPaymentDashBoard method", e);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug(e.getMessage());
		} finally {
			try {
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
			}
		}
		logger.info(LoggerConstants.methodEndLevel());
		return workbook;
	}
	
	
	//Added for IFOX 367728 To get profile entry for unique claim number changes*/
	public String getProfileEntry(String mfId ,Connection conn, String uniqueClaimInd) throws ApplicationException {
		logger.info(LoggerConstants.methodStartLevel());
	  String   SQL = "SELECT OVERRIDE_IND FROM ENC_PROFILE WHERE PARM_CD = ? AND Mf_id = ?";
	  try{
	     PreparedStatement  psState = conn.prepareStatement(SQL);
	        psState.setString(1, "UNIQUE");
	       
	        psState.setString(2, mfId);
	        ResultSet rsState = psState.executeQuery();
	        if (rsState.next()) {
	        String val = StringUtil.nonNullTrim(rsState.getString("OVERRIDE_IND"));
	        if (val != null) {
				if (val.equalsIgnoreCase("N"))
					uniqueClaimInd = "TRUE";
				else if (val.equalsIgnoreCase("Y"))
					uniqueClaimInd = "FALSE";
	        }}}
	  catch(SQLException e){
		  logger.error(LoggerConstants.exceptionMessage(e.toString()));
			logger.debug("createCSV: caught Exception: " + e.getMessage());
			throw new ApplicationException("Error in getProfileEntry method", e);
		  
	  }
	  logger.info(LoggerConstants.methodEndLevel());
	  return uniqueClaimInd;
	  
	}
  
	 public HSSFWorkbook createWorkbook(List paymentData) throws Exception {
		 logger.info(LoggerConstants.methodStartLevel());
	        HSSFWorkbook wb = new HSSFWorkbook();
	        HSSFSheet sheet = wb.createSheet("User Data");
	       
//            McaidDiscDashboardVO pbpData = (McaidDiscDashboardVO) dataList.get(pbpIndex);
//            index++;
//            row = sheet.createRow(index);


		        /**
		         * Setting the width of the first three columns.
		         */
		        sheet.setColumnWidth((short)0, (short)3500);
		        sheet.setColumnWidth((short)1, (short)7500);
		        sheet.setColumnWidth((short)2, (short)5000);

		        /**
		         * Style for the header cells.
		         */
		        HSSFCellStyle headerCellStyle = wb.createCellStyle();
		        HSSFFont boldFont = wb.createFont();
		        boldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		        headerCellStyle.setFont(boldFont);

		        HSSFRow row = sheet.createRow(0);
		        HSSFCell cell = row.createCell((short)0);
		        cell.setCellStyle(headerCellStyle);
		        cell.setCellValue(new HSSFRichTextString("PBP"));
		        cell = row.createCell((short) 1);
		        cell.setCellStyle(headerCellStyle);
		        cell.setCellValue(new HSSFRichTextString("CMS Paid"));
		        cell = row.createCell((short)2);
		        cell.setCellStyle(headerCellStyle);
		        cell.setCellValue(new HSSFRichTextString("Plan Expected"));

		        for (int index = 0; index < paymentData.size(); index++) {
		        McaidPaymentDashBoardVO paymentVO = (McaidPaymentDashBoardVO) paymentData.get(index);
		            row = sheet.createRow(index);
		            cell = row.createCell((short)0);
//		            String vo = (String) paymentData.get(index);
		            HSSFRichTextString pbp = new HSSFRichTextString(paymentVO.getPbpId());
		            cell.setCellValue(pbp);
		            cell = row.createCell((short)1);
		            HSSFRichTextString cmsPaid = new HSSFRichTextString(paymentVO.getCmsPaid());
		            cell.setCellValue(cmsPaid);
		            cell = row.createCell((short)2);
		            HSSFRichTextString planExpected = new HSSFRichTextString(paymentVO.getPlanExpected());
		            cell.setCellValue(planExpected);
		            
		        }
		        logger.info(LoggerConstants.methodEndLevel());
	        return wb;
	    }
	 
	 
	 
	 public String createFileTrackingExportExcel(Connection conn, String uiContextRange, HPEContext context, String exportType, String clmType) throws ApplicationException {
		 logger.info(LoggerConstants.methodStartLevel());
		 
		 String claimType = "";
			String clmNumber = "";
			String source = null;
			String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
			String dateType = "",searchFrom = "",searchTo = "";
			String submitId = "", dateInd = "";
			
			String fileName = MssProperties.getExportLocation()+ File.separator + System.currentTimeMillis() + ".xls";
			
			BufferedOutputStream stream = null;	
			HPEFTService hpeftService = new HPEFTService();
			HPEFileTrackDao fileTrackDao = new HPEFileTrackDao();
			List<HPEFTDailyFileProcessingDO> exportDashResultLst = null; 
			final StringBuffer headerNames = new StringBuffer();
			StringBuffer s = null;
			
			ENCCodeCache cc = ENCCodeCache.getInstance();
			HashMap codes = cc.getHmENCDashboardStatusIndex();
			
			final String EXPORT_HEADER_NAMES = "CUST_FILE_NAME, File ID, EN, Recieved, 837 File Name, Submitted, 999 RSP FILE NAME, 999 ACC,999 REJ, 277 RSP FILE NAME, 277 ACC, 277 REJ, MAO002 FILE NAME, MAO002 ACC, MAO002 REJ, Wipro REJ";
			final String LINE_SEPARATOR = System.getProperty("line.separator");
			if(context.getHpeftSearchVO()!=null){
				exportDashResultLst = new ArrayList<HPEFTDailyFileProcessingDO>();
				
				if(context.getHpeftSearchVO().getSearchBy()!=null && context.getHpeftSearchVO().getSearchBy().equals(HPEConstants.FILETRACK_SEARCH_BY_FILEID) && context.getHpeftSearchVO().getOrig_intrchg_ctrl_nbr()!=null && !context.getHpeftSearchVO().getOrig_intrchg_ctrl_nbr().isEmpty()){
					exportDashResultLst= fileTrackDao.searchDailyFileProcessingByFileId(conn, context.getHpeftSearchVO().getMfId(), context.getHpeftSearchVO().getSearchSubmitterId(), context.getHpeftSearchVO().getSearchEncType(), context.getHpeftSearchVO().getOrig_intrchg_ctrl_nbr());
				}
				
				else if(context.getHpeftSearchVO().getSearchBy()!=null && context.getHpeftSearchVO().getSearchBy().equals(HPEConstants.FILETRACK_SEARCH_BY_FILENAME) && context.getHpeftSearchVO().getFileName()!=null && !context.getHpeftSearchVO().getFileName().isEmpty()){
					exportDashResultLst= fileTrackDao.searchDailyFileProcessingByFileName(conn, context.getHpeftSearchVO().getMfId(), context.getHpeftSearchVO().getSearchSubmitterId(), context.getHpeftSearchVO().getSearchEncType(), context.getHpeftSearchVO().getFileName());
				}
				else if(context.getHpeftSearchVO().getClmType() != "N" && !context.getHpeftSearchVO().getClaimNumber().isEmpty()){
					exportDashResultLst = hpeftService.searchClaim(conn, context.getHpeftSearchVO());
				}
				
			}
			
		
			
			try{
		    stream = new BufferedOutputStream(new FileOutputStream(new File(fileName)));
	        HSSFWorkbook wb = new HSSFWorkbook();
	        HSSFSheet sheet = wb.createSheet("FileTrack Export");
		        /**
		         * Setting the width of the first three columns.
		         */
		        sheet.setColumnWidth((short)0, (short)3500);
		        sheet.setColumnWidth((short)1, (short)7500);
		        sheet.setColumnWidth((short)2, (short)5000);

		        /**
		         * Style for the header cells.
		         */
		           
		        
		        HSSFCellStyle headerCellStyle = wb.createCellStyle();
		        HSSFFont boldFont = wb.createFont();
		        boldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		        headerCellStyle.setFont(boldFont);

		        HSSFRow row = sheet.createRow(0);
		        HSSFCell cell = row.createCell((short)0);
		        cell.setCellStyle(headerCellStyle);
		        cell.setCellValue(new HSSFRichTextString("PBP"));
		        cell = row.createCell((short) 1);
		        cell.setCellStyle(headerCellStyle);
		        cell.setCellValue(new HSSFRichTextString("CMS Paid"));
		        cell = row.createCell((short)2);
		        cell.setCellStyle(headerCellStyle);
		        cell.setCellValue(new HSSFRichTextString("Plan Expected"));
		        
		        
		        
		        for (int index = 0; index < exportDashResultLst.size(); index++) {
		        	HPEFTDailyFileProcessingDO hpeDo = (HPEFTDailyFileProcessingDO)exportDashResultLst.get(index);
		        	 row = sheet.createRow(index+1);
			            cell = row.createCell((short)0);
			            HSSFRichTextString pbp = new HSSFRichTextString(hpeDo.getCms837Name());
			            cell.setCellValue(pbp);			          
			            HSSFCellStyle style = wb.createCellStyle(); //Create new style
			            style.setWrapText(true);
			            cell = row.createCell((short)1);
			            HSSFRichTextString cmsPaid = new HSSFRichTextString(hpeDo.getCms277Name());
			            cell.setCellValue(cmsPaid);
			            cell = row.createCell((short)2);
			            HSSFRichTextString planExpected = new HSSFRichTextString(hpeDo.getCmsMAOName());
			            cell.setCellValue(planExpected);
		        }

		        FileOutputStream fileOut = new FileOutputStream(fileName);
		        wb.write(fileOut);
		        fileOut.flush();
		        fileOut.close();
		        
			}catch(Exception ex){
				logger.error(LoggerConstants.exceptionMessage(ex.toString()));
				logger.debug("In catch --"+ex.getLocalizedMessage());
			}finally {
				try {				
					if (stream != null)
						stream.close();
				} catch (IOException e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
				}
			}
			
			logger.info(LoggerConstants.methodEndLevel());
	        return fileName;
	    }
	 
	 
	 public String createFileTrackingExport(Connection conn, String uiContextRange, HPEContext context, String exportType, String clmType) throws ApplicationException {
		 logger.info(LoggerConstants.methodStartLevel());
			String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
			String mfId = context.getHpeftSearchVO().getMfId();
			
			String CSVfileName = getCvsFileName();
			BufferedOutputStream stream = null;	
			HPEFTService hpeftService = new HPEFTService();
			HPEFileTrackDao fileTrackDao = new HPEFileTrackDao();
			List<HPEFTDailyFileProcessingDO> exportDashResultLst = null; 
			final StringBuffer headerNames = new StringBuffer();
			StringBuffer s = null;
			
			ENCCodeCache cc = ENCCodeCache.getInstance();
			HashMap codes = cc.getHmENCDashboardStatusIndex();
			//IFOX-00409720 - Add File Id and HCSC 837 file name for HCSC customers starts			
			String EXPORT_HEADER_NAMES = "CUST_FILE_NAME, Recieved Cnt,Recieved Date, Wipro REJ, File Id,Cust File Id, 837 File Name, Submitted, 999 RSP FILE NAME, 999 ACC,999 REJ, 277 RSP FILE NAME, 277 ACC, 277 REJ, MAO002 FILE NAME, MAO002 ACC, MAO002 REJ"; //IFOX-00416789 - Add Customer File Id
			
			if(mfId.equals("HCF0324")) {
				EXPORT_HEADER_NAMES = EXPORT_HEADER_NAMES.replaceAll("837 File Name", "837 File Name, HCSC 837 File Name");
			}
			//IFOX-00409720 - Add File Id and HCSC 837 file name for HCSC customers Ends
			final String LINE_SEPARATOR = System.getProperty("line.separator");
			if(context.getHpeftSearchVO()!=null){
				exportDashResultLst = new ArrayList<HPEFTDailyFileProcessingDO>();
				
				if((!context.getHpeftSearchVO().getOrig_intrchg_ctrl_nbr().equals("") || !context.getHpeftSearchVO().getFileName().equals("")) && context.getHpeftSearchVO().getClmType() != "N" && !context.getHpeftSearchVO().getClaimNumber().isEmpty()){
					context.getHpeftSearchVO().setOrig_intrchg_ctrl_nbr("");
					context.getHpeftSearchVO().setFileName("");
					context.getHpeftSearchVO().setCustFileId(""); //IFOX-00415108 - Add CMS ICN to the export
					exportDashResultLst = hpeftService.searchClaim(conn, context.getHpeftSearchVO());
				
				}else if(context.getHpeftSearchVO().getSearchBy()!=null && context.getHpeftSearchVO().getSearchBy().equals(HPEConstants.FILETRACK_SEARCH_BY_FILEID) && context.getHpeftSearchVO().getOrig_intrchg_ctrl_nbr()!=null && !context.getHpeftSearchVO().getOrig_intrchg_ctrl_nbr().isEmpty()){
					exportDashResultLst= fileTrackDao.searchDailyFileProcessingByFileId(conn, context.getHpeftSearchVO().getMfId(), context.getHpeftSearchVO().getSearchSubmitterId(), context.getHpeftSearchVO().getSearchEncType(), context.getHpeftSearchVO().getOrig_intrchg_ctrl_nbr());
				
				}else if(context.getHpeftSearchVO().getSearchBy()!=null && context.getHpeftSearchVO().getSearchBy().equals(HPEConstants.FILETRACK_SEARCH_BY_FILENAME) && context.getHpeftSearchVO().getFileName()!=null && !context.getHpeftSearchVO().getFileName().isEmpty()){
					exportDashResultLst= fileTrackDao.searchDailyFileProcessingByFileName(conn, context.getHpeftSearchVO().getMfId(), context.getHpeftSearchVO().getSearchSubmitterId(), context.getHpeftSearchVO().getFileName(), context.getHpeftSearchVO().getSearchEncType());
				
				}else if(context.getHpeftSearchVO().getClmType() != "N" && !context.getHpeftSearchVO().getClaimNumber().isEmpty()){
					exportDashResultLst = hpeftService.searchClaim(conn, context.getHpeftSearchVO());
				}
				
			}
			
			try{
				stream = new BufferedOutputStream(new FileOutputStream(new File(CSVfileName)));
				headerNames.append(EXPORT_HEADER_NAMES);
				stream.write((headerNames.toString() + LINE_SEPARATOR).getBytes());
				
				if(exportDashResultLst!=null){
					for(HPEFTDailyFileProcessingDO dfpd:exportDashResultLst){						
						s = new StringBuffer();
						//IFOX-00409720 - Add File Id and HCSC 837 file name for HCSC customers starts	
						if(mfId.equals("HCF0324")) {
							s.append(dfpd.getCust_file_name()).append(",").append(dfpd.getEncInFile()).append(",").append(dfpd.getSubmissionDate()).append(",").append(dfpd.getWiproRej()).append(",").append(dfpd.getIcn()).append(",").append(dfpd.getCustFileId()).append(",").append(dfpd.getCms837Name()).append(",") //IFOX-00416789 - Add Customer File Id
								.append(dfpd.getHcsc837Name()).append(",").append(dfpd.getEncSenttoCMS()).append(",").append(dfpd.getCms999Name()).append(",").append(dfpd.getCms_999_ACC()).append(",").append(dfpd.getCms_999_Rej()).append(",")
								.append(dfpd.getCms277Name()).append(",").append(dfpd.getCms_277CA_ACC()).append(",").append(dfpd.getCms_277CA_Rej()).append(",").append(dfpd.getCmsMAOName()).append(",").append(dfpd.getCms_MAO002_ACC()).append(",").append(dfpd.getCms_MAO002_Rej());
						}else {
							s.append(dfpd.getCust_file_name()).append(",").append(dfpd.getEncInFile()).append(",").append(dfpd.getSubmissionDate()).append(",").append(dfpd.getWiproRej()).append(",").append(dfpd.getIcn()).append(",").append(dfpd.getCustFileId()).append(",").append(dfpd.getCms837Name()).append(",") //IFOX-00416789 - Add Customer File Id
								.append(dfpd.getEncSenttoCMS()).append(",").append(dfpd.getCms999Name()).append(",").append(dfpd.getCms_999_ACC()).append(",").append(dfpd.getCms_999_Rej()).append(",")
								.append(dfpd.getCms277Name()).append(",").append(dfpd.getCms_277CA_ACC()).append(",").append(dfpd.getCms_277CA_Rej()).append(",").append(dfpd.getCmsMAOName()).append(",").append(dfpd.getCms_MAO002_ACC()).append(",").append(dfpd.getCms_MAO002_Rej());
						}
						//IFOX-00409720 - Add File Id and HCSC 837 file name for HCSC customers Ends
				        stream.write((s + LINE_SEPARATOR).getBytes());
					}
					
				//	logger.error("s is" + s);
				}
				
				
			}catch(Exception ex){
				logger.error(LoggerConstants.exceptionMessage(ex.toString()));
				logger.debug("In catch --"+ex.getLocalizedMessage());
			}finally {
				try {				
					if (stream != null)
						stream.close();
				} catch (IOException e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
				}
			}
			logger.info(LoggerConstants.methodEndLevel());
			return CSVfileName;
		
	 }
	 
	 /*This method is used to export file tracking list*/ 
	 public String createExportFileNames(Connection conn, String uiContextRange, HPEContext context, String exportType, String clmType) throws ApplicationException {
		 logger.info(LoggerConstants.methodStartLevel());
			String clmNumber = "";
			String source = null;
			String extractDate = new DateUtil().getTodaysDate("MM/dd/yyyy");
			String dateType = "",searchFrom = "",searchTo = "";
			String submitId = "", dateInd = "";
			String mfId = context.getHpeftSearchVO().getMfId();//IFOX-00409720 - Add File Id and HCSC 837 file name for HCSC customers
			
			String CSVfileName = getCvsFileName();
			BufferedOutputStream stream = null;

			//IFOX-00409720 - Add File Id and HCSC 837 file name for HCSC customers starts
			String EXPORT_HEADER_NAMES = "CUST_FILE_NAME, FILE_ID,CUST_FILE_ID, C837_FILE_NAME, TA1_FILE_NAME, C999_FILE_NAME, C277_FILE_NAME, MAO1_FILE_NAME, MAO2_FILE_NAME,INVALID_RSP_FILE_NAME"; //IFOX-00416789 - Add Customer File Id
			if(mfId.equals("HCF0324")) {
				EXPORT_HEADER_NAMES = EXPORT_HEADER_NAMES.replaceAll("C837_FILE_NAME", "C837_FILE_NAME, HCSC837_FILE_NAME");
			}
			//IFOX-00409720 - Add File Id and HCSC 837 file name for HCSC customers Ends
			final String LINE_SEPARATOR = System.getProperty("line.separator");

			String CUSTOMER_FILE_SQL = "SELECT D.CUST_FILE_NAME, E.INTERCHANGE_NBR,D.CUSTOMER_FILE_ID, E.CUST837_FILE_NAME, E.C837_FILE_NAME,E.TA1_FILE_NAME,E.C999_FILE_NAME, E.C277_FILE_NAME,E.MAO1_FILE_NAME,E.MAO2_FILE_NAME, E.INVALID_RSP_FILE_NAME "//IFOX-00409720 - Add File Id and HCSC 837 file name for HCSC customers. 
					+ "FROM ENC_FILE_XREF as D "
					+ "INNER JOIN ENC_BATCH_TRACKING as E "
					+ "ON D.MF_ID=E.MF_ID AND D.INTERNAL_FILE_NAME=E.INTERNAL_FILE_NAME AND D.INTRCHG_SNDR_ID=E.SUBMITTER_ID ";

			PreparedStatement ps = null;
			final StringBuffer headerNames = new StringBuffer();
			ResultSet resultSet = null;
			StringBuffer s = null;
			String mfid = null, internalFileName = null, createTime = null, custFileName = null, splitFileSeqNbr = null,
					encType = null, claimType = null, prodTestInd = null, fileDate = null, lastUpdtTime = null,
					lastUpdtUser = null, status = null, origIntrchgCtrlNbr = null, custFileId=null, clmstatInd = null, sourceId = null, //IFOX-00416789 - Add Customer File Id
					cms837FileName = null, cms277FileName = null, cms999FileName = null, cmsMAO1FileName = null,
					cmsMAO2FileName = null,ta1FileName = null, invalidRspFileName = null, fileId = null, hcsc837FileName = null;
			try {

				stream = new BufferedOutputStream(new FileOutputStream(new File(CSVfileName)));
				headerNames.append(EXPORT_HEADER_NAMES);

				stream.write((headerNames.toString() + LINE_SEPARATOR).getBytes());

				String query = CUSTOMER_FILE_SQL;
				String where = ""; 
				String cFileName="";

				ArrayList parameters = new ArrayList();

				// Required key columns
				where += " D.MF_ID=? ";
				parameters.add(mfId);//IFOX-00409720 - Add File Id and HCSC 837 file name for HCSC customers

				// Required key columns
				where += " AND D.INTRCHG_SNDR_ID=? ";
				parameters.add(context.getHpeftSearchVO().getSearchSubmitterId());

				if (context.getHPEFTSearchVO().getFileName() != null && !StringUtil.isNullOrEmpty(context.getHPEFTSearchVO().getFileName())) {
					where += " AND D.CUST_FILE_NAME LIKE ? ";
					cFileName ="%"+context.getHPEFTSearchVO().getFileName()+"%";
					parameters.add(cFileName);
				}
				if (context.getHpeftSearchVO().getSearchFromDate() != null && !StringUtil.isNullOrEmpty(context.getHpeftSearchVO().getSearchFromDate())) {
					where += " AND D.FILE_DATE BETWEEN ? AND ?";
					Date fromdate = null, todate = null;
					try {
						todate = new SimpleDateFormat("MM/yyyy").parse(context.getHpeftSearchVO().getSearchFromDate());
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						logger.error(LoggerConstants.exceptionMessage(e.toString()));
						logger.debug(e.getMessage());
					}
					 
					try {
						 fromdate = new SimpleDateFormat("MM/yyyy").parse(context.getHpeftSearchVO().getSearchToDate());
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						logger.error(LoggerConstants.exceptionMessage(e.toString()));
						logger.debug(e.getMessage());
					}
					
					
					String fromtimestamp = new SimpleDateFormat("yyyyMMdd").format(fromdate);
					String totimestamp = new SimpleDateFormat("yyyyMMdd").format(todate);
					
					//IFOX-00416603 - File Management Starts
					SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
					try {
						Calendar c = Calendar.getInstance();
						c.setTime(dateFormat.parse(totimestamp));
						c.set(Calendar.DAY_OF_MONTH, c.getActualMaximum(Calendar.DAY_OF_MONTH));
						totimestamp = new SimpleDateFormat("yyyyMMdd").format(c.getTime());
					} catch (ParseException e) {
						e.printStackTrace();
					}
					//IFOX-00416603 - File Management Ends

					parameters.add(fromtimestamp);
					parameters.add(totimestamp);
				}

				/*if ("HCF0324".equals(mfId)) {*/
					logger.debug("Submitter id is::" + context.getHpeftSearchVO().getSearchSubmitterId());
					logger.debug("TypeofBusiness is::" + context.getHpeftSearchVO().getTypeOfBusiness());

					if (!StringUtil.isNullOrEmpty(context.getHpeftSearchVO().getTypeOfBusiness()) && context.getHpeftSearchVO().getTypeOfBusiness().trim().equals("EN")) {
							where += " AND D.INTRCHG_RCVR_ID in ('" + HPEConstants.MMAI_CARE_INST_REC_ID + "','"
									+ HPEConstants.MMAI_CARE_PROF_REC_ID + "','" + HPEConstants.MMAI_CARE_DME_REC_ID +"','"+HPEConstants.MAO_INST_REC_ID + "','"+ HPEConstants.MAO_PROF_REC_ID + "','" + HPEConstants.MAO_DME_REC_ID + "')";

					}
					if (!StringUtil.isNullOrEmpty(context.getHpeftSearchVO().getTypeOfBusiness()) && context.getHpeftSearchVO().getTypeOfBusiness().trim().equals("MD")) {
							where += " AND D.INTRCHG_RCVR_ID in ('" + HPEConstants.MMAI_CAID_INST_REC_ID + "','"
									+ HPEConstants.MMAI_CAID_PROF_REC_ID + "','" + HPEConstants.MMAI_CAID_DME_REC_ID + "','"
									+ HPEConstants.MMAI_CAID_DENTAL_REC_ID + "')";
					}
				//}

				CUSTOMER_FILE_SQL += " WHERE " + where;
				// Query for YearMonthDay and no. of Files columns - Start.
				logger.debug(CUSTOMER_FILE_SQL);
			
				ps = conn.prepareStatement(CUSTOMER_FILE_SQL);

				for (int i = 1; i <= parameters.size(); ++i) {
					ps.setString(i, parameters.get(i - 1).toString());
					logger.debug("parameters is :" + parameters.get(i - 1).toString());
				}

				logger.debug("CUSTOMER_FILE_SQL is :" + CUSTOMER_FILE_SQL);

				resultSet = ps.executeQuery();
				while (resultSet.next()) {
					s = new StringBuffer();

					custFileName = StringUtil.nonNullTrim(resultSet.getString("CUST_FILE_NAME"));
					cms837FileName = StringUtil.nonNullTrim(resultSet.getString("C837_FILE_NAME"));
					cms277FileName = StringUtil.nonNullTrim(resultSet.getString("C277_FILE_NAME"));
					cms999FileName = StringUtil.nonNullTrim(resultSet.getString("C999_FILE_NAME"));
					cmsMAO1FileName = StringUtil.nonNullTrim(resultSet.getString("MAO1_FILE_NAME"));
					cmsMAO2FileName = StringUtil.nonNullTrim(resultSet.getString("MAO2_FILE_NAME"));
					ta1FileName = StringUtil.nonNullTrim(resultSet.getString("TA1_FILE_NAME"));
					invalidRspFileName = StringUtil.nonNullTrim(resultSet.getString("INVALID_RSP_FILE_NAME"));
					//IFOX-00409720 - Add File Id and HCSC 837 file name for HCSC customers starts
					fileId = StringUtil.nonNullTrim(resultSet.getString("INTERCHANGE_NBR"));
					custFileId = StringUtil.nonNullTrim(resultSet.getString("CUSTOMER_FILE_ID")); //IFOX-00416789 - Add Customer File Id
					hcsc837FileName = StringUtil.nonNullTrim(resultSet.getString("CUST837_FILE_NAME"));
					
					if(mfId.equals("HCF0324")) {
					s.append(custFileName).append(",").append(fileId).append(",").append(custFileId).append(",").append(cms837FileName).append(",").append(hcsc837FileName).append(",").append(ta1FileName).append(",").append(cms999FileName).append(",") //IFOX-00416789 - Add Customer File Id
							.append(cms277FileName).append(",").append(cmsMAO1FileName).append(",").append(cmsMAO2FileName).append(",").append(invalidRspFileName);
					}else {
						s.append(custFileName).append(",").append(fileId).append(",").append(custFileId).append(",").append(cms837FileName).append(",").append(ta1FileName).append(",").append(cms999FileName).append(",") //IFOX-00416789 - Add Customer File Id
						.append(cms277FileName).append(",").append(cmsMAO1FileName).append(",").append(cmsMAO2FileName).append(",").append(invalidRspFileName);
					}
					//IFOX-00409720 - Add File Id and HCSC 837 file name for HCSC customers Ends
					logger.debug("s is" + s);

					stream.write((s + LINE_SEPARATOR).getBytes());
				}
			} catch (FileNotFoundException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception: " + e.getMessage());
				throw new ApplicationException("Error in exportFileNames method", e);
			} catch (IOException e) {
				logger.error(LoggerConstants.exceptionMessage(e.toString()));
				logger.debug("createCSV: caught Exception: " + e.getMessage());
				throw new ApplicationException("Error in exportFileNames method", e);
			} catch (SQLException eSQL) {
				logger.error(LoggerConstants.exceptionMessage(eSQL.toString()));
				logger.debug("Database Error code : " + eSQL.getErrorCode() + " and Msg : " + eSQL.getMessage());
				throw new DaoException(Constants.EXCEPTION_MSG, eSQL);
			} finally {
				try {
					if (resultSet != null) {
						try {
							resultSet.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							logger.error(LoggerConstants.exceptionMessage(e.toString()));
							logger.debug(e.getMessage());
						}
						resultSet = null;
					}
					if (ps != null) {
						try {
							ps.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							logger.error(LoggerConstants.exceptionMessage(e.toString()));
							logger.debug(e.getMessage());
						}
						ps = null;
					}
					if (stream != null)
						stream.close();
				} catch (IOException e) {
					logger.error(LoggerConstants.exceptionMessage(e.toString()));
					logger.debug("createCSV: caught Exception while closing FileOutPut Stream: " + e.getMessage());
				}
			}
			logger.info(LoggerConstants.methodEndLevel());
			return CSVfileName;
		}
			
	 }


