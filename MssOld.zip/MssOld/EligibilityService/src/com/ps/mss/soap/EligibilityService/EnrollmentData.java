/*
 * $Id: EnrollmentData.java,v 1.1 2014/06/26 07:24:11 praveen Exp $
 */

package com.ps.mss.soap.EligibilityService;

/**
 *
 * @author  alevin
 */
public class EnrollmentData {
    
    private String planId;
    private String planEnrollmentDate;
    private String drugPlanInd;
    
    /** Creates a new instance of EnrollmentData */
    public EnrollmentData() {
    }
    

	/**
	 * @return Returns the drugPlanInd.
	 */
	public String getDrugPlanInd() {
		return drugPlanInd;
	}
	/**
	 * @param drugPlanInd The drugPlanInd to set.
	 */
	public void setDrugPlanInd(String drugPlanInd) {
		this.drugPlanInd = drugPlanInd;
	}
	/**
	 * @return Returns the planEnrollmentDate.
	 */
	public String getPlanEnrollmentDate() {
		return planEnrollmentDate;
	}
	/**
	 * @param planEnrollmentDate The planEnrollmentDate to set.
	 */
	public void setPlanEnrollmentDate(String planEnrollmentDate) {
		this.planEnrollmentDate = planEnrollmentDate;
	}
	/**
	 * @return Returns the planId.
	 */
	public String getPlanId() {
		return planId;
	}
	/**
	 * @param planId The planId to set.
	 */
	public void setPlanId(String planId) {
		this.planId = planId;
	}
}
