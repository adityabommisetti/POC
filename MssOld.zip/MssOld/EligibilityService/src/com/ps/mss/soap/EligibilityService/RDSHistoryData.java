/*
 * $Id: RDSHistoryData.java,v 1.1 2014/06/26 07:24:12 praveen Exp $
 */
package com.ps.mss.soap.EligibilityService;

public class RDSHistoryData {

    private String rdsStartDate;
    private String rdsEndDate;

	/**
	 * @return Returns the rdsEndDate.
	 */
	public String getRdsEndDate() {
		return rdsEndDate;
	}
	/**
	 * @param rdsEndDate The rdsEndDate to set.
	 */
	public void setRdsEndDate(String rdsEndDate) {
		this.rdsEndDate = rdsEndDate;
	}
	/**
	 * @return Returns the rdsStartDate.
	 */
	public String getRdsStartDate() {
		return rdsStartDate;
	}
	/**
	 * @param rdsStartDate The rdsStartDate to set.
	 */
	public void setRdsStartDate(String rdsStartDate) {
		this.rdsStartDate = rdsStartDate;
	}
}
