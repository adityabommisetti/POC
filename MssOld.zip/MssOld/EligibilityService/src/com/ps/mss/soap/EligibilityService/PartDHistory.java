/*
 * partDHistory.java
 *
 * Created on November 2, 2006, 3:21 PM
 */

package com.ps.mss.soap.EligibilityService;

/**
 *
 * @author  alevin
 */
public class PartDHistory {
    
    private String prtDStartDate;
    private String prtDEndDate;
    
    /** Creates a new instance of partDHistory */
    public PartDHistory() {
    }
    
    /**
     * Getter for property prtDEndDate.
     * @return Value of property prtDEndDate.
     */
    public java.lang.String getPrtDStartDate() {
        return prtDStartDate;
    }
    
    /**
     * Setter for property prtDStartDate.
     * @param prtDStartDate New value of property prtDStartDate.
     */
    public void setPrtDStartDate(java.lang.String prtDStartDate) {
        this.prtDStartDate = prtDStartDate;
    }
    
    /**
     * Getter for property prtDEndDate.
     * @return Value of property prtDEndDate.
     */
    public java.lang.String getPrtDEndDate() {
        return prtDEndDate;
    }
    
    /**
     * Setter for property pbpStartDate.
     * @param pbpStartDate New value of property pbpStartDate.
     */
    public void setPrtDEndDate(java.lang.String prtDEndDate) {
        this.prtDEndDate = prtDEndDate;
    }
    
}
