/*
 * Member.java
 *
 * Created on January 28, 2005, 1:57 PM
 */

package com.ps.mss.soap.EligibilityService;

/**
 *
 * @author  rnenne
 */
public class Member {

	private String mbdLoadDate;
	private String foundHicNbr;
	private String foundNameorDOB;
    private String hicNbr;
    private String lastName;
    private String firstName;
    private String middleInitial;
    private String genderCd;
    private String birthDate;
    private String prtAEntitlementDate;
    private String prtAEntitleEndDate;
    private String prtBEntitlementDate;
    private String prtBEntitleEndDate;
    private String countyCd;
    private String stateCd;
    private String hospiceStatus;
    private String hospiceStartDate;
    private String hospiceEndDate;
    private String esrdStatus;
    private String esrdStartDate;
    private String esrdEndDate;
    private String instStatus;
    private String instStartDate;
    private String instEndDate;
    private String medicaidStatus;
    private String medicaidStartDate;
    private String medicaidEndDate;
    private String eghpInd;
    private String livingStatus;
    private String deathDate;
    private String inquiryResponse;
    private String prtDEligibleDate;
    private LisData lisInfo[];
    private String potentialUncvrdMths;
    private String potentialUncvrdMthsEffDate;
    private PartDHistData prtDHistInfo[];
    private PlanEnrollmentData enrollmentInfo[];
    private NuncMoData nuncMoInfo[];
    
    /** Creates a new instance of Member */
    public Member() {
    }
    
    public void Initialize() {
    	mbdLoadDate = "";
    	foundHicNbr = "N";
    	foundNameorDOB = "N";
    }

    
	/**
	 * @return Returns the birthDate.
	 */
	public String getBirthDate() {
		return birthDate;
	}
	/**
	 * @param birthDate The birthDate to set.
	 */
	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}
	/**
	 * @return Returns the countyCd.
	 */
	public String getCountyCd() {
		return countyCd;
	}
	/**
	 * @param countyCd The countyCd to set.
	 */
	public void setCountyCd(String countyCd) {
		this.countyCd = countyCd;
	}
	/**
	 * @return Returns the deathDate.
	 */
	public String getDeathDate() {
		return deathDate;
	}
	/**
	 * @param deathDate The deathDate to set.
	 */
	public void setDeathDate(String deathDate) {
		this.deathDate = deathDate;
	}
	/**
	 * @return Returns the eghpInd.
	 */
	public String getEghpInd() {
		return eghpInd;
	}
	/**
	 * @param eghpInd The eghpInd to set.
	 */
	public void setEghpInd(String eghpInd) {
		this.eghpInd = eghpInd;
	}
	/**
	 * @return Returns the enrollmentInfo.
	 */
	public PlanEnrollmentData[] getEnrollmentInfo() {
		return enrollmentInfo;
	}
	/**
	 * @param enrollmentInfo The enrollmentInfo to set.
	 */
	public void setEnrollmentInfo(PlanEnrollmentData[] enrollmentInfo) {
		this.enrollmentInfo = enrollmentInfo;
	}
	/**
	 * @return Returns the esrdEndDate.
	 */
	public String getEsrdEndDate() {
		return esrdEndDate;
	}
	/**
	 * @param esrdEndDate The esrdEndDate to set.
	 */
	public void setEsrdEndDate(String esrdEndDate) {
		this.esrdEndDate = esrdEndDate;
	}
	/**
	 * @return Returns the esrdStartDate.
	 */
	public String getEsrdStartDate() {
		return esrdStartDate;
	}
	/**
	 * @param esrdStartDate The esrdStartDate to set.
	 */
	public void setEsrdStartDate(String esrdStartDate) {
		this.esrdStartDate = esrdStartDate;
	}
	/**
	 * @return Returns the esrdStatus.
	 */
	public String getEsrdStatus() {
		return esrdStatus;
	}
	/**
	 * @param esrdStatus The esrdStatus to set.
	 */
	public void setEsrdStatus(String esrdStatus) {
		this.esrdStatus = esrdStatus;
	}
	/**
	 * @return Returns the firstName.
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName The firstName to set.
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return Returns the foundHicNbr.
	 */
	public String getFoundHicNbr() {
		return foundHicNbr;
	}
	/**
	 * @param foundHicNbr The foundHicNbr to set.
	 */
	public void setFoundHicNbr(String foundHicNbr) {
		this.foundHicNbr = foundHicNbr;
	}
	/**
	 * @return Returns the foundNameorDOB.
	 */
	public String getFoundNameorDOB() {
		return foundNameorDOB;
	}
	/**
	 * @param foundNameorDOB The foundNameorDOB to set.
	 */
	public void setFoundNameorDOB(String foundNameorDOB) {
		this.foundNameorDOB = foundNameorDOB;
	}
	/**
	 * @return Returns the genderCd.
	 */
	public String getGenderCd() {
		return genderCd;
	}
	/**
	 * @param genderCd The genderCd to set.
	 */
	public void setGenderCd(String genderCd) {
		this.genderCd = genderCd;
	}
	/**
	 * @return Returns the hicNbr.
	 */
	public String getHicNbr() {
		return hicNbr;
	}
	/**
	 * @param hicNbr The hicNbr to set.
	 */
	public void setHicNbr(String hicNbr) {
		this.hicNbr = hicNbr;
	}
	/**
	 * @return Returns the hospiceEndDate.
	 */
	public String getHospiceEndDate() {
		return hospiceEndDate;
	}
	/**
	 * @param hospiceEndDate The hospiceEndDate to set.
	 */
	public void setHospiceEndDate(String hospiceEndDate) {
		this.hospiceEndDate = hospiceEndDate;
	}
	/**
	 * @return Returns the hospiceStartDate.
	 */
	public String getHospiceStartDate() {
		return hospiceStartDate;
	}
	/**
	 * @param hospiceStartDate The hospiceStartDate to set.
	 */
	public void setHospiceStartDate(String hospiceStartDate) {
		this.hospiceStartDate = hospiceStartDate;
	}
	/**
	 * @return Returns the hospiceStatus.
	 */
	public String getHospiceStatus() {
		return hospiceStatus;
	}
	/**
	 * @param hospiceStatus The hospiceStatus to set.
	 */
	public void setHospiceStatus(String hospiceStatus) {
		this.hospiceStatus = hospiceStatus;
	}
	/**
	 * @return Returns the inquiryResponse.
	 */
	public String getInquiryResponse() {
		return inquiryResponse;
	}
	/**
	 * @param inquiryResponse The inquiryResponse to set.
	 */
	public void setInquiryResponse(String inquiryResponse) {
		this.inquiryResponse = inquiryResponse;
	}
	/**
	 * @return Returns the instEndDate.
	 */
	public String getInstEndDate() {
		return instEndDate;
	}
	/**
	 * @param instEndDate The instEndDate to set.
	 */
	public void setInstEndDate(String instEndDate) {
		this.instEndDate = instEndDate;
	}
	/**
	 * @return Returns the instStartDate.
	 */
	public String getInstStartDate() {
		return instStartDate;
	}
	/**
	 * @param instStartDate The instStartDate to set.
	 */
	public void setInstStartDate(String instStartDate) {
		this.instStartDate = instStartDate;
	}
	/**
	 * @return Returns the instStatus.
	 */
	public String getInstStatus() {
		return instStatus;
	}
	/**
	 * @param instStatus The instStatus to set.
	 */
	public void setInstStatus(String instStatus) {
		this.instStatus = instStatus;
	}
	/**
	 * @return Returns the lastName.
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName The lastName to set.
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return Returns the lisInfo.
	 */
	public LisData[] getLisInfo() {
		return lisInfo;
	}
	/**
	 * @param lisInfo The lisInfo to set.
	 */
	public void setLisInfo(LisData[] lisInfo) {
		this.lisInfo = lisInfo;
	}
	/**
	 * @return Returns the livingStatus.
	 */
	public String getLivingStatus() {
		return livingStatus;
	}
	/**
	 * @param livingStatus The livingStatus to set.
	 */
	public void setLivingStatus(String livingStatus) {
		this.livingStatus = livingStatus;
	}
	/**
	 * @return Returns the mbdLoadDate.
	 */
	public String getMbdLoadDate() {
		return mbdLoadDate;
	}
	/**
	 * @param mbdLoadDate The mbdLoadDate to set.
	 */
	public void setMbdLoadDate(String mbdLoadDate) {
		this.mbdLoadDate = mbdLoadDate;
	}
	/**
	 * @return Returns the medicaidEndDate.
	 */
	public String getMedicaidEndDate() {
		return medicaidEndDate;
	}
	/**
	 * @param medicaidEndDate The medicaidEndDate to set.
	 */
	public void setMedicaidEndDate(String medicaidEndDate) {
		this.medicaidEndDate = medicaidEndDate;
	}
	/**
	 * @return Returns the medicaidStartDate.
	 */
	public String getMedicaidStartDate() {
		return medicaidStartDate;
	}
	/**
	 * @param medicaidStartDate The medicaidStartDate to set.
	 */
	public void setMedicaidStartDate(String medicaidStartDate) {
		this.medicaidStartDate = medicaidStartDate;
	}
	/**
	 * @return Returns the medicaidStatus.
	 */
	public String getMedicaidStatus() {
		return medicaidStatus;
	}
	/**
	 * @param medicaidStatus The medicaidStatus to set.
	 */
	public void setMedicaidStatus(String medicaidStatus) {
		this.medicaidStatus = medicaidStatus;
	}
	/**
	 * @return Returns the middleInitial.
	 */
	public String getMiddleInitial() {
		return middleInitial;
	}
	/**
	 * @param middleInitial The middleInitial to set.
	 */
	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}
	/**
	 * @return Returns the nuncMoInfo.
	 */
	public NuncMoData[] getNuncMoInfo() {
		return nuncMoInfo;
	}
	/**
	 * @param nuncMoInfo The nuncMoInfo to set.
	 */
	public void setNuncMoInfo(NuncMoData[] nuncMoInfo) {
		this.nuncMoInfo = nuncMoInfo;
	}
	/**
	 * @return Returns the potentialUncvrdMths.
	 */
	public String getPotentialUncvrdMths() {
		return potentialUncvrdMths;
	}
	/**
	 * @param potentialUncvrdMths The potentialUncvrdMths to set.
	 */
	public void setPotentialUncvrdMths(String potentialUncvrdMths) {
		this.potentialUncvrdMths = potentialUncvrdMths;
	}
	/**
	 * @return Returns the potentialUncvrdMthsEffDate.
	 */
	public String getPotentialUncvrdMthsEffDate() {
		return potentialUncvrdMthsEffDate;
	}
	/**
	 * @param potentialUncvrdMthsEffDate The potentialUncvrdMthsEffDate to set.
	 */
	public void setPotentialUncvrdMthsEffDate(String potentialUncvrdMthsEffDate) {
		this.potentialUncvrdMthsEffDate = potentialUncvrdMthsEffDate;
	}
	/**
	 * @return Returns the prtAEntitleEndDate.
	 */
	public String getPrtAEntitleEndDate() {
		return prtAEntitleEndDate;
	}
	/**
	 * @param prtAEntitleEndDate The prtAEntitleEndDate to set.
	 */
	public void setPrtAEntitleEndDate(String prtAEntitleEndDate) {
		this.prtAEntitleEndDate = prtAEntitleEndDate;
	}
	/**
	 * @return Returns the prtAEntitlementDate.
	 */
	public String getPrtAEntitlementDate() {
		return prtAEntitlementDate;
	}
	/**
	 * @param prtAEntitlementDate The prtAEntitlementDate to set.
	 */
	public void setPrtAEntitlementDate(String prtAEntitlementDate) {
		this.prtAEntitlementDate = prtAEntitlementDate;
	}
	/**
	 * @return Returns the prtBEntitleEndDate.
	 */
	public String getPrtBEntitleEndDate() {
		return prtBEntitleEndDate;
	}
	/**
	 * @param prtBEntitleEndDate The prtBEntitleEndDate to set.
	 */
	public void setPrtBEntitleEndDate(String prtBEntitleEndDate) {
		this.prtBEntitleEndDate = prtBEntitleEndDate;
	}
	/**
	 * @return Returns the prtBEntitlementDate.
	 */
	public String getPrtBEntitlementDate() {
		return prtBEntitlementDate;
	}
	/**
	 * @param prtBEntitlementDate The prtBEntitlementDate to set.
	 */
	public void setPrtBEntitlementDate(String prtBEntitlementDate) {
		this.prtBEntitlementDate = prtBEntitlementDate;
	}
	/**
	 * @return Returns the prtDEligibleDate.
	 */
	public String getPrtDEligibleDate() {
		return prtDEligibleDate;
	}
	/**
	 * @param prtDEligibleDate The prtDEligibleDate to set.
	 */
	public void setPrtDEligibleDate(String prtDEligibleDate) {
		this.prtDEligibleDate = prtDEligibleDate;
	}
	/**
	 * @return Returns the prtDHistInfo.
	 */
	public PartDHistData[] getPrtDHistInfo() {
		return prtDHistInfo;
	}
	/**
	 * @param prtDHistInfo The prtDHistInfo to set.
	 */
	public void setPrtDHistInfo(PartDHistData[] prtDHistInfo) {
		this.prtDHistInfo = prtDHistInfo;
	}
	/**
	 * @return Returns the stateCd.
	 */
	public String getStateCd() {
		return stateCd;
	}
	/**
	 * @param stateCd The stateCd to set.
	 */
	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}
}
