/*
 * $Id: RDSHistoryDataSerializer.java,v 1.1 2014/06/26 07:24:12 praveen Exp $
 */
package com.ps.mss.soap.EligibilityService;

import java.io.IOException;
import java.io.Writer;

import org.apache.soap.encoding.soapenc.SoapEncUtils;
import org.apache.soap.rpc.Parameter;
import org.apache.soap.rpc.RPCConstants;
import org.apache.soap.rpc.SOAPContext;
import org.apache.soap.util.Bean;
import org.apache.soap.util.StringUtils;
import org.apache.soap.util.xml.DOMUtils;
import org.apache.soap.util.xml.Deserializer;
import org.apache.soap.util.xml.NSStack;
import org.apache.soap.util.xml.QName;
import org.apache.soap.util.xml.Serializer;
import org.apache.soap.util.xml.XMLJavaMappingRegistry;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class RDSHistoryDataSerializer implements Deserializer, Serializer {

	/* (non-Javadoc)
	 * @see org.apache.soap.util.xml.Deserializer#unmarshall(java.lang.String, org.apache.soap.util.xml.QName, org.w3c.dom.Node, org.apache.soap.util.xml.XMLJavaMappingRegistry, org.apache.soap.rpc.SOAPContext)
	 */
    public Bean unmarshall(String inScopeEncStyle, QName elementType,
            Node src, XMLJavaMappingRegistry xjmr, SOAPContext ctx) throws IllegalArgumentException {
		Element root = (Element)src;
		Element tempEl = DOMUtils.getFirstChildElement(root);
		RDSHistoryData rdsHistory;
		
		try {
			rdsHistory = (RDSHistoryData)RDSHistoryData.class.newInstance();
		} catch (Exception e) {
			throw new IllegalArgumentException("Problem instantiating bean: " + e.getMessage());
		}
		
		while (tempEl != null) {
			Bean paramBean = xjmr.unmarshall(inScopeEncStyle,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
			Parameter param = (Parameter)paramBean.value;
			String tagName = tempEl.getTagName();
			
			if (tagName.equals("rdsStartDate")) {
				rdsHistory.setRdsStartDate((java.lang.String)param.getValue());
			}
			else if (tagName.equals("rdsEndDate")) {
				rdsHistory.setRdsEndDate((java.lang.String)param.getValue());
			}
			
			tempEl = DOMUtils.getNextSiblingElement(tempEl);
		}
		
		return new Bean(RDSHistoryData.class, rdsHistory);
}
	/* (non-Javadoc)
	 * @see org.apache.soap.util.xml.Serializer#marshall(java.lang.String, java.lang.Class, java.lang.Object, java.lang.Object, java.io.Writer, org.apache.soap.util.xml.NSStack, org.apache.soap.util.xml.XMLJavaMappingRegistry, org.apache.soap.rpc.SOAPContext)
	 */
    public void marshall(String inScopeEncStyle, Class javaType,
            Object src, Object context, Writer sink,
            NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx) throws IllegalArgumentException, IOException	{
		nsStack.pushScope();
		
		SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context, sink, nsStack, xjmr);
		
		sink.write(StringUtils.lineSeparator);
		
		RDSHistoryData rdsHistory = (RDSHistoryData)src;
		Parameter param;
		
		param = new Parameter("rdsStartDate", java.lang.String.class, rdsHistory.getRdsStartDate(), null);
		xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
		sink.write(StringUtils.lineSeparator);
		
		param = new Parameter("rdsEndDate", java.lang.String.class, rdsHistory.getRdsEndDate(), null);
		xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
		
		sink.write(StringUtils.lineSeparator);		
		sink.write("</" + context + '>');
		
		nsStack.popScope();
	}
}
