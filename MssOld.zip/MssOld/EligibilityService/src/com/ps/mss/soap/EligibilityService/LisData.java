/*
 * lisData.java
 *
 * Created on November 2, 2006, 3:21 PM
 */

package com.ps.mss.soap.EligibilityService;

/**
 *
 * @author  alevin
 */
public class LisData {
    
    private String subsidyStartDate;
    private String subsidyEndDate;
    private String copayLevel;
    private String prtDPremSubPct;
    
    /** Creates a new instance of lisData */
    public LisData() {
    }
    
/**
     * Getter for property subsidyStartDate.
     * @return Value of property subsidyStartDate.
     */
    public java.lang.String getSubsidyStartDate() {
        return subsidyStartDate;
    }
    
    /**
     * Setter for property subsidyStartDate.
     * @param subsidyStartDate New value of property subsidyStartDate.
     */
    public void setSubsidyStartDate(java.lang.String subsidyStartDate) {
        this.subsidyStartDate = subsidyStartDate;
    }
    
    /**
     * Getter for property subsidyEndDate.
     * @return Value of property subsidyEndDate.
     */
    public java.lang.String getSubsidyEndDate() {
        return subsidyEndDate;
    }
    
    /**
     * Setter for property subsidyEndDate.
     * @param subsidyEndDate New value of property subsidyEndDate.
     */
    public void setSubsidyEndDate(java.lang.String subsidyEndDate) {
        this.subsidyEndDate = subsidyEndDate;
    }
    
    /**
     * Getter for property copayLevel.
     * @return Value of property copayLevel.
     */
    public java.lang.String getCopayLevel() {
        return copayLevel;
    }
    
    /**
     * Setter for property copayLevel.
     * @param copayLevel New value of property copayLevel.
     */
    public void setCopayLevel(java.lang.String copayLevel) {
        this.copayLevel = copayLevel;
    }
    
    /**
     * Getter for property prtDPremSubPct.
     * @return Value of property prtDPremSubPct.
     */
    public java.lang.String getPrtDPremSubPct() {
        return prtDPremSubPct;
    }
    
    /**
     * Setter for property prtDPremSubPct.
     * @param prtDPremSubPct New value of property prtDPremSubPct.
     */
    public void setPrtDPremSubPct(java.lang.String prtDPremSubPct) {
        this.prtDPremSubPct = prtDPremSubPct;
    }
    
}
