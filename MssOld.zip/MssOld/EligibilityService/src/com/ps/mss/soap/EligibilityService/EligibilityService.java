/*
 * $Id: EligibilityService.java,v 1.1 2014/06/26 07:24:09 praveen Exp $
 */

package com.ps.mss.soap.EligibilityService;

import java.io.PrintStream;
import java.io.File;
import java.util.Iterator;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.SQLException;

import org.slf4j.LoggerFactory;
import com.ps.text.DateFormatter;
import com.ps.util.StringUtil;
import com.ps.util.DateUtil;
import com.ps.mss.db.DbConn;
import com.ps.mss.db.AuthUserPersistence;
import com.ps.mss.db.CustSvcParmsPersistence;
import com.ps.mss.db.MBDNuncmo;
import com.ps.mss.db.PrtDHistory;
import com.ps.mss.db.SecPlanPersistence;
import com.ps.mss.db.ServicePersistence;
import com.ps.mss.db.MBD;
import com.ps.mss.db.MBDPersistence;
import com.ps.mss.db.view.MBDDatesView;
import com.ps.mss.db.view.MBDHistResponseView;
import com.ps.mss.db.view.MBDHistView;
import com.ps.mss.db.MBDHistoryPersistence;
import com.ps.mss.db.BillingLog;
import com.ps.mss.db.RDSHistory;
import com.ps.mss.db.BillingLogPersistence;
import com.ps.mss.db.CodeCache;
import com.ps.mss.security.AuthUser;
import com.ps.mss.security.AuthUserManager;
import com.ps.mss.soap.EligibilityService.LisData;
import com.ps.mss.soap.EligibilityService.Member;

import org.apache.soap.SOAPException;
import org.slf4j.Logger;			


/**
 *
 * @author  rnenne
 */
public class EligibilityService {
	private static Logger logger=LoggerFactory.getLogger(EligibilityService.class);
    /** Creates a new instance of EligibilityService */
    public EligibilityService() {
    } 
    
    /**
     * @deprecated
     * @param userId
     * @param passWord
     * @param hicNbr
     * @param lastName
     * @param birthDate
     * @return
     * @throws SOAPException
     */   
    public Member memberInquiry(String userId, String passWord, String hicNbr, String lastName, String birthDate) throws SOAPException   {
    	
        logger.info("WebService: memberInquiry- Request Received: " + userId + " " + hicNbr + " " + lastName + " " + birthDate);
    	checkForMaintenance(userId);
    	
        Connection conn = null;

        Member mbr = null;
        
        try {

            conn = DbConn.getConnection();
            
            AuthUserPersistence aup = new AuthUserPersistence();
            AuthUser au = aup.get(conn,StringUtil.nonNullTrim(userId).toUpperCase());
            
            //authenticate the user and get the default plan id
            String planId = authenticateUser(conn, au, passWord, userId, "memberInquiry");
            conn = getServiceConnection(conn, au);
            
            boolean testData = isTestData(au.getCustNbr());
            hicNbr = StringUtil.nonNullTrim(hicNbr).toUpperCase();
            birthDate = StringUtil.nonNullTrim(birthDate);
            
            //mbr = getMemberInquiryEQ(conn,log.getStream(),hicNbr,lastName,birthDate,au.getCustNbr(),testData);
            mbr = getMemberInquiryEQ(conn,hicNbr,lastName,birthDate,au.getCustNbr(),testData);
            if (mbr == null)
            {	// should return flags now
            	throw new SOAPException("MSS-00120","Internal Processing Exception");
            }
                       
            String inquiryType = StringUtil.nonNullTrim(mbr.getInquiryResponse());
            
           // submitBillingLogEntry(conn, log, au.getCustNbr(), au.getMfId(), au.getUserId(), planId, hicNbr, birthDate, inquiryType);
            submitBillingLogEntry(conn, au.getCustNbr(), au.getMfId(), au.getUserId(), planId, hicNbr, birthDate, inquiryType);

        } catch(SOAPException eES) {
            throw eES; 
        } catch(SQLException eSQL) {
            logger.error(eSQL.getMessage());
            throw new SOAPException("MSS-00125","Database Error");
        } catch(Exception e) {
            logger.error(e.getMessage());
            throw new SOAPException("MSS-00120","Internal Processing Exception");            
        } finally {
            try {
                if (conn != null)
                    conn.close();
            } catch (Exception e) {
                logger.error("DB conn close " + e.getMessage());
            }
        }

        //log.println("Returning data");
        logger.info("Request Responded: " + userId + " " + hicNbr + " " + lastName + " " + birthDate);
        return mbr;
    }

    private Member getMemberInquiryEQ(Connection conn,String hicNbr, String lastName, String birthDate, String custNbr,  boolean testData) throws SQLException {
        
    	DateUtil du = new DateUtil();
    	//MBDPersistence mbdPersist = new MBDPersistence(log,true);
    	MBDPersistence mbdPersist = new MBDPersistence(true);

    	Member mbr = new Member();
        mbr.Initialize();
               
        MBDDatesView dateV = mbdPersist.getMBDDates(conn);        
        mbr.setMbdLoadDate(dateV.getMBDLoadDate());
        
        if (hicNbr.length() <= 12) {
        	String [] flags = new String[2];
            MBD mbd = mbdPersist.getHicMatch(conn, hicNbr, lastName, birthDate, testData, flags,"");
            mbr.setFoundHicNbr(flags[0]);
            mbr.setFoundNameorDOB(flags[1]);
                            
            if (mbd != null) {
                MBDHistoryPersistence mbdHistPersist = new MBDHistoryPersistence();
                SecPlanPersistence spp = new SecPlanPersistence();
                mbr.setHicNbr(mbd.getHicNbr());
                
                mbr.setLastName(mbd.getLastName());
                mbr.setFirstName(mbd.getFirstName());
                mbr.setMiddleInitial(mbd.getMiddleInit());
                
                mbr.setGenderCd(CodeCache.getShortGenderNumDesc(mbd.getGenderCd()));
                
                mbr.setBirthDate(mbd.getBirthDate());

                mbr.setPrtAEntitlementDate(DateFormatter.dateFilter(mbd.getPrtAEntitleDate()));
                mbr.setPrtAEntitleEndDate(DateFormatter.dateFilter(mbd.getPrtAEntitleEndDate()));

                mbr.setPrtBEntitlementDate(DateFormatter.dateFilter(mbd.getPrtBEntitleDate()));
                mbr.setPrtBEntitleEndDate(DateFormatter.dateFilter(mbd.getPrtBEntitleEndDate()));
                
                mbr.setStateCd(mbd.getStateCd());
                mbr.setCountyCd(mbd.getCountyCd());

                mbr.setHospiceStatus(mbd.getHospiceInd());
                mbr.setHospiceStartDate(DateFormatter.dateFilter(mbd.getHospiceStartDate()));
                mbr.setHospiceEndDate(DateFormatter.dateFilter(mbd.getHospiceEndDate()));

                mbr.setInstStatus(mbd.getInstInd());
                mbr.setInstStartDate(DateFormatter.dateFilter(mbd.getInstStartDate()));
                mbr.setInstEndDate(DateFormatter.dateFilter(mbd.getInstEndDate()));

                mbr.setEsrdStatus(mbd.getEsrdInd());
                mbr.setEsrdStartDate(DateFormatter.dateFilter(mbd.getEsrdStartDate()));
                mbr.setEsrdEndDate(DateFormatter.dateFilter(mbd.getEsrdEndDate()));
                
                mbr.setMedicaidStatus(mbd.getMedicInd());
                mbr.setMedicaidStartDate(DateFormatter.dateFilter(mbd.getMedicStartDate()));
                mbr.setMedicaidEndDate(DateFormatter.dateFilter(mbd.getMedicEndDate()));

                mbr.setEghpInd(mbd.getEghpInd());
                
                mbr.setLivingStatus(mbd.getLivingStatus());            
                mbr.setDeathDate(DateFormatter.dateFilter(mbd.getDeathDate()));
                
                // enrollmentInfo
                String planList = "";
                int arrSize = 0;
                String planId = StringUtil.nonNullTrim(mbd.getPlanId());
                String coPlanId = StringUtil.nonNullTrim(mbd.getCoPlanId());
                if (!planId.equals("")) {
                	arrSize += 1;
                	planList = "'" + planId + "'";
                }
                if (!coPlanId.equals("")) {
                	arrSize += 1;
                	if (!planList.equals(""))
                		planList = planList + ",";
                	planList = "'" + coPlanId + "'";
                }
                
            	PlanEnrollmentData [] edArr = new PlanEnrollmentData[arrSize];                
                if (arrSize > 0) {
                	int idx = 0;
                	PlanEnrollmentData ed;
                	if (!planId.equals("")) {
                		ed = new PlanEnrollmentData();
                		ed.setPlanId(planId);
                		ed.setPlanEnrollmentDate(DateFormatter.dateFilter(mbd.getPlanEnrollDate()));
                		
                        ed.setPbpId("");
                        ed.setPlanDisenrollmentDate("");
                        ed.setPBPStartDate("");
                        ed.setPBPEndDate("");
                		
                		edArr[idx] = ed;
                		idx += 1;
                	}
                	if (!coPlanId.equals("")) {
                		ed = new PlanEnrollmentData();
                		ed.setPlanId(coPlanId);
                		ed.setPlanEnrollmentDate(DateFormatter.dateFilter(mbd.getCoPlanEnrollDate()));
                		
                        ed.setPbpId("");
                        ed.setPlanDisenrollmentDate("");
                        ed.setPBPStartDate("");
                        ed.setPBPEndDate("");
                		
                		edArr[idx] = ed;
                		idx += 1;
                	}
                }
                mbr.setEnrollmentInfo(edArr);
                
                boolean rslt = spp.areAnyCustomerPlan(conn,custNbr,planList);
                if (rslt)
                	mbr.setInquiryResponse("M");
                else
                	mbr.setInquiryResponse("E");
                
                mbr.setPotentialUncvrdMthsEffDate(dateV.getUncoveredMonthsEffDate());
                mbr.setPotentialUncvrdMths(mbd.getUncovMonths());
                mbr.setPrtDEligibleDate(DateFormatter.dateFilter(mbd.getPrtDEligibleDate()));

                // LisInfo
                LisData [] ldArr = new LisData[2];

                LisData ld = new LisData();
                ld.setSubsidyStartDate(DateFormatter.dateFilter(mbd.getSubsidyStartDate1()));
                ld.setSubsidyEndDate(DateFormatter.dateFilter(mbd.getSubsidyEndDate1()));
                ld.setCopayLevel(mbd.getCopayLevelId1());
                ld.setPrtDPremSubPct(mbd.getPartDPremsubsPct1());
                ldArr[0] = ld;
                
                ld = new LisData();
                ld.setSubsidyStartDate(DateFormatter.dateFilter(mbd.getSubsidyStartDate2()));
                ld.setSubsidyEndDate(DateFormatter.dateFilter(mbd.getSubsidyEndDate2()));
                ld.setCopayLevel(mbd.getCopayLevelId2());
                ld.setPrtDPremSubPct(mbd.getPartDPremsubsPct2());
                ldArr[1] = ld;

                mbr.setLisInfo(ldArr);
                
                // prtDHistInfo
                // use return hic for lookups in case we match on the xref hic
                ArrayList prtDHistLst = mbdHistPersist.getPartDHistory(conn,mbr.getHicNbr());
                
                int arrSz = prtDHistLst.size();
                PartDHistData [] pdhArr = new PartDHistData[arrSz];
                Iterator iter = prtDHistLst.iterator();
                int cntr = 0;
                while (iter.hasNext()) {
                	PartDHistData pdh = new PartDHistData();
                	PrtDHistory prtDHist = (PrtDHistory)iter.next();
                	
                    pdh.setPrtDStartDate(DateFormatter.dateFilter(prtDHist.getPrtDStartDate()));
                    pdh.setPrtDEndDate(DateFormatter.dateFilter(prtDHist.getPrtDEndDate()));
                    pdh.setRdsIndicator("");
                    
                    pdhArr[cntr] = pdh;
                    cntr++;
                }
                
                mbr.setPrtDHistInfo(pdhArr);

                // nuncMoInfo
                // use return hic for lookups in case we match on the xref hic
                ArrayList nuncMoLst = mbdHistPersist.getNuncmo(conn,mbr.getHicNbr());
                arrSz = nuncMoLst.size();
                NuncMoData [] nuncMoArr = new NuncMoData[arrSz];
                iter = nuncMoLst.iterator();
                cntr = 0;
                while (iter.hasNext()) {
                    NuncMoData nmd = new NuncMoData();
                    MBDNuncmo mbdNuncmo = (MBDNuncmo)iter.next();
                    
                    nmd.setUncovMthsStartDate(mbdNuncmo.getStartDate());
                    nmd.setUncovMths(Integer.toString(mbdNuncmo.getNbrUncovMonths()));
                    nmd.setNuncmoInd(mbdNuncmo.getNuncmoInd());
                    nmd.setTotUncovMths(Integer.toString(mbdNuncmo.getTotNuncmo()));
                    
                    nuncMoArr[cntr] = nmd;
                    cntr++;
                }
                
                mbr.setNuncMoInfo(nuncMoArr);
                            
            }
        }
        
        return mbr;
    }    
    
    private Member getMemberInquiry(MBDPersistence mbdPersist, Connection conn, String hicNbr, String lastName, String birthDate, String custNbr,  boolean testData) throws SQLException {
        
        Member mbr = new Member();
        mbr.Initialize();
        if (hicNbr.length() <= 12) {
        	String [] flags = new String[2];
            MBD mbd = mbdPersist.getHicMatch(conn, hicNbr, lastName, birthDate, testData, flags,"");
            mbr.setFoundHicNbr(flags[0]);
            mbr.setFoundNameorDOB(flags[1]);
            
            MBDDatesView dateV = mbdPersist.getMBDDates(conn);
            mbr.setMbdLoadDate(dateV.getMBDLoadDate());
            
            if (mbd != null) {
                mbr.setPotentialUncvrdMthsEffDate(dateV.getUncoveredMonthsEffDate());
                
                mbr.setHicNbr(mbd.getHicNbr());
                
                mbr.setLastName(mbd.getLastName());
                mbr.setFirstName(mbd.getFirstName());
                mbr.setMiddleInitial(mbd.getMiddleInit());
                mbr.setGenderCd(CodeCache.getShortGenderNumDesc(mbd.getGenderCd()));
                mbr.setBirthDate(mbd.getBirthDate());
                
                mbr.setPrtAEntitlementDate(DateFormatter.dateFilter(mbd.getPrtAEntitleDate()));
                mbr.setPrtAEntitleEndDate(DateFormatter.dateFilter(mbd.getPrtAEntitleEndDate()));
                
                mbr.setPrtBEntitlementDate(DateFormatter.dateFilter(mbd.getPrtBEntitleDate()));
                mbr.setPrtBEntitleEndDate(DateFormatter.dateFilter(mbd.getPrtBEntitleEndDate()));
                
                mbr.setCountyCd(mbd.getCountyCd());                    
                mbr.setStateCd(mbd.getStateCd());
                
                mbr.setHospiceStatus(mbd.getHospiceInd());
                mbr.setHospiceStartDate(DateFormatter.dateFilter(mbd.getHospiceStartDate()));
                mbr.setHospiceEndDate(DateFormatter.dateFilter(mbd.getHospiceEndDate()));
                
                mbr.setEsrdStatus(mbd.getEsrdInd());
                mbr.setEsrdStartDate(DateFormatter.dateFilter(mbd.getEsrdStartDate()));
                mbr.setEsrdEndDate(DateFormatter.dateFilter(mbd.getEsrdEndDate()));
                
                mbr.setInstStatus(mbd.getInstInd());
                mbr.setInstStartDate(DateFormatter.dateFilter(mbd.getInstStartDate()));
                mbr.setInstEndDate(DateFormatter.dateFilter(mbd.getInstEndDate()));

                mbr.setMedicaidStatus(mbd.getMedicInd());
                mbr.setMedicaidStartDate(DateFormatter.dateFilter(mbd.getMedicStartDate()));
                mbr.setMedicaidEndDate(DateFormatter.dateFilter(mbd.getMedicEndDate()));
                
                mbr.setLivingStatus(mbd.getLivingStatus());            
                mbr.setDeathDate(DateFormatter.dateFilter(mbd.getDeathDate()));
                
                mbr.setEghpInd(mbd.getEghpInd());
                
                mbr.setPotentialUncvrdMths(mbd.getUncovMonths());
                mbr.setPrtDEligibleDate(DateFormatter.dateFilter(mbd.getPrtDEligibleDate()));
                
                MBDHistoryPersistence mbdHistPersist = new MBDHistoryPersistence();
                
                MBDHistResponseView mbdHistResp = mbdHistPersist.getPlanEnrollmentResponse(conn,hicNbr,custNbr);
                
                mbr.setInquiryResponse(mbdHistResp.getInquiryResponse());
                ArrayList histAL = mbdHistResp.getHist();
                if (histAL != null)
                {
                    int arrSize = histAL.size();
                    if (arrSize > 0) {
                    	PlanEnrollmentData [] edArr = new PlanEnrollmentData[arrSize];
                    	Iterator it = histAL.iterator();
                    	int cnt = 0;
                    	while (it.hasNext()) {
                            MBDHistView hist = (MBDHistView)it.next();
                                                    
                            PlanEnrollmentData ed = new PlanEnrollmentData();
                            ed.setPlanId(hist.getPlanId());
                            ed.setPbpId(hist.getPbpId());
                            ed.setPlanEnrollmentDate(DateFormatter.dateFilter(hist.getPlanEnrollDate()));
                            ed.setPlanDisenrollmentDate(DateFormatter.dateFilter(hist.getPlanDisenrollDate()));
                            ed.setPBPStartDate(DateFormatter.dateFilter(hist.getPbpStartDate()));
                            ed.setPBPEndDate(DateFormatter.dateFilter(hist.getPbpEndDate()));

                            edArr[cnt] = ed;
                            cnt++;
                    	}
                    	mbr.setEnrollmentInfo(edArr);
                    }
                }
                
                LisData [] ldArr = new LisData[2];

                LisData ld = new LisData();
                ld.setSubsidyStartDate(DateFormatter.dateFilter(mbd.getSubsidyStartDate1()));
                ld.setSubsidyEndDate(DateFormatter.dateFilter(mbd.getSubsidyEndDate1()));
                ld.setCopayLevel(mbd.getCopayLevelId1());
                ld.setPrtDPremSubPct(mbd.getPartDPremsubsPct1());
                ldArr[0] = ld;
                
                ld = new LisData();
                ld.setSubsidyStartDate(DateFormatter.dateFilter(mbd.getSubsidyStartDate2()));
                ld.setSubsidyEndDate(DateFormatter.dateFilter(mbd.getSubsidyEndDate2()));
                ld.setCopayLevel(mbd.getCopayLevelId2());
                ld.setPrtDPremSubPct(mbd.getPartDPremsubsPct2());
                ldArr[1] = ld;

                mbr.setLisInfo(ldArr);
                     
                ArrayList prtDHistLst = mbdHistPersist.getPartDHistory(conn,hicNbr);
                
                int arrSz = prtDHistLst.size();
                PartDHistData [] pdhArr = new PartDHistData[arrSz];
                Iterator iter = prtDHistLst.iterator();
                int cntr = 0;
                while (iter.hasNext()) {
                    PartDHistData pdh = new PartDHistData();
                    PrtDHistory prtDHist = (PrtDHistory)iter.next();
                    pdh.setPrtDStartDate(DateFormatter.dateFilter(prtDHist.getPrtDStartDate()));
                    pdh.setPrtDEndDate(DateFormatter.dateFilter(prtDHist.getPrtDEndDate()));
                    pdh.setRdsIndicator("");
                    pdhArr[cntr] = pdh;
                    cntr++;
                }
                
                mbr.setPrtDHistInfo(pdhArr);
                
                ArrayList nuncMoLst = mbdHistPersist.getNuncmo(conn,hicNbr);
                arrSz = nuncMoLst.size();
                NuncMoData [] nuncMoArr = new NuncMoData[arrSz];
                iter = nuncMoLst.iterator();
                cntr = 0;
                while (iter.hasNext()) {
                    NuncMoData nmd = new NuncMoData();
                    MBDNuncmo mbdNuncmo = (MBDNuncmo)iter.next();
                    
                    nmd.setUncovMthsStartDate(mbdNuncmo.getStartDate());
                    nmd.setUncovMths(Integer.toString(mbdNuncmo.getNbrUncovMonths()));
                    nmd.setNuncmoInd(mbdNuncmo.getNuncmoInd());
                    nmd.setTotUncovMths(Integer.toString(mbdNuncmo.getTotNuncmo()));
                    
                    nuncMoArr[cntr] = nmd;
                    cntr++;
                }
                
                mbr.setNuncMoInfo(nuncMoArr);
            }
        }
        
        return mbr;
    }

    /**
     * @deprecated
     * @param userId
     * @param passWord
     * @param hicNbr
     * @param lastName
     * @param birthDate
     * @return
     * @throws SOAPException
     */       
    public MedicareEligibilityRsp medicareEligibility(String userId, String passWord, String hicNbr, String lastName, String birthDate) throws SOAPException   {

        logger.info("Request Received: " + userId + " " + hicNbr + " " + lastName + " " + birthDate);
        checkForMaintenance(userId);
        
        Connection conn = null;

        MedicareEligibilityRsp mbr = null;
        
        try {

            conn = DbConn.getConnection();
            
            AuthUserPersistence aup = new AuthUserPersistence();
            AuthUser au = aup.get(conn,StringUtil.nonNullTrim(userId).toUpperCase());
            
            //authenticate the user and get the default plan id
            //String planId = authenticateUser(conn, log, au, passWord, userId, "medicareEligibility");
            //conn = getServiceConnection(conn, log, au, hicNbr);
            String planId = authenticateUser(conn, au, passWord, userId, "medicareEligibility");
            conn = getServiceConnection(conn, au);
            boolean testData = isTestData(au.getCustNbr());
            hicNbr = StringUtil.nonNullTrim(hicNbr).toUpperCase();            
            birthDate = StringUtil.nonNullTrim(birthDate);
            
            MBDPersistence mbdPersist = new MBDPersistence();
            mbr = getMedicareEligibilityEQ(conn,hicNbr,lastName,birthDate,au.getCustNbr(),testData);
            if (mbr == null)
            {	// should return flags now
            	throw new SOAPException("MSS-00120","Internal Processing Exception");
            }
                       
            String inquiryType = StringUtil.nonNullTrim(mbr.getInquiryResponse());
            submitBillingLogEntry(conn, au.getCustNbr(), au.getMfId(), au.getUserId(), planId, hicNbr, birthDate, inquiryType);
            
        } catch(SOAPException eES) {
            throw eES; 
        } catch(SQLException eSQL) {
            logger.error(eSQL.getMessage());
            throw new SOAPException("MSS-00125","Database Error");
        } catch(Exception e) {
            logger.error(e.getMessage());
            throw new SOAPException("MSS-00120","Internal Processing Exception");            
        } finally {
            try {
                if (conn != null)
                    conn.close();
            } catch (Exception e) {
                logger.error("DB conn close " + e.getMessage());
            }
        }

        //log.println("Returning data");
        logger.info("Request Responded: " + userId + " " + hicNbr + " " + lastName + " " + birthDate);
        return mbr;
    }

    private MedicareEligibilityRsp getMedicareEligibilityEQ(Connection conn, String hicNbr, String lastName, String birthDate, String custNbr,  boolean testData) throws SQLException {
        
    	DateUtil du = new DateUtil();
    	MBDPersistence mbdPersist = new MBDPersistence(true);
    	
    	MedicareEligibilityRsp mbr = new MedicareEligibilityRsp();
        mbr.Initialize();
             
        MBDDatesView dateV = mbdPersist.getMBDDates(conn);        
        mbr.setMbdLoadDate(dateV.getMBDLoadDate());
        
        if (hicNbr.length() <= 12) {
        	String [] flags = new String[2];
            MBD mbd = mbdPersist.getHicMatch(conn, hicNbr, lastName, birthDate, testData, flags,"");
            mbr.setFoundHicNbr(flags[0]);
            mbr.setFoundNameorDOB(flags[1]);
                            
            if (mbd != null) {
                MBDHistoryPersistence mbdHistPersist = new MBDHistoryPersistence();
                SecPlanPersistence spp = new SecPlanPersistence();
                
                mbr.setHicNbr(mbd.getHicNbr());
                
                mbr.setLastName(mbd.getLastName());
                mbr.setFirstName(mbd.getFirstName());
                mbr.setMiddleInitial(mbd.getMiddleInit());
                
                mbr.setGenderCd(CodeCache.getShortGenderNumDesc(mbd.getGenderCd()));
                
                mbr.setBirthDate(mbd.getBirthDate());

                mbr.setPrtAEntitlementDate(DateFormatter.dateFilter(mbd.getPrtAEntitleDate()));
                mbr.setPrtAEntitleEndDate(DateFormatter.dateFilter(mbd.getPrtAEntitleEndDate()));

                mbr.setPrtBEntitlementDate(DateFormatter.dateFilter(mbd.getPrtBEntitleDate()));
                mbr.setPrtBEntitleEndDate(DateFormatter.dateFilter(mbd.getPrtBEntitleEndDate()));
                
                mbr.setStateCd(mbd.getStateCd());
                mbr.setCountyCd(mbd.getCountyCd());

                mbr.setHospiceStatus(mbd.getHospiceInd());
                mbr.setHospiceStartDate(DateFormatter.dateFilter(mbd.getHospiceStartDate()));
                mbr.setHospiceEndDate(DateFormatter.dateFilter(mbd.getHospiceEndDate()));

                mbr.setInstStatus(mbd.getInstInd());
                mbr.setInstStartDate(DateFormatter.dateFilter(mbd.getInstStartDate()));
                mbr.setInstEndDate(DateFormatter.dateFilter(mbd.getInstEndDate()));

                mbr.setEsrdStatus(mbd.getEsrdInd());
                mbr.setEsrdStartDate(DateFormatter.dateFilter(mbd.getEsrdStartDate()));
                mbr.setEsrdEndDate(DateFormatter.dateFilter(mbd.getEsrdEndDate()));
                
                mbr.setMedicaidStatus(mbd.getMedicInd());
                mbr.setMedicaidStartDate(DateFormatter.dateFilter(mbd.getMedicStartDate()));
                mbr.setMedicaidEndDate(DateFormatter.dateFilter(mbd.getMedicEndDate()));

                mbr.setEghpInd(mbd.getEghpInd());
                
                mbr.setLivingStatus(mbd.getLivingStatus());            
                mbr.setDeathDate(DateFormatter.dateFilter(mbd.getDeathDate()));
                
                // enrollmentInfo
                String planList = "";
                int arrSize = 0;
                String planId = StringUtil.nonNullTrim(mbd.getPlanId());
                String coPlanId = StringUtil.nonNullTrim(mbd.getCoPlanId());
                if (!planId.equals("")) {
                	arrSize += 1;
                	planList = "'" + planId + "'";
                }
                if (!coPlanId.equals("")) {
                	arrSize += 1;
                	if (!planList.equals(""))
                		planList = planList + ",";
                	planList = "'" + coPlanId + "'";
                }
                
            	PlanEnrollmentData [] edArr = new PlanEnrollmentData[arrSize];                
                if (arrSize > 0) {
                	int idx = 0;
                	PlanEnrollmentData ed;
                	if (!planId.equals("")) {
                		ed = new PlanEnrollmentData();
                		ed.setPlanId(planId);
                		ed.setPlanEnrollmentDate(DateFormatter.dateFilter(mbd.getPlanEnrollDate()));
                		
                        ed.setPbpId("");
                        ed.setPlanDisenrollmentDate("");
                        ed.setPBPStartDate("");
                        ed.setPBPEndDate("");

                		edArr[idx] = ed;
                		idx += 1;
                	}
                	if (!coPlanId.equals("")) {
                		ed = new PlanEnrollmentData();
                		ed.setPlanId(coPlanId);
                		ed.setPlanEnrollmentDate(DateFormatter.dateFilter(mbd.getCoPlanEnrollDate()));
                		
                        ed.setPbpId("");
                        ed.setPlanDisenrollmentDate("");
                        ed.setPBPStartDate("");
                        ed.setPBPEndDate("");
                		
                		edArr[idx] = ed;
                		idx += 1;
                	}
                }
                mbr.setEnrollmentInfo(edArr);
                
                boolean rslt = spp.areAnyCustomerPlan(conn,custNbr,planList);
                if (rslt)
                	mbr.setInquiryResponse("M");
                else
                	mbr.setInquiryResponse("E");
                
                mbr.setPotentialUncvrdMthsEffDate(dateV.getUncoveredMonthsEffDate());
                mbr.setPotentialUncvrdMths(mbd.getUncovMonths());
                mbr.setPrtDEligibleDate(DateFormatter.dateFilter(mbd.getPrtDEligibleDate()));

                // LisInfo
                LisData [] ldArr = new LisData[2];

                LisData ld = new LisData();
                ld.setSubsidyStartDate(DateFormatter.dateFilter(mbd.getSubsidyStartDate1()));
                ld.setSubsidyEndDate(DateFormatter.dateFilter(mbd.getSubsidyEndDate1()));
                ld.setCopayLevel(mbd.getCopayLevelId1());
                ld.setPrtDPremSubPct(mbd.getPartDPremsubsPct1());
                ldArr[0] = ld;
                
                ld = new LisData();
                ld.setSubsidyStartDate(DateFormatter.dateFilter(mbd.getSubsidyStartDate2()));
                ld.setSubsidyEndDate(DateFormatter.dateFilter(mbd.getSubsidyEndDate2()));
                ld.setCopayLevel(mbd.getCopayLevelId2());
                ld.setPrtDPremSubPct(mbd.getPartDPremsubsPct2());
                ldArr[1] = ld;

                mbr.setLisInfo(ldArr);
                
                // prtDHistInfo
                // use return hic for lookups in case we match on the xref hic
                ArrayList prtDHistLst = mbdHistPersist.getPartDHistory(conn,mbr.getHicNbr());
                
                int arrSz = prtDHistLst.size();
                PartDHistory [] pdhArr = new PartDHistory[arrSz];
                Iterator iter = prtDHistLst.iterator();
                int cntr = 0;
                while (iter.hasNext()) {
                    PartDHistory pdh = new PartDHistory();
                    PrtDHistory prtDHist = (PrtDHistory)iter.next();
                    pdh.setPrtDStartDate(DateFormatter.dateFilter(prtDHist.getPrtDStartDate()));
                    pdh.setPrtDEndDate(DateFormatter.dateFilter(prtDHist.getPrtDEndDate()));
                    pdhArr[cntr] = pdh;
                    cntr++;
                }
                
                mbr.setPrtDHistInfo(pdhArr);

                // nuncMoInfo
                // use return hic for lookups in case we match on the xref hic
                ArrayList nuncMoLst = mbdHistPersist.getNuncmo(conn,mbr.getHicNbr());
                arrSz = nuncMoLst.size();
                NuncMoData [] nuncMoArr = new NuncMoData[arrSz];
                iter = nuncMoLst.iterator();
                cntr = 0;
                while (iter.hasNext()) {
                    NuncMoData nmd = new NuncMoData();
                    MBDNuncmo mbdNuncmo = (MBDNuncmo)iter.next();
                    
                    nmd.setUncovMthsStartDate(mbdNuncmo.getStartDate());
                    nmd.setUncovMths(Integer.toString(mbdNuncmo.getNbrUncovMonths()));
                    nmd.setNuncmoInd(mbdNuncmo.getNuncmoInd());
                    nmd.setTotUncovMths(Integer.toString(mbdNuncmo.getTotNuncmo()));
                    
                    nuncMoArr[cntr] = nmd;
                    cntr++;
                }
                
                mbr.setNuncMoInfo(nuncMoArr);
                
                // rdsHistInfo
                // use return hic for lookups in case we match on the xref hic
                ArrayList rdsLst = mbdHistPersist.getRDSHistory(conn,mbr.getHicNbr());                
                arrSz = rdsLst.size();
                RDSHistoryData [] rdsArr = new RDSHistoryData[arrSz];
                iter = rdsLst.iterator();
                cntr = 0;
                while (iter.hasNext()) {
                	RDSHistoryData item = new RDSHistoryData();
                	RDSHistory rdsHist = (RDSHistory)iter.next();
                	item.setRdsStartDate(DateFormatter.dateFilter(rdsHist.getRdsStartDate()));
                	item.setRdsEndDate(DateFormatter.dateFilter(rdsHist.getRdsEndDate()));
                	rdsArr[cntr++] = item;
                }
                mbr.setRdsHistInfo(rdsArr);                 
            
            }
        }
        
        return mbr;
    }    
    
    private MedicareEligibilityRsp getMedicareEligibility(MBDPersistence mbdPersist, Connection conn, String hicNbr, String lastName, String birthDate, String custNbr,  boolean testData) throws SQLException {
        
    	MedicareEligibilityRsp mbr = new MedicareEligibilityRsp();
        mbr.Initialize();
        if (hicNbr.length() <= 12) {
        	String [] flags = new String[2];
            MBD mbd = mbdPersist.getHicMatch(conn, hicNbr, lastName, birthDate, testData, flags,"");
            mbr.setFoundHicNbr(flags[0]);
            mbr.setFoundNameorDOB(flags[1]);
            
            MBDDatesView dateV = mbdPersist.getMBDDates(conn);
            mbr.setMbdLoadDate(dateV.getMBDLoadDate());
            
            if (mbd != null) {

                mbr.setPotentialUncvrdMthsEffDate(dateV.getUncoveredMonthsEffDate());
                
                mbr.setHicNbr(mbd.getHicNbr());
                
                mbr.setLastName(mbd.getLastName());
                mbr.setFirstName(mbd.getFirstName());
                mbr.setMiddleInitial(mbd.getMiddleInit());
                mbr.setGenderCd(CodeCache.getShortGenderNumDesc(mbd.getGenderCd()));
                mbr.setBirthDate(mbd.getBirthDate());
                
                mbr.setPrtAEntitlementDate(DateFormatter.dateFilter(mbd.getPrtAEntitleDate()));
                mbr.setPrtAEntitleEndDate(DateFormatter.dateFilter(mbd.getPrtAEntitleEndDate()));
                
                mbr.setPrtBEntitlementDate(DateFormatter.dateFilter(mbd.getPrtBEntitleDate()));
                mbr.setPrtBEntitleEndDate(DateFormatter.dateFilter(mbd.getPrtBEntitleEndDate()));
                
                mbr.setCountyCd(mbd.getCountyCd());                    
                mbr.setStateCd(mbd.getStateCd());
                
                mbr.setHospiceStatus(mbd.getHospiceInd());
                mbr.setHospiceStartDate(DateFormatter.dateFilter(mbd.getHospiceStartDate()));
                mbr.setHospiceEndDate(DateFormatter.dateFilter(mbd.getHospiceEndDate()));
                
                mbr.setEsrdStatus(mbd.getEsrdInd());
                mbr.setEsrdStartDate(DateFormatter.dateFilter(mbd.getEsrdStartDate()));
                mbr.setEsrdEndDate(DateFormatter.dateFilter(mbd.getEsrdEndDate()));
                
                mbr.setInstStatus(mbd.getInstInd());
                mbr.setInstStartDate(DateFormatter.dateFilter(mbd.getInstStartDate()));
                mbr.setInstEndDate(DateFormatter.dateFilter(mbd.getInstEndDate()));

                mbr.setMedicaidStatus(mbd.getMedicInd());
                mbr.setMedicaidStartDate(DateFormatter.dateFilter(mbd.getMedicStartDate()));
                mbr.setMedicaidEndDate(DateFormatter.dateFilter(mbd.getMedicEndDate()));
                
                mbr.setLivingStatus(mbd.getLivingStatus());            
                mbr.setDeathDate(DateFormatter.dateFilter(mbd.getDeathDate()));
                
                mbr.setEghpInd(mbd.getEghpInd());
                
                mbr.setPotentialUncvrdMths(mbd.getUncovMonths());
                mbr.setPrtDEligibleDate(DateFormatter.dateFilter(mbd.getPrtDEligibleDate()));
                
                MBDHistoryPersistence mbdHistPersist = new MBDHistoryPersistence();
                
                MBDHistResponseView mbdHistResp = mbdHistPersist.getPlanEnrollmentResponse(conn,hicNbr,custNbr);
                
                mbr.setInquiryResponse(mbdHistResp.getInquiryResponse());
                ArrayList histAL = mbdHistResp.getHist();
                if (histAL != null)
                {
                    int arrSize = histAL.size();
                    if (arrSize > 0) {
                    	PlanEnrollmentData [] edArr = new PlanEnrollmentData[arrSize];
                    	Iterator it = histAL.iterator();
                    	int cnt = 0;
                    	while (it.hasNext()) {
                            MBDHistView hist = (MBDHistView)it.next();
                                                    
                            PlanEnrollmentData ed = new PlanEnrollmentData();
                            ed.setPlanId(hist.getPlanId());
                            ed.setPbpId(hist.getPbpId());
                            ed.setPlanEnrollmentDate(DateFormatter.dateFilter(hist.getPlanEnrollDate()));
                            ed.setPlanDisenrollmentDate(DateFormatter.dateFilter(hist.getPlanDisenrollDate()));
                            ed.setPBPStartDate(DateFormatter.dateFilter(hist.getPbpStartDate()));
                            ed.setPBPEndDate(DateFormatter.dateFilter(hist.getPbpEndDate()));

                            edArr[cnt] = ed;
                            cnt++;
                    	}
                    	mbr.setEnrollmentInfo(edArr);
                    }
                }
                
                LisData [] ldArr = new LisData[2];

                LisData ld = new LisData();
                ld.setSubsidyStartDate(DateFormatter.dateFilter(mbd.getSubsidyStartDate1()));
                ld.setSubsidyEndDate(DateFormatter.dateFilter(mbd.getSubsidyEndDate1()));
                ld.setCopayLevel(mbd.getCopayLevelId1());
                ld.setPrtDPremSubPct(mbd.getPartDPremsubsPct1());
                ldArr[0] = ld;
                
                ld = new LisData();
                ld.setSubsidyStartDate(DateFormatter.dateFilter(mbd.getSubsidyStartDate2()));
                ld.setSubsidyEndDate(DateFormatter.dateFilter(mbd.getSubsidyEndDate2()));
                ld.setCopayLevel(mbd.getCopayLevelId2());
                ld.setPrtDPremSubPct(mbd.getPartDPremsubsPct2());
                ldArr[1] = ld;

                mbr.setLisInfo(ldArr);
                     
                ArrayList prtDHistLst = mbdHistPersist.getPartDHistory(conn,hicNbr);
                
                int arrSz = prtDHistLst.size();
                PartDHistory [] pdhArr = new PartDHistory[arrSz];
                Iterator iter = prtDHistLst.iterator();
                int cntr = 0;
                while (iter.hasNext()) {
                    PartDHistory pdh = new PartDHistory();
                    PrtDHistory prtDHist = (PrtDHistory)iter.next();
                    pdh.setPrtDStartDate(DateFormatter.dateFilter(prtDHist.getPrtDStartDate()));
                    pdh.setPrtDEndDate(DateFormatter.dateFilter(prtDHist.getPrtDEndDate()));
                    pdhArr[cntr] = pdh;
                    cntr++;
                }
                
                mbr.setPrtDHistInfo(pdhArr);
                
                ArrayList nuncMoLst = mbdHistPersist.getNuncmo(conn,hicNbr);
                arrSz = nuncMoLst.size();
                NuncMoData [] nuncMoArr = new NuncMoData[arrSz];
                iter = nuncMoLst.iterator();
                cntr = 0;
                while (iter.hasNext()) {
                    NuncMoData nmd = new NuncMoData();
                    MBDNuncmo mbdNuncmo = (MBDNuncmo)iter.next();
                    
                    nmd.setUncovMthsStartDate(mbdNuncmo.getStartDate());
                    nmd.setUncovMths(Integer.toString(mbdNuncmo.getNbrUncovMonths()));
                    nmd.setNuncmoInd(mbdNuncmo.getNuncmoInd());
                    nmd.setTotUncovMths(Integer.toString(mbdNuncmo.getTotNuncmo()));
                    
                    nuncMoArr[cntr] = nmd;
                    cntr++;
                }
                
                mbr.setNuncMoInfo(nuncMoArr);
 
                ArrayList rdsLst = mbdHistPersist.getRDSHistory(conn,hicNbr);                
                arrSz = rdsLst.size();
                RDSHistoryData [] rdsArr = new RDSHistoryData[arrSz];
                iter = rdsLst.iterator();
                cntr = 0;
                while (iter.hasNext()) {
                	RDSHistoryData item = new RDSHistoryData();
                	RDSHistory rdsHist = (RDSHistory)iter.next();
                	item.setRdsStartDate(DateFormatter.dateFilter(rdsHist.getRdsStartDate()));
                	item.setRdsEndDate(DateFormatter.dateFilter(rdsHist.getRdsEndDate()));
                	rdsArr[cntr++] = item;
                }
                mbr.setRdsHistInfo(rdsArr);
            }
        }
        
        return mbr;
    }    

    public EligibilityQueryRsp eligibilityQuery(String userId, String passWord, String hicNbr, String lastName, String birthDate) throws SOAPException   {

        logger.info("Request Received: " + userId + " " + hicNbr + " " + lastName + " " + birthDate);
        checkForMaintenance(userId);
        
        Connection conn = null;

        EligibilityQueryRsp mbr = null;
        
        try {

            conn = DbConn.getConnection();
            
            AuthUserPersistence aup = new AuthUserPersistence();
            AuthUser au = aup.get(conn,StringUtil.nonNullTrim(userId).toUpperCase());
            
            //authenticate the user and get the default plan id
            String planId = authenticateUser(conn, au, passWord, userId, "eligibilityQuery");
            conn = getServiceConnection(conn, au);
            
            boolean testData = isTestData(au.getCustNbr());
            hicNbr = StringUtil.nonNullTrim(hicNbr).toUpperCase();            
            birthDate = StringUtil.nonNullTrim(birthDate);
            
            mbr = getEligibilityQuery(conn,hicNbr,lastName,birthDate,au.getCustNbr(),testData);
            if (mbr == null)
            {	// should return flags now
            	throw new SOAPException("MSS-00120","Internal Processing Exception");
            }
                       
            String inquiryType = StringUtil.nonNullTrim(mbr.getInquiryResponse());
            
            submitBillingLogEntry(conn, au.getCustNbr(), au.getMfId(), au.getUserId(), planId, hicNbr, birthDate, inquiryType);
            
        } catch(SOAPException eES) {
        	logger.error(eES.getMessage());
            throw eES; 
        } catch(SQLException eSQL) {
        	logger.error(eSQL.getMessage());
            throw new SOAPException("MSS-00125","Database Error");
        } catch(Exception e) {
            logger.error(e.getMessage());
            throw new SOAPException("MSS-00120","Internal Processing Exception");            
        } finally {
            try {
                if (conn != null)
                    conn.close();
            } catch (Exception e) {
                logger.error("DB conn close " + e.getMessage());
            }
        }

        //log.println("Returning data");
        logger.info("Request Responded: " + userId + " " + hicNbr + " " + lastName + " " + birthDate);
        return mbr;
    }
    
    private EligibilityQueryRsp getEligibilityQuery(Connection conn, String hicNbr, String lastName, String birthDate, String custNbr,  boolean testData) throws SQLException {
        
    	DateUtil du = new DateUtil();
    	MBDPersistence mbdPersist = new MBDPersistence(true);
    	
    	EligibilityQueryRsp mbr = new EligibilityQueryRsp();
        mbr.Initialize();
       
        mbr.setTxnDate(du.getDTS().substring(0,14));
        
        mbr.setRequestHicNbr(hicNbr);
        mbr.setRequestLastName(lastName);
        mbr.setRequestDOB(birthDate);
        
        MBDDatesView dateV = mbdPersist.getMBDDates(conn);        
        mbr.setMbdLoadEffDate(dateV.getMBDLoadDate());
        
        if (hicNbr.length() <= 12) {
        	//SSNRI changes- start
        	String [] flags = new String[3];
        	//SSNRI changes- end
            MBD mbd = mbdPersist.getHicMatchXRef(conn, hicNbr, lastName, birthDate, testData, flags);
            mbr.setFoundHicNbr(flags[0]);
            mbr.setFoundNameorDOB(flags[1]);
                            
            if (mbd != null) {

                MBDHistoryPersistence mbdHistPersist = new MBDHistoryPersistence();
                SecPlanPersistence spp = new SecPlanPersistence();
                
                mbr.setHicNbr(mbd.getHicNbr());
                
                mbr.setLastName(mbd.getLastName());
                mbr.setFirstName(mbd.getFirstName());
                mbr.setMiddleInitial(mbd.getMiddleInit());
                
                mbr.setGenderCd(CodeCache.getShortGenderNumDesc(mbd.getGenderCd()));
                mbr.setRaceCd(mbd.getRaceCd());
                
                mbr.setBirthDate(mbd.getBirthDate());

                mbr.setPrtAEntitlementDate(DateFormatter.dateFilter(mbd.getPrtAEntitleDate()));
                mbr.setPrtAEntitleEndDate(DateFormatter.dateFilter(mbd.getPrtAEntitleEndDate()));

                mbr.setPrtBEntitlementDate(DateFormatter.dateFilter(mbd.getPrtBEntitleDate()));
                mbr.setPrtBEntitleEndDate(DateFormatter.dateFilter(mbd.getPrtBEntitleEndDate()));
                
                mbr.setStateCd(mbd.getStateCd());
                mbr.setCountyCd(mbd.getCountyCd());

                mbr.setHospiceStatus(mbd.getHospiceInd());
                mbr.setHospiceStartDate(DateFormatter.dateFilter(mbd.getHospiceStartDate()));
                mbr.setHospiceEndDate(DateFormatter.dateFilter(mbd.getHospiceEndDate()));

                mbr.setInstStatus(mbd.getInstInd());
                mbr.setInstStartDate(DateFormatter.dateFilter(mbd.getInstStartDate()));
                mbr.setInstEndDate(DateFormatter.dateFilter(mbd.getInstEndDate()));

                mbr.setEsrdStatus(mbd.getEsrdInd());
                mbr.setEsrdStartDate(DateFormatter.dateFilter(mbd.getEsrdStartDate()));
                mbr.setEsrdEndDate(DateFormatter.dateFilter(mbd.getEsrdEndDate()));
                
                mbr.setMedicaidStatus(mbd.getMedicInd());
                mbr.setMedicaidStartDate(DateFormatter.dateFilter(mbd.getMedicStartDate()));
                mbr.setMedicaidEndDate(DateFormatter.dateFilter(mbd.getMedicEndDate()));

                mbr.setEghpInd(mbd.getEghpInd());
                
                mbr.setLivingStatus(mbd.getLivingStatus());            
                mbr.setDeathDate(DateFormatter.dateFilter(mbd.getDeathDate()));

                if (mbd.getXrefClaimNbr().equals(mbd.getHicNbr()))
                	mbr.setXrefHicNbr("");
                else
                	mbr.setXrefHicNbr(mbd.getXrefClaimNbr());
                
                // enrollmentInfo
                String planList = "";
                int arrSize = 0;
                String planId = StringUtil.nonNullTrim(mbd.getPlanId());
                String coPlanId = StringUtil.nonNullTrim(mbd.getCoPlanId());
                if (!planId.equals("")) {
                	arrSize += 1;
                	planList = "'" + planId + "'";
                }
                if (!coPlanId.equals("")) {
                	arrSize += 1;
                	if (!planList.equals(""))
                		planList = planList + ",";
                	planList = "'" + coPlanId + "'";
                }
                
            	EnrollmentData [] edArr = new EnrollmentData[arrSize];                
                if (arrSize > 0) {
                	int idx = 0;
                	EnrollmentData ed;
                	if (!planId.equals("")) {
                		ed = new EnrollmentData();
                		ed.setPlanId(planId);
                		ed.setPlanEnrollmentDate(DateFormatter.dateFilter(mbd.getPlanEnrollDate()));
                		ed.setDrugPlanInd(mbd.getPlanDrugInd());
                		edArr[idx] = ed;
                		idx += 1;
                	}
                	if (!coPlanId.equals("")) {
                		ed = new EnrollmentData();
                		ed.setPlanId(coPlanId);
                		ed.setPlanEnrollmentDate(DateFormatter.dateFilter(mbd.getCoPlanEnrollDate()));
                		ed.setDrugPlanInd(mbd.getCoPlanDrugInd());
                		edArr[idx] = ed;
                		idx += 1;
                	}
                }
                mbr.setEnrollmentInfo(edArr);
                
                boolean rslt = spp.areAnyCustomerPlan(conn,custNbr,planList);
                if (rslt)
                	mbr.setInquiryResponse("M");
                else
                	mbr.setInquiryResponse("E");
                
                mbr.setPotentialUncvrdMthsEffDate(dateV.getUncoveredMonthsEffDate());
                mbr.setPotentialUncvrdMths(mbd.getUncovMonths());
                mbr.setPrtDEligibleDate(DateFormatter.dateFilter(mbd.getPrtDEligibleDate()));

                // LisInfo
                LisData [] ldArr = new LisData[2];

                LisData ld = new LisData();
                ld.setSubsidyStartDate(DateFormatter.dateFilter(mbd.getSubsidyStartDate1()));
                ld.setSubsidyEndDate(DateFormatter.dateFilter(mbd.getSubsidyEndDate1()));
                ld.setCopayLevel(mbd.getCopayLevelId1());
                ld.setPrtDPremSubPct(mbd.getPartDPremsubsPct1());
                ldArr[0] = ld;
                
                ld = new LisData();
                ld.setSubsidyStartDate(DateFormatter.dateFilter(mbd.getSubsidyStartDate2()));
                ld.setSubsidyEndDate(DateFormatter.dateFilter(mbd.getSubsidyEndDate2()));
                ld.setCopayLevel(mbd.getCopayLevelId2());
                ld.setPrtDPremSubPct(mbd.getPartDPremsubsPct2());
                ldArr[1] = ld;

                mbr.setLisInfo(ldArr);
                
                // prtDHistInfo
                // use return hic for lookups in case we match on the xref hic
                ArrayList prtDHistLst = mbdHistPersist.getPartDHistory(conn,mbr.getHicNbr());
                
                int arrSz = prtDHistLst.size();
                PartDHistory [] pdhArr = new PartDHistory[arrSz];
                Iterator iter = prtDHistLst.iterator();
                int cntr = 0;
                while (iter.hasNext()) {
                    PartDHistory pdh = new PartDHistory();
                    PrtDHistory prtDHist = (PrtDHistory)iter.next();
                    pdh.setPrtDStartDate(DateFormatter.dateFilter(prtDHist.getPrtDStartDate()));
                    pdh.setPrtDEndDate(DateFormatter.dateFilter(prtDHist.getPrtDEndDate()));
                    pdhArr[cntr] = pdh;
                    cntr++;
                }
                
                mbr.setPrtDHistInfo(pdhArr);

                // nuncMoInfo
                // use return hic for lookups in case we match on the xref hic
                ArrayList nuncMoLst = mbdHistPersist.getNuncmo(conn,mbr.getHicNbr());
                arrSz = nuncMoLst.size();
                NuncMoData [] nuncMoArr = new NuncMoData[arrSz];
                iter = nuncMoLst.iterator();
                cntr = 0;
                while (iter.hasNext()) {
                    NuncMoData nmd = new NuncMoData();
                    MBDNuncmo mbdNuncmo = (MBDNuncmo)iter.next();
                    
                    nmd.setUncovMthsStartDate(mbdNuncmo.getStartDate());
                    nmd.setUncovMths(Integer.toString(mbdNuncmo.getNbrUncovMonths()));
                    nmd.setNuncmoInd(mbdNuncmo.getNuncmoInd());
                    nmd.setTotUncovMths(Integer.toString(mbdNuncmo.getTotNuncmo()));
                    
                    nuncMoArr[cntr] = nmd;
                    cntr++;
                }
                
                mbr.setNuncMoInfo(nuncMoArr);
                
                // rdsHistInfo
                // use return hic for lookups in case we match on the xref hic
                ArrayList rdsLst = mbdHistPersist.getRDSHistory(conn,mbr.getHicNbr());                
                arrSz = rdsLst.size();
                RDSHistoryData [] rdsArr = new RDSHistoryData[arrSz];
                iter = rdsLst.iterator();
                cntr = 0;
                while (iter.hasNext()) {
                	RDSHistoryData item = new RDSHistoryData();
                	RDSHistory rdsHist = (RDSHistory)iter.next();
                	item.setRdsStartDate(DateFormatter.dateFilter(rdsHist.getRdsStartDate()));
                	item.setRdsEndDate(DateFormatter.dateFilter(rdsHist.getRdsEndDate()));
                	rdsArr[cntr++] = item;
                }
                mbr.setRdsHistInfo(rdsArr);                 
            
            }
        }
        
        return mbr;
    }    
    
    
    private void checkForMaintenance(String userId) throws SOAPException {
        File fn = new File("D:\\Java\\MAINTENANCE");
        if (fn.exists())
        {
        	if (!StringUtil.nonNullTrim(userId).equals("HCFLCSWS"))
       			throw new SOAPException("MSS-00090","System Maintenance");
        }
    }
    
    private boolean checkActive(String method) {
        File fn = new File("D:\\Java\\properties\\" + method);
        if (fn.exists())
        {
        	return false;
        }
        return true;
    }
    
    private boolean isTestData(String custNbr) {
    	MBDPersistence mbdP = new MBDPersistence();
    	return mbdP.checkDemoAccount(custNbr);
    }
    
        private String authenticateUser(Connection conn, AuthUser au, String passWord, String userId, String method) throws SOAPException, SQLException {

    	if (!checkActive(method)) {
    		CustSvcParmsPersistence csp = new CustSvcParmsPersistence();
    		String val = StringUtil.nonNullTrim(csp.getParmValue(conn,au.getMfId(),"EPI",method));
    		if (!val.equals("ALLOW")) {
    			 logger.info("Web Service Depreciated: " + userId + " " + method);
            	throw new SOAPException("MSS-00120","No Such Method");    			
    		}
    	}
    	
        AuthUserManager mgr = new AuthUserManager();

        int authCode = mgr.authenticate(au,passWord);
        if ((authCode == AuthUserManager.AUTH_NO_USER) || (authCode == AuthUserManager.AUTH_BAD_PWD))
        {
        	 logger.info("Security DB Invalid User Id / Password " + userId);
            throw new SOAPException("MSS-00100","Invalid Logon Id / Password");
        }
        
        if (authCode == AuthUserManager.AUTH_USER_INACTIVE)
        {
        	 logger.info("Security DB Inactive User " + userId);
            throw new SOAPException("MSS-00105","User id is not active");
        }

        if (authCode == AuthUserManager.AUTH_PWD_EXPIRE)
        {
            logger.info("Security DB Password Expired " + userId);
            throw new SOAPException("MSS-00110","Password Expired");
        }

        SecPlanPersistence spp = new SecPlanPersistence();

        String planId = spp.getDefaultPlan(conn,au.getCustNbr());
        if (planId == null)
        {
            logger.info("Security DB Plan ID Query Error Cust: " + au.getCustNbr());
            throw new SOAPException("MSS-00115","Configuration Error");
        }
        return planId;
    }
    
    private Connection getServiceConnection(Connection conn, AuthUser au) throws SOAPException, SQLException{
    	ServicePersistence sp = new ServicePersistence();
        if (!sp.hasService(conn,au.getGroupId(),"EPI"))
        {
        	if(!sp.hasService(conn,au.getGroupId(),"EPIT")) 
        	{
	            logger.info("User/Group Not Authorized For Service: " + au.getUserId() +  "/" + au.getGroupId());
	            throw new SOAPException("MSS-00115","Configuration Error");
        	}
        	else
        	{
                conn.close();
        		conn = DbConn.getConnection(DbConn.DB_TEST);
        	}
        }
        return conn;
    }
    
    private void submitBillingLogEntry(Connection conn, String custNbr, String mfId, String userId, String planId, String hicNbr, String birthDate, String inquiryType) throws SQLException {
    	BillingLogPersistence blp = new BillingLogPersistence();

        String billingCust = custNbr;
        
        BillingLog billingLogEntry = new BillingLog();
        billingLogEntry.setCustNbr(billingCust);
        billingLogEntry.setPlanId(planId);
        billingLogEntry.setMfId(mfId);
        billingLogEntry.setUserId(userId);
        
        if (inquiryType.equalsIgnoreCase("M"))
            billingLogEntry.setRecType(BillingLog.REC_WSELIGIB_M);
        else
            billingLogEntry.setRecType(BillingLog.REC_WSELIGIB);            
        billingLogEntry.setProgramId(BillingLog.MSS_WSELIGIB);
        if (hicNbr.length() <= 12)
            billingLogEntry.setHicNbr(hicNbr);
        else
            billingLogEntry.setHicNbr("<hic length>");

        try {
		    blp.preparePut(conn);
		    blp.put(conn,billingLogEntry);
        } catch (SQLException eSQL) {
        	throw eSQL;
        } finally {
        	if (blp != null) {
                try {
                    blp.closePut();
                } catch(Exception e) {
                    logger.error("blp close " + e.getMessage());
                }
            }
        }
    }
}