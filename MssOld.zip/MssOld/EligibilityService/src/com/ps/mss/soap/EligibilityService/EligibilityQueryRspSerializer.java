/*
 * $Id: EligibilityQueryRspSerializer.java,v 1.1 2014/06/26 07:24:12 praveen Exp $
 */
package com.ps.mss.soap.EligibilityService;

import java.io.IOException;
import java.io.Writer;

import org.apache.soap.encoding.soapenc.SoapEncUtils;
import org.apache.soap.rpc.Parameter;
import org.apache.soap.rpc.RPCConstants;
import org.apache.soap.rpc.SOAPContext;
import org.apache.soap.util.Bean;
import org.apache.soap.util.StringUtils;
import org.apache.soap.util.xml.DOMUtils;
import org.apache.soap.util.xml.Deserializer;
import org.apache.soap.util.xml.NSStack;
import org.apache.soap.util.xml.QName;
import org.apache.soap.util.xml.Serializer;
import org.apache.soap.util.xml.XMLJavaMappingRegistry;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class EligibilityQueryRspSerializer implements Serializer,
		Deserializer {

	/* (non-Javadoc)
	 * @see org.apache.soap.util.xml.Serializer#marshall(java.lang.String, java.lang.Class, java.lang.Object, java.lang.Object, java.io.Writer, org.apache.soap.util.xml.NSStack, org.apache.soap.util.xml.XMLJavaMappingRegistry, org.apache.soap.rpc.SOAPContext)
	 */
    public void marshall(String inScopeEncStyle, Class javaType,
            Object src, Object context, Writer sink,
            NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
    			throws IllegalArgumentException, IOException {       

    	nsStack.pushScope();

    	SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context, sink, nsStack, xjmr);
    	sink.write(StringUtils.lineSeparator);

    	EligibilityQueryRsp medElig = (EligibilityQueryRsp)src;
    	Parameter param;

    	param = new Parameter("txnDate", java.lang.String.class, medElig.getTxnDate(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("mbdLoadEffDate", java.lang.String.class, medElig.getMbdLoadEffDate(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("requestHicNbr", java.lang.String.class, medElig.getRequestHicNbr(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("requestLastName", java.lang.String.class, medElig.getRequestLastName(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("requestDOB", java.lang.String.class, medElig.getRequestDOB(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);
    	
    	param = new Parameter("foundHicNbr", java.lang.String.class, medElig.getFoundHicNbr(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("foundNameorDOB", java.lang.String.class, medElig.getFoundNameorDOB(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("inquiryResponse", java.lang.String.class, medElig.getInquiryResponse(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("hicNbr", java.lang.String.class, medElig.getHicNbr(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("lastName", java.lang.String.class, medElig.getLastName(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("firstName", java.lang.String.class, medElig.getFirstName(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("middleInitial", java.lang.String.class, medElig.getMiddleInitial(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("genderCd", java.lang.String.class, medElig.getGenderCd(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("raceCd", java.lang.String.class, medElig.getRaceCd(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("birthDate", java.lang.String.class, medElig.getBirthDate(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("prtAEntitlementDate", java.lang.String.class, medElig.getPrtAEntitlementDate(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("prtAEntitleEndDate", java.lang.String.class, medElig.getPrtAEntitleEndDate(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("prtBEntitlementDate", java.lang.String.class, medElig.getPrtBEntitlementDate(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("prtBEntitleEndDate", java.lang.String.class, medElig.getPrtBEntitleEndDate(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("stateCd", java.lang.String.class, medElig.getStateCd(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("countyCd", java.lang.String.class, medElig.getCountyCd(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("hospiceStatus", java.lang.String.class, medElig.getHospiceStatus(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("hospiceStartDate", java.lang.String.class, medElig.getHospiceStartDate(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("hospiceEndDate", java.lang.String.class, medElig.getHospiceEndDate(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("instStatus", java.lang.String.class, medElig.getInstStatus(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("instStartDate", java.lang.String.class, medElig.getInstStartDate(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("instEndDate", java.lang.String.class, medElig.getInstEndDate(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("esrdStatus", java.lang.String.class, medElig.getEsrdStatus(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("esrdStartDate", java.lang.String.class, medElig.getEsrdStartDate(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("esrdEndDate", java.lang.String.class, medElig.getEsrdEndDate(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("medicaidStatus", java.lang.String.class, medElig.getMedicaidStatus(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("medicaidStartDate", java.lang.String.class, medElig.getMedicaidStartDate(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("medicaidEndDate", java.lang.String.class, medElig.getMedicaidEndDate(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("eghpInd", java.lang.String.class, medElig.getEghpInd(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("livingStatus", java.lang.String.class, medElig.getLivingStatus(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("deathDate", java.lang.String.class, medElig.getDeathDate(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("xrefHicNbr", java.lang.String.class, medElig.getXrefHicNbr(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("enrollmentInfo", com.ps.mss.soap.EligibilityService.EnrollmentData[].class, medElig.getEnrollmentInfo(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("potentialUncvrdMths", java.lang.String.class, medElig.getPotentialUncvrdMths(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("potentialUncvrdMthsEffDate", java.lang.String.class, medElig.getPotentialUncvrdMthsEffDate(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("prtDEligibleDate", java.lang.String.class, medElig.getPrtDEligibleDate(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("lisInfo", com.ps.mss.soap.EligibilityService.LisData[].class, medElig.getLisInfo(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("prtDHistInfo", com.ps.mss.soap.EligibilityService.PartDHistory[].class, medElig.getPrtDHistInfo(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("nuncMoInfo", com.ps.mss.soap.EligibilityService.NuncMoData[].class, medElig.getNuncMoInfo(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	param = new Parameter("rdsHistInfo", com.ps.mss.soap.EligibilityService.RDSHistoryData[].class, medElig.getRdsHistInfo(), null);
    	xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
    	sink.write(StringUtils.lineSeparator);

    	sink.write("</" + context + '>');

    	nsStack.popScope();
    }

	/* (non-Javadoc)
	 * @see org.apache.soap.util.xml.Deserializer#unmarshall(java.lang.String, org.apache.soap.util.xml.QName, org.w3c.dom.Node, org.apache.soap.util.xml.XMLJavaMappingRegistry, org.apache.soap.rpc.SOAPContext)
	 */
    public Bean unmarshall(String inScopeEncStyle, QName elementType,
            Node src, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
  			throws IllegalArgumentException {

  	Element root = (Element)src;
  	Element tempEl = DOMUtils.getFirstChildElement(root);
  	EligibilityQueryRsp medElig;

  	try {
  		medElig = (EligibilityQueryRsp)EligibilityQueryRsp.class.newInstance();
  	} catch (Exception e) {
  		throw new IllegalArgumentException("Problem instantiating bean: " + e.getMessage());
  	}

  	while (tempEl != null) {

  		String tagName = tempEl.getTagName();

  		Bean paramBean = xjmr.unmarshall(inScopeEncStyle,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
  		Parameter param = (Parameter)paramBean.value;
        
  		if (tagName.equals("txnDate")) {
  			medElig.setTxnDate((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("mbdLoadEffDate")) {
  			medElig.setMbdLoadEffDate((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("requestHicNbr")) {
  			medElig.setRequestHicNbr((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("requestLastName")) {
  			medElig.setRequestLastName((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("requestDOB")) {
  			medElig.setRequestDOB((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("foundHicNbr")) {
  			medElig.setFoundHicNbr((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("foundNameorDOB")) {
  			medElig.setFoundNameorDOB((java.lang.String)param.getValue());
  		}                
  		else if (tagName.equals("inquiryResponse")) {
  			medElig.setInquiryResponse((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("hicNbr")) {
  			medElig.setHicNbr((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("lastName")) {
  			medElig.setLastName((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("firstName")) {
  			medElig.setFirstName((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("middleInitial")) {
  			medElig.setMiddleInitial((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("genderCd")) {
  			medElig.setGenderCd((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("raceCd")) {
  			medElig.setRaceCd((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("birthDate")) {
  			medElig.setBirthDate((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("prtAEntitlementDate")) {
  			medElig.setPrtAEntitlementDate((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("prtAEntitleEndDate")) {
  			medElig.setPrtAEntitleEndDate((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("prtBEntitlementDate")) {
  			medElig.setPrtBEntitlementDate((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("prtBEntitleEndDate")) {
  			medElig.setPrtBEntitleEndDate((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("stateCd")) {
  			medElig.setStateCd((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("countyCd")) {
  			medElig.setCountyCd((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("hospiceStatus")) {
  			medElig.setHospiceStatus((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("hospiceStartDate")) {
  			medElig.setHospiceStartDate((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("hospiceEndDate")) {
  			medElig.setHospiceEndDate((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("instStatus")) {
  			medElig.setInstStatus((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("instStartDate")) {
  			medElig.setInstStartDate((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("instEndDate")) {
  			medElig.setInstEndDate((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("esrdStatus")) {
  			medElig.setEsrdStatus((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("esrdStartDate")) {
  			medElig.setEsrdStartDate((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("esrdEndDate")) {
  			medElig.setEsrdEndDate((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("medicaidStatus")) {
  			medElig.setMedicaidStatus((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("medicaidStartDate")) {
  			medElig.setMedicaidStartDate((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("medicaidEndDate")) {
  			medElig.setMedicaidEndDate((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("eghpInd")) {
  			medElig.setEghpInd((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("livingStatus")) {
  			medElig.setLivingStatus((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("deathDate")) {
  			medElig.setDeathDate((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("xrefHicNbr")) {
  			medElig.setXrefHicNbr((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("enrollmentInfo")) {
  			medElig.setEnrollmentInfo((com.ps.mss.soap.EligibilityService.EnrollmentData[])param.getValue());
  		}
  		else if (tagName.equals("potentialUncvrdMths")) {
  			medElig.setPotentialUncvrdMths((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("potentialUncvrdMthsEffDate")) {
  			medElig.setPotentialUncvrdMthsEffDate((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("prtDEligibleDate")) {
  			medElig.setPrtDEligibleDate((java.lang.String)param.getValue());
  		}
  		else if (tagName.equals("lisInfo")) {
  			medElig.setLisInfo((com.ps.mss.soap.EligibilityService.LisData[])param.getValue());
  		}
  		else if (tagName.equals("prtDHistInfo")) {
  			medElig.setPrtDHistInfo((com.ps.mss.soap.EligibilityService.PartDHistory[])param.getValue());
  		}
  		else if (tagName.equals("nuncMoInfo")) {
  			medElig.setNuncMoInfo((com.ps.mss.soap.EligibilityService.NuncMoData[])param.getValue());
  		}
  		else if (tagName.equals("rdsHistInfo")) {
  			medElig.setRdsHistInfo((com.ps.mss.soap.EligibilityService.RDSHistoryData[])param.getValue());
  		}

  		tempEl = DOMUtils.getNextSiblingElement(tempEl);
  	}

  	return new Bean(EligibilityQueryRsp.class, medElig);
  }    
}
