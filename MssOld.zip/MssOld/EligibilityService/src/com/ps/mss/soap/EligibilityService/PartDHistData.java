/*
 * $Id: PartDHistData.java,v 1.1 2014/06/26 07:24:11 praveen Exp $
 */

package com.ps.mss.soap.EligibilityService;

/**
 *
 * @author  alevin
 */
public class PartDHistData {
    
    private String prtDStartDate;
    private String prtDEndDate;
    private String rdsIndicator;
    
    /** Creates a new instance of partDHistory */
    public PartDHistData() {
    }
    
    /**
     * Getter for property prtDEndDate.
     * @return Value of property prtDEndDate.
     */
    public java.lang.String getPrtDStartDate() {
        return prtDStartDate;
    }
    
    /**
     * Setter for property prtDStartDate.
     * @param prtDStartDate New value of property prtDStartDate.
     */
    public void setPrtDStartDate(java.lang.String prtDStartDate) {
        this.prtDStartDate = prtDStartDate;
    }
    
    /**
     * Getter for property prtDEndDate.
     * @return Value of property prtDEndDate.
     */
    public java.lang.String getPrtDEndDate() {
        return prtDEndDate;
    }
    
    /**
     * Setter for property pbpStartDate.
     * @param pbpStartDate New value of property pbpStartDate.
     */
    public void setPrtDEndDate(java.lang.String prtDEndDate) {
        this.prtDEndDate = prtDEndDate;
    }
    
	/**
	 * @return Returns the rdsInd.
	 */
	public String getRdsIndicator() {
		return rdsIndicator;
	}
	/**
	 * @param rdsInd The rdsInd to set.
	 */
	public void setRdsIndicator(String rdsIndicator) {
		this.rdsIndicator = rdsIndicator;
	}
}
