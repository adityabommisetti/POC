/*
 * lisDataSerializer.java
 *
 * Created on November 2, 2006, 3:45 PM
 */

package com.ps.mss.soap.EligibilityService;

import java.io.IOException;
import java.io.Writer;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import org.apache.soap.util.StringUtils;
import org.apache.soap.util.Bean;
import org.apache.soap.util.xml.Deserializer;
import org.apache.soap.util.xml.Serializer;
import org.apache.soap.util.xml.NSStack;
import org.apache.soap.util.xml.XMLJavaMappingRegistry;
import org.apache.soap.util.xml.QName;
import org.apache.soap.util.xml.DOMUtils;
import org.apache.soap.encoding.soapenc.SoapEncUtils;
import org.apache.soap.rpc.SOAPContext;
import org.apache.soap.rpc.Parameter;
import org.apache.soap.rpc.RPCConstants;

import com.ps.mss.soap.EligibilityService.LisData;

/**
 *
 * @author  alevin
 */
public class LisDataSerializer implements Serializer, Deserializer{
    
    /** Creates a new instance of lisDataSerializer */
    public LisDataSerializer() {
    }
    
    public void marshall(String inScopeEncStyle, Class javaType,
                         Object src, Object context, Writer sink,
                         NSStack nsStack, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
            throws IllegalArgumentException, IOException
    {
        nsStack.pushScope();

        SoapEncUtils.generateStructureHeader(inScopeEncStyle, javaType, context, sink, nsStack, xjmr);

        sink.write(StringUtils.lineSeparator);

        LisData lisData = (LisData)src;
        Parameter param;

        param = new Parameter("subsidyStartDate", java.lang.String.class, lisData.getSubsidyStartDate(), null);
        xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
        sink.write(StringUtils.lineSeparator);

        param = new Parameter("subsidyEndDate", java.lang.String.class, lisData.getSubsidyEndDate(), null);
        xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
        sink.write(StringUtils.lineSeparator);
        
        param = new Parameter("copayLevel", java.lang.String.class, lisData.getCopayLevel(), null);
        xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
        sink.write(StringUtils.lineSeparator);
        
        param = new Parameter("prtDPremSubPct", java.lang.String.class, lisData.getPrtDPremSubPct(), null);
        xjmr.marshall(inScopeEncStyle, Parameter.class, param, null, sink, nsStack, ctx);
        sink.write(StringUtils.lineSeparator);
        
        sink.write("</" + context + '>');

        nsStack.popScope();
    }
    
    public Bean unmarshall(String inScopeEncStyle, QName elementType,
                           Node src, XMLJavaMappingRegistry xjmr, SOAPContext ctx)
            throws IllegalArgumentException
    {
        Element root = (Element)src;
        Element tempEl = DOMUtils.getFirstChildElement(root);
        LisData lisData;

        try {
            lisData = (LisData)LisData.class.newInstance();
        } catch (Exception e) {
            throw new IllegalArgumentException("Problem instantiating bean: " + e.getMessage());
        }

        while (tempEl != null)
        {
            Bean paramBean = xjmr.unmarshall(inScopeEncStyle,RPCConstants.Q_ELEM_PARAMETER,tempEl, ctx);
            Parameter param = (Parameter)paramBean.value;
            String tagName = tempEl.getTagName();

            if (tagName.equals("subsidyStartDate"))
            {
                lisData.setSubsidyStartDate((java.lang.String)param.getValue());
            }
            else
            if (tagName.equals("subsidyEndDate"))
            {
                lisData.setSubsidyEndDate((java.lang.String)param.getValue());
            }
            else
            if (tagName.equals("copayLevel"))
            {
                lisData.setCopayLevel((java.lang.String)param.getValue());
            }
            else
            if (tagName.equals("prtDPremSubPct"))
            {
                lisData.setPrtDPremSubPct((java.lang.String)param.getValue());
            }
            
            tempEl = DOMUtils.getNextSiblingElement(tempEl);
        }

        return new Bean(LisData.class, lisData);
    }
    
}
