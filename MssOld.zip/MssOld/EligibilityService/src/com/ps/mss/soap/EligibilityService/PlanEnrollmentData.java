/*
 * $Id: PlanEnrollmentData.java,v 1.1 2014/06/26 07:24:11 praveen Exp $
 */

package com.ps.mss.soap.EligibilityService;

/**
 *
 * @author  alevin
 */
public class PlanEnrollmentData {
    
    private String planId;
    private String pbpId;
    private String planEnrollmentDate;
    private String planDisenrollmentDate;
    private String pbpStartDate;
    private String pbpEndDate;
    
    /** Creates a new instance of EnrollmentData */
    public PlanEnrollmentData() {
    }
    
    /**
     * Getter for property planId.
     * @return Value of property planId.
     */
    public java.lang.String getPlanId() {
        return planId;
    }
    
    /**
     * Setter for property planId.
     * @param planId New value of property planId.
     */
    public void setPlanId(java.lang.String planId) {
        this.planId = planId;
    }
    
    /**
     * Getter for property pbpId.
     * @return Value of property pbpId.
     */
    public java.lang.String getPbpId() {
        return pbpId;
    }
    
    /**
     * Setter for property pbpId.
     * @param pbpId New value of property pbpId.
     */
    public void setPbpId(java.lang.String pbpId) {
        this.pbpId = pbpId;
    }
    
    /**
     * Getter for property planEnrollmentDate.
     * @return Value of property planEnrollmentDate.
     */
    public java.lang.String getPlanEnrollmentDate() {
        return planEnrollmentDate;
    }
    
    /**
     * Setter for property planEnrollmentDate.
     * @param planEnrollmentDate New value of property planEnrollmentDate.
     */
    public void setPlanEnrollmentDate(java.lang.String planEnrollmentDate) {
        this.planEnrollmentDate = planEnrollmentDate;
    }
    
    /**
     * Getter for property planDisenrollmentDate.
     * @return Value of property planDisenrollmentDate.
     */
    public java.lang.String getPlanDisenrollmentDate() {
        return planDisenrollmentDate;
    }
    
    /**
     * Setter for property planDisenrollmentDate.
     * @param planDisenrollmentDate New value of property planDisenrollmentDate.
     */
    public void setPlanDisenrollmentDate(java.lang.String planDisenrollmentDate) {
        this.planDisenrollmentDate = planDisenrollmentDate;
    }
	/**
	 * @return Returns the pbpStartDate.
	 */
	public String getPBPStartDate() {
		return pbpStartDate;
	}
	/**
	 * @param pbpStartDate The pbpStartDate to set.
	 */
	public void setPBPStartDate(String pbpStartDate) {
		this.pbpStartDate = pbpStartDate;
	}    
	/**
	 * @return Returns the pbpEndDate.
	 */
	public String getPBPEndDate() {
		return pbpEndDate;
	}
	/**
	 * @param pbpEndDate The pbpEndDate to set.
	 */
	public void setPBPEndDate(String pbpEndDate) {
		this.pbpEndDate = pbpEndDate;
	}

}
