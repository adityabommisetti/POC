/*
 * $Id: NuncMoData.java,v 1.1 2014/06/26 07:24:11 praveen Exp $
 */
package com.ps.mss.soap.EligibilityService;

public class NuncMoData {

	private String uncovMthsStartDate;
	private String uncovMths;
	private String nuncmoInd;
	private String totUncovMths;
	
	public NuncMoData() {
	}

	/**
	 * @return Returns the nuncmoInd.
	 */
	public String getNuncmoInd() {
		return nuncmoInd;
	}
	/**
	 * @param nuncmoInd The nuncmoInd to set.
	 */
	public void setNuncmoInd(String nuncmoInd) {
		this.nuncmoInd = nuncmoInd;
	}
	/**
	 * @return Returns the totUncovMths.
	 */
	public String getTotUncovMths() {
		return totUncovMths;
	}
	/**
	 * @param totUncovMths The totUncovMths to set.
	 */
	public void setTotUncovMths(String totUncovMths) {
		this.totUncovMths = totUncovMths;
	}
	/**
	 * @return Returns the uncovMths.
	 */
	public String getUncovMths() {
		return uncovMths;
	}
	/**
	 * @param uncovMths The uncovMths to set.
	 */
	public void setUncovMths(String uncovMths) {
		this.uncovMths = uncovMths;
	}
	/**
	 * @return Returns the uncovMthsStartDate.
	 */
	public String getUncovMthsStartDate() {
		return uncovMthsStartDate;
	}
	/**
	 * @param uncovMthsStartDate The uncovMthsStartDate to set.
	 */
	public void setUncovMthsStartDate(String uncovMthsStartDate) {
		this.uncovMthsStartDate = uncovMthsStartDate;
	}
}
