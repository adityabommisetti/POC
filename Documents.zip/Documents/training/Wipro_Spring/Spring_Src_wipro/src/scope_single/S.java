package scope_single;

public class S {

}
