package scope_protype;

public class T {

}
