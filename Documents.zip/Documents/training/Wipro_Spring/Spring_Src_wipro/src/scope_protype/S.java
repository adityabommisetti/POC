package scope_protype;

public class S {

}
